sub init()
m.heroBackdrop = m.top.findNode(_l1d_462afc("8f857b91719596a19b90a698", 215, 208))
m.heroBadge = m.top.findNode(_l1d_462afc("c1c1d1d1e7c9cfd5d6", 224, 57))
m.heroTitle = m.top.findNode(_l1d_462afc("cfcdbbd9a7ddcde8e2", 83, 148))
m.heroMeta = m.top.findNode(_l1d_462afc("231933290a25392f", 69, 246))
m.heroDesc = m.top.findNode(_l1d_462afc("343244421c3e4f42", 65, 11))
m.heroPlayBtn = m.top.findNode(_l1d_462afc("f6ee06feea01011ce81512", 68, 202))
m.heroWatchlistBtn = m.top.findNode(_l1d_462afc("8e9c8e9c77a49caca6adaba8ae9fb4c1", 89, 93))
m.rowList = m.top.findNode(_l1d_462afc("ead2edb5ddfaf6", 204, 44))
m.loadingGroup = m.top.findNode(_l1d_462afc("aeaebfbfbdbbc5a8e0c6e3eb", 143, 203))
m.heroPlayBtn.observeField(_l1d_462afc("b8d0d4d7cfd3b9d2ded8d5efe1e5", 131, 215), _l1d_462afc("1113fc14282010272742", 6, 168))
m.heroWatchlistBtn.observeField(_l1d_462afc("273b3f423e42283d4943445a4c50", 65, 4), _l1d_462afc("e2e60ff50bf12c05150907060c25274a121d201e28", 239, 98))
m.rowList.observeField(_l1d_462afc("503651225a4c474455515b60726468", 207, 147), _l1d_462afc("787cab818ca991838ebf8c98929ba99b9f", 37, 46))
m.rowList.observeField(_l1d_462afc("6b616c4971636e4c7675828b787c", 5, 244), _l1d_462afc("aaac73b39e93a1b5c09cc8bfb4b5cacc", 144, 171))
m.top.observeField(_l1d_462afc("6c7877646d7a7c", 212, 186), _l1d_462afc("7579947e756e6b9e8c86948e93", 115, 89))
loadHomeData()
end sub
sub onFocusChange()
if ((8320 - 1040 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.top.hasFocus() then
if m.rowList <> invalid then m.rowList.setFocus(true)
end if
end sub
sub onCategoryChange()
loadHomeData()
end sub
sub loadHomeData()
if ((36846 - 4094 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.loadingGroup.visible = true
if m.catalogTask <> invalid then m.catalogTask.control = _l1d_462afc("f6001802", 211, 118)
m.catalogTask = CreateObject(_l1d_462afc("766c9b8a96787274", 101, 95), _l1d_462afc("c7a8c0aebec2bdefbdd2cd", 33, 101))
_lIl1lIl = m.top.category
if _lIl1lIl = invalid or _lIl1lIl = "" then _lIl1lIl = _l1d_462afc("2a2e332e", 227, 159)
m.catalogTask.category = _lIl1lIl
m.catalogTask.observeField(_l1d_462afc("3b35424b4550", 66, 11), _l1d_462afc("0b0f25061e0c1c201b45291e26282c", 225, 125))
m.catalogTask.control = _l1d_462afc("35354f", 55, 208)
end sub
sub onCatalogLoaded()
if ((38082 - 6347 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.loadingGroup.visible = false
_ll1lIIl = m.catalogTask.result
if _ll1lIIl <> invalid and _ll1lIIl.getChildCount() > 0 then
m.rowList.content = _ll1lIIl
_lIllIIl = _ll1lIIl.getChild(0)
if _lIllIIl <> invalid and _lIllIIl.getChildCount() > 0 then
updateHero(_lIllIIl.getChild(0))
end if
m.rowList.setFocus(true)
else if m.top.category = _l1d_462afc("a3aaae97b5b79fb2", 21, 45) or m.top.category = _l1d_462afc("4f3c54444e4c50", 129, 89) then
_llllIIl = CreateObject(_l1d_462afc("7b79605763858385", 131, 138), _l1d_462afc("5d4c4e574b57607d61595d", 96, 58))
_l1llIIl = _llllIIl.createChild(_l1d_462afc("e60d111e101a2700222022", 199, 98))
_l1llIIl.title = _l1d_462afc("8b72765f7d7f677a429287778f999b9d975d68c9ab69b4b6a3a1bdadb581bbc2b694", 181, 149)
m.rowList.content = _llllIIl
end if
end sub
sub onRowItemFocused()
_lllIll1 = m.rowList.rowItemFocused
if _lllIll1 <> invalid and _lllIll1.Count() >= 2 then
_lIlIll1 = _lllIll1[0]
_l1I1ll1 = _lllIll1[1]
_lII1ll1 = m.rowList.content
if _lII1ll1 <> invalid and _lIlIll1 < _lII1ll1.getChildCount() then
_l1lIll1 = _lII1ll1.getChild(_lIlIll1)
if _l1lIll1 <> invalid and _l1I1ll1 < _l1lIll1.getChildCount() then
updateHero(_l1lIll1.getChild(_l1I1ll1))
end if
end if
end if
m.top.scrollEvent = true
end sub
sub updateHero(_l1IlIl1 as Object)
if ((33768 - 8442 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _l1IlIl1 = invalid then return
m.currentItem = _l1IlIl1
m.heroBackdrop.uri = _l1IlIl1.HDBackgroundImageUrl
m.heroTitle.text = _l1IlIl1.title
_lIIlIl1 = _l1d_462afc("f1f2fef6f5", 131, 35)
if _l1IlIl1.kind <> invalid and _l1IlIl1.kind = _l1d_462afc("5e63", 24, 242) then
_lIIlIl1 = _l1d_462afc("a7acc1b79fa1bc", 236, 239)
else if _l1IlIl1.ContentType = 2 then
_lIIlIl1 = _l1d_462afc("474c394f57615c", 152, 123)
end if
if m.heroBadge <> invalid then
m.heroBadge.text = _l1d_462afc("36363d4d4f59454970", 237, 139) + _lIIlIl1
end if
_l1l1Il1 = ""
if _l1IlIl1.Rating <> invalid and _l1IlIl1.Rating <> "" then
_l1l1Il1 = _l1d_462afc("e3e0", 6, 183) + _l1IlIl1.Rating + _l1d_462afc("cdd0d3", 233, 4)
end if
if _l1IlIl1.ReleaseDate <> invalid and _l1IlIl1.ReleaseDate <> "" then
_l1l1Il1 = _l1l1Il1 + _l1IlIl1.ReleaseDate + _l1d_462afc("bdc0e7c6c9", 62, 159)
end if
_l1l1Il1 = _l1l1Il1 + _lIIlIl1
if _l1IlIl1.Categories <> invalid and _l1IlIl1.Categories.Count() > 0 then
_lI1lIl1 = ""
_lll1Il1 = 2
if _l1IlIl1.Categories.Count() <= 2 then _lll1Il1 = _l1IlIl1.Categories.Count() - 1
for _llIlIl1 = 0 to _lll1Il1
if _llIlIl1 > 0 then _lI1lIl1 = _lI1lIl1 + _l1d_462afc("9b92", 161, 14)
_lI1lIl1 = _lI1lIl1 + _l1IlIl1.Categories[_llIlIl1].ToStr()
end for
if _lI1lIl1 <> "" then _l1l1Il1 = _l1l1Il1 + _l1d_462afc("4447a64d50", 35, 65) + _lI1lIl1
end if
m.heroMeta.text = _l1l1Il1
m.heroDesc.text = _l1IlIl1.description
updateHeroWatchlistBtn()
end sub
sub updateHeroWatchlistBtn()
if m.currentItem = invalid or m.heroWatchlistBtn = invalid then return
if WL_IsFavorite(m.currentItem.id) then
m.heroWatchlistBtn.text = _l1d_462afc("d1e6ca83d9cac0cedae1e1cad2fe", 50, 104)
else
m.heroWatchlistBtn.text = _l1d_462afc("abb5ad7a92827c83819ea4", 105, 105)
end if
end sub
sub onHeroWatchlistToggle()
if m.currentItem = invalid then return
_lIl1I11 = _l1d_462afc("9398829897", 80, 86)
if m.currentItem.kind <> invalid and (m.currentItem.kind = _l1d_462afc("999a", 139, 154) or m.currentItem.kind = _l1d_462afc("857a8a748394", 136, 138)) then
_lIl1I11 = _l1d_462afc("8485", 71, 81)
else if m.currentItem.ContentType = 2 then
_lIl1I11 = _l1d_462afc("7075", 220, 200)
end if
_l1l1I11 = {
id: m.currentItem.id,
title: m.currentItem.Title,
kind: _lIl1I11,
year: m.currentItem.ReleaseDate,
poster: m.currentItem.HDPosterUrl,
rating: m.currentItem.Rating
}
WL_ToggleFavorite(_l1l1I11)
updateHeroWatchlistBtn()
_ll11I11 = m.top.getScene()
if _ll11I11 <> invalid and _ll11I11.hasField(_l1d_462afc("f80402fde10b1c0d0d", 222, 75)) then
if WL_IsFavorite(m.currentItem.id) then
_ll11I11.showToast = _l1d_462afc("714654484c93625a9c886171657372788183d0bd", 103, 61) + m.currentItem.Title
else
_ll11I11.showToast = _l1d_462afc("9ba7b2b7c3b3b7febfd6cccd0dbdd2e2dae4e3e9f6f4", 197, 4)
end if
end if
end sub
sub onRowItemSelected()
_l1ll1I1 = m.rowList.rowItemSelected
if _l1ll1I1 <> invalid and _l1ll1I1.Count() >= 2 then
_ll1l1I1 = _l1ll1I1[0]
_lIIIlI1 = _l1ll1I1[1]
_llll1I1 = m.rowList.content
if _llll1I1 <> invalid and _ll1l1I1 < _llll1I1.getChildCount() then
_lIll1I1 = _llll1I1.getChild(_ll1l1I1)
if _lIll1I1 <> invalid and _lIIIlI1 < _lIll1I1.getChildCount() then
m.top.selectedItem = _lIll1I1.getChild(_lIIIlI1)
end if
end if
end if
end sub
sub onHeroPlay()
if ((17964 - 4491 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.currentItem <> invalid then
m.top.selectedItem = m.currentItem
end if
end sub
function onKeyEvent(_l11l1lI as String, _lI1l1lI as Boolean) as Boolean
if not _lI1l1lI then return false
if _l11l1lI = _l1d_462afc("9bb5b6baa9", 240, 25) then
if m.heroPlayBtn.hasFocus() then
m.heroWatchlistBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("111d1d12", 58, 187) then
if m.heroWatchlistBtn.hasFocus() then
m.heroPlayBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("ccd2", 36, 123) then
if m.rowList.hasFocus() and m.rowList.rowItemFocused[0] = 0 then
m.heroPlayBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("b5bfaac4", 50, 95) then
if m.heroPlayBtn.hasFocus() or m.heroWatchlistBtn.hasFocus() then
m.rowList.setFocus(true)
return true
end if
end if
return false
end function
function _l1d_462afc(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function