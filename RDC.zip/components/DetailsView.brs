sub init()
m.backdrop = m.top.findNode(_l1d_6bae63("a3a3a8a3b1c2b0c6", 201, 248))
m.poster = m.top.findNode(_l1d_6bae63("ebd7eef8eaf8", 107, 208))
m.title = m.top.findNode(_l1d_6bae63("dfffe500fc", 212, 63))
m.subMeta = m.top.findNode(_l1d_6bae63("b9c2cef0dbcddd", 186, 240))
m.genres = m.top.findNode(_l1d_6bae63("faff0918081d", 39, 186))
m.description = m.top.findNode(_l1d_6bae63("bfc3b8cbbddbc5c4e4e1e3", 54, 109))
m.playBtn = m.top.findNode(_l1d_6bae63("c4abbbc6a2cfbc", 140, 200))
m.favBtn = m.top.findNode(_l1d_6bae63("f2fc08df10f9", 78, 202))
m.seriesSection = m.top.findNode(_l1d_6bae63("95869a888fa487989dad9d9a9c", 14, 24))
m.seasonDropdownBtn = m.top.findNode(_l1d_6bae63("dacfcee3d2d6bff0def4ebe702eed50af7", 137, 224))
m.seasonInfoLabel = m.top.findNode(_l1d_6bae63("ff0c13080f11f717221efe2e32302a", 220, 80))
m.episodesGrid = m.top.findNode(_l1d_6bae63("93a19da6a5a1a5b2c9b7b5b3", 162, 204))
m.seasonDropdownGroup = m.top.findNode(_l1d_6bae63("95a6ad9eb5b7d4a9c1b1c0cab5cfebc1d9c6cc", 182, 208))
m.seasonList = m.top.findNode(_l1d_6bae63("6f8087787f83688e8789", 95, 67))
m.loadingNotice = m.top.findNode(_l1d_6bae63("61616262706e68947684827b7c", 231, 214))
m.playBtn.observeField(_l1d_6bae63("877d7f829092aa9f99a5a69aaeb0", 56, 45), _l1d_6bae63("8a8e87969ca780a2a0a9a4b5b9", 139, 166))
m.favBtn.observeField(_l1d_6bae63("cfdfe3e6ced210e1dde7ecfef0f4", 47, 130), _l1d_6bae63("edf1dcfcf2e0020009041519", 27, 121))
m.seasonDropdownBtn.observeField(_l1d_6bae63("534d4f525c5e766f6975726a7e80", 186, 123), _l1d_6bae63("90948a9f9eb3a2a68fc0aec4bbb7d2bea5dac7adcbc9d6d1dee2", 137, 170))
m.seasonList.observeField(_l1d_6bae63("869488937c919b9798aca0a2", 128, 157), _l1d_6bae63("e3e525f6fd0ef5f71c041d1d43140e1a1f2f2325", 110, 226))
m.episodesGrid.observeField(_l1d_6bae63("8f7d919ca19aa4a09d95a9ab", 178, 180), _l1d_6bae63("454771475350575f637c69636f7864787a", 60, 242))
m.episodesGrid.observeField(_l1d_6bae63("0510fd23", 134, 36), _l1d_6bae63("6a6c4a78747d7c787c89608e8c8a6c9784a2", 194, 189))
m.allSeasons = []
m.selectedSeasonIndex = 0
m.top.observeField(_l1d_6bae63("d7d3e2d3d8e9eb", 254, 63), _l1d_6bae63("f3f722fc0318192c0610121c1d", 105, 237))
end sub
sub onEpisodesGridGoUp()
m.seasonDropdownBtn.setFocus(true)
end sub
sub onFocusChange()
if ((14476 - 2068 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.top.hasFocus() then
if m.playBtn <> invalid then m.playBtn.setFocus(true)
end if
end sub
sub onContentChange()
_lIl1lIl = m.top.content
if _lIl1lIl = invalid then return
m.backdrop.uri = _lIl1lIl.HDBackgroundImageUrl
m.poster.uri = _lIl1lIl.HDPosterUrl
m.title.text = _lIl1lIl.Title
_l1I1lIl = _l1d_6bae63("4146524645", 129, 85)
if _lIl1lIl.kind <> invalid and (_lIl1lIl.kind = _l1d_6bae63("9192", 234, 243) or _lIl1lIl.kind = _l1d_6bae63("6f687472717e", 194, 190)) then
_l1I1lIl = _l1d_6bae63("7a7b", 95, 79)
else if _lIl1lIl.ContentType = 2 then
_l1I1lIl = _l1d_6bae63("0c0d", 131, 21)
end if
_l1lIlIl = _lIl1lIl.Title
if _l1lIlIl = invalid or _l1lIlIl = "" then _l1lIlIl = _lIl1lIl.title
_lllIlIl = _lIl1lIl.HDPosterUrl
if (_lllIlIl = invalid or _lllIlIl = "") and Left(_lIl1lIl.id, 2) = _l1d_6bae63("8083", 170, 162) then
_lllIlIl = _l1d_6bae63("3b5a5d5c5e181013545b62676c79276d788a7a7494803f979b8f909952aa98afb7abb767beafb6b4b779", 42, 249) + _lIl1lIl.id + _l1d_6bae63("85c2c9d6", 184, 238)
end if
W_RememberContext(_lIl1lIl.id, {
title:  _l1lIlIl,
poster: _lllIlIl,
kind:   _l1I1lIl,
imdb:   _lIl1lIl.id,
year:   _lIl1lIl.ReleaseDate,
rating: _lIl1lIl.Rating
})
_lII1lIl = ""
if _lIl1lIl.Rating <> invalid and _lIl1lIl.Rating <> "" then _lII1lIl = _l1d_6bae63("665f", 32, 92) + _lIl1lIl.Rating + _l1d_6bae63("8c8fbe9598", 154, 210)
if _lIl1lIl.ReleaseDate <> invalid and _lIl1lIl.ReleaseDate <> "" then _lII1lIl = _lII1lIl + _lIl1lIl.ReleaseDate + _l1d_6bae63("dee128e7ea", 44, 210)
_llI1lIl = _l1d_6bae63("fdfe0a0201", 227, 79)
_lI11lIl = false
if _lIl1lIl.kind <> invalid and (_lIl1lIl.kind = _l1d_6bae63("c9ca", 191, 254) or _lIl1lIl.kind = _l1d_6bae63("f300fa120902", 181, 45)) then
_llI1lIl = _l1d_6bae63("21267327111934", 201, 132)
_lI11lIl = true
else if _lIl1lIl.ContentType = 2 then
_llI1lIl = _l1d_6bae63("969b70a69ea0ab", 4, 70)
_lI11lIl = true
end if
_lII1lIl = _lII1lIl + _llI1lIl
m.subMeta.text = _lII1lIl
_ll11lIl = ""
if _lIl1lIl.Categories <> invalid and _lIl1lIl.Categories.Count() > 0 then
for _l111lIl = 0 to _lIl1lIl.Categories.Count() - 1
if _l111lIl > 0 then _ll11lIl = _ll11lIl + _l1d_6bae63("201f", 151, 101)
_ll11lIl = _ll11lIl + _lIl1lIl.Categories[_l111lIl].ToStr()
end for
end if
m.genres.text = _ll11lIl
m.description.text = _lIl1lIl.Description
updateFavButton()
if _lI11lIl then
m.seriesSection.visible = true
m.loadingNotice.visible = true
m.seasonDropdownGroup.visible = false
m.allSeasons = []
m.detailsTask = CreateObject(_l1d_6bae63("dcd201f0fcdedcde", 167, 7), _l1d_6bae63("ee1204141f250ff3231833", 144, 26))
m.detailsTask.imdbId = _lIl1lIl.id
m.detailsTask.observeField(_l1d_6bae63("857b8c918b96", 160, 179), _l1d_6bae63("191b082c1e2e292f25153740464a4c", 154, 36))
m.detailsTask.control = _l1d_6bae63("4b536d", 147, 138)
else
m.seriesSection.visible = false
m.loadingNotice.visible = false
m.seasonDropdownGroup.visible = false
end if
m.playBtn.setFocus(true)
end sub
sub updateFavButton()
if ((6312 - 1578 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_llllIIl = m.top.content
if _llllIIl = invalid then return
if WL_IsFavorite(_llllIIl.id) then
m.favBtn.text = _l1d_6bae63("e8fd1b5ce821112533323821230d", 215, 92)
else
m.favBtn.text = _l1d_6bae63("adb5877c6a847c7b83807c", 252, 214)
end if
end sub
sub onFavClicked()
_l1I1ll1 = m.top.content
if _l1I1ll1 = invalid then return
_lllIll1 = _l1d_6bae63("1d1e282a21", 230, 146)
if _l1I1ll1.kind <> invalid and (_l1I1ll1.kind = _l1d_6bae63("c4c5", 15, 73) or _l1I1ll1.kind = _l1d_6bae63("98ad9fb7b6a7", 145, 182)) then
_lllIll1 = _l1d_6bae63("898e", 160, 181)
else if _l1I1ll1.ContentType = 2 then
_lllIll1 = _l1d_6bae63("e4e5", 83, 189)
end if
_lII1ll1 = {
id: _l1I1ll1.id,
title: _l1I1ll1.Title,
kind: _lllIll1,
year: _l1I1ll1.ReleaseDate,
poster: _l1I1ll1.HDPosterUrl,
rating: _l1I1ll1.Rating
}
WL_ToggleFavorite(_lII1ll1)
updateFavButton()
end sub
sub onDetailsLoaded()
m.loadingNotice.visible = false
_lI1lIl1 = m.detailsTask.result
if _lI1lIl1 <> invalid and _lI1lIl1.seasons <> invalid and _lI1lIl1.seasons.Count() > 0 then
m.allSeasons = _lI1lIl1.seasons
populateSeasonDropdown()
selectSeason(0)
end if
end sub
sub populateSeasonDropdown()
_lI1Il11 = CreateObject(_l1d_6bae63("7f9d647b87a9a7a9", 83, 94), _l1d_6bae63("fcd3d7d0e2e0d906e8f2f4", 125, 190))
for _ll1Il11 = 0 to m.allSeasons.Count() - 1
_l1IIl11 = m.allSeasons[_ll1Il11]
_llIIl11 = _lI1Il11.createChild(_l1d_6bae63("bedddffcf0e805cef2fe02", 202, 53))
_l11Il11 = _l1d_6bae63("ccb9c0b5ccce0b", 116, 165) + _l1IIl11.number.ToStr()
if _l1IIl11.label <> invalid and _l1IIl11.label <> "" then _l11Il11 = _l1IIl11.label
_llIIl11.title = _l11Il11
end for
m.seasonList.content = _lI1Il11
end sub
sub onSeasonDropdownBtnClicked()
if m.seasonDropdownGroup.visible then
closeSeasonDropdown()
else
openSeasonDropdown()
end if
end sub
sub openSeasonDropdown()
if m.allSeasons.Count() = 0 then return
m.seasonDropdownGroup.visible = true
m.seasonList.jumpToItem = m.selectedSeasonIndex
m.seasonList.setFocus(true)
end sub
sub closeSeasonDropdown()
m.seasonDropdownGroup.visible = false
m.seasonDropdownBtn.setFocus(true)
end sub
sub onSeasonListSelected()
_l11l1lI = m.seasonList.itemSelected
if _l11l1lI >= 0 and _l11l1lI < m.allSeasons.Count() then
selectSeason(_l11l1lI)
end if
closeSeasonDropdown()
end sub
sub selectSeason(_lIIIIlI as Integer)
if _lIIIIlI < 0 or _lIIIIlI >= m.allSeasons.Count() then return
m.selectedSeasonIndex = _lIIIIlI
_l1IIIlI = m.allSeasons[_lIIIIlI]
_lllll1I = _l1d_6bae63("f7242b20373bf8", 21, 177) + _l1IIIlI.number.ToStr()
if _l1IIIlI.label <> invalid and _l1IIIlI.label <> "" then _lllll1I = _l1IIIlI.label
m.seasonDropdownBtn.text = _lllll1I + _l1d_6bae63("ced1bdadc5", 233, 5)
_ll1IIlI = 0
if _l1IIIlI.episodes <> invalid then _ll1IIlI = _l1IIIlI.episodes.Count()
m.seasonInfoLabel.text = _l1d_6bae63("08", 81, 143) + _ll1IIlI.ToStr() + _l1d_6bae63("c1697793809f979b8ce5", 208, 209)
_llIIIlI = CreateObject(_l1d_6bae63("37351c131f413f41", 131, 70), _l1d_6bae63("7b9a9e9bada7a48dafbdbf", 155, 163))
if _l1IIIlI.episodes <> invalid then
for each _lIlIIlI in _l1IIIlI.episodes
_l11IIlI = _llIIIlI.createChild(_l1d_6bae63("cffe00ed0109f6ef130f13", 18, 126))
_lI1IIlI = ""
if _lIlIIlI.episode <> invalid then
_lI1IIlI = _lIlIIlI.episode.ToStr()
end if
_l11IIlI.id = _lI1IIlI
_l11IIlI.Title = _lIlIIlI.title
_l11IIlI.ShortDescriptionLine1 = _l1d_6bae63("f8301a371e282a72", 205, 112) + _lI1IIlI
_l11IIlI.HDPosterUrl = _lIlIIlI.thumbnail
if _l11IIlI.HDPosterUrl = "" then _l11IIlI.HDPosterUrl = m.top.content.HDPosterUrl
_l11IIlI.Description = _lIlIIlI.description
end for
end if
m.episodesGrid.content = _llIIIlI
end sub
sub onPlayClicked()
if ((8238 - 1373 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lll111I = m.top.content
if _lll111I = invalid then return
_lIl111I = _l1d_6bae63("a5a6c2aab9", 235, 31)
if _lll111I.kind <> invalid and (_lll111I.kind = _l1d_6bae63("fbfc", 102, 233) or _lll111I.kind = _l1d_6bae63("f708fe1a1106", 247, 115)) then
_lIl111I = _l1d_6bae63("b7b8", 46, 93)
else if _lll111I.ContentType = 2 then
_lIl111I = _l1d_6bae63("f2f7", 65, 189)
end if
_l11111I = 1
_l1l111I = 1
if _lIl111I = _l1d_6bae63("7071", 34, 26) and m.allSeasons.Count() > 0 then
_ll1111I = m.allSeasons[m.selectedSeasonIndex]
if _ll1111I <> invalid then
_l11111I = _ll1111I.number
if _ll1111I.episodes <> invalid and _ll1111I.episodes.Count() > 0 then
_l1l111I = _ll1111I.episodes[0].episode
end if
end if
end if
m.top.playAction = {
imdbId: _lll111I.id,
title: _lll111I.Title,
kind: _lIl111I,
season: _l11111I,
episode: _l1l111I,
poster: _lll111I.HDPosterUrl
}
end sub
sub onEpisodeSelected()
if ((18390 - 3678 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1III1I = m.top.content
if _l1III1I = invalid or m.allSeasons.Count() = 0 then return
_l1lllII = m.allSeasons[m.selectedSeasonIndex]
_lllllII = m.episodesGrid.itemSelected
if _lllllII >= 0 and _lllllII < _l1lllII.episodes.Count() then
_lIIII1I = _l1lllII.episodes[_lllllII]
m.top.playAction = {
imdbId: _l1III1I.id,
title: _l1III1I.Title + _l1d_6bae63("03fb09bb", 206, 21) + _l1lllII.number.ToStr() + _l1d_6bae63("5a02", 82, 232) + _lIIII1I.episode.ToStr() + _l1d_6bae63("8883", 170, 254) + _lIIII1I.title + _l1d_6bae63("74", 6, 69),
kind: _l1d_6bae63("4a4f", 8, 206),
season: _l1lllII.number,
episode: _lIIII1I.episode,
poster: _l1III1I.HDPosterUrl
}
end if
end sub
function onKeyEvent(_llI11II as String, _l1I11II as Boolean) as Boolean
if not _l1I11II then return false
_lI111II = LCase(_llI11II)
if _lI111II = _l1d_6bae63("b4a2a1bfc0c4b2", 149, 186) or _lI111II = _l1d_6bae63("77", 255, 162) then
onFavClicked()
_lII11II = m.top.getScene()
if _lII11II <> invalid and _lII11II.hasField(_l1d_6bae63("637b7d688886837874", 244, 220)) then
if m.favBtn.text = _l1d_6bae63("bdaed60bc5d2e8dae2e9e9f6fae6", 64, 162) then
_lII11II.showToast = _l1d_6bae63("8c6a6d7173ba8973c3b18a988e8a8991aaaae2", 110, 93)
else
_lII11II.showToast = _l1d_6bae63("4d635e637d6f7130798878793f79869c8e868d8daaae", 8, 243)
end if
end if
return true
end if
if m.seasonDropdownGroup.visible then
if _lI111II = _l1d_6bae63("9fa1a6b1", 16, 45) or _lI111II = _l1d_6bae63("4b57576c", 78, 41) or _lI111II = _l1d_6bae63("1701120625", 232, 125) then
closeSeasonDropdown()
return true
end if
return false
end if
if _lI111II = _l1d_6bae63("b4aeb0c5", 163, 229) then
if m.favBtn.hasFocus() then
m.playBtn.setFocus(true)
return true
else if m.seasonDropdownBtn.hasFocus() then
if m.selectedSeasonIndex > 0 then
selectSeason(m.selectedSeasonIndex - 1)
end if
return true
end if
else if _lI111II = _l1d_6bae63("503a433f56", 44, 242) then
if m.playBtn.hasFocus() then
m.favBtn.setFocus(true)
return true
else if m.seasonDropdownBtn.hasFocus() then
if m.selectedSeasonIndex < m.allSeasons.Count() - 1 then
selectSeason(m.selectedSeasonIndex + 1)
end if
return true
end if
else if _lI111II = _l1d_6bae63("f7efeaf6", 95, 188) then
if m.playBtn.hasFocus() or m.favBtn.hasFocus() then
if m.seriesSection.visible then
m.seasonDropdownBtn.setFocus(true)
return true
end if
else if m.seasonDropdownBtn.hasFocus() then
if m.episodesGrid.content <> invalid and m.episodesGrid.content.getChildCount() > 0 then
m.episodesGrid.setFocus(true)
return true
end if
end if
else if _lI111II = _l1d_6bae63("bebe", 67, 136) then
if m.seasonDropdownBtn.hasFocus() then
m.playBtn.setFocus(true)
return true
end if
end if
return false
end function
function _l1d_6bae63(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function