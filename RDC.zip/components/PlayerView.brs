sub init()
m.videoPlayer = m.top.findNode(_l1d_2b697b("374f4f515a246359546351", 83, 18))
m.statusOverlay = m.top.findNode(_l1d_2b697b("f6f40afafc05fc081812272520", 149, 16))
m.statusTitle = m.top.findNode(_l1d_2b697b("322e463438415d4d434e5a", 124, 35))
m.statusText = m.top.findNode(_l1d_2b697b("94968c9c9ea38597a7ae", 79, 88))
m.cancelBtn = m.top.findNode(_l1d_2b697b("0207130b141ef32c25", 2, 161))
m.menuOverlay = m.top.findNode(_l1d_2b697b("15101a26ff2b1f2d2e243f", 131, 39))
m.menuTitle = m.top.findNode(_l1d_2b697b("2e39312f113937424e", 90, 247))
m.menuTime = m.top.findNode(_l1d_2b697b("19241e1afe2c2b36", 159, 39))
m.menuBtnBar = m.top.findNode(_l1d_2b697b("2c37332d5d323f66483c", 120, 23))
m.fitModes = [
{ label: _l1d_2b697b("29fc0e00030b4c291b216e5b6f7174646a754a403a3d85", 230, 116),  sx: 1.00, sy: 1.00 },
{ label: _l1d_2b697b("abded0eaede5aed3edeba0bda9b8cbc9c4de0e0e1b1312da", 26, 98), sx: 0.95, sy: 0.95 },
{ label: _l1d_2b697b("2e41534d50581136606e33203c362e2c3761767a803e757650", 2, 221), sx: 0.90, sy: 0.90 },
{ label: _l1d_2b697b("c497ab9b9ea869c6b6be8b7893897c848fe7ced3e3d5d6e8a6", 39, 80), sx: 0.85, sy: 0.85 },
{ label: _l1d_2b697b("56697b717480b55e8492dbc4dfdad2d0db8da2a0a4eb", 64, 67),   sx: 0.80, sy: 0.80 }
]
_lII11ll = U_PrefDefault(_l1d_2b697b("e9e8def9e8fad1f505df04fe00", 129, 248), 0)
if _lII11ll < 0 or _lII11ll >= m.fitModes.Count() then _lII11ll = 0
m.fitMode = _lII11ll
applyFitMode(m.fitMode)
m.cancelBtn.observeField(_l1d_2b697b("585054576f7379727e78756f8185", 51, 7), _l1d_2b697b("a7ab91b6b4bac3bf", 219, 243))
m.menuBtnBar.observeField(_l1d_2b697b("b4a2a4a7c5c797c4cecad3bfd3d5", 20, 62), _l1d_2b697b("a8aad0abb3c1d5c6bfefc0cac6cbdbcfd1", 102, 159))
m.videoPlayer.observeField(_l1d_2b697b("9e9c92a294", 205, 224), _l1d_2b697b("2327f22a2a2c35fc26342c3e", 83, 231))
m.videoPlayer.observeField(_l1d_2b697b("07f70ef717fd060a", 233, 110), _l1d_2b697b("1d21422625322a38353967454f454f54", 63, 205))
end sub
sub applyFitMode(_l1Ill1l as Integer)
if ((71976 - 8997 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.fitModes = invalid or m.fitModes.Count() = 0 then return
if _l1Ill1l < 0 or _l1Ill1l >= m.fitModes.Count() then _l1Ill1l = 0
m.fitMode = _l1Ill1l
_llIll1l = m.fitModes[_l1Ill1l]
_l111l1l = 1920
_ll11l1l = 1080
_lIl1l1l = Int(_l111l1l * _llIll1l.sx)
_l1l1l1l = Int(_ll11l1l * _llIll1l.sy)
_lIIll1l = Int((_l111l1l - _lIl1l1l) / 2)
_lll1l1l = Int((_ll11l1l - _l1l1l1l) / 2)
if m.videoPlayer <> invalid then
m.videoPlayer.translation = [_lIIll1l, _lll1l1l]
m.videoPlayer.width = _lIl1l1l
m.videoPlayer.height = _l1l1l1l
end if
end sub
sub onFitClicked()
_l11I11l = (m.fitMode + 1) Mod m.fitModes.Count()
U_PrefSet(_l1d_2b697b("3a392f4a394b22465630554f51", 193, 137), _l11I11l)
applyFitMode(_l11I11l)
if m.menuOverlay <> invalid and m.menuOverlay.visible then
updateMenuButtons()
refocusMenuButton(_l1d_2b697b("0addefe5e8f429", 224, 87))
end if
end sub
sub refocusMenuButton(_l111lIl as String)
if m.menuBtnBar = invalid then return
_lIl1lIl = m.menuBtnBar.buttons
if _lIl1lIl = invalid then return
for _ll11lIl = 0 to _lIl1lIl.Count() - 1
if Left(_lIl1lIl[_ll11lIl], Len(_l111lIl)) = _l111lIl then
if _ll11lIl < m.menuBtnBar.getChildCount() then
m.menuBtnBar.getChild(_ll11lIl).setFocus(true)
end if
exit for
end if
end for
end sub
sub onPlayConfigChange()
if ((29718 - 3302 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_llllIIl = m.top.playConfig
if _llllIIl = invalid then return
m.currentConfig = _llllIIl
m.statusTitle.text = _llllIIl.title
m.menuTitle.text = _llllIIl.title
m.statusText.text = _l1d_2b697b("9dc9c2c9cbc8d4d6e026dad8e1edf4eb3bfcf3f9fa4adf0f0a0cf5110b031c141264676a", 221, 14)
m.statusOverlay.visible = true
m.cancelBtn.setFocus(true)
applyFitMode(m.fitMode)
m.resolveTask = CreateObject(_l1d_2b697b("4961707f896d696d", 54, 5), _l1d_2b697b("9e9885a4a891a7b49c99b3b2c1cbbbacc7", 242, 254))
m.resolveTask.imdbId = _llllIIl.imdbId
m.resolveTask.kind = _llllIIl.kind
if _llllIIl.season <> invalid then m.resolveTask.season = _llllIIl.season
if _llllIIl.episode <> invalid then m.resolveTask.episode = _llllIIl.episode
m.resolveTask.observeField(_l1d_2b697b("8197888d9792", 24, 23), _l1d_2b697b("75794f79768e8d8c629a87969c95a9ad", 91, 65))
m.resolveTask.control = _l1d_2b697b("818983", 227, 208)
end sub
sub onStreamResolved()
if ((59240 - 7405 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1I1ll1 = m.resolveTask.result
if _l1I1ll1 <> invalid and _l1I1ll1.url <> invalid and _l1I1ll1.url <> "" then
m.statusText.text = _l1d_2b697b("1de9ff0202fc040610d62b1b1618411d174f28201efa4e2c3541483f05080b", 189, 30)
startPlayback(_l1I1ll1)
else
m.statusText.text = _l1d_2b697b("406c6f6f75402d5f87847e7d8c429a928ca0929da39b9baca870699cbdb7c4c77b9dc2cec6cfd99a", 2, 249)
end if
end sub
sub startPlayback(_l1l1Il1 as Object)
_lIl1Il1 = CreateObject(_l1d_2b697b("9d83c2b1ad8f9d9f", 47, 64), _l1d_2b697b("5483879082909976989294", 129, 146))
_lIl1Il1.url = _l1l1Il1.url
_lIl1Il1.StreamFormat = _l1d_2b697b("b7bea8", 80, 127)
if _l1l1Il1.streamFormat <> invalid then _lIl1Il1.StreamFormat = _l1l1Il1.streamFormat
_lIl1Il1.Title = m.currentConfig.title
if _l1l1Il1.referer <> invalid and _l1l1Il1.referer <> "" then
_llIlIl1 = [
_l1d_2b697b("9eaeb0b4cabad01b08", 71, 137) + _l1l1Il1.referer,
_l1d_2b697b("08eddef49c0be8ede704c1be", 175, 14) + _l1l1Il1.userAgent
]
_lIl1Il1.HttpSendClientHeaders = _llIlIl1
end if
applyFitMode(m.fitMode)
_lIIlIl1 = 0
if m.currentConfig.kind = _l1d_2b697b("3233", 242, 172) then
_lll1Il1 = 1
_lI1lIl1 = 1
if m.currentConfig.season <> invalid then _lll1Il1 = m.currentConfig.season
if m.currentConfig.episode <> invalid then _lI1lIl1 = m.currentConfig.episode
_l1IlIl1 = W_GetEpisodeProgress(m.currentConfig.imdbId, "", _lll1Il1, _lI1lIl1)
if _l1IlIl1 <> invalid and _l1IlIl1.pos <> invalid and _l1IlIl1.pos > 30 and not _l1IlIl1.done then
_lIIlIl1 = _l1IlIl1.pos
end if
else
_l1IlIl1 = W_GetMovieProgress(m.currentConfig.imdbId, "")
if _l1IlIl1 <> invalid and _l1IlIl1.pos <> invalid and _l1IlIl1.pos > 30 and not _l1IlIl1.done then
_lIIlIl1 = _l1IlIl1.pos
end if
end if
m.videoPlayer.content = _lIl1Il1
m.videoPlayer.control = _l1d_2b697b("51706863", 82, 47)
if _lIIlIl1 > 0 then
m.videoPlayer.seek = _lIIlIl1
end if
m.videoPlayer.setFocus(true)
end sub
sub onVideoState()
_ll1Il11 = m.videoPlayer.state
if _ll1Il11 = _l1d_2b697b("1d1c122d202620", 227, 138) then
m.statusOverlay.visible = false
else if _ll1Il11 = _l1d_2b697b("7c708689897b939d97", 209, 201) then
m.statusOverlay.visible = true
m.statusText.text = _l1d_2b697b("31071b1e20101a222e6a3f312c345d3b33653e3c348e6448495f5e5da1a4a7", 120, 247)
else if _ll1Il11 = _l1d_2b697b("1b17191d3a242a2e", 141, 48) then
saveProgress()
m.videoPlayer.control = _l1d_2b697b("1715011f", 109, 249)
m.top.closePlayer = true
else if _ll1Il11 = _l1d_2b697b("b7c3c6c6cc", 130, 208) then
m.statusOverlay.visible = true
m.statusText.text = _l1d_2b697b("033a3a353d43444f8b4b3f425a489d636265565a5d6f71babb4e6f817679cd6f94989899a3e4", 86, 253)
m.cancelBtn.setFocus(true)
end if
end sub
sub onPositionChange()
_l1l1I11 = m.videoPlayer.position
_ll11I11 = m.videoPlayer.duration
if _ll11I11 > 0 then
_lIl1I11 = formatTime(_l1l1I11) + _l1d_2b697b("b2b4b8", 152, 250) + formatTime(_ll11I11)
m.menuTime.text = _lIl1I11
end if
end sub
sub performSeek(_l1ll1I1 as Integer)
if ((41504 - 5188 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lIIIlI1 = m.videoPlayer.position
_llll1I1 = m.videoPlayer.duration
_lIll1I1 = _lIIIlI1 + _l1ll1I1
if _lIll1I1 < 0 then _lIll1I1 = 0
if _llll1I1 > 0 and _lIll1I1 > _llll1I1 - 2 then _lIll1I1 = _llll1I1 - 2
m.videoPlayer.seek = _lIll1I1
end sub
sub showMenu()
m.menuOverlay.visible = true
_llI1II1 = m.videoPlayer.duration
m.menuTime.text = formatTime(m.videoPlayer.position) + _l1d_2b697b("d5d9db", 151, 30) + formatTime(_llI1II1)
updateMenuButtons()
m.menuBtnBar.setFocus(true)
if m.menuBtnBar.getChildCount() > 0 then
m.menuBtnBar.getChild(0).setFocus(true)
end if
end sub
sub hideMenu()
m.menuOverlay.visible = false
m.videoPlayer.setFocus(true)
end sub
sub updateMenuButtons()
if m.menuBtnBar = invalid or m.fitModes = invalid then return
_l11IIlI = m.fitModes[m.fitMode].label
_ll1IIlI = [_l1d_2b697b("212213e3f8f9e4ef372af1ff0a04080904", 111, 208), _l11IIlI, _l1d_2b697b("8762677124906c797e76364143574f9451", 38, 18), _l1d_2b697b("3e4c6561596d6aa162796162b05573787575787e7e8a", 204, 160)]
if m.currentConfig <> invalid and m.currentConfig.kind = _l1d_2b697b("8586", 162, 175) then
_ll1IIlI.Push(_l1d_2b697b("0c34444b022058425f4650521a23", 141, 73))
if m.currentConfig.episode <> invalid and m.currentConfig.episode > 1 then
_ll1IIlI.Push(_l1d_2b697b("d5bcef10081a12172421d7fd2d27302f2d2f", 131, 22))
end if
end if
_ll1IIlI.Push(_l1d_2b697b("aeeee0e81fd2e9e702e903", 69, 174))
m.menuBtnBar.buttons = _ll1IIlI
for _lI1IIlI = 0 to m.menuBtnBar.getChildCount() - 1
_lIlIIlI = m.menuBtnBar.getChild(_lI1IIlI)
_lIlIIlI.minWidth = 800
_lIlIIlI.height = 48
end for
end sub
sub onMenuBtnSelected()
_l1l111I = m.menuBtnBar.buttonSelected
_lll111I = m.menuBtnBar.buttons
if _lll111I = invalid or _l1l111I < 0 or _l1l111I >= _lll111I.Count() then return
_lIl111I = _lll111I[_l1l111I]
if Left(_lIl111I, 8) = _l1d_2b697b("e5caff15262b2621", 128, 39) then
hideMenu()
if m.videoPlayer.state = _l1d_2b697b("fcf00704fdff", 98, 234) then m.videoPlayer.control = _l1d_2b697b("778b7c818c97", 25, 12)
else if Left(_lIl111I, 7) = _l1d_2b697b("c6f9edf9fcfac7", 29, 120) or Left(_lIl111I, 4) = _l1d_2b697b("825c5a0f", 186, 134) then
onFitClicked()
else if Left(_lIl111I, 10) = _l1d_2b697b("060106f2c52f0dfaff15", 55, 162) then
hideMenu()
performSeek(85)
else if Left(_lIl111I, 7) = _l1d_2b697b("fc34212b392b34", 91, 243) then
hideMenu()
m.videoPlayer.seek = 0
m.videoPlayer.control = _l1d_2b697b("3f314647323d", 238, 163)
else if Left(_lIl111I, 7) = _l1d_2b697b("beaa92a170d6a6", 59, 73) then
onNextEpClicked()
else if Left(_lIl111I, 6) = _l1d_2b697b("e900d3b8ccc2", 249, 36) then
onPrevEpClicked()
else if _lIl111I = _l1d_2b697b("1f1f1119d0431a18331a30", 167, 61) then
onStopClicked()
end if
end sub
sub onNextEpClicked()
hideMenu()
saveProgress()
if m.currentConfig <> invalid and m.currentConfig.episode <> invalid then
m.currentConfig.episode = m.currentConfig.episode + 1
m.currentConfig.title = Left(m.currentConfig.title, Instr(1, m.currentConfig.title, _l1d_2b697b("636b697f", 148, 175)) - 1) + _l1d_2b697b("18161ef2", 121, 191) + m.currentConfig.season.ToStr() + _l1d_2b697b("1af8", 247, 67) + m.currentConfig.episode.ToStr()
onPlayConfigChange()
end if
end sub
sub onPrevEpClicked()
if ((40920 - 5115 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
hideMenu()
saveProgress()
if m.currentConfig <> invalid and m.currentConfig.episode <> invalid and m.currentConfig.episode > 1 then
m.currentConfig.episode = m.currentConfig.episode - 1
m.currentConfig.title = Left(m.currentConfig.title, Instr(1, m.currentConfig.title, _l1d_2b697b("929298ce", 136, 234)) - 1) + _l1d_2b697b("ff050595", 87, 136) + m.currentConfig.season.ToStr() + _l1d_2b697b("b197", 233, 232) + m.currentConfig.episode.ToStr()
onPlayConfigChange()
end if
end sub
sub onStopClicked()
hideMenu()
stopAndExit()
end sub
sub stopAndExit()
saveProgress()
if m.resolveTask <> invalid then m.resolveTask.control = _l1d_2b697b("151f2721", 59, 173)
if m.videoPlayer <> invalid then
m.videoPlayer.control = _l1d_2b697b("f4f4defe", 14, 119)
m.videoPlayer.content = invalid
end if
m.top.closePlayer = true
end sub
sub saveProgress()
if m.currentConfig = invalid then return
_lIIll1l = Int(m.videoPlayer.position)
_l111l1l = Int(m.videoPlayer.duration)
if _l111l1l <= 0 or _lIIll1l <= 0 then return
_l1l1l1l = m.currentConfig.kind
if _l1l1l1l = invalid or _l1l1l1l = "" then _l1l1l1l = _l1d_2b697b("8388748887", 177, 167)
_lIl1l1l = ""
if m.currentConfig.poster <> invalid then _lIl1l1l = m.currentConfig.poster
W_RememberContext(m.currentConfig.imdbId, {
title:  m.currentConfig.title,
kind:   _l1l1l1l,
imdb:   m.currentConfig.imdbId,
poster: _lIl1l1l
})
if _l1l1l1l = _l1d_2b697b("b5ba", 89, 136) then
_ll11l1l = 1
_lll1l1l = 1
if m.currentConfig.season <> invalid then _ll11l1l = m.currentConfig.season
if m.currentConfig.episode <> invalid then _lll1l1l = m.currentConfig.episode
W_SaveEpisodeProgress(m.currentConfig.imdbId, "", _ll11l1l, _lll1l1l, _lIIll1l, _l111l1l, "", m.currentConfig.title, 0, 0)
else
W_SaveMovieProgress(m.currentConfig.imdbId, "", _lIIll1l, _l111l1l)
end if
end sub
sub onCancel()
stopAndExit()
end sub
function formatTime(_l1lIlIl as Float) as String
_lII1lIl = Int(_l1lIlIl)
if _lII1lIl < 0 then _lII1lIl = 0
_l111lIl = _lII1lIl \ 3600
_lI11lIl = (_lII1lIl mod 3600) \ 60
_l1I1lIl = _lII1lIl mod 60
_lllIlIl = _l1I1lIl.ToStr()
if _l1I1lIl < 10 then _lllIlIl = _l1d_2b697b("0f", 182, 137) + _lllIlIl
_llI1lIl = _lI11lIl.ToStr()
if _lI11lIl < 10 and _l111lIl > 0 then _llI1lIl = _l1d_2b697b("e8", 104, 144) + _llI1lIl
if _l111lIl > 0 then
return _l111lIl.ToStr() + _l1d_2b697b("36", 249, 115) + _llI1lIl + _l1d_2b697b("bb", 211, 210) + _lllIlIl
end if
return _llI1lIl + _l1d_2b697b("c5", 65, 74) + _lllIlIl
end function
function onKeyEvent(_lIllIIl as String, _ll1lIIl as Boolean) as Boolean
if ((22587 - 7529 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if not _ll1lIIl then return false
if m.menuOverlay.visible then
if _lIllIIl = _l1d_2b697b("5d63645f", 26, 229) then
hideMenu()
return true
else if _lIllIIl = _l1d_2b697b("404c4c41", 122, 42) or _lIllIIl = _l1d_2b697b("e0dad3dfe6", 164, 10) then
return true
else if _lIllIIl = _l1d_2b697b("f8e2e9ff0408ee", 19, 124) then
onFitClicked()
return true
end if
return false
end if
if _lIllIIl = _l1d_2b697b("c2e0dde5d4", 242, 66) or _lIllIIl = _l1d_2b697b("59574c506561575f6c6075", 120, 59) then
if not m.statusOverlay.visible then
performSeek(15)
return true
end if
else if _lIllIIl = _l1d_2b697b("879197a8", 137, 162) or _lIllIIl = _l1d_2b697b("463e4f383e4b", 11, 205) then
if not m.statusOverlay.visible then
performSeek(-15)
return true
end if
end if
if _lIllIIl = _l1d_2b697b("0707", 51, 193) or _lIllIIl = _l1d_2b697b("cac2ddc9", 79, 159) then
if not m.statusOverlay.visible then
showMenu()
return true
end if
end if
if _lIllIIl = _l1d_2b697b("d0f2f1dfdce0fe", 15, 112) then
onFitClicked()
return true
end if
if _lIllIIl = _l1d_2b697b("0504", 208, 102) or _lIllIIl = _l1d_2b697b("c6c5bdd8", 66, 148) then
if not m.statusOverlay.visible then
if m.videoPlayer.state = _l1d_2b697b("b2b1a9c4b7bfbb", 192, 2) then
m.videoPlayer.control = _l1d_2b697b("4f63525b68", 60, 3)
else
m.videoPlayer.control = _l1d_2b697b("7a727f88837e", 163, 169)
end if
return true
end if
end if
if _lIllIIl = _l1d_2b697b("81818681", 121, 102) then
stopAndExit()
return true
end if
return false
end function
function _l1d_2b697b(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function