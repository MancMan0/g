sub init()
m.keyboard = m.top.findNode(_l1d_9f71f3("606d54707075697e", 184, 141))
m.btnGoResults = m.top.findNode(_l1d_9f71f3("536c557f5a926a77806c8783", 235, 202))
m.resultsGrid = m.top.findNode(_l1d_9f71f3("c6d2cbc8e4cfd706def6ee", 53, 127))
m.resultsHeading = m.top.findNode(_l1d_9f71f3("26322b28342f3721474e4e4c4e58", 29, 183))
m.noResults = m.top.findNode(_l1d_9f71f3("d3d7c5d3ece9e3eef8", 196, 41))
m.keyboard.observeField(_l1d_9f71f3("fcf0fe05", 78, 194), _l1d_9f71f3("1517f514271f19162e3a323e3f", 156, 34))
m.keyboard.observeField(_l1d_9f71f3("c2cbd9d9d8d8", 91, 154), _l1d_9f71f3("cdd1ffe0d6dee5ed", 39, 133))
if m.btnGoResults <> invalid then m.btnGoResults.observeField(_l1d_9f71f3("7b73777a82869c95919b9892a4a8", 187, 162), _l1d_9f71f3("161a002917272636", 131, 42))
m.resultsGrid.observeField(_l1d_9f71f3("3040323d623b47413e584a4e", 227, 166), _l1d_9f71f3("585a38465a652e636d696a5e7274", 80, 25))
if m.keyboard <> invalid then m.keyboard.setFocus(true)
end sub
sub onQueryChange()
_llIll1l = m.keyboard.text
if _llIll1l = invalid then _llIll1l = ""
_lIIll1l = ""
_l1Ill1l = CreateObject(_l1d_9f71f3("f60edc0e0f1412", 86, 210), _l1d_9f71f3("dadf0b3608eb17424c", 79, 201), _l1d_9f71f3("a8", 5, 70))
if _l1Ill1l <> invalid then _lIIll1l = _l1Ill1l.replaceAll(_llIll1l, "") else _lIIll1l = _llIll1l
if _lIIll1l = "" then
m.resultsGrid.content = invalid
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("ab9b9585cb9193d4a3a29ae0aaa3c2aab2b3c3b4fbcac404d6c7ceded2de19e8e8eee9e5fa303336", 102, 121)
m.resultsHeading.text = _l1d_9f71f3("a7dfccd5e1dcd8", 219, 30)
if m.btnGoResults <> invalid then m.btnGoResults.visible = false
return
end if
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("a2b3bacabecacecac68ebfd5e0dcb9e3efc5f2f808b4b7ba", 134, 205)
if m.searchTask <> invalid then m.searchTask.control = _l1d_9f71f3("9c9eb6a8", 247, 248)
m.searchTask = CreateObject(_l1d_9f71f3("bed6e5f4fee2dee2", 54, 122), _l1d_9f71f3("784950605450875f705b", 110, 59))
m.searchTask.query = _llIll1l
m.searchTask.observeField(_l1d_9f71f3("ccbcd1d2bed9", 239, 47), _l1d_9f71f3("7274ac8584948884bd97a4ad97b2b0", 106, 109))
m.searchTask.control = _l1d_9f71f3("6d6d77", 255, 192)
end sub
sub onSearchResults()
if ((18739 - 2677 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lI1I11l = m.searchTask.result
if _lI1I11l <> invalid and _lI1I11l.getChildCount() > 0 then
m.resultsGrid.content = _lI1I11l
m.noResults.visible = false
_l11I11l = _lI1I11l.getChildCount().ToStr()
m.resultsHeading.text = _l1d_9f71f3("657b8c918b96984853", 128, 147) + _l11I11l + _l1d_9f71f3("616d6b73492a3f7f344843484254944b579d6255635e5d72", 121, 17)
if m.btnGoResults <> invalid then
m.btnGoResults.visible = true
m.btnGoResults.text = _l1d_9f71f3("ed200e292821e1", 11, 164) + _l11I11l + _l1d_9f71f3("5b4c26333c26413f7380", 234, 145)
end if
else
m.resultsGrid.content = invalid
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("e1055524142a1521366a27234028357c344351474347434f9795", 78, 225) + m.keyboard.text + _l1d_9f71f3("6c", 233, 158)
m.resultsHeading.text = _l1d_9f71f3("25110a07130e16e8e3dee8", 189, 54)
if m.btnGoResults <> invalid then m.btnGoResults.visible = false
end if
end sub
sub onSubmit()
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
end if
end sub
sub onItemSelected()
_l1llIIl = m.resultsGrid.itemSelected
_llllIIl = m.resultsGrid.content
if _llllIIl <> invalid and _l1llIIl >= 0 and _l1llIIl < _llllIIl.getChildCount() then
m.top.selectedItem = _llllIIl.getChild(_l1llIIl)
end if
end sub
function onKeyEvent(_lllIll1 as String, _l1lIll1 as Boolean) as Boolean
if ((60025 - 8575 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if not _l1lIll1 then return false
if _lllIll1 = _l1d_9f71f3("6f59625e75", 108, 81) then
if (m.keyboard <> invalid and m.keyboard.isInFocusChain()) or (m.btnGoResults <> invalid and m.btnGoResults.hasFocus()) then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("c4ced4c5", 89, 143) then
if m.resultsGrid <> invalid and (m.resultsGrid.hasFocus() or m.resultsGrid.isInFocusChain()) then
_lII1ll1 = m.resultsGrid.itemFocused
if _lII1ll1 = invalid then _lII1ll1 = 0
_l1I1ll1 = m.resultsGrid.numColumns
if _l1I1ll1 = invalid or _l1I1ll1 <= 0 then _l1I1ll1 = 6
if _lII1ll1 <= 0 or (_lII1ll1 Mod _l1I1ll1) = 0 then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("9189a490", 107, 130) then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnGoResults <> invalid and m.btnGoResults.visible then
m.btnGoResults.setFocus(true)
return true
else if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("e6ec", 150, 3) then
if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("8e909590", 92, 80) then
if m.resultsGrid <> invalid and (m.resultsGrid.isInFocusChain() or m.resultsGrid.hasFocus()) then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
end if
return false
end function
function _l1d_9f71f3(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function