sub init()
m.viewHost = m.top.findNode(_l1d_14a035("d1b5c4d9dfc7dee4", 233, 50))
m.headerBar = m.top.findNode(_l1d_14a035("1a202727292316362c", 157, 37))
m.accentLine = m.top.findNode(_l1d_14a035("a8adb0adbba49fc5c7bf", 213, 244))
m.topBar = m.top.findNode(_l1d_14a035("331f3d123248", 141, 58))
m.bgGradient = m.top.findNode(_l1d_14a035("7e8467978b939998a2af", 195, 221))
m.navHome = m.top.findNode(_l1d_14a035("4844563353544f", 133, 93))
m.navMovies = m.top.findNode(_l1d_14a035("8983777596809a9986", 18, 13))
m.navTv = m.top.findNode(_l1d_14a035("6d635b7c61", 176, 143))
m.navCategories = m.top.findNode(_l1d_14a035("2e344c5c3d53474c475d475667", 168, 104))
m.navSearch = m.top.findNode(_l1d_14a035("9a8ea8c69b9ab0a2ac", 225, 11))
m.toastGroup = m.top.findNode(_l1d_14a035("28121b2c34063424413f", 202, 106))
m.toastText = m.top.findNode(_l1d_14a035("22201d322e1125433a", 68, 242))
m.exitModal = m.top.findNode(_l1d_14a035("c2d2c4dce6c7d5dbd3", 239, 56))
m.btnExitCancel = m.top.findNode(_l1d_14a035("cebfc8f4c4d6ce02e7ddebece8", 255, 49))
m.btnExitConfirm = m.top.findNode(_l1d_14a035("382d4a643a4e3c6e5d5f5a604c6a", 112, 38))
if m.btnExitCancel <> invalid then m.btnExitCancel.observeField(_l1d_14a035("0e282a2d2729512a34302d45393b", 226, 142), _l1d_14a035("dbddcbf9ed03d9fef20203fd", 78, 186))
if m.btnExitConfirm <> invalid then m.btnExitConfirm.observeField(_l1d_14a035("776d6f7290929a8f9995968a9ea0", 176, 165), _l1d_14a035("373b17574951254c504b5b655d", 71, 15))
m.navHome.observeField(_l1d_14a035("d1c9cdd0d8dcb2ebe7f1eee8fafe", 155, 216), _l1d_14a035("2d311440521f3f404b", 141, 75))
m.navMovies.observeField(_l1d_14a035("181014172f33f9323e38352f4145", 147, 39), _l1d_14a035("e0e4c7efe5d1f2eef605f2", 219, 44))
m.navTv.observeField(_l1d_14a035("12060a0d292df328342e2f25373b", 81, 223), _l1d_14a035("2e32152d432849", 67, 2))
m.navCategories.observeField(_l1d_14a035("3642464935393744404a53615357", 205, 135), _l1d_14a035("090b2e200c4429172b2c2725333a2f", 126, 248))
if m.navSearch <> invalid then m.navSearch.observeField(_l1d_14a035("94808487a3a7b5a2aea8b19fb1b5", 117, 125), _l1d_14a035("23274a1e18362b2a20323c", 241, 133))
m.navBtns = [m.navHome, m.navMovies, m.navTv, m.navCategories, m.navSearch]
m.verifyOverlay = m.top.findNode(_l1d_14a035("9fb5a9c7bbbdeab4cabed7d7d2", 182, 223))
m.verifyTitle = m.top.findNode(_l1d_14a035("6a80748286785e8e848f9b", 222, 194))
m.verifyDetail = m.top.findNode(_l1d_14a035("dbefe501f7f71f01f50b1616", 55, 154))
m.viewStack = []
m.top.observeField(_l1d_14a035("939d94898a9fa3", 113, 124), _l1d_14a035("e4e6eee1eaf2f010fcf3ece9", 242, 71))
m.sessionWatchdogTimer = CreateObject(_l1d_14a035("0b29f00713353335", 147, 42), _l1d_14a035("f311100b25", 69, 226))
m.sessionWatchdogTimer.duration = 4
m.sessionWatchdogTimer.repeat = true
m.sessionWatchdogTimer.observeField(_l1d_14a035("0903fb15", 26, 141), _l1d_14a035("424434415a5d565759455a68626a616f6a5a7a7782", 132, 87))
if KA_IsActivated() then
verifyAndShowHome()
else
showKeyAuthView()
end if
m.initFocusTimer = CreateObject(_l1d_14a035("c2c0a79eaacccacc", 67, 145), _l1d_14a035("6179807b8b", 128, 141))
m.initFocusTimer.duration = 0.15
m.initFocusTimer.repeat = false
m.initFocusTimer.observeField(_l1d_14a035("020a140c", 3, 157), _l1d_14a035("272b0b313131223c433c392349505b49", 155, 51))
m.initFocusTimer.control = _l1d_14a035("fbfd130506", 183, 55)
end sub
sub verifyAndShowHome()
if ((35332 - 8833 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1Ill1l = KA_GetSavedLicense()
_llIll1l = KA_GetSavedExpiry()
if KA_IsExpired(_llIll1l) then
KA_ClearLicense()
showToast(_l1d_14a035("93b9c6c3c1bfcc94b2c2cdd7d5e1e5", 29, 66))
showKeyAuthView()
if m.keyAuthView <> invalid then
_lIIll1l = m.keyAuthView.findNode(_l1d_14a035("5959515f6368785c6e66716f", 166, 132))
if _lIIll1l <> invalid then
_lIIll1l.text = _l1d_14a035("45162f39ea212734312f4d3a023d475c0e4c5c67516f5b5f1c299c636d7489763e7c7a93859f50928c599ba0ae9cb6a66ea5abb8b5b3d1be86c2c7d688", 173, 81)
end if
end if
return
end if
setHeaderVisible(false)
if m.verifyOverlay <> invalid then
m.verifyOverlay.visible = true
if m.verifyTitle <> invalid then m.verifyTitle.text = _l1d_14a035("6393858d9f8396a0aae887a5b2b7b5abc0ea03", 89, 84) + _l1Ill1l
if m.verifyDetail <> invalid then m.verifyDetail.text = _l1d_14a035("cdf4f6f9f7fc0c0c08044c1b1555061c2723002a360c393f4f79484282444b4d485a625c9a616962636b7b6cb27e87bb7f809090948ad2d5d8", 198, 72)
end if
if m.verifyTask <> invalid then m.verifyTask.control = _l1d_14a035("78786282", 46, 251)
m.verifyTask = CreateObject(_l1d_14a035("02f8271622040204", 39, 173), _l1d_14a035("8972819c8b8f7eb58b9c87", 47, 37))
m.verifyTask.action = _l1d_14a035("8092828c9c82", 152, 146)
m.verifyTask.observeField(_l1d_14a035("938d9aa38da8", 234, 251), _l1d_14a035("757967857b918e90987989a39b95b18f9bb4b1adb8", 133, 139))
m.verifyTask.control = _l1d_14a035("b4bed6", 50, 84)
end sub
sub onStartupVerifyResult()
if m.verifyOverlay <> invalid then m.verifyOverlay.visible = false
_lI1I11l = m.verifyTask.result
if _lI1I11l <> invalid and _lI1I11l.success = true then
showToast(_l1d_14a035("90b6bfc0bad8c911b3d4e6d4eade2c29", 79, 141) + KA_GetSavedLicense())
showHomeView(_l1d_14a035("c1c9cac5", 225, 56))
startSessionWatchdog()
else
_l11I11l = _l1d_14a035("3d23201d2b3926ee383a363b49475141", 165, 84)
if _lI1I11l <> invalid and _lI1I11l.message <> invalid and _lI1I11l.message <> "" then
_l11I11l = KA_CleanAuthMessage(_lI1I11l.message)
end if
KA_ClearLicense()
showToast(_l1d_14a035("073b36342139372b48403e809d", 95, 250) + _l11I11l)
showKeyAuthView()
if m.keyAuthView <> invalid then
_llII11l = m.keyAuthView.findNode(_l1d_14a035("192131272b28604436465157", 178, 88))
if _llII11l <> invalid then
_llII11l.text = _l1d_14a035("9f836f8f8889c5d2", 118, 103) + _l11I11l + chr(10) + _l1d_14a035("639c8587d8a7a5a2a7b59bb0f0baa7f9caccb605c7ccc2d8cada1aeaee23b8e8f3fdd602ecdc05f5fb554add1c16150a1f5f25331c2e207133457a3c41374d3f4f8f5e5c595e6c5267a7737067c1", 209, 219)
end if
end if
end if
end sub
sub onSceneFocus()
if m.top.hasFocus() then
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then return
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
end sub
sub onInitFocusTimer()
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then return
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
if m.initFocusTimer <> invalid then m.initFocusTimer.control = _l1d_14a035("0d172f19", 115, 13)
end sub
sub showHomeView(_l1I1ll1 = _l1d_14a035("69696a75", 237, 228) as String)
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("93806d71468d958e8f9787985ea9a5966aaaa8a3bfa7b9bb82c8b68bd7c094e0dcc7e1e7efe5aeaf02f9f5fcedfec4040cf90d01d61a1edf23241434182ef43b433c3d4535460c564f4e18476121636a6c59797563763e", 54, 36))
return
end if
clearViews()
m.homeView = CreateObject(_l1d_14a035("9ea4c3d2ceb0babc", 61, 79), _l1d_14a035("4e343944743e4d5e", 106, 44))
m.homeView.category = _l1I1ll1
m.homeView.observeField(_l1d_14a035("84919d97a08ea0a4d29aacb7", 181, 190), _l1d_14a035("8587657387925b909a96978b9fa1", 208, 198))
m.homeView.observeField(_l1d_14a035("7b6e827072755f9585839c", 73, 65), _l1d_14a035("ced2b3d7dcd7a4d7cbe9eff2ccdef2fce9", 147, 210))
m.viewHost.appendChild(m.homeView)
m.viewStack.Push(m.homeView)
setHeaderVisible(true)
focusActiveView(m.homeView)
end sub
sub onHomeScrollEvent()
checkLicenseOnInteraction()
end sub
sub showDetailsView(_ll1Il11 as Object)
m.detailsView = CreateObject(_l1d_14a035("101ef50c082a3436", 25, 165), _l1d_14a035("e60afc0c171d03e9232213", 146, 16))
m.detailsView.content = _ll1Il11
m.detailsView.observeField(_l1d_14a035("d3bacad5f0d5e1d1d2d4", 44, 119), _l1d_14a035("c1c5f2c9c7e2edd2e0dedfe3", 229, 55))
m.viewHost.appendChild(m.detailsView)
m.viewStack.Push(m.detailsView)
setHeaderVisible(false)
m.detailsView.setFocus(true)
end sub
sub showPlayerView(_l1l1I11 as Object)
m.playerView = CreateObject(_l1d_14a035("c7d5ec03ffe1eff1", 251, 62), _l1d_14a035("e8f7fd080715fc041324", 203, 77))
m.playerView.playConfig = _l1l1I11
m.playerView.observeField(_l1d_14a035("3e424857443a51516c536b", 196, 151), _l1d_14a035("31330b3b3d243d0b4a423d4c38", 82, 244))
m.viewHost.appendChild(m.playerView)
m.viewStack.Push(m.playerView)
setHeaderVisible(false)
m.playerView.setFocus(true)
end sub
sub showSearchView()
clearViews()
m.searchView = CreateObject(_l1d_14a035("d3f3fa111bfffbff", 114, 211), _l1d_14a035("97686f7f737fa4867d8e", 102, 98))
m.searchView.observeField(_l1d_14a035("819aa6a09d97a9ad93a3b5c0", 147, 161), _l1d_14a035("e3e7c303f5f0e9fefa04051b0d11", 201, 61))
m.viewHost.appendChild(m.searchView)
m.viewStack.Push(m.searchView)
setHeaderVisible(true)
m.searchView.setFocus(true)
end sub
sub showMyListView()
if ((8658 - 2886 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
clearViews()
m.myListView = CreateObject(_l1d_14a035("4c3473625c40484c", 108, 46), _l1d_14a035("5968607e6771528a897a", 83, 59))
m.myListView.observeField(_l1d_14a035("dcd1ddd7d8eee0e40afaecf7", 225, 74), _l1d_14a035("7c7ea09e928dc29b95a19eb6aaac", 234, 247))
m.viewHost.appendChild(m.myListView)
m.viewStack.Push(m.myListView)
setHeaderVisible(true)
m.myListView.setFocus(true)
end sub
sub showCategoriesView()
clearViews()
m.categoriesView = CreateObject(_l1d_14a035("8169a89791758185", 174, 165), _l1d_14a035("1439493b3c4757534a5f3f5f5667", 135, 80))
m.categoriesView.observeField(_l1d_14a035("131422161b16342e1b28222e37433739", 204, 100), _l1d_14a035("6e72a08575878883837fa899959fa496a8ac", 191, 158))
m.viewHost.appendChild(m.categoriesView)
m.viewStack.Push(m.categoriesView)
setHeaderVisible(true)
m.categoriesView.setFocus(true)
end sub
sub showKeyAuthView()
if ((73096 - 9137 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
stopSessionWatchdog()
clearViews()
m.keyAuthView = CreateObject(_l1d_14a035("0ff534231f010b0d", 109, 240), _l1d_14a035("77a4ab86bdbfa6a7adbcd1", 72, 116))
m.keyAuthView.observeField(_l1d_14a035("4e4f5f5f635d6b6b686a5a7b707374898c", 198, 167), _l1d_14a035("2628102928132224430d2e4346473c3f", 214, 109))
m.keyAuthView.observeField(_l1d_14a035("3f494938495b5b5243", 247, 171), _l1d_14a035("a7a9c9aac1ccc3c5bcd6c6c8cfc8", 34, 90))
m.viewHost.appendChild(m.keyAuthView)
m.viewStack.Push(m.keyAuthView)
setHeaderVisible(false)
focusActiveView(m.keyAuthView)
end sub
sub onKeyAuthSuccess()
showToast(_l1d_14a035("9e8683808c9c894fb398a4a4aca2b0a4a66de3c0b9bcb9d2d5c3d5cfd2ea95", 164, 182))
showHomeView(_l1d_14a035("ebf3f4ef", 81, 178))
startSessionWatchdog()
end sub
sub onKeyAuthClose()
if KA_IsActivated() then
showHomeView(_l1d_14a035("8d8d8e89", 5, 32))
else
showExitModal()
end if
end sub
sub onCategorySelected(_llI11II as Object)
_lI111II = _llI11II.getData()
if _lI111II = invalid or _lI111II = "" then return
if _lI111II = _l1d_14a035("99868da1958d", 12, 26) then
showSearchView()
else if _lI111II = _l1d_14a035("1029192d2b2a30292b", 31, 168) then
showMyListView()
else if _lI111II = _l1d_14a035("0916fd180f131a", 249, 119) then
showKeyAuthView()
else
showHomeView(_lI111II)
end if
end sub
sub clearViews()
if ((17600 - 4400 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.viewHost.removeChildrenIndex(m.viewHost.getChildCount(), 0)
m.viewStack.Clear()
end sub
sub setHeaderVisible(_l1lI1ll as Boolean)
m.headerBar.visible = _l1lI1ll
m.accentLine.visible = _l1lI1ll
m.topBar.visible = _l1lI1ll
if m.bgGradient <> invalid then m.bgGradient.visible = _l1lI1ll
if _l1lI1ll then
m.viewHost.translation = [0, 140]
else
m.viewHost.translation = [0, 0]
end if
end sub
sub onItemSelected(_lIIll1l as Object)
if ((45765 - 5085 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("1b0c050dde151d2a27232330f6313d320242303b474351531a5452235f5c2c686863796f777d3a479a818d9489965c9c9891a59d6eb2aa77bbc0acbcb4c68cc3cbd8d5d1d1dea4e2e7d6b0dfedb9fff6f8f10101fb0eca", 188, 54))
return
end if
_lll1l1l = _lIIll1l.getData()
if _lll1l1l <> invalid then
showDetailsView(_lll1l1l)
end if
end sub
sub onPlayAction(_l1II11l as Object)
_llII11l = _l1II11l.getData()
if _llII11l <> invalid then
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("65968f996aa1a7b4b1afadba82bdc7bc8eccbcc7d1cfdbdfa6dedeafe9e6b8f2f4ef03fb0109c6d3e60d171e1320e81c252e2af7313300303d35440f514b185a5f4d5b55652d646a777472707d4581867551808c5a8e8c95a1a89f65", 157, 161))
return
end if
m.pendingPlayConfig = _llII11l
showToast(_l1d_14a035("0dffef0909ff121a16d221211e232f172cea2439273ef94e404b536c5a42745d4b532b2e31", 176, 39))
if m.playVerifyTask <> invalid then m.playVerifyTask.control = _l1d_14a035("e0defae8", 245, 58)
m.playVerifyTask = CreateObject(_l1d_14a035("190ffeedf91b1517", 133, 34), _l1d_14a035("ba9b92bd9498afbeac9db8", 243, 2))
m.playVerifyTask.action = _l1d_14a035("6d5d6f67697d", 33, 22)
m.playVerifyTask.observeField(_l1d_14a035("1a08211e1823", 68, 228), _l1d_14a035("060aeb12200bf1251b272d1d07372c2d3934", 31, 150))
m.playVerifyTask.control = _l1d_14a035("2d2947", 53, 198)
end if
end sub
sub onPlayVerifyResult()
if ((7085 - 1417 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.playVerifyTask = invalid then return
_llI1lIl = m.playVerifyTask.result
if _llI1lIl = invalid then return
if _llI1lIl.success = true then
if _llI1lIl.expiry <> invalid then U_PrefSet(_l1d_14a035("525f8c696f7a667e7c", 42, 17), _llI1lIl.expiry)
if m.pendingPlayConfig <> invalid then
_l111lIl = m.pendingPlayConfig
m.pendingPlayConfig = invalid
showPlayerView(_l111lIl)
end if
else
_lI11lIl = _l1d_14a035("b4929ba49e94ad6d9eb6a8b2b1c2c6", 187, 189)
if _llI1lIl.message <> invalid and _llI1lIl.message <> "" then _lI11lIl = KA_CleanAuthMessage(_llI1lIl.message)
m.pendingPlayConfig = invalid
kickoutUser(_l1d_14a035("f6d7dae3d0d3270ef2eaecfbfd223f0b00fdf94e0d0d161f170f2866221b6f2c307837393b474c388d51524a524e64a29d", 250, 59) + _lI11lIl + _l1d_14a035("e0e4", 130, 53))
end if
end sub
sub onClosePlayer()
if ((47656 - 6808 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.viewStack.Count() > 0 then
_ll1lIIl = m.viewStack.Peek()
if _ll1lIIl <> invalid and _ll1lIIl.isSubtype(_l1d_14a035("d7beccb7cec8e7d3dacf", 61, 106)) then
m.viewHost.removeChild(_ll1lIIl)
m.viewStack.Pop()
if m.viewStack.Count() > 0 then
_lIllIIl = m.viewStack.Peek()
focusActiveView(_lIllIIl)
if _lIllIIl <> invalid and _lIllIIl.isSubtype(_l1d_14a035("3717181329251c11", 181, 58)) then
_lIllIIl.category = _lIllIIl.category
end if
else
showHomeView(_l1d_14a035("292f343f", 58, 215))
end if
end if
end if
end sub
sub focusActiveView(_l11Ill1 as Object)
if ((36072 - 9018 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _l11Ill1 = invalid then return
if _l11Ill1.isSubtype(_l1d_14a035("6e92a49c9795b391a3aabb", 206, 228)) then
setHeaderVisible(false)
_l11Ill1.setFocus(true)
_lllIll1 = _l11Ill1.findNode(_l1d_14a035("2b4a403b253e57", 83, 8))
if _lllIll1 <> invalid then _lllIll1.setFocus(true)
else if _l11Ill1.isSubtype(_l1d_14a035("00242924f62e2d1e", 83, 229)) then
setHeaderVisible(true)
_l11Ill1.setFocus(true)
_lllIll1 = _l11Ill1.findNode(_l1d_14a035("fbf907052f0e041f29221b", 35, 176))
if _lllIll1 <> invalid and _lllIll1.visible then
_lllIll1.setFocus(true)
else
_ll1Ill1 = _l11Ill1.findNode(_l1d_14a035("6959743c5c797d", 200, 175))
if _ll1Ill1 <> invalid then _ll1Ill1.setFocus(true)
end if
else if _l11Ill1.isSubtype(_l1d_14a035("4b605f7567616266758a", 9, 241)) then
setHeaderVisible(true)
_l11Ill1.setFocus(true)
_l1lIll1 = _l11Ill1.findNode(_l1d_14a035("202918302839293a", 62, 203))
if _l1lIll1 <> invalid then _l1lIll1.setFocus(true)
else if _l11Ill1.isSubtype(_l1d_14a035("43688072737e8682818e768e8d9e", 131, 131)) then
setHeaderVisible(true)
_l11Ill1.setFocus(true)
_lllIll1 = _l11Ill1.findNode(_l1d_14a035("231c25ff302834323937303a", 219, 106))
if _lllIll1 <> invalid then _lllIll1.setFocus(true)
else if _l11Ill1.isSubtype(_l1d_14a035("2d04341a17153a262d22", 189, 61)) then
setHeaderVisible(true)
_l11Ill1.setFocus(true)
_lIlIll1 = _l11Ill1.findNode(_l1d_14a035("525a6363756b695f", 230, 200))
if _lIlIll1 <> invalid then _lIlIll1.setFocus(true)
else if _l11Ill1.isSubtype(_l1d_14a035("bce5f4cffe00efe4f6fd0e", 14, 119)) then
setHeaderVisible(false)
_l1lIll1 = _l11Ill1.findNode(_l1d_14a035("6a675e6c7a6f657a", 81, 48))
if _l1lIll1 <> invalid then
_l1lIll1.setFocus(true)
else
_l11Ill1.setFocus(true)
end if
else
_l11Ill1.setFocus(true)
end if
end sub
sub onNavHome()
showHomeView(_l1d_14a035("59595a65", 221, 164))
end sub
sub onNavMovies()
showHomeView(_l1d_14a035("bcbdb9c9d0c5", 31, 74))
showToast(_l1d_14a035("c6dcd5dbeaf0dbeef4fec0d7f40c0613090f19dbf91a161e2d1a", 27, 103))
end sub
sub onNavTv()
if ((6858 - 2286 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
showHomeView(_l1d_14a035("88818f8b8a97", 35, 56))
showToast(_l1d_14a035("2c040101101803161e2a66392b1f2731392d7e555a875d454f4a49", 248, 112))
end sub
sub onNavCategories()
showCategoriesView()
end sub
sub onNavSearch()
showSearchView()
end sub
sub onShowToastChange()
if ((3549 - 1183 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_llIl1lI = m.top.showToast
if _llIl1lI <> invalid and _llIl1lI <> "" then
showToast(_llIl1lI)
end if
end sub
sub showToast(_l11IIlI as String)
if ((23196 - 5799 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.toastText.text = _l11IIlI
m.toastGroup.visible = true
m.toastTimer = CreateObject(_l1d_14a035("6260877e8a6c6668", 161, 143), _l1d_14a035("1101000b03", 60, 169))
m.toastTimer.duration = 2.5
m.toastTimer.observeField(_l1d_14a035("cbcfbdd1", 113, 180), _l1d_14a035("40443a3e104a4b3c3c", 22, 194))
m.toastTimer.control = _l1d_14a035("bbc1cfc5ca", 249, 49)
end sub
sub hideToast()
m.toastGroup.visible = false
if m.toastTimer <> invalid then m.toastTimer.control = _l1d_14a035("51534b5d", 71, 29)
end sub
sub showExitModal()
if m.exitModal <> invalid then
m.exitModal.visible = true
if m.btnExitCancel <> invalid then m.btnExitCancel.setFocus(true)
end if
end sub
sub hideExitModal()
if m.exitModal <> invalid then
m.exitModal.visible = false
if m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
end sub
sub onExitCancel()
if ((55360 - 6920 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
hideExitModal()
end sub
sub onExitConfirm()
if ((52317 - 5813 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.exitApp = true
end sub
function onKeyEvent(_lI11l1l as String, _lII1l1l as Boolean) as Boolean
if not _lII1l1l then return false
if m.exitModal <> invalid and m.exitModal.visible then
if _lI11l1l = _l1d_14a035("77797e89", 176, 165) then
hideExitModal()
return true
else if _lI11l1l = _l1d_14a035("aba5abbc", 33, 94) or _lI11l1l = _l1d_14a035("2e34", 140, 53) then
if m.btnExitCancel <> invalid then
m.btnExitCancel.setFocus(true)
return true
end if
else if _lI11l1l = _l1d_14a035("0c261f2b12", 244, 134) or _lI11l1l = _l1d_14a035("2d35203c", 211, 118) then
if m.btnExitConfirm <> invalid then
m.btnExitConfirm.setFocus(true)
return true
end if
else if _lI11l1l = _l1d_14a035("656c", 39, 253) or _lI11l1l = _l1d_14a035("80919d979c8e", 183, 188) then
if m.btnExitConfirm <> invalid and m.btnExitConfirm.hasFocus() then
onExitConfirm()
return true
else
onExitCancel()
return true
end if
end if
return true
end if
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then
if _lI11l1l = _l1d_14a035("88888d98", 33, 69) then
showExitModal()
return true
end if
return true
end if
if KA_IsActivated() then
checkLicenseOnInteraction()
end if
if m.top.hasFocus() then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
if _lI11l1l = _l1d_14a035("61454c646d6f57", 144, 98) then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_lllIl1l = m.viewStack.Peek()
if _lllIl1l <> invalid and _lllIl1l.isSubtype(_l1d_14a035("1f465641584c2b5d6455", 94, 17)) then
return false
end if
end if
showSearchView()
return true
end if
if m.topBar <> invalid and m.topBar.isInFocusChain() then
if _lI11l1l = _l1d_14a035("99a1aca8", 131, 178) then
if m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
return true
end if
else if _lI11l1l = _l1d_14a035("bbbbc0bb", 109, 172) then
if m.viewStack.Count() > 0 then
_lIl1l1l = m.viewStack.Peek()
if _lIl1l1l.isSubtype(_l1d_14a035("4c707570427a796a", 147, 113)) then
showExitModal()
return true
else
focusActiveView(_lIl1l1l)
return true
end if
else
showExitModal()
return true
end if
else if _lI11l1l = _l1d_14a035("838f93a4", 136, 159) or _lI11l1l = _l1d_14a035("3c3a2f3f46", 102, 40) then
_l111l1l = 0
for _ll11l1l = 0 to m.navBtns.Count() - 1
if m.navBtns[_ll11l1l].hasFocus() then
_l111l1l = _ll11l1l
exit for
end if
end for
if _lI11l1l = _l1d_14a035("97858a8aa1", 46, 59) then
_llI1l1l = (_l111l1l + 1) Mod m.navBtns.Count()
else
_llI1l1l = (_l111l1l - 1 + m.navBtns.Count()) Mod m.navBtns.Count()
end if
m.navBtns[_llI1l1l].setFocus(true)
return true
else if _lI11l1l = _l1d_14a035("302e", 10, 177) then
return true
end if
return false
end if
if _lI11l1l = _l1d_14a035("d9ddded9", 91, 160) then
if m.viewStack.Count() > 1 then
_lllIl1l = m.viewStack.Pop()
m.viewHost.removeChild(_lllIl1l)
_l1I1l1l = m.viewStack.Peek()
if _l1I1l1l <> invalid then
focusActiveView(_l1I1l1l)
return true
end if
else if m.viewStack.Count() = 1 and not m.viewStack[0].isSubtype(_l1d_14a035("9ec0c1cca0ced5ca", 28, 74)) then
if m.viewStack[0].isSubtype(_l1d_14a035("49765d586f737a5b7f8e83", 153, 119)) and not KA_IsActivated() then
showExitModal()
return true
end if
showHomeView(_l1d_14a035("323a3b46", 41, 241))
return true
else
showExitModal()
return true
end if
else if _lI11l1l = _l1d_14a035("2a32", 167, 88) then
if m.headerBar.visible then
if m.viewStack.Count() > 0 then
_lIl1l1l = m.viewStack.Peek()
if _lIl1l1l <> invalid then
if _lIl1l1l.isSubtype(_l1d_14a035("7d5e4e60657060786f6888847b70", 53, 7)) then
m.navCategories.setFocus(true)
return true
else if _lIl1l1l.isSubtype(_l1d_14a035("e3fcfb0bff0bf8121122", 2, 146)) then
m.navSearch.setFocus(true)
return true
else if _lIl1l1l.isSubtype(_l1d_14a035("b39484969b96969ea59ebeaab1a6", 125, 117)) or _lIl1l1l.isSubtype(_l1d_14a035("0e45153b444627473e4f", 135, 68)) then
m.navCategories.setFocus(true)
return true
else if _lIl1l1l.isSubtype(_l1d_14a035("270f100b21151409", 49, 174)) and _lIl1l1l.category <> invalid then
_l1l1l1l = _lIl1l1l.category
if _l1l1l1l = _l1d_14a035("0f10fa141300", 50, 176) then
m.navMovies.setFocus(true)
return true
else if _l1l1l1l = _l1d_14a035("4e5f5571685d", 215, 170) or _l1l1l1l = _l1d_14a035("ccd1", 149, 235) then
m.navTv.setFocus(true)
return true
else if _l1l1l1l <> _l1d_14a035("9d9d9e99", 5, 48) then
m.navCategories.setFocus(true)
return true
end if
end if
end if
end if
m.navHome.setFocus(true)
return true
end if
end if
return false
end function
sub startSessionWatchdog()
m.watchdogTickCount = 0
if m.sessionWatchdogTimer <> invalid then
m.sessionWatchdogTimer.control = _l1d_14a035("dcded6e8", 231, 72)
m.sessionWatchdogTimer.control = _l1d_14a035("9e9a92a6a3", 76, 95)
end if
end sub
sub stopSessionWatchdog()
if ((15325 - 3065 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.sessionWatchdogTimer <> invalid then
m.sessionWatchdogTimer.control = _l1d_14a035("17213923", 19, 183)
end if
end sub
sub checkLicenseOnInteraction()
if not KA_IsActivated() then
kickoutUser(_l1d_14a035("332c25277837354247453b50904a47995a5c56a5676c62686a7ab8bd907f89887d92d298968fa193e4a6a8edafb4aab0b2c202c1bfccd1cfc5da1ad6e3ca24", 249, 147))
return
end if
_l11lIIl = KA_GetSavedExpiry()
if KA_IsExpired(_l11lIIl) then
kickoutUser(_l1d_14a035("0902ebed3e0d0b080d1b011656211b106228201b3523373b887d504f49483d529258664f6153a46678ad6f746a807282c2918f8c919f859adaa6a39ae69db9efb3c2c6afc5cfb7ca0abec4c5d9d8e7e6f0ea36", 113, 225))
return
end if
_lI1lIIl = CreateObject(_l1d_14a035("180ee80e1e100422211c", 197, 97)).AsSeconds()
if m.lastOnlineVerifyTime = invalid then m.lastOnlineVerifyTime = 0
if (_lI1lIIl - m.lastOnlineVerifyTime) >= 4 then
m.lastOnlineVerifyTime = _lI1lIIl
triggerOnlineVerify()
end if
end sub
sub triggerOnlineVerify()
if ((15463 - 2209 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if not KA_IsActivated() then return
if m.watchdogTask <> invalid and m.watchdogTask.state = _l1d_14a035("d6dae8ebe7f1fb", 153, 235) then return
if m.watchdogTask <> invalid then
m.watchdogTask.unobserveField(_l1d_14a035("94a4999aa6a1", 31, 39))
m.watchdogTask = invalid
end if
m.watchdogTask = CreateObject(_l1d_14a035("bec4a3b2aed0dadc", 29, 79), _l1d_14a035("789d8c87969aa980b6abb6", 29, 34))
m.watchdogTask.action = _l1d_14a035("6272646c7e62", 249, 211)
m.watchdogTask.observeField(_l1d_14a035("1c2c21222e29", 159, 47), _l1d_14a035("a2a490a9b7adb9b0bab5a7bdd1cfc3e5bdcfe4e5dfea", 70, 121))
m.watchdogTask.control = _l1d_14a035("1e1e28", 95, 17)
end sub
sub onSessionWatchdogTick()
if ((11030 - 2206 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if not KA_IsActivated() then
stopSessionWatchdog()
return
end if
_lll1Il1 = KA_GetSavedExpiry()
if KA_IsExpired(_lll1Il1) then
kickoutUser(_l1d_14a035("4a232c2edf2e2c292e3c4237f7423c510349615c5664585c291e91706a697e733379879082944587994e9095aba1b3a363b2b0adb2c0c6bb7bc7c4db87deda90d4e3e7f0e6f0f8ebabff0506faf90807110bd7", 161, 82))
return
end if
triggerOnlineVerify()
end sub
sub onWatchdogVerifyResult()
if ((11249 - 1607 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.watchdogTask = invalid then return
_lIll111 = m.watchdogTask.result
if _lIll111 = invalid then return
if _lIll111.success = true then
if _lIll111.expiry <> invalid and _lIll111.expiry <> "" then
U_PrefSet(_l1d_14a035("7b784d7a78738f7785", 214, 190), _lIll111.expiry)
if KA_IsExpired(_lIll111.expiry) then
kickoutUser(_l1d_14a035("d5a6afb768afb7b4b1bdcdba80cbc7dc8ccceae5e1eddbddaaa71af1edf409f6bcfc0811051dce121ad71b202c2c3426ec333b383541513e04524766105f5d195f66687171717b6e348a868f7d848b92928e58", 164, 216))
return
end if
end if
else
_l1ll111 = _lIll111.message
if _l1ll111 = invalid then _l1ll111 = ""
_llll111 = LCase(_l1ll111)
_lIIIl11 = (InStr(1, _llll111, _l1d_14a035("b5a3a2adb178acc9cd", 15, 58)) > 0 or InStr(1, _llll111, _l1d_14a035("353d313540404a", 125, 34)) > 0 or InStr(1, _llll111, _l1d_14a035("ced5d9dcd8ddcfedeaee", 215, 26)) > 0 or InStr(1, _llll111, _l1d_14a035("cfdee2e5ddded4a3daf6", 177, 253)) > 0)
if not _lIIIl11 then
_l1IIl11 = KA_CleanAuthMessage(_l1ll111)
if _l1IIl11 = "" then _l1IIl11 = _l1d_14a035("2c524f4c5a68559d725e746e756a6eb57d8dbe888a868b9997a191", 69, 35)
kickoutUser(_l1d_14a035("05e6e9f2dfe2380901f3fdfc0d113653", 123, 203) + _l1IIl11 + _l1d_14a035("98a5985f69708572ba78768f819bcc8e88d5979caa98b2a2eaa1a7b4b1afcdba02bec3d204", 109, 85))
end if
end if
end sub
sub kickoutUser(_lII1I11 as String)
if m.playerView <> invalid then
_l11II11 = m.playerView.findNode(_l1d_14a035("2b271f212e5c33314c334d", 101, 24))
if _l11II11 <> invalid then _l11II11.control = _l1d_14a035("ecf0fef2", 24, 129)
m.viewHost.removeChild(m.playerView)
m.playerView = invalid
end if
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
for _l1I1I11 = m.viewStack.Count() - 1 to 0 step -1
_lIlII11 = m.viewStack[_l1I1I11]
if _lIlII11 <> invalid and _lIlII11.isSubtype(_l1d_14a035("d9e0eef9f00ae9f5fc11", 13, 124)) then
_ll1II11 = _lIlII11.findNode(_l1d_14a035("62545a5e57575e6e797084", 14, 234))
if _ll1II11 <> invalid then _ll1II11.control = _l1d_14a035("f7fdf9ff", 97, 229)
m.viewHost.removeChild(_lIlII11)
end if
end for
end if
stopSessionWatchdog()
KA_ClearLicense()
clearViews()
showKeyAuthView()
if m.keyAuthView <> invalid then
_lllII11 = m.keyAuthView.findNode(_l1d_14a035("3c44544a4e4b83675969747a", 114, 59))
if _lllII11 <> invalid then
_lllII11.text = _lII1I11
end if
_llI1I11 = m.keyAuthView.findNode(_l1d_14a035("c1c3c1c7c8b0d0", 132, 219))
if _llI1I11 <> invalid then
_llI1I11.color = _l1d_14a035("baf50e11c6c9c8cbd3d6", 157, 13)
_llI1I11.width = 120
end if
_lI11I11 = m.keyAuthView.findNode(_l1d_14a035("0808080c0d4113332a", 37, 193))
if _lI11I11 <> invalid then
_lI11I11.text = _l1d_14a035("d1e1d3dde4edf1", 159, 4)
_lI11I11.color = _l1d_14a035("17624b4e252824275d60", 133, 98)
end if
_l1lII11 = m.keyAuthView.findNode(_l1d_14a035("bcc6b4cccecbf5cbdbd6d0", 35, 108))
if _l1lII11 <> invalid then _l1lII11.text = _l1d_14a035("10f1f4f5eaed431404f600071014", 255, 82)
end if
showToast(_l1d_14a035("795f5c596755622a7f6b617b82777b3c45a78c8f8c85885ab99ba9ada4a8", 181, 128))
end sub
function _l1d_14a035(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function