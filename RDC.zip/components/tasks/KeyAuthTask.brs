sub init()
m.top.functionName = _l1d_492033("918dabd1a6a5d09fa3c2", 245, 10)
end sub
sub runKeyAuth()
_llIll1l = m.top.action
if _llIll1l = _l1d_492033("777d7a77859380", 101, 110) then
m.top.result = KA_License(m.top.licenseKey)
else if _llIll1l = _l1d_492033("61736b857d7b", 212, 191) then
m.top.result = KA_VerifySavedLicense()
else if _llIll1l = _l1d_492033("42443f484c", 98, 52) then
m.top.result = KA_Login(m.top.username, m.top.password)
else
m.top.result = KA_Init()
end if
end sub
function _l1d_492033(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function