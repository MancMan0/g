sub init()
m.top.functionName = _l1d_3b1f7b("3c2841282a4737704e57434a41", 45, 221)
end sub
sub resolveStream()
_l1Ill1l = m.top.imdbId
_lIIll1l = m.top.kind
_lll1l1l = m.top.season
_llIll1l = m.top.episode
if _l1Ill1l = invalid or _l1Ill1l = "" then
m.top.result = { url: "", error: _l1d_3b1f7b("89708d90797b85cbba88a08b95ddb7bf", 109, 105) }
return
end if
_l1l1l1l = VSR_Resolve(_l1Ill1l, _lIIll1l, _lll1l1l, _llIll1l)
if _l1l1l1l <> invalid and _l1l1l1l.url <> invalid and _l1l1l1l.url <> "" then
m.top.result = _l1l1l1l
else
m.top.result = { url: "", error: _l1d_3b1f7b("7a516a545fa65f637bb287758e75759284ca9d84949f9a9e939fe5bbb7c0aeb5ac", 236, 203) }
end if
end sub
function _l1d_3b1f7b(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function