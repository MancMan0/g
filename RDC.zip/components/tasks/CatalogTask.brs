sub init()
m.top.functionName = _l1d_04d6a4("0208fd0325061c0c1a201b", 224, 118)
end sub
sub loadCatalog()
_ll11l1l = m.top.category
_llI111l = CreateObject(_l1d_04d6a4("c5ddecfb05e9e1e5", 52, 127), _l1d_04d6a4("09f8fa07fb0310290d090d", 226, 104))
_lII111l = []
if _ll11l1l = _l1d_04d6a4("a9adb2bd", 139, 198) then
_lII1l1l = W_ListInProgress(20)
if _lII1l1l <> invalid and _lII1l1l.Count() > 0 then
_ll1111l = []
for each _l1Il11l in _lII1l1l
if _l1Il11l.title = invalid or _l1Il11l.title = "" or Left(_l1Il11l.title, 2) = _l1d_04d6a4("edf0", 73, 176) or _l1Il11l.poster = invalid or _l1Il11l.poster = "" then
_lIIl11l = VSC_FetchTitleMeta(_l1Il11l.itemKey, _l1Il11l.kind)
if _lIIl11l <> invalid then
if _lIIl11l.title <> invalid and _lIIl11l.title <> "" then _l1Il11l.title = _lIIl11l.title
if _lIIl11l.poster <> invalid and _lIIl11l.poster <> "" then _l1Il11l.poster = _lIIl11l.poster
if _lIIl11l.backdrop <> invalid and _lIIl11l.backdrop <> "" then _l1Il11l.backdrop = _lIIl11l.backdrop
W_RememberContext(_l1Il11l.itemKey, {
title:    _l1Il11l.title,
poster:   _l1Il11l.poster,
backdrop: _l1Il11l.backdrop,
kind:     _l1Il11l.kind,
imdb:     _l1Il11l.itemKey,
year:     _lIIl11l.year,
rating:   _lIIl11l.rating
})
end if
end if
if (_l1Il11l.poster = invalid or _l1Il11l.poster = "") and Left(_l1Il11l.itemKey, 2) = _l1d_04d6a4("888b", 191, 189) then
_l1Il11l.poster = _l1d_04d6a4("e6e5e8e7eda7bfc2ff060d161708d6182315251f1f2fee26263a3f440135473e425646164d5a615f6228", 152, 246) + _l1Il11l.itemKey + _l1d_04d6a4("33f0f7f4", 193, 69)
end if
if _l1Il11l.backdrop = invalid or _l1Il11l.backdrop = "" then _l1Il11l.backdrop = _l1Il11l.poster
_ll1111l.Push(_l1Il11l)
end for
if _ll1111l.Count() > 0 then
_lII111l.Push({ title: _l1d_04d6a4("0b222643312f4b3e86324b5b4f4d4f4d57", 79, 255), items: _ll1111l })
end if
end if
end if
if _ll11l1l = _l1d_04d6a4("6870716c", 193, 191) then
_l1ll11l = VSC_FetchHomeRows()
if _l1ll11l <> invalid then
for each _l11l11l in _l1ll11l
_lII111l.Push(_l11l11l)
end for
end if
else if _ll11l1l = _l1d_04d6a4("cecfd9dbd2e7", 134, 227) then
_llII11l = VSC_FetchTrendingMovies()
if _llII11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("1e3f53515a505a6422406561657465", 153, 81), items: _llII11l })
_lllI11l = VSC_FetchByGenre(_l1d_04d6a4("ced3cfd3e2", 57, 122), _l1d_04d6a4("4a1d266d4b2f", 225, 152))
if _lllI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("f306135af41c580627332b2a37", 195, 99), items: _lllI11l })
_llIll1l = VSC_FetchByGenre(_l1d_04d6a4("0102fe0e15", 127, 239), _l1d_04d6a4("86abb9b7b8bc", 5, 66))
if _llIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("cdf2e8eef7fb40de03ff031203", 217, 53), items: _llIll1l })
_l111l1l = VSC_FetchByGenre(_l1d_04d6a4("6d728c7a81", 236, 236), _l1d_04d6a4("542b2c373b29", 125, 22))
if _l111l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("472e2f2a2e2c785e432f4b423b", 245, 145), items: _l111l1l })
_lIll11l = VSC_FetchByGenre(_l1d_04d6a4("4647534b4a", 195, 152), _l1d_04d6a4("557371747c7a", 30, 255))
if _lIll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("c6a2a2a5abab80d6b7b3c3cabf", 191, 207), items: _lIll11l })
else if _ll11l1l = _l1d_04d6a4("615268545b70", 143, 101) or _ll11l1l = _l1d_04d6a4("3338", 129, 62) then
_l1II11l = VSC_FetchTrendingSeries()
if _l1II11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("0707edf30f05fb4c23285529232b1615", 113, 230), items: _l1II11l })
_l1Ill1l = VSC_FetchByGenre(_l1d_04d6a4("7e93859d9c8d", 113, 124), _l1d_04d6a4("dbc0d6bcc5c9", 169, 243))
if _l1Ill1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("654a5e565f61168c61716b6a7b", 160, 132), items: _l1Ill1l })
_l1lI11l = VSC_FetchByGenre(_l1d_04d6a4("c0d5c5cfdecf", 184, 245), _l1d_04d6a4("647780476589", 129, 146))
if _l1lI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("03d6e3aa04eca8adae13f3010efc0d1ac6360f1d191825", 163, 19), items: _l1lI11l })
_lI11l1l = VSC_FetchByGenre(_l1d_04d6a4("e8ddedd7e6f7", 8, 109), _l1d_04d6a4("a382838e9078", 184, 168))
if _lI11l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("e7d6d7d2d4cc96ece1d1ebeadb", 176, 244), items: _lI11l1l })
else if _ll11l1l = _l1d_04d6a4("3f443a40494d", 185, 103) then
_llIll1l = VSC_FetchByGenre(_l1d_04d6a4("a8adb7adac", 96, 155), _l1d_04d6a4("375c52586165", 217, 159))
if _llIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("5e83778f989acf7fa48ea4a394", 80, 77), items: _llIll1l })
_l1Ill1l = VSC_FetchByGenre(_l1d_04d6a4("5e73637d7c6d", 208, 187), _l1d_04d6a4("dbfcee0c090d", 87, 197))
if _l1Ill1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("7b9cae9c999d6e9d9e77a7b5b1ccd3", 15, 45), items: _l1Ill1l })
else if _ll11l1l = _l1d_04d6a4("3b2e2b3731", 10, 194) then
_lllI11l = VSC_FetchByGenre(_l1d_04d6a4("c8cdb9cdcc", 17, 76), _l1d_04d6a4("15485118345a", 16, 210))
if _lllI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("592c29705a327e5c3d5941505d", 235, 161), items: _lllI11l })
_l1lI11l = VSC_FetchByGenre(_l1d_04d6a4("16231d352c25", 149, 48), _l1d_04d6a4("366966254d6f", 30, 233))
if _l1lI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("eafdfa41e9034d04055608141a3534", 202, 81), items: _l1lI11l })
else if _ll11l1l = _l1d_04d6a4("4e555a555977", 103, 74) then
_l111l1l = VSC_FetchByGenre(_l1d_04d6a4("bbbcb8c0cf", 27, 69), _l1d_04d6a4("c2a9aaa5a9c7", 229, 28))
if _l111l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("6d5c5d585c721e8c717d717081", 33, 11), items: _l111l1l })
_lI11l1l = VSC_FetchByGenre(_l1d_04d6a4("ae9bb5ada4bd", 37, 88), _l1d_04d6a4("1e3d3e494d53", 73, 20))
if _lI11l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("9ebdbec9cdb30fa6ab18acd6ded9d8", 89, 132), items: _lI11l1l })
else if _ll11l1l = _l1d_04d6a4("545060635969", 103, 69) then
_lIll11l = VSC_FetchByGenre(_l1d_04d6a4("0106120e05", 133, 25), _l1d_04d6a4("0d2d4d503656", 13, 200))
if _lIll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("7f9fafb2a8b8698fb4c0bcb3cc", 133, 178), items: _lIll11l })
_ll1l11l = VSC_FetchByGenre(_l1d_04d6a4("e9def0d8e7f8", 105, 207), _l1d_04d6a4("0ae60609ef0f", 47, 163))
if _ll1l11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("add3b9bcdcc217aeaf20b2eef4dfde", 82, 147), items: _ll1l11l })
else if _ll11l1l = _l1d_04d6a4("0f050d0c1b2b19161a", 143, 33) then
_lIIll1l = VSC_FetchByGenre(_l1d_04d6a4("d8ddf9ddec", 9, 116), _l1d_04d6a4("fe2e2c332a20384143", 80, 237))
if _lIIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("ef1f1d241b11252766163b253b3a2b", 208, 94), items: _lIIll1l })
_lll1l1l = VSC_FetchByGenre(_l1d_04d6a4("cbe4d2eeedda", 179, 11), _l1d_04d6a4("c9fbf7fef50d030c10", 1, 137))
if _lll1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("f5d5d3dae5232c290dedebf2f9ef0305441a0fff091809", 248, 60), items: _lll1l1l })
else if _ll11l1l = _l1d_04d6a4("8d9e8e9d94", 1, 40) then
_lIlIl1l = VSC_FetchByGenre(_l1d_04d6a4("e2e703e7f6", 73, 190), _l1d_04d6a4("e3b8ccc3d2", 191, 232))
if _lIlIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("76ab9f96a5697fa0bcacb3c8", 143, 171), items: _lIlIl1l })
_ll1Il1l = VSC_FetchByGenre(_l1d_04d6a4("665f6d696875", 35, 22), _l1d_04d6a4("8192a4a3aa", 24, 37))
if _ll1Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("6a374b4a51156c6d1e6e5c605b5a", 59, 235), items: _ll1Il1l })
else if _ll11l1l = _l1d_04d6a4("bfd3cbd2cd", 193, 29) then
_llI1l1l = VSC_FetchByGenre(_l1d_04d6a4("1516001a19", 146, 22), _l1d_04d6a4("daaeb6bdc8", 185, 224))
if _llI1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("5529313843838c89673643495b4d45a17f6460647364", 249, 155), items: _llI1l1l })
_l1I1l1l = VSC_FetchByGenre(_l1d_04d6a4("b2c7b9c1d0c1", 57, 104), _l1d_04d6a4("eadcc6c5d0", 44, 123))
if _l1I1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("4052707772b0b5b666756e768a7684ce6566d769a5ab9695", 82, 47), items: _l1I1l1l })
else if _ll11l1l = _l1d_04d6a4("70726e6b7b6c69", 90, 52) then
_llIIl1l = VSC_FetchByGenre(_l1d_04d6a4("4a4b47575e", 95, 24), _l1d_04d6a4("567674717f706d", 91, 57))
if _llIIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("031f213a283d3672103551354455", 73, 244), items: _llIIl1l })
_l1IIl1l = VSC_FetchByGenre(_l1d_04d6a4("f0fdf50f06ff", 212, 73), _l1d_04d6a4("a37f819a889d96", 105, 116))
if _l1IIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("f21610091f140de9f8fdf20630302b32", 29, 151), items: _l1IIl1l })
else if _ll11l1l = _l1d_04d6a4("c9cad0ea", 44, 130) or _ll11l1l = _l1d_04d6a4("787685848a7a", 80, 66) then
_l11Il1l = VSC_FetchByGenre(_l1d_04d6a4("050a061219", 189, 53), _l1d_04d6a4("193746454b3b", 208, 131))
if _l11Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("e207fdf3c7c4cdea141b222018e20a2b15372e23", 22, 133), items: _l11Il1l })
_lIIll1l = VSC_FetchByGenre(_l1d_04d6a4("cdcedadad1", 135, 227), _l1d_04d6a4("350b131221111f1c20", 63, 183))
if _lIIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("f2c6d0cfdeece0e2290debfcf2ea070b0f0116", 110, 195), items: _lIIll1l })
_lI1Il1l = VSC_FetchByGenre(_l1d_04d6a4("412e46303750", 140, 66), _l1d_04d6a4("12fa010808fe", 183, 33))
if _lI1Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("acd1d7cda1b0b1aabcede1eff6eb", 30, 87), items: _lI1Il1l })
_lll1l1l = VSC_FetchByGenre(_l1d_04d6a4("1e2f2531382d", 31, 178), _l1d_04d6a4("aacac8cfd6ccd4dddf", 88, 145))
if _lll1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("7b6050515b5e6060b4b1ba9e727c7b8a788c8ed5a793918c93", 126, 62), items: _lll1l1l })
else if _ll11l1l = _l1d_04d6a4("5e4d665252555f75", 175, 131) then
_l11I11l = VSC_FetchByGenre(_l1d_04d6a4("d7d8d2dceb", 58, 128), _l1d_04d6a4("02e1eae8e6e9e5f9", 102, 208))
if _l11I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("ec0b141210130f2358555e1031363a2a3242337921424c4e455a", 198, 90), items: _l11I11l })
_lI1I11l = VSC_FetchByGenre(_l1d_04d6a4("8c85918f8e9b", 2, 27), _l1d_04d6a4("61404d454548425c", 229, 176))
if _lI1I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("6e4b54566462606d35897670787f78", 189, 128), items: _lI1I11l })
else if _ll11l1l = _l1d_04d6a4("dcf4f9f8fcfcfd", 118, 216) then
_l11111l = VSC_FetchByGenre(_l1d_04d6a4("555a566269", 221, 165), _l1d_04d6a4("1b3334333b3b38", 132, 69))
if _l11111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("87bdc2c1c7c5c68e8b94bbdbc7dba3c9ead6f6ede2", 23, 66), items: _l11111l })
_lI1111l = VSC_FetchByGenre(_l1d_04d6a4("4d62545c6b5c", 185, 131), _l1d_04d6a4("a5dbe0dfe5e3e4", 87, 160))
if _lI1111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("6c8a8f8694a19790d6869fada9a8b5", 67, 91), items: _lI1111l })
else if _ll11l1l = _l1d_04d6a4("c7c5ccc1ccd7d3ccdcd0ca", 152, 203) then
_lllIl1l = VSC_FetchByGenre(_l1d_04d6a4("4c514b5960", 28, 219), _l1d_04d6a4("795158715c67617e6c7e7a", 235, 202))
if _lllIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("1b05fc15100b132010202e583d2322383c38323f", 98, 245), items: _lllIl1l })
_l1lIl1l = VSC_FetchByGenre(_l1d_04d6a4("231c2a262532", 227, 147), _l1d_04d6a4("1c0a01f6110c180111050f", 240, 104))
if _l1lIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("032f261b1c31233b3a2b", 145, 46), items: _l1lIl1l })
else if _ll11l1l = _l1d_04d6a4("fdfffc020e06fe", 121, 236) then
_lIIIl1l = VSC_FetchByGenre(_l1d_04d6a4("b2b7c1b7b6", 224, 37), _l1d_04d6a4("183a575d496159", 137, 87))
if _lIIIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("40624f4d6959716e6f7736373c4c817748667e989588", 21, 227), items: _lIIIl1l })
_llll11l = VSC_FetchByGenre(_l1d_04d6a4("0b20101a291a", 88, 224), _l1d_04d6a4("c3e5fe08f00804", 75, 192))
if _llll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("dec0b9bbc3c3bf1bebdcd2dee5da", 127, 167), items: _llll11l })
else if _ll11l1l = _l1d_04d6a4("dae2ebe6d6e6daf5e7", 49, 135) then
_l1l1l1l = VSC_FetchByGenre(_l1d_04d6a4("faff0bfffe", 33, 174), _l1d_04d6a4("557f807b7183759084", 84, 63))
if _l1l1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("0ee8e9f40afc0ef9fd0a0b01d0280d27151c35", 44, 160), items: _l1l1l1l })
_lIl1l1l = VSC_FetchByGenre(_l1d_04d6a4("6f64746e6d7e", 128, 124), _l1d_04d6a4("3e5657627a6a7e697b", 13, 239))
if _lIl1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("1af2fb06f606fa0507141515dc3025171f2e1f", 185, 31), items: _lIl1l1l })
else if _ll11l1l = _l1d_04d6a4("a5a98fadae", 46, 72) then
_lIlI11l = VSC_FetchByGenre(_l1d_04d6a4("5b605a686f", 28, 234), _l1d_04d6a4("688e9a929b", 219, 224))
if _lIlI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("aaced4d2d3d92dc5e6e0f2f9ee", 222, 29), items: _lIlI11l })
_ll1I11l = VSC_FetchByGenre(_l1d_04d6a4("ed02f4fc0bfc", 153, 3), _l1d_04d6a4("fbdfdde3ec", 34, 138))
if _ll1I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("8caea6b6b3bb6d8cb8b7c4bfbac8d1c7ddd5cce597989dd1ebebf6fd", 133, 182), items: _ll1I11l })
else if _ll11l1l = _l1d_04d6a4("4b3c5551455d44", 204, 144) then
_lIII11l = VSC_FetchByGenre(_l1d_04d6a4("ecf1fbf1f0", 160, 31), _l1d_04d6a4("558a777f937f9e", 82, 80))
if _lIII11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("e0d1cac6dad2e9a60ef3ddfbf2eb", 52, 125), items: _lIII11l })
_llllI1l = VSC_FetchByGenre(_l1d_04d6a4("29362e483f38", 84, 2), _l1d_04d6a4("9b8c8583958fa6", 53, 57))
if _llllI1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("8b9cb5b1a5bdb471a7b4ccc6bdd6", 132, 184), items: _llllI1l })
else if _ll11l1l = _l1d_04d6a4("67777e868c7482", 119, 98) then
_lIl111l = VSC_FetchByGenre(_l1d_04d6a4("d4cdd9c7d6e3", 74, 155), _l1d_04d6a4("d7c9d0d6dec4d4a3edee", 54, 115))
if _lIl111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("253f3e4c4c5a620c4344154763697473", 2, 213), items: _lIl111l })
_l1l111l = VSC_FetchByGenre(_l1d_04d6a4("4146604e55", 140, 96), _l1d_04d6a4("859dac9da8b3adaac0b2ae", 223, 234))
if _l1l111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("08fcfbfb4221ff111151250b170f172617", 121, 221), items: _l1l111l })
end if
for each _lll111l in _lII111l
_l1I111l = _llI111l.createChild(_l1d_04d6a4("fb222431252d3a13373337", 198, 118))
_l1I111l.title = _lll111l.title
for each _lI1l11l in _lll111l.items
_llIl11l = _l1I111l.createChild(_l1d_04d6a4("5675799284829b688a9496", 9, 12))
populateItemNode(_llIl11l, _lI1l11l)
end for
end for
m.top.result = _llI111l
end sub
sub populateItemNode(_l1II11l as Object, _lI1I11l as Object)
_l1II11l.id = _lI1I11l.id
if _l1II11l.id = invalid or _l1II11l.id = "" then
if _lI1I11l.itemKey <> invalid then _l1II11l.id = _lI1I11l.itemKey
end if
_l1II11l.title = _lI1I11l.title
_l1II11l.HDPosterUrl = _lI1I11l.poster
_l1II11l.HDBackgroundImageUrl = _lI1I11l.backdrop
if _l1II11l.HDBackgroundImageUrl = invalid or _l1II11l.HDBackgroundImageUrl = "" then
_l1II11l.HDBackgroundImageUrl = _lI1I11l.poster
end if
_l1II11l.description = _lI1I11l.description
_l1II11l.ReleaseDate = _lI1I11l.year
if _lI1I11l.rating <> invalid and _lI1I11l.rating <> "" then
_l1II11l.Rating = _lI1I11l.rating.ToStr()
end if
_llII11l = _l1d_04d6a4("c3c8b4d0c7", 213, 11)
if _lI1I11l.kind <> invalid and (_lI1I11l.kind = _l1d_04d6a4("cacf", 92, 162) or _lI1I11l.kind = _l1d_04d6a4("f3e8fae2f102", 73, 185)) then _llII11l = _l1d_04d6a4("1516", 10, 151)
_l1II11l.addField(_l1d_04d6a4("6f707079", 156, 120), _l1d_04d6a4("7f85868e98a2", 249, 245), false)
_l1II11l.kind = _llII11l
if _llII11l = _l1d_04d6a4("7b7c", 155, 140) then
_l1II11l.ContentType = 2
_l11I11l = ""
if _lI1I11l.season <> invalid and _lI1I11l.season > 0 then
_l11I11l = _l1d_04d6a4("2b", 37, 181) + _lI1I11l.season.ToStr() + _l1d_04d6a4("321a", 232, 106) + _lI1I11l.episode.ToStr()
end if
if _lI1I11l.pct <> invalid and _lI1I11l.pct > 0 then
if _l11I11l <> "" then _l11I11l = _l11I11l + _l1d_04d6a4("cdd8", 82, 91) + _lI1I11l.pct.ToStr() + _l1d_04d6a4("bfb6", 120, 98) else _l11I11l = _lI1I11l.pct.ToStr() + _l1d_04d6a4("37", 9, 11)
end if
if _l11I11l <> "" then _l1II11l.ReleaseDate = _l11I11l
else
_l1II11l.ContentType = 1
if _lI1I11l.pct <> invalid and _lI1I11l.pct > 0 then
_l1II11l.ReleaseDate = _lI1I11l.pct.ToStr() + _l1d_04d6a4("bac2ae87978b898f93", 111, 112)
end if
end if
if _lI1I11l.genres <> invalid then
_l1II11l.Categories = _lI1I11l.genres
end if
end sub
function _l1d_04d6a4(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function