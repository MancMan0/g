sub init()
m.top.functionName = _l1d_54710c("2f3b0a373e344650", 149, 62)
end sub
sub doSearch()
_l1l1l1l = m.top.query
_lIl1l1l = CreateObject(_l1d_54710c("1e2605140e323e42", 222, 114), _l1d_54710c("d8ff010e020a17f0141014", 198, 83))
if _l1l1l1l = invalid or _l1l1l1l = "" then
m.top.result = _lIl1l1l
return
end if
_lIIll1l = VSC_Search(_l1l1l1l)
for each _llIll1l in _lIIll1l
_l1Ill1l = _lIl1l1l.createChild(_l1d_54710c("a0bfc1bacecac3b0d4dce0", 216, 5))
_l1Ill1l.id = _llIll1l.id
_l1Ill1l.title = _llIll1l.title
_l1Ill1l.HDPosterUrl = _llIll1l.poster
_l1Ill1l.HDBackgroundImageUrl = _llIll1l.backdrop
_l1Ill1l.description = _llIll1l.description
_l1Ill1l.ReleaseDate = _llIll1l.year
if _llIll1l.rating <> invalid and _llIll1l.rating <> "" then
_l1Ill1l.Rating = _llIll1l.rating.ToStr()
end if
_lll1l1l = _l1d_54710c("f1f2fcfef5", 166, 38)
if _llIll1l.kind <> invalid and (_llIll1l.kind = _l1d_54710c("696e", 25, 252) or _llIll1l.kind = _l1d_54710c("9e97a391a0ad", 42, 69)) then _lll1l1l = _l1d_54710c("a6a7", 46, 76)
_l1Ill1l.addField(_l1d_54710c("9fa4a8b5", 90, 110), _l1d_54710c("d2d0d9c1c3cd", 13, 84), false)
_l1Ill1l.kind = _lll1l1l
if _lll1l1l = _l1d_54710c("8384", 34, 45) then
_l1Ill1l.ContentType = 2
else
_l1Ill1l.ContentType = 1
end if
if _llIll1l.genres <> invalid then
_l1Ill1l.Categories = _llIll1l.genres
end if
end for
m.top.result = _lIl1l1l
end sub
function _l1d_54710c(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function