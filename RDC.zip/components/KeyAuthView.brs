sub init()
m.keyboard = m.top.findNode(_l1d_a25f62("3d36553d45465647", 38, 240))
m.btnActivate = m.top.findNode(_l1d_a25f62("6e7b78947987858f839385", 165, 167))
m.hwidText = m.top.findNode(_l1d_a25f62("717d7676a97b9392", 163, 166))
m.statusTitle = m.top.findNode(_l1d_a25f62("57556b5b5d6684726a757f", 189, 137))
m.statusDetail = m.top.findNode(_l1d_a25f62("e7e9ffeff1f6e80afe141f1f", 87, 195))
m.spinnerLabel = m.top.findNode(_l1d_a25f62("fbffebe7eaf80c1505050701", 110, 222))
m.badgeText = m.top.findNode(_l1d_a25f62("1c1c242829fd2f1726", 217, 97))
m.activatedActions = m.top.findNode(_l1d_a25f62("717284728880908286ac8d9f8d8a8eac", 47, 35))
m.btnContinue = m.top.findNode(_l1d_a25f62("47345171585a4363634d60", 244, 177))
m.btnDeactivate = m.top.findNode(_l1d_a25f62("aec7b0ddbfbebfd9bfddcde5d7", 235, 37))
m.btnActivate.observeField(_l1d_a25f62("30222427414313444e4a4f3f5355", 86, 252), _l1d_a25f62("a9add1b6acb2b4c0b8caebc9c7d4cfdce0", 185, 211))
m.keyboard.observeField(_l1d_a25f62("48513f3f3e5e", 235, 176), _l1d_a25f62("3436604139413d4f45597656565f5a6b6d", 58, 223))
if m.btnContinue <> invalid then m.btnContinue.observeField(_l1d_a25f62("3f4f53564e5240515d575c6e6064", 71, 26), _l1d_a25f62("b8baeac1c3dccccce6d902d6deebe6ebed", 236, 53))
if m.btnDeactivate <> invalid then m.btnDeactivate.observeField(_l1d_a25f62("c8c0c4c7dfe3a9e2eee8e5dff1f5", 19, 87), _l1d_a25f62("575b385a6162547258706072578187808b8488", 87, 31))
_lII11ll = KA_GetHwid()
m.hwidText.text = _lII11ll
refreshLicenseState()
if m.keyboard <> invalid then
if m.keyboard.textEditBox <> invalid then
m.keyboard.textEditBox.hintText = _l1d_a25f62("7e6a5367572897777479856d8240ae8b82", 48, 9)
m.keyboard.textEditBox.maxTextLength = 64
end if
m.keyboard.setFocus(true)
_lllI1ll = KA_GetSavedLicense()
if _lllI1ll <> "" then m.keyboard.text = _lllI1ll
end if
m.top.observeField(_l1d_a25f62("918d94a9aa9fa1", 136, 163), _l1d_a25f62("6e704b7776838c5f87838b8788", 132, 131))
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
end if
end if
end sub
sub refreshLicenseState()
if ((24396 - 8132 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if KA_IsActivated() then
_l1II11l = KA_GetSavedLicense()
_l11I11l = U_PrefDefault(_l1d_a25f62("fbf8edfe0d1110fc1a282412", 135, 15), _l1d_a25f62("4a4b40524145444f", 9, 206))
m.badgeText.text = _l1d_a25f62("04051d152117", 226, 97)
m.statusTitle.text = _l1d_a25f62("210700010bf90ad2341507250b1fddea", 55, 166) + _l1II11l
_lI1I11l = U_PrefDefault(_l1d_a25f62("1d2aef2c1c27312b27", 95, 233), "")
_llII11l = KA_FormatExpiry(_lI1I11l)
_lIII11l = U_PrefDefault(_l1d_a25f62("b4adeec5cabc", 161, 234), _l1d_a25f62("9f8383859c96a1", 98, 121))
m.statusDetail.text = _l1d_a25f62("806575697c6e887279919a9ccbd4", 240, 221) + _lIII11l + _l1d_a25f62("95983f9ea13f4f5a645e6e639fbc", 95, 22) + _llII11l + chr(10) + _l1d_a25f62("0c203c3ff626302d4544535258521456575a63505329735c32688287877e898a8e4d999d568da4a68f65acaea0b8b1ba84", 19, 183)
if m.activatedActions <> invalid then m.activatedActions.visible = true
if m.btnActivate <> invalid then m.btnActivate.text = _l1d_a25f62("bceabbabf6c0b4aac6bcbc08efd5cecfd9c7d820f6", 247, 16)
else
m.badgeText.text = _l1d_a25f62("a1a2a5a69b9e", 55, 43)
m.statusTitle.text = _l1d_a25f62("d80915151c1d18e00f2be9fe2e393b14402a224b3341", 21, 150)
m.statusDetail.text = _l1d_a25f62("14f2ebfdef40ea03fcfe4f0e0c191e1c122767233017732a367c3e43464b3c3f913b544d4fa05f5d6b5e6e645cb87a7c85c4787e7f939291d9939de2ab9ba7aaf1ccdbf8", 121, 216)
if m.activatedActions <> invalid then m.activatedActions.visible = false
if m.btnActivate <> invalid then m.btnActivate.text = _l1d_a25f62("88e2969fb0acf18bb5fad1bd03b8c8c3cdb6d2ecbcd5f5eb27d5", 73, 118)
end if
end sub
sub onActivateClicked()
_lIl1lIl = m.keyboard.text
if _lIl1lIl = invalid then _lIl1lIl = ""
_ll11lIl = CreateObject(_l1d_a25f62("ff172517181d1b", 246, 123), _l1d_a25f62("9ba07eb989ac8ac5bd", 102, 99), _l1d_a25f62("24", 83, 240))
if _ll11lIl <> invalid then _lIl1lIl = _ll11lIl.replaceAll(_lIl1lIl, "")
if _lIl1lIl = "" then
if KA_IsActivated() then
_lIl1lIl = KA_GetSavedLicense()
else
m.statusDetail.text = _l1d_a25f62("c7e6e2e1f2eba9f1f906fa06bb170c1915ca1919121b232b24e22c2d44ee3c3ef74e4545034d4e654d5d56665f1e5f6969757b753385827f898b8f8b4b979b5e", 130, 245)
m.keyboard.setFocus(true)
return
end if
end if
m.spinnerLabel.visible = true
m.spinnerLabel.text = _l1d_a25f62("c996a39f9fa5af71abb17ad1b983f4c8c3c9f6ceecf8d5f5eba1a4a7", 43, 81)
m.statusDetail.text = _l1d_a25f62("4574787b73748a808a84c29995cb80909ba57eaab484adbdc3efc6c2f8d1c1d3cbcde10de7e0e9eb1cebe9e6ebf9fff4424548", 65, 67)
if m.authTask <> invalid then m.authTask.control = _l1d_a25f62("fcf81602", 20, 181)
m.authTask = CreateObject(_l1d_a25f62("7c9aa1b8c4a6a0a2", 177, 185), _l1d_a25f62("643938633234535a524762", 52, 229))
m.authTask.action = _l1d_a25f62("fc04fdfe06f607", 214, 66)
m.authTask.licenseKey = _lIl1lIl
m.authTask.observeField(_l1d_a25f62("8d87949d87a2", 138, 149), _l1d_a25f62("74765867698851837879937e", 86, 59))
m.authTask.control = _l1d_a25f62("eff1d9", 110, 179)
end sub
sub onAuthResult()
if ((12817 - 1831 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.spinnerLabel.visible = false
_l1llIIl = m.authTask.result
if _l1llIIl <> invalid and _l1llIIl.success = true then
m.badgeText.text = _l1d_a25f62("6a6f5d7b6575", 181, 118)
m.statusTitle.text = _l1d_a25f62("9b838c8d858596dcc0a191a195af9db1b3faccadc2c5c6bbbeccc2cccfc7", 126, 105)
m.statusDetail.text = _l1d_a25f62("8cc1cdc1d0d5d090c7df99aadee9efccf4e2cefbebf1bcc0ef0d060f19ff18d80d210f2b29313034f3354340ff354f54544b56575b24", 147, 200)
refreshLicenseState()
m.top.activationSuccess = true
else
_llllIIl = _l1d_a25f62("05eaf6f6fef40202030542030914120e105d5a40282029346c4839424a7b424a474450604d93615675a5", 100, 224)
if _l1llIIl <> invalid and _l1llIIl.message <> invalid and _l1llIIl.message <> "" then
_llllIIl = KA_CleanAuthMessage(_l1llIIl.message)
if _llllIIl = _l1d_a25f62("74503b555b6359a0676f6869716172b8827b7a", 118, 53) or _llllIIl = _l1d_a25f62("e7c5bec7d1b7d090d8d9d09ce9ebd9a8edf7e4fefb", 179, 232) then
_llllIIl = _l1d_a25f62("5e84918e8caa975f9ba0af6ba4a6c077b8b2cbb9c27f8cbfc6d0d7ecd9a1f2e2fce4eefab600f10a14c5010615d1130d16dd2c352de92b2c312c2ef1", 13, 29)
end if
end if
m.badgeText.text = _l1d_a25f62("e4e6d0eeebe8", 117, 169)
m.statusTitle.text = _l1d_a25f62("4e3b48420b674b1471555159626b", 186, 101)
m.statusDetail.text = _llllIIl
end if
end sub
sub onContinueClicked()
if ((19748 - 4937 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.activationSuccess = true
end sub
sub onDeactivateClicked()
KA_ClearLicense()
m.keyboard.text = ""
refreshLicenseState()
m.statusDetail.text = _l1d_a25f62("8eaeabb0bca4b9f7bec2c1c6bad2c2d0c6dadc1bedef24dbf2f6e333fafef208050a564bf31f081c0c5d19321b1b6c3b3b383d49314684524f46904765995d62566e5e6c6276b478817e8991d4", 208, 242)
m.keyboard.setFocus(true)
end sub
function onKeyEvent(_ll1Il11 as String, _l11Il11 as Boolean) as Boolean
if not _l11Il11 then return false
if not (m.keyboard.isInFocusChain() or (m.btnActivate <> invalid and m.btnActivate.hasFocus()) or (m.btnContinue <> invalid and m.btnContinue.hasFocus()) or (m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus())) then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
if _ll1Il11 = _l1d_a25f62("5f5b5662", 249, 194) then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
else if m.btnActivate <> invalid and m.btnActivate.hasFocus() then
if m.activatedActions <> invalid and m.activatedActions.visible then
m.btnContinue.setFocus(true)
return true
end if
end if
else if _ll1Il11 = _l1d_a25f62("787e", 244, 247) then
if m.btnActivate <> invalid and m.btnActivate.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
else if m.btnContinue <> invalid and m.btnContinue.hasFocus() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
else if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
end if
else if _ll1Il11 = _l1d_a25f62("a5919e98b7", 107, 140) then
if m.btnContinue <> invalid and m.btnContinue.hasFocus() and m.btnDeactivate <> invalid and m.btnDeactivate.visible then
m.btnDeactivate.setFocus(true)
return true
end if
else if _ll1Il11 = _l1d_a25f62("4f595f70", 13, 238) then
if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() and m.btnContinue <> invalid and m.btnContinue.visible then
m.btnContinue.setFocus(true)
return true
end if
else if _ll1Il11 = _l1d_a25f62("acaeb3be", 52, 86) then
if KA_IsActivated() then
m.top.closeView = true
return true
end if
end if
return false
end function
function _l1d_a25f62(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function