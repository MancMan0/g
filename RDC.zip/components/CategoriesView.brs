sub init()
m.btnWatchlist = m.top.findNode(_l1d_2b2032("5b68554f64746c66656b8886", 205, 172))
m.btnKeyAuth = m.top.findNode(_l1d_2b2032("6d5e775f787762717392", 86, 57))
m.btnAction = m.top.findNode(_l1d_2b2032("bcd1bee4c9ddc5ced0", 168, 242))
m.btnScifi = m.top.findNode(_l1d_2b2032("e801eae0f3f0fef6", 139, 255))
m.btnComedy = m.top.findNode(_l1d_2b2032("e5f2ef0ff6f7f2f414", 100, 223))
m.btnHorror = m.top.findNode(_l1d_2b2032("44553e274363664c6c", 79, 23))
m.btnThriller = m.top.findNode(_l1d_2b2032("e6fbf8e1f805fd05080214", 65, 195))
m.btnCrime = m.top.findNode(_l1d_2b2032("fa0bf4e41604030e", 142, 14))
m.btnAnimation = m.top.findNode(_l1d_2b2032("e3f8e5cbebe9f0f70df5fe00", 8, 121))
m.btnDrama = m.top.findNode(_l1d_2b2032("142916ff30222128", 200, 106))
m.btnRomance = m.top.findNode(_l1d_2b2032("5e4f68776d7271777576", 247, 201))
m.btnFantasy = m.top.findNode(_l1d_2b2032("b7a8c1dcc6cab7cfc0cd", 54, 99))
m.btnKids = m.top.findNode(_l1d_2b2032("e3d8e505e6f4e6", 56, 137))
m.btnDoc = m.top.findNode(_l1d_2b2032("173029062e25", 195, 118))
m.btnHistory = m.top.findNode(_l1d_2b2032("291633583a2725413139", 181, 82))
m.btnBio = m.top.findNode(_l1d_2b2032("f3e4fd1c0805", 55, 158))
m.btnSport = m.top.findNode(_l1d_2b2032("1a0f1c3214241c21", 57, 191))
m.btnWestern = m.top.findNode(_l1d_2b2032("8f9c898394adab9db79e", 205, 224))
m.btnReality = m.top.findNode(_l1d_2b2032("c1aecbdac8cfd5ddc3d3", 52, 107))
m.btnMoviesAll = m.top.findNode(_l1d_2b2032("84717e9e837f8b928bbc9497", 189, 165))
m.btnSeriesAll = m.top.findNode(_l1d_2b2032("423b541a53415d5c493e6e71", 83, 17))
m.rows = [
[m.btnWatchlist, m.btnKeyAuth],
[m.btnAction, m.btnScifi, m.btnComedy],
[m.btnHorror, m.btnThriller, m.btnCrime],
[m.btnAnimation, m.btnDrama, m.btnRomance],
[m.btnFantasy, m.btnKids, m.btnDoc],
[m.btnHistory, m.btnBio, m.btnSport],
[m.btnWestern, m.btnReality],
[m.btnMoviesAll, m.btnSeriesAll]
]
m.curRow = 0
m.curCol = 0
m.btnWatchlist.observeField(_l1d_2b2032("e6d6daddf5f9c7f804fe03f5070b", 215, 49), _l1d_2b2032("1719e512081a222929161afc313b37382c4042", 208, 88))
if m.btnKeyAuth <> invalid then m.btnKeyAuth.observeField(_l1d_2b2032("6f818386808272838d898e9e9294", 70, 75), _l1d_2b2032("82846c85846f7e809f699aa4a0a595a9ab", 150, 137))
m.btnAction.observeField(_l1d_2b2032("e6f2f6f9e5e927f4f0fa03110307", 45, 151), _l1d_2b2032("f5f9d9fa0c0a070bf90a16101527191d", 71, 205))
m.btnScifi.observeField(_l1d_2b2032("1b35373a24265e37313d3a524648", 106, 19), _l1d_2b2032("e8ecc2f5f200f8d10a06100d07191d", 219, 52))
m.btnComedy.observeField(_l1d_2b2032("9bafb3b6a2a6dcb1adb7b8cec0c4", 169, 208), _l1d_2b2032("1b1f4d24293438466f403c464b5d4f53", 111, 27))
m.btnHorror.observeField(_l1d_2b2032("6c5a5c5f7d7f8f7c86828b778b8d", 52, 22), _l1d_2b2032("8a8c6993898c9c9276aba5b1b2a6babc", 88, 83))
m.btnThriller.observeField(_l1d_2b2032("efdbdfe2fe0210fd09030cfa0c10", 117, 216), _l1d_2b2032("31354e35323a42454f416358545e5f55676b", 185, 91))
m.btnCrime.observeField(_l1d_2b2032("45535558565888555f5b64706466", 36, 255), _l1d_2b2032("797d63777f86916297939d9e94a6aa", 217, 195))
m.btnAnimation.observeField(_l1d_2b2032("d9edf1f4f0f41aeffbf5f60cfe02", 225, 86), _l1d_2b2032("c5c7a5cdd3d2d1dfdfe0e2d2dfe9e5eefaeef0", 132, 218))
m.btnDrama.observeField(_l1d_2b2032("7664666977795986808c95819597", 28, 248), _l1d_2b2032("afb390bdb1c0b7a8c1cdc7c4ded0d4", 195, 3))
m.btnRomance.observeField(_l1d_2b2032("7a6e727591955b909c96978d9fa3", 17, 7), _l1d_2b2032("4549104e534a584e57245d6963605a6c70", 19, 201))
m.btnFantasy.observeField(_l1d_2b2032("cac0c2c5e3e5ede2ece8e9ddf1f3", 112, 184), _l1d_2b2032("30341f473d3a50413e2758545e6355676b", 159, 64))
m.btnKids.observeField(_l1d_2b2032("bbadafb2bcbedecfc9d5dacadee0", 190, 223), _l1d_2b2032("3a3e644941355849554f5446585c", 55, 226))
m.btnDoc.observeField(_l1d_2b2032("5d51555864687e736f797a708286", 57, 2), _l1d_2b2032("ebed16f4031603fd0912fe1214", 252, 88))
m.btnHistory.observeField(_l1d_2b2032("2135393c383c6237433d3e54464a", 225, 158), _l1d_2b2032("dcdec7eb0404ee0c0af304fe0a0f1f1315", 78, 187))
m.btnBio.observeField(_l1d_2b2032("8575797c9498a697a39da294a6aa", 119, 112), _l1d_2b2032("d2d4bbd5ded5eae4f0f105f9fb", 8, 107))
m.btnSport.observeField(_l1d_2b2032("888084878f93a9a29ea8a59fb1b5", 123, 111), _l1d_2b2032("1c1e0e2e2836331d2a34303945393b", 196, 113))
m.btnWestern.observeField(_l1d_2b2032("c0d2d4d7d1d3c3d4dedadfefe3e5", 6, 92), _l1d_2b2032("7779558a7f7f93878e6e9f99a5aa9aaeb0", 222, 198))
m.btnReality.observeField(_l1d_2b2032("20121417313343343e3a3f2f4345", 54, 204), _l1d_2b2032("9092d1a3aaa0a8bebee7b8b2bec3d3c7c9", 46, 79))
m.btnMoviesAll.observeField(_l1d_2b2032("7d898d908c90be8b97919aa89a9e", 101, 118), _l1d_2b2032("77795f807a8493807593966ca59faba8a0b4b6", 90, 66))
m.btnSeriesAll.observeField(_l1d_2b2032("9fb1b3b6a0a2e2b3adb9becec2c4", 238, 19), _l1d_2b2032("0509ef081612111ef323260a232f2926403236", 67, 217))
m.top.observeField(_l1d_2b2032("3e3847343d4a4e", 189, 99), _l1d_2b2032("dfe3bee8e7d4ddd0faf4fef8f9", 213, 37))
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.btnWatchlist <> invalid then m.btnWatchlist.setFocus(true)
end if
end sub
sub onWatchlistSelected()
if ((49896 - 5544 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.categorySelected = _l1d_2b2032("09fe0c06fefd05221e", 140, 14)
end sub
sub onKeyAuthSelected()
m.top.categorySelected = _l1d_2b2032("7d72917c8b8d8c", 36, 46)
end sub
sub onActionSelected()
m.top.categorySelected = _l1d_2b2032("505163514e52", 47, 2)
end sub
sub onScifiSelected()
if ((61092 - 6788 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.categorySelected = _l1d_2b2032("ded1dadae0", 192, 43)
end sub
sub onComedySelected()
if ((24220 - 3460 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.categorySelected = _l1d_2b2032("8c83848f9381", 29, 14)
end sub
sub onHorrorSelected()
m.top.categorySelected = _l1d_2b2032("b0accccfb5d5", 207, 9)
end sub
sub onThrillerSelected()
m.top.categorySelected = _l1d_2b2032("405f4c666467635b", 20, 224)
end sub
sub onCrimeSelected()
m.top.categorySelected = _l1d_2b2032("364a32313c", 173, 104)
end sub
sub onAnimationSelected()
m.top.categorySelected = _l1d_2b2032("8698949b928aa0a9ad", 17, 22)
end sub
sub onDramaSelected()
if ((46420 - 9284 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.categorySelected = _l1d_2b2032("9db6a6adac", 197, 252)
end sub
sub onRomanceSelected()
m.top.categorySelected = _l1d_2b2032("4a4247464a4a4b", 166, 118)
end sub
sub onFantasySelected()
m.top.categorySelected = _l1d_2b2032("293137243a2b38", 55, 216)
end sub
sub onKidsSelected()
m.top.categorySelected = _l1d_2b2032("a4a9b9c5", 203, 4)
end sub
sub onDocSelected()
m.top.categorySelected = _l1d_2b2032("433d4c5d48534b6860706e", 238, 185)
end sub
sub onHistorySelected()
m.top.categorySelected = _l1d_2b2032("787a939d859d99", 11, 21)
end sub
sub onBioSelected()
m.top.categorySelected = _l1d_2b2032("b8b0b1bcd4c4d8c3d5", 237, 41)
end sub
sub onSportSelected()
if ((7596 - 1266 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.categorySelected = _l1d_2b2032("989e9aa2ab", 67, 104)
end sub
sub onWesternSelected()
m.top.categorySelected = _l1d_2b2032("897e9393879b92", 38, 56)
end sub
sub onRealitySelected()
m.top.categorySelected = _l1d_2b2032("8e9ca399a19797", 188, 192)
end sub
sub onMoviesAllSelected()
if ((32568 - 8142 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.categorySelected = _l1d_2b2032("bdc2cccac1da", 228, 52)
end sub
sub onSeriesAllSelected()
m.top.categorySelected = _l1d_2b2032("837c8a768592", 139, 139)
end sub
function getCurrentPosition() as Object
if ((19098 - 6366 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
for _lIIlIl1 = 0 to m.rows.Count() - 1
_lll1Il1 = m.rows[_lIIlIl1]
for _l1IlIl1 = 0 to _lll1Il1.Count() - 1
if _lll1Il1[_l1IlIl1] <> invalid and _lll1Il1[_l1IlIl1].hasFocus() then
return { r: _lIIlIl1, c: _l1IlIl1 }
end if
end for
end for
return { r: 0, c: 0 }
end function
function onKeyEvent(_l1IIl11 as String, _llll111 as Boolean) as Boolean
if not _llll111 then return false
_llIIl11 = getCurrentPosition()
_lIll111 = _llIIl11.r
_lI1Il11 = _llIIl11.c
_ll1l111 = m.rows[_lIll111]
if _l1IIl11 = _l1d_2b2032("465e57654c", 21, 223) then
if _lI1Il11 < _ll1l111.Count() - 1 then
_ll1l111[_lI1Il11 + 1].setFocus(true)
return true
end if
else if _l1IIl11 = _l1d_2b2032("d9d3d9ca", 245, 64) then
if _lI1Il11 > 0 then
_ll1l111[_lI1Il11 - 1].setFocus(true)
return true
end if
else if _l1IIl11 = _l1d_2b2032("2935203c", 213, 120) then
if _lIll111 < m.rows.Count() - 1 then
_lIIIl11 = m.rows[_lIll111 + 1]
_l11l111 = _lI1Il11
if _l11l111 >= _lIIIl11.Count() then _l11l111 = _lIIIl11.Count() - 1
_lIIIl11[_l11l111].setFocus(true)
return true
end if
else if _l1IIl11 = _l1d_2b2032("7f7f", 147, 153) then
if _lIll111 > 0 then
_l1ll111 = m.rows[_lIll111 - 1]
_l11l111 = _lI1Il11
if _l11l111 >= _l1ll111.Count() then _l11l111 = _l1ll111.Count() - 1
_l1ll111[_l11l111].setFocus(true)
return true
else
return false
end if
end if
return false
end function
function _l1d_2b2032(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function