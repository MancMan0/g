sub init()
if ((77985 - 8665 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.listGrid = m.top.findNode(_l1d_bc7069("abb1aeace0b8c0c8", 253, 26))
m.emptyNotice = m.top.findNode(_l1d_bc7069("69746463715f816f8d8687", 215, 183))
m.listGrid.observeField(_l1d_bc7069("e0d8eae502f3eff9fef00206", 127, 202), _l1d_bc7069("ff01e3110510f50e181411291d1f", 2, 146))
m.top.observeField(_l1d_bc7069("808c839c999294", 66, 92), _l1d_bc7069("4f536e584f444578625c6e6869", 241, 177))
loadFavorites()
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.listGrid <> invalid then m.listGrid.setFocus(true)
end if
end sub
sub loadFavorites()
if ((29697 - 9899 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lI1I11l = WL_GetFavorites()
_lIII11l = CreateObject(_l1d_bc7069("a2b0c7dedabccacc", 251, 25), _l1d_bc7069("41585c596b65624b6d7b7d", 223, 165))
if _lI1I11l <> invalid and _lI1I11l.Count() > 0 then
m.emptyNotice.visible = false
for each _l11I11l in _lI1I11l
_llII11l = _lIII11l.createChild(_l1d_bc7069("657c80798b89826f919b9d", 93, 71))
_llII11l.id = _l11I11l.id
_llII11l.title = _l11I11l.title
_llII11l.HDPosterUrl = _l11I11l.poster
_llII11l.HDBackgroundImageUrl = _l11I11l.poster
_llII11l.ReleaseDate = _l11I11l.year
if _l11I11l.rating <> invalid and _l11I11l.rating <> "" then
_llII11l.Rating = _l11I11l.rating.ToStr()
end if
_l1II11l = _l1d_bc7069("2f344e3443", 8, 202)
if _l11I11l.kind <> invalid and (_l11I11l.kind = _l1d_bc7069("b9be", 249, 44) or _l11I11l.kind = _l1d_bc7069("3d5644605f4c", 115, 61)) then _l1II11l = _l1d_bc7069("7277", 5, 1)
_llII11l.addField(_l1d_bc7069("4344463f", 117, 37), _l1d_bc7069("6e72736d7571", 224, 219), false)
_llII11l.kind = _l1II11l
if _l1II11l = _l1d_bc7069("454a", 209, 160) then
_llII11l.ContentType = 2
else
_llII11l.ContentType = 1
end if
end for
m.listGrid.content = _lIII11l
m.listGrid.setFocus(true)
else
m.listGrid.content = invalid
m.emptyNotice.visible = true
end if
end sub
sub onItemSelected()
if ((64056 - 8007 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_ll11lIl = m.listGrid.itemSelected
_lIl1lIl = m.listGrid.content
if _lIl1lIl <> invalid and _ll11lIl >= 0 and _ll11lIl < _lIl1lIl.getChildCount() then
m.top.selectedItem = _lIl1lIl.getChild(_ll11lIl)
end if
end sub
function _l1d_bc7069(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function