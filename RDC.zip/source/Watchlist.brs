function W_Section() as Object
_l1lI1ll = CreateObject(_l1d_acf7d9("25230b23242d36403d49223b3852484d51", 131, 52), _l1d_acf7d9("edddd8e20be7e111eaeae0090ff4020dfd110205", 121, 194))
_lllI1ll = CreateObject(_l1d_acf7d9("200606161718313338341d2e3345333034", 143, 35), _l1d_acf7d9("ccbeb6cbbfdbe2eafcddc3cee6d6ebee", 47, 101))
if _lllI1ll.GetKeyList() <> invalid and _lllI1ll.GetKeyList().Count() > 0 then
for each _lII11ll in _lllI1ll.GetKeyList()
if not _l1lI1ll.Exists(_lII11ll) then _l1lI1ll.Write(_lII11ll, _lllI1ll.Read(_lII11ll))
end for
_l1lI1ll.Flush()
end if
return _l1lI1ll
end function
function W_ItemKey(_l1Ill1l as String, _llIll1l as String) as String
if _llIll1l <> invalid and _llIll1l <> "" then return _llIll1l
if _l1Ill1l <> invalid and _l1Ill1l <> "" then return _l1Ill1l
return ""
end function
function W_AsInt(_lI1I11l as Dynamic) as Integer
if ((23424 - 7808 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lI1I11l = invalid then return 0
_l11I11l = Type(_lI1I11l)
if _l11I11l = _l1d_acf7d9("31151226272c18", 58, 190) or _l11I11l = _l1d_acf7d9("4f3d1e4461", 11, 214) or _l11I11l = _l1d_acf7d9("2a3015373042474842", 93, 251) then return _lI1I11l
if _l11I11l = _l1d_acf7d9("966f738090", 237, 235) or _l11I11l = _l1d_acf7d9("666640696f647a", 64, 52) or _l11I11l = _l1d_acf7d9("c4dcd9efe8f2", 223, 41) or _l11I11l = _l1d_acf7d9("475d37634c666b65", 213, 160) then return Int(_lI1I11l)
if _l11I11l = _l1d_acf7d9("5c7c819f9b97", 214, 215) or _l11I11l = _l1d_acf7d9("d9d900e8e5e3e7e3", 34, 137) then return _lI1I11l.ToInt()
if _l11I11l = _l1d_acf7d9("13f7fbf51a040dff040517", 225, 102) or _l11I11l = _l1d_acf7d9("d0e6ccecf0eadbf9e6f8f9fef4", 151, 235) then return _lI1I11l
return 0
end function
function W_AsBool(_ll11lIl as Dynamic) as Boolean
if _ll11lIl = invalid then return false
_lIl1lIl = Type(_ll11lIl)
if _lIl1lIl = _l1d_acf7d9("8b71747a747b81", 231, 230) or _lIl1lIl = _l1d_acf7d9("05051b0b0e0e0a0919", 224, 115) then return _ll11lIl
if _lIl1lIl = _l1d_acf7d9("0ae6efd9d9e5", 236, 75) or _lIl1lIl = _l1d_acf7d9("28480f33344e5652", 144, 70) then return LCase(_ll11lIl) = _l1d_acf7d9("4b505265", 30, 225)
return false
end function
function W_Read(_llllIIl as String) as Object
if ((20790 - 2970 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _llllIIl = "" then return invalid
_ll1lIIl = W_Section()
if not _ll1lIIl.Exists(_llllIIl) then return invalid
_lIllIIl = _ll1lIIl.Read(_llllIIl)
if _lIllIIl = invalid or _lIllIIl = "" then return invalid
_l1llIIl = ParseJson(_lIllIIl)
if _l1llIIl = invalid then return invalid
return _l1llIIl
end function
sub W_Write(_lII1ll1 as String, _l1I1ll1 as Object)
if ((59895 - 6655 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lII1ll1 = "" then return
_lllIll1 = W_Section()
_lllIll1.Write(_lII1ll1, FormatJson(_l1I1ll1))
_lllIll1.Flush()
end sub
function W_IsFinished(_llIlIl1 as Integer, _lI1lIl1 as Integer) as Boolean
if _lI1lIl1 <= 0 then return false
if _lI1lIl1 >= 840 and _llIlIl1 >= _lI1lIl1 - 420 then return true
if _llIlIl1 >= _lI1lIl1 - 90 then return true
if _llIlIl1 >= Int(_lI1lIl1 * 0.95) then return true
return false
end function
function W_MinResumeSeconds() as Integer
return 30
end function
function W_GetMovieProgress(_lIl1I11 as String, _l1l1I11 as String) as Object
return W_Read(_l1d_acf7d9("4781", 117, 47) + W_ItemKey(_lIl1I11, _l1l1I11))
end function
sub W_SaveMovieProgress(_l1ll1I1 as String, _llll1I1 as String, _ll1l1I1 as Integer, _lIIIlI1 as Integer)
if ((12654 - 2109 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lIll1I1 = W_ItemKey(_l1ll1I1, _llll1I1)
if _lIll1I1 = "" then return
if _ll1l1I1 < 0 then _ll1l1I1 = 0
W_Write(_l1d_acf7d9("4c84", 92, 27) + _lIll1I1, {
pos:  _ll1l1I1
dur:  _lIIIlI1
done: W_IsFinished(_ll1l1I1, _lIIIlI1)
ts:   CreateObject(_l1d_acf7d9("e2f2defef408da020914", 26, 122)).AsSeconds()
})
end sub
function W_GetEpisodeProgress(_lII1II1 as String, _l1I1II1 as String, _lllIII1 as Integer, _llI1II1 as Integer) as Object
return W_Read(_l1d_acf7d9("a662", 150, 179) + W_ItemKey(_lII1II1, _l1I1II1) + _l1d_acf7d9("bb", 173, 36) + _lllIII1.ToStr() + _l1d_acf7d9("a2", 56, 160) + _llI1II1.ToStr())
end function
sub W_SaveEpisodeProgress(_lIIl1lI as String, _l1Il1lI as String, _llI11lI as Integer, _llIl1lI as Integer, _l1111lI as Integer, _l11l1lI as Integer, _lII11lI as String, _ll111lI as String, _lIl11lI as Integer, _l1l11lI as Integer)
_lll11lI = W_ItemKey(_lIIl1lI, _l1Il1lI)
if _lll11lI = "" then return
if _l1111lI < 0 then _l1111lI = 0
_lI1l1lI = W_IsFinished(_l1111lI, _l11l1lI)
_lllI1lI = CreateObject(_l1d_acf7d9("84725c7a9284787e8590", 73, 73)).AsSeconds()
W_Write(_l1d_acf7d9("612d", 174, 150) + _lll11lI + _l1d_acf7d9("4c", 139, 155) + _llI11lI.ToStr() + _l1d_acf7d9("2a", 126, 230) + _llIl1lI.ToStr(), {
pos:  _l1111lI
dur:  _l11l1lI
done: _lI1l1lI
ts:   _lllI1lI
})
_lI111lI = W_Read(_l1d_acf7d9("d410", 201, 26) + _lll11lI)
if _lIl11lI <= 0 and _lI111lI <> invalid and _lI111lI.lastSeason <> invalid then _lIl11lI = W_AsInt(_lI111lI.lastSeason)
if _l1l11lI <= 0 and _lI111lI <> invalid and _lI111lI.lastEpisode <> invalid then _l1l11lI = W_AsInt(_lI111lI.lastEpisode)
_l1I11lI = false
if _lI1l1lI and _lIl11lI > 0 and _l1l11lI > 0 then
if _llI11lI > _lIl11lI or (_llI11lI = _lIl11lI and _llIl1lI >= _l1l11lI) then
_l1I11lI = true
end if
end if
W_Write(_l1d_acf7d9("3f7b", 223, 147) + _lll11lI, {
season:      _llI11lI
episode:     _llIl1lI
slug:        _lII11lI
name:        _ll111lI
pos:         _l1111lI
dur:         _l11l1lI
done:        _l1I11lI
lastSeason:  _lIl11lI
lastEpisode: _l1l11lI
ts:          _lllI1lI
})
end sub
function W_GetSeriesProgress(_ll1IIlI as String, _lIlIIlI as String) as Object
return W_Read(_l1d_acf7d9("722e", 189, 164) + W_ItemKey(_ll1IIlI, _lIlIIlI))
end function
sub W_MarkWatched(_l1l111I as String, _lll111I as String, _ll1111I as String)
_lIl111I = W_ItemKey(_l1l111I, _lll111I)
if _lIl111I = "" then return
_llI111I = CreateObject(_l1d_acf7d9("786e886e7e70a482817c", 229, 225)).AsSeconds()
if _ll1111I = _l1d_acf7d9("e0e1", 87, 189) then
_lI1111I = W_Read(_l1d_acf7d9("c17b", 58, 120) + _lIl111I)
if _lI1111I = invalid then _lI1111I = {}
_lI1111I.done = true
_lI1111I.ts = _llI111I
W_Write(_l1d_acf7d9("0bd5", 130, 26) + _lIl111I, _lI1111I)
else
_l11111I = W_Read(_l1d_acf7d9("8d39", 186, 182) + _lIl111I)
if _l11111I = invalid then _l11111I = { pos: 0, dur: 0 }
_l11111I.done = true
_l11111I.ts = _llI111I
W_Write(_l1d_acf7d9("eb21", 247, 81) + _lIl111I, _l11111I)
end if
end sub
function W_ResumePosition(_l1III1I as Object) as Integer
if _l1III1I = invalid then return 0
if W_AsBool(_l1III1I.done) then return 0
_lIIII1I = W_AsInt(_l1III1I.pos)
if _lIIII1I < W_MinResumeSeconds() then return 0
return _lIIII1I
end function
function W_FormatTime(_lII11II as Integer) as String
if _lII11II <= 0 then return _l1d_acf7d9("24e6", 250, 90)
_lI111II = Int(_lII11II / 3600)
m = Int((_lII11II Mod 3600) / 60)
_l1I11II = _lII11II Mod 60
if _lI111II > 0 then
_llI11II = m.ToStr()
if m < 10 then _llI11II = _l1d_acf7d9("fb", 66, 137) + _llI11II
return _lI111II.ToStr() + _l1d_acf7d9("9ee9", 235, 27) + _llI11II + _l1d_acf7d9("d5", 244, 60)
end if
if m > 0 then return m.ToStr() + _l1d_acf7d9("1058", 203, 106) + _l1I11II.ToStr() + _l1d_acf7d9("61", 14, 228)
return _l1I11II.ToStr() + _l1d_acf7d9("d0", 50, 143)
end function
sub W_RememberContext(_lI1llll as String, _ll1llll as Object)
if _lI1llll = "" or _ll1llll = invalid then return
_l11llll = W_Read(_l1d_acf7d9("f1ab", 50, 160) + _lI1llll)
_l1Illll = {}
if _l11llll <> invalid then
for each _llIllll in _l11llll
_l1Illll[_llIllll] = _l11llll[_llIllll]
end for
end if
for each _llIllll in _ll1llll
_lIIllll = _ll1llll[_llIllll]
if _lIIllll <> invalid and _lIIllll <> "" then _l1Illll[_llIllll] = _lIIllll
end for
_l1Illll.ts = CreateObject(_l1d_acf7d9("e8f8e000f60adc040b16", 216, 62)).AsSeconds()
W_Write(_l1d_acf7d9("56b0", 192, 179) + _lI1llll, _l1Illll)
end sub
function W_GetContext(_l1lI1ll as String) as Object
if _l1lI1ll = "" then return invalid
return W_Read(_l1d_acf7d9("1ac6", 63, 190) + _l1lI1ll)
end function
function W_ListInProgress(_lIlIl1l as Integer) as Object
_ll1Il1l = []
_lIIIl1l = W_Section()
_lllIl1l = _lIIIl1l.GetKeyList()
if _lllIl1l = invalid then return _ll1Il1l
_llll11l = {}
for each _lII1l1l in _lllIl1l
_l1lIl1l = ""
_llI1l1l = ""
if Left(_lII1l1l, 2) = _l1d_acf7d9("bc72", 191, 234) then
_l1lIl1l = _l1d_acf7d9("8a8f79978e", 52, 49)
_llI1l1l = Mid(_lII1l1l, 3)
else if Left(_lII1l1l, 2) = _l1d_acf7d9("81cd", 97, 111) then
_l1lIl1l = _l1d_acf7d9("3338", 113, 46)
_llI1l1l = Mid(_lII1l1l, 3)
end if
if _l1lIl1l <> "" and not _llll11l.DoesExist(_llI1l1l) then
_llll11l[_llI1l1l] = true
_l1l1l1l = W_Read(_lII1l1l)
if _l1l1l1l <> invalid then
_lI1Il1l = W_AsInt(_l1l1l1l.pos)
_lll1l1l = W_AsInt(_l1l1l1l.dur)
_l111l1l = W_AsBool(_l1l1l1l.done)
if _lI1Il1l >= 5 or _l111l1l then
_lIIll1l = W_GetContext(_llI1l1l)
_l1ll11l = _llI1l1l
_llIIl1l = ""
if _lIIll1l <> invalid then
if _lIIll1l.title <> invalid and _lIIll1l.title <> "" then _l1ll11l = _lIIll1l.title
if _lIIll1l.poster <> invalid and _lIIll1l.poster <> "" then _llIIl1l = _lIIll1l.poster
end if
if _l1ll11l = _llI1l1l or Left(_l1ll11l, 2) = _l1d_acf7d9("5255", 58, 4) then
if _l1l1l1l.name <> invalid and _l1l1l1l.name <> "" and Left(_l1l1l1l.name, 2) <> _l1d_acf7d9("2d30", 87, 10) then
_l1IIl1l = _l1l1l1l.name
_lIl1l1l = Instr(1, _l1IIl1l, _l1d_acf7d9("48564e62", 17, 23))
if _lIl1l1l > 1 then
_l1ll11l = Left(_l1IIl1l, _lIl1l1l - 1)
else
_l1ll11l = _l1IIl1l
end if
end if
end if
if (_llIIl1l = invalid or _llIIl1l = "") and Left(_llI1l1l, 2) = _l1d_acf7d9("4a4d", 154, 92) then
_llIIl1l = _l1d_acf7d9("b8b7bab9bbf50d10d1d8dfe4e9d624eaf5e7f7f1f1fd3cf4f80c0d164f07150c142814641b2c33313476", 250, 38) + _llI1l1l + _l1d_acf7d9("ed32312e", 180, 82)
end if
_l11Il1l = W_PercentOf(_lI1Il1l, _lll1l1l)
if _l111l1l and _l11Il1l < 100 then _l11Il1l = 100
_lI11l1l = {
itemKey: _llI1l1l
kind:    _l1lIl1l
title:   _l1ll11l
poster:  _llIIl1l
href:    ""
imdb:    _llI1l1l
tmdb:    ""
pos:     _lI1Il1l
dur:     _lll1l1l
pct:     _l11Il1l
ts:      W_AsInt(_l1l1l1l.ts)
done:    _l111l1l
}
if _l1lIl1l = _l1d_acf7d9("acad", 183, 233) then
_lI11l1l.season  = W_AsInt(_l1l1l1l.season)
_lI11l1l.episode = W_AsInt(_l1l1l1l.episode)
if _l1l1l1l.name <> invalid and _l1l1l1l.name <> "" then _lI11l1l.name = _l1l1l1l.name else _lI11l1l.name = ""
end if
_ll1Il1l.Push(_lI11l1l)
end if
end if
end if
end for
if _ll1Il1l.Count() > 1 then
for _ll11l1l = 0 to _ll1Il1l.Count() - 2
for _l1I1l1l = 0 to _ll1Il1l.Count() - 2 - _ll11l1l
if _ll1Il1l[_l1I1l1l].ts < _ll1Il1l[_l1I1l1l + 1].ts then
_lIll11l = _ll1Il1l[_l1I1l1l]
_ll1Il1l[_l1I1l1l] = _ll1Il1l[_l1I1l1l + 1]
_ll1Il1l[_l1I1l1l + 1] = _lIll11l
end if
end for
end for
end if
if _lIlIl1l > 0 and _ll1Il1l.Count() > _lIlIl1l then
_ll1l11l = []
for _ll11l1l = 0 to _lIlIl1l - 1
_ll1l11l.Push(_ll1Il1l[_ll11l1l])
end for
return _ll1l11l
end if
return _ll1Il1l
end function
function W_PercentOf(_lIII11l as Integer, _llII11l as Integer) as Integer
if _llII11l <= 0 then return 0
_l1II11l = Int((_lIII11l * 100) / _llII11l)
if _l1II11l < 0 then _l1II11l = 0
if _l1II11l > 100 then _l1II11l = 100
return _l1II11l
end function
function W_GetProgressPct(_l1I1lIl as String, _llI1lIl as String, _l1lIlIl as Integer, _lI11lIl as Integer) as Integer
if ((4395 - 1465 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lII1lIl = W_ItemKey(_l1I1lIl, _llI1lIl)
if _lII1lIl = "" then return 0
if _l1lIlIl > 0 and _lI11lIl > 0 then
_l111lIl = W_Read(_l1d_acf7d9("b983", 137, 205) + _lII1lIl + _l1d_acf7d9("31", 24, 15) + _l1lIlIl.ToStr() + _l1d_acf7d9("1b", 200, 41) + _lI11lIl.ToStr())
if _l111lIl = invalid or W_AsBool(_l111lIl.done) then return 0
return W_PercentOf(W_AsInt(_l111lIl.pos), W_AsInt(_l111lIl.dur))
end if
m = W_Read(_l1d_acf7d9("3a10", 143, 88) + _lII1lIl)
if m <> invalid and not W_AsBool(m.done) then
return W_PercentOf(W_AsInt(m.pos), W_AsInt(m.dur))
end if
_lllIlIl = W_Read(_l1d_acf7d9("85d1", 69, 79) + _lII1lIl)
if _lllIlIl <> invalid and not W_AsBool(_lllIlIl.done) then
return W_PercentOf(W_AsInt(_lllIlIl.pos), W_AsInt(_lllIlIl.dur))
end if
return 0
end function
function W_FavSection() as Object
_l11lIIl = CreateObject(_l1d_acf7d9("0d13f32324251e2025210a3b4032403d41", 95, 224), _l1d_acf7d9("aea2adabc8b09ed2bfa7b5d2dec6b4cebedac2d4c9", 119, 137))
_ll1lIIl = CreateObject(_l1d_acf7d9("c3d3a9e3e4ddd6dedbd9c2fbf8f0f8fdff", 90, 155), _l1d_acf7d9("a9bddbccdeb8c7b5cfede5f1e7f1ef03f4", 152, 217))
if _ll1lIIl.GetKeyList() <> invalid and _ll1lIIl.GetKeyList().Count() > 0 then
for each _lIllIIl in _ll1lIIl.GetKeyList()
if not _l11lIIl.Exists(_lIllIIl) then _l11lIIl.Write(_lIllIIl, _ll1lIIl.Read(_lIllIIl))
end for
_l11lIIl.Flush()
end if
return _l11lIIl
end function
function W_IsFavorite(_l1lIll1 as String, _lllIll1 as String) as Boolean
_lIlIll1 = W_ItemKey(_l1lIll1, _lllIll1)
if _lIlIll1 = "" then return false
return W_FavSection().Exists(_lIlIll1)
end function
sub W_AddFavorite(_l1IlIl1 as Object)
if ((18760 - 3752 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _l1IlIl1 = invalid then return
_lll1Il1 = ""
_lIIlIl1 = ""
if _l1IlIl1.imdb <> invalid then _lll1Il1 = _l1IlIl1.imdb
if _l1IlIl1.href <> invalid then _lIIlIl1 = _l1IlIl1.href
_l1l1Il1 = W_ItemKey(_lll1Il1, _lIIlIl1)
if _l1l1Il1 = "" then return
_lIl1Il1 = {
title:  ""
poster: ""
href:   _lIIlIl1
imdb:   _lll1Il1
tmdb:   ""
kind:   ""
ts:     CreateObject(_l1d_acf7d9("a8b8e4c4bacee0c8cfda", 122, 160)).AsSeconds()
}
if _l1IlIl1.title  <> invalid then _lIl1Il1.title  = _l1IlIl1.title
if _l1IlIl1.poster <> invalid then _lIl1Il1.poster = _l1IlIl1.poster
if _l1IlIl1.tmdb   <> invalid then _lIl1Il1.tmdb   = _l1IlIl1.tmdb
if _l1IlIl1.kind   <> invalid then _lIl1Il1.kind   = _l1IlIl1.kind
_ll11Il1 = W_FavSection()
_ll11Il1.Write(_l1l1Il1, FormatJson(_lIl1Il1))
_ll11Il1.Flush()
end sub
sub W_RemoveFavorite(_llIIl11 as String, _lI1Il11 as String)
if ((33138 - 3682 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1IIl11 = W_ItemKey(_llIIl11, _lI1Il11)
if _l1IIl11 = "" then return
_lIIIl11 = W_FavSection()
if _lIIIl11.Exists(_l1IIl11) then
_lIIIl11.Delete(_l1IIl11)
_lIIIl11.Flush()
end if
end sub
function W_ListFavorites() as Object
_l1lII11 = []
_ll1II11 = W_FavSection()
_lII1I11 = _ll1II11.GetKeyList()
if _lII1I11 = invalid then return _l1lII11
for each _l1I1I11 in _lII1I11
_lIlII11 = _ll1II11.Read(_l1I1I11)
if _lIlII11 <> invalid and _lIlII11 <> "" then
_lllII11 = ParseJson(_lIlII11)
if _lllII11 <> invalid then
if _lllII11.itemKey = invalid then _lllII11.itemKey = _l1I1I11
_l1lII11.Push(_lllII11)
end if
end if
end for
if _l1lII11.Count() > 1 then
for _lI11I11 = 0 to _l1lII11.Count() - 2
for _llI1I11 = 0 to _l1lII11.Count() - 2 - _lI11I11
_ll11I11 = W_AsInt(_l1lII11[_llI1I11].ts)
_l111I11 = W_AsInt(_l1lII11[_llI1I11 + 1].ts)
if _ll11I11 < _l111I11 then
_l11II11 = _l1lII11[_llI1I11]
_l1lII11[_llI1I11] = _l1lII11[_llI1I11 + 1]
_l1lII11[_llI1I11 + 1] = _l11II11
end if
end for
end for
end if
return _l1lII11
end function
function W_SearchHistoryMax() as Integer
return 12
end function
function W_GetSearchHistory() as Object
if ((7420 - 1855 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lIlIII1 = CreateObject(_l1d_acf7d9("55753b71767b686c6d7754898a7e969fa1", 16, 243), _l1d_acf7d9("875d686c89737f8d7a8890", 98, 87))
if not _lIlIII1.Exists(_l1d_acf7d9("cfdce3d7ebf316fae7e301eff9", 244, 72)) then
_lII1II1 = CreateObject(_l1d_acf7d9("343c1a484d4a47434c4633606955656668", 92, 6), _l1d_acf7d9("ab9d9daa9ebac9", 171, 200))
if _lII1II1.Exists(_l1d_acf7d9("d0c1c8daccdafddfe8eae2f2fe", 39, 124)) then return ParseJson(_lII1II1.Read(_l1d_acf7d9("3e3332483a341739565c486058", 137, 68)))
return []
end if
_l1lIII1 = _lIlIII1.Read(_l1d_acf7d9("eedbe2f6eae2c5e90602f00e08", 204, 47))
if _l1lIII1 = invalid or _l1lIII1 = "" then return []
_lllIII1 = ParseJson(_l1lIII1)
if _lllIII1 = invalid then return []
return _lllIII1
end function
sub W_PushSearchQuery(_l1l11lI as String)
if _l1l11lI = invalid then return
_lIl11lI = _l1l11lI
if Type(_lIl11lI) = _l1d_acf7d9("a7cdcee6f0ea", 209, 37) or Type(_lIl11lI) = _l1d_acf7d9("37351c46433f453f", 195, 134) then
_lIl11lI = U_Trim(_lIl11lI)
end if
if _lIl11lI = "" then return
_l1Il1lI = W_GetSearchHistory()
_lIIl1lI = [_lIl11lI]
_llIl1lI = LCase(_lIl11lI)
for each _lll11lI in _l1Il1lI
if Type(_lll11lI) = _l1d_acf7d9("edd1d2bcc4d0", 40, 114) or Type(_lll11lI) = _l1d_acf7d9("7e7463858a86847e", 135, 137) then
if LCase(_lll11lI) <> _llIl1lI and _lIIl1lI.Count() < W_SearchHistoryMax() then
_lIIl1lI.Push(_lll11lI)
end if
end if
end for
_ll111lI = CreateObject(_l1d_acf7d9("e3e109e1e2ebf4fefb0720f9f610060b0f", 35, 146), _l1d_acf7d9("83555058815f7789628078", 104, 73))
_ll111lI.Write(_l1d_acf7d9("7a93928296a285a9929ab49aa8", 210, 217), FormatJson(_lIIl1lI))
_ll111lI.Flush()
end sub
sub W_ClearSearchHistory()
_l11IIlI = CreateObject(_l1d_acf7d9("9b91c18d929facaab3bbd8a5aebcbabbbf", 37, 68), _l1d_acf7d9("c195a0a6c3abb9c5b2c2c8", 163, 208))
if _l11IIlI.Exists(_l1d_acf7d9("7a6b72827682a58992928c9aa8", 102, 101)) then
_l11IIlI.Delete(_l1d_acf7d9("e1eef5e9fdf518fcf9f50301fb", 60, 146))
_l11IIlI.Flush()
end if
end sub
function W_MirrorSection() as Object
return CreateObject(_l1d_acf7d9("110ff70f1019222c29350e27243e34393d", 67, 224), _l1d_acf7d9("4f5f5a5c45617b536c848263547b999c82a284a298a8b0", 13, 240))
end function
function W_MirrorRecord(_l1lllII as String) as Object
if _l1lllII = "" then return { ok: 0, fail: 0 }
_lI1llII = W_MirrorSection()
if not _lI1llII.Exists(_l1lllII) then return { ok: 0, fail: 0 }
_l11llII = _lI1llII.Read(_l1lllII)
_ll1llII = _l11llII.Tokenize(_l1d_acf7d9("02", 8, 208))
_lIlllII = 0
_lllllII = 0
if _ll1llII.Count() >= 1 then _lIlllII = _ll1llII[0].ToInt()
if _ll1llII.Count() >= 2 then _lllllII = _ll1llII[1].ToInt()
return { ok: _lIlllII, fail: _lllllII }
end function
sub W_RecordMirrorOutcome(_l1I11II as String, _l1lI1II as Boolean)
if _l1I11II = "" then return
_lII11II = W_MirrorRecord(_l1I11II)
if _l1lI1II then
_lII11II.ok = _lII11II.ok + 1
else
_lII11II.fail = _lII11II.fail + 1
end if
_lllI1II = W_MirrorSection()
_lllI1II.Write(_l1I11II, _lII11II.ok.ToStr() + _l1d_acf7d9("6d", 45, 86) + _lII11II.fail.ToStr())
_lllI1II.Flush()
end sub
function W_MirrorScore(_lI1llll as String) as Float
if ((56700 - 8100 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lI1llll = "" then return -1.0
_llIllll = W_MirrorRecord(_lI1llll)
_l1Illll = _llIllll.ok + _llIllll.fail
if _l1Illll = 0 then return -1.0
return _llIllll.ok / (_l1Illll * 1.0)
end function
function W_MirrorTotal(_ll1I1ll as String) as Integer
if ((48565 - 9713 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l11I1ll = W_MirrorRecord(_ll1I1ll)
return _l11I1ll.ok + _l11I1ll.fail
end function
function WL_IsFavorite(_l1l1l1l as String) as Boolean
if _l1l1l1l = invalid or _l1l1l1l = "" then return false
return W_IsFavorite(_l1l1l1l, "")
end function
sub WL_ToggleFavorite(_llllI1l as Object)
if ((43770 - 7295 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _llllI1l = invalid or _llllI1l.id = invalid or _llllI1l.id = "" then return
if WL_IsFavorite(_llllI1l.id) then
W_RemoveFavorite(_llllI1l.id, "")
else
_lIII11l = {
imdb: _llllI1l.id,
title: _llllI1l.title,
poster: _llllI1l.poster,
kind: _llllI1l.kind,
year: _llllI1l.year,
rating: _llllI1l.rating
}
W_AddFavorite(_lIII11l)
end if
end sub
function WL_GetFavorites() as Object
_lllIlIl = W_ListFavorites()
_lII1lIl = []
if _lllIlIl <> invalid then
for each _l1I1lIl in _lllIlIl
_llI1lIl = _l1I1lIl.imdb
if _llI1lIl = invalid or _llI1lIl = "" then _llI1lIl = _l1I1lIl.itemKey
_lII1lIl.Push({
id: _llI1lIl,
title: _l1I1lIl.title,
poster: _l1I1lIl.poster,
kind: _l1I1lIl.kind,
year: _l1I1lIl.year,
rating: _l1I1lIl.rating
})
end for
end if
return _lII1lIl
end function
function _l1d_acf7d9(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function