function HM_FetchQualities(_l11I1ll as String, _l1lI1ll as String, _ll1I1ll as Object) as Object
if ((9054 - 1509 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lllI1ll = []
if _l11I1ll = invalid or _l11I1ll = "" then return _lllI1ll
if Instr(1, LCase(_l11I1ll), _l1d_f60394("9fe5a2e3a1", 158, 239)) = 0 then return _lllI1ll
_lII11ll = {}
if _l1lI1ll <> "" then _lII11ll[_l1d_f60394("68747a7a94809a", 77, 73)] = _l1lI1ll
_lIlI1ll = HC_Get(_ll1I1ll, _l11I1ll, _lII11ll, 6000)
if _lIlI1ll = invalid or _lIlI1ll.body = "" then return _lllI1ll
if Instr(1, _lIlI1ll.body, _l1d_f60394("7f646a7985738b8488897f7e7da07f8792", 232, 180)) = 0 then return _lllI1ll
return HM_ParseMasterPlaylist(_lIlI1ll.body, _l11I1ll)
end function
function HM_ParseMasterPlaylist(_ll1Il1l as String, _l1Ill1l as String) as Object
if ((27015 - 5403 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lllIl1l = []
if _ll1Il1l = invalid or _ll1Il1l = "" then return _lllIl1l
_l1I1l1l = _ll1Il1l.Tokenize(chr(10))
if _l1I1l1l = invalid then return _lllIl1l
_lII1l1l = _l1I1l1l.Count()
for _l111l1l = 0 to _lII1l1l - 1
line = _l1I1l1l[_l111l1l]
if Left(line, 17) <> _l1d_f60394("fba4bab915c31bc0c8c5bfbecd30cfd3ce", 66, 154) then continue for
_llIll1l = HM_ParseAttrs(line)
_lIIll1l = 0
if _llIll1l.BANDWIDTH <> invalid then _lIIll1l = _llIll1l.BANDWIDTH.ToInt()
_ll11l1l = 0
_lIlIl1l = ""
if _llIll1l.RESOLUTION <> invalid then _lIlIl1l = _llIll1l.RESOLUTION
if _lIlIl1l <> "" then
_lI1Il1l = Instr(1, _lIlIl1l, _l1d_f60394("b3", 226, 25))
if _lI1Il1l > 0 and _lI1Il1l < Len(_lIlIl1l) then
_ll11l1l = Mid(_lIlIl1l, _lI1Il1l + 1).ToInt()
end if
end if
_l11Il1l = ""
for _lI11l1l = _l111l1l + 1 to _lII1l1l - 1
_lll1l1l = U_Trim(_l1I1l1l[_lI11l1l])
if _lll1l1l = "" then continue for
if Left(_lll1l1l, 1) = _l1d_f60394("83", 73, 25) then continue for
_l11Il1l = _lll1l1l
exit for
end for
if _l11Il1l = "" then continue for
_l11Il1l = RP_AbsUrl(_l11Il1l, _l1Ill1l)
_llI1l1l = _l1d_f60394("335f555d686a63", 25, 228)
if _ll11l1l > 0 then
_llI1l1l = _ll11l1l.ToStr() + _l1d_f60394("4b", 170, 113)
else if _lIIll1l > 0 then
_llI1l1l = (_lIIll1l \ 1000).ToStr() + _l1d_f60394("35415656", 47, 241)
end if
_lllIl1l.Push({
label: _llI1l1l
height: _ll11l1l
bandwidth: _lIIll1l
url: _l11Il1l
})
end for
for _l111l1l = 1 to _lllIl1l.Count() - 1
_l1l1l1l = _lllIl1l[_l111l1l]
_lIl1l1l = _l1l1l1l.height
if _lIl1l1l = invalid then _lIl1l1l = 0
_lI11l1l = _l111l1l - 1
while _lI11l1l >= 0
_l1lIl1l = _lllIl1l[_lI11l1l].height
if _l1lIl1l = invalid then _l1lIl1l = 0
if _l1lIl1l >= _lIl1l1l then exit while
_lllIl1l[_lI11l1l + 1] = _lllIl1l[_lI11l1l]
_lI11l1l = _lI11l1l - 1
end while
_lllIl1l[_lI11l1l + 1] = _l1l1l1l
end for
return _lllIl1l
end function
function HM_ParseAttrs(line as String) as Object
if ((20528 - 5132 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llII11l = {}
if line = invalid or line = "" then return _llII11l
_lIII11l = CreateObject(_l1d_f60394("391f5f2b303141", 109, 26), _l1d_f60394("56ec0564f45d6d5c730677786f7d", 88, 230) + chr(34) + _l1d_f60394("8886", 214, 251) + chr(34) + _l1d_f60394("6450", 18, 21) + chr(34) + _l1d_f60394("f5d3d9cee2ced4", 146, 7), _l1d_f60394("03", 117, 241))
_lI1I11l = _lIII11l.matchAll(line)
if _lI1I11l = invalid then return _llII11l
for each _l1II11l in _lI1I11l
if _l1II11l.Count() < 3 then continue for
_l11I11l = _l1II11l[1]
_llllI1l = _l1II11l[2]
if Len(_llllI1l) >= 2 and Left(_llllI1l, 1) = chr(34) and Right(_llllI1l, 1) = chr(34) then
_llllI1l = Mid(_llllI1l, 2, Len(_llllI1l) - 2)
end if
_llII11l[_l11I11l] = _llllI1l
end for
return _llII11l
end function
function HM_CoerceKind(_lIl1lIl as String) as String
if ((63837 - 7093 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lIl1lIl = invalid or _lIl1lIl = "" then return ""
_ll11lIl = LCase(_lIl1lIl)
if Instr(1, _ll11lIl, _l1d_f60394("eef4f1eefc", 91, 188)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("47514751515751", 195, 155)) > 0 then return _l1d_f60394("d4d2cfd4da", 255, 62)
if Instr(1, _ll11lIl, _l1d_f60394("9c959798a8", 184, 197)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("32243a3c4432", 112, 31)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("f804fd0d0d09", 148, 7)) > 0 then return _l1d_f60394("b7d0d4ddc3", 45, 117)
if Instr(1, _ll11lIl, _l1d_f60394("283e3f4032", 16, 198)) > 0 then return _l1d_f60394("3a2e2f3044", 33, 231)
return ""
end function
function HM_ExtractChaptersHtml(_l1llIIl as String) as Object
_llIlIIl = []
if _l1llIIl = invalid or _l1llIIl = "" then return _llIlIIl
_lll1IIl = {}
_ll1lIIl = CreateObject(_l1d_f60394("5e4e845e5f646a", 170, 134), chr(34) + _l1d_f60394("8a9e9ee8d3d8f49eb3a5e7ed0a07f50bfb181c19071d11251d21173733353a322f344847375147414147515f595360565c661f", 171, 7) + chr(34) + _l1d_f60394("3105c1d43d11cd46224c20dc", 35, 178) + chr(34) + _l1d_f60394("2f37473740", 90, 6) + chr(34) + _l1d_f60394("213511042d411d223964282e22224b3c517c40453a4b6377535c6f835f", 147, 82) + chr(34) + _l1d_f60394("aeaab3", 108, 165) + chr(34) + _l1d_f60394("4874c0b35480ccd1609bd7ddc9d172e378b3eff4e1fa", 95, 69), _l1d_f60394("3233", 17, 186))
_lIllIIl = _ll1lIIl.matchAll(_l1llIIl)
if _lIllIIl <> invalid then
for each _lI1lIIl in _lIllIIl
if _lI1lIIl.Count() < 4 then continue for
_l11lIIl = HM_CoerceKind(_lI1lIIl[1])
if _l11lIIl = "" or _lll1IIl.DoesExist(_l11lIIl) then continue for
_l1l1IIl = _lI1lIIl[2].ToFloat()
_llllIIl = _lI1lIIl[3].ToFloat()
if _llllIIl > _l1l1IIl then
_llIlIIl.Push({ kind: _l11lIIl, start: _l1l1IIl, end: _llllIIl })
_lll1IIl[_l11lIIl] = true
end if
end for
end if
_l1IlIIl = CreateObject(_l1d_f60394("1810fe10111634", 6, 164), _l1d_f60394("dc202009122a1a30191b243c2c3e303e405036404445535c5d4f566c5868747a7a766e7a867f8f8f8b58adacac60b3589793ab9f9cce", 52, 192) + chr(34) + _l1d_f60394("3e621e263a4c393f5691454b3f3f68596ea95d6257687983a7898d8eab79887d8285c384968a8ab399a4b5bcc2b4c7a805ff0cd0", 155, 119) + chr(34) + _l1d_f60394("dafc464436ea4343f2fd4f4f616704590a156768796e", 68, 194), _l1d_f60394("6a67", 194, 191))
_lIIlIIl = _l1IlIIl.matchAll(_l1llIIl)
if _lIIlIIl <> invalid then
for each _lI1lIIl in _lIIlIIl
if _lI1lIIl.Count() < 4 then continue for
_l11lIIl = HM_CoerceKind(_lI1lIIl[1])
if _l11lIIl = "" or _lll1IIl.DoesExist(_l11lIIl) then continue for
_l1l1IIl = _lI1lIIl[2].ToFloat()
_llllIIl = _lI1lIIl[3].ToFloat()
if _llllIIl > _l1l1IIl then
_llIlIIl.Push({ kind: _l11lIIl, start: _l1l1IIl, end: _llllIIl })
_lll1IIl[_l11lIIl] = true
end if
end for
end if
return _llIlIIl
end function
function HM_ExtractChaptersHls(_l1Il1l1 as String, _llll1l1 as String, _l11l1l1 as Object) as Object
_lIIIll1 = []
if _l1Il1l1 = invalid or _l1Il1l1 = "" then return _lIIIll1
_l11Ill1 = {}
if _llll1l1 <> "" then _l11Ill1[_l1d_f60394("a4b0b6b6d0bcd6", 13, 69)] = _llll1l1
_l1ll1l1 = HC_Get(_l11l1l1, _l1Il1l1, _l11Ill1, 6000)
if _l1ll1l1 = invalid or _l1ll1l1.body = "" then return _lIIIll1
_lIIl1l1 = _l1ll1l1.body
if Instr(1, _lIIl1l1, _l1d_f60394("80696f7e8a78907a7a90849086828e93", 106, 55)) = 0 then
if Instr(1, _lIIl1l1, _l1d_f60394("da7f7574f07ef67f83849a99a80baab2ad", 208, 231)) = 0 then return _lIIIll1
_ll1Ill1 = ""
_l1IIll1 = _lIIl1l1.Tokenize(chr(10))
if _l1IIll1 = invalid then return _lIIIll1
for _lI1Ill1 = 0 to _l1IIll1.Count() - 1
_lII1ll1 = U_Trim(_l1IIll1[_lI1Ill1])
if _lII1ll1 = "" or Left(_lII1ll1, 1) = _l1d_f60394("3e", 151, 138) then continue for
_ll1Ill1 = _lII1ll1
exit for
end for
if _ll1Ill1 = "" then return _lIIIll1
_ll1Ill1 = RP_AbsUrl(_ll1Ill1, _l1Il1l1)
_lIll1l1 = HC_Get(_l11l1l1, _ll1Ill1, _l11Ill1, 6000)
if _lIll1l1 = invalid or _lIll1l1.body = "" then return _lIIIll1
_lIIl1l1 = _lIll1l1.body
if Instr(1, _lIIl1l1, _l1d_f60394("349d95944e9e54b0aea6b8a6bac8c2c7", 179, 164)) = 0 then return _lIIIll1
end if
_ll1l1l1 = {}
_l1IIll1 = _lIIl1l1.Tokenize(chr(10))
if _l1IIll1 = invalid then return _lIIIll1
for _lI1Ill1 = 0 to _l1IIll1.Count() - 1
line = _l1IIll1[_lI1Ill1]
if Left(line, 16) <> _l1d_f60394("82dfedf480f686f0f806fa1204fc0809", 172, 243) then continue for
_l1I1ll1 = HM_ParseAttrs(line)
_lllIll1 = ""
if _l1I1ll1.CLASS <> invalid then _lllIll1 = _l1I1ll1.CLASS
_llIIll1 = HM_CoerceKind(_lllIll1)
if _llIIll1 = "" and _l1I1ll1.ID <> invalid then _llIIll1 = HM_CoerceKind(_l1I1ll1.ID)
if _llIIll1 = "" or _ll1l1l1.DoesExist(_llIIll1) then continue for
_lI1l1l1 = ""
if _l1I1ll1.X_START <> invalid then _lI1l1l1 = _l1I1ll1.X_START
if _lI1l1l1 = "" and _l1I1ll1[_l1d_f60394("3dad4a4a625253", 94, 55)] <> invalid then _lI1l1l1 = _l1I1ll1[_l1d_f60394("3068313545393e", 240, 136)]
if _lI1l1l1 = "" and _l1I1ll1[_l1d_f60394("fc741d1c1d801f27202131922b2f3f3338", 88, 252)] <> invalid then _lI1l1l1 = _l1I1ll1[_l1d_f60394("ae86abaaaf92b1b5d2cfbfa4d9e1d1e1ea", 138, 220)]
_llIl1l1 = 0.0
if _lI1l1l1 <> "" then _llIl1l1 = _lI1l1l1.ToFloat()
_l1lIll1 = ""
if _l1I1ll1[_l1d_f60394("0311ecfaf3", 229, 70)] <> invalid then _l1lIll1 = _l1I1ll1[_l1d_f60394("c4fce7dfec", 122, 162)]
if _l1lIll1 = "" and _l1I1ll1[_l1d_f60394("99f196959afd9ca0bdbaaa0fbab2bf", 202, 7)] <> invalid then _l1lIll1 = _l1I1ll1[_l1d_f60394("47fd5665660968725b5c7a1b76847d", 49, 222)]
_lIlIll1 = 0.0
if _l1lIll1 <> "" then
_lIlIll1 = _l1lIll1.ToFloat()
else if _l1I1ll1.DURATION <> invalid then
_lIlIll1 = _llIl1l1 + _l1I1ll1.DURATION.ToFloat()
end if
if _lIlIll1 > _llIl1l1 then
_lIIIll1.Push({ kind: _llIIll1, start: _llIl1l1, end: _lIlIll1 })
_ll1l1l1[_llIIll1] = true
end if
end for
return _lIIIll1
end function
function HM_ExtractSubsHls(_lllIIl1 as String, _lI11Il1 as String, _lII1Il1 as Object) as Object
_l111Il1 = []
if _lllIIl1 = invalid or _lllIIl1 = "" then return _l111Il1
if Instr(1, LCase(_lllIIl1), _l1d_f60394("a06293509e", 212, 166)) = 0 then return _l111Il1
_lIIlIl1 = {}
if _lI11Il1 <> "" then _lIIlIl1[_l1d_f60394("0f4349493b4f41", 209, 140)] = _lI11Il1
_llI1Il1 = HC_Get(_lII1Il1, _lllIIl1, _lIIlIl1, 6000)
if _llI1Il1 = invalid or _llI1Il1.body = "" then return _l111Il1
_l1lIIl1 = _llI1Il1.body
if Instr(1, _l1lIIl1, _l1d_f60394("f301fd0b2607041e0b29112c261f", 245, 82)) = 0 then return _l111Il1
_lIl1Il1 = _l1lIIl1.Tokenize(chr(10))
if _lIl1Il1 = invalid then return _l111Il1
_l1I1Il1 = {}
for _lll1Il1 = 0 to _lIl1Il1.Count() - 1
line = U_Trim(_lIl1Il1[_lll1Il1])
if Left(line, 12) <> _l1d_f60394("963f3534b03eb65954565e59", 210, 165) then continue for
if Instr(1, line, _l1d_f60394("353b372d683d46344d43534e4855", 99, 254)) = 0 then continue for
_llIlIl1 = HM_ParseAttrs(line)
_lIlIIl1 = ""
if _llIlIl1.URI <> invalid then _lIlIIl1 = _llIlIl1.URI
if _lIlIIl1 = "" then continue for
_lI1lIl1 = RP_AbsUrl(_lIlIIl1, _lllIIl1)
_l1IlIl1 = HM_ResolveSubPlaylist(_lI1lIl1, _lI11Il1, _lII1Il1)
if _l1IlIl1 = "" then continue for
_l1l1Il1 = _l1d_f60394("5951", 94, 30)
if _llIlIl1.LANGUAGE <> invalid then _l1l1Il1 = LCase(_llIlIl1.LANGUAGE)
_ll11Il1 = ""
if _llIlIl1.NAME <> invalid then _ll11Il1 = _llIlIl1.NAME
if _ll11Il1 = "" then _ll11Il1 = UCase(_l1l1Il1)
if _l1I1Il1.DoesExist(_l1IlIl1) then continue for
_l1I1Il1[_l1IlIl1] = true
_l111Il1.Push({
url: _l1IlIl1
language: _l1l1Il1
name: _ll11Il1
})
end for
return _l111Il1
end function
function HM_ResolveSubPlaylist(_lIll111 as String, _lIIIl11 as String, _l1ll111 as Object) as String
if _lIll111 = invalid or _lIll111 = "" then return ""
_llIIl11 = LCase(_lIll111)
if Instr(1, _llIIl11, _l1d_f60394("6712171a", 242, 139)) > 0 then return _lIll111
if Instr(1, _llIIl11, _l1d_f60394("34828683", 5, 9)) > 0 then return _lIll111
if Instr(1, _llIIl11, _l1d_f60394("2a6e3b7c4c", 135, 129)) = 0 then return _lIll111
_l11Il11 = {}
if _lIIIl11 <> "" then _l11Il11[_l1d_f60394("14080e0e001406", 249, 105)] = _lIIIl11
_llll111 = HC_Get(_l1ll111, _lIll111, _l11Il11, 5000)
if _llll111 = invalid or _llll111.body = "" then return _lIll111
_l1IIl11 = _llll111.body.Tokenize(chr(10))
if _l1IIl11 = invalid then return _lIll111
for _lI1Il11 = 0 to _l1IIl11.Count() - 1
_ll1Il11 = U_Trim(_l1IIl11[_lI1Il11])
if _ll1Il11 = "" or Left(_ll1Il11, 1) = _l1d_f60394("a4", 70, 63) then continue for
return RP_AbsUrl(_ll1Il11, _lIll111)
end for
return _lIll111
end function
function HM_ScrapeSubs(_l1l1I11 as String) as Object
_l1I1I11 = []
if _l1l1I11 = invalid or _l1l1I11 = "" then return _l1I1I11
_lII1I11 = CreateObject(_l1d_f60394("233909353a3b3b", 85, 252), _l1d_f60394("dea1a0a3a2a4e3e1f9fc8b91", 218, 236) + chr(34) + _l1d_f60394("0f3d40436f274b2052232c3840878c8f8a969a9b494c", 15, 231), _l1d_f60394("5b50", 230, 204))
_lI11I11 = _lII1I11.matchAll(_l1l1I11)
if _lI11I11 = invalid then return _l1I1I11
_lllII11 = {}
for each _llI1I11 in _lI11I11
if _llI1I11.Count() < 2 then continue for
_l1lII11 = _llI1I11[1]
if _lllII11.DoesExist(_l1lII11) then continue for
_lllII11[_l1lII11] = true
_lIl1I11 = _l1d_f60394("a0ac", 32, 91)
_ll11I11 = CreateObject(_l1d_f60394("1c1c021c1d2238", 130, 44), _l1d_f60394("df16e91aed1bf1ea29d9ffe02ae8370c4345194a1d", 248, 60), _l1d_f60394("b3", 15, 77))
_l111I11 = _ll11I11.match(_l1lII11)
if _l111I11 <> invalid and _l111I11.Count() >= 2 then _lIl1I11 = LCase(_l111I11[1])
_l1I1I11.Push({ url: _l1lII11, language: _lIl1I11, name: UCase(_lIl1I11) })
end for
return _l1I1I11
end function
function HM_MergeSubs(_l1ll1I1 as Object, _lIIIlI1 as Object) as Object
_llll1I1 = []
_ll1l1I1 = {}
if _l1ll1I1 <> invalid and type(_l1ll1I1) = _l1d_f60394("584e2b6164546f", 69, 33) then
for each _lIll1I1 in _l1ll1I1
if type(_lIll1I1) <> _l1d_f60394("a89ebbb0b3aaa9b2adbdbbc5b5dcd2d5c5e0", 101, 145) then continue for
if _lIll1I1.url = invalid or _lIll1I1.url = "" then continue for
if _ll1l1I1.DoesExist(_lIll1I1.url) then continue for
_ll1l1I1[_lIll1I1.url] = true
_llll1I1.Push(_lIll1I1)
end for
end if
if _lIIIlI1 <> invalid and type(_lIIIlI1) = _l1d_f60394("949ccd9da0b6a1", 254, 8) then
for each _lIll1I1 in _lIIIlI1
if type(_lIll1I1) <> _l1d_f60394("7f6794898c73827b8694849c8eb5a9ac9ea9", 172, 161) then continue for
if _lIll1I1.url = invalid or _lIll1I1.url = "" then continue for
if _ll1l1I1.DoesExist(_lIll1I1.url) then continue for
_ll1l1I1[_lIll1I1.url] = true
_llll1I1.Push(_lIll1I1)
end for
end if
return _llll1I1
end function
function HM_FetchFreeSubs(_l1I1II1 as String, _lIlIII1 as String, _lII1II1 as String, _lllIII1 as Integer, _llI1II1 as Integer, _l1lIII1 as Object) as Object
if ((50052 - 8342 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return HM_QueryOpenSubtitles(_l1I1II1, _lII1II1, _lllIII1, _llI1II1, _l1lIII1)
end function
function HM_QueryOpenSubtitles(_lIIl1lI as String, _l1l11lI as String, _lII11lI as Integer, _l1Il1lI as Integer, _l1lI1lI as Object) as Object
_lI111lI = []
if _lIIl1lI = invalid or _lIIl1lI = "" then return _lI111lI
if Left(_lIIl1lI, 2) <> _l1d_f60394("373a", 149, 86) then return _lI111lI
_l11l1lI = Mid(_lIIl1lI, 3)
if _l11l1lI = "" then return _lI111lI
if _l1l11lI = _l1d_f60394("6a6b", 214, 200) and _lII11lI > 0 and _l1Il1lI > 0 then
_ll1I1lI = _l1d_f60394("32515453530f05086058656f185a746a647a83718a70907b859242849c924da49d9caea09e62afbfa9c2b1bfc17c", 11, 207) + _l1Il1lI.ToStr() + _l1d_f60394("5b201f29322c326e", 108, 24) + _l11l1lI + _l1d_f60394("2c8378778c7b7d3f", 168, 165) + _lII11lI.ToStr()
else
_ll1I1lI = _l1d_f60394("6c7b7e7d7d493f428a828f9952949e949ea4ad9bb4aabab5afbc7cbec6bc87cec7c6d8cad89cdde4e0dde9e9b3", 3, 1) + _l11l1lI
end if
_l1I11lI = HC_Get(_l1lI1lI, _ll1I1lI, {
"X-User-Agent": _l1d_f60394("a3a89ca7a7a1b7b9f1beb6fbe6dd", 103, 144)
"Accept": _l1d_f60394("2c40433a403d3e4e4c4d51935b655c60", 229, 168)
}, 6000)
if _l1I11lI = invalid or _l1I11lI.body = "" then return _lI111lI
if _l1I11lI.status < 200 or _l1I11lI.status >= 300 then return _lI111lI
_llI11lI = ParseJSON(_l1I11lI.body)
if _llI11lI = invalid or type(_llI11lI) <> _l1d_f60394("161e0b1f22341f", 220, 104) then return _lI111lI
_lI1I1lI = CreateObject(_l1d_f60394("5d5b435b5c6179", 67, 44), _l1d_f60394("9cc6c5dcaaa8bae7b6ee9fbfaed5c2c7cc061016121117e1e1f823e9ee", 146, 223), _l1d_f60394("9f", 89, 111))
_lllI1lI = {}
for each _llIl1lI in _llI11lI
if type(_llIl1lI) <> _l1d_f60394("dcf2cfe4e7fefd0601f10ff909f006091914", 149, 245) then continue for
_lIl11lI = ""
if _llIl1lI.SubLanguageID <> invalid then _lIl11lI = LCase(_llIl1lI.SubLanguageID)
if _lIl11lI = "" then continue for
if _lllI1lI.DoesExist(_lIl11lI) then continue for
_lI1l1lI = ""
if _llIl1lI.SubDownloadLink <> invalid then _lI1l1lI = _llIl1lI.SubDownloadLink
if _lI1l1lI = "" then continue for
_ll111lI = _lI1I1lI.match(_lI1l1lI)
if _ll111lI = invalid or _ll111lI.Count() < 3 then continue for
_l11I1lI = _ll111lI[1]
_lIlI1lI = _ll111lI[2]
_llII1lI = _l1d_f60394("ea01040b0d47373a191a0e45212222181f57211e613067", 238, 100) + _l11I1lI + _l1d_f60394("e9aea4f2", 212, 238) + _lIlI1lI + _l1d_f60394("07615d5b6574621e666b6e3f857d8d8490908c98457072836157", 158, 102)
_lll11lI = ""
if _llIl1lI.ISO639 <> invalid then _lll11lI = LCase(_llIl1lI.ISO639)
if _lll11lI = "" then _lll11lI = Left(_lIl11lI, 2)
_l1111lI = ""
if _llIl1lI.LanguageName <> invalid then _l1111lI = _llIl1lI.LanguageName
if _l1111lI = "" then _l1111lI = UCase(_lIl11lI)
_lI111lI.Push({
url: _llII1lI
language: _lll11lI
name: _l1111lI
})
_lllI1lI[_lIl11lI] = true
end for
return _lI111lI
end function
function HM_MergeSubtitles(_lIlIIlI as Object, _ll1IIlI as Object) as Object
_l1IIIlI = []
_l1lll1I = {}
_lllll1I = {}
if _lIlIIlI = invalid or type(_lIlIIlI) <> _l1d_f60394("fbf3140407fd18", 166, 39) then _lIlIIlI = []
if _ll1IIlI = invalid or type(_ll1IIlI) <> _l1d_f60394("0e1e43171a2c17", 120, 4) then _ll1IIlI = []
for each _lIIIIlI in _lIlIIlI
if type(_lIIIIlI) <> _l1d_f60394("cfedc6d7daf9f0fdf8f006f408e7f9fc100b", 19, 110) then continue for
_lIlll1I = ""
if _lIIIIlI.url <> invalid then _lIlll1I = _lIIIIlI.url
if _lIlll1I = "" then continue for
if _l1lll1I.DoesExist(_lIlll1I) then continue for
_lI1IIlI = ""
if _lIIIIlI.language <> invalid then _lI1IIlI = LCase(_lIIIIlI.language)
_llIIIlI = ""
if _lIIIIlI.name <> invalid then _llIIIlI = LCase(_lIIIIlI.name)
_l11IIlI = _lI1IIlI + _l1d_f60394("9e", 56, 90) + _llIIIlI
if _llIIIlI <> "" and _lllll1I.DoesExist(_l11IIlI) then continue for
_l1lll1I[_lIlll1I] = true
if _llIIIlI <> "" then _lllll1I[_l11IIlI] = true
_l1IIIlI.Push(_lIIIIlI)
end for
for each _lIIIIlI in _ll1IIlI
if type(_lIIIIlI) <> _l1d_f60394("dfdfb8e9ecebe2efea00f804fad9090c021d", 130, 239) then continue for
_lIlll1I = ""
if _lIIIIlI.url <> invalid then _lIlll1I = _lIIIIlI.url
if _lIlll1I = "" then continue for
if _l1lll1I.DoesExist(_lIlll1I) then continue for
_lI1IIlI = ""
if _lIIIIlI.language <> invalid then _lI1IIlI = LCase(_lIIIIlI.language)
_llIIIlI = ""
if _lIIIIlI.name <> invalid then _llIIIlI = LCase(_lIIIIlI.name)
_l11IIlI = _lI1IIlI + _l1d_f60394("42", 253, 193) + _llIIIlI
if _llIIIlI <> "" and _lllll1I.DoesExist(_l11IIlI) then continue for
_l1lll1I[_lIlll1I] = true
if _llIIIlI <> "" then _lllll1I[_l11IIlI] = true
_l1IIIlI.Push(_lIIIIlI)
end for
return _l1IIIlI
end function
function HM_FetchSkipTimes(_l1l111I as String, _llI111I as String, _lIl111I as String, _l11111I as Integer, _lll111I as Integer, _lI1111I as Object) as Object
_ll1111I = []
if _lIl111I <> _l1d_f60394("e6e7", 67, 175) then return _ll1111I
if _lll111I = invalid or _lll111I <= 0 then return _ll1111I
if _l11111I = invalid then _l11111I = 0
_ll1111I = HM_FetchTheIntroDB(_l1l111I, _llI111I, _l11111I, _lll111I, _lI1111I)
if _ll1111I.Count() > 0 then return _ll1111I
_ll1111I = HM_FetchIntroDB(_l1l111I, _l11111I, _lll111I, _lI1111I)
if _ll1111I.Count() > 0 then return _ll1111I
_ll1111I = HM_FetchAniSkipForEpisode(_llI111I, _lll111I, _lI1111I)
return _ll1111I
end function
function HM_FetchTheIntroDB(_lIIII1I as String, _llIllII as String, _l11llII as Integer, _l1III1I as Integer, _lI1llII as Object) as Object
_lllllII = []
if _l11llII <= 0 or _l1III1I <= 0 then return _lllllII
_lIlllII = ""
if _llIllII <> invalid and _llIllII <> "" then
_lIlllII = _l1d_f60394("c1ddd7d8f8e5e31f", 112, 189) + U_UrlEncode(_llIllII)
else if _lIIII1I <> invalid and _lIIII1I <> "" then
_lIlllII = _l1d_f60394("848b97986693a3cd", 89, 84) + U_UrlEncode(_lIIII1I)
else
return _lllllII
end if
_l1IllII = _l1d_f60394("cbdadddcdea8a0a3dceeeaaefbf2f2f9fd0a07070300cf131911dc26e5e52a25272f2a07", 130, 225) + _lIlllII + _l1d_f60394("73c1b6b5cac9cd9d", 161, 236) + _l11llII.ToStr() + _l1d_f60394("9ee0cedad7e6eef29d", 152, 224) + _l1III1I.ToStr()
_ll1llII = HC_Get(_lI1llII, _l1IllII, {
"Accept": _l1d_f60394("14080b1218212616242125e72f293034", 191, 54)
"User-Agent": _l1d_f60394("e0141f1dfa22100431192776043a412a83748a7b", 87, 219)
}, 5000)
if _ll1llII = invalid or _ll1llII.body = "" then return _lllllII
if _ll1llII.status = 204 or _ll1llII.status = 404 then return _lllllII
_l1lllII = ParseJSON(_ll1llII.body)
if _l1lllII = invalid or type(_l1lllII) <> _l1d_f60394("9f97b4a9aca3a2aba6b4b4bcaed5c9ccbed9", 36, 73) then return _lllllII
HM_AppendTheIntroDbSegments(_l1lllII.intro,   _l1d_f60394("b0b099a2ba", 148, 179),  _lllllII)
HM_AppendTheIntroDbSegments(_l1lllII.recap,   _l1d_f60394("a4bcb9beb2", 251, 27),  _lllllII)
HM_AppendTheIntroDbSegments(_l1lllII.credits, _l1d_f60394("0f0c10151b", 31, 159),  _lllllII)
return _lllllII
end function
sub HM_AppendTheIntroDbSegments(_lI111II as Dynamic, _lII11II as String, _lllI1II as Object)
if ((37888 - 4736 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lI111II = invalid or type(_lI111II) <> _l1d_f60394("405039494c624d", 26, 216) then return
for each _l1lI1II in _lI111II
if type(_l1lI1II) <> _l1d_f60394("b8c0edc2c5ccdbd4dfcdddd5e70ee2e5f7e2", 188, 234) then continue for
_lIlI1II = 0
if _l1lI1II.start_ms <> invalid then _lIlI1II = _l1lI1II.start_ms
_llI11II = invalid
if _l1lI1II.end_ms <> invalid then _llI11II = _l1lI1II.end_ms
if _llI11II = invalid then continue for
_ll1I1II = _lIlI1II / 1000.0
_l1I11II = _llI11II / 1000.0
if _l1I11II <= _ll1I1II then continue for
_lllI1II.Push({ kind: _lII11II, start: _ll1I1II, end: _l1I11II })
end for
end sub
function HM_FetchIntroDB(_lI1llll as String, _ll11lll as Integer, _l11llll as Integer, _lI11lll as Object) as Object
_lll1lll = []
if _lI1llll = invalid or _lI1llll = "" then return _lll1lll
if _ll11lll <= 0 or _l11llll <= 0 then return _lll1lll
_l1I1lll = _l1d_f60394("7a91949b9d57474a9bad99559f9bb8bda5b1b66dbfd1d47ad9cacbc8d3cbe8eea5dedde7ec14edf3bf", 46, 52) + U_UrlEncode(_lI1llll) + _l1d_f60394("85d3c8c7dcdbdfaf", 129, 222) + _ll11lll.ToStr() + _l1d_f60394("a0665c6861687478a3", 126, 72) + _l11llll.ToStr()
_lIl1lll = HC_Get(_lI11lll, _l1I1lll, {
"Accept": _l1d_f60394("5264674e56636472626365296f8b7274", 44, 5)
"User-Agent": _l1d_f60394("35494f445a443ba7336b725bb4a5b9aa", 86, 23)
}, 5000)
if _lIl1lll = invalid or _lIl1lll.body = "" then return _lll1lll
if _lIl1lll.status = 204 or _lIl1lll.status = 404 then return _lll1lll
_l1l1lll = ParseJSON(_lIl1lll.body)
if _l1l1lll = invalid then return _lll1lll
_l1Illll = invalid
if type(_l1l1lll) = _l1d_f60394("a6967fafb2a8b3", 138, 174) then
_l1Illll = _l1l1lll
else if type(_l1l1lll) = _l1d_f60394("bea4d5c6c9b0bfbcc7d7c5dbcff6e8ebdfea", 111, 161) then
if _l1l1lll.segments <> invalid and type(_l1l1lll.segments) = _l1d_f60394("ece405f5f8ee09", 166, 24) then _l1Illll = _l1l1lll.segments
if _l1Illll = invalid and _l1l1lll.data <> invalid and type(_l1l1lll.data) = _l1d_f60394("57452e60635762", 139, 94) then _l1Illll = _l1l1lll.data
if _l1Illll = invalid and _l1l1lll.results <> invalid and type(_l1l1lll.results) = _l1d_f60394("5262875b5e705b", 56, 8) then _l1Illll = _l1l1lll.results
end if
if _l1Illll = invalid then return _lll1lll
for each _llIllll in _l1Illll
if type(_llIllll) <> _l1d_f60394("796f4c81847b7a837e8e8c96866da3a696b1", 5, 2) then continue for
_l111lll = ""
if _llIllll.segment_type <> invalid then _l111lll = LCase(_llIllll.segment_type)
if _l111lll = "" and _llIllll.type <> invalid then _l111lll = LCase(_llIllll.type)
_lIIllll = ""
if _l111lll = _l1d_f60394("a4aec7c8b6", 105, 164) then _lIIllll = _l1d_f60394("8c8ca5ae96", 204, 231)
if _l111lll = _l1d_f60394("9f8b9495a9", 173, 192) then _lIIllll = _l1d_f60394("728687887c", 185, 167)
if _l111lll = _l1d_f60394("a7a0a4a5b3", 57, 81) or _l111lll = _l1d_f60394("788a80828a989a", 64, 85) then _lIIllll = _l1d_f60394("3441434040", 226, 167)
if _lIIllll = "" then continue for
_llI1lll = HM_ParseClockOrSeconds(_llIllll.start_sec)
_ll1llll = HM_ParseClockOrSeconds(_llIllll.end_sec)
if _ll1llll <= _llI1lll then continue for
_lll1lll.Push({ kind: _lIIllll, start: _llI1lll, end: _ll1llll })
end for
return _lll1lll
end function
function HM_ParseClockOrSeconds(_lI1I1ll as Dynamic) as Float
if _lI1I1ll = invalid then return 0.0
_l11I1ll = type(_lI1I1ll)
if _l11I1ll = _l1d_f60394("280cf90d0e13ff", 178, 45) or _l11I1ll = _l1d_f60394("cfbfa0c4e1", 10, 87) or _l11I1ll = _l1d_f60394("224f4f5060", 199, 161) or _l11I1ll = _l1d_f60394("a2907c95999eb6", 201, 231) or _l11I1ll = _l1d_f60394("f41c29172822", 131, 45) or _l11I1ll = _l1d_f60394("5058405e576f6470", 220, 162) then
return _lI1I1ll + 0.0
end if
if _l11I1ll = _l1d_f60394("81a3a8b4b2bc", 31, 53) or _l11I1ll = _l1d_f60394("c1b9e8c8cdcbc7c3", 102, 173) then
_ll1I1ll = _lI1I1ll
if _ll1I1ll = "" then return 0.0
if Instr(1, _ll1I1ll, _l1d_f60394("37", 30, 19)) = 0 then return _ll1I1ll.ToFloat()
_lIlI1ll = _ll1I1ll.Tokenize(_l1d_f60394("c6", 64, 76))
if _lIlI1ll = invalid then return 0.0
_l1lI1ll = _lIlI1ll.Count()
if _l1lI1ll = 3 then
return _lIlI1ll[0].ToFloat() * 3600.0 + _lIlI1ll[1].ToFloat() * 60.0 + _lIlI1ll[2].ToFloat()
else if _l1lI1ll = 2 then
return _lIlI1ll[0].ToFloat() * 60.0 + _lIlI1ll[1].ToFloat()
else
return _ll1I1ll.ToFloat()
end if
end if
return 0.0
end function
function HM_FetchAniSkipForEpisode(_lI11l1l as String, _lIIll1l as Integer, _ll11l1l as Object) as Object
if ((17374 - 2482 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lIl1l1l = []
if _lI11l1l = invalid or _lI11l1l = "" then return _lIl1l1l
if _lIIll1l <= 0 then return _lIl1l1l
_l111l1l = HM_FetchTitleFromTmdb(_lI11l1l, _l1d_f60394("6465", 251, 213), _ll11l1l)
if _l111l1l = "" then return _lIl1l1l
_lll1l1l = HM_LookupMalIdViaJikan(_l111l1l, _ll11l1l)
if _lll1l1l <> "" then
_lIl1l1l = HM_FetchAniSkipByMal(_lll1l1l, _lIIll1l, _ll11l1l)
if _lIl1l1l.Count() > 0 then return _lIl1l1l
end if
_l1l1l1l = HM_LookupMalIdViaAnilist(_l111l1l, _ll11l1l)
if _l1l1l1l <> "" and _l1l1l1l <> _lll1l1l then
_lIl1l1l = HM_FetchAniSkipByMal(_l1l1l1l, _lIIll1l, _ll11l1l)
end if
return _lIl1l1l
end function
function HM_FetchTitleFromTmdb(_lIllI1l as String, _llII11l as String, _l1llI1l as Object) as String
if _lIllI1l = invalid or _lIllI1l = "" then return ""
_lIII11l = _l1d_f60394("b0c7cad1d7110104ccd50ce7d5dbdfe6fbf424fdeb2e4d34", 108, 172) + _llII11l + _l1d_f60394("d8", 104, 145) + _lIllI1l
_llllI1l = HC_Get(_l1llI1l, _lIII11l, {}, 5000)
if _llllI1l = invalid or _llllI1l.body = "" then return ""
_l1II11l = ParseJSON(_llllI1l.body)
if _l1II11l = invalid or type(_l1II11l) <> _l1d_f60394("eed4c5f6f9e0efecf707f50bffe6181b0f1a", 15, 113) then return ""
if _llII11l = _l1d_f60394("a2a3", 103, 143) then
if _l1II11l.original_name <> invalid and _l1II11l.original_name <> "" then return _l1II11l.original_name
if _l1II11l.name <> invalid then return _l1II11l.name
else
if _l1II11l.original_title <> invalid and _l1II11l.original_title <> "" then return _l1II11l.original_title
if _l1II11l.title <> invalid then return _l1II11l.title
end if
return ""
end function
function HM_LookupMalIdViaJikan(_lllIlIl as String, _lII1lIl as Object) as String
if ((20909 - 2987 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lllIlIl = invalid or _lllIlIl = "" then return ""
_l1lIlIl = _l1d_f60394("8c83868d8fc9d9dcad9fabe7aeb4b5c2b6f9bfc0cd06c0050fe0d4dedde811e219", 254, 246) + U_UrlEncode(_lllIlIl) + _l1d_f60394("6730303736449087", 224, 161)
_l1I1lIl = HC_Get(_lII1lIl, _l1lIlIl, { "Accept": _l1d_f60394("86787b828a979886969799dda39fa6a8", 220, 201) }, 5000)
if _l1I1lIl = invalid or _l1I1lIl.body = "" then return ""
_llI1lIl = ParseJSON(_l1I1lIl.body)
if _llI1lIl = invalid or type(_llI1lIl) <> _l1d_f60394("05fb1c0d100706130e1e1c22163d2f322641", 103, 240) then return ""
_lI11lIl = _llI1lIl.data
if _lI11lIl = invalid or type(_lI11lIl) <> _l1d_f60394("dccaf3e5e8dce7", 107, 195) or _lI11lIl.Count() = 0 then return ""
_l111lIl = _lI11lIl[0]
if type(_l111lIl) <> _l1d_f60394("c8e6bbd0d3f2e9f2ede5fbedfddcf2f50500", 145, 229) then return ""
if _l111lIl.mal_id = invalid then return ""
return _l111lIl.mal_id.ToStr()
end function
function HM_LookupMalIdViaAnilist(_lIIlIIl as String, _l1IlIIl as Object) as String
if _lIIlIIl = invalid or _lIIlIIl = "" then return ""
_lIllIIl = _l1d_f60394("b8", 54, 107) + chr(34) + _l1d_f60394("b5bccfbfc9", 240, 52) + chr(34) + _l1d_f60394("a5", 160, 11) + chr(34) + _l1d_f60394("5a6174645e303f712b977b7c868e9a4f84b9a4a69ea963a1b6b5a9bdb56a87b985c0b8c2da82fcfcfa010ca3d8e9f713faf8ecef", 184, 145) + chr(34) + _l1d_f60394("16", 248, 66) + chr(34) + _l1d_f60394("212f233d383c494536", 240, 155) + chr(34) + _l1d_f60394("cd8f", 239, 248) + chr(34) + _l1d_f60394("7e", 12, 255) + chr(34) + _l1d_f60394("70", 227, 151) + chr(34) + HM_JsonEscape(_lIIlIIl) + chr(34) + _l1d_f60394("7376", 250, 236)
_llIlIIl = HC_Post(_l1IlIIl, _l1d_f60394("09181b1a1ae6dcdf1a2a1e322d3737f8303e3e46444d57104655", 35, 190), { "Content-Type": _l1d_f60394("bfb3b6bdc3d0d1c1cfd0d496ded8dfe3", 189, 227), "Accept": _l1d_f60394("293d40272d3a3b4b393a3e004862494d", 141, 61) }, _lIllIIl, 5000)
if _llIlIIl = invalid or _llIlIIl.body = "" then return ""
_lI1lIIl = ParseJSON(_llIlIIl.body)
if _lI1lIIl = invalid or type(_lI1lIIl) <> _l1d_f60394("b5d3acbdc0dfd6e3ded6ecdaeecddfe2f6f1", 19, 84) then return ""
_ll1lIIl = _lI1lIIl.data
if _ll1lIIl = invalid or type(_ll1lIIl) <> _l1d_f60394("b3a1cabbbeadb4b1bcd4bad8ccebdde0d4df", 107, 154) then return ""
_l11lIIl = _ll1lIIl.Media
if _l11lIIl = invalid or type(_l11lIIl) <> _l1d_f60394("3a502d42455c5b645f4f6d57674e64677772", 21, 211) then return ""
if _l11lIIl.idMal = invalid then return ""
return _l11lIIl.idMal.ToStr()
end function
function HM_FetchAniSkipByMal(_l11Ill1 as String, _l1lIll1 as Integer, _l1ll1l1 as Object) as Object
_lI1Ill1 = []
if _l11Ill1 = invalid or _l11Ill1 = "" then return _lI1Ill1
_l11l1l1 = _l1d_f60394("31181b2222eefcff40344e0c4c525a435e634f2462696e2f5b223867828773497593928d8259", 183, 82) + _l11Ill1 + _l1d_f60394("90", 44, 141) + _l1lIll1.ToStr() + _l1d_f60394("6c2634303e37625f825745964755515f588380a36e72", 117, 34)
_lIIIll1 = HC_Get(_l1ll1l1, _l11l1l1, { "Accept": _l1d_f60394("1305080f17202513232022e62c282f31", 30, 148) }, 5000)
if _lIIIll1 = invalid or _lIIIll1.body = "" then return _lI1Ill1
_llIIll1 = ParseJSON(_lIIIll1.body)
if _llIIll1 = invalid or type(_llIIll1) <> _l1d_f60394("a0b697a8abc2c1cec9b9d7bdd1b8cacde1dc", 151, 187) then return _lI1Ill1
if _llIIll1.found <> true then return _lI1Ill1
_llll1l1 = _llIIll1.results
if _llll1l1 = invalid or type(_llll1l1) <> _l1d_f60394("987e6fa1a498a3", 143, 155) then return _lI1Ill1
for each _l1IIll1 in _llll1l1
if type(_l1IIll1) <> _l1d_f60394("5c74956669807f8c877595798fb686899f9a", 182, 152) then continue for
_lIlIll1 = _l1IIll1.interval
if _lIlIll1 = invalid or type(_lIlIll1) <> _l1d_f60394("0919421316252c29342a322e446333364c37", 250, 129) then continue for
_ll1l1l1 = 0.0
_lllIll1 = 0.0
if _lIlIll1.startTime <> invalid then _ll1l1l1 = _lIlIll1.startTime
if _lIlIll1.endTime <> invalid then _lllIll1 = _lIlIll1.endTime
if _lllIll1 <= _ll1l1l1 then continue for
_lIll1l1 = ""
if _l1IIll1.skipType <> invalid then _lIll1l1 = LCase(_l1IIll1.skipType)
_ll1Ill1 = ""
if _lIll1l1 = _l1d_f60394("4840", 26, 211) then _ll1Ill1 = _l1d_f60394("c1bfacb1c7", 23, 67)
if _lIll1l1 = _l1d_f60394("7377", 75, 69) then _ll1Ill1 = _l1d_f60394("ad9a9ca1b9", 214, 244)
if _lIll1l1 = _l1d_f60394("4f564a50541e6351", 21, 215) then _ll1Ill1 = _l1d_f60394("fbffece909", 18, 128)
if _lIll1l1 = _l1d_f60394("d8d7ebd9dda7e2e6", 131, 234) then _ll1Ill1 = _l1d_f60394("263f414a32", 236, 163)
if _lIll1l1 = _l1d_f60394("1121262b1f", 255, 132) then _ll1Ill1 = _l1d_f60394("74666b7082", 70, 64)
if _ll1Ill1 = "" then continue for
_lI1Ill1.Push({ kind: _ll1Ill1, start: _ll1l1l1, end: _lllIll1 })
end for
return _lI1Ill1
end function
function HM_JsonEscape(_l111Il1 as String) as String
if _l111Il1 = invalid or _l111Il1 = "" then return ""
_l1IlIl1 = chr(92)
_lIIlIl1 = _l111Il1
_lll1Il1 = CreateObject(_l1d_f60394("29310f41424735", 222, 125), _l1IlIl1 + _l1IlIl1, _l1d_f60394("eb", 249, 77))
_lIIlIl1 = _lll1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1IlIl1)
_l1l1Il1 = CreateObject(_l1d_f60394("cae0b0dce1e2e2", 149, 227), chr(34), _l1d_f60394("e4", 242, 79))
_lIIlIl1 = _l1l1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + chr(34))
_lIl1Il1 = CreateObject(_l1d_f60394("56663c7277785e", 152, 108), chr(10), _l1d_f60394("2d", 62, 212))
_lIIlIl1 = _lIl1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1d_f60394("22", 96, 20))
_ll11Il1 = CreateObject(_l1d_f60394("7e946494959a9a", 23, 25), chr(13), _l1d_f60394("3e", 189, 100))
_lIIlIl1 = _ll11Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1d_f60394("95", 253, 6))
return _lIIlIl1
end function
function _l1d_f60394(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function