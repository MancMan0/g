sub Main()
if ((16866 - 2811 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
ShowChannelSGScreen()
end sub
sub ShowChannelSGScreen()
_lll1l1l = CreateObject(_l1d_67ec73("4e5e758c7b6e607a7d75", 58, 6))
m.port = CreateObject(_l1d_67ec73("39593e5946495e636836745a63", 146, 89))
_lll1l1l.SetMessagePort(m.port)
_lIIll1l = _lll1l1l.CreateScene(_l1d_67ec73("c5a4afb1bfb2afbdb5", 245, 13))
_lIIll1l.observeField(_l1d_67ec73("270d211f4f2124", 122, 8), m.port)
_lll1l1l.Show()
while true
_llIll1l = wait(0, m.port)
_l1Ill1l = type(_llIll1l)
if _l1Ill1l = _l1d_67ec73("c5bdecdbf2c5d7c5c8d4eee2d4e0e9", 100, 175) then
if _llIll1l.isScreenClosed() then return
else if _l1Ill1l = _l1d_67ec73("fdede4dbd5f90105e81c0e0a23", 8, 131) then
if _llIll1l.getField() = _l1d_67ec73("7e667878a67a7d", 185, 162) and _llIll1l.getData() = true then
_lll1l1l.close()
return
end if
end if
end while
end sub
function _l1d_67ec73(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function