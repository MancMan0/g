function R4_KSA(_l1lI1ll as Object) as Object
_ll1I1ll = CreateObject(_l1d_503d1b("fd1bf30b0b1dfc12152520", 209, 90))
for _lII11ll = 0 to 255
_ll1I1ll.Push(_lII11ll)
end for
if _l1lI1ll = invalid or _l1lI1ll.Count() = 0 then return _ll1I1ll
_lIlI1ll = _l1lI1ll.Count()
_lllI1ll = 0
for _lII11ll = 0 to 255
_lllI1ll = (_lllI1ll + _ll1I1ll[_lII11ll] + _l1lI1ll[_lII11ll mod _lIlI1ll]) AND 255
_l11I1ll = _ll1I1ll[_lII11ll]
_ll1I1ll[_lII11ll] = _ll1I1ll[_lllI1ll]
_ll1I1ll[_lllI1ll] = _l11I1ll
end for
return _ll1I1ll
end function
function R4_PRGA(_l111l1l as Object, _llIll1l as Object) as Object
_ll11l1l = CreateObject(_l1d_503d1b("29311f2d33472e3e415742", 222, 125))
if _l111l1l = invalid or _llIll1l = invalid then return _ll11l1l
_l1Ill1l = 0
_lIIll1l = 0
_lIl1l1l = _llIll1l.Count()
for _lll1l1l = 0 to _lIl1l1l - 1
_l1Ill1l = (_l1Ill1l + 1) AND 255
_lIIll1l = (_lIIll1l + _l111l1l[_l1Ill1l]) AND 255
_lI11l1l = _l111l1l[_l1Ill1l]
_l111l1l[_l1Ill1l] = _l111l1l[_lIIll1l]
_l111l1l[_lIIll1l] = _lI11l1l
_l1l1l1l = _l111l1l[(_l111l1l[_l1Ill1l] + _l111l1l[_lIIll1l]) AND 255]
_ll11l1l.Push(B_Xor(_llIll1l[_lll1l1l], _l1l1l1l))
end for
return _ll11l1l
end function
function R4_Crypt(_lI1I11l as Object, _l11I11l as Object) as Object
_llII11l = R4_KSA(_lI1I11l)
return R4_PRGA(_llII11l, _l11I11l)
end function
function _l1d_503d1b(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function