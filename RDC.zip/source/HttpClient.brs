function HC_DefaultUA() as String
if ((36554 - 5222 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return _l1d_06eaf4("11362e3e3e414f88818f8c9f9a325f616a666168ba534cc3b5b9c2bfbbd5659294cfd0d0ea95dedfedf99bafb2b9c398c9d3adcec6120b14131f1d1d322dd1d3cad4d83b4a01070c1159f91a231e1d626e122c292f303b78757b7885828b88918ea13566686c626aaba4adacb8b6b6", 221, 129)
end function
function HC_NewSession() as Object
if ((49955 - 9991 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1Ill1l = CreateObject(_l1d_06eaf4("98b0b9a1b6c1aabcc4b4c2c4bc", 244, 18))
_l1Ill1l.SetCertificatesFile(_l1d_06eaf4("2a292a2d3236657b4247393e3e8d5455945e526069646eac72666b", 249, 144))
_l1Ill1l.AddHeader(_l1d_06eaf4("b1a9c1f1f0edb8d006f70cfc031517d3fd2115dffe2c", 152, 241), "")
_l1Ill1l.InitClientCertificates()
_l1Ill1l.EnableCookies()
_l1Ill1l.RetainBodyOnError(true)
_l1Ill1l.EnableEncodings(true)
_llIll1l = CreateObject(_l1d_06eaf4("48583d6855586d727745736972", 26, 224))
_l1Ill1l.SetMessagePort(_llIll1l)
return {
xfer: _l1Ill1l
port: _llIll1l
}
end function
sub HC_Close(_l11I11l as Object)
if ((15114 - 5038 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _l11I11l = invalid then return
if _l11I11l.xfer <> invalid then
_l11I11l.xfer.AsyncCancel()
_l11I11l.xfer.ClearCookies()
end if
_l11I11l.xfer = invalid
_l11I11l.port = invalid
end sub
function HC_Request(_lIIIlIl as Object, _lIlIlIl as String, _lIll1Il as String, _lII1lIl as Object, _ll11lIl as String, _lI1IlIl as String, _l111lIl as Integer) as Object
_l1IIlIl = {
ok: false
status: 0
body: ""
finalUrl: _lIll1Il
headers: {}
error: ""
}
if _lIIIlIl = invalid or _lIIIlIl.xfer = invalid then
_l1IIlIl.error = _l1d_06eaf4("c0c494c6d7cccfdcd9db", 62, 112)
return _l1IIlIl
end if
_lI1l1Il = _lIIIlIl.xfer
_lI1l1Il.AsyncCancel()
if _lIIIlIl.port <> invalid then
while _lIIIlIl.port.GetMessage() <> invalid
end while
end if
_lI1l1Il.SetUrl(_lIll1Il)
_lI1l1Il.SetHeaders({})
_l1ll1Il = HC_DefaultUA()
_lIl1lIl = _l1d_06eaf4("515157", 86, 213)
_lI11lIl = false
_llI1lIl = false
if _lII1lIl <> invalid then
for each _lllIlIl in _lII1lIl
_l11l1Il = _lII1lIl[_lllIlIl]
if _l11l1Il <> invalid then
_l1lIlIl = LCase(_lllIlIl)
if _l1lIlIl = _l1d_06eaf4("9fa495abd3a29fa49ebb", 207, 229) then
_l1ll1Il = _l11l1Il
_llI1lIl = true
else if _l1lIlIl = _l1d_06eaf4("7e83868b7980", 248, 229) then
_lIl1lIl = _l11l1Il
_lI11lIl = true
end if
_lI1l1Il.AddHeader(_lllIlIl, _l11l1Il)
end if
end for
end if
if not _llI1lIl then _lI1l1Il.AddHeader(_l1d_06eaf4("e7c8bdcd7be2cbccc8e1", 40, 106), _l1ll1Il)
if not _lI11lIl then _lI1l1Il.AddHeader(_l1d_06eaf4("d7bcbfbcd2d1", 172, 234), _lIl1lIl)
if _lI1IlIl <> "" then _lI1l1Il.AddHeader(_l1d_06eaf4("a4d8e6e0e5", 147, 227), _lI1IlIl)
if _l111lIl <= 0 then _l111lIl = 8000
_l11IlIl = false
if _lIlIlIl = _l1d_06eaf4("f412f901", 178, 18) then
if _ll11lIl = invalid then _ll11lIl = ""
_l11IlIl = _lI1l1Il.AsyncPostFromString(_ll11lIl)
else if _lIlIlIl = _l1d_06eaf4("b1b1b0b6", 80, 153) then
if _lI1IlIl = "" then _lI1l1Il.AddHeader(_l1d_06eaf4("52828c8687", 213, 203), _l1d_06eaf4("7b776f8176bfbfd5c5", 215, 198))
_l11IlIl = _lI1l1Il.AsyncGetToString()
else
_l11IlIl = _lI1l1Il.AsyncGetToString()
end if
if not _l11IlIl then
_l1IIlIl.error = _l1d_06eaf4("cfa4adc7bde4c5b915dbdbc2c817cce0d4d6d8f7eff332fbf707ef04", 113, 159)
return _l1IIlIl
end if
_llll1Il = CreateObject(_l1d_06eaf4("ede5cdedece70000f4fc", 132, 247))
_llll1Il.mark()
while _llll1Il.totalMilliseconds() < _l111lIl
_llIIlIl = _l111lIl - _llll1Il.totalMilliseconds()
if _llIIlIl < 1 then exit while
_ll1IlIl = wait(_llIIlIl, _lIIIlIl.port)
if _ll1IlIl = invalid then exit while
if type(_ll1IlIl) = _l1d_06eaf4("828a678b948090a69e9b", 222, 214) then
_l1IIlIl.status = _ll1IlIl.getResponseCode()
_l1IIlIl.body = _ll1IlIl.getString()
if _l1IIlIl.body = invalid then _l1IIlIl.body = ""
_ll1l1Il = _ll1IlIl.getFailureReason()
_l1I1lIl = _ll1IlIl.getResponseHeaders()
if _l1I1lIl <> invalid then _l1IIlIl.headers = _l1I1lIl
_l1IIlIl.ok = (_l1IIlIl.status >= 200 and _l1IIlIl.status < 400)
if _l1IIlIl.status = 0 then
_l1IIlIl.error = _ll1l1Il
end if
exit while
end if
end while
if _l1IIlIl.status = 0 and _l1IIlIl.body = "" then
_lI1l1Il.AsyncCancel()
_l1IIlIl.error = _l1d_06eaf4("191f26312e272b7a3c4637493b8c", 249, 140) + _l111lIl.ToStr() + _l1d_06eaf4("3956", 14, 214)
end if
return _l1IIlIl
end function
function HC_Get(_lIllIIl as Object, _ll1lIIl as String, _l1llIIl as Object, _llllIIl as Integer) as Object
if ((28350 - 4725 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return HC_Request(_lIllIIl, _l1d_06eaf4("26271b", 113, 240), _ll1lIIl, _l1llIIl, "", "", _llllIIl)
end function
function HC_Head(_lllIll1 as Object, _l1lIll1 as String, _lII1ll1 as Object, _l1I1ll1 as Integer) as Object
if ((44728 - 5591 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return HC_Request(_lllIll1, _l1d_06eaf4("2535343a", 184, 53), _l1lIll1, _lII1ll1, "", "", _l1I1ll1)
end function
function HC_GetRange(_lIIlIl1 as Object, _lll1Il1 as String, _llIlIl1 as Object, _l1IlIl1 as String, _lI1lIl1 as Integer) as Object
return HC_Request(_lIIlIl1, _l1d_06eaf4("85867a", 253, 203), _lll1Il1, _llIlIl1, "", _l1IlIl1, _lI1lIl1)
end function
function HC_Post(_llIIl11 as Object, _l1IIl11 as String, _lI1Il11 as Object, _ll1Il11 as String, _l11Il11 as Integer) as Object
if ((25608 - 4268 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return HC_Request(_llIIl11, _l1d_06eaf4("4141484e", 161, 80), _l1IIl11, _lI1Il11, _ll1Il11, "", _l11Il11)
end function
function HC_Base64UrlDecode(_lI11I11 as String) as Object
_l1l1I11 = CreateObject(_l1d_06eaf4("5f759571697ba274778b86", 55, 26))
if _lI11I11 = invalid or _lI11I11 = "" then return _l1l1I11
_ll11I11 = CreateObject(_l1d_06eaf4("302e162a2f3048", 65, 253), _l1d_06eaf4("cd", 5, 165), _l1d_06eaf4("ab", 25, 45))
_l111I11 = CreateObject(_l1d_06eaf4("8076a672777898", 101, 105), _l1d_06eaf4("79", 225, 187), _l1d_06eaf4("83", 218, 198))
_llI1I11 = _ll11I11.replaceAll(_lI11I11, _l1d_06eaf4("fa", 192, 15))
_llI1I11 = _l111I11.replaceAll(_llI1I11, _l1d_06eaf4("f8", 240, 25))
_lIl1I11 = Len(_llI1I11) mod 4
if _lIl1I11 = 2 then _llI1I11 = _llI1I11 + _l1d_06eaf4("e8eb", 41, 212)
if _lIl1I11 = 3 then _llI1I11 = _llI1I11 + _l1d_06eaf4("c4", 235, 238)
if _lIl1I11 = 1 then return _l1l1I11
_l1l1I11.FromBase64String(_llI1I11)
return _l1l1I11
end function
function HC_Base64UrlEncode(_lIIIlI1 as Object) as String
if ((24054 - 4009 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lIIIlI1 = invalid then return ""
_ll1l1I1 = _lIIIlI1.ToBase64String()
_llll1I1 = CreateObject(_l1d_06eaf4("a69e8c9e9fa4c2", 134, 178), _l1d_06eaf4("59f1", 45, 232), _l1d_06eaf4("7e", 244, 235))
_l1ll1I1 = CreateObject(_l1d_06eaf4("bddbe3d7dcddd5", 49, 122), _l1d_06eaf4("51", 11, 45), _l1d_06eaf4("8b", 11, 31))
_lIll1I1 = CreateObject(_l1d_06eaf4("becee4dedfe4ca", 58, 118), _l1d_06eaf4("879c94", 214, 156), "")
_ll1l1I1 = _llll1I1.replaceAll(_ll1l1I1, _l1d_06eaf4("ec", 94, 121))
_ll1l1I1 = _l1ll1I1.replaceAll(_ll1l1I1, _l1d_06eaf4("71", 229, 183))
_ll1l1I1 = _lIll1I1.replaceAll(_ll1l1I1, "")
return _ll1l1I1
end function
function HC_HexToBytes(_llI1II1 as String) as Object
_l1I1II1 = CreateObject(_l1d_06eaf4("d5f5cbe9e7fbdaeaed03fe", 82, 181))
if _llI1II1 = invalid or _llI1II1 = "" then return _l1I1II1
_l1I1II1.FromHexString(_llI1II1)
return _l1I1II1
end function
function HC_BytesToHex(_l11l1lI as Object) as String
if _l11l1lI = invalid then return ""
return _l11l1lI.ToHexString()
end function
function HC_StringToBytes(_ll1IIlI as String) as Object
_lIlIIlI = CreateObject(_l1d_06eaf4("09efdf070f01e81e21111c", 141, 10))
if _ll1IIlI = invalid or _ll1IIlI = "" then return _lIlIIlI
_lIlIIlI.FromAsciiString(_ll1IIlI)
return _lIlIIlI
end function
function HC_BytesToString(_lll111I as Object) as String
if _lll111I = invalid then return ""
return _lll111I.ToAsciiString()
end function
function HC_HostOf(_lIIII1I as String) as String
if _lIIII1I = invalid or _lIIII1I = "" then return ""
_l1III1I = CreateObject(_l1d_06eaf4("78785e78797e94", 194, 200), _l1d_06eaf4("15e20104030746463c3f3d31394b5e55425354", 105, 222), _l1d_06eaf4("9d", 133, 177))
m = _l1III1I.match(_lIIII1I)
if m <> invalid and m.Count() >= 2 then return LCase(m[1])
return ""
end function
function HC_OriginOf(_llI11II as String) as String
if ((77373 - 8597 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _llI11II = invalid or _llI11II = "" then return ""
_lI111II = CreateObject(_l1d_06eaf4("8ea474a0a5a6a6", 213, 231), _l1d_06eaf4("e499dcc3c6cdd198a0aeb10808baadbc11cacb", 53, 121), _l1d_06eaf4("8c", 29, 24))
m = _lI111II.match(_llI11II)
if m <> invalid and m.Count() >= 2 then return m[1]
return ""
end function
function HC_GetJson(_lll1lll as String, _l11llll = 8000 as Integer) as Object
if _lll1lll = invalid or _lll1lll = "" then return invalid
_l1l1lll = CreateObject(_l1d_06eaf4("c7c5aed0cdb8d9c9dbe1d9d9eb", 129, 212))
_l1l1lll.SetCertificatesFile(_l1d_06eaf4("aab1b2b5babef503c2bfb9b6be15d4d51cdecae8e1ece634f2e6e3", 245, 20))
_l1l1lll.AddHeader(_l1d_06eaf4("85bd91818081cca09a87a08c93a9abe7d1b5a5f3d2c0", 122, 99), "")
_l1l1lll.InitClientCertificates()
_l1l1lll.SetUrl(_lll1lll)
_l1l1lll.AddHeader(_l1d_06eaf4("8d728379d1b08d929c89", 119, 107), HC_DefaultUA())
_l1l1lll.AddHeader(_l1d_06eaf4("98bdc0bdd3d2", 140, 203), _l1d_06eaf4("ec0003f2f0f9fe16fc010547072110145960372931406842313732387d847d8383", 235, 98))
_l1l1lll.EnableEncodings(true)
_llIllll = CreateObject(_l1d_06eaf4("fff71cf70c0f0401063c122021", 38, 171))
_l1l1lll.SetMessagePort(_llIllll)
if not _l1l1lll.AsyncGetToString() then return invalid
_lIIllll = CreateObject(_l1d_06eaf4("b7bf97c7c6d1cacaded6", 28, 73))
_lIIllll.mark()
_ll1llll = invalid
while _lIIllll.totalMilliseconds() < _l11llll
_l1Illll = _l11llll - _lIIllll.totalMilliseconds()
if _l1Illll < 1 then exit while
_lI1llll = wait(_l1Illll, _llIllll)
if _lI1llll = invalid then exit while
if type(_lI1llll) = _l1d_06eaf4("63634c6c6945796b7780", 64, 49) then
if _lI1llll.getResponseCode() >= 200 and _lI1llll.getResponseCode() < 300 then
_ll1llll = _lI1llll.getString()
end if
exit while
end if
end while
if _ll1llll = invalid or _ll1llll = "" then
_l1l1lll.AsyncCancel()
return invalid
end if
return ParseJson(_ll1llll)
end function
function _l1d_06eaf4(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function