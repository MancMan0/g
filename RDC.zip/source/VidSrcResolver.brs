function VSR_Resolve(_ll1I1ll as String, _l11I1ll as String, _llII1ll = 1 as Integer, _lIlI1ll = 1 as Integer) as Object
if _ll1I1ll = invalid or _ll1I1ll = "" then return invalid
if _l11I1ll = invalid or _l11I1ll = "" then _l11I1ll = _l1d_007d69("dfe0dcecf3", 127, 205)
if _l11I1ll = _l1d_007d69("a3a8", 253, 26) then
_l1lI1ll = _l1d_007d69("ea01040b0bc7b5b81a010f1a1127ce1e2d311926212f2f33ec3a31f4413c4a4a4e0664650f", 175, 35) + _ll1I1ll + _l1d_007d69("0e", 112, 175) + _llII1ll.ToStr() + _l1d_007d69("3e", 11, 26) + _lIlI1ll.ToStr()
else
_l1lI1ll = _l1d_007d69("11303332326e646741303641404e7d455c60485550565e629b6160a3706b71797db57a7b977f8ec7", 235, 142) + _ll1I1ll
end if
_lllI1ll = {
embedUrl: _l1lI1ll,
refer: _l1d_007d69("6d84878e924e3c3f9d84929d94ae55a1b0b4a0a9a4b6b2b673c1b87b", 173, 168),
kind: _l11I1ll,
imdb: _ll1I1ll,
season: _llII1ll,
episode: _lIlI1ll
}
print _l1d_007d69("75737375857b91a2a1a1aea09b6198b9c3b6beba769ad1d3d1aad5cdd3d594dde9efa0", 128, 154); _ll1I1ll; _l1d_007d69("3e49", 149, 137); _l11I1ll; _l1d_007d69("a8", 71, 58)
_lI1I1ll = R_ResolveEmbed(_lllI1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("70767e807886786d747871879250b483858fbc97a3a5a76ea0a1b6b9baafb26c89", 190, 139); Left(_lI1I1ll.url, 60)
return _lI1I1ll
end if
if _l11I1ll = _l1d_007d69("4247", 201, 133) then
_lII11ll = _l1d_007d69("8a91949b9febd9dcb1a9a89fecaebeacf7b0bbbdb9bd09", 197, 221) + _ll1I1ll + _l1d_007d69("e9", 102, 160) + _llII1ll.ToStr() + _l1d_007d69("38", 66, 201) + _lIlI1ll.ToStr() + _l1d_007d69("9a", 127, 74)
else
_lII11ll = _l1d_007d69("161518171753696c1d2d34437c3e364c87544f555d6199", 251, 131) + _ll1I1ll + _l1d_007d69("9c", 113, 62)
end if
_lllI1ll.embedUrl = _lII11ll
_lllI1ll.refer = _l1d_007d69("c6dde0e7eda7979aeff5e4eba8ec0afab5", 172, 2)
print _l1d_007d69("ababa9adbbb3ab98b7bda6bad5fdd4b1bdd0d6d012f4dfc9e0edebdf2aeff9e136", 243, 3); _ll1I1ll
_lI1I1ll = R_ResolveEmbed(_lllI1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("8e8e8c909e96cebbdae0c9ddb8a0c2edd7eefbf9edb8e8f1fe010af7fac6d3", 147, 198); Left(_lI1I1ll.url, 60)
return _lI1I1ll
end if
_l1II1ll = HC_NewSession()
_lI1I1ll = VSR_ResolveVidSrcIn(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
HC_Close(_l1II1ll)
print _l1d_007d69("d4e4e2e6e4ece4d1e0e6dff3feb60bf3030ff3052208d1010a171a231013", 187, 244)
return _lI1I1ll
end if
_lI1I1ll = VSR_ResolveVidSrcCc(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
HC_Close(_l1II1ll)
print _l1d_007d69("d5dbe3e5ddebfd12f9fd160cf75502141a103226092c704243383b3c5154", 206, 64)
return _lI1I1ll
end if
_lI1I1ll = VSR_ResolveVidSrcXyz(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
HC_Close(_l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("84929294949a748170748d83aec4b98391bfa195c1a5a5e2b4bdaaadb6c3c6", 234, 211)
return _lI1I1ll
end if
print _l1d_007d69("cad2d8dcd2e212070e140d21ecec0e2629f836262d3246473941414319565e595963672e6b65653a", 159, 6); _ll1I1ll
return invalid
end function
function VSR_ResolveVidSrcCc(_lll1l1l as String, _l1l1l1l as String, _llI1l1l as Integer, _l1Ill1l as Integer, _lllIl1l as Object) as Object
_lIl1l1l = _l1d_007d69("d2c9ccd3d58f9fa2dceef4eaec00b60609", 30, 92)
_llIll1l = _lIl1l1l + _l1d_007d69("cb77b6d48d9892969ae6a7ac98acabf8", 209, 205) + _lll1l1l
if _l1l1l1l = _l1d_007d69("0a0b", 223, 95) then
_llIll1l = _lIl1l1l + _l1d_007d69("56803f5f9ca79ba5a7719d9e7a", 146, 153) + _lll1l1l + _l1d_007d69("04", 211, 8) + _llI1l1l.ToStr() + _l1d_007d69("03", 207, 35) + _l1Ill1l.ToStr()
_lII1l1l = _lIl1l1l + _l1d_007d69("1edbcde92ae3d9f5e2f9f1f542", 116, 195) + _lll1l1l + _l1d_007d69("64", 105, 30) + _llI1l1l.ToStr() + _l1d_007d69("2f", 195, 67) + _l1Ill1l.ToStr() + _l1d_007d69("a877647e7d6d8789", 197, 190)
else
_lII1l1l = _lIl1l1l + _l1d_007d69("bf081c06cb1828122b1a282ae3", 43, 187) + _lll1l1l + _l1d_007d69("c1687d6d7486767a", 240, 226)
end if
_lIIll1l = {
"Referer": _llIll1l,
"Origin": _lIl1l1l,
"Accept": _l1d_007d69("b2a4a7aeb6bfc4b2c2bfc185cbc7ced095a4d3e7d5dca6e6edfdf8f4b9c8c1c1c7", 30, 51),
"X-Requested-With": _l1d_007d69("9c949695949796bb91a0a79aabaf", 104, 108)
}
_l111l1l = HC_Get(_lllIl1l, _lII1l1l, _lIIll1l, 6000)
if _l111l1l = invalid or _l111l1l.body = "" then return invalid
_ll11l1l = ParseJson(_l111l1l.body)
if _ll11l1l = invalid or type(_ll11l1l) <> _l1d_007d69("a38b78adb097a69faab8a8c0b299cdd0c2cd", 12, 37) then return invalid
_l1I1l1l = invalid
if _ll11l1l.data <> invalid then _l1I1l1l = _ll11l1l.data
if (_l1I1l1l = invalid or type(_l1I1l1l) <> _l1d_007d69("8795ba9093a38e", 57, 60)) and _ll11l1l.servers <> invalid then _l1I1l1l = _ll11l1l.servers
if _l1I1l1l = invalid or type(_l1I1l1l) <> _l1d_007d69("d4f2cbdde0f4ef", 83, 179) or _l1I1l1l.Count() = 0 then return invalid
for each _ll1Il1l in _l1I1l1l
if type(_ll1Il1l) <> _l1d_007d69("d8e80de2e5f4fbf4fff5fdfd0f2e02051702", 120, 206) then continue for
_l11Il1l = ""
if _ll1Il1l.hash <> invalid then _l11Il1l = _ll1Il1l.hash
if _l11Il1l = "" and _ll1Il1l.data_id <> invalid then _l11Il1l = _ll1Il1l.data_id
if _l11Il1l = "" and _ll1Il1l.id <> invalid then _l11Il1l = _ll1Il1l.id
if _l11Il1l = "" then continue for
_l1lIl1l = _lIl1l1l + _l1d_007d69("e6a3b5b1f2c1b8c1c9bdba07", 196, 251) + _l11Il1l
_lIlIl1l = HC_Get(_lllIl1l, _l1lIl1l, _lIIll1l, 6000)
if _lIlIl1l = invalid or _lIlIl1l.body = "" then continue for
_lI11l1l = ParseJson(_lIlIl1l.body)
if _lI11l1l = invalid or type(_lI11l1l) <> _l1d_007d69("afbda6b7bac9d0cdd8d0d6d4e8c7d9dcf0db", 155, 198) then continue for
_lI1Il1l = ""
if _lI11l1l.data <> invalid and type(_lI11l1l.data) = _l1d_007d69("a9c99eb3b6d5ccd5d0c6decee0bfd3d6e8e3", 144, 199) and _lI11l1l.data.stream <> invalid then
if type(_lI11l1l.data.stream) = _l1d_007d69("4b73706e726e", 66, 58) or type(_lI11l1l.data.stream) = _l1d_007d69("45556c50515b636f", 120, 59) then
_lI1Il1l = _lI11l1l.data.stream
end if
end if
if _lI1Il1l = "" and _lI11l1l.stream <> invalid and (type(_lI11l1l.stream) = _l1d_007d69("b39b98a6aab6", 122, 138) or type(_lI11l1l.stream) = _l1d_007d69("657d4c6c718f8b87", 150, 129)) then
_lI1Il1l = _lI11l1l.stream
end if
if _lI1Il1l <> "" then
_l1IIl1l = []
if _lI11l1l.data <> invalid and _lI11l1l.data.subtitles <> invalid and type(_lI11l1l.data.subtitles) = _l1d_007d69("1a385123263a35", 243, 153) then
for each _llIIl1l in _lI11l1l.data.subtitles
if _llIIl1l.file <> invalid and _llIIl1l.file <> "" then
_l1IIl1l.Push({
url: _llIIl1l.file,
label: _llIIl1l.label,
language: _llIIl1l.language
})
end if
end for
end if
return {
url: _lI1Il1l,
streamFormat: U_StreamFormat(_lI1Il1l),
subtitles: _l1IIl1l,
referer: _llIll1l,
userAgent: _lllIl1l.userAgent
}
end if
end for
return invalid
end function
function VSR_ResolveVidSrcIn(_lIII11l as String, _llllI1l as String, _lI1lI1l as Integer, _l1II11l as Integer, _llIlI1l as Object) as Object
_llII11l = _l1d_007d69("f5f4f7f6fa364c4f0b0f1f0f132565212b6d36313b3f437f404541455491", 249, 100) + _lIII11l
if _llllI1l = _l1d_007d69("787d", 237, 223) then
_llII11l = _l1d_007d69("c4cbced5d7a19194dee0d6eceee2a8f2eeb2effaf6f8fac41011cd", 38, 118) + _lIII11l + _l1d_007d69("8a", 48, 107) + _lI1lI1l.ToStr() + _l1d_007d69("6c", 172, 233) + _l1II11l.ToStr()
end if
_lIllI1l = HC_Get(_llIlI1l, _llII11l, { "Referer": _l1d_007d69("233a3d444400eef14d3d45595d4f074f4d0f", 175, 92) }, 7000)
if _lIllI1l = invalid or _lIllI1l.body = "" then return invalid
_ll1lI1l = CreateObject(_l1d_007d69("eaf210fe0304f2", 252, 92), _l1d_007d69("d321231222312c050df010012c3042ff20", 145, 38) + chr(34) + _l1d_007d69("ec35eb413f", 60, 209) + chr(34) + _l1d_007d69("743d6e6f44", 249, 150) + chr(34) + _l1d_007d69("44a1", 51, 48), _l1d_007d69("32", 179, 88))
m = _ll1lI1l.match(_lIllI1l.body)
if m <> invalid and m.Count() >= 2 then
_lI1I11l = U_AbsUrl(m[1], _l1d_007d69("93a2a5a4a4f0e6e9b5adadb9bdafffbfc507", 227, 8))
_l11I11l = HC_Get(_llIlI1l, _lI1I11l, { "Referer": _llII11l }, 7000)
if _l11I11l <> invalid and _l11I11l.body <> "" then
_l11lI1l = CreateObject(_l1d_007d69("b8b09eb0b1b6d4", 70, 132), _l1d_007d69("edb0cfd2d1d110100609b8c0c5e9", 203, 10) + chr(34) + _l1d_007d69("70498250854576338367676848", 245, 158) + chr(34) + _l1d_007d69("3a134d4d", 245, 104), _l1d_007d69("65", 135, 119))
_l1llI1l = _l11lI1l.match(_l11I11l.body)
if _l1llI1l <> invalid and _l1llI1l.Count() >= 2 then
return {
url: _l1llI1l[1],
streamFormat: _l1d_007d69("0e0d1b", 6, 160),
subtitles: [],
referer: _lI1I11l,
userAgent: _llIlI1l.userAgent
}
end if
end if
end if
return invalid
end function
function VSR_ResolveVidSrcXyz(_l111lIl as String, _lI11lIl as String, _lII1lIl as Integer, _ll11lIl as Integer, _lllIlIl as Object) as Object
if ((16849 - 2407 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lIl1lIl = _l1d_007d69("7980838a8edac8cb97938ba3a799e1b6b8beeca5b0b2aeb2febfc4d0ccc320d5d4d0d92d", 69, 76) + _l111lIl
if _lI11lIl = _l1d_007d69("ff00", 178, 57) then
_lIl1lIl = _l1d_007d69("97a6a9a8aef8f0f3bdb3b1c3c5b907d4d8dc14cdd8d0d6d826eef33fecf3edee4c", 224, 15) + _l111lIl + _l1d_007d69("1cf4e1e8fde4e638", 76, 178) + _lII1lIl.ToStr() + _l1d_007d69("c080708a77969092cd", 113, 105) + _ll11lIl.ToStr()
end if
_llI1lIl = HC_Get(_lllIlIl, _lIl1lIl, { "Referer": _l1d_007d69("07fe01080ac4d4d71123291f2135eb242828f8", 62, 177) }, 7000)
if _llI1lIl = invalid or _llI1lIl.body = "" then return invalid
_l1I1lIl = CreateObject(_l1d_007d69("332919252a2b4b", 197, 124), _l1d_007d69("773a393c3b41807e9699282e2f59", 216, 135) + chr(34) + _l1d_007d69("8c29962e9f658a53993b41465c", 82, 23) + chr(34) + _l1d_007d69("461f5151", 113, 240), _l1d_007d69("17", 152, 38))
m = _l1I1lIl.match(_llI1lIl.body)
if m <> invalid and m.Count() >= 2 then
return {
url: m[1],
streamFormat: _l1d_007d69("282717", 53, 203),
subtitles: [],
referer: _lIl1lIl,
userAgent: _lllIlIl.userAgent
}
end if
return invalid
end function
function _l1d_007d69(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function