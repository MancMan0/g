function TMDB_BuildKey() as String
if ((44442 - 7407 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return ""
end function
function TMDB_Key() as String
_llIll1l = U_PrefDefault(_l1d_9f1519("5f6b75724e7f66", 154, 113), "")
if _llIll1l <> invalid and _llIll1l <> "" then return _llIll1l
return TMDB_BuildKey()
end function
function TMDB_Enabled() as Boolean
return TMDB_Key() <> ""
end function
function TMDB_Image(_lIl1lIl as String, _ll11lIl as String) as String
if ((40455 - 4495 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lIl1lIl = invalid or _lIl1lIl = "" then return ""
if _ll11lIl = "" then _ll11lIl = _l1d_9f1519("83444447", 49, 61)
if Left(_lIl1lIl, 4) = _l1d_9f1519("eae9eceb", 187, 23) then return _lIl1lIl
return _l1d_9f1519("3f5e6160629c9497585f666b70a885717b78b77b9189c4a0caa2d0", 202, 157) + _ll11lIl + _lIl1lIl
end function
function TMDB_IsNumeric(_l1llIIl as Dynamic) as Boolean
if _l1llIIl = invalid then return false
_lIllIIl = ""
if Type(_l1llIIl) = _l1d_9f1519("4b35321e242e", 171, 83) or Type(_l1llIIl) = _l1d_9f1519("3e5665454a686460", 54, 250) then
_lIllIIl = _l1llIIl
else
return false
end if
if _lIllIIl = "" then return false
_llllIIl = CreateObject(_l1d_9f1519("78885e94999a80", 24, 14), _l1d_9f1519("9da2adfbf3", 198, 5), "")
return _llllIIl.isMatch(_lIllIIl)
end function
function TMDB_FmtRating(_l1lIll1 as Dynamic) as String
if ((22631 - 3233 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _l1lIll1 = invalid then return ""
_lII1ll1 = 0.0
_lII1ll1 = _l1lIll1
if _lII1ll1 <= 0 then return ""
_lllIll1 = Int(_lII1ll1 * 10 + 0.5)
_lIlIll1 = _lllIll1 \ 10
_l1I1ll1 = _lllIll1 mod 10
return _lIlIll1.ToStr() + _l1d_9f1519("6f", 218, 123) + _l1I1ll1.ToStr()
end function
function TMDB_FindId(_lll1Il1 as String, _lIl1Il1 as String, _l1IlIl1 as String) as String
if ((8520 - 2840 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if not TMDB_Enabled() then return ""
if _lll1Il1 = invalid or _lll1Il1 = "" then return ""
_lIIlIl1 = _l1d_9f1519("0b0c28181f", 207, 105)
if _l1IlIl1 = _l1d_9f1519("2f30", 158, 69) then _lIIlIl1 = _l1d_9f1519("757a", 48, 49)
_l1l1Il1 = _l1d_9f1519("a6a5a8a7ade7ff02c7b9c50dc6cdddd8ddd7ddeceeef2ef2e8003b3241f80d0c00140c56", 248, 22) + _lIIlIl1 + _l1d_9f1519("835c505a2f5e6f569d", 219, 159) + TMDB_Key() + _l1d_9f1519("9e70776a7684cb", 66, 58) + U_UrlEncode(_lll1Il1)
if _lIl1Il1 <> invalid and _lIl1Il1 <> "" then
if _l1IlIl1 = _l1d_9f1519("9297", 140, 154) then
_l1l1Il1 = _l1l1Il1 + _l1d_9f1519("470a0a040608e0211c16ec2a302032fb243b42346c", 95, 206) + _lIl1Il1
else
_l1l1Il1 = _l1l1Il1 + _l1d_9f1519("3bfffefd134f", 201, 76) + _lIl1Il1
end if
end if
_lI1lIl1 = HA_GetJson(_l1l1Il1)
if _lI1lIl1 = invalid or _lI1lIl1.results = invalid then return ""
if _lI1lIl1.results.Count() = 0 then return ""
_llIlIl1 = _lI1lIl1.results[0]
if _llIlIl1.id = invalid then return ""
return _llIlIl1.id.ToStr()
end function
function TMDB_Enrich(_llll111 as Object) as Object
if _llll111 = invalid then return _llll111
if not TMDB_Enabled() then return _llll111
_ll1l111 = ""
if _llll111.tmdb <> invalid then _ll1l111 = _llll111.tmdb.ToStr()
if not TMDB_IsNumeric(_ll1l111) then
_ll1l111 = TMDB_FindId(_llll111.title, _llll111.year, _llll111.kind)
end if
if not TMDB_IsNumeric(_ll1l111) then return _llll111
_l1ll111 = _l1d_9f1519("0809230d1c", 202, 97)
if _llll111.kind = _l1d_9f1519("7b7c", 127, 112) then _l1ll111 = _l1d_9f1519("b6bb", 221, 13)
_l11l111 = _l1d_9f1519("354447464612080b44585218655c5a6566726a696d6a397b8379444b4a", 163, 106) + _l1ll111 + _l1d_9f1519("db", 33, 205) + _ll1l111 + _l1d_9f1519("a6fbeff9d2010ef5bc", 25, 128) + TMDB_Key() + _l1d_9f1519("e1293d402e38356d4b437656465b61555967583360746468767e82327f7d837d9289868b66919b5fcacf", 167, 96)
_lI1Il11 = HA_GetJson(_l11l111)
if _lI1Il11 = invalid then return _llll111
_llll111.tmdb = _ll1l111
if _lI1Il11.overview <> invalid and _lI1Il11.overview <> "" then _llll111.description = _lI1Il11.overview
if _lI1Il11.backdrop_path <> invalid and _lI1Il11.backdrop_path <> "" then _llll111.backdrop = TMDB_Image(_lI1Il11.backdrop_path, _l1d_9f1519("66a3a9a2ad", 73, 40))
if (_llll111.poster = "" or _llll111.poster = invalid) and _lI1Il11.poster_path <> invalid then _llll111.poster = TMDB_Image(_lI1Il11.poster_path, _l1d_9f1519("ee33393c", 94, 197))
_lIll111 = TMDB_FmtRating(_lI1Il11.vote_average)
if _lIll111 <> "" then _llll111.rating = _lIll111
if _llll111.kind = _l1d_9f1519("a0a1", 35, 73) then
if _lI1Il11.episode_run_time <> invalid and Type(_lI1Il11.episode_run_time) = _l1d_9f1519("9c9273a5a89cb7", 135, 167) and _lI1Il11.episode_run_time.Count() > 0 then
_llll111.runtime = _lI1Il11.episode_run_time[0].ToStr() + _l1d_9f1519("03cbd2ce", 214, 13)
end if
if _lI1Il11.first_air_date <> invalid and Len(_lI1Il11.first_air_date) >= 4 then _llll111.year = Left(_lI1Il11.first_air_date, 4)
else
if _lI1Il11.runtime <> invalid and _lI1Il11.runtime > 0 then _llll111.runtime = _lI1Il11.runtime.ToStr() + _l1d_9f1519("a05e5d63", 107, 85)
if _lI1Il11.release_date <> invalid and Len(_lI1Il11.release_date) >= 4 then _llll111.year = Left(_lI1Il11.release_date, 4)
end if
if _lI1Il11.genres <> invalid and _lI1Il11.genres.Count() > 0 then
_l1IIl11 = []
for each _lIIIl11 in _lI1Il11.genres
if _lIIIl11.name <> invalid then _l1IIl11.Push(_lIIIl11.name)
end for
if _l1IIl11.Count() > 0 then _llll111.genres = _l1IIl11
end if
if _lI1Il11.credits <> invalid and _lI1Il11.credits.cast <> invalid and _lI1Il11.credits.cast.Count() > 0 then
_l11Il11 = []
for each _ll1Il11 in _lI1Il11.credits.cast
_llIIl11 = { id: "", name: "", character: "", photo: "" }
if _ll1Il11.id <> invalid then _llIIl11.id = _ll1Il11.id.ToStr()
if _ll1Il11.name <> invalid then _llIIl11.name = _ll1Il11.name
if _ll1Il11.character <> invalid then _llIIl11.character = _ll1Il11.character
if _ll1Il11.profile_path <> invalid and _ll1Il11.profile_path <> "" then _llIIl11.photo = TMDB_Image(_ll1Il11.profile_path, _l1d_9f1519("aff802fa", 230, 30))
_l11Il11.Push(_llIIl11)
if _l11Il11.Count() >= 18 then exit for
end for
if _l11Il11.Count() > 0 then _llll111.cast = _l11Il11
end if
return _llll111
end function
function _l1d_9f1519(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function