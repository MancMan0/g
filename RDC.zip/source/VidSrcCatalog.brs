function VSC_Base() as String
if ((20007 - 6669 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return _l1d_8ce772("88878a898dc9dfe29edce9b2abb5bdb8c3b7c507bdc3c4d8d319d5de", 217, 215)
end function
function VSC_NormalizeItem(_lI11l1l as Object, _l1Ill1l = _l1d_8ce772("dfe4d0ece3", 149, 231) as String) as Object
if ((11256 - 3752 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lI11l1l = invalid then return invalid
_l1l1l1l = ""
if _lI11l1l.imdb_id <> invalid then _l1l1l1l = _lI11l1l.imdb_id
if _l1l1l1l = "" and _lI11l1l.id <> invalid then _l1l1l1l = _lI11l1l.id
_lIl1l1l = _l1Ill1l
if _lI11l1l.type <> invalid and _lI11l1l.type = _l1d_8ce772("b3c8bac2d1c2", 25, 73) then _lIl1l1l = _l1d_8ce772("afb4", 96, 155)
_llI1l1l = ""
if _lI11l1l.name <> invalid then _llI1l1l = _lI11l1l.name
if _llI1l1l = "" and _lI11l1l.title <> invalid then _llI1l1l = _lI11l1l.title
_l1I1l1l = ""
if _lI11l1l.year <> invalid then _l1I1l1l = _lI11l1l.year.ToStr()
if _l1I1l1l = "" and _lI11l1l.releaseInfo <> invalid then _l1I1l1l = _lI11l1l.releaseInfo
_ll11l1l = ""
if _lI11l1l.poster <> invalid then _ll11l1l = _lI11l1l.poster
if _ll11l1l = "" then _ll11l1l = _l1d_8ce772("e1fbfab0c80910070c11fedd05241c1d262c323631352100294642", 178, 31)
_llIll1l = ""
if _lI11l1l.background <> invalid then _llIll1l = _lI11l1l.background
if _llIll1l = "" then _llIll1l = _ll11l1l
_lIIll1l = ""
if _lI11l1l.description <> invalid then _lIIll1l = _lI11l1l.description
_l111l1l = _l1d_8ce772("1b2516", 186, 142)
if _lI11l1l.imdbRating <> invalid and _lI11l1l.imdbRating <> "" then _l111l1l = _lI11l1l.imdbRating.ToStr()
_lll1l1l = []
if _lI11l1l.genres <> invalid and type(_lI11l1l.genres) = _l1d_8ce772("cac8ddd3d6c6e1", 97, 183) then _lll1l1l = _lI11l1l.genres
return {
id: _l1l1l1l,
imdb: _l1l1l1l,
tmdb: "",
kind: _lIl1l1l,
title: _llI1l1l,
year: _l1I1l1l,
poster: _ll11l1l,
backdrop: _llIll1l,
description: _lIIll1l,
rating: _l111l1l,
genres: _lll1l1l
}
end function
function VSC_FetchTrendingMovies() as Object
if ((17886 - 5962 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lIII11l = VSC_Base() + _l1d_8ce772("8bcacbbbd1d9ddd8a3e4e9d5f1e8b5dffbe9c209f30a0e", 181, 241)
_l11I11l = HC_GetJson(_lIII11l, 8000)
_l1II11l = []
if _l11I11l <> invalid and _l11I11l.metas <> invalid and type(_l11I11l.metas) = _l1d_8ce772("f6f4cdff02f611", 131, 5) then
for each _llII11l in _l11I11l.metas
_lI1I11l = VSC_NormalizeItem(_llII11l, _l1d_8ce772("a1a28eaea5", 247, 7))
if _lI1I11l <> invalid and _lI1I11l.id <> "" then _l1II11l.Push(_lI1I11l)
end for
end if
return _l1II11l
end function
function VSC_FetchTrendingSeries() as Object
_llI1lIl = VSC_Base() + _l1d_8ce772("8f565b536161616ca75e776571806dbc7a827cc988829195", 123, 59)
_lIl1lIl = HC_GetJson(_llI1lIl, 8000)
_l111lIl = []
if _lIl1lIl <> invalid and _lIl1lIl.metas <> invalid and type(_lIl1lIl.metas) = _l1d_8ce772("93a9c69c9fafaa", 181, 204) then
for each _lI11lIl in _lIl1lIl.metas
_ll11lIl = VSC_NormalizeItem(_lI11lIl, _l1d_8ce772("f7fc", 96, 227))
if _ll11lIl <> invalid and _ll11lIl.id <> "" then _l111lIl.Push(_ll11lIl)
end for
end if
return _l111lIl
end function
function VSC_FetchByGenre(_l11lIIl as String, _l1llIIl as String) as Object
_ll1lIIl = _l11lIIl
if _ll1lIIl = _l1d_8ce772("1011", 66, 218) then _ll1lIIl = _l1d_8ce772("8e83958d8c9d", 193, 220)
_l1IlIIl = VSC_Base() + _l1d_8ce772("3c8388808e8e8e9954", 27, 8) + _ll1lIIl + _l1d_8ce772("6b39313b7732374148409b", 99, 31) + U_UrlEncode(_l1llIIl) + _l1d_8ce772("d817132224", 152, 34)
_llllIIl = HC_GetJson(_l1IlIIl, 7000)
_llIlIIl = []
if _llllIIl <> invalid and _llllIIl.metas <> invalid and type(_llllIIl.metas) = _l1d_8ce772("3654293f42524d", 17, 211) then
for each _lI1lIIl in _llllIIl.metas
_lIllIIl = VSC_NormalizeItem(_lI1lIIl, _l11lIIl)
if _lIllIIl <> invalid and _lIllIIl.id <> "" then _llIlIIl.Push(_lIllIIl)
end for
end if
return _llIlIIl
end function
function VSC_FetchHomeRows() as Object
_lIlIll1 = VSC_FetchTrendingMovies()
_lI1Ill1 = VSC_FetchTrendingSeries()
_ll1Ill1 = []
if _lIlIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("6f94a69eababa7b37b93b4aec0c7bc", 158, 165),
items: _lIlIll1
})
end if
if _lI1Ill1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("76745c647e7666bb9293c49692988382", 242, 212),
items: _lI1Ill1
})
end if
_l11Ill1 = VSC_FetchByGenre(_l1d_8ce772("e4e903f1f8", 140, 3), _l1d_8ce772("cdc0b978e6c2", 189, 223))
if _l11Ill1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("273a33f2203c08090e325b59556f204e5c607a6a848673", 13, 201),
items: _l11Ill1
})
end if
_l1I1ll1 = VSC_FetchByGenre(_l1d_8ce772("858aa48a99", 40, 64), _l1d_8ce772("c9aec2aab3b5", 104, 160))
if _l1I1ll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("42233b33383af3f8f95d43544a525f635f59", 34, 223),
items: _l1I1ll1
})
end if
_lllIll1 = VSC_FetchByGenre(_l1d_8ce772("9499a5a198", 197, 236), _l1d_8ce772("72898a9599a7", 77, 100))
if _lllIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("3b2a2b262a406c57394949", 97, 25),
items: _lllIll1
})
end if
_l1lIll1 = VSC_FetchByGenre(_l1d_8ce772("72737f7776", 3, 4), _l1d_8ce772("9fc9afb2d2b8", 144, 199))
if _l1lIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("10f6fcffff053a3f40370e17151b1e1a262a", 226, 102),
items: _l1lIll1
})
end if
_lII1ll1 = VSC_FetchByGenre(_l1d_8ce772("686d896d7c", 9, 4), _l1d_8ce772("cbada9b0b7afb5bec2", 57, 83))
if _lII1ll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("12f800fffeee0c090dcecbd4361c24231e", 183, 28),
items: _lII1ll1
})
end if
return _ll1Ill1
end function
function VSC_Search(_lIl1Il1 as String) as Object
if ((12524 - 3131 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1l1Il1 = []
if _lIl1Il1 = invalid or _lIl1Il1 = "" then return _l1l1Il1
_lI1lIl1 = U_UrlEncode(_lIl1Il1)
_lll1Il1 = VSC_Base() + _l1d_8ce772("81d0d5c5dbd3d3de99dedfdbebf2abe9f1f3b7f6070e001210be", 191, 241) + _lI1lIl1 + _l1d_8ce772("c1809c8b8d", 74, 93)
_l111Il1 = VSC_Base() + _l1d_8ce772("e3aaabc3b1b1b5c0fbd2c7d9c1d0e110ead6ec1cf3e8e7fdefe93f", 233, 29) + _lI1lIl1 + _l1d_8ce772("e4230f2e30", 146, 40)
_lIIlIl1 = HC_GetJson(_lll1Il1, 6000)
_ll11Il1 = HC_GetJson(_l111Il1, 6000)
if _lIIlIl1 <> invalid and _lIIlIl1.metas <> invalid then
for each _llIlIl1 in _lIIlIl1.metas
_l1IlIl1 = VSC_NormalizeItem(_llIlIl1, _l1d_8ce772("454a565249", 37, 253))
if _l1IlIl1 <> invalid then _l1l1Il1.Push(_l1IlIl1)
end for
end if
if _ll11Il1 <> invalid and _ll11Il1.metas <> invalid then
for each _llIlIl1 in _ll11Il1.metas
_l1IlIl1 = VSC_NormalizeItem(_llIlIl1, _l1d_8ce772("f0f5", 193, 59))
if _l1IlIl1 <> invalid then _l1l1Il1.Push(_l1IlIl1)
end for
end if
return _l1l1Il1
end function
function VSC_FetchSeriesDetails(_l1ll111 as String) as Object
_l1l1111 = VSC_Base() + _l1d_8ce772("63283325357229422e3c4b3887", 90, 238) + _l1ll111 + _l1d_8ce772("c9102c1315", 172, 71)
_l11Il11 = HC_GetJson(_l1l1111, 8000)
_llIl111 = []
if _l11Il11 = invalid or _l11Il11.meta = invalid or _l11Il11.meta.videos = invalid then return _llIl111
_ll11111 = _l11Il11.meta.videos
_ll1Il11 = {}
for each _lIl1111 in _ll11111
_lI1l111 = 1
if _lIl1111.season <> invalid then _lI1l111 = _lIl1111.season
_llIIl11 = 1
if _lIl1111.number <> invalid then _llIIl11 = _lIl1111.number else if _lIl1111.episode <> invalid then _llIIl11 = _lIl1111.episode
_lIIIl11 = _l1d_8ce772("8fbfa9c6b5bfc101", 73, 131) + _llIIl11.ToStr()
if _lIl1111.name <> invalid and _lIl1111.name <> "" then _lIIIl11 = _lIl1111.name else if _lIl1111.title <> invalid and _lIl1111.title <> "" then _lIIIl11 = _lIl1111.title
_lIIl111 = ""
if _lIl1111.thumbnail <> invalid then _lIIl111 = _lIl1111.thumbnail
_lI1Il11 = ""
if _lIl1111.overview <> invalid then _lI1Il11 = _lIl1111.overview else if _lIl1111.description <> invalid then _lI1Il11 = _lIl1111.description
_l11l111 = _l1d_8ce772("b7", 26, 78) + _lI1l111.ToStr()
if not _ll1Il11.DoesExist(_l11l111) then _ll1Il11[_l11l111] = []
_ll1Il11[_l11l111].Push({
season: _lI1l111,
episode: _llIIl11,
title: _lIIIl11,
thumbnail: _lIIl111,
description: _lI1Il11
})
end for
for each _ll1l111 in _ll1Il11
_l1Il111 = Mid(_ll1l111, 2).ToInt()
_l1IIl11 = _ll1Il11[_ll1l111]
_llIl111.Push({
number: _l1Il111,
label: _l1d_8ce772("3b6c73647b7d3e", 150, 118) + _l1Il111.ToStr(),
episodes: _l1IIl11
})
end for
for _llll111 = 1 to _llIl111.Count() - 1
_lIll111 = _llll111
while _lIll111 > 0 and _llIl111[_lIll111].number < _llIl111[_lIll111 - 1].number
_lll1111 = _llIl111[_lIll111]
_llIl111[_lIll111] = _llIl111[_lIll111 - 1]
_llIl111[_lIll111 - 1] = _lll1111
_lIll111 = _lIll111 - 1
end while
end for
return _llIl111
end function
function VSC_FetchTitleMeta(_lI11I11 as String, _llI1I11 as String) as Object
if ((62752 - 7844 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lI11I11 = invalid or _lI11I11 = "" then return invalid
_lIlII11 = _l1d_8ce772("71725c7675", 50, 18)
if _llI1I11 = _l1d_8ce772("4748", 254, 189) or _llI1I11 = _l1d_8ce772("ddf2e4fcfbec", 17, 123) then _lIlII11 = _l1d_8ce772("3e33453d3c4d", 65, 12)
_ll1II11 = VSC_Base() + _l1d_8ce772("d59a95899fe4", 247, 253) + _lIlII11 + _l1d_8ce772("d3", 47, 211) + _lI11I11 + _l1d_8ce772("f6b5cfbec2", 201, 15)
_ll11I11 = HC_GetJson(_ll1II11, 6000)
if _ll11I11 <> invalid and _ll11I11.meta <> invalid then
_l1I1I11 = _ll11I11.meta
_l1lII11 = ""
if _l1I1I11.name <> invalid and _l1I1I11.name <> "" then
_l1lII11 = _l1I1I11.name
else if _l1I1I11.title <> invalid and _l1I1I11.title <> "" then
_l1lII11 = _l1I1I11.title
end if
_lII1I11 = ""
if _l1I1I11.poster <> invalid and _l1I1I11.poster <> "" then
_lII1I11 = _l1I1I11.poster
else if Left(_lI11I11, 2) = _l1d_8ce772("878a", 73, 74) then
_lII1I11 = _l1d_8ce772("51404342440e26296a71686d725f3d837e70808a7a86557d8195969f6890ae959db19d7da4c5bccacd8f", 50, 247) + _lI11I11 + _l1d_8ce772("c7908f98", 238, 6)
end if
_lIl1I11 = ""
if _l1I1I11.background <> invalid and _l1I1I11.background <> "" then
_lIl1I11 = _l1I1I11.background
else
_lIl1I11 = _lII1I11
end if
_lI1II11 = ""
if _l1I1I11.year <> invalid then _lI1II11 = _l1I1I11.year.ToStr()
_lllII11 = _l1d_8ce772("9591aa", 167, 5)
if _l1I1I11.imdbRating <> invalid and _l1I1I11.imdbRating <> "" then _lllII11 = _l1I1I11.imdbRating.ToStr()
return {
title: _l1lII11,
poster: _lII1I11,
backdrop: _lIl1I11,
year: _lI1II11,
rating: _lllII11,
description: _l1I1I11.description
}
end if
_l1l1I11 = _l1d_8ce772("213a28344330", 123, 25)
if _lIlII11 = _l1d_8ce772("daebe1fdf4e9", 247, 86) then _l1l1I11 = _l1d_8ce772("8186728e85", 213, 201)
_l11II11 = VSC_Base() + _l1d_8ce772("975c574959a6", 82, 26) + _l1l1I11 + _l1d_8ce772("6a", 139, 198) + _lI11I11 + _l1d_8ce772("e027232a2c", 30, 176)
_l111I11 = HC_GetJson(_l11II11, 4000)
if _l111I11 <> invalid and _l111I11.meta <> invalid then
_l1I1I11 = _l111I11.meta
_l1lII11 = ""
if _l1I1I11.name <> invalid and _l1I1I11.name <> "" then
_l1lII11 = _l1I1I11.name
else if _l1I1I11.title <> invalid and _l1I1I11.title <> "" then
_l1lII11 = _l1I1I11.title
end if
_lII1I11 = ""
if _l1I1I11.poster <> invalid and _l1I1I11.poster <> "" then
_lII1I11 = _l1I1I11.poster
else if Left(_lI11I11, 2) = _l1d_8ce772("7073", 208, 204) then
_lII1I11 = _l1d_8ce772("bad1d4dbdd17070ad3d2e1dee3f81ee4ef01f9f30bff36161a0e0f1049290f2e2e22365e3d26352b2e70", 238, 52) + _lI11I11 + _l1d_8ce772("793a413a", 211, 125)
end if
_lIl1I11 = ""
if _l1I1I11.background <> invalid and _l1I1I11.background <> "" then _lIl1I11 = _l1I1I11.background else _lIl1I11 = _lII1I11
_lI1II11 = ""
if _l1I1I11.year <> invalid then _lI1II11 = _l1I1I11.year.ToStr()
_lllII11 = _l1d_8ce772("ede7f4", 64, 118)
if _l1I1I11.imdbRating <> invalid and _l1I1I11.imdbRating <> "" then _lllII11 = _l1I1I11.imdbRating.ToStr()
return {
title: _l1lII11,
poster: _lII1I11,
backdrop: _lIl1I11,
year: _lI1II11,
rating: _lllII11,
description: _l1I1I11.description
}
end if
return invalid
end function
function _l1d_8ce772(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function