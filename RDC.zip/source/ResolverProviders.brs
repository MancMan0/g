function RP_ResolveGeneric(_lII11ll as String, _lIII1ll as String, _llllIll as Object) as Object
_lIlI1ll = {}
if _lIII1ll <> "" then _lIlI1ll[_l1d_55a757("7e58585e6a6470", 234, 198)] = _lIII1ll
_l1II1ll = HC_Get(_llllIll, _lII11ll, _lIlI1ll, 8000)
if _l1II1ll = invalid or _l1II1ll.body = "" then return invalid
_l11I1ll = _l1II1ll.body
_lllI1ll = _l1II1ll.finalUrl
if _lllI1ll = invalid or _lllI1ll = "" then _lllI1ll = _lII11ll
_ll1I1ll = CreateObject(_l1d_55a757("dde303eff4f5e5", 189, 14), _l1d_55a757("03465558575928261e219096", 162, 121) + chr(34) + _l1d_55a757("5d797c7f9d63897e8e7fc572b381a3a1", 150, 172) + chr(34) + _l1d_55a757("ac181b1e04c228b4ba", 170, 31), _l1d_55a757("6d", 81, 53))
_l1lI1ll = _ll1I1ll.match(_l11I1ll)
if _l1lI1ll <> invalid and _l1lI1ll.Count() >= 2 then
return {
url: _l1lI1ll[1]
streamFormat: _l1d_55a757("777676", 189, 162)
qualities: []
subtitles: RP_ExtractSubs(_l11I1ll)
chapters: []
referer: _lIII1ll
userAgent: ""
}
end if
_llII1ll = CreateObject(_l1d_55a757("dbfb01fbfc01f7", 50, 155), _l1d_55a757("76b9d0d3dade959d8b8ec5c5", 13, 81) + chr(34) + _l1d_55a757("6735383b1f5f43704a7b3f377e525a", 251, 139) + chr(34) + _l1d_55a757("7ad2d5d8b280e29294", 48, 99), _l1d_55a757("86", 89, 86))
_lI1I1ll = _llII1ll.match(_l11I1ll)
if _lI1I1ll <> invalid and _lI1I1ll.Count() >= 2 then
return {
url: _lI1I1ll[1]
streamFormat: _l1d_55a757("f2eab1", 153, 254)
qualities: []
subtitles: RP_ExtractSubs(_l11I1ll)
chapters: []
referer: _lIII1ll
userAgent: ""
}
end if
return invalid
end function
function RP_ExtractSubs(_llIll1l as String) as Object
if ((30312 - 7578 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_ll11l1l = []
if _llIll1l = invalid or _llIll1l = "" then return _ll11l1l
_l111l1l = CreateObject(_l1d_55a757("2a381048494e36", 91, 1), _l1d_55a757("32f50c0f16184f554548fffd", 78, 204) + chr(34) + _l1d_55a757("08a2a5a8c810b029b72c312129e0e1e4efeff3f04e51", 213, 22), _l1d_55a757("cbdc", 57, 123))
_l1l1l1l = _l111l1l.matchAll(_llIll1l)
if _l1l1l1l = invalid then return _ll11l1l
for each _lIl1l1l in _l1l1l1l
if _lIl1l1l.Count() < 2 then continue for
_lI11l1l = _lIl1l1l[1]
_l1Ill1l = _l1d_55a757("f3eb", 190, 24)
_lIIll1l = CreateObject(_l1d_55a757("868c6c9c9da292", 95, 89), _l1d_55a757("84db8ee396e496b3f2bea8c50fd100b1080abe13c6", 202, 243), _l1d_55a757("1a", 53, 190))
_lll1l1l = _lIIll1l.match(_lI11l1l)
if _lll1l1l <> invalid and _lll1l1l.Count() >= 2 then _l1Ill1l = LCase(_lll1l1l[1])
_ll11l1l.Push({ url: _lI11l1l, language: _l1Ill1l, name: UCase(_l1Ill1l) })
end for
return _ll11l1l
end function
function RP_ResolveVidsrcCc(_l1II11l as String, _l1IlI1l as String, _lI11I1l as Object) as Object
_l11lI1l = CreateObject(_l1d_55a757("3333193334394f", 66, 3), _l1d_55a757("c6d0bcc48bd2d8e1ceaba6b4b4b8f0fab8b9b5c5ccb8c3c414111beae521d3dee1fcf733383c28303e4817124e53505a292460656855", 255, 246), _l1d_55a757("15", 35, 203))
m = _l11lI1l.match(_l1II11l)
if m = invalid or m.Count() < 3 then return invalid
_llllI1l = m[1]
_lI1I11l = m[2]
_lIl1I1l = ""
_lIII11l = ""
if m.Count() >= 5 then
_lIl1I1l = m[3]
_lIII11l = m[4]
end if
_ll1lI1l = HC_OriginOf(_l1II11l)
if _ll1lI1l = "" then return invalid
if _llllI1l = _l1d_55a757("7475", 166, 162) and _lIl1I1l <> "" and _lIII11l <> "" then
_l111I1l = _ll1lI1l + _l1d_55a757("013e324c0d463e58455c565825", 53, 231) + _lI1I11l + _l1d_55a757("64", 152, 173) + _lIl1I1l + _l1d_55a757("4a", 137, 164) + _lIII11l + _l1d_55a757("f2c9c2d0d7cbd9db", 235, 46)
else
_l111I1l = _ll1lI1l + _l1d_55a757("8f60725e9b687e6a836a767ab3", 206, 174) + _lI1I11l + _l1d_55a757("6d443d4950465256", 74, 8)
end if
_l11I11l = {
"Referer": _l1II11l
"Origin": _ll1lI1l
"Accept": _l1d_55a757("87797c939b949987a7a4a6eab09cb3b5faf9a8bcbab10bbbd2d2ddd91e1d26262c", 214, 208)
"X-Requested-With": _l1d_55a757("614f535a81848b707c9392859e9c", 133, 132)
}
_lIIlI1l = HC_Get(_lI11I1l, _l111I1l, _l11I11l, 8000)
if _lIIlI1l = invalid or _lIIlI1l.body = "" then return invalid
_lI1lI1l = ParseJSON(_lIIlI1l.body)
if _lI1lI1l = invalid or type(_lI1lI1l) <> _l1d_55a757("4349364b4e55645d6858666070576d70806b", 29, 212) then return invalid
_ll11I1l = invalid
if _lI1lI1l.data <> invalid then _ll11I1l = _lI1lI1l.data
if (_ll11I1l = invalid or type(_ll11I1l) <> _l1d_55a757("fef4d1070afa15", 197, 71)) and _lI1lI1l.servers <> invalid then _ll11I1l = _lI1lI1l.servers
if _ll11I1l = invalid or type(_ll11I1l) <> _l1d_55a757("d2e8c9dbdef2ed", 215, 45) then return invalid
for each _lII1I1l in _ll11I1l
if type(_lII1I1l) <> _l1d_55a757("aac8e1b2b5d4cbd8d3cbe1cfe302d4d7ebe6", 51, 105) then continue for
_lllII1l = ""
if _lII1I1l.hash <> invalid then _lllII1l = _lII1I1l.hash
if _lllII1l = "" and _lII1I1l.data_id <> invalid then _lllII1l = _lII1I1l.data_id
if _lllII1l = "" and _lII1I1l.id <> invalid then _lllII1l = _lII1I1l.id
if _lllII1l = "" then continue for
_llI1I1l = _ll1lI1l + _l1d_55a757("a95e526cb55c7b6466787dca", 241, 203) + _lllII1l
_l1I1I1l = HC_Get(_lI11I1l, _llI1I1l, _l11I11l, 8000)
if _l1I1I1l = invalid or _l1I1I1l.body = "" then continue for
_l1l1I1l = ParseJSON(_l1I1I1l.body)
if _l1l1I1l = invalid or type(_l1l1I1l) <> _l1d_55a757("0715fa0f122128212c242a2c3c1b3134442f", 153, 28) then continue for
_llII11l = invalid
if _l1l1I1l.data <> invalid and type(_l1l1I1l.data) = _l1d_55a757("977fb0a1a48b9a97a2b0a0b4aad1c1c4bac5", 238, 251) then
_llII11l = _l1l1I1l.data
else
_llII11l = _l1l1I1l
end if
_l1lII1l = ""
if _llII11l.stream <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.stream)
if _l1lII1l = "" and _llII11l.source <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.source)
if _l1lII1l = "" and _llII11l.file <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.file)
if _l1lII1l = "" and _llII11l.url <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.url)
if _l1lII1l = "" then continue for
_lIlII1l = []
_llIlI1l = invalid
if _llII11l.subtitles <> invalid then _llIlI1l = _llII11l.subtitles
if _llIlI1l = invalid and _llII11l.captions <> invalid then _llIlI1l = _llII11l.captions
if _llIlI1l <> invalid and type(_llIlI1l) = _l1d_55a757("4d3b6456594d58", 107, 52) then
for each _lll1I1l in _llIlI1l
if type(_lll1I1l) <> _l1d_55a757("def613e8eb02010a05f313fb0d34080b1d18", 244, 88) then continue for
_ll1II1l = ""
if _lll1I1l.file <> invalid then _ll1II1l = _lll1I1l.file
if _ll1II1l = "" and _lll1I1l.url <> invalid then _ll1II1l = _lll1I1l.url
if _ll1II1l = "" and _lll1I1l.src <> invalid then _ll1II1l = _lll1I1l.src
if _ll1II1l = "" then continue for
_l1llI1l = _l1d_55a757("f901", 22, 134)
if _lll1I1l.language <> invalid then _l1llI1l = LCase(Left(_lll1I1l.language, 2))
if _l1llI1l = "" and _lll1I1l.lang <> invalid then _l1llI1l = LCase(Left(_lll1I1l.lang, 2))
if _l1llI1l = "" and _lll1I1l.label <> invalid then _l1llI1l = LCase(Left(_lll1I1l.label, 2))
_lIllI1l = ""
if _lll1I1l.label <> invalid then _lIllI1l = _lll1I1l.label
if _lIllI1l = "" and _lll1I1l.language <> invalid then _lIllI1l = _lll1I1l.language
if _lIllI1l = "" then _lIllI1l = _l1d_55a757("2f0c06130119040e27", 173, 49)
_lIlII1l.Push({ url: _ll1II1l, language: _l1llI1l, name: _lIllI1l })
end for
end if
return {
url: _l1lII1l
streamFormat: U_StreamFormat(_l1lII1l)
qualities: []
subtitles: _lIlII1l
chapters: []
referer: _l1II11l
userAgent: ""
}
end for
return invalid
end function
function RP_AsStreamString(_ll11lIl as Dynamic) as String
if _ll11lIl = invalid then return ""
if type(_ll11lIl) = _l1d_55a757("60828793919b", 159, 148) or type(_ll11lIl) = _l1d_55a757("4d6b325859717b75", 17, 234) then return _ll11lIl
if type(_ll11lIl) = _l1d_55a757("dcfacfe5e8f8f3", 17, 121) then
if _ll11lIl.Count() = 0 then return ""
_lIl1lIl = _ll11lIl[0]
if type(_lIl1lIl) = _l1d_55a757("638d8aa6aca6", 211, 227) or type(_lIl1lIl) = _l1d_55a757("c1d1a8d0cddbdfeb", 218, 25) then return _lIl1lIl
if type(_lIl1lIl) = _l1d_55a757("34220b3c3f2e35323d553b594d2c5e615560", 75, 251) then
if _lIl1lIl.file <> invalid then return _lIl1lIl.file
if _lIl1lIl.url <> invalid then return _lIl1lIl.url
end if
end if
return ""
end function
function RP_ResolveAirflix(_l11lIIl as String, _llI1IIl as String, _ll1IIIl as Object) as Object
if ((29316 - 4886 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l111IIl = CreateObject(_l1d_55a757("4b4931454a4b63", 1, 216), _l1d_55a757("7dbac5bbc3c78f91d7d8c4dcdbd7d2d3abb0b2e1e40ffabef81b06cacfd3c7c7dddf3621e5eaeff14833f7fcfff4", 179, 225), _l1d_55a757("c2", 51, 104))
m = _l111IIl.match(_l11lIIl)
if m = invalid or m.Count() < 3 then return invalid
_lIl1IIl = m[1]
_l1l1IIl = m[2]
_l1lIIIl = ""
_llIlIIl = ""
if m.Count() >= 5 then
_l1lIIIl = m[3]
_llIlIIl = m[4]
end if
_l1IlIIl = _l1d_55a757("a8c2bebb", 115, 161)
if Left(_l1l1IIl, 2) = _l1d_55a757("7174", 180, 177) then _l1IlIIl = _l1d_55a757("d7d6e0e5", 94, 160)
_lIllIIl = _l1d_55a757("c8dfe2e9ef29191cfbf700eef5ecf6fe0c043c170d1f0616211830573634612e402c6c49344f89", 236, 68) + _l1IlIIl + _l1d_55a757("6b", 226, 140) + U_UrlEncode(_l1l1IIl) + _l1d_55a757("63b8b8c2b27d", 14, 59) + _lIl1IIl
if _lIl1IIl = _l1d_55a757("b8b9", 122, 170) and _l1lIIIl <> "" and _llIlIIl <> "" then
_lIllIIl = _lIllIIl + _l1d_55a757("28566b6a5f6e7222", 185, 137) + _l1lIIIl + _l1d_55a757("a9ef05f10af1fd01cc", 14, 129) + _llIlIIl
end if
_l1llIIl = _l1d_55a757("223134333703f9fc4038504f43445248565a63575c585e716966366c7b7c41", 1, 185)
_l1I1IIl = HC_Get(_ll1IIIl, _lIllIIl, {
"Referer": _l1llIIl
"Origin": _l1d_55a757("8baaadacb06c6265a9b1b9c8bcbdbbc1bfc3dcd0d5d1d7ead2df9fe5e4e5", 137, 170)
}, 8000)
if _l1I1IIl = invalid or _l1I1IIl.body = "" then return invalid
_lI1lIIl = ParseJSON(_l1I1IIl.body)
if _lI1lIIl = invalid or type(_lI1lIIl) <> _l1d_55a757("d1bfa4d9dccbd2cbd6eed4f6e6c5fbfeeef9", 73, 150) then return invalid
_lllIIIl = ""
if _lI1lIIl.status_code <> invalid then _lllIIIl = _lI1lIIl.status_code.ToStr()
if _lllIIIl <> _l1d_55a757("52575a", 218, 106) then return invalid
_ll1lIIl = _lI1lIIl.data
if _ll1lIIl = invalid or type(_ll1lIIl) <> _l1d_55a757("d9efcce1e4fbfa03feee0cf606ed03061611", 85, 178) then return invalid
_l11IIIl = _ll1lIIl.stream_urls
if _l11IIIl = invalid or type(_l11IIIl) <> _l1d_55a757("9086a7999c90ab", 167, 187) or _l11IIIl.Count() = 0 then return invalid
_llIIIIl = []
_lIlIIIl = {}
_llllIIl = []
_l1IIIIl = [_lI1lIIl.subs, _ll1lIIl.subs, _lI1lIIl.default_subs, _ll1lIIl.default_subs]
for each _lll1IIl in _l1IIIIl
if _lll1IIl = invalid or type(_lll1IIl) <> _l1d_55a757("fe1cf5070a1e19", 83, 221) then continue for
for each _lII1IIl in _lll1IIl
if type(_lII1IIl) <> _l1d_55a757("45653a4f527168716c627a6a7c5b6f72847f", 208, 163) then continue for
_lIIIIIl = ""
if _lII1IIl.url <> invalid then _lIIIIIl = _lII1IIl.url
if _lIIIIIl = "" and _lII1IIl.file <> invalid then _lIIIIIl = _lII1IIl.file
if _lIIIIIl = "" then continue for
if _lIlIIIl.DoesExist(_lIIIIIl) then continue for
_lIlIIIl[_lIIIIIl] = true
_lIIlIIl = ""
if _lII1IIl.code <> invalid then _lIIlIIl = LCase(_lII1IIl.code)
if _lIIlIIl = "" and _lII1IIl.language <> invalid then _lIIlIIl = LCase(_lII1IIl.language)
if _lIIlIIl = "" and _lII1IIl.lang <> invalid and Len(_lII1IIl.lang) >= 2 then _lIIlIIl = LCase(Left(_lII1IIl.lang, 2))
if _lIIlIIl = "" then _lIIlIIl = _l1d_55a757("dbd7", 136, 238)
_ll11IIl = ""
if _lII1IIl.label <> invalid then _ll11IIl = _lII1IIl.label
if _ll11IIl = "" and _lII1IIl.lang <> invalid then _ll11IIl = _lII1IIl.lang
if _ll11IIl = "" and _lII1IIl.language <> invalid then _ll11IIl = _lII1IIl.language
if _ll11IIl = "" then _ll11IIl = UCase(_lIIlIIl)
_llllIIl.Push({ url: _lIIIIIl, language: _lIIlIIl, name: _ll11IIl })
end for
end for
for each _llllll1 in _llllIIl
if _llllll1.language = _l1d_55a757("212f", 17, 173) then _llIIIIl.Push(_llllll1)
end for
for each _llllll1 in _llllIIl
if _llllll1.language <> _l1d_55a757("8983", 207, 223) then _llIIIIl.Push(_llllll1)
end for
for each _lI1IIIl in _l11IIIl
if type(_lI1IIIl) <> _l1d_55a757("f3d5dae6e4ee", 191, 7) and type(_lI1IIIl) <> _l1d_55a757("0efe35191a040c18", 104, 244) then continue for
if _lI1IIIl = "" then continue for
_lI11IIl = HC_Get(_ll1IIIl, _lI1IIIl, { "Referer": _l1llIIl }, 6000)
if _lI11IIl = invalid or _lI11IIl.body = "" then continue for
if Left(_lI11IIl.body, 7) <> _l1d_55a757("31525249633051", 151, 125) then continue for
return {
url: _lI1IIIl
streamFormat: _l1d_55a757("b8bfd9", 232, 56)
qualities: []
subtitles: _llIIIIl
chapters: []
referer: _l1llIIl
userAgent: ""
}
end for
return invalid
end function
function RP_HlsLeadSkip(_l11Ill1 as Object, _lllIll1 as String, _l1lIll1 as String, _ll1Ill1 as String) as Integer
if ((37356 - 9339 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _l1lIll1 = "" then return 0
_l1I1ll1 = _lllIll1
_l1IIll1 = _l1lIll1
if _l1I1ll1 = "" then
_lIlIll1 = HC_Get(_l11Ill1, _l1IIll1, { "Referer": _ll1Ill1 }, 5000)
if _lIlIll1 = invalid or _lIlIll1.body = "" then return 0
_l1I1ll1 = _lIlIll1.body
end if
if Left(_l1I1ll1, 7) <> _l1d_55a757("311a12112b3019", 243, 97) then return 0
if Instr(1, _l1I1ll1, _l1d_55a757("d57a7271eb7bf17a80819594a306a5afaa", 81, 99)) <= 0 then
return RP_ProbeMediaPlaylist(_l11Ill1, _l1I1ll1, _l1IIll1, _ll1Ill1)
end if
_lII1ll1 = 0
for each line in _l1I1ll1.Tokenize(Chr(10))
_llIIll1 = U_Trim(line)
if _llIIll1 = "" then continue for
if Left(_llIIll1, 1) = _l1d_55a757("3c", 174, 175) then continue for
_llll1l1 = U_AbsUrl(_llIIll1, HC_OriginOf(_l1IIll1))
if _llll1l1 = "" then continue for
_lIIIll1 = HC_Get(_l11Ill1, _llll1l1, { "Referer": _ll1Ill1 }, 5000)
if _lIIIll1 <> invalid and _lIIIll1.body <> "" and Left(_lIIIll1.body, 7) = _l1d_55a757("0aa7979ea809a6", 221, 12) then
_lI1Ill1 = RP_ProbeMediaPlaylist(_l11Ill1, _lIIIll1.body, _llll1l1, _ll1Ill1)
if _lI1Ill1 > 0 then return _lI1Ill1
end if
_lII1ll1 = _lII1ll1 + 1
if _lII1ll1 >= 8 then exit for
end for
return 0
end function
function RP_ProbeMediaPlaylist(_lI11Il1 as Object, _lll1Il1 as String, _l1l1Il1 as String, _l111Il1 as String) as Integer
_l1IlIl1 = 0.0
_lIIlIl1 = ""
_lIl1Il1 = 0.0
_llIlIl1 = CreateObject(_l1d_55a757("ddf503f1f6f7f5", 180, 23), _l1d_55a757("9dbacad1bfc1ccbbace0cab0c7b9e9c2c3", 13, 111), _l1d_55a757("38", 45, 244))
for each line in _lll1Il1.Tokenize(Chr(10))
_l1I1Il1 = U_Trim(line)
if _l1I1Il1 = "" then continue for
if Left(_l1I1Il1, 1) = _l1d_55a757("24", 248, 73) then
_lI1lIl1 = _llIlIl1.match(_l1I1Il1)
if _lI1lIl1 <> invalid and _lI1lIl1.Count() >= 2 then _lIl1Il1 = Val(_lI1lIl1[1])
continue for
end if
_lIIlIl1 = U_AbsUrl(_l1I1Il1, HC_OriginOf(_l1l1Il1))
_l1IlIl1 = _lIl1Il1
exit for
end for
if _lIIlIl1 = "" then return 0
_ll11Il1 = HC_GetRange(_lI11Il1, _lIIlIl1, { "Referer": _l111Il1 }, _l1d_55a757("a5adbdafc07d85738a", 41, 90), 5000)
if _ll11Il1 = invalid then return 0
if _ll11Il1.status <= 0 then return 0
if Len(_ll11Il1.body) > 0 then return 0
_llI1Il1 = Int(_l1IlIl1 + 0.999) + 2
if _llI1Il1 < 4 then _llI1Il1 = 8
if _llI1Il1 > 30 then _llI1Il1 = 30
print _l1d_55a757("574746485d9b4e585d5a61636d6fb6a9b1816b7185cb8c8a868a86dd93a0a59ea9a59ef5edfbb2bec5c3ddc8c9c3fb", 124, 48); _llI1Il1
return _llI1Il1
end function
function RP_VidrockEncrypt(_ll1l111 as String, _l1ll111 as String, _llll111 as String) as String
if ((12275 - 2455 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l11Il11 = CreateObject(_l1d_55a757("bda5d2e2ebddbad4bfc7db", 174, 225))
_lI1l111 = _l11Il11.Setup(true, _l1d_55a757("474e3b0c020a0c185d6163", 27, 205), _l1ll111, _llll111, 1)
if _lI1l111 <> 0 then return ""
_l11l111 = CreateObject(_l1d_55a757("2c3a622a3a4c6b4144543f", 185, 97))
_l11l111.FromAsciiString(_ll1l111)
_l1IIl11 = CreateObject(_l1d_55a757("907e668e9e906fa5a898a3", 201, 213))
_lI1Il11 = _l11Il11.Process(_l11l111)
if _lI1Il11 <> invalid then
for _lIIIl11 = 0 to _lI1Il11.Count() - 1
_l1IIl11.Push(_lI1Il11[_lIIIl11])
end for
end if
_llIIl11 = _l11Il11.Final()
if _llIIl11 <> invalid then
for _lIIIl11 = 0 to _llIIl11.Count() - 1
_l1IIl11.Push(_llIIl11[_lIIIl11])
end for
end if
if _l1IIl11.Count() = 0 then return ""
_ll1Il11 = _l1IIl11.ToBase64String()
_llIl111 = CreateObject(_l1d_55a757("535b39676c6d5b", 92, 37), _l1d_55a757("2e64", 254, 140), "")
_l1Il111 = CreateObject(_l1d_55a757("6e569466676c7a", 238, 210), _l1d_55a757("a3", 45, 161), "")
_lIIl111 = CreateObject(_l1d_55a757("e00006fc0102f8", 176, 30), _l1d_55a757("d6e7e5", 113, 138), "")
_lIll111 = _llIl111.ReplaceAll(_ll1Il11, _l1d_55a757("ca", 162, 59))
_lIll111 = _l1Il111.ReplaceAll(_lIll111, _l1d_55a757("48", 226, 139))
_lIll111 = _lIIl111.ReplaceAll(_lIll111, "")
return _lIll111
end function
function RP_ResolveVidrock(_lI11I11 as String, _lllllI1 as String, _l11llI1 as Object) as Object
if ((45423 - 6489 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lI1II11 = CreateObject(_l1d_55a757("765c9c6c6d7282", 47, 25), _l1d_55a757("252f3b43fbf6040408404956500e0f2b1b222e393a6a6771603b77495457724d898e929ea6949e8d68a4a9a6b09f7ab6bbbecb", 239, 101), _l1d_55a757("3c", 138, 89))
m = _lI1II11.match(_lI11I11)
if m = invalid or m.Count() < 3 then return invalid
_lIlII11 = m[1]
_ll11I11 = m[2]
_ll1llI1 = ""
_l1I1I11 = ""
if m.Count() >= 5 then
_ll1llI1 = m[3]
_l1I1I11 = m[4]
end if
_l1l1I11 = _l1d_55a757("4c53565d63ad9da06a685e776f6e79b78684", 68, 32)
if _lIlII11 = _l1d_55a757("6c71", 172, 148) and _ll1llI1 <> "" and _l1I1I11 <> "" then
_l1III11 = _ll11I11 + _l1d_55a757("01", 84, 246) + _ll1llI1 + _l1d_55a757("f5", 228, 58) + _l1I1I11
else
_l1III11 = _ll11I11
end if
_l1lII11 = _l1d_55a757("d7d9e1e0e43bedeaf045f7fffb0403070b0f0d151516191d212029272b84343a3b3c3e45464a4d5050a458595f5f62636ac0717574ca7cd1838586db8ee09592", 191, 79)
_lllII11  = _l1d_55a757("c6d2d0cfd128dce5dd2ee2e8eaefeef0fafcfc020005080a0c1b18201a6f1d25", 52, 195)
_llI1I11 = RP_VidrockEncrypt(_l1III11, _l1lII11, _lllII11)
if _llI1I11 = "" then return invalid
if _lIlII11 = _l1d_55a757("fc01", 65, 199) and _ll1llI1 <> "" and _l1I1I11 <> "" then
_lIl1I11 = _l1l1I11 + _l1d_55a757("0d52665019737822", 169, 135) + _llI1I11
else
_lIl1I11 = _l1l1I11 + _l1d_55a757("0f50445e1b60614d6d642d", 183, 119) + _llI1I11
end if
_lII1I11 = {
"Referer": _l1l1I11 + _l1d_55a757("b5", 210, 184) + _lIlII11 + _l1d_55a757("25", 78, 196) + _ll11I11
"Origin": _l1l1I11
"Accept": _l1d_55a757("a69a9dbcbab3b8b0c6cbcf11d1bbdade231ad1e3dbda32dcfbf1fc02473e474d4d", 211, 244)
"User-Agent": _l1d_55a757("8bb0c6b8b6b9c9829b87a49792ccd9d9e2e0fb02b2cbe4bbcfd1bad7d5cdff0c0ce7e8eae22df6f7e7f115474a313d32434b27485e0c252e2d1737352a254b4b624e5033427981868b5173949d98975c668ca4c1a9aab5728f93907d9a83a089a699cfe0e0e6fae4a5bec7c6b0d0ce", 12, 74)
}
_l1lllI1 = HC_Get(_l11llI1, _lIl1I11, _lII1I11, 8000)
if _l1lllI1 = invalid or _l1lllI1.body = "" then return invalid
_llIII11 = ParseJSON(_l1lllI1.body)
if _llIII11 = invalid or type(_llIII11) <> _l1d_55a757("46647d4e517067746f677d6b7f9e70738782", 243, 197) then
_l111I11 = RP_TryBase64Decode(U_Trim(_l1lllI1.body))
if _l111I11 <> "" then _llIII11 = ParseJSON(_l111I11)
if _llIII11 = invalid or type(_llIII11) <> _l1d_55a757("0d2b441518372e3b362e44324665373a4e49", 51, 204) then return invalid
end if
_llIllI1 = []
RP_WalkForStreams(_llIII11, _llIllI1)
if _llIllI1.Count() = 0 then return invalid
_l1IllI1 = []
_lIIII11 = invalid
if _llIII11.subtitle <> invalid then _lIIII11 = _llIII11.subtitle
if _lIIII11 = invalid and _llIII11.subtitles <> invalid then _lIIII11 = _llIII11.subtitles
if _lIIII11 = invalid and _llIII11.captions <> invalid then _lIIII11 = _llIII11.captions
if _lIIII11 <> invalid and type(_lIIII11) = _l1d_55a757("2919fe32352732", 200, 111) then
for each _lIlllI1 in _lIIII11
if type(_lIlllI1) <> _l1d_55a757("19274c2124333a333e363c3e4e6d43465641", 121, 14) then continue for
_lIIllI1 = ""
if _lIlllI1.file <> invalid then _lIIllI1 = _lIlllI1.file
if _lIIllI1 = "" and _lIlllI1.url <> invalid then _lIIllI1 = _lIlllI1.url
if _lIIllI1 = "" then continue for
_ll1II11 = _l1d_55a757("8c88", 92, 83)
if _lIlllI1.language <> invalid then _ll1II11 = LCase(Left(_lIlllI1.language, 2))
if _ll1II11 = "" and _lIlllI1.lang <> invalid then _ll1II11 = LCase(Left(_lIlllI1.lang, 2))
_l11II11 = ""
if _lIlllI1.label <> invalid then _l11II11 = _lIlllI1.label
if _l11II11 = "" and _lIlllI1.language <> invalid then _l11II11 = _lIlllI1.language
if _l11II11 = "" then _l11II11 = _l1d_55a757("ccb5c1bad2c0dbd7c4", 50, 107)
_l1IllI1.Push({ url: _lIIllI1, language: _ll1II11, name: _l11II11 })
end for
end if
_lI1llI1 = _llIllI1[0]
return {
url: _lI1llI1
streamFormat: U_StreamFormat(_lI1llI1)
qualities: []
subtitles: _l1IllI1
chapters: []
referer: _lI11I11
userAgent: ""
}
end function
sub RP_WalkForStreams(_lIll1I1 as Dynamic, _ll1l1I1 as Object)
if _lIll1I1 = invalid or _ll1l1I1 = invalid then return
_l11l1I1 = type(_lIll1I1)
if _l11l1I1 = _l1d_55a757("5c522f64675e5d6661716f79695086897994", 133, 101) then
for each _l1ll1I1 in _lIll1I1
_lI1l1I1 = _lIll1I1[_l1ll1I1]
if _lI1l1I1 = invalid then continue for
_llIl1I1 = type(_lI1l1I1)
if _llIl1I1 = _l1d_55a757("28484d5b5763", 94, 27) or _llIl1I1 = _l1d_55a757("c6d4abd5d2dee4ee", 91, 157) then
if Instr(1, _lI1l1I1, _l1d_55a757("347a1f682e", 146, 120)) > 0 or Instr(1, _lI1l1I1, _l1d_55a757("f1b7d514", 78, 145)) > 0 then _ll1l1I1.Push(_lI1l1I1)
else if _llIl1I1 = _l1d_55a757("9fb798a9acc3c2cfcab8d8bcd2b9c9cce2dd", 150, 187) or _llIl1I1 = _l1d_55a757("a09879a9aca2bd", 70, 108) then
RP_WalkForStreams(_lI1l1I1, _ll1l1I1)
end if
end for
else if _l11l1I1 = _l1d_55a757("7383687c7f917c", 88, 73) then
for each _llll1I1 in _lIll1I1
if _llll1I1 = invalid then continue for
_lIIIlI1 = type(_llll1I1)
if _lIIIlI1 = _l1d_55a757("43232846423e", 182, 94) or _lIIIlI1 = _l1d_55a757("515f76605d696f79", 187, 136) then
if Instr(1, _llll1I1, _l1d_55a757("7fbfa0dd9d", 173, 252)) > 0 or Instr(1, _llll1I1, _l1d_55a757("1fe1c70e", 208, 33)) > 0 then _ll1l1I1.Push(_llll1I1)
else if _lIIIlI1 = _l1d_55a757("3c24114649303f38435141594b3266695b66", 76, 254) or _lIIIlI1 = _l1d_55a757("afad82b8bbabc6", 193, 252) then
RP_WalkForStreams(_llll1I1, _ll1l1I1)
end if
end for
end if
end sub
function RP_TryBase64Decode(_lII1II1 as String) as String
if _lII1II1 = invalid or _lII1II1 = "" then return ""
_lllIII1 = _lII1II1
_l1I1II1 = Len(_lllIII1) mod 4
if _l1I1II1 = 1 then return ""
if _l1I1II1 = 2 then _lllIII1 = _lllIII1 + _l1d_55a757("0306", 173, 115)
if _l1I1II1 = 3 then _lllIII1 = _lllIII1 + _l1d_55a757("eb", 226, 12)
_llI1II1 = CreateObject(_l1d_55a757("68805e7c72866d7d809691", 214, 196))
_llI1II1.FromBase64String(_lllIII1)
return _llI1II1.ToAsciiString()
end function
function RP_ResolveXpass(_l1l11lI as String, _lI1I1lI as String, _l1II1lI as Object) as Object
_l1111lI = {}
if _lI1I1lI <> "" then _l1111lI[_l1d_55a757("f11d23231d2923", 157, 34)] = _lI1I1lI else _l1111lI[_l1d_55a757("b88a8a90a496aa", 230, 4)] = _l1d_55a757("84a3a6a5abe5dde09cb0aebfb1abbaf7ced401", 72, 100)
_lllI1lI = HC_Get(_l1II1lI, _l1l11lI, _l1111lI, 8000)
if _lllI1lI = invalid or _lllI1lI.body = "" then return invalid
_lI111lI = _lllI1lI.body
_ll111lI = _lllI1lI.finalUrl
if _ll111lI = invalid or _ll111lI = "" then _ll111lI = _l1l11lI
_llIl1lI = []
_l11I1lI = CreateObject(_l1d_55a757("aacad0cacbd0c6", 114, 170), chr(34) + _l1d_55a757("d8c7cfdad0d0edf1", 104, 192) + chr(34) + _l1d_55a757("f5cb859801d791", 34, 119) + chr(34) + _l1d_55a757("e01414", 5, 179) + chr(34) + _l1d_55a757("8f6469", 143, 189) + chr(34), _l1d_55a757("59", 249, 201))
_ll1I1lI = _l11I1lI.match(_lI111lI)
if _ll1I1lI <> invalid and _ll1I1lI.Count() >= 2 then
_llIl1lI.Push({ label: _l1d_55a757("76666753a6a79594a3b3b1", 14, 28), url: RP_AbsUrl(_ll1I1lI[1], _ll111lI) })
end if
_l11l1lI = RP_ParseXpassBackups(_lI111lI)
if _l11l1lI <> invalid and type(_l11l1lI) = _l1d_55a757("8a70a193968a95", 175, 173) then
for each _lIl11lI in _l11l1lI
if type(_lIl11lI) <> _l1d_55a757("6b6b847578776e7b768c849086a595988ea9", 226, 219) then continue for
_lIllIlI = _lIl11lI.url
if _lIllIlI = invalid or _lIllIlI = "" then continue for
_lII11lI = ""
if _lIl11lI.name <> invalid then _lII11lI = _lIl11lI.name
if _lII11lI = "" then _lII11lI = _l1d_55a757("c9cbd0cbe0e6", 172, 251)
_llIl1lI.Push({ label: _lII11lI, url: RP_AbsUrl(_lIllIlI, _ll111lI) })
end for
end if
_llII1lI = {}
_l1llIlI = []
for each _lI1l1lI in _llIl1lI
if _lI1l1lI.url = "" then continue for
if _llII1lI.DoesExist(_lI1l1lI.url) then continue for
_llII1lI[_lI1l1lI.url] = true
_l1llIlI.Push(_lI1l1lI)
end for
for _llI11lI = 1 to _l1llIlI.Count() - 1
_l1Il1lI = _l1llIlI[_llI11lI]
_lIIl1lI = RP_XpassSrcRank(_l1Il1lI)
_l1I11lI = _llI11lI - 1
while _l1I11lI >= 0
if RP_XpassSrcRank(_l1llIlI[_l1I11lI]) <= _lIIl1lI then exit while
_l1llIlI[_l1I11lI + 1] = _l1llIlI[_l1I11lI]
_l1I11lI = _l1I11lI - 1
end while
_l1llIlI[_l1I11lI + 1] = _l1Il1lI
end for
_llllIlI = RP_FetchXpassSubs(_lI111lI, _l1II1lI)
for each _lI1l1lI in _l1llIlI
_l1lI1lI = _lI1l1lI.url
_lIlI1lI = HC_Get(_l1II1lI, _l1lI1lI, { "Referer": _ll111lI }, 6000)
if _lIlI1lI = invalid or _lIlI1lI.body = "" then continue for
_lll11lI = ParseJSON(_lIlI1lI.body)
if _lll11lI = invalid or type(_lll11lI) <> _l1d_55a757("78784d8285847b847f958d9d8f6ea2a597b2", 128, 134) then continue for
_lIII1lI = RP_XpassFirstSource(_lll11lI)
if _lIII1lI = "" then continue for
_lIII1lI = RP_AbsUrl(_lIII1lI, _l1lI1lI)
_ll1lIlI = HC_Get(_l1II1lI, _lIII1lI, { "Referer": _ll111lI }, 6000)
if _ll1lIlI = invalid or _ll1lIlI.body = "" then continue for
if Left(_ll1lIlI.body, 7) <> _l1d_55a757("3be4faf9f55a03", 194, 90) then continue for
return {
url: _lIII1lI
streamFormat: _l1d_55a757("969da3", 98, 140)
qualities: []
subtitles: _llllIlI
chapters: []
referer: _ll111lI
userAgent: ""
}
end for
return invalid
end function
function RP_XpassSrcRank(_lIlIIlI as Object) as Integer
_ll1IIlI = ""
_l11IIlI = ""
if _lIlIIlI.label <> invalid then _ll1IIlI = UCase(_lIlIIlI.label)
if _lIlIIlI.url <> invalid then _l11IIlI = LCase(_lIlIIlI.url)
if Instr(1, _ll1IIlI, _l1d_55a757("534b50", 160, 95)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("b3f4fefe1404c5", 136, 12)) > 0 then return 100
if Instr(1, _ll1IIlI, _l1d_55a757("4a4b55", 162, 91)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("e2e3dda8aae4ad", 62, 143)) > 0 then return 0
if Instr(1, _ll1IIlI, _l1d_55a757("051711", 254, 93)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("24706c7830", 133, 122)) > 0 then return 1
if Instr(1, _ll1IIlI, _l1d_55a757("554d65", 35, 229)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("609faf9f6c", 63, 80)) > 0 then return 2
return 50
end function
function RP_ParseXpassBackups(_lII111I as String) as Object
if _lII111I = invalid or _lII111I = "" then return []
_l1II11I = CreateObject(_l1d_55a757("9d9dc3999e9fb5", 32, 75), _l1d_55a757("615b6b5472ad676d6e7982888a7290cadc7e9cd6878d", 198, 177), _l1d_55a757("36", 185, 102))
_l1I111I = _l1II11I.match(_lII111I)
if _l1I111I = invalid or _l1I111I.Count() < 1 then return []
_ll1I11I = _l1I111I[0]
_llllI1I = Instr(1, _lII111I, _ll1I11I)
if _llllI1I <= 0 then return []
_lll111I = Instr(_llllI1I, _lII111I, _l1d_55a757("c6", 86, 185))
if _lll111I <= 0 then return []
_ll1111I = 0
_l1lI11I = false
_lI1I11I = ""
_llI111I = false
_lI1111I = 0
_lIlI11I = Len(_lII111I)
_l1l111I = chr(92)
_l11111I = chr(34)
_lIII11I = _l1d_55a757("62", 106, 21)
for _lllI11I = _lll111I to _lIlI11I
_lIl111I = Mid(_lII111I, _lllI11I, 1)
if _l1lI11I then
if _llI111I then
_llI111I = false
else if _lIl111I = _l1l111I then
_llI111I = true
else if _lIl111I = _lI1I11I then
_l1lI11I = false
end if
else
if _lIl111I = _l11111I or _lIl111I = _lIII11I then
_l1lI11I = true
_lI1I11I = _lIl111I
else if _lIl111I = _l1d_55a757("ae", 198, 17) then
_ll1111I = _ll1111I + 1
else if _lIl111I = _l1d_55a757("7f", 127, 93) then
_ll1111I = _ll1111I - 1
if _ll1111I = 0 then
_lI1111I = _lllI11I
exit for
end if
end if
end if
end for
if _lI1111I = 0 then return []
_llII11I = Mid(_lII111I, _lll111I, _lI1111I - _lll111I + 1)
_l11I11I = ParseJSON(_llII11I)
if _l11I11I = invalid or type(_l11I11I) <> _l1d_55a757("4d3b2056594954", 201, 146) then return []
return _l11I11I
end function
function RP_XpassFirstSource(_l1III1I as Object) as String
if ((27070 - 5414 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _l1III1I = invalid or type(_l1III1I) <> _l1d_55a757("4e5e43585b6a716a756b73738564787b8d78", 152, 100) then return ""
_l1lllII = _l1III1I.playlist
if _l1lllII = invalid or type(_l1lllII) <> _l1d_55a757("393f3042455944", 95, 12) then return ""
for each _lIIII1I in _l1lllII
if type(_lIIII1I) <> _l1d_55a757("a0ae97a8abbac1bec9c1c7c5d9b8cacde1cc", 219, 247) then continue for
_ll1llII = _lIIII1I.sources
if _ll1llII = invalid or type(_ll1llII) <> _l1d_55a757("c8debbd1d4e4df", 21, 97) then continue for
for each _lIlllII in _ll1llII
if type(_lIlllII) <> _l1d_55a757("d9e1d2e3e6edfcf904f202f60cf303061c07", 30, 109) then continue for
_lllllII = _lIlllII.file
if _lllllII <> invalid and _lllllII <> "" then return _lllllII
end for
end for
return ""
end function
function RP_FetchXpassSubs(_lI111II as String, _lI1I1II as Object) as Object
if ((50940 - 8490 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lIlI1II = []
if _lI111II = invalid or _lI111II = "" then return _lIlI1II
_ll1I1II = CreateObject(_l1d_55a757("a28ac8969b9caa", 172, 196), _l1d_55a757("6f7b719e76517c81938789a6b9916d61c59d79", 177, 168) + chr(34) + _l1d_55a757("51c3c1", 46, 75) + chr(34) + _l1d_55a757("31aaab", 220, 176) + chr(34), _l1d_55a757("e5", 26, 114))
m = _ll1I1II.match(_lI111II)
if m = invalid or m.Count() < 2 then return _lIlI1II
_l11I1II = HC_Get(_lI1I1II, m[1], invalid, 6000)
if _l11I1II = invalid or _l11I1II.body = "" then return _lIlI1II
_lII11II = ParseJSON(_l11I1II.body)
if _lII11II = invalid or type(_lII11II) <> _l1d_55a757("fc122f05081813", 181, 53) then return _lIlI1II
_llII1II = _lII11II.Count()
if _llII1II > 30 then _llII1II = 30
for _llI11II = 0 to _llII1II - 1
_l1I11II = _lII11II[_llI11II]
if type(_l1I11II) <> _l1d_55a757("9d8db2a7aa99a099a4baa2c2b4d3c7cabcc7", 168, 195) then continue for
_l1II1II = _l1I11II.url
if _l1II1II = invalid or _l1II1II = "" then continue for
_lllI1II = _l1d_55a757("aea8", 111, 164)
if _l1I11II.language <> invalid then _lllI1II = LCase(_l1I11II.language)
_l1lI1II = ""
if _l1I11II.display <> invalid then _l1lI1II = _l1I11II.display
if _l1lI1II = "" then
if _l1I11II.language <> invalid then _l1lI1II = UCase(_l1I11II.language) else _l1lI1II = _l1d_55a757("b0b8", 242, 249)
end if
_lIlI1II.Push({ url: _l1II1II, language: _lllI1II, name: _l1lI1II })
end for
return _lIlI1II
end function
function RP_ResolveJwplayerPage(_lI1llll as String, _l1Illll as String, _lll1lll as String, _l111lll as Object) as Object
if _lI1llll = invalid or _lI1llll = "" then return invalid
_l11llll = []
RP_JwExtractInto(_lI1llll, _l11llll)
_llIllll = CreateObject(_l1d_55a757("0800ee00010624", 134, 20), _l1d_55a757("09ff0b1bee5d1e0e2c22182e373b0c7b26853b8b43915197519d5833a1363c54423a47b8afb1c56c7f738b777ecb", 81, 213), _l1d_55a757("82", 86, 67))
_lIIllll = _llIllll.match(_lI1llll)
if _lIIllll <> invalid and _lIIllll.Count() >= 1 then
_llI1lll = JU_UnpackPacked(_lIIllll[0])
if _llI1lll <> "" then RP_JwExtractInto(_llI1lll, _l11llll)
end if
if _l11llll.Count() = 0 then return invalid
_l1l1lll = _lll1lll
if _l1l1lll = "" then _l1l1lll = _l1Illll
_ll11lll = {}
for each _ll1llll in _l11llll
_lI11lll = RP_AbsUrl(_ll1llll.url, _l1Illll)
if _lI11lll = "" then continue for
if _ll11lll.DoesExist(_lI11lll) then continue for
_ll11lll[_lI11lll] = true
_lIl1lll = HC_Get(_l111lll, _lI11lll, { "Referer": _l1l1lll }, 6000)
if _lIl1lll = invalid or _lIl1lll.body = "" then continue for
if _ll1llll.fmt = _l1d_55a757("656c76", 128, 125) and Left(_lIl1lll.body, 7) <> _l1d_55a757("d8b5a5acb6d7b4", 125, 122) then continue for
return {
url: _lI11lll
streamFormat: _ll1llll.fmt
qualities: []
subtitles: RP_ExtractSubs(_lI1llll)
chapters: []
referer: _l1l1lll
userAgent: ""
}
end for
return invalid
end function
sub RP_JwExtractInto(_lI1lIll as String, _llII1ll as Object)
if _lI1lIll = invalid or _lI1lIll = "" then return
_l1lI1ll = chr(34)
_llllIll = _l1d_55a757("abb3bbb5d1a58174ddb18ddf", 179, 214) + _l1lI1ll + _l1d_55a757("feab03b3b3", 79, 150) + _l1lI1ll + _l1d_55a757("b66f90d2c99bca7f", 65, 80) + _l1lI1ll + _l1d_55a757("606d", 31, 40)
_l1llIll = _l1d_55a757("213825293d3e5836908364429c70", 118, 28) + _l1lI1ll + _l1d_55a757("b780b0848c", 249, 217) + _l1lI1ll + _l1d_55a757("441d064857096035", 245, 114) + _l1lI1ll + _l1d_55a757("4653", 27, 10)
_lIllIll = _l1d_55a757("0307f91f0fbbce2b1bc739", 173, 37) + _l1lI1ll + _l1d_55a757("67f05ef4fa", 216, 104) + _l1lI1ll + _l1d_55a757("25f2cf152cde02333428280035fe36fd0f074e54252d", 123, 201) + _l1lI1ll + _l1d_55a757("a009999b10", 40, 145) + _l1lI1ll + _l1d_55a757("a891", 232, 217)
_ll1lIll = _l1d_55a757("543b4b563d614a3d6b152849772155", 14, 214) + _l1lI1ll + _l1d_55a757("57f464f4fc", 211, 99) + _l1lI1ll + _l1d_55a757("23bcdd1f36e837cc", 81, 173) + _l1lI1ll + _l1d_55a757("fcc9", 254, 35)
for each _lIII1ll in [_llllIll, _l1llIll, _lIllIll, _ll1lIll]
_l11lIll = CreateObject(_l1d_55a757("8f9575a5a6ab9b", 31, 34), _lIII1ll, _l1d_55a757("ca", 44, 133))
m = _l11lIll.match(_lI1lIll)
if m <> invalid and m.Count() >= 2 then
_llIlIll = RP_UnescapeSlashes(m[1])
_lIlI1ll = _l1d_55a757("8c939b", 161, 195)
if Instr(1, LCase(_llIlIll), _l1d_55a757("21e1c910", 209, 34)) > 0 then _lIlI1ll = _l1d_55a757("fff53c", 88, 202)
_llII1ll.Push({ url: _llIlIll, fmt: _lIlI1ll })
end if
end for
_l11I1ll = CreateObject(_l1d_55a757("d2c8b8c4c9caea", 133, 219), _l1d_55a757("35f8f7faf9fd3c3c5255e4ec", 89, 196) + _l1lI1ll + _l1d_55a757("832d3033639b3b94429757b875b55959", 77, 25) + _l1lI1ll + _l1d_55a757("5b838689bb71936b6d", 140, 176), _l1d_55a757("05", 221, 81))
_ll1I1ll = _l11I1ll.match(_lI1lIll)
if _ll1I1ll <> invalid and _ll1I1ll.Count() >= 2 then _llII1ll.Push({ url: _ll1I1ll[1], fmt: _l1d_55a757("585745", 246, 186) })
_lI1I1ll = CreateObject(_l1d_55a757("67654d65666b83", 195, 182), _l1d_55a757("5497a6a9a8aa79776f72e1e7", 34, 74) + _l1lI1ll + _l1d_55a757("8bb7babdeba1c79ccc9de301c0dedc", 14, 98) + _l1lI1ll + _l1d_55a757("f903060939f1110b0b", 29, 191), _l1d_55a757("0d", 45, 201))
_l1II1ll = _lI1I1ll.match(_lI1lIll)
if _l1II1ll <> invalid and _l1II1ll.Count() >= 2 then _llII1ll.Push({ url: _l1II1ll[1], fmt: _l1d_55a757("ea08c7", 12, 137) })
end sub
function RP_UnescapeSlashes(_lll1l1l as String) as String
if _lll1l1l = invalid or _lll1l1l = "" then return ""
_lIIll1l = CreateObject(_l1d_55a757("97b5bdb5b6bbb3", 179, 214), _l1d_55a757("d8dbcd", 154, 18), _l1d_55a757("e9", 72, 186))
return _lIIll1l.replaceAll(_lll1l1l, _l1d_55a757("c1", 81, 67))
end function
function RP_AbsUrl(_llllI1l as String, _llII11l as String) as String
if ((24984 - 3123 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _llllI1l = invalid or _llllI1l = "" then return ""
_lIII11l = U_Trim(_llllI1l)
if Left(_lIII11l, 7) = _l1d_55a757("32191c23ecfafd", 183, 83) or Left(_lIII11l, 8) = _l1d_55a757("c9e0e3eaec261619", 238, 67) then return _lIII11l
if Left(_lIII11l, 2) = _l1d_55a757("7c7f", 54, 99) then return _l1d_55a757("3e55585f659f", 76, 26) + _lIII11l
_ll1lI1l = HC_OriginOf(_llII11l)
if _ll1lI1l = "" then return _lIII11l
if Left(_lIII11l, 1) = _l1d_55a757("5b", 182, 194) then return _ll1lI1l + _lIII11l
_lI1lI1l = Len(_ll1lI1l) + 1
if _lI1lI1l > Len(_llII11l) then return _ll1lI1l + _l1d_55a757("23", 61, 17) + _lIII11l
_l11lI1l = Mid(_llII11l, _lI1lI1l + 1)
_llIlI1l = Instr(1, _l11lI1l, _l1d_55a757("8b", 77, 25))
if _llIlI1l > 0 then _l11lI1l = Left(_l11lI1l, _llIlI1l - 1)
_l1II11l = Instr(1, _l11lI1l, _l1d_55a757("81", 25, 71))
if _l1II11l > 0 then _l11lI1l = Left(_l11lI1l, _l1II11l - 1)
_lIllI1l = 0
for _l1llI1l = 1 to Len(_l11lI1l)
if Mid(_l11lI1l, _l1llI1l, 1) = _l1d_55a757("e6", 183, 78) then _lIllI1l = _l1llI1l
end for
if _lIllI1l = 0 then return _ll1lI1l + _l1d_55a757("2f", 206, 78) + _lIII11l
return _ll1lI1l + _l1d_55a757("8b", 30, 90) + Left(_l11lI1l, _lIllI1l) + _lIII11l
end function
function RP_ResolveLookmovie(_l111lIl as String, _l1IIlIl as String, _llll1Il as Object) as Object
_llI1lIl = {}
if _l1IIlIl <> "" then _llI1lIl[_l1d_55a757("51696b6f7d7583", 11, 248)] = _l1IIlIl else _llI1lIl[_l1d_55a757("304042465c4c62", 7, 219)] = _l111lIl
_lI1IlIl = HC_Get(_llll1Il, _l111lIl, _llI1lIl, 8000)
if _lI1IlIl = invalid or _lI1IlIl.body = "" then return invalid
_lI11lIl = _lI1IlIl.finalUrl
if _lI11lIl = invalid or _lI11lIl = "" then _lI11lIl = _l111lIl
_l11IlIl = CreateObject(_l1d_55a757("1836fe32373830", 145, 53), _l1d_55a757("11071b13e6dd26162432202e2f3304fb36fd4b035309510f5915602b213634643a4a3f3927293d7c8f838b878643", 157, 25), _l1d_55a757("b1", 179, 215))
_llIIlIl = _l11IlIl.match(_lI1IlIl.body)
if _llIIlIl = invalid or _llIIlIl.Count() < 1 then return invalid
_lIll1Il = JU_UnpackPacked(_llIIlIl[0])
if _lIll1Il = "" then return invalid
_lllIlIl = {}
_lII1lIl = CreateObject(_l1d_55a757("48686e64696a60", 176, 134), chr(34) + _l1d_55a757("fec1c0ceb9131717c31a", 198, 16) + chr(34) + _l1d_55a757("5a3e0afd664a16", 187, 115) + chr(34) + _l1d_55a757("aa9aa2", 227, 223) + chr(34) + _l1d_55a757("83f4f5", 216, 254) + chr(34), _l1d_55a757("1310", 178, 56))
_l1lIlIl = _lII1lIl.matchAll(_lIll1Il)
if _l1lIlIl <> invalid then
for each _lIlIlIl in _l1lIlIl
if _lIlIlIl.Count() < 3 then continue for
_lllIlIl[_lIlIlIl[1]] = RP_UnescapeSlashes(_lIlIlIl[2])
end for
end if
_ll1IlIl = [_l1d_55a757("757c7437", 153, 132), _l1d_55a757("dfe6f034", 192, 55), _l1d_55a757("d5dcd014", 251, 66)]
for each _l1I1lIl in _ll1IlIl
_l1ll1Il = _lllIlIl[_l1I1lIl]
if _l1ll1Il = invalid or _l1ll1Il = "" then continue for
_l1ll1Il = RP_AbsUrl(_l1ll1Il, _lI11lIl)
_lIIIlIl = HC_Get(_llll1Il, _l1ll1Il, { "Referer": _lI11lIl }, 6000)
if _lIIIlIl = invalid or _lIIIlIl.body = "" then continue for
if Left(_lIIIlIl.body, 7) <> _l1d_55a757("2546665d574465", 135, 129) then continue for
return {
url: _l1ll1Il
streamFormat: _l1d_55a757("e0e7cd", 178, 6)
qualities: []
subtitles: RP_ExtractSubs(_lI1IlIl.body)
chapters: []
referer: _lI11lIl
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidora(_lIllIIl as String, _llIlIIl as String, _l1IlIIl as Object) as Object
if ((9492 - 1582 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l11lIIl = {}
if _llIlIIl <> "" then _l11lIIl[_l1d_55a757("937f85857f8b85", 181, 172)] = _llIlIIl else _l11lIIl[_l1d_55a757("54222628402e46", 164, 94)] = _l1d_55a757("fbeaedecf0bcd2d5161b071b1a0b1c102af41d39fc", 145, 2)
_lI1lIIl = HC_Get(_l1IlIIl, _lIllIIl, _l11lIIl, 8000)
if _lI1lIIl = invalid or _lI1lIIl.body = "" then return invalid
_ll1lIIl = _lI1lIIl.finalUrl
if _ll1lIIl = invalid or _ll1lIIl = "" then _ll1lIIl = _lIllIIl
return RP_ResolveJwplayerPage(_lI1lIIl.body, _ll1lIIl, _ll1lIIl, _l1IlIIl)
end function
function RP_Resolve2embed(_lllIll1 as String, _llll1l1 as String, _l1ll1l1 as Object) as Object
if ((68499 - 7611 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lI1Ill1 = {}
if _llll1l1 <> "" then _lI1Ill1[_l1d_55a757("de18181e0a2410", 26, 150)] = _llll1l1 else _lI1Ill1[_l1d_55a757("d9c9cbcfc5d5cb", 247, 52)] = _l1d_55a757("242b2e353501eff23c4e364b3f4b420b5a5a13", 7, 181)
_lIIIll1 = HC_Get(_l1ll1l1, _lllIll1, _lI1Ill1, 8000)
if _lIIIll1 = invalid or _lIIIll1.body = "" then return invalid
_ll1Ill1 = _lIIIll1.finalUrl
if _ll1Ill1 = invalid or _ll1Ill1 = "" then _ll1Ill1 = _lllIll1
_lI1l1l1 = CreateObject(_l1d_55a757("0119e7151a1b19", 212, 91), _l1d_55a757("d2c0c69fa795ade4a1a3b79fadafc300efd4", 254, 252) + chr(34) + _l1d_55a757("0ee71fe2c9ccd3d71e263437e6e4edf90007f8fc0e01275c4b17222420243f7432357c2b2a47344e5d816868", 117, 188) + chr(34) + _l1d_55a757("87d48186d7", 187, 235) + chr(34) + _l1d_55a757("64b1", 187, 200), _l1d_55a757("3b", 38, 236))
_lIll1l1 = _lI1l1l1.match(_lIIIll1.body)
_llIl1l1 = ""
if _lIll1l1 <> invalid and _lIll1l1.Count() >= 2 then
_llIl1l1 = _lIll1l1[1]
else
_l1lIll1 = CreateObject(_l1d_55a757("2f271523282947", 4, 185), _l1d_55a757("3578676a696b3a3850537a827f9998a78c8ea29585765db7c2b6c0c29d8ec6c998bfc6dfc8e4bb9dbcc2c7dd", 146, 123) + chr(34) + _l1d_55a757("554142a85d62", 190, 188), _l1d_55a757("92", 202, 239))
_l11Ill1 = _l1lIll1.match(_lIIIll1.body)
if _l11Ill1 <> invalid and _l11Ill1.Count() >= 2 then _llIl1l1 = _l11Ill1[1]
end if
if _llIl1l1 = "" then return invalid
_llIl1l1 = U_HtmlDecode(_llIl1l1)
_ll1l1l1 = HC_Get(_l1ll1l1, _llIl1l1, { "Referer": _ll1Ill1 }, 8000)
if _ll1l1l1 = invalid or _ll1l1l1.body = "" then return invalid
_l11l1l1 = _ll1l1l1.finalUrl
if _l11l1l1 = invalid or _l11l1l1 = "" then _l11l1l1 = _llIl1l1
_llIIll1 = CreateObject(_l1d_55a757("354b1b4b4c5151", 87, 16), _l1d_55a757("6f1d2b3a2e2d385d65886c7954584a9b78", 235, 152) + chr(34) + _l1d_55a757("2e07370b13", 241, 88) + chr(34) + _l1d_55a757("6ca57e7fb4", 133, 202) + chr(34) + _l1d_55a757("12ef", 118, 193), _l1d_55a757("ce", 117, 178))
_lIlIll1 = _llIIll1.match(_ll1l1l1.body)
if _lIlIll1 = invalid or _lIlIll1.Count() < 2 then return invalid
_l1IIll1 = _lIlIll1[1]
_l1Il1l1 = ""
if Left(_l1IIll1, 4) = _l1d_55a757("bed5d8df", 173, 249) then
_l1Il1l1 = _l1IIll1
else
_l1Il1l1 = _l1d_55a757("d6dde0e7e9332326eaeceff6f7f80204fb4f461611161256135c", 230, 72) + _l1IIll1
end if
return RP_ResolveLookmovie(_l1Il1l1, _l11l1l1, _l1ll1l1)
end function
function RP_ResolveCloudnestra(_lll1Il1 as String, _l11ll11 as String, _lll1l11 as Object) as Object
if ((23512 - 5878 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lI1ll11 = _l11ll11
if _lI1ll11 = "" then _lI1ll11 = _lll1Il1
_lIlIIl1 = HC_Get(_lll1l11, _lll1Il1, { "Referer": _lI1ll11 }, 8000)
if _lIlIIl1 = invalid or _lIlIIl1.body = "" then return invalid
_ll11Il1 = _lIlIIl1.finalUrl
if _ll11Il1 = invalid or _ll11Il1 = "" then _ll11Il1 = _lll1Il1
_lIlll11 = CreateObject(_l1d_55a757("1131f72d323329", 16, 175), _l1d_55a757("0d11034f2c1c483a", 109, 239) + chr(34) + _l1d_55a757("b4f1c7c515160e1c1024da110f", 134, 19) + chr(34) + _l1d_55a757("d986d3d889", 75, 109) + chr(34) + _l1d_55a757("0720", 148, 84), _l1d_55a757("9c", 101, 144))
m = _lIlll11.match(_lIlIIl1.body)
if m = invalid or m.Count() < 2 then
_ll1ll11 = CreateObject(_l1d_55a757("171d3d292e2f1f", 125, 8), _l1d_55a757("97", 114, 110) + chr(34) + _l1d_55a757("748d8286b1b6cebcd0c09ab1af", 20, 65) + chr(34) + _l1d_55a757("c19ad3d4a9", 244, 238) + chr(34) + _l1d_55a757("8603", 39, 134), _l1d_55a757("34", 226, 169))
m = _ll1ll11.match(_lIlIIl1.body)
if m = invalid or m.Count() < 2 then return RP_ResolveGeneric(_lll1Il1, _l11ll11, _lll1l11)
end if
_lllll11 = m[1]
if Left(_lllll11, 1) <> _l1d_55a757("f9", 202, 20) then _lllll11 = _l1d_55a757("83", 176, 228) + _lllll11
_l1IIIl1 = RP_AbsUrl(_lllll11, _ll11Il1)
_ll1IIl1 = HC_Get(_lll1l11, _l1IIIl1, { "Referer": _ll11Il1 }, 8000)
if _ll1IIl1 = invalid or _ll1IIl1.body = "" then return invalid
_l111Il1 = _ll1IIl1.finalUrl
if _l111Il1 = invalid or _l111Il1 = "" then _l111Il1 = _l1IIIl1
_lIl1Il1 = CreateObject(_l1d_55a757("bbcba1dbdce1c7", 90, 147), _l1d_55a757("d6e0e6e236dff52f", 194, 50) + chr(34) + _l1d_55a757("1e7076", 58, 12) + chr(34) + _l1d_55a757("6edbe0", 211, 224) + chr(34), _l1d_55a757("af", 202, 12))
_lI11Il1 = _lIl1Il1.match(_ll1IIl1.body)
if _lI11Il1 = invalid or _lI11Il1.Count() < 2 then return invalid
_l1l1Il1 = _lI11Il1[1]
_lllIIl1 = CreateObject(_l1d_55a757("8d95b3a5a6ab99", 254, 1), chr(34) + _l1d_55a757("ada4a7aeb46e7e8185bcc8c9c5ce90e69bf3eca3dba4aca3b3b508c10dc21a13ca0220d9da", 188, 217) + chr(34), _l1d_55a757("b0c1", 41, 112))
_lII1Il1 = _lllIIl1.matchAll(_ll1IIl1.body)
_l1lIIl1 = []
_lIIll11 = {}
if _lII1Il1 <> invalid then
for each _l1I1Il1 in _lII1Il1
if _l1I1Il1.Count() < 2 then continue for
_llI1Il1 = _l1I1Il1[1]
if _lIIll11.DoesExist(_llI1Il1) then continue for
_lIIll11[_llI1Il1] = true
_l1lIIl1.Push(_llI1Il1)
end for
end if
if _l1lIIl1.Count() = 0 then _l1lIIl1.Push(_l1d_55a757("cec8cdd7d41816ccdedeebdfe7efe1efedfa0401f5030511014f051419", 67, 151))
_l1lll11 = []
_l1l1l11 = CreateObject(_l1d_55a757("948a7a8a8b90b0", 199, 223), _l1d_55a757("a48641808eb39550", 164, 172), _l1d_55a757("5e", 12, 249))
_lI1IIl1 = _l1l1l11.split(_l1l1Il1)
if _lI1IIl1 <> invalid then
for each _l11IIl1 in _lI1IIl1
_ll11l11 = U_Trim(_l11IIl1)
if _ll11l11 <> "" then _l1lll11.Push(_ll11l11)
end for
end if
_l1IlIl1 = []
_llIIIl1 = CreateObject(_l1d_55a757("b9d1dfd1d2d7d5", 54, 117), _l1d_55a757("ddc1b9e6d19defd1", 183, 242), _l1d_55a757("a2", 11, 54))
for each _lIIIIl1 in _l1lll11
if Instr(1, _lIIIIl1, _l1d_55a757("cdcb", 178, 4)) > 0 then
for each _llI1Il1 in _l1lIIl1
_lIIlIl1 = Instr(1, _llI1Il1, _l1d_55a757("98", 227, 203))
if _lIIlIl1 > 0 and _lIIlIl1 < Len(_llI1Il1) then
_lIl1l11 = Mid(_llI1Il1, _lIIlIl1 + 1)
else
_lIl1l11 = _llI1Il1
end if
_l1IlIl1.Push(_llIIIl1.replaceAll(_lIIIIl1, _lIl1l11))
end for
else
_l1IlIl1.Push(_lIIIIl1)
end if
end for
_l1Ill11 = {}
for each _l111l11 in _l1IlIl1
if _l111l11 = "" or _l1Ill11.DoesExist(_l111l11) then continue for
_l1Ill11[_l111l11] = true
_llIll11 = HC_Get(_lll1l11, _l111l11, { "Referer": _l111Il1 }, 6000)
if _llIll11 = invalid or _llIll11.body = "" then continue for
if Left(_llIll11.body, 7) <> _l1d_55a757("ab48363d49aa47", 92, 44) then continue for
return {
url: _l111l11
streamFormat: _l1d_55a757("3b3a26", 215, 124)
qualities: []
subtitles: RP_ExtractSubs(_ll1IIl1.body)
chapters: []
referer: _l111Il1
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidsrcXyz(_llIIl11 as String, _ll1l111 as String, _llIl111 as Object) as Object
_l11l111 = _ll1l111
if _l11l111 = "" then _l11l111 = _l1d_55a757("434245444680989b555f6d5b5d71af7175b9", 218, 145)
_lIIIl11 = HC_Get(_llIl111, _llIIl11, { "Referer": _l11l111 }, 8000)
if _lIIIl11 = invalid or _lIIIl11.body = "" then return invalid
_l1IIl11 = _lIIIl11.finalUrl
if _l1IIl11 = invalid or _l1IIl11 = "" then _l1IIl11 = _llIIl11
_l1ll111 = CreateObject(_l1d_55a757("927a78868b8c9a", 204, 212), _l1d_55a757("55a5a594a6b5b0898f729485c6c480a1", 144, 169) + chr(34) + _l1d_55a757("ed8aa2c1b7b2c1af9dceccbbcfded9ae", 211, 249) + chr(34) + _l1d_55a757("c3ccd5d5b8d8d10c1022c7f0", 29, 137) + chr(34) + _l1d_55a757("3e5b495b61", 18, 9) + chr(34) + _l1d_55a757("13d01d22d3", 194, 46) + chr(34) + _l1d_55a757("85f2", 47, 125), _l1d_55a757("87", 214, 200))
m = _l1ll111.match(_lIIIl11.body)
if m = invalid or m.Count() < 2 then
_lIll111 = CreateObject(_l1d_55a757("e7df0ddfe0e503", 230, 83), _l1d_55a757("696d7fa44d", 221, 187) + chr(34) + _l1d_55a757("0069ff01047b79", 44, 245) + chr(34) + _l1d_55a757("7c598d49515340525b594e4e53698280", 246, 171) + chr(34) + _l1d_55a757("f0d9f2f3e8", 108, 165) + chr(34) + _l1d_55a757("0916", 30, 208), _l1d_55a757("61", 17, 233))
m = _lIll111.match(_lIIIl11.body)
end if
if m <> invalid and m.Count() >= 2 then
_llll111 = RP_AbsUrl(m[1], _l1IIl11)
_lI1l111 = RP_ResolveCloudnestra(_llll111, _l1IIl11, _llIl111)
if _lI1l111 <> invalid and _lI1l111.url <> "" then return _lI1l111
end if
_lI1Il11 = R_FollowKnownIframes(_lIIIl11.body, _l1IIl11, _l11l111, 0, _llIl111)
if _lI1Il11 <> invalid and _lI1Il11.url <> invalid and _lI1Il11.url <> "" then return _lI1Il11
return RP_ResolveGeneric(_llIIl11, _ll1l111, _llIl111)
end function
function RP_ResolveMoviesapi(_l111I11 as String, _l1I1I11 as String, _lllII11 as Object) as Object
if ((46430 - 9286 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lII1I11 = _l1I1I11
if _lII1I11 = "" then _lII1I11 = _l1d_55a757("6180838288c2babd798d8b9c8e8897d4abb1de", 72, 65)
_llI1I11 = HC_Get(_lllII11, _l111I11, { "Referer": _lII1I11 }, 8000)
if _llI1I11 = invalid or _llI1I11.body = "" then return invalid
_lI11I11 = _llI1I11.finalUrl
if _lI11I11 = invalid or _lI11I11 = "" then _lI11I11 = _l111I11
_ll11I11 = R_FollowKnownIframes(_llI1I11.body, _lI11I11, _lII1I11, 0, _lllII11)
if _ll11I11 <> invalid and _ll11I11.url <> invalid and _ll11I11.url <> "" then return _ll11I11
return RP_ResolveJwplayerPage(_llI1I11.body, _lI11I11, _lII1I11, _lllII11)
end function
function RP_ResolveAutoembed(_l11l1I1 as String, _ll111I1 as String, _l1I11I1 as Object) as Object
_l1ll1I1 = _l1d_55a757("0efd00ffffcbe1e428241c1b2b303a3042422f4344444639554e1e54636829", 19, 147)
_l1l11I1 = CreateObject(_l1d_55a757("220a08161b1c2a", 140, 36), _l1d_55a757("662f2a3a383a787c3c413b49503a454a98999d5457326daf5b3e79bbbcbeb0b6c6ca5994d6d7d8dc6ba6e8e9ecdd", 220, 115), _l1d_55a757("e7", 203, 69))
m = _l1l11I1.match(_l11l1I1)
if m = invalid or m.Count() < 3 then return invalid
_lll11I1 = m[1]
_lIIl1I1 = m[2]
_llI11I1 = ""
_llIl1I1 = ""
if m.Count() >= 5 then
_llI11I1 = m[3]
_llIl1I1 = m[4]
end if
_l1Il1I1 = _l1d_55a757("f1ede7e8", 96, 221)
if Left(_lIIl1I1, 2) = _l1d_55a757("8f92", 60, 71) then _l1Il1I1 = _l1d_55a757("9897919a", 180, 187)
_lIll1I1 = _l1d_55a757("8b8a8d8c8cc8dee198a29fb7b6b5c1bfb7c503becec2d1d7c2e1cf1ed5dd26efe3ed33ecf7f22e", 123, 120) + _l1Il1I1 + _l1d_55a757("3c", 142, 137) + U_UrlEncode(_lIIl1I1) + _l1d_55a757("d1261e2820eb", 170, 69) + _lll11I1
if _lll11I1 = _l1d_55a757("0708", 43, 168) and _llI11I1 <> "" and _llIl1I1 <> "" then
_lIll1I1 = _lIll1I1 + _l1d_55a757("663429283d2c3080", 73, 247) + _llI11I1 + _l1d_55a757("7438303a333a484a75", 95, 251) + _llIl1I1
end if
_l1111I1 = HC_Get(_l1I11I1, _lIll1I1, {
"Referer": _l1ll1I1
"Origin": _l1d_55a757("aaa9acabad677f82c4d2b8c7d9ded6dedee0ddeff0f2f2e5f3fcba020106", 26, 56)
}, 8000)
if _l1111I1 = invalid or _l1111I1.body = "" then return invalid
_lI1l1I1 = ParseJSON(_l1111I1.body)
if _lI1l1I1 = invalid or type(_lI1l1I1) <> _l1d_55a757("effde2f7fa091009140c12142403191c2c17", 217, 68) then return invalid
_lI111I1 = ""
if _lI1l1I1.status_code <> invalid then _lI111I1 = _lI1l1I1.status_code.ToStr()
if _lI111I1 <> _l1d_55a757("565b5e", 134, 162) then return invalid
_ll1l1I1 = _lI1l1I1.data
if _ll1l1I1 = invalid or type(_ll1l1I1) <> _l1d_55a757("b7c7f0c1c4d3dad7e2d8e0dcf211e1e4fae5", 122, 175) then return invalid
_lII11I1 = _ll1l1I1.stream_urls
if _lII11I1 = invalid or type(_lII11I1) <> _l1d_55a757("8e9cc1979aaa95", 185, 195) or _lII11I1.Count() = 0 then return invalid
for each _lllI1I1 in _lII11I1
if type(_lllI1I1) <> _l1d_55a757("c4a2abb3b5bf", 189, 214) and type(_lllI1I1) <> _l1d_55a757("e5ed0cecf1fffb07", 254, 89) then continue for
if _lllI1I1 = "" then continue for
_lIl11I1 = HC_Get(_l1I11I1, _lllI1I1, { "Referer": _l1ll1I1 }, 6000)
if _lIl11I1 = invalid or _lIl11I1.body = "" then continue for
if Left(_lIl11I1.body, 7) <> _l1d_55a757("411e3c332f603d", 100, 250) then continue for
return {
url: _lllI1I1
streamFormat: _l1d_55a757("535242", 21, 214)
qualities: []
subtitles: []
chapters: []
referer: _l1ll1I1
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveYthd(_lII1II1 as String, _l1IIII1 as String, _lIIIII1 as Object) as Object
_l1lIII1 = {}
if _l1IIII1 <> "" then _l1lIII1[_l1d_55a757("bad0d4d6e6dcec", 200, 32)] = _l1IIII1
_l11III1 = HC_Get(_lIIIII1, _lII1II1, _l1lIII1, 8000)
if _l11III1 = invalid or _l11III1.body = "" then return invalid
_lIlIII1 = CreateObject(_l1d_55a757("210f471f20252d", 107, 8), _l1d_55a757("435a58535a547a6f6960707772", 181, 126) + chr(34) + _l1d_55a757("9ec893ced0e491", 24, 90) + chr(34) + _l1d_55a757("dbdeda1016ea", 8, 180) + chr(34) + _l1d_55a757("70090a0b6b5d6f171d9191", 173, 128) + chr(34) + _l1d_55a757("9f9499", 23, 85) + chr(34), _l1d_55a757("3b", 14, 212))
_ll1III1 = _lIlIII1.match(_l11III1.body)
if _ll1III1 <> invalid and _ll1III1.Count() >= 3 then
_lI1III1 = _l1d_55a757("6e55585f612b3b3e", 22, 240) + _ll1III1[1] + _l1d_55a757("d61c1024e2", 130, 41) + _ll1III1[2]
return RP_ResolveCloudnestra(_lI1III1, _lII1II1, _lIIIII1)
end if
_llIIII1 = CreateObject(_l1d_55a757("66564c6267686e", 8, 236), _l1d_55a757("3d43534980485263519f", 79, 18) + chr(34) + _l1d_55a757("950705", 166, 7) + chr(34) + _l1d_55a757("58696a", 104, 35) + chr(34), _l1d_55a757("90", 171, 206))
m = _llIIII1.match(_l11III1.body)
if m = invalid or m.Count() < 2 then return invalid
_lllIII1 = m[1]
_lI1III1 = _l1d_55a757("dedde0dfe19bb3b6fdfdfffc0e08fe120e1e0b13102622262032ee36353afb31453907", 58, 140) + _lllIII1
return RP_ResolveCloudnestra(_lI1III1, _lII1II1, _lIIIII1)
end function
function RP_ResolveVidking(_llIl1lI as String, _l1l11lI as String, _l1111lI as Object) as Object
_lll11lI = CreateObject(_l1d_55a757("6d555365666b79", 14, 241), _l1d_55a757("1cd5e0e2dee22e34f2f7e3fff6f2edf24e4f55e40f5f0d080bf621717276666e7c82113c8c8d8e94234e9e9fa293", 85, 162), _l1d_55a757("3f", 237, 187))
m = _lll11lI.match(_llIl1lI)
if m = invalid or m.Count() < 3 then return invalid
_lIIl1lI = m[1]
_lI111lI = m[2]
_lIl11lI = ""
_l1Il1lI = ""
if m.Count() >= 5 then
_lIl11lI = m[3]
_l1Il1lI = m[4]
end if
_ll111lI# = B_StrToLong(_lI111lI)
return RP_VideasyFamilyResolve(_lIIl1lI, _lI111lI, _lIl11lI, _l1Il1lI, _ll111lI#, _lI111lI, _l1111lI)
end function
function RP_ResolveVideasy(_l11IIlI as String, _lIIIIlI as String, _lIlll1I as Object) as Object
_l1IIIlI = CreateObject(_l1d_55a757("41276733383949", 237, 162), _l1d_55a757("97a1dfe0dcecf3dfeaebbbb8c2d10cc8cdd1bdc5d3ddec27e3e8e5effe39f5fafdea", 31, 103), _l1d_55a757("cd", 142, 230))
m = _l1IIIlI.match(_l11IIlI)
if m = invalid or m.Count() < 3 then return invalid
_llIIIlI = m[1]
_ll1ll1I = m[2]
_lllll1I = ""
_lI1IIlI = ""
if m.Count() >= 5 then
_lllll1I = m[3]
_lI1IIlI = m[4]
end if
_l1lll1I# = B_StrToLong(_ll1ll1I)
return RP_VideasyFamilyResolve(_llIIIlI, _ll1ll1I, _lllll1I, _lI1IIlI, _l1lll1I#, _ll1ll1I, _lIlll1I)
end function
function RP_VideasyFamilyResolve(_llI111I as String, _lIl1I1I as String, _llllI1I as String, _l11111I as String, _l1llI1I as LongInteger, _lIllI1I as String, _ll1lI1I as Object) as Object
_l1lI11I = _l1d_55a757("162528272b776d702a2b7a4539393b3a4f58925b579aa1a0", 225, 141) + _llI111I + _l1d_55a757("a8", 216, 177) + _lIl1I1I + _l1d_55a757("30fdeff2020e07e5fd1bee0c1a13132d2f1f2c673230273b334a484e24594f49", 84, 197)
_lllI11I = HC_Get(_ll1lI1I, _l1lI11I, {}, 6000)
_l1l1I1I = ""
_l111I1I = ""
_lI1111I = ""
if _lllI11I <> invalid and _lllI11I.body <> "" then
_lII111I = ParseJSON(_lllI11I.body)
if type(_lII111I) = _l1d_55a757("93a1ca9b9eadb4b1bcb4bab8ccebbdc0d4bf", 251, 10) then
if _llI111I = _l1d_55a757("d4d5bfe1d8", 182, 249) and _lII111I.title <> invalid then _l1l1I1I = _lII111I.title
if _llI111I = _l1d_55a757("4243", 247, 191) and _lII111I.name <> invalid then _l1l1I1I = _lII111I.name
if _llI111I = _l1d_55a757("c1c2dcced5", 14, 94) and _lII111I.release_date <> invalid then _l111I1I = Left(_lII111I.release_date, 4)
if _llI111I = _l1d_55a757("8081", 135, 141) and _lII111I.first_air_date <> invalid then _l111I1I = Left(_lII111I.first_air_date, 4)
if _lII111I.external_ids <> invalid and type(_lII111I.external_ids) = _l1d_55a757("cbdb00d5d8e7eee7f2e8f0f00221f5f80af5", 120, 193) then
if _lII111I.external_ids.imdb_id <> invalid then _lI1111I = _lII111I.external_ids.imdb_id
end if
end if
end if
_llII11I = [_l1d_55a757("4a5a105c555d6f", 140, 105), _l1d_55a757("070d1a", 33, 197), _l1d_55a757("5c66716b70726b717581c4", 98, 86)]
_lIl111I = {
"Referer": _l1d_55a757("1211141317d3e9ec223137224133023d4151535247401a535f22", 25, 161)
"Origin": _l1d_55a757("5d6c6f6e72beb4b77d7c728d7c8ecd988c8c8e8da2abe5aeaa", 225, 212)
"Accept": _l1d_55a757("020808", 139, 97)
}
for each _lI1I11I in _llII11I
_ll11I1I = _l1d_55a757("e9d8dbdade2a4043f8ec0650fb0f0f1110050e68112d70", 241, 80) + _lI1I11I + _l1d_55a757("a279688181757a8bb8957a987fc7a189a7929eebb39bb9a4b0fb", 200, 187) + U_UrlEncode(_l1l1I1I) + _l1d_55a757("034f4a4e5c574775715f3a", 7, 226) + _llI111I + _l1d_55a757("d7071e2517cf", 159, 30) + U_UrlEncode(_l111I1I)
if _llI111I = _l1d_55a757("b0b1", 238, 22) then
_ll1111I = _l1d_55a757("44", 32, 51)
_l11lI1I = _l1d_55a757("01", 202, 6)
if _l11111I <> "" then _ll1111I = _l11111I
if _llllI1I <> "" then _l11lI1I = _llllI1I
_ll11I1I = _ll11I1I + _l1d_55a757("73b9c7c3cccbc7cbf2d0ac", 162, 239) + _ll1111I + _l1d_55a757("f52d3a41364d4f354b07", 20, 195) + _l11lI1I
end if
_ll11I1I = _ll11I1I + _l1d_55a757("8edfc9d5d6aedea8", 137, 223) + _lIl1I1I + _l1d_55a757("f1b7beb8b9a3c11d", 64, 139) + U_UrlEncode(_lI1111I)
_l1II11I = HC_Get(_ll1lI1I, _ll11I1I, _lIl111I, 8000)
if _l1II11I = invalid or _l1II11I.body = "" then continue for
_l11I11I = RP_VideasyDecrypt(U_Trim(_l1II11I.body), _l1llI1I)
if _l11I11I = "" then continue for
_ll1I11I = ParseJSON(_l11I11I)
if _ll1I11I = invalid or type(_ll1I11I) <> _l1d_55a757("f0f0c5fafdfcf3fcf70d051507e61a1d0f2a", 64, 190) then continue for
_lI1lI1I = _ll1I11I.sources
if _lI1lI1I = invalid or type(_lI1lI1I) <> _l1d_55a757("fe06f7070a200b", 222, 82) or _lI1lI1I.Count() = 0 then continue for
_l1IlI1I = ""
for each _llIlI1I in _lI1lI1I
if type(_llIlI1I) <> _l1d_55a757("02f0d50a0dfc03fc071f052717f62c2f1f2a", 9, 135) then continue for
if _llIlI1I.url <> invalid and _llIlI1I.url <> "" then
_l1IlI1I = _llIlI1I.url
exit for
end if
if _llIlI1I.file <> invalid and _llIlI1I.file <> "" then
_l1IlI1I = _llIlI1I.file
exit for
end if
end for
if _l1IlI1I = "" then continue for
_lIIlI1I = []
if _ll1I11I.subtitles <> invalid and type(_ll1I11I.subtitles) = _l1d_55a757("59413262655b66", 14, 221) then
for each _lIII11I in _ll1I11I.subtitles
if type(_lIII11I) <> _l1d_55a757("b3c1e6bbbecdd4cdd8d0d6d8e807dde0f0db", 185, 232) then continue for
_lll1I1I = ""
if _lIII11I.url <> invalid then _lll1I1I = _lIII11I.url
if _lll1I1I = "" and _lIII11I.file <> invalid then _lll1I1I = _lIII11I.file
if _lll1I1I = "" then continue for
_l1I111I = _l1d_55a757("bbc5", 163, 245)
if _lIII11I.language <> invalid then _l1I111I = LCase(Left(_lIII11I.language, 2))
if _l1I111I = "" and _lIII11I.lang <> invalid then _l1I111I = LCase(Left(_lIII11I.lang, 2))
_lIlI11I = ""
if _lIII11I.label <> invalid then _lIlI11I = _lIII11I.label
if _lIlI11I = "" then _lIlI11I = UCase(_l1I111I)
_lIIlI1I.Push({ url: _lll1I1I, language: _l1I111I, name: _lIlI11I })
end for
end if
return {
url: _l1IlI1I
streamFormat: U_StreamFormat(_l1IlI1I)
qualities: []
subtitles: _lIIlI1I
chapters: []
referer: _l1d_55a757("92a1a4a3a56f676ab2b1a9c4b3bf7ec9c3c1c5c4d5e296d9d7e9a3", 34, 72)
userAgent: ""
}
end for
return invalid
end function
function RP_VideasyDecrypt(_llIllII as String, _llIIlII as LongInteger) as String
if _llIllII = invalid or _llIllII = "" then return ""
_l11llII = CreateObject(_l1d_55a757("afcde5bdbdcfeec4c7d7d2", 113, 172))
_l11llII.FromHexString(_llIllII)
if _l11llII.Count() = 0 then return ""
_lI11lII = RP_VkLcgBytes(_llIIlII, 50)
_l1I1lII = RP_VkSerializeBytes(_lI11lII)
_llI1lII = CreateObject(_l1d_55a757("453d1b594f432a5a5d536e", 134, 81))
_llI1lII.FromAsciiString(_l1I1lII)
_l111lII = _l1d_55a757("89808d9393c399c99fd2a1a6aeaab1b7b8babdc3c4c2cac9cfd5d1d6dde1e117e7ebede7f329f9ffff0506040c0b0d1313184d1e1a56202b255e313637703d4249474d4753555a588c5f94676ba1", 138, 203)
_ll11lII = CreateObject(_l1d_55a757("f4e2caf606f8d7090c000b", 203, 59))
_ll11lII.FromHexString(_l111lII)
_ll1IlII = R4_KSA(_ll11lII)
_lIIllII = R4_PRGA(_ll1IlII, _llI1lII)
_l11IlII = R4_KSA(_lIIllII)
_l1IIlII = R4_PRGA(_l11IlII, _l11llII)
if _l1IIlII.Count() < 32 then return ""
if _l1IIlII[0] <> 83 or _l1IIlII[1] <> 97 or _l1IIlII[2] <> 108 or _l1IIlII[3] <> 116 then return ""
if _l1IIlII[4] <> 101 or _l1IIlII[5] <> 100 or _l1IIlII[6] <> 95 or _l1IIlII[7] <> 95 then return ""
_lI1IlII = B_Slice(_l1IIlII, 8, 16)
_lllllII = B_Slice(_l1IIlII, 16, _l1IIlII.Count())
_l1lIlII = CreateObject(_l1d_55a757("305066403e527145485a55", 112, 46))
_l1l1lII = EvpBytesToKey(_l1lIlII, _lI1IlII, 32)
if _l1l1lII.Count() < 32 then return ""
_lIl1lII = B_Slice(_l1l1lII, 0, 16)
_lll1lII = B_Slice(_l1l1lII, 16, 32)
_lIlllII = _lIl1lII.ToHexString()
_l1lllII = _lll1lII.ToHexString()
_ll1llII = CreateObject(_l1d_55a757("6f8fac9c9daf9c86a1a18d", 242, 239))
_lIlIlII = _ll1llII.Setup(false, _l1d_55a757("f0f7e4c5acaebbd1060a0c", 179, 30), _lIlllII, _l1lllII, 1)
if _lIlIlII <> 0 then return ""
_lII1lII = CreateObject(_l1d_55a757("a8aedeaab2c4ebbdc0d4bf", 255, 27))
_lllIlII = _ll1llII.Process(_lllllII)
if _lllIlII <> invalid then
for _l1IllII = 0 to _lllIlII.Count() - 1
_lII1lII.Push(_lllIlII[_l1IllII])
end for
end if
_lI1llII = _ll1llII.Final()
if _lI1llII <> invalid then
for _l1IllII = 0 to _lI1llII.Count() - 1
_lII1lII.Push(_lI1llII[_l1IllII])
end for
end if
if _lII1lII.Count() = 0 then return ""
return _lII1lII.ToAsciiString()
end function
function RP_VkLcgBytes(_lIlI1II as LongInteger, _lII11II as Integer) as Object
_l1lI1II = CreateObject(_l1d_55a757("27273d3b392d4c3c3f3550", 98, 23))
_ll1I1II# = _lIlI1II AND 2147483647&
for _lllI1II = 1 to _lII11II
_ll1I1II# = (_ll1I1II# * 1103515245& + 12345&) AND 2147483647&
_l1I11II# = _ll1I1II# mod 255&
_l1lI1II.Push(_l1I11II#)
end for
return _l1lI1II
end function
function RP_VkSerializeBytes(_lI1llll as Object) as String
if ((46755 - 9351 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lI1llll = invalid or _lI1llll.Count() = 0 then return ""
_lIIllll = ""
_l1Illll = _lI1llll.Count()
for _llIllll = 0 to _l1Illll - 1
if _llIllll > 0 then _lIIllll = _lIIllll + _l1d_55a757("11", 199, 38)
_lIIllll = _lIIllll + _lI1llll[_llIllll].ToStr()
end for
return _lIIllll
end function
function RP_ResolvePeachify(_l11I1ll as String, _lll1Ill as String, _l111Ill as Object) as Object
_ll1lIll = CreateObject(_l1d_55a757("45432b43444961", 195, 148), _l1d_55a757("c5cf0d0e0a1a210d1819e9e6f0ff3af6283336114c080d11fd05131d2c672328252f3e79353a3d2a", 159, 21), _l1d_55a757("f2", 49, 154))
m = _ll1lIll.match(_l11I1ll)
if m = invalid or m.Count() < 3 then return invalid
_lIII1ll = m[1]
_l1lIIll = m[2]
_ll11Ill = ""
_llII1ll = ""
if m.Count() >= 5 then
_ll11Ill = m[3]
_llII1ll = m[4]
end if
_lIIlIll = [
{ host: _l1d_55a757("3a374c0a56554d174f65646563285e7264", 187, 108),  path: _l1d_55a757("bdc1c7cab8", 179, 226) },
{ host: _l1d_55a757("bebfc40edad9d11bd3e9e8e9e72ce2f6e8", 91, 144),  path: _l1d_55a757("b8b9a3c5bcc0c8c0", 182, 221) },
{ host: _l1d_55a757("434035713f3e5480564e4d4e4a8f67596d", 74, 4),  path: _l1d_55a757("2a45314c3a", 141, 74) },
{ host: _l1d_55a757("4d4e539d697060aa6a787f807ebb798d7f", 223, 163),  path: _l1d_55a757("071103", 220, 85) },
{ host: _l1d_55a757("a5a2b775c1c0b882bad0cfd0ce93c9ddcf", 187, 215),  path: _l1d_55a757("010c1a", 133, 29) }
]
_l1II1ll = {
"Referer": _l1d_55a757("2b1a1d1c226c84872b4342474f535349a14a684cae", 112, 19)
"Origin": _l1d_55a757("8f76798084505e618f9da4a9b3b5afab7da6c2b0", 21, 18)
"Accept": _l1d_55a757("998d909f9da6aba3a9aeb2f4b4aebdc1", 123, 127)
}
for each _l1IlIll in _lIIlIll
_lIlIIll = _l1d_55a757("beadb0afb37f9598", 17, 69) + _l1IlIll.host + _l1d_55a757("07", 114, 170) + _l1IlIll.path + _l1d_55a757("e8", 35, 220) + _lIII1ll + _l1d_55a757("e1", 31, 177) + _l1lIIll
if _lIII1ll = _l1d_55a757("b6b7", 62, 108) and _ll11Ill <> "" and _llII1ll <> "" then
_lIlIIll = _lIlIIll + _l1d_55a757("6e", 143, 206) + _ll11Ill + _l1d_55a757("4c", 36, 65) + _llII1ll
end if
_l1l1Ill = HC_Get(_l111Ill, _lIlIIll, _l1II1ll, 8000)
if _l1l1Ill = invalid or _l1l1Ill.body = "" then continue for
_lI1I1ll = ParseJSON(_l1l1Ill.body)
if _lI1I1ll = invalid or type(_lI1I1ll) <> _l1d_55a757("010738090c13221f2a1a281e32592b2e422d", 255, 116) then continue for
if _lI1I1ll.isEncrypted <> true then continue for
_ll1I1ll = _lI1I1ll.data
if _ll1I1ll = invalid or type(_ll1I1ll) <> _l1d_55a757("b0a695b3bcb4b6b0", 69, 121) then continue for
_llIlIll = RP_PeachifyDecrypt(_ll1I1ll)
if _llIlIll = "" then continue for
_l11lIll = ParseJSON(_llIlIll)
if _l11lIll = invalid or type(_l11lIll) <> _l1d_55a757("1c02ef24270e1d1621311f39291046493944", 205, 93) then continue for
_lI11Ill = _l11lIll.sources
if _lI11Ill = invalid or type(_lI11Ill) <> _l1d_55a757("7664897f82727d", 105, 91) or _lI11Ill.Count() = 0 then continue for
_l1I1Ill = ""
for each _llI1Ill in _lI11Ill
if type(_llI1Ill) <> _l1d_55a757("7161467b7e6d746d788e769688679b9e909b", 72, 55) then continue for
if _llI1Ill.url <> invalid and _llI1Ill.url <> "" then
_l1I1Ill = _llI1Ill.url
exit for
end if
if _llI1Ill.file <> invalid and _llI1Ill.file <> "" then
_l1I1Ill = _llI1Ill.file
exit for
end if
end for
if _l1I1Ill = "" then continue for
_lII1Ill = []
if _l11lIll.subtitles <> invalid and type(_l11lIll.subtitles) = _l1d_55a757("d1c9a6daddcfea", 132, 219) then
for each _lIl1Ill in _l11lIll.subtitles
if type(_lIl1Ill) <> _l1d_55a757("7583a87d808f968f9a92989aaac99fa2b29d", 57, 42) then continue for
_lllIIll = ""
if _lIl1Ill.url <> invalid then _lllIIll = _lIl1Ill.url
if _lllIIll = "" and _lIl1Ill.file <> invalid then _lllIIll = _lIl1Ill.file
if _lllIIll = "" then continue for
_llllIll = _l1d_55a757("eeea", 220, 53)
if _lIl1Ill.language <> invalid then _llllIll = LCase(Left(_lIl1Ill.language, 2))
_lIllIll = ""
if _lIl1Ill.label <> invalid then _lIllIll = _lIl1Ill.label
if _lIllIll = "" then _lIllIll = UCase(_llllIll)
_lII1Ill.Push({ url: _lllIIll, language: _llllIll, name: _lIllIll })
end for
end if
_lI1lIll = U_StreamFormat(_l1I1Ill)
_l1llIll = LCase(_l1I1Ill)
if Instr(1, _l1llIll, _l1d_55a757("f4390248", 98, 229)) > 0 then
_lI1lIll = _l1d_55a757("232234", 36, 215)
else if Instr(1, _l1llIll, _l1d_55a757("f6f635", 223, 68)) > 0 then
_lI1lIll = _l1d_55a757("7795d4", 108, 118)
end if
return {
url: _l1I1Ill
streamFormat: _lI1lIll
qualities: []
subtitles: _lII1Ill
chapters: []
referer: _l1d_55a757("6c6b6e6d712d43467c9291969092a488629ba79d6d", 57, 27)
userAgent: ""
}
end for
return invalid
end function
function RP_PeachifyDecrypt(_lI11l1l as String) as String
if _lI11l1l = invalid or _lI11l1l = "" then return ""
_l111l1l = _lI11l1l.Tokenize(_l1d_55a757("33", 239, 114))
if _l111l1l = invalid or _l111l1l.Count() < 3 then return ""
_lIl1l1l = HC_Base64UrlDecode(_l111l1l[0])
_l1l1l1l = HC_Base64UrlDecode(_l111l1l[1])
_l1I1l1l = HC_Base64UrlDecode(_l111l1l[2])
if _lIl1l1l.Count() <> 12 then return ""
if _l1I1l1l.Count() <> 16 then return ""
_ll11l1l = _l1d_55a757("ed47f443f94cfc560960096163636e6a70217423762a7d32893b924293459f489d50a053a75ab265b96cb96fc374ce77d47e8389d990dc95e498eea1f5a2fba7", 226, 106)
_llI1l1l = AGD_Decrypt(_ll11l1l, _lIl1l1l, _l1l1l1l, _l1I1l1l)
if _llI1l1l = invalid then return ""
return _llI1l1l.ToAsciiString()
end function
function RP_ResolvePrimesrc(_lIII11l as String, _llllI1l as String, _l1llI1l as Object) as Object
return invalid
end function
function RP_ResolveStreamtape(_lIlIlIl as String, _l11l1Il as String, _lI1l1Il as Object) as Object
_l11IlIl = CreateObject(_l1d_55a757("3b5b215b5c6157", 146, 91), _l1d_55a757("b42bf0062ec3c93d06cd272fd650e9dff657e85bf4f5", 37, 170), _l1d_55a757("40", 233, 192))
_l1IIlIl = _l11IlIl.match(_lIlIlIl)
if _l1IIlIl = invalid or _l1IIlIl.Count() < 2 then return invalid
_l1lIlIl = _l1d_55a757("72898c93934f3d409fa1a6969d94b0a6baa862b0a7ac6dba73", 47, 43) + _l1IIlIl[1]
_ll1IlIl = {}
if _l11l1Il <> "" then _ll1IlIl[_l1d_55a757("db131519071f0d", 91, 210)] = _l11l1Il
_lIIIlIl = HC_Get(_lI1l1Il, _l1lIlIl, _ll1IlIl, 8000)
if _lIIIlIl = invalid or _lIIIlIl.body = "" then return invalid
_lII1lIl = _l1d_55a757("212f261b36313d26833f403266504c57525e4778528563aaac5a7a70806883838b8bcacfd7959da09a8ac3b2ced0e7e7edf7", 112, 13)
_lI1IlIl = Instr(1, _lIIIlIl.body, _lII1lIl)
if _lI1IlIl <= 0 then return invalid
_llI1lIl = Mid(_lIIIlIl.body, _lI1IlIl + Len(_lII1lIl))
_lIll1Il = Instr(1, _llI1lIl, _l1d_55a757("38", 148, 133))
if _lIll1Il <= 0 then return invalid
_llll1Il = Left(_llI1lIl, _lIll1Il - 1)
_lllIlIl = _l1d_55a757("d9d7e2de38202a", 131, 49)
_llIIlIl = Instr(1, _llI1lIl, _lllIlIl)
if _llIIlIl <= 0 then return invalid
_l1I1lIl = Mid(_llI1lIl, _llIIlIl + Len(_lllIlIl))
_ll1l1Il = Instr(1, _l1I1lIl, _l1d_55a757("b2", 13, 136))
if _ll1l1Il <= 0 then return invalid
_l1ll1Il = Left(_l1I1lIl, _ll1l1Il - 1)
_llIl1Il = _l1d_55a757("473e41484804", 31, 208) + _llll1Il + _l1ll1Il
return {
url: _llIl1Il
streamFormat: U_StreamFormat(_llIl1Il)
qualities: []
subtitles: []
chapters: []
referer: _l1d_55a757("eff6f90002ccbcbf0e0e13050c131d152717df1f262bec", 166, 33)
userAgent: ""
}
end function
function RP_ResolveUqload(_l11lIIl as String, _lIIlIIl as String, _lll1IIl as Object) as Object
if ((13948 - 3487 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lI1lIIl = {}
if _lIIlIIl <> "" then _lI1lIIl[_l1d_55a757("2e08080e1a1420", 162, 62)] = _lIIlIIl
_llIlIIl = HC_Get(_lll1IIl, _l11lIIl, _lI1lIIl, 8000)
if _llIlIIl = invalid or _llIlIIl.body = "" then return invalid
_l1IlIIl = CreateObject(_l1d_55a757("ff15e515161b1b", 23, 154), _l1d_55a757("4b524f5367685d35632d20416f394a50", 30, 222) + chr(34) + _l1d_55a757("10262c", 16, 216) + chr(34) + _l1d_55a757("49babb", 80, 60) + chr(34), _l1d_55a757("09", 89, 217))
m = _l1IlIIl.match(_llIlIIl.body)
if m = invalid or m.Count() < 2 then return invalid
_l1l1IIl = m[1]
if Left(_l1l1IIl, 4) <> _l1d_55a757("ddd4d7de", 95, 166) then return invalid
return {
url: _l1l1IIl
streamFormat: U_StreamFormat(_l1l1IIl)
qualities: []
subtitles: []
chapters: []
referer: _l1d_55a757("f900030a0edac8cb141b13171414e12b32e9", 133, 12)
userAgent: ""
}
end function
function RP_ResolveDoodstream(_ll1Ill1 as String, _l1l11l1 as String, _lIl11l1 as Object) as Object
_llIIll1 = {}
if _l1l11l1 <> "" then _llIIll1[_l1d_55a757("d7cfd1d5c3dbc9", 187, 238)] = _l1l11l1
_ll1l1l1 = HC_Get(_lIl11l1, _ll1Ill1, _llIIll1, 8000)
if _ll1l1l1 = invalid or _ll1l1l1.body = "" then return invalid
_lI1Ill1 = _ll1l1l1.finalUrl
if _lI1Ill1 = invalid or _lI1Ill1 = "" then _lI1Ill1 = _ll1Ill1
if Instr(1, _ll1l1l1.body, _l1d_55a757("0660526366855a663821", 171, 130)) <= 0 then return invalid
_lI1l1l1 = CreateObject(_l1d_55a757("dedc04d8dddef6", 97, 203), _l1d_55a757("6a2a3e2f32493e487c855c5a96", 126, 25) + chr(34) + _l1d_55a757("1603", 26, 207), _l1d_55a757("7b", 213, 191))
_l11l1l1 = _lI1l1l1.match(_ll1l1l1.body)
if _l11l1l1 = invalid or _l11l1l1.Count() < 1 then return invalid
_llll1l1 = _l11l1l1[0]
_lIlIll1 = HC_OriginOf(_lI1Ill1)
if _lIlIll1 = "" then return invalid
_lIll1l1 = _lIlIll1 + _llll1l1
_lIIIll1 = 0
for _l1IIll1 = 1 to Len(_llll1l1)
if Mid(_llll1l1, _l1IIll1, 1) = _l1d_55a757("fa", 47, 250) then _lIIIll1 = _l1IIll1
end for
if _lIIIll1 = 0 or _lIIIll1 = Len(_llll1l1) then return invalid
_lI111l1 = Mid(_llll1l1, _lIIIll1 + 1)
_l1ll1l1 = HC_Get(_lIl11l1, _lIll1l1, { "Referer": _lI1Ill1 }, 8000)
if _l1ll1l1 = invalid or _l1ll1l1.body = "" then return invalid
_lll11l1 = RP_RandomB62String(10)
_l11Ill1 = RP_NowMillis()
_llI11l1 = _l1ll1l1.body + _lll11l1 + _l1d_55a757("53110908091367", 227, 119) + _lI111l1 + _l1d_55a757("fc40605b555f6b2a", 7, 219) + _l11Ill1
_lIIl1l1 = ""
_ll111l1 = CreateObject(_l1d_55a757("291f0f1f202545", 71, 244), _l1d_55a757("0fcac8d0cbc51f18c8c82dcf25293929f7f5fdf8f24c", 71, 148), _l1d_55a757("7f", 90, 76))
_l1111l1 = _ll111l1.match(_ll1l1l1.body)
if _l1111l1 <> invalid and _l1111l1.Count() >= 2 then
_l1Il1l1 = CreateObject(_l1d_55a757("07ededf9feff0f", 77, 200), _l1d_55a757("ad646f83bec0cb958dc7", 67, 66), _l1d_55a757("08", 163, 62))
_llIl1l1 = _l1Il1l1.match(_l1111l1[1])
if _llIl1l1 <> invalid and _llIl1l1.Count() >= 2 then _lIIl1l1 = _llIl1l1[1]
end if
return {
url: _llI11l1
streamFormat: U_StreamFormat(_llI11l1)
qualities: []
subtitles: []
chapters: []
referer: _lIlIll1 + _l1d_55a757("d6", 20, 155)
userAgent: _l1d_55a757("d2b3a9bfbdc0c005f20afb0e19dfe0dcd9e3ced5290efb3226283d2e384412130f3a3f4d5914494e6e684c1e213834453a3e6a4f358f7c81809a8a88a1ac8e92799597bab980888982c8a68b909b9ae3ddbfab94acb1acf5e6e6e700f106f70cfd10e2d7d3ddcdeb28151a19332321", 246, 23)
}
end function
function RP_RandomB62String(_ll11Il1 as Integer) as String
_lll1Il1 = _l1d_55a757("b5b5b9c1c5c5c9d1d5d5d9e1e5e5e9f1f5f5f9010505091115152323272f3333373f4343474f5353575f6363676f7373777f8383c0c4c4c8d0d4d4d8e0e4", 66, 178)
_l111Il1 = ""
for _l1l1Il1 = 1 to _ll11Il1
_lIl1Il1 = Rnd(62)
_l111Il1 = _l111Il1 + Mid(_lll1Il1, _lIl1Il1, 1)
end for
return _l111Il1
end function
function RP_NowMillis() as String
if ((19384 - 2423 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1IIl11 = CreateObject(_l1d_55a757("edddc9e9fff3e5edf4ff", 10, 117))
_l1IIl11.Mark()
_l1ll111 = _l1IIl11.AsSeconds()
_lIIIl11 = _l1IIl11.GetMilliseconds()
_llll111 = _lIIIl11.ToStr()
_llll111 = Right(_l1d_55a757("e5e8eb", 185, 92) + _llll111, 3)
return _l1ll111.ToStr() + _llll111
end function
function RP_ResolveVoe(_lllII11 as String, _lIlllI1 as String, _l11llI1 as Object) as Object
_ll1II11 = {}
if _lIlllI1 <> "" then _ll1II11[_l1d_55a757("b6f0f0f6e2fce8", 26, 110)] = _lIlllI1
_ll1II11[_l1d_55a757("250e1b13e948292a361f", 52, 196)] = _l1d_55a757("53746478808389c6c3cdc6d9d470999faca49f9ef4918efdeff300f9f10fa3ccd20d120624cf1c212733d5e9ecfb05d60b09e30808504d4a515d535b6c67070d0c161a7d844341425393375c59545b9ca848665f6d727db6afb1bac3bcc9c2cfc8db6ba0a6a698a4e9e6e3eaf6ecf4", 219, 189)
_l1III11 = HC_Get(_l11llI1, _lllII11, _ll1II11, 8000)
if _l1III11 = invalid or _l1III11.body = "" then return invalid
_l11II11 = _l1III11.body
_l1lII11 = _l1III11.finalUrl
if _l1lII11 = invalid or _l1lII11 = "" then _l1lII11 = _lllII11
_l1lllI1 = CreateObject(_l1d_55a757("aeb494c0c5c6b6", 29, 63), _l1d_55a757("dff8fefb03eedc4d1212090e061c2125fa6b2c152d2f0c207c74182c8886902028922f9ca19e95", 83, 187), _l1d_55a757("06", 165, 58))
_ll1llI1 = _l1lllI1.match(_l11II11)
if _ll1llI1 <> invalid and _ll1llI1.Count() >= 2 then
_llIllI1 = RP_AbsUrl(_ll1llI1[1], _l1lII11)
_llIII11 = HC_Get(_l11llI1, _llIllI1, _ll1II11, 8000)
if _llIII11 <> invalid and _llIII11.body <> "" then
_l11II11 = _llIII11.body
_l1lII11 = _llIII11.finalUrl
if _l1lII11 = invalid or _l1lII11 = "" then _l1lII11 = _llIllI1
end if
end if
_lI11I11 = CreateObject(_l1d_55a757("a9b78fc7c8cdb5", 155, 192), _l1d_55a757("f22a1d3129353c646c0f6f004e54504621", 161, 85) + chr(34) + _l1d_55a757("cbdfe2d9dfdcddedebecf032fa04fbff", 197, 39) + chr(34) + _l1d_55a757("615fc268dccbe47676947c7a83f7e700ee00afc2b4d2bcbb04", 214, 212), _l1d_55a757("f5", 212, 56))
_llI1I11 = _lI11I11.match(_l11II11)
if _llI1I11 = invalid or _llI1I11.Count() < 2 then return invalid
_lllllI1 = U_Trim(_llI1I11[1])
if Left(_lllllI1, 2) <> _l1d_55a757("eb", 105, 185) + chr(34) then return invalid
_lllllI1 = Mid(_lllllI1, 3)
_l1I1I11 = 0
for _lI1II11 = Len(_lllllI1) to 1 step -1
if Mid(_lllllI1, _lI1II11, 1) = _l1d_55a757("14", 45, 164) then
_l1I1I11 = _lI1II11
exit for
end if
end for
if _l1I1I11 <= 1 then return invalid
_lllllI1 = Left(_lllllI1, _l1I1I11 - 1)
if Right(_lllllI1, 1) = chr(34) then _lllllI1 = Left(_lllllI1, Len(_lllllI1) - 1)
_lII1I11 = RP_VoeDecrypt(_lllllI1)
if _lII1I11 = "" then return invalid
_lIIII11 = ParseJSON(_lII1I11)
if _lIIII11 = invalid or type(_lIIII11) <> _l1d_55a757("b7adcebfc2b9b8c5c0d0ced4c8efe1e4d8f3", 103, 162) then return invalid
_lI1llI1 = ""
_lIlII11 = _l1d_55a757("efee0a", 175, 40)
if _lIIII11.source <> invalid and type(_lIIII11.source) = _l1d_55a757("8694ab91929aa4ae", 249, 251) then
_lI1llI1 = _lIIII11.source
_lIlII11 = _l1d_55a757("181713", 63, 193)
else if _lIIII11.direct_access_url <> invalid and type(_lIIII11.direct_access_url) = _l1d_55a757("b4d49bc3c0dee2de", 210, 20) then
_lI1llI1 = _lIIII11.direct_access_url
_lIlII11 = _l1d_55a757("30460d", 136, 75)
end if
if _lI1llI1 = "" then return invalid
return {
url: _lI1llI1
streamFormat: _lIlII11
qualities: []
subtitles: []
chapters: []
referer: _l1lII11
userAgent: _ll1II11[_l1d_55a757("405d7662b45b80857d7a", 218, 177)]
}
end function
function RP_VoeDecrypt(_llIl1I1 as String) as String
if _llIl1I1 = invalid or _llIl1I1 = "" then return ""
_lIl11I1 = RP_VoeRot13(_llIl1I1)
_l1l11I1 = CreateObject(_l1d_55a757("3d3d23393e3f55", 128, 75), _l1d_55a757("cbcaf5b0d3d4d9dabfc0e9c812ee0ed4f724dbe02629e92d35", 243, 24), _l1d_55a757("7e", 145, 136))
_lIl11I1 = _l1l11I1.replaceAll(_lIl11I1, _l1d_55a757("74", 150, 171))
_l1111I1 = CreateObject(_l1d_55a757("654d4b595e5f6d", 76, 39), _l1d_55a757("39", 128, 90), _l1d_55a757("2e", 3, 202))
_lIl11I1 = _l1111I1.replaceAll(_lIl11I1, "")
_l11l1I1 = CreateObject(_l1d_55a757("f5fd2bf5fb0f360a0d1f0a", 124, 231))
_l11l1I1.FromBase64String(_lIl11I1)
_lll11I1 = _l11l1I1.Count()
if _lll11I1 = 0 then return ""
for _l1Il1I1 = 0 to _lll11I1 - 1
_lI111I1 = _l11l1I1[_l1Il1I1] - 3
if _lI111I1 < 0 then _lI111I1 = _lI111I1 + 256
_l11l1I1[_l1Il1I1] = _lI111I1
end for
_l1Il1I1 = 0
_lIIl1I1 = _lll11I1 - 1
while _l1Il1I1 < _lIIl1I1
_ll111I1 = _l11l1I1[_l1Il1I1]
_l11l1I1[_l1Il1I1] = _l11l1I1[_lIIl1I1]
_l11l1I1[_lIIl1I1] = _ll111I1
_l1Il1I1 = _l1Il1I1 + 1
_lIIl1I1 = _lIIl1I1 - 1
end while
_ll1l1I1 = _l11l1I1.ToAsciiString()
_lI1l1I1 = CreateObject(_l1d_55a757("777d6d757d8f768c8f9f8a", 93, 72))
_lI1l1I1.FromBase64String(_ll1l1I1)
if _lI1l1I1.Count() = 0 then return ""
return _lI1l1I1.ToAsciiString()
end function
function RP_VoeRot13(_l11III1 as String) as String
if ((29016 - 3627 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _l11III1 = "" then return ""
_l1lIII1 = CreateObject(_l1d_55a757("142c4a281e3259292c423d", 246, 144))
_l1lIII1.FromAsciiString(_l11III1)
for _ll1III1 = 0 to _l1lIII1.Count() - 1
_lIlIII1 = _l1lIII1[_ll1III1]
if _lIlIII1 >= 65 and _lIlIII1 <= 90 then
_l1lIII1[_ll1III1] = ((_lIlIII1 - 65 + 13) mod 26) + 65
else if _lIlIII1 >= 97 and _lIlIII1 <= 122 then
_l1lIII1[_ll1III1] = ((_lIlIII1 - 97 + 13) mod 26) + 97
end if
end for
return _l1lIII1.ToAsciiString()
end function
function RP_ResolveStreamsb(_l1l11lI as String, _lIlI1lI as String, _llII1lI as Object) as Object
_lI111lI = CreateObject(_l1d_55a757("5f5d45595e5f77", 1, 236), _l1d_55a757("6359576f3c75297b48434751538f8e90625f9e4a88a773a0b09f84b98cb9be", 250, 145), _l1d_55a757("e3", 170, 32))
_llI11lI = _lI111lI.match(_l1l11lI)
if _llI11lI = invalid or _llI11lI.Count() < 2 then return invalid
_l1111lI = _llI11lI[1]
_ll111lI = HC_HostOf(_l1l11lI)
if _ll111lI = "" then return invalid
_l1llIlI = _l1d_55a757("cdc8a7b6cfdbcfc2f9eafebe0b0e", 128, 235) + _l1111lI + _l1d_55a757("e9ece405daefdf15ee0c1af01cd813161a24213938372c40", 155, 2)
_lll11lI = CreateObject(_l1d_55a757("d5bbebd7dfd1f8eaede1ec", 175, 248))
_lll11lI.FromAsciiString(_l1llIlI)
_lIl11lI = UCase(_lll11lI.ToHexString())
_lIIl1lI = _l1d_55a757("c0c7cad1d31d0d10", 230, 50) + _ll111lI + _l1d_55a757("da81a08d899da693d8dcf8", 242, 253) + _lIl11lI
_ll1I1lI = HC_Get(_llII1lI, _lIIl1lI, {
"Referer": _l1l11lI
"watchsb": _l1d_55a757("908496a09d9594a3", 131, 160)
"Accept": _l1d_55a757("5145485f65626353717276b8806a8185", 85, 29)
}, 8000)
if _ll1I1lI = invalid or _ll1I1lI.body = "" then return invalid
_lllI1lI = ParseJSON(_ll1I1lI.body)
if _lllI1lI = invalid or type(_lllI1lI) <> _l1d_55a757("4f4724595c53525b5664646c5e45797c6e89", 68, 25) then return invalid
_lI1I1lI = _lllI1lI.stream_data
if _lI1I1lI = invalid or type(_lI1I1lI) <> _l1d_55a757("a6bc99aeb1c8c7d0cbbbd9c3d3bad0d3e3de", 21, 63) then return invalid
_l1II1lI = ""
if _lI1I1lI.file <> invalid then _l1II1lI = U_Trim(_lI1I1lI.file)
if _l1II1lI = "" then return invalid
_lIII1lI = []
_l1lI1lI = _lI1I1lI.subs
if _l1lI1lI <> invalid and type(_l1lI1lI) = _l1d_55a757("2c4c2135384a45", 144, 74) then
for each _l11I1lI in _l1lI1lI
if type(_l11I1lI) <> _l1d_55a757("1a08312225141b18233b213f335244473b46", 43, 193) then continue for
_llllIlI = _l11I1lI.file
if _llllIlI = invalid or _llllIlI = "" then continue for
_l1I11lI = ""
if _l11I1lI.label <> invalid then _l1I11lI = _l11I1lI.label
_lII11lI = _l1d_55a757("4f5b", 100, 78)
if _l1I11lI <> "" then _lII11lI = LCase(Left(_l1I11lI, 2))
_lIII1lI.Push({ url: _llllIlI, language: _lII11lI, name: _l1I11lI })
end for
end if
return {
url: _l1II1lI
streamFormat: _l1d_55a757("7c7b6b", 53, 31)
qualities: []
subtitles: _lIII1lI
chapters: []
referer: _l1l11lI
userAgent: ""
}
end function
function RP_ResolveMixdrop(_llIIIlI as String, _lIlll1I as String, _lI1ll1I as Object) as Object
_l1IIIlI = {}
if _lIlll1I <> "" then _l1IIIlI[_l1d_55a757("615153574d5d53", 127, 52)] = _lIlll1I else _l1IIIlI[_l1d_55a757("e315151b0f2115", 94, 215)] = _l1d_55a757("280f12191fe9f9fc3d44363d364e3a13535a1d", 180, 76)
_l1IIIlI[_l1d_55a757("fc213226801f3c414936", 86, 249)] = _l1d_55a757("947967797f828a4b4450455853b59aa2aba9a4a373d4cd7c70728378768ee8cdd590918ba3ce9fa0a8b216e8ebfa061b0c0c280907d5cecfd6e0d8deebe64c4c4b5759fc0342424754127c5d5e59601d278d656272737e3b30342e463b4c4152475ab0a1a9a79ba56e67686f797177", 184, 159)
_lllll1I = HC_Get(_lI1ll1I, _llIIIlI, _l1IIIlI, 8000)
if _lllll1I = invalid or _lllll1I.body = "" then return invalid
_ll1ll1I = CreateObject(_l1d_55a757("15053b15161b21", 106, 253), _l1d_55a757("44809387a38f8ebaba5dc177667fb5a7bfc7dbddb9e3dfe89e8c01fd01e8d8e80507e30d0912c8b6cfbfcffe1105210d0cd5", 183, 185), _l1d_55a757("21", 111, 27))
_llIll1I = _ll1ll1I.match(_lllll1I.body)
if _llIll1I = invalid or _llIll1I.Count() < 2 then
_l11ll1I = CreateObject(_l1d_55a757("dae8c0f8f9fee6", 155, 241), _l1d_55a757("f92f4234523c43292f1238241b2c3e465c4c42533f376c6664937993687086766c7d6961ae9eb0be8c94aa9a90a18d85968c9ec5d8cae8d2d9a2", 146, 75), _l1d_55a757("af", 73, 143))
_llIll1I = _l11ll1I.match(_lllll1I.body)
if _llIll1I = invalid or _llIll1I.Count() < 2 then return invalid
end if
_lIIIIlI = _llIll1I[1]
_ll11l1I = JU_UnpackPacked(_lIIIIlI)
if _ll11l1I = "" then return invalid
_l111l1I = CreateObject(_l1d_55a757("fbf321f3f4f917", 102, 231), _l1d_55a757("7261495d79ae58595b788b63bfb3976fcb", 113, 64) + chr(34) + _l1d_55a757("4bfdfb", 78, 229) + chr(34) + _l1d_55a757("016e73", 211, 115) + chr(34), _l1d_55a757("dd", 214, 30))
_lIl1l1I = _l111l1I.match(_ll11l1I)
if _lIl1l1I = invalid or _lIl1l1I.Count() < 2 then return invalid
_l1lll1I = _lIl1l1I[1]
if Left(_l1lll1I, 2) = _l1d_55a757("6164", 99, 21) then
_lI11l1I = _l1d_55a757("b4bbbec5cb95", 164, 232) + _l1lll1I
else if Left(_l1lll1I, 4) = _l1d_55a757("11f8fb02", 118, 243) then
_lI11l1I = _l1lll1I
else
return invalid
end if
_lll1l1I = []
_lIIll1I = CreateObject(_l1d_55a757("40582654595a58", 148, 90), _l1d_55a757("f50c2a1802d736241f243c3049463e2355ff0d2f610b", 140, 38) + chr(34) + _l1d_55a757("6f434b", 249, 158) + chr(34) + _l1d_55a757("39ced3", 166, 62) + chr(34), _l1d_55a757("f1", 104, 240))
_l1Ill1I = _lIIll1I.match(_ll11l1I)
if _l1Ill1I <> invalid and _l1Ill1I.Count() >= 2 then
_l1l1l1I = _l1Ill1I[1]
if Left(_l1l1l1I, 2) = _l1d_55a757("686b", 69, 254) then _l1l1l1I = _l1d_55a757("546b6e757731", 142, 110) + _l1l1l1I
if Left(_l1l1l1I, 4) = _l1d_55a757("fb02050c", 132, 15) then
_lll1l1I.Push({ url: _l1l1l1I, language: _l1d_55a757("f600", 83, 192), name: _l1d_55a757("ebc8e0cdddd3deeae3", 252, 60) })
end if
end if
return {
url: _lI11l1I
streamFormat: U_StreamFormat(_lI11l1I)
qualities: []
subtitles: _lll1l1I
chapters: []
referer: _l1IIIlI[_l1d_55a757("ac7a7e8098869e", 236, 238)]
userAgent: _l1IIIlI[_l1d_55a757("51728777456c9596928b", 152, 132)]
}
end function
function _l1d_55a757(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function