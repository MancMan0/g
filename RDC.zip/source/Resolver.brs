function R_ResolveEmbed(_lII11ll as Object) as Object
if _lII11ll = invalid then return invalid
_lllI1ll = ""
if _lII11ll.embedUrl <> invalid then _lllI1ll = _lII11ll.embedUrl
if _lllI1ll = "" then return invalid
_lI1I1ll = ""
if _lII11ll.refer <> invalid then _lI1I1ll = _lII11ll.refer
if _lI1I1ll = "" then _lI1I1ll = HC_OriginOf(_lllI1ll)
if U_LooksHls(_lllI1ll) or U_LooksMp4(_lllI1ll) then
_lIlI1ll = 0
if U_LooksHls(_lllI1ll) then
_l11I1ll = HC_NewSession()
_lIlI1ll = RP_HlsLeadSkip(_l11I1ll, "", _lllI1ll, _lI1I1ll)
HC_Close(_l11I1ll)
end if
return {
url: _lllI1ll
streamFormat: U_StreamFormat(_lllI1ll)
qualities: []
subtitles: []
chapters: []
referer: _lI1I1ll
userAgent: ""
leadSkip: _lIlI1ll
}
end if
_llII1ll = HC_NewSession()
_ll1I1ll = invalid
_l1lI1ll = ""
_ll1I1ll = R_DispatchByHost(_lllI1ll, _lI1I1ll, _llII1ll)
if (_ll1I1ll = invalid or _ll1I1ll.url = "") and R_HasContentIds(_lII11ll) then
_ll1I1ll = R_FallbackByContentIds(_lII11ll, _llII1ll)
end if
if _ll1I1ll <> invalid and _ll1I1ll.url <> invalid and _ll1I1ll.url <> "" then
_ll1I1ll = R_EnrichResult(_ll1I1ll, _lII11ll, _lI1I1ll, _llII1ll)
end if
HC_Close(_llII1ll)
if _ll1I1ll = invalid then return invalid
if _ll1I1ll.url = invalid or _ll1I1ll.url = "" then return invalid
return R_NormalizeResult(_ll1I1ll, _lI1I1ll)
end function
function R_EnrichResult(_llI1l1l as Object, _llIll1l as Object, _l1I1l1l as String, _l1lIl1l as Object) as Object
if _llI1l1l = invalid or _llI1l1l.url = invalid or _llI1l1l.url = "" then return _llI1l1l
_lIlIl1l = _llI1l1l.url
_l111l1l = U_LooksHls(_lIlIl1l)
_lII1l1l = ""
if _llI1l1l.referer <> invalid and _llI1l1l.referer <> "" then _lII1l1l = _llI1l1l.referer
if _lII1l1l = "" then _lII1l1l = _l1I1l1l
if _lII1l1l = "" then _lII1l1l = _lIlIl1l
_ll11l1l = ""
_ll1Il1l = ""
_lI11l1l = ""
_lllIl1l = 0
_l1Ill1l = 0
if _llIll1l <> invalid then
if _llIll1l.imdb <> invalid then _ll11l1l = _llIll1l.imdb
if _llIll1l.tmdb <> invalid then _ll1Il1l = _llIll1l.tmdb
if _llIll1l.kind <> invalid then _lI11l1l = _llIll1l.kind
if _llIll1l.season <> invalid then _lllIl1l = _llIll1l.season
if _llIll1l.episode <> invalid then _l1Ill1l = _llIll1l.episode
end if
if _l111l1l then
_lll1l1l = invalid
if _llI1l1l.qualities <> invalid and type(_llI1l1l.qualities) = _l1d_f60343("88865b9194849f", 1, 21) then _lll1l1l = _llI1l1l.qualities
if _lll1l1l = invalid or _lll1l1l.Count() = 0 then
_llI1l1l.qualities = HM_FetchQualities(_lIlIl1l, _lII1l1l, _l1lIl1l)
end if
_lIIll1l = invalid
if _llI1l1l.chapters <> invalid and type(_llI1l1l.chapters) = _l1d_f60343("cdbbe0d6d9c9d4", 169, 242) then _lIIll1l = _llI1l1l.chapters
if _lIIll1l = invalid or _lIIll1l.Count() = 0 then
_llI1l1l.chapters = HM_ExtractChaptersHls(_lIlIl1l, _lII1l1l, _l1lIl1l)
end if
if _llI1l1l.leadSkip = invalid then
_llI1l1l.leadSkip = RP_HlsLeadSkip(_l1lIl1l, "", _lIlIl1l, _lII1l1l)
end if
end if
if _llI1l1l.chapters = invalid or type(_llI1l1l.chapters) <> _l1d_f60343("9d8b70a6a999a4", 9, 34) or _llI1l1l.chapters.Count() = 0 then
_llI1l1l.chapters = HM_FetchSkipTimes(_ll11l1l, _ll1Il1l, _lI11l1l, _lllIl1l, _l1Ill1l, _l1lIl1l)
end if
if _llI1l1l.subtitles = invalid or type(_llI1l1l.subtitles) <> _l1d_f60343("2f2542383b2b46", 101, 24) then _llI1l1l.subtitles = []
if _l111l1l then
_lIl1l1l = HM_ExtractSubsHls(_lIlIl1l, _lII1l1l, _l1lIl1l)
_llI1l1l.subtitles = HM_MergeSubtitles(_llI1l1l.subtitles, _lIl1l1l)
end if
_l1l1l1l = HM_FetchFreeSubs(_ll11l1l, _ll1Il1l, _lI11l1l, _lllIl1l, _l1Ill1l, _l1lIl1l)
_llI1l1l.subtitles = HM_MergeSubtitles(_llI1l1l.subtitles, _l1l1l1l)
return _llI1l1l
end function
function R_DispatchByHost(_l11I11l as String, _llII11l as String, _l1II11l as Object) as Object
_lI1I11l = HC_HostOf(_l11I11l)
print _l1d_f60343("0c080ef826333527372f3927774242514f99", 197, 110); _lI1I11l; _l1d_f60343("774d4f4c9e", 65, 22); _l11I11l
if _lI1I11l = "" then return invalid
if Instr(1, _lI1I11l, _l1d_f60343("06fc00f90d0a120b0912225c2a2122", 93, 200)) > 0 then return RP_ResolveCloudnestra(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("06121a121628e015171d", 61, 187)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("49473d57594d935959", 68, 23)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("7f7373838779498e8c", 129, 136)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("bed2d2c2c6d828e4ed", 81, 151)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("88aaa09698ac72b5b3a5", 182, 200)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("adaba49fa5adb1eac1c9", 235, 16)) > 0 then return RP_ResolveVidsrcXyz(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("c0a6b4c6c8bc7ac2c5", 168, 226)) > 0 then return RP_ResolveVidsrcCc(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("24363c3139484381445244", 222, 124)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("e4faf8eaec004ef90ff9", 112, 222)) > 0 then return RP_ResolveVidrock(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("cb7b76848488c18f92", 111, 110)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("cf8782889094cd8fa79d", 107, 118)) > 0 then return RP_Resolve2embed(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("93959897a0a18ba5a4d0ef97b2b7bb", 210, 213)) > 0 then return RP_ResolveLookmovie(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("757a84827992839591d19195a199", 228, 236)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("5b5c48685f54695d77b5627a", 215, 161)) > 0 then return RP_ResolveMoviesapi(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("7f77777f877b498f99968e8d9c", 3, 10)) > 0 then return RP_ResolveVidora(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("ef060a02ff0a00080c", 99, 237)) > 0 then return RP_ResolveAutoembed(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("5d586c61643a63816d", 52, 17)) > 0 then return RP_ResolveXpass(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("241f372e2b2b3d89753d3c41", 106, 25)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("342733403a39384a4249414e5b575f5f53a369686d", 91, 251)) > 0 then return RP_ResolveAirflix(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("7270666a71868f3f827c8e", 132, 128)) > 0 then return RP_ResolveVideasy(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("6b6363676c726c387b778b", 35, 22)) > 0 then return RP_ResolveVidking(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("53534a4916586056", 1, 219)) > 0 then return RP_ResolveYthd(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("cac0bfc0bec0ced60ce9d1eb", 235, 47)) > 0 then return RP_ResolvePeachify(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("5c5d6b727d6a6c803e848f", 186, 146)) > 0 then return RP_ResolvePrimesrc(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("53555a4a5158645a6e5c", 135, 95)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("f0ecf5e3eae1fbf32b08f8", 204, 49)) > 0 then return RP_ResolveStreamtape(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("302f4d4f484e", 82, 9)) > 0 then return RP_ResolveUqload(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("00fafd09", 10, 146)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("abe2e5e8b7", 212, 251)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("649b9ea1a473", 221, 171)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("849e60a18898a3", 12, 28)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("d4ca8ccbede3e7f0", 150, 226)) > 0 then return RP_ResolveDoodstream(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("89837cca98a2", 197, 214)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("af9ba860b0a7ac", 14, 55)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("a0acb9acb4c3bc", 126, 152)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("deeaf3aee9f5fcf9ff0601", 184, 16)) > 0 then return RP_ResolveVoe(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("65766c7a867082", 242, 224)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("d0ccd5c3cad1e2d4", 164, 249)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("172b333e343c40", 19, 183)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("d2e6d7f6ece7", 145, 240)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("2c1e2d2739", 96, 25)) > 0 then return RP_ResolveStreamsb(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("1b22161d12281a", 23, 161)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("68567566766a", 248, 211)) > 0 then return RP_ResolveMixdrop(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("1133292a3425257e2f3048", 118, 17)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("aa9ca2b6bc61bea8", 142, 178)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("faf501030501102121152950151d1921", 110, 239)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("a3a1a4a2a99ba875b7a7b5", 53, 69)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("556c5c57656569a271676b78", 79, 44)) > 0 then return invalid
return RP_ResolveGeneric(_l11I11l, _llII11l, _l1II11l)
end function
function R_FollowKnownIframes(_lI11lIl as String, _l1lIlIl as String, _ll1IlIl as String, _ll11lIl as Integer, _l11IlIl as Object) as Object
if _lI11lIl = invalid or _lI11lIl = "" then return invalid
if _ll11lIl >= 3 then return invalid
_lIlIlIl = CreateObject(_l1d_f60343("4d3b33474c4d55", 9, 210), _l1d_f60343("5b293b2a3a39444d5578588944485a87", 249, 150) + chr(34) + _l1d_f60343("fe8e96", 83, 131) + chr(34) + _l1d_f60343("da6f74", 47, 104) + chr(34), _l1d_f60343("291e", 103, 27))
_l1I1lIl = _lIlIlIl.matchAll(_lI11lIl)
if _l1I1lIl = invalid then return invalid
for each _lII1lIl in _l1I1lIl
if _lII1lIl.Count() < 2 then continue for
_lIl1lIl = U_AbsUrl(_lII1lIl[1], HC_OriginOf(_l1lIlIl))
if _lIl1lIl = "" then continue for
_l111lIl = R_DispatchByHost(_lIl1lIl, _l1lIlIl, _l11IlIl)
if _l111lIl <> invalid and _l111lIl.url <> invalid and _l111lIl.url <> "" then return _l111lIl
_lllIlIl = HC_Get(_l11IlIl, _lIl1lIl, { "Referer": _l1lIlIl }, 6000)
if _lllIlIl <> invalid and _lllIlIl.body <> "" then
_llI1lIl = R_FollowKnownIframes(_lllIlIl.body, _lIl1lIl, _l1lIlIl, _ll11lIl + 1, _l11IlIl)
if _llI1lIl <> invalid and _llI1lIl.url <> "" then return _llI1lIl
end if
end for
return invalid
end function
function R_FallbackByContentIds(_llllIIl as Object, _lIIlIIl as Object) as Object
if ((22182 - 7394 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if not R_HasContentIds(_llllIIl) then return invalid
_l11lIIl = ""
if _llllIIl.kind <> invalid then _l11lIIl = _llllIIl.kind
_lll1IIl = ""
if _llllIIl.tmdb <> invalid then _lll1IIl = _llllIIl.tmdb
_ll1lIIl = ""
if _llllIIl.imdb <> invalid then _ll1lIIl = _llllIIl.imdb
_l1IlIIl = 1
if _llllIIl.season <> invalid then _l1IlIIl = _llllIIl.season
_lIllIIl = 1
if _llllIIl.episode <> invalid then _lIllIIl = _llllIIl.episode
_llIlIIl = ""
if _llllIIl.refer <> invalid then _llIlIIl = _llllIIl.refer
_l1llIIl = R_BuildFallbackCandidates(_l11lIIl, _lll1IIl, _ll1lIIl, _l1IlIIl, _lIllIIl)
for each _l1l1IIl in _l1llIIl
if _l1l1IIl <> "" then
_lI1lIIl = R_DispatchByHost(_l1l1IIl, _llIlIIl, _lIIlIIl)
if _lI1lIIl <> invalid and _lI1lIIl.url <> invalid and _lI1lIIl.url <> "" then return _lI1lIIl
end if
end for
return invalid
end function
function R_BuildFallbackCandidates(_lIlIll1 as String, _llIIll1 as String, _lllIll1 as String, _l11Ill1 as Integer, _l1I1ll1 as Integer) as Object
_ll1Ill1 = []
_l1lIll1 = (_lIlIll1 <> _l1d_f60343("8687", 227, 239))
if _l1lIll1 then
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("202f323133fdf5f8403f3752414d0c465d5f595661555f612a627134717c707a7c468b8c96908f58", 2, 182) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("0cf3f6fd03cddde00c23231e251df4322123413a454543451252591c5560605e602e6f745e7c7340", 52, 176) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("bcb3b6bdc37d8d90ddd8d4e3dce4d6a2aafaf1f2b700fb0b090bc90a0f09171edb", 188, 232) + _llIIll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("f2e9ecf3f7334144110c0a1912180c56602e25266b342f413d417d3e433f4b528f", 253, 93) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("838a8d9498645255a39a98b39ab46bb6b2aaacb3c8d183c6bed28ecfd4e0dcd3a0", 165, 182) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("374649484a948c8f57564e699d6e695d6e71af7c767ebc79c28788928c8bd4", 226, 173) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("ece3e6edf3adbdc0fa080e080a1ed42427de18dfe7302b3b393bf93a3f39474e0b", 28, 120) + _llIIll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("4d3c3f3e448ea6a9536967595b6fbd6a6e72ca838e868c8edc9da28ca2a1deabb2acadeb", 240, 181) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("94b3b6b5b571676ac6aebecacec080c0c688d5d0d6dee29adfe0fce4f3ac", 139, 177) + _llIIll1)
else
_lI1Ill1 = _l11Ill1.ToStr()
_lII1ll1 = _l1I1ll1.ToStr()
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("5c43464d4d99a7aa5c73716c7369c0806f738b8893919195de9ca3e6a3aeacacb0f8a6a701", 87, 29) + _lllIll1 + _l1d_f60343("5e", 190, 205) + _lI1Ill1 + _l1d_f60343("3d", 155, 137) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("90a7aab1b16d5b5ec0a7b5c0b7cd74c4d3d7bfccc7d5d5d992e0d79ae7e2f0f0f4ac0a0bb5", 143, 169) + _llIIll1 + _l1d_f60343("c7", 167, 63) + _lI1Ill1 + _l1d_f60343("f1", 121, 155) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("3c3b3e3d3df90f125b565067646256202e747378398681878f934b898a54", 155, 73) + _llIIll1 + _l1d_f60343("51", 51, 53) + _lI1Ill1 + _l1d_f60343("e6", 107, 162) + _lII1ll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("635a5d646aa4b4b7847f7b8a838b7dc9d1a19899dea7a2b2b0b2f0a8adf9", 92, 47) + _lllIll1 + _l1d_f60343("0c", 64, 157) + _lI1Ill1 + _l1d_f60343("ab", 7, 131) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("0b1a1d1c226c64672b2a223d2c3c7b463c3a3e3d525b93565062a0686da9", 96, 3) + _llIIll1 + _l1d_f60343("16", 113, 184) + _lI1Ill1 + _l1d_f60343("a2", 133, 248) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("fc03060d0fd9c9cc1c13132eda332e223336ec393343f936ff4b4c08", 38, 174) + _llIIll1 + _l1d_f60343("53", 164, 200) + _lI1Ill1 + _l1d_f60343("8d", 71, 37) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("adbcbfbebe8a8083cfc7c7d3d7c999cfd2a1edacaae7f2e8f0f4bc0a0bc5", 3, 66) + _llIIll1 + _l1d_f60343("8c", 142, 235) + _lI1Ill1 + _l1d_f60343("ef", 68, 132) + _lII1ll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("a8c7cac9cb857d80dac4d2e0e2d694e5e9e9a1eee9edf7f9b30f10ccfd040e0bdd", 10, 70) + _lllIll1 + _l1d_f60343("814f484758474b9f", 75, 20) + _lI1Ill1 + _l1d_f60343("2cf208040d0400045f", 230, 108) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("361d2027297383863052483e40549a6460a4616c686a6cb66263bf", 86, 248) + _llIIll1 + _l1d_f60343("05", 164, 122) + _lI1Ill1 + _l1d_f60343("72", 40, 107) + _lII1ll1)
end if
return _ll1Ill1
end function
function R_HasContentIds(_lI1lIl1 as Object) as Boolean
if _lI1lIl1 = invalid then return false
if _lI1lIl1.tmdb <> invalid and _lI1lIl1.tmdb <> "" then return true
if _lI1lIl1.imdb <> invalid and _lI1lIl1.imdb <> "" then return true
return false
end function
function R_NormalizeResult(_lI1Il11 as Object, _ll1Il11 as String) as Object
_l11Il11 = {
url: ""
streamFormat: _l1d_f60343("afb6c0", 160, 231)
qualities: []
subtitles: []
chapters: []
referer: ""
userAgent: ""
leadSkip: 0
}
if _lI1Il11 = invalid then return _l11Il11
if _lI1Il11.url <> invalid then _l11Il11.url = _lI1Il11.url
if _lI1Il11.leadSkip <> invalid then _l11Il11.leadSkip = _lI1Il11.leadSkip
if _lI1Il11.streamFormat <> invalid and _lI1Il11.streamFormat <> "" then
_l11Il11.streamFormat = _lI1Il11.streamFormat
else if _l11Il11.url <> "" then
_l11Il11.streamFormat = U_StreamFormat(_l11Il11.url)
end if
if _lI1Il11.qualities <> invalid then _l11Il11.qualities = _lI1Il11.qualities
if _lI1Il11.subtitles <> invalid then _l11Il11.subtitles = _lI1Il11.subtitles
if _lI1Il11.chapters <> invalid then _l11Il11.chapters = _lI1Il11.chapters
if _lI1Il11.referer <> invalid and _lI1Il11.referer <> "" then
_l11Il11.referer = _lI1Il11.referer
else
_l11Il11.referer = _ll1Il11
end if
if _lI1Il11.userAgent <> invalid then _l11Il11.userAgent = _lI1Il11.userAgent
return _l11Il11
end function
function _l1d_f60343(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function