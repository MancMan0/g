function U_Trim(_lllI1ll as String) as String
if _lllI1ll = invalid then return ""
_lII11ll = CreateObject(_l1d_444dfc("a58d8b999e9fad", 140, 167), _l1d_444dfc("b9bedcb7e7cae8c3bb", 150, 241), _l1d_444dfc("3a", 85, 8))
return _lII11ll.replaceAll(_lllI1ll, "")
end function
function U_HtmlDecode(_lIl1l1l as String) as String
if ((3213 - 1071 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lIl1l1l = invalid or _lIl1l1l = "" then return ""
_lll1l1l = _lIl1l1l
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("9ee0dff5af", 42, 146), _l1d_444dfc("44", 34, 64))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("080e04040102", 95, 143), _l1d_444dfc("2e", 64, 199))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("8b93a6b3b4", 198, 171), _l1d_444dfc("d6", 214, 229))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("367c8e789752", 44, 44), _l1d_444dfc("46", 4, 35))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("28605f786632", 23, 247), chr(34))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("f2bba6f0", 240, 28), _l1d_444dfc("dc", 35, 189))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("2aeefe40", 108, 224), _l1d_444dfc("ae", 59, 169))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("642f2e40468e", 199, 131), _l1d_444dfc("16", 5, 241))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("3d72807c7f7d9955", 41, 46), _l1d_444dfc("a3a6a9", 133, 248))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("d01a141c3129ff", 36, 206), _l1d_444dfc("e4", 199, 250))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("36717e7e8f7b4d", 42, 42), _l1d_444dfc("f2", 15, 208))
_l1l1l1l = CreateObject(_l1d_444dfc("a19987959a9bb9", 132, 171), _l1d_444dfc("a2a29a916c76bfadc984b3c8", 104, 84), _l1d_444dfc("d5", 23, 101))
_llIll1l = _l1l1l1l.matchAll(_lll1l1l)
if _llIll1l <> invalid then
for each _l1Ill1l in _llIll1l
_lIIll1l = _l1Ill1l[1].ToInt()
if _lIIll1l > 0 and _lIIll1l < 1114112 then
_lll1l1l = _lll1l1l.Replace(_l1Ill1l[0], chr(_lIIll1l))
end if
end for
end if
return _lll1l1l
end function
function U_StripTags(_lI1I11l as String) as String
if _lI1I11l = invalid then return ""
_l11I11l = CreateObject(_l1d_444dfc("92787884898a9a", 77, 83), _l1d_444dfc("e5c1c9ecd0fdf5", 243, 22), _l1d_444dfc("2e", 224, 167))
return U_Trim(_l11I11l.replaceAll(_lI1I11l, ""))
end function
function U_FirstMatch(_lIl1lIl as String, _ll11lIl as String) as String
_l111lIl = CreateObject(_l1d_444dfc("c3aba9bbbcc1cf", 14, 71), _ll11lIl, _l1d_444dfc("e9f6", 164, 28))
m = _l111lIl.match(_lIl1lIl)
if m <> invalid and m.Count() >= 2 then return m[1]
return ""
end function
function U_AllMatches(_llllIIl as String, _lIllIIl as String) as Object
_ll1lIIl = CreateObject(_l1d_444dfc("88a66ea6a7aca4", 19, 39), _lIllIIl, _l1d_444dfc("5c55", 27, 234))
_l1llIIl = []
m = _ll1lIIl.matchAll(_llllIIl)
if m = invalid then return _l1llIIl
return m
end function
function U_UrlEncode(_lII1ll1 as String) as String
if ((30044 - 4292 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lII1ll1 = invalid then return ""
_l1I1ll1 = CreateObject(_l1d_444dfc("1d0b0426130e2f1f21372f2f41", 137, 34))
return _l1I1ll1.escape(_lII1ll1)
end function
function U_AbsUrl(_l1IlIl1 as String, _lI1lIl1 as String) as String
if _l1IlIl1 = invalid or _l1IlIl1 = "" then return ""
_llIlIl1 = U_Trim(_l1IlIl1)
if Left(_llIlIl1, 4) = _l1d_444dfc("bcc3c6cd", 39, 109) then return _llIlIl1
if Left(_llIlIl1, 2) = _l1d_444dfc("9093", 110, 79) then return _l1d_444dfc("1a191c1b1bd7", 187, 71) + _llIlIl1
if Left(_llIlIl1, 1) = _l1d_444dfc("0a", 159, 90) then return _lI1lIl1 + _llIlIl1
return _lI1lIl1 + _l1d_444dfc("68", 41, 98) + _llIlIl1
end function
function U_TmdbImage(_lI1Il11 as String, _l11Il11 as String) as String
if _lI1Il11 = invalid or _lI1Il11 = "" then return ""
_ll1Il11 = CreateObject(_l1d_444dfc("405e265e5f645c", 147, 95), _l1d_444dfc("fffe0d0e0ff94e27131d260b602442326d45734f79302e82338c", 76, 218), _l1d_444dfc("a2", 132, 181))
if _l11Il11 = "" then _l11Il11 = _l1d_444dfc("2368686b", 91, 247)
return _ll1Il11.replace(_lI1Il11, _l1d_444dfc("3c3b4a474c06634d595e15577765207e26882c", 143, 86) + _l11Il11)
end function
function U_DefaultPoster() as String
if ((43696 - 5462 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return _l1d_444dfc("b9a0a3aaae7a888bd0cfcecfd09ec7e1dde6adefdfedb8e2beecc4efb0b8bbd3", 21, 60)
end function
function U_LooksHls(_llll1I1 as String) as Boolean
if _llll1I1 = invalid then return false
_lIIIlI1 = LCase(_llll1I1)
return Instr(1, _lIIIlI1, _l1d_444dfc("793d8a4b9b", 231, 176)) > 0 or Instr(1, _lIIIlI1, _l1d_444dfc("307473753c", 188, 157)) > 0
end function
function U_LooksMp4(_llI1II1 as String) as Boolean
if _llI1II1 = invalid then return false
return Instr(1, LCase(_llI1II1), _l1d_444dfc("e22212d1", 149, 39)) > 0
end function
function U_StreamFormat(_l11l1lI as String) as String
if ((30504 - 5084 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if U_LooksHls(_l11l1lI) then return _l1d_444dfc("e2e1dd", 223, 43)
if U_LooksMp4(_l11l1lI) then return _l1d_444dfc("3a2867", 246, 159)
if Instr(1, LCase(_l11l1lI), _l1d_444dfc("06482e45", 144, 72)) > 0 then return _l1d_444dfc("3f3f304c", 82, 9)
return _l1d_444dfc("d4d3f1", 46, 142)
end function
function U_DefaultResolverUrl() as String
return ""
end function
function U_ClientId() as String
_l1l111I = CreateObject(_l1d_444dfc("10284428183a3334633f3a46", 54, 204))
if _l1l111I <> invalid then
_lll111I = _l1l111I.GetChannelClientId()
if _lll111I <> invalid and _lll111I <> "" then return _lll111I
end if
_ll1111I = CreateObject(_l1d_444dfc("cad0f0e0e1e2dbdde2de07f8fdeffdfafe", 127, 189), _l1d_444dfc("2b5d687049775f517a6870", 144, 105))
if _ll1111I.Exists(_l1d_444dfc("1610161d1734422a", 239, 138)) then return _ll1111I.Read(_l1d_444dfc("cfc7cfd6cecbfbe1", 254, 50))
_lIl111I = CreateObject(_l1d_444dfc("c7cffbdfcfe1eaeb0ae6f1ed", 190, 251)).GetRandomUUID()
if _lIl111I = invalid or _lIl111I = "" then _lIl111I = _l1d_444dfc("bfa7aec772", 14, 67) + CreateObject(_l1d_444dfc("d6f4ceece4f6ca000702", 17, 115)).AsSeconds().ToStr()
_ll1111I.Write(_l1d_444dfc("6c72786f7d86a47c", 229, 230), _lIl111I)
_ll1111I.Flush()
return _lIl111I
end function
function U_PrefDefault(_lIIII1I as String, _l1III1I as Dynamic) as Dynamic
_l1lllII = CreateObject(_l1d_444dfc("c3bba9bbbccdd6d6dbe9c2d3d8e8e8e5e7", 134, 207), _l1d_444dfc("497f8a8e6b95816f9c8a92", 82, 73))
if _l1lllII.Exists(_lIIII1I) then
_lIlllII = _l1lllII.Read(_lIIII1I)
if type(_l1III1I) = _l1d_444dfc("d1e7eaf0fa01f7", 95, 180) then
return _lIlllII = _l1d_444dfc("6a676f82", 211, 195)
else if type(_l1III1I) = _l1d_444dfc("3654716364697f", 143, 112) or type(_l1III1I) = _l1d_444dfc("9f8d6a94ad", 137, 164) then
return _lIlllII.ToInt()
end if
return _lIlllII
else
_lllllII = CreateObject(_l1d_444dfc("dcec02fcfdf6eff7f4f21b141109111618", 58, 148), _l1d_444dfc("4c1e3e2b3f5b6a", 251, 153))
if _lllllII.Exists(_lIIII1I) then
_lIlllII = _lllllII.Read(_lIIII1I)
_l1lllII.Write(_lIIII1I, _lIlllII)
_l1lllII.Flush()
if type(_l1III1I) = _l1d_444dfc("13f3f6fa060501", 250, 91) then
return _lIlllII = _l1d_444dfc("5059574a", 140, 88)
else if type(_l1III1I) = _l1d_444dfc("c3dfcce0e1e6da", 150, 228) or type(_l1III1I) = _l1d_444dfc("4e341d3b58", 143, 81) then
return _lIlllII.ToInt()
end if
return _lIlllII
end if
end if
return _l1III1I
end function
sub U_PrefSet(_lI111II as String, _l1I11II as Dynamic)
_llI11II = CreateObject(_l1d_444dfc("fa08201819120b15120e37302d272d3236", 59, 177), _l1d_444dfc("ec02fd01ee0824f20f2d25", 202, 84))
_llI11II.Write(_lI111II, _l1I11II.ToStr())
_llI11II.Flush()
end sub
sub U_BumpCellFavorite(_ll1llll as Object)
if ((39975 - 7995 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _ll1llll = invalid then return
if not _ll1llll.hasField(_l1d_444dfc("bbbfb1e8b4cfbf", 245, 40)) then
_ll1llll.addField(_l1d_444dfc("4a4c402f49544a", 90, 14), _l1d_444dfc("a3a38ca0a5a69e", 180, 198), true)
end if
_l11llll = _ll1llll.favBump
if _l11llll = invalid then _l11llll = 0
_ll1llll.favBump = _l11llll + 1
end sub
sub U_SetCellKind(_l1lI1ll as Object, _lIlI1ll as String)
if _l1lI1ll = invalid then return
if not _l1lI1ll.hasField(_l1d_444dfc("4a4b554e", 177, 112)) then _l1lI1ll.addField(_l1d_444dfc("1b201c19", 6, 174), _l1d_444dfc("f1eff800020c", 61, 163), false)
_l1lI1ll.kind = _lIlI1ll
end sub
function U_GetCellKind(_lIIll1l as Object) as String
if ((10480 - 1310 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lIIll1l = invalid then return ""
if not _lIIll1l.hasField(_l1d_444dfc("24292d2a", 2, 187)) then return ""
_lll1l1l = _lIIll1l.kind
if _lll1l1l = invalid then return ""
if Type(_lll1l1l) = _l1d_444dfc("b19798b0bab4", 49, 79) or Type(_lll1l1l) = _l1d_444dfc("0222e90d0e28302c", 80, 224) then return _lll1l1l
return ""
end function
sub U_SetCellPct(_llII11l as Object, _l1II11l as Integer)
if _llII11l = invalid then return
if not _llII11l.hasField(_l1d_444dfc("ae9eb8d8a9c1adabb9bd", 43, 83)) then _llII11l.addField(_l1d_444dfc("03f30d2dfe1602000e12", 171, 40), _l1d_444dfc("e8ece9fdfe03ef", 250, 85), false)
_llII11l.pctWatched = _l1II11l
end sub
sub U_BumpAllCellsByUrl(_lI11lIl as Object, _lllIlIl as String)
if _lI11lIl = invalid or _lllIlIl = invalid or _lllIlIl = "" then return
_lII1lIl = _lI11lIl.getChildCount()
if _lII1lIl <= 0 then return
for _l1I1lIl = 0 to _lII1lIl - 1
_l111lIl = _lI11lIl.getChild(_l1I1lIl)
if _l111lIl <> invalid then
_llI1lIl = _l111lIl.url
if _llI1lIl <> invalid and _llI1lIl = _lllIlIl then
U_BumpCellFavorite(_l111lIl)
end if
if _l111lIl.getChildCount() > 0 then
U_BumpAllCellsByUrl(_l111lIl, _lllIlIl)
end if
end if
end for
end sub
function U_ToggleFavoriteForCell(_lIllIIl as Object, _ll1lIIl as Object) as Boolean
if ((32960 - 6592 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lIllIIl = invalid then return false
_l11lIIl = ""
if _lIllIIl.url <> invalid then _l11lIIl = _lIllIIl.url
if _l11lIIl = "" then return false
_l1IlIIl = ""
if _lIllIIl.title <> invalid then _l1IlIIl = _lIllIIl.title
_llIlIIl = ""
if _lIllIIl.HDPosterUrl <> invalid then _llIlIIl = _lIllIIl.HDPosterUrl
_lIIlIIl = ""
if _lIllIIl.id <> invalid then _lIIlIIl = _lIllIIl.id
_lI1lIIl = U_GetCellKind(_lIllIIl)
if W_IsFavorite("", _l11lIIl) then
W_RemoveFavorite("", _l11lIIl)
else
W_AddFavorite({
title:  _l1IlIIl
poster: _llIlIIl
href:   _l11lIIl
imdb:   ""
tmdb:   _lIIlIIl
kind:   _lI1lIIl
})
end if
U_BumpAllCellsByUrl(_ll1lIIl, _l11lIIl)
return true
end function
function _l1d_444dfc(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function