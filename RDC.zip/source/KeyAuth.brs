function KA_GetConfig() as Object
return {
name: _l1d_a500bd("a999a092ac939f97", 237, 1),
ownerid: _l1d_a500bd("e5da01af1df61dec0323", 35, 150),
version: _l1d_a500bd("95a99a", 214, 174),
apiUrl: _l1d_a500bd("82919493935f55589798af9ab1b5ac71bbb4ba7cb5c9c388918f9594", 163, 183)
}
end function
function KA_GetChecksum() as String
if ((16581 - 5527 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llIll1l = CreateObject(_l1d_a500bd("88a87e9c9aae8d9da0b6b1", 18, 40))
if _llIll1l.ReadFile(_l1d_a500bd("183433eb0142394b4749493a40", 177, 87)) then
_l1Ill1l = CreateObject(_l1d_a500bd("b0b0c9dddad1b9babbccd0", 32, 94))
if _l1Ill1l <> invalid and _l1Ill1l.Setup(_l1d_a500bd("453ff3", 176, 104)) = 0 then
return _l1Ill1l.Process(_llIll1l)
end if
end if
return ""
end function
function KA_GetHwid() as String
_lIII11l = U_PrefDefault(_l1d_a500bd("3d365743354a48", 112, 34), "")
if _lIII11l <> "" and Len(_lIII11l) >= 20 then return _lIII11l
_lI1I11l = CreateObject(_l1d_a500bd("967ca6889e8a9794b395a09a", 237, 247))
_l11I11l = _lI1I11l.GetChannelClientId()
if _l11I11l = invalid or Len(_l11I11l) < 8 then _l11I11l = _lI1I11l.GetRandomUUID()
_l1II11l = _lI1I11l.GetModel()
if _l1II11l = invalid or _l1II11l = "" then _l1II11l = _l1d_a500bd("fd0d0c09", 152, 51)
_llII11l = _l1d_a500bd("4452514e79", 121, 25) + _l1II11l + _l1d_a500bd("3d", 167, 179) + _l11I11l
while Len(_llII11l) < 24
_llII11l = _llII11l + _l1d_a500bd("b7", 105, 94)
end while
U_PrefSet(_l1d_a500bd("2a23fc321a372f", 21, 172), _llII11l)
return _llII11l
end function
function KA_HttpPost(_l1lIlIl as Object) as Object
if ((75483 - 8387 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_ll11lIl = KA_GetConfig()
_llIIlIl = CreateObject(_l1d_a500bd("d2b8b5dbc4bfe4d8ceecdce0f6", 15, 85))
_llIIlIl.SetCertificatesFile(_l1d_a500bd("d2e1e2e5eaeebdb3eaef010606c5fcfdcc061a18111c16e41a2e33", 33, 144))
_llIIlIl.InitClientCertificates()
_llIIlIl.SetUrl(_ll11lIl.apiUrl)
_llIIlIl.RetainBodyOnError(true)
_llIIlIl.EnableEncodings(true)
_llIIlIl.AddHeader(_l1d_a500bd("af96988599a18e6ab4a49eae", 182, 186), _l1d_a500bd("837578979794958ba3acae729e76a3a6a982becab0ce91bcbcd9d5e1d9e8e0e4e6", 176, 178))
_llIIlIl.AddHeader(_l1d_a500bd("8bb4c1b97faecfd0ccc5", 28, 66), _l1d_a500bd("b7edf8fcd903efdd0af800d7db1b1a0be4cde9d2", 146, 247))
_llIIlIl.AddHeader(_l1d_a500bd("9576797a9291", 47, 39), _l1d_a500bd("3d4f5251514a4f655d6264a866727173b8af867a908fc99190889397dcd3dce4e2", 66, 26))
_lIl1lIl = ""
_lI11lIl = true
for each _l1I1lIl in _l1lIlIl
if not _lI11lIl then _lIl1lIl = _lIl1lIl + _l1d_a500bd("f4", 48, 222)
_lIl1lIl = _lIl1lIl + _l1I1lIl.ToStr() + _l1d_a500bd("cb", 254, 8) + _llIIlIl.Escape(_l1lIlIl[_l1I1lIl].ToStr())
_lI11lIl = false
end for
_lllIlIl = CreateObject(_l1d_a500bd("6c5c7d68797c6d7677a5778d92", 104, 82))
_llIIlIl.SetMessagePort(_lllIlIl)
if not _llIIlIl.AsyncPostFromString(_lIl1lIl) then
return { success: false, message: _l1d_a500bd("456570787276b58c84be7e8d9194908da7d6ada5df90a4afb592bac894c1d1d703d3ccdae1d9d2db25", 195, 192) }
end if
_lI1IlIl = CreateObject(_l1d_a500bd("5c4c485057626f736763", 202, 164))
_lI1IlIl.mark()
_l111lIl = 12000
_ll1IlIl = ""
_l11IlIl = 0
while _lI1IlIl.totalMilliseconds() < _l111lIl
_lIlIlIl = _l111lIl - _lI1IlIl.totalMilliseconds()
if _lIlIlIl < 1 then exit while
_lII1lIl = wait(_lIlIlIl, _lllIlIl)
if _lII1lIl = invalid then exit while
if type(_lII1lIl) = _l1d_a500bd("d6d6bfdfdcb8ecdeeaf3", 128, 228) then
_l11IlIl = _lII1lIl.getResponseCode()
_ll1IlIl = _lII1lIl.getString()
if _ll1IlIl = invalid then _ll1IlIl = ""
exit while
end if
end while
if _ll1IlIl = "" and _l11IlIl = 0 then
_llIIlIl.AsyncCancel()
return { success: false, message: _l1d_a500bd("1d040609070cfc1c191b5c0b2b2a25276e3421237c7d5f4b4348538f4b5845499e6a6653675b727062b97b828487858a7a9a9799dc", 118, 232) }
end if
_llI1lIl = ParseJson(_ll1IlIl)
if _llI1lIl = invalid then
if _l11IlIl > 0 then
return { success: false, message: _l1d_a500bd("6c7e79816a88a0728ba9a1dba3b3b6a6bcede88baaadacff", 72, 82) + _l11IlIl.ToStr() + _l1d_a500bd("f7f90620425d51494f571e735f787a626684712f", 13, 211) }
else
return { success: false, message: _l1d_a500bd("cdbbcdcfbad8c490d2c9cbcedce1f1e1dee0b1f10508f00eb5c628040c110cd824112e32e7231f3c30442b394b02443b3d404e536353505215", 46, 109) }
end if
end if
return _llI1lIl
end function
function KA_Init() as Object
_llllIIl = KA_GetConfig()
_l1llIIl = KA_GetChecksum()
_ll1lIIl = {
"type": _l1d_a500bd("31373747", 67, 7),
"ver": _llllIIl.version,
"hash": _l1llIIl,
"name": _llllIIl.name,
"ownerid": _llllIIl.ownerid
}
_l11lIIl = KA_HttpPost(_ll1lIIl)
if _l11lIIl.success = true and _l11lIIl.sessionid <> invalid and _l11lIIl.sessionid <> "" then
return { success: true, sessionid: _l11lIIl.sessionid, message: _l11lIIl.message }
else
_lIllIIl = _l1d_a500bd("1a2e3937143c4a1e4b53610d5d4e6463635c5d256f6d757d7b767e84968292908d91528f97a2a29ca0", 7, 197)
if _l11lIIl.message <> invalid then _lIllIIl = _l11lIIl.message
return { success: false, message: _lIllIIl }
end if
end function
function KA_CleanAuthMessage(_lII1ll1 as String) as String
if _lII1ll1 = invalid or _lII1ll1 = "" then return ""
_l1I1ll1 = _lII1ll1
_lllIll1 = CreateObject(_l1d_a500bd("ae9e94aaafb0b6", 136, 180), _l1d_a500bd("39433e4a4a4858974d4e6355646867727e66b2b88a72be7e88838f8f8d9ddc9b99a6aba99fb4f4b0bda4", 249, 169), _l1d_a500bd("03", 109, 255))
if _lllIll1 <> invalid then _l1I1ll1 = _lllIll1.replaceAll(_l1I1ll1, _l1d_a500bd("7aa09bababa9b9f8b7b5bec7c1b7d010c8d9c0", 219, 232))
_l1lIll1 = CreateObject(_l1d_a500bd("2a4a104a4b5046", 18, 202), _l1d_a500bd("0c121d0d1d1b1bda302d2634332b3a35f54149fe4d4b444d575d56165e5f76", 3, 162), _l1d_a500bd("6a", 141, 134))
if _l1lIll1 <> invalid then _l1I1ll1 = _l1lIll1.replaceAll(_l1I1ll1, _l1d_a500bd("b290aba39ba1a970a7adb6b7b1cfc088c0c9d8", 175, 204))
_l11Ill1 = CreateObject(_l1d_a500bd("4c6a726a6b7068", 115, 75), _l1d_a500bd("95a7989ba2ada5befdc4bcc9b604c913c9c4d5d2cd24e1e3e12733f1f8f0fcfaf1f80afbfe5412110a1b221a26241b22264136352e3f463e4a483f4658494c535e566fae6c6b64757c74807e", 123, 138), _l1d_a500bd("84", 37, 56))
if _l11Ill1 <> invalid then _l1I1ll1 = _l11Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("87a7a4a9b5bdb270bebbd27cc3d1cadb8bdce0e897e7def4e6ee", 128, 187))
_l1IIll1 = CreateObject(_l1d_a500bd("4e547460656656", 253, 191), _l1d_a500bd("acb1c2b6bdcfc6d117ccd0cc23e0dcd9e1eed9e5ed01f3f7f30d0703000815", 126, 161), _l1d_a500bd("ba", 62, 99))
if _l1IIll1 <> invalid then _l1I1ll1 = _l1IIll1.replaceAll(_l1I1ll1, _l1d_a500bd("ba9a979ca8b0a563b1aec56fc0c4cc7bc4d0d9d5ce", 32, 78))
_lIlIll1 = CreateObject(_l1d_a500bd("4353696364694f", 122, 59), _l1d_a500bd("acb6c1adbdbbbb7ad0d1c6d8d7cbdad5", 1, 68), _l1d_a500bd("7d", 137, 157))
if _lIlIll1 <> invalid then _l1I1ll1 = _lIlIll1.replaceAll(_l1I1ll1, _l1d_a500bd("5e7a958f858d93da9199a2a39bbbacf2acb5c4", 206, 215))
_llll1l1 = CreateObject(_l1d_a500bd("516977696a6f6d", 246, 205), _l1d_a500bd("b8bdaec2b9bbc2bd03d4c6dddcdbe3d5d7", 230, 37), _l1d_a500bd("25", 30, 174))
if _llll1l1 <> invalid then _l1I1ll1 = _llll1l1.replaceAll(_l1I1ll1, _l1d_a500bd("2c524f4c5a48551d695e5d295e6a61607f6d797d", 21, 211))
_lI1Ill1 = CreateObject(_l1d_a500bd("8e84b484858aaa", 39, 57), _l1d_a500bd("8c7e93969580a08d54a995acab9ab8a4a8", 141, 143), _l1d_a500bd("c2", 47, 124))
if _lI1Ill1 <> invalid then _l1I1ll1 = _lI1Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("d4f4fd06fef60fcd0718ffd90a24131a21193335", 154, 254))
_lIIIll1 = CreateObject(_l1d_a500bd("839b69979c9d9b", 148, 157), _l1d_a500bd("3c3d3244333736410141590a5d4f64676e597166", 41, 224), _l1d_a500bd("20", 97, 24))
if _lIIIll1 <> invalid then _l1I1ll1 = _lIIIll1.replaceAll(_l1I1ll1, _l1d_a500bd("22202d3230463bfb37444b", 41, 221))
_llIIll1 = CreateObject(_l1d_a500bd("2b131123242937", 142, 47), _l1d_a500bd("b1bac7c1c8d4cbd6", 29, 73), _l1d_a500bd("70", 100, 99))
if _llIIll1 <> invalid then _l1I1ll1 = _llIIll1.replaceAll(_l1I1ll1, _l1d_a500bd("a3c1bec3d1b7cc8cb8d5cc", 17, 70))
_ll1Ill1 = CreateObject(_l1d_a500bd("5b7941757a7b73", 81, 56), _l1d_a500bd("c0d4c9cccbe6d4e1", 244, 60), _l1d_a500bd("39", 242, 158))
if _ll1Ill1 <> invalid then _l1I1ll1 = _ll1Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("7fa5a29fad9ba8f09cb1b0", 85, 102))
return _l1I1ll1
end function
function KA_License(_lll1Il1 as String) as Object
if _lll1Il1 = invalid or U_Trim(_lll1Il1) = "" then
return { success: false, message: _l1d_a500bd("f3120c0b1c15551b2532243267413643417645433c454f554e8e56576ea4", 195, 96) }
end if
_lll1Il1 = U_Trim(_lll1Il1)
_lIIlIl1 = KA_Init()
if not _lIIlIl1.success then
return _lIIlIl1
end if
_lI1lIl1 = KA_GetConfig()
_l1IlIl1 = KA_GetHwid()
_ll11Il1 = {
"type": _l1d_a500bd("d7d7e2e3e1", 159, 228),
"username": _lll1Il1,
"pass": "",
"hwid": _l1IlIl1,
"sessionid": _lIIlIl1.sessionid,
"name": _lI1lIl1.name,
"ownerid": _lI1lIl1.ownerid
}
_lI11Il1 = KA_HttpPost(_ll11Il1)
if _lI11Il1.success = true then
_llIlIl1 = ""
_l1I1Il1 = _l1d_a500bd("fe00060af90500", 93, 197)
if _lI11Il1.info <> invalid and _lI11Il1.info.subscriptions <> invalid and _lI11Il1.info.subscriptions.Count() > 0 then
_llI1Il1 = KA_CheckSubscriptions(_lI11Il1.info.subscriptions)
if _llI1Il1.isExpired then
KA_ClearLicense()
return {
success: false,
message: _l1d_a500bd("dbf40d0dbefdfd0a0f0b2318d6111d32e22a303b2743393bf8fd303f4b4a5f5412675d596378247069828233898e7e928597819ba28a939558", 8, 138)
}
end if
_llIlIl1 = _llI1Il1.expiry
_l1I1Il1 = _llI1Il1.subName
end if
U_PrefSet(_l1d_a500bd("362f683a403d3a48564380574c6b", 37, 232), _lll1Il1)
U_PrefSet(_l1d_a500bd("1724513e3b344231393843", 171, 87), _lll1Il1)
U_PrefSet(_l1d_a500bd("c7d001cfefd4e4", 41, 133), _l1IlIl1)
U_PrefSet(_l1d_a500bd("565330595052693f5b635d75", 82, 29), _l1d_a500bd("3e3c353e482e47", 211, 127))
U_PrefSet(_l1d_a500bd("e2eff4f1e1ecf6f0ec", 255, 78), _llIlIl1)
U_PrefSet(_l1d_a500bd("eeebe8ff08f6", 131, 6), _l1I1Il1)
U_PrefSet(_l1d_a500bd("dbd40ddfddf2f01cf8e802faf400f7fb", 165, 13), CreateObject(_l1d_a500bd("1b2957352d3f5339404b", 251, 146)).AsSeconds().ToStr())
return {
success: true,
message: _l1d_a500bd("6e9693909c8c99dfada2a1eb9caea6c0b8c6bdbf06bcb9d2d5d2cbcedccee8ebe32e", 84, 86),
expiry: _llIlIl1,
subscription: _l1I1Il1,
authType: _l1d_a500bd("0402fb040ef40d", 83, 197)
}
end if
_lIl1Il1 = {
"type": _l1d_a500bd("c6c4c1c6d4dacf", 161, 249),
"key": _lll1Il1,
"hwid": _l1IlIl1,
"sessionid": _lIIlIl1.sessionid,
"name": _lI1lIl1.name,
"ownerid": _lI1lIl1.ownerid
}
_l111Il1 = KA_HttpPost(_lIl1Il1)
if _l111Il1.success = true then
_llIlIl1 = ""
_l1I1Il1 = _l1d_a500bd("0103050d1c1823", 135, 30)
if _l111Il1.info <> invalid and _l111Il1.info.subscriptions <> invalid and _l111Il1.info.subscriptions.Count() > 0 then
_llI1Il1 = KA_CheckSubscriptions(_l111Il1.info.subscriptions)
if _llI1Il1.isExpired then
KA_ClearLicense()
return {
success: false,
message: _l1d_a500bd("dff401ff340301fa030d130c4c171122581e36312b352d317a7326453f3e4f488859515b57689a74697674a97982708275898591988e9397da", 195, 69)
}
end if
_llIlIl1 = _llI1Il1.expiry
_l1I1Il1 = _llI1Il1.subName
end if
U_PrefSet(_l1d_a500bd("564f3062605d6270566b4877746b", 81, 28), _lll1Il1)
U_PrefSet(_l1d_a500bd("958e8f9bada2a0", 192, 234), _l1IlIl1)
U_PrefSet(_l1d_a500bd("fa032c09181c0b3b25232f1d", 45, 180), _l1d_a500bd("e4e2eff4f2e8fd", 121, 207))
U_PrefSet(_l1d_a500bd("a2af74b19faab6aeac", 94, 109), _llIlIl1)
U_PrefSet(_l1d_a500bd("f1eaeb0207f7", 192, 70), _l1I1Il1)
U_PrefSet(_l1d_a500bd("dfdc11e5e5f6f620faf00402f608ff01", 166, 18), CreateObject(_l1d_a500bd("cbb19bc1d1c3b7c5c4cf", 141, 204)).AsSeconds().ToStr())
return {
success: true,
message: _l1d_a500bd("3f5f586169516aa872736ab47879718975877d9193d2848d9a9da69396aca2bcbfaffa", 82, 33),
expiry: _llIlIl1,
subscription: _l1I1Il1,
authType: _l1d_a500bd("b3b3bcc5bdb5ce", 58, 93)
}
end if
_l1l1Il1 = _l1d_a500bd("a989748a90988e559ca4a19eaa9aa76dbbb0af", 52, 44)
if _l111Il1.message <> invalid and _l111Il1.message <> "" and _l111Il1.message <> _l1d_a500bd("553b263646444483525049525c425b9b63645b", 115, 27) then
_l1l1Il1 = KA_CleanAuthMessage(_l111Il1.message)
else if _lI11Il1.message <> invalid and _lI11Il1.message <> "" and _lI11Il1.message <> _l1d_a500bd("9a76718b81898f56868b9c9097a9a0ab", 62, 35) then
_l1l1Il1 = KA_CleanAuthMessage(_lI11Il1.message)
else if _lI11Il1.message <> invalid and _lI11Il1.message <> "" then
_l1l1Il1 = KA_CleanAuthMessage(_lI11Il1.message)
end if
KA_ClearLicense()
return { success: false, message: _l1l1Il1 }
end function
function KA_Login(_l1ll111 as String, _l1IIl11 = "" as String) as Object
if ((29862 - 4977 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _l1ll111 = invalid or _l1ll111 = "" then
return { success: false, message: _l1d_a500bd("e0c0c9d2cac2db99d3e4cba5d6f0dfe6ede5ff01ba", 186, 234) }
end if
_lI1Il11 = KA_Init()
if not _lI1Il11.success then return _lI1Il11
_ll1Il11 = KA_GetConfig()
_l11Il11 = KA_GetHwid()
_lIIIl11 = {
"type": _l1d_a500bd("b4bab5c2c2", 36, 108),
"username": _l1ll111,
"pass": _l1IIl11,
"hwid": _l11Il11,
"sessionid": _lI1Il11.sessionid,
"name": _ll1Il11.name,
"ownerid": _ll1Il11.ownerid
}
_llll111 = KA_HttpPost(_lIIIl11)
if _llll111.success = true then
U_PrefSet(_l1d_a500bd("5d563767676469755d724f7e7b72", 16, 226), _l1ll111)
U_PrefSet(_l1d_a500bd("4c594673706977666e6d78", 75, 44), _l1ll111)
U_PrefSet(_l1d_a500bd("ecf9fef8ecfd05", 191, 24), _l11Il11)
U_PrefSet(_l1d_a500bd("2835623b52543b715d555f57", 170, 103), _l1d_a500bd("e4e4f1f6f20aff", 72, 192))
return { success: true, message: _l1d_a500bd("a0c0c9d2cae2db19dddef6defaec02f6f8370912ff020b181b11271114245f", 202, 26) }
else
KA_ClearLicense()
_llIIl11 = _l1d_a500bd("8eb6afb0b8a8b97fc3c4b4d4b8d2c0e0dddfa0dde7f2f0ecee", 150, 180)
if _llll111.message <> invalid then _llIIl11 = KA_CleanAuthMessage(_llll111.message)
return { success: false, message: _llIIl11 }
end if
end function
function KA_IsActivated() as Boolean
if ((73968 - 9246 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lIl1I11 = U_PrefDefault(_l1d_a500bd("d1cee3d9dfd8d9e3d1e2fbf2ebea", 183, 245), "")
if _lIl1I11 = "" or Len(_lIl1I11) < 2 then return false
_l1l1I11 = U_PrefDefault(_l1d_a500bd("dae30ce5f3feea0600", 108, 211), "")
if KA_IsExpired(_l1l1I11) then return false
return true
end function
function KA_GetSavedLicense() as String
return U_PrefDefault(_l1d_a500bd("dfdcd9edede6eff7fff8f1000118", 66, 182), "")
end function
function KA_GetSavedExpiry() as String
return U_PrefDefault(_l1d_a500bd("0916232006111d1513", 250, 120), "")
end function
function KA_IsExpired(_l11l1lI as String) as Boolean
if _l11l1lI = invalid or _l11l1lI = "" or _l11l1lI = _l1d_a500bd("0d", 124, 193) or _l11l1lI = _l1d_a500bd("ffd9eddff7", 100, 213) or _l11l1lI = _l1d_a500bd("d0f0fc02f4fc030e", 26, 122) then
return false
end if
_lI1l1lI = _l11l1lI.ToInt()
if _lI1l1lI <= 0 then return false
_llIl1lI = CreateObject(_l1d_a500bd("8a829a829084b6969590", 164, 180)).AsSeconds()
return (_lI1l1lI <= _llIl1lI)
end function
function KA_FormatExpiry(_ll1IIlI as String) as String
if _ll1IIlI = invalid or _ll1IIlI = "" or _ll1IIlI = _l1d_a500bd("5b", 227, 136) or _ll1IIlI = _l1d_a500bd("3850465648", 145, 89) or _ll1IIlI = _l1d_a500bd("0af2fafceefefd08", 252, 90) then
return _l1d_a500bd("d6b4b2b6cac0c7c2", 35, 103)
end if
_l11IIlI = _ll1IIlI.ToInt()
if _l11IIlI <= 0 then return _ll1IIlI
_lIlIIlI = CreateObject(_l1d_a500bd("54728c6a6274887e8580", 113, 81))
_lIlIIlI.FromSeconds(_l11IIlI)
_llIIIlI = _lIlIIlI.ToISOString()
_lI1IIlI = _llIIIlI
if Len(_llIIIlI) >= 16 then
_lI1IIlI = Mid(_llIIIlI, 1, 10) + _l1d_a500bd("88", 14, 90) + Mid(_llIIIlI, 12, 5) + _l1d_a500bd("03999da9", 219, 8)
end if
if KA_IsExpired(_ll1IIlI) then
return _lI1IIlI + _l1d_a500bd("8c97adcdc8c2ccbcc0ae", 7, 101)
end if
return _lI1IIlI
end function
function KA_CheckSubscriptions(_lII111I as Object) as Object
if ((26128 - 6532 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lII111I = invalid or _lII111I.Count() = 0 then
return { isExpired: false, expiry: "", subName: _l1d_a500bd("808484869d87a2", 106, 114) }
end if
_l11111I = CreateObject(_l1d_a500bd("d6d6aecee4d8cae2e9e4", 192, 36)).AsSeconds()
_ll1111I = false
_lll111I = 0
_l1l111I = _l1d_a500bd("5c60646279637e", 200, 176)
for each _llI111I in _lII111I
_lI1111I = ""
if _llI111I.expiry <> invalid then _lI1111I = _llI111I.expiry.ToStr()
_l1I111I = _l1d_a500bd("9c9ea0a8b7b3be", 167, 217)
if _llI111I.subscription <> invalid then _l1I111I = _llI111I.subscription
if _lI1111I = "" or _lI1111I = _l1d_a500bd("67", 64, 247) or _lI1111I = _l1d_a500bd("f01e0e2418", 94, 224) or _lI1111I = _l1d_a500bd("a6ccc6c6dad8d7d2", 133, 221) then
_ll1111I = true
_l1l111I = _l1I111I
_lll111I = 0
exit for
else
_lIl111I = _lI1111I.ToInt()
if _lIl111I > _lll111I then
_lll111I = _lIl111I
_l1l111I = _l1I111I
end if
end if
end for
if _ll1111I then
return { isExpired: false, expiry: _l1d_a500bd("2d", 214, 71), subName: _l1l111I }
end if
if _lll111I > 0 then
if _lll111I <= _l11111I then
return { isExpired: true, expiry: _lll111I.ToStr(), subName: _l1l111I }
else
return { isExpired: false, expiry: _lll111I.ToStr(), subName: _l1l111I }
end if
end if
return { isExpired: false, expiry: "", subName: _l1l111I }
end function
function KA_ClearLicense()
U_PrefSet(_l1d_a500bd("eae3fcecf4f1eefaeaf7140b00ff", 116, 203), "")
U_PrefSet(_l1d_a500bd("221b142d36233b32303732", 68, 243), "")
U_PrefSet(_l1d_a500bd("c7c499c6c4bfdbc3d1", 214, 10), "")
U_PrefSet(_l1d_a500bd("7e8bb09fa096", 175, 186), "")
U_PrefSet(_l1d_a500bd("0603e00900041bef0d130f25", 83, 206), "")
end function
function KA_VerifySavedLicense() as Object
_l1I11II = KA_GetSavedLicense()
if _l1I11II = "" then return { success: false, message: _l1d_a500bd("375b2b626a73746c8c7d437d86954fa196a2989a", 142, 119) }
_lI111II = KA_GetSavedExpiry()
if KA_IsExpired(_lI111II) then
KA_ClearLicense()
return { success: false, message: _l1d_a500bd("ccd9e6eca1e8eee7e8f200f1b904fe0fc503231e18221216dfe0132a242b3c2df54636403c4d07614e5b611666675d6f6276727e7d7b787c3f", 7, 110) }
end if
_l1lI1II = KA_License(_l1I11II)
if _l1lI1II = invalid or _l1lI1II.success <> true then
_lllI1II = ""
if _l1lI1II <> invalid and _l1lI1II.message <> invalid then _lllI1II = _l1lI1II.message
_lII11II = LCase(_lllI1II)
_llI11II = (InStr(1, _lII11II, _l1d_a500bd("bdd3dad5d918e4d1d5", 243, 54)) > 0 or InStr(1, _lII11II, _l1d_a500bd("eae2f6faf505ff", 5, 127)) > 0 or InStr(1, _lII11II, _l1d_a500bd("21181a1d2b3020302d2f", 158, 36)) > 0 or InStr(1, _lII11II, _l1d_a500bd("3847494c46473b8a415f", 240, 165)) > 0)
if not _llI11II then
KA_ClearLicense()
end if
end if
return _l1lI1II
end function
function _l1d_a500bd(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function