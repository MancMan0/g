function S_SyncSections() as Object
return [ _l1d_d37629("52625d67506c86566f8f856e74998792a296a7aa", 137, 119), _l1d_d37629("20565155425c58466361593e587a6e7a707e7c907d", 90, 24), _l1d_d37629("edfdf802eb0721f10a2a2009fa19373a28402248364e4e", 137, 18) ]
end function
function S_HydraSyncKeys() as Object
return [ _l1d_d37629("b3c8c7bbcfd7badecbcfedd3dd", 80, 144) ]
end function
function S_BuildSnapshot() as Object
if ((12423 - 4141 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_llllI1l = {}
for each _lIllI1l in S_SyncSections()
_l1llI1l = CreateObject(_l1d_d37629("8f85b5818693a09ea7afcc99a2b0aeafb3", 37, 56), _lIllI1l)
_lIII11l = _l1llI1l.GetKeyList()
if _lIII11l <> invalid then
_l11I11l = {}
for each _l1II11l in _lIII11l
_l11I11l[_l1II11l] = _l1llI1l.Read(_l1II11l)
end for
_llllI1l[_lIllI1l] = _l11I11l
end if
end for
_lI1I11l = CreateObject(_l1d_d37629("bcdce2dcdde6cfd7d4e2fbf4f1e9010608", 178, 252), _l1d_d37629("c0b6b1addab4b0e6c3b9b9", 190, 212))
_llII11l = {}
for each _l1II11l in S_HydraSyncKeys()
if _lI1I11l.Exists(_l1II11l) then _llII11l[_l1II11l] = _lI1I11l.Read(_l1II11l)
end for
if _llII11l.Count() > 0 then _llllI1l[_l1d_d37629("0c423d412e4844324f4d45", 218, 132)] = _llII11l
return _llllI1l
end function
sub S_ApplySnapshot(_llI1lIl as Object)
if _llI1lIl = invalid then return
for each _lI11lIl in _llI1lIl
_lIl1lIl = _llI1lIl[_lI11lIl]
if _lIl1lIl <> invalid then
_l111lIl = CreateObject(_l1d_d37629("3e4664565758515156547d6e7363737072", 190, 114), _lI11lIl)
for each _ll11lIl in _lIl1lIl
if not _l111lIl.Exists(_ll11lIl) then
_l1I1lIl = _lIl1lIl[_ll11lIl]
if _l1I1lIl <> invalid then _l111lIl.Write(_ll11lIl, _l1I1lIl.ToStr())
end if
end for
_l111lIl.Flush()
end if
end for
end sub
function S_ResolverUrl() as String
_llllIIl = U_DefaultResolverUrl()
if _llllIIl = "" then _llllIIl = U_PrefDefault(_l1d_d37629("150d1a090f281c2a123021", 139, 28), "")
return _llllIIl
end function
function S_PullOnBoot() as Boolean
if ((71208 - 8901 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1lIll1 = S_ResolverUrl()
if _l1lIll1 = "" then return false
_ll1Ill1 = CreateObject(_l1d_d37629("9098b7c6c0a4b0b4", 62, 68), _l1d_d37629("7daaa096909eafaa", 3, 45))
if _ll1Ill1 = invalid then return false
_ll1Ill1.mode = _l1d_d37629("39412b2e", 234, 159)
_ll1Ill1.resolverUrl = _l1lIll1
_ll1Ill1.did = U_ClientId()
_lII1ll1 = CreateObject(_l1d_d37629("a79dbe99b2b5a6a7a8e0b8c8c5", 37, 80))
_ll1Ill1.observeField(_l1d_d37629("16021b18041f", 77, 215), _lII1ll1)
_ll1Ill1.control = _l1d_d37629("0d110f", 161, 26)
_l1I1ll1 = wait(5000, _lII1ll1)
if _l1I1ll1 = invalid then
_ll1Ill1.control = _l1d_d37629("fe08000a", 163, 14)
return false
end if
_lllIll1 = _ll1Ill1.result
if _lllIll1 = invalid or _lllIll1.ok <> true then return false
_lIlIll1 = _lllIll1.snapshot
if _lIlIll1 = invalid then return false
S_ApplySnapshot(_lIlIll1)
return true
end function
sub S_QueuePush()
if ((64449 - 7161 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.global = invalid then return
m.global.addField(_l1d_d37629("9eabb7b79fbfb0b097b7bcd8", 86, 121), _l1d_d37629("abaf9c", 178, 208), false)
m.global.addField(_l1d_d37629("f2ebfb0b170f040f", 188, 35), _l1d_d37629("caccc6c8", 177, 235), false)
_llIlIl1 = CreateObject(_l1d_d37629("371d472d3d2f6331303b", 45, 216)).AsSeconds()
_lI1lIl1 = m.global.syncLastPush
if _lI1lIl1 > 0 and (_llIlIl1 - _lI1lIl1) < 5 then return
S_FirePush(_llIlIl1)
end sub
sub S_QueuePushNow()
if ((76688 - 9586 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.global = invalid then return
m.global.addField(_l1d_d37629("0401151d3d25161e3d25222e", 122, 251), _l1d_d37629("3f4532", 115, 37), false)
m.global.addField(_l1d_d37629("bac3b5b3a1b7ccc7", 197, 4), _l1d_d37629("d3d5cfd1", 85, 152), false)
S_FirePush(CreateObject(_l1d_d37629("b6b68eaec4b8aac2c9c4", 128, 196)).AsSeconds())
end sub
sub S_FirePush(_l1l1I11 as Integer)
if ((76014 - 8446 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lIl1I11 = S_ResolverUrl()
if _lIl1I11 = "" then return
_ll11I11 = CreateObject(_l1d_d37629("100e352c381a181a", 227, 127), _l1d_d37629("3b685454445c6d68", 198, 166))
if _ll11I11 = invalid then return
_ll11I11.mode = _l1d_d37629("242a2b35", 25, 187)
_ll11I11.resolverUrl = _lIl1I11
_ll11I11.did = U_ClientId()
_ll11I11.payload = FormatJson(S_BuildSnapshot())
m.global.syncTask = _ll11I11
m.global.syncLastPush = _l1l1I11
_ll11I11.control = _l1d_d37629("0a121c", 123, 225)
end sub
function _l1d_d37629(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function