sub init()
m.listGrid = m.top.findNode(_l1d_bc7069("76768f9769978593", 10, 16))
m.emptyNotice = m.top.findNode(_l1d_bc7069("a9b4bcc3c9dfc1cfc5bec7", 99, 163))
m.listGrid.observeField(_l1d_bc7069("c1d7cbc603d4cedadfefe3e5", 238, 58), _l1d_bc7069("3133593f333e6f3c46424b574b4d", 228, 166))
m.top.observeField(_l1d_bc7069("08140b20211618", 64, 226), _l1d_bc7069("4145304a5146473a545e606a6b", 217, 139))
loadFavorites()
end sub
sub onFocusChange()
if ((7275 - 2425 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.top.hasFocus() then
if m.listGrid <> invalid then m.listGrid.setFocus(true)
end if
end sub
sub loadFavorites()
if ((32295 - 6459 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lI1I11l = WL_GetFavorites()
_lIII11l = CreateObject(_l1d_bc7069("ac9493827ca0acb0", 206, 240), _l1d_bc7069("87a6aac3b5b3cc99bbc5c7", 73, 125))
if _lI1I11l <> invalid and _lI1I11l.Count() > 0 then
m.emptyNotice.visible = false
for each _l11I11l in _lI1I11l
_llII11l = _lIII11l.createChild(_l1d_bc7069("bfe6e8d5e9f1ded7fbf7fb", 22, 106))
_llII11l.id = _l11I11l.id
_llII11l.title = _l11I11l.title
_llII11l.HDPosterUrl = _l11I11l.poster
_llII11l.HDBackgroundImageUrl = _l11I11l.poster
_llII11l.ReleaseDate = _l11I11l.year
if _l11I11l.rating <> invalid and _l11I11l.rating <> "" then
_llII11l.Rating = _l11I11l.rating.ToStr()
end if
_l1II11l = _l1d_bc7069("d4d5dfd9d8", 2, 101)
if _l11I11l.kind <> invalid and (_l11I11l.kind = _l1d_bc7069("bec3", 237, 37) or _l11I11l.kind = _l1d_bc7069("a390aa9299b2", 45, 69)) then _l1II11l = _l1d_bc7069("494e", 45, 240)
_llII11l.addField(_l1d_bc7069("bdbec0c9", 189, 231), _l1d_bc7069("9fa3a4bec6c2", 240, 28), false)
_llII11l.kind = _l1II11l
if _l1II11l = _l1d_bc7069("d1d6", 172, 249) then
_llII11l.ContentType = 2
else
_llII11l.ContentType = 1
end if
end for
m.listGrid.content = _lIII11l
m.listGrid.setFocus(true)
else
m.listGrid.content = invalid
m.emptyNotice.visible = true
end if
end sub
sub onItemSelected()
_ll11lIl = m.listGrid.itemSelected
_lIl1lIl = m.listGrid.content
if _lIl1lIl <> invalid and _ll11lIl >= 0 and _ll11lIl < _lIl1lIl.getChildCount() then
m.top.selectedItem = _lIl1lIl.getChild(_ll11lIl)
end if
end sub
function _l1d_bc7069(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function