sub init()
m.top.functionName = _l1d_04d6a4("e4e6eff5d3f80efefcfe09", 138, 254)
end sub
sub loadCatalog()
if ((49167 - 5463 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_ll11l1l = m.top.category
_llI111l = CreateObject(_l1d_04d6a4("6e6c938a96787678", 227, 221), _l1d_04d6a4("7c53575062605986687274", 189, 126))
_lII111l = []
if _ll11l1l = _l1d_04d6a4("b9b9bab5", 85, 124) then
_lII1l1l = W_ListInProgress(20)
if _lII1l1l <> invalid and _lII1l1l.Count() > 0 then
_ll1111l = []
for each _l1Il11l in _lII1l1l
if _l1Il11l.title = invalid or _l1Il11l.title = "" or Left(_l1Il11l.title, 2) = _l1d_04d6a4("a3a6", 121, 150) or _l1Il11l.poster = invalid or _l1Il11l.poster = "" then
_lIIl11l = VSC_FetchTitleMeta(_l1Il11l.itemKey, _l1Il11l.kind)
if _lIIl11l <> invalid then
if _lIIl11l.title <> invalid and _lIIl11l.title <> "" then _l1Il11l.title = _lIIl11l.title
if _lIIl11l.poster <> invalid and _lIIl11l.poster <> "" then _l1Il11l.poster = _lIIl11l.poster
if _lIIl11l.backdrop <> invalid and _lIIl11l.backdrop <> "" then _l1Il11l.backdrop = _lIIl11l.backdrop
W_RememberContext(_l1Il11l.itemKey, {
title:    _l1Il11l.title,
poster:   _l1Il11l.poster,
backdrop: _l1Il11l.backdrop,
kind:     _l1Il11l.kind,
imdb:     _l1Il11l.itemKey,
year:     _lIIl11l.year,
rating:   _lIIl11l.rating
})
end if
end if
if (_l1Il11l.poster = invalid or _l1Il11l.poster = "") and Left(_l1Il11l.itemKey, 2) = _l1d_04d6a4("7a7d", 200, 190) then
_l1Il11l.poster = _l1d_04d6a4("5d6c6f6e74beb6b9767d747d7e8fcd8f8a9c8c96a696e5adada1a6abf8bcbec5c9bdcd0dd4d1c8d6d91f", 224, 213) + _l1Il11l.itemKey + _l1d_04d6a4("3b84838c", 191, 171)
end if
if _l1Il11l.backdrop = invalid or _l1Il11l.backdrop = "" then _l1Il11l.backdrop = _l1Il11l.poster
_ll1111l.Push(_l1Il11l)
end for
if _ll1111l.Count() > 0 then
_lII111l.Push({ title: _l1d_04d6a4("759ca089a7a991a46c7cb1a1b9c3c5c7c1", 149, 159), items: _ll1111l })
end if
end if
end if
if _ll11l1l = _l1d_04d6a4("38363b36", 150, 58) then
_l1ll11l = VSC_FetchHomeRows()
if _l1ll11l <> invalid then
for each _l11l11l in _l1ll11l
_lII111l.Push(_l11l11l)
end for
end if
else if _ll11l1l = _l1d_04d6a4("82836f8f867b", 23, 8) then
_llII11l = VSC_FetchTrendingMovies()
if _llII11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("fb18322a372f333f7f1f403a445340", 90, 237), items: _llII11l })
_lllI11l = VSC_FetchByGenre(_l1d_04d6a4("80818d8584", 195, 210), _l1d_04d6a4("d9aca5e4d2ae", 109, 155))
if _lllI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("3a4d5615315f194166706e657e", 4, 227), items: _lllI11l })
_llIll1l = VSC_FetchByGenre(_l1d_04d6a4("feff1b0b12", 111, 252), _l1d_04d6a4("012232221f21", 206, 114))
if _llIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("fadbcbdbd8da2b03e4def0f7ec", 254, 59), items: _llIll1l })
_l111l1l = VSC_FetchByGenre(_l1d_04d6a4("eeefdbfbf2", 151, 244), _l1d_04d6a4("3c23241f2141", 36, 213))
if _l111l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("b8e7e8e3e5fd27d7fc06fcfb0c", 64, 181), items: _l111l1l })
_lIll11l = VSC_FetchByGenre(_l1d_04d6a4("1718121c2b", 250, 128), _l1d_04d6a4("71574d506056", 58, 255))
if _lIll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("e0c6cccfcfd50afadbe5dfdeeb", 98, 182), items: _lIll11l })
else if _ll11l1l = _l1d_04d6a4("e6d3edd5dcf5", 205, 40) or _ll11l1l = _l1d_04d6a4("9499", 56, 72) then
_l1II11l = VSC_FetchTrendingSeries()
if _l1II11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("0602ecf20e04f6cb2223d42422261110", 179, 35), items: _l1II11l })
_l1Ill1l = VSC_FetchByGenre(_l1d_04d6a4("dbcce0ded5ea", 166, 6), _l1d_04d6a4("0b2c443c4143", 2, 200))
if _l1Ill1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("3c5d6f5d5a5eaf5f708672798e", 79, 46), items: _l1Ill1l })
_l1lI11l = VSC_FetchByGenre(_l1d_04d6a4("2a23312d2c39", 195, 122), _l1d_04d6a4("d5e8f534cefe", 199, 65))
if _l1lI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("083b48071f510b08112e585c4961525f293b6c607e756a", 22, 195), items: _l1lI11l })
_lI11l1l = VSC_FetchByGenre(_l1d_04d6a4("67606c6a6976", 66, 54), _l1d_04d6a4("3c5b606b6d75", 138, 115))
if _lI11l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("270e130e12105c2c1d132f261b", 119, 243), items: _lI11l1l })
else if _ll11l1l = _l1d_04d6a4("d5daf0e6eff3", 225, 85) then
_llIll1l = VSC_FetchByGenre(_l1d_04d6a4("1c211b2130", 56, 199), _l1d_04d6a4("a08591818284", 172, 179))
if _llIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("dec3d9bfc8cc91efd4f0d4e3f4", 169, 246), items: _llIll1l })
_l1Ill1l = VSC_FetchByGenre(_l1d_04d6a4("2e1b331d243d", 204, 111), _l1d_04d6a4("4c715f7d7e82", 85, 56))
if _l1Ill1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("e7c8b8c8c5c798e7e8a1f3dfddd8df", 190, 232), items: _l1Ill1l })
else if _ll11l1l = _l1d_04d6a4("3447404a46", 29, 198) then
_lllI11l = VSC_FetchByGenre(_l1d_04d6a4("43445e4857", 106, 60), _l1d_04d6a4("4457500f3d59", 141, 102))
if _lllI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("b2a5a261cbab77cdaeaabac1b6", 191, 198), items: _lllI11l })
_l1lI11l = VSC_FetchByGenre(_l1d_04d6a4("2b18322a213a", 37, 213), _l1d_04d6a4("8c7f8c53ab95", 50, 43))
if _l1lI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("716461a8906ab48b8cbd8f7b817c7b", 250, 200), items: _l1lI11l })
else if _ll11l1l = _l1d_04d6a4("efeeeffafee4", 185, 21) then
_l111l1l = VSC_FetchByGenre(_l1d_04d6a4("161b171b2a", 57, 194), _l1d_04d6a4("17363b464850", 10, 206))
if _l111l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("fde4e5e0e4e2ae14f9e501f8f1", 181, 7), items: _l111l1l })
_lI11l1l = VSC_FetchByGenre(_l1d_04d6a4("293e2e484738", 112, 38), _l1d_04d6a4("b68d929d9f8f", 126, 121))
if _lI11l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("2f0e0f1a1c04de353ae73d252f2a29", 56, 180), items: _lI11l1l })
else if _ll11l1l = _l1d_04d6a4("d4d8e0e3e1e9", 3, 105) then
_lIll11l = VSC_FetchByGenre(_l1d_04d6a4("454a545249", 132, 92), _l1d_04d6a4("ac94acaf9db5", 41, 75))
if _lIll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("05e3f1f4ecfaaf17f80204fb10", 166, 23), items: _lIll11l })
_ll1l11l = VSC_FetchByGenre(_l1d_04d6a4("102117332a1f", 23, 172), _l1d_04d6a4("947a90938399", 42, 50))
if _ll1l11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("ffe1dfe2eae839080d42180002fd04", 252, 75), items: _ll1l11l })
else if _ll11l1l = _l1d_04d6a4("242c3231301e3e3f41", 20, 175) then
_lIIll1l = VSC_FetchByGenre(_l1d_04d6a4("bfc0bcccd3", 191, 237), _l1d_04d6a4("8763656c7389717678", 234, 220))
if _lIIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("3d5f5b6269617377b6547975798879", 89, 37), items: _lIIll1l })
_lll1l1l = VSC_FetchByGenre(_l1d_04d6a4("6f64745e6d7e", 104, 84), _l1d_04d6a4("e21410170e261c2529", 193, 98))
if _lll1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("6c545a59541a1b20846c7271705e72743b917e76908780", 180, 119), items: _lll1l1l })
else if _ll11l1l = _l1d_04d6a4("baafc5bccb", 126, 160) then
_lIlIl1l = VSC_FetchByGenre(_l1d_04d6a4("20251f2d34", 252, 143), _l1d_04d6a4("f5eadee5e4", 167, 18))
if _lIlIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("9eafc1d0c789b9dec8deddce", 144, 202), items: _lIlIl1l })
_ll1Il1l = VSC_FetchByGenre(_l1d_04d6a4("9cb1a1abbaab", 120, 145), _l1d_04d6a4("c6f7e9f8ef", 128, 2))
if _ll1Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("22f3031209cd2429d62a242c1716", 177, 45), items: _ll1Il1l })
else if _ll11l1l = _l1d_04d6a4("9cb09897a2", 141, 174) then
_llI1l1l = VSC_FetchByGenre(_l1d_04d6a4("0308221017", 76, 226), _l1d_04d6a4("8296aeb5b0", 209, 240))
if _llI1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("7284a2a9a462676898a7a0a8bca8b680b0d1bbd5d4c1", 146, 161), items: _llI1l1l })
_l1I1l1l = VSC_FetchByGenre(_l1d_04d6a4("35223c242b44", 237, 151), _l1d_04d6a4("4c402c2b36", 47, 224))
if _l1I1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("7b6d6b6a652b2831999089897d919f49b8b952c4a09ea9b0", 38, 22), items: _l1I1l1l })
else if _ll11l1l = _l1d_04d6a4("d8dad6d3e3d4d1", 186, 252) then
_llIIl1l = VSC_FetchByGenre(_l1d_04d6a4("565b675b5a", 193, 170), _l1d_04d6a4("856f6360786966", 190, 141))
if _llIIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("6a8888a191a69f59799eb89eadbe", 8, 28), items: _llIIl1l })
_l1IIl1l = VSC_FetchByGenre(_l1d_04d6a4("4a3b4f3d4459", 142, 77), _l1d_04d6a4("759ba38ca499a2", 148, 163))
if _l1IIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("a1877f7890857ed8a7ace1b79fa19ca3", 124, 103), items: _l1IIl1l })
else if _ll11l1l = _l1d_04d6a4("f5f6f406", 64, 202) or _ll11l1l = _l1d_04d6a4("656766656b7b", 10, 249) then
_l11Il1l = VSC_FetchByGenre(_l1d_04d6a4("262b15332a", 148, 45), _l1d_04d6a4("987675747a6a", 120, 90))
if _l11Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("8a6b738bbdbec3a4887f86869cd8ae93af9ba2bb", 237, 228), items: _l11Il1l })
_lIIll1l = VSC_FetchByGenre(_l1d_04d6a4("f1f2dcfef5", 86, 182), _l1d_04d6a4("6648444b524a50595d", 121, 46))
if _lIIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("fe2a2c332a203436f5193f30464e3b3f3b5542", 18, 171), items: _lIIll1l })
_lI1Il1l = VSC_FetchByGenre(_l1d_04d6a4("7d6a846c738c", 109, 95), _l1d_04d6a4("8caeadacb2a2", 218, 240))
if _lI1Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("86677767b99095c2968b7d859485", 121, 84), items: _lI1Il1l })
_lll1l1l = VSC_FetchByGenre(_l1d_04d6a4("f3e8faf2f102", 97, 225), _l1d_04d6a4("fdebebf2e9e1f7fc00", 179, 11))
if _lll1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("a6877b808e91938bdbe4e1c5a5a3aab1a7bbbdfcd2bac4bfbe", 248, 235), items: _lll1l1l })
else if _ll11l1l = _l1d_04d6a4("8877947c7c7f89a3", 173, 175) then
_l11I11l = VSC_FetchByGenre(_l1d_04d6a4("c9cae4d6dd", 206, 38), _l1d_04d6a4("9fa6c3adb3b6c2d2", 72, 131))
if _l11I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("b198959da5a8b2a4f5fefbcfb4b5b7cdcbc1d616f4d9d5d9e8d9", 249, 4), items: _l11I11l })
_lI1I11l = VSC_FetchByGenre(_l1d_04d6a4("25122c241b34", 133, 47), _l1d_04d6a4("1908050f0d101c14", 124, 241))
if _lI1I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("ccf1f2f40a18fe1353e71c0e262516", 209, 74), items: _lI1I11l })
else if _ll11l1l = _l1d_04d6a4("08202524282829", 22, 164) then
_l11111l = VSC_FetchByGenre(_l1d_04d6a4("eff00cfc03", 111, 237), _l1d_04d6a4("cae8e9e0f2e8ed", 1, 119))
if _l11111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("b5c3c4cbcdd3d818211ebde1fded2dcbf00cf0ff10", 201, 26), items: _l11111l })
_lI1111l = VSC_FetchByGenre(_l1d_04d6a4("263f2d494835", 147, 70), _l1d_04d6a4("2f4546454f4d4a", 133, 88))
if _lI1111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("0d0b0c0315fe141153271c0e262516", 241, 106), items: _lI1111l })
else if _ll11l1l = _l1d_04d6a4("4541483d4853514a584e46", 185, 104) then
_lllIl1l = VSC_FetchByGenre(_l1d_04d6a4("e4e5cfe9e8", 18, 101), _l1d_04d6a4("cff7ee0702fd0714021420", 67, 200))
if _lllIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("bd97a6b7a2ada5c2bacac802dfc5ccdadee2d4e9", 238, 19), items: _lllIl1l })
_l1lIl1l = VSC_FetchByGenre(_l1d_04d6a4("cedbd3ede4dd", 148, 231), _l1d_04d6a4("ee1a1126211c2a3321373f", 193, 105))
if _l1lIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("fe181f18152e1a283724", 154, 32), items: _l1lIl1l })
else if _ll11l1l = _l1d_04d6a4("ff03ecec06f402", 54, 161) then
_lIIIl1l = VSC_FetchByGenre(_l1d_04d6a4("686d89757c", 13, 8), _l1d_04d6a4("ceb0b9c3bbc3cf", 99, 163))
if _lIIIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("40241d1d2725333c413706030c5a534318784e5a6356", 62, 202), items: _lIIIl1l })
_llll11l = VSC_FetchByGenre(_l1d_04d6a4("0d2612302f1c", 18, 172), _l1d_04d6a4("f2d6e3e7e5ebf5", 160, 10))
if _llll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("567a9793819f99538996ae989fb8", 140, 146), items: _llll11l })
else if _ll11l1l = _l1d_04d6a4("8781828d8395879286", 92, 73) then
_l1l1l1l = VSC_FetchByGenre(_l1d_04d6a4("9697a39b9a", 195, 232), _l1d_04d6a4("1f09120dfb0dff1a0e", 240, 109))
if _l1l1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("5840413c544458535552535b1a8065716d647d", 165, 113), items: _l1l1l1l })
_lIl1l1l = VSC_FetchByGenre(_l1d_04d6a4("728b79959481", 51, 50), _l1d_04d6a4("5a848d8876887a9589", 208, 200))
if _lIl1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("5684817c72887a959992979d5c6e9f93b1a89d", 150, 130), items: _lIl1l1l })
else if _ll11l1l = _l1d_04d6a4("9195a399a2", 58, 72) then
_lIlI11l = VSC_FetchByGenre(_l1d_04d6a4("9ca19ba9b0", 28, 43), _l1d_04d6a4("9abab4c2bf", 132, 195))
if _lIlI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("8aaebcb2bbb98dadcec8d2e1ce", 26, 65), items: _lIlI11l })
_ll1I11l = VSC_FetchByGenre(_l1d_04d6a4("99b29eacbba8", 186, 208), _l1d_04d6a4("80a28aaaa7", 13, 34))
if _ll1I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("785c72606167bb9a8483748f8a927f9787a59c91e5e2ebbdb9b7a2a9", 246, 211), items: _ll1I11l })
else if _ll11l1l = _l1d_04d6a4("998ea3a397aba2", 70, 104) then
_lIII11l = VSC_FetchByGenre(_l1d_04d6a4("1516301a29", 10, 174), _l1d_04d6a4("70a19a98aaa4bb", 85, 110))
if _lIII11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("233445493d4d3c81214660465566", 200, 132), items: _lIII11l })
_llllI1l = VSC_FetchByGenre(_l1d_04d6a4("3b48404a514a", 124, 44), _l1d_04d6a4("996a7b81738584", 161, 163))
if _llllI1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("d8edfa02f602f13aec0511ff0e1b", 74, 187), items: _llllI1l })
else if _ll11l1l = _l1d_04d6a4("273940464e3444", 150, 67) then
_lIl111l = VSC_FetchByGenre(_l1d_04d6a4("e9d6f0d8dff8", 141, 235), _l1d_04d6a4("b2e8e7f5f5e3eb42ccd1", 80, 176))
if _lIl111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("28343b4349515f0b3a3f144862626d74", 133, 81), items: _lIl111l })
_l1l111l = VSC_FetchByGenre(_l1d_04d6a4("9499a5a198", 165, 204), _l1d_04d6a4("c19ba2bba6b1a9c6b6c6c4", 106, 147))
if _l1l111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("49394048076e544a4e16664860506c6358", 55, 228), items: _l1l111l })
end if
for each _lll111l in _lII111l
_l1I111l = _llI111l.createChild(_l1d_04d6a4("d2c1c5cec0ced7f4d6d0d2", 97, 176))
_l1I111l.title = _lll111l.title
for each _lI1l11l in _lll111l.items
_llIl11l = _l1I111l.createChild(_l1d_04d6a4("562d2f4c4038555e424e52", 174, 105))
populateItemNode(_llIl11l, _lI1l11l)
end for
end for
m.top.result = _llI111l
end sub
sub populateItemNode(_l1II11l as Object, _lI1I11l as Object)
_l1II11l.id = _lI1I11l.id
if _l1II11l.id = invalid or _l1II11l.id = "" then
if _lI1I11l.itemKey <> invalid then _l1II11l.id = _lI1I11l.itemKey
end if
_l1II11l.title = _lI1I11l.title
_l1II11l.HDPosterUrl = _lI1I11l.poster
_l1II11l.HDBackgroundImageUrl = _lI1I11l.backdrop
if _l1II11l.HDBackgroundImageUrl = invalid or _l1II11l.HDBackgroundImageUrl = "" then
_l1II11l.HDBackgroundImageUrl = _lI1I11l.poster
end if
_l1II11l.description = _lI1I11l.description
_l1II11l.ReleaseDate = _lI1I11l.year
if _lI1I11l.rating <> invalid and _lI1I11l.rating <> "" then
_l1II11l.Rating = _lI1I11l.rating.ToStr()
end if
_llII11l = _l1d_04d6a4("a6a7a1abba", 58, 79)
if _lI1I11l.kind <> invalid and (_lI1I11l.kind = _l1d_04d6a4("7576", 215, 210) or _lI1I11l.kind = _l1d_04d6a4("453e4c384754", 43, 237)) then _llII11l = _l1d_04d6a4("e2e7", 33, 141)
_l1II11l.addField(_l1d_04d6a4("dddee0d9", 37, 143), _l1d_04d6a4("c6cecbc9cdc9", 98, 181), false)
_l1II11l.kind = _llII11l
if _llII11l = _l1d_04d6a4("e8e9", 2, 114) then
_l1II11l.ContentType = 2
_l11I11l = ""
if _lI1I11l.season <> invalid and _lI1I11l.season > 0 then
_l11I11l = _l1d_04d6a4("62", 1, 16) + _lI1I11l.season.ToStr() + _l1d_04d6a4("a0c0", 156, 228) + _lI1I11l.episode.ToStr()
end if
if _lI1I11l.pct <> invalid and _lI1I11l.pct > 0 then
if _l11I11l <> "" then _l11I11l = _l11I11l + _l1d_04d6a4("e1ec", 211, 238) + _lI1I11l.pct.ToStr() + _l1d_04d6a4("7988", 213, 137) else _l11I11l = _lI1I11l.pct.ToStr() + _l1d_04d6a4("be", 88, 65)
end if
if _l11I11l <> "" then _l1II11l.ReleaseDate = _l11I11l
else
_l1II11l.ContentType = 1
if _lI1I11l.pct <> invalid and _lI1I11l.pct > 0 then
_l1II11l.ReleaseDate = _lI1I11l.pct.ToStr() + _l1d_04d6a4("d1d1c596ae9aa8a6aa", 227, 11)
end if
end if
if _lI1I11l.genres <> invalid then
_l1II11l.Categories = _lI1I11l.genres
end if
end sub
function _l1d_04d6a4(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function