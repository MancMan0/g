sub init()
m.top.functionName = _l1d_492033("bcbea6ceb7c6e1d0d2c1", 110, 160)
end sub
sub runKeyAuth()
if ((59724 - 9954 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llIll1l = m.top.action
if _llIll1l = _l1d_492033("7e7c858e887e97", 59, 39) then
m.top.result = KA_License(m.top.licenseKey)
else if _llIll1l = _l1d_492033("2313251d1f33", 225, 140) then
m.top.result = KA_VerifySavedLicense()
else if _llIll1l = _l1d_492033("191b261f23", 154, 35) then
m.top.result = KA_Login(m.top.username, m.top.password)
else
m.top.result = KA_Init()
end if
end sub
function _l1d_492033(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function