sub init()
m.top.functionName = _l1d_54710c("e0dab9eaf1e1f5f1", 222, 38)
end sub
sub doSearch()
_l1l1l1l = m.top.query
_lIl1l1l = CreateObject(_l1d_54710c("33435a716b4f575b", 184, 105), _l1d_54710c("e302061f110f28f5172123", 201, 89))
if _l1l1l1l = invalid or _l1l1l1l = "" then
m.top.result = _lIl1l1l
return
end if
_lIIll1l = VSC_Search(_l1l1l1l)
for each _llIll1l in _lIIll1l
_l1Ill1l = _lIl1l1l.createChild(_l1d_54710c("1cf3f5ee02fef724081014", 252, 93))
_l1Ill1l.id = _llIll1l.id
_l1Ill1l.title = _llIll1l.title
_l1Ill1l.HDPosterUrl = _llIll1l.poster
_l1Ill1l.HDBackgroundImageUrl = _llIll1l.backdrop
_l1Ill1l.description = _llIll1l.description
_l1Ill1l.ReleaseDate = _llIll1l.year
if _llIll1l.rating <> invalid and _llIll1l.rating <> "" then
_l1Ill1l.Rating = _llIll1l.rating.ToStr()
end if
_lll1l1l = _l1d_54710c("4a4b674f5e", 75, 36)
if _llIll1l.kind <> invalid and (_llIll1l.kind = _l1d_54710c("6768", 223, 188) or _llIll1l.kind = _l1d_54710c("4b64525e6d5a", 59, 3)) then _lll1l1l = _l1d_54710c("7879", 47, 29)
_l1Ill1l.addField(_l1d_54710c("0d0e1821", 73, 235), _l1d_54710c("3d3d42302c38", 206, 128), false)
_l1Ill1l.kind = _lll1l1l
if _lll1l1l = _l1d_54710c("393a", 198, 135) then
_l1Ill1l.ContentType = 2
else
_l1Ill1l.ContentType = 1
end if
if _llIll1l.genres <> invalid then
_l1Ill1l.Categories = _llIll1l.genres
end if
end for
m.top.result = _lIl1l1l
end sub
function _l1d_54710c(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function