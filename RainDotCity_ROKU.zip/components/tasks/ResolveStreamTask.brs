sub init()
m.top.functionName = _l1d_3b1f7b("e4d4e9d0d6efe3d8faffeff6ed", 207, 39)
end sub
sub resolveStream()
_l1Ill1l = m.top.imdbId
_lIIll1l = m.top.kind
_lll1l1l = m.top.season
_llIll1l = m.top.episode
if _l1Ill1l = invalid or _l1Ill1l = "" then
m.top.result = { url: "", error: _l1d_3b1f7b("8e6d6a6d76808a489f8585909a5ab4c4", 185, 154) }
return
end if
_l1l1l1l = VSR_Resolve(_l1Ill1l, _lIIll1l, _lll1l1l, _llIll1l)
if _l1l1l1l <> invalid and _l1l1l1l.url <> invalid and _l1l1l1l.url <> "" then
m.top.result = _l1l1l1l
else
m.top.result = { url: "", error: _l1d_3b1f7b("e5fc15ff0a510a0e265d32203920203d2f75482f3f4a45493e4a9066626b596057", 204, 86) }
end if
end sub
function _l1d_3b1f7b(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function