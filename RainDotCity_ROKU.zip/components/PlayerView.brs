sub init()
m.videoPlayer = m.top.findNode(_l1d_2b697b("3238464a475b4a523d5c4c", 184, 100))
m.statusOverlay = m.top.findNode(_l1d_2b697b("a6aa9ab0b4b584beb0c0adb5c0", 8, 43))
m.statusTitle = m.top.findNode(_l1d_2b697b("0309f70f1112f8fe1e0913", 201, 73))
m.statusText = m.top.findNode(_l1d_2b697b("a19f95a5a7b08ea0c0b7", 69, 107))
m.cancelBtn = m.top.findNode(_l1d_2b697b("bdbed0c6cbd7f0e5e2", 225, 59))
m.menuOverlay = m.top.findNode(_l1d_2b697b("8b968e8c758fa599a2b29d", 94, 88))
m.menuTitle = m.top.findNode(_l1d_2b697b("615c685234745a7571", 148, 104))
m.menuTime = m.top.findNode(_l1d_2b697b("abb6b2ac8eb6bdc8", 152, 182))
m.menuBtnBar = m.top.findNode(_l1d_2b697b("746f7765916a839a8070", 50, 21))
m.fitModes = [
{ label: _l1d_2b697b("485b6f5b5e6c294a767e4f384a4e513f47526b9b979a60", 133, 114),  sx: 1.00, sy: 1.00 },
{ label: _l1d_2b697b("aa9d8f9da09c69caa89e5f78646b7e847fddc1c9d2cec595", 60, 59), sx: 0.95, sy: 0.95 },
{ label: _l1d_2b697b("0bfef2fe010fcc2d1901d2dbd5d1dfe7f23e2f3131f9484d09", 53, 165), sx: 0.90, sy: 0.90 },
{ label: _l1d_2b697b("ea1d0f292c24ed122c2adffce7f70a08032d4c51475b5c541c", 154, 33), sx: 0.85, sy: 0.85 },
{ label: _l1d_2b697b("8e6173656870318e808653405b56464c57bd9e949867", 166, 153),   sx: 0.80, sy: 0.80 }
]
_lII11ll = U_PrefDefault(_l1d_2b697b("cad9e1ccebd70ee8e612f3ff03", 250, 64), 0)
if _lII11ll < 0 or _lII11ll >= m.fitModes.Count() then _lII11ll = 0
m.fitMode = _lII11ll
applyFitMode(m.fitMode)
m.cancelBtn.observeField(_l1d_2b697b("96a2a6a9a5a9d7a4b0aab3c1b3b7", 37, 79), _l1d_2b697b("e3e715faf0fefffb", 111, 227))
m.menuBtnBar.observeField(_l1d_2b697b("b1c7c9cccaccb4c9d3cfd0e4d8da", 192, 15), _l1d_2b697b("5d61816c6a629469768c817d87887e9094", 57, 7))
m.videoPlayer.observeField(_l1d_2b697b("b5b5cdbbcf", 86, 144), _l1d_2b697b("9fa3dea2b2b4b1e8cebcd4c6", 41, 89))
m.videoPlayer.observeField(_l1d_2b697b("66566d56765c6569", 169, 141), _l1d_2b697b("9092cf99b8a1b7a7a8aadab2beb6c2c3", 236, 13))
end sub
sub applyFitMode(_l1Ill1l as Integer)
if m.fitModes = invalid or m.fitModes.Count() = 0 then return
if _l1Ill1l < 0 or _l1Ill1l >= m.fitModes.Count() then _l1Ill1l = 0
m.fitMode = _l1Ill1l
_llIll1l = m.fitModes[_l1Ill1l]
_l111l1l = 1920
_ll11l1l = 1080
_lIl1l1l = Int(_l111l1l * _llIll1l.sx)
_l1l1l1l = Int(_ll11l1l * _llIll1l.sy)
_lIIll1l = Int((_l111l1l - _lIl1l1l) / 2)
_lll1l1l = Int((_ll11l1l - _l1l1l1l) / 2)
if m.videoPlayer <> invalid then
m.videoPlayer.translation = [_lIIll1l, _lll1l1l]
m.videoPlayer.width = _lIl1l1l
m.videoPlayer.height = _l1l1l1l
end if
end sub
sub onFitClicked()
if ((67360 - 8420 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l11I11l = (m.fitMode + 1) Mod m.fitModes.Count()
U_PrefSet(_l1d_2b697b("26353d2847332a44422e4f5b5f", 90, 252), _l11I11l)
applyFitMode(_l11I11l)
if m.menuOverlay <> invalid and m.menuOverlay.visible then
updateMenuButtons()
refocusMenuButton(_l1d_2b697b("88bbafc3c6d489", 145, 198))
end if
end sub
sub refocusMenuButton(_l111lIl as String)
if m.menuBtnBar = invalid then return
_lIl1lIl = m.menuBtnBar.buttons
if _lIl1lIl = invalid then return
for _ll11lIl = 0 to _lIl1lIl.Count() - 1
if Left(_lIl1lIl[_ll11lIl], Len(_l111lIl)) = _l111lIl then
if _ll11lIl < m.menuBtnBar.getChildCount() then
m.menuBtnBar.getChild(_ll11lIl).setFocus(true)
end if
exit for
end if
end for
end sub
sub onPlayConfigChange()
if ((33092 - 8273 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_llllIIl = m.top.playConfig
if _llllIIl = invalid then return
m.currentConfig = _llllIIl
m.statusTitle.text = _llllIIl.title
m.menuTitle.text = _llllIIl.title
m.statusText.text = _l1d_2b697b("021c29282c352f332f6f414946403f4e844958585d93445a656946707c4a77858dc1c4c7", 194, 114)
m.statusOverlay.visible = true
m.cancelBtn.setFocus(true)
applyFitMode(m.fitMode)
m.resolveTask = CreateObject(_l1d_2b697b("636b8a9993777f83", 60, 21), _l1d_2b697b("3f6f647b816a7e53757a8a9198649a8ba6", 215, 186))
m.resolveTask.imdbId = _llllIIl.imdbId
m.resolveTask.kind = _llllIIl.kind
if _llllIIl.season <> invalid then m.resolveTask.season = _llllIIl.season
if _llllIIl.episode <> invalid then m.resolveTask.episode = _llllIIl.episode
m.resolveTask.observeField(_l1d_2b697b("1f37242d4934", 83, 254), _l1d_2b697b("666a785a5f6f767d8b7b70878d768a8e", 55, 14))
m.resolveTask.control = _l1d_2b697b("666450", 108, 40)
end sub
sub onStreamResolved()
if ((28448 - 3556 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1I1ll1 = m.resolveTask.result
if _l1I1ll1 <> invalid and _l1I1ll1.url <> invalid and _l1I1ll1.url <> "" then
m.statusText.text = _l1d_2b697b("79879b9ea098a2a2ae7287b9b4b49dbbb3adc6bcbc96acc8d1dfe6dda1a4a7", 28, 27)
startPlayback(_l1I1ll1)
else
m.statusText.text = _l1d_2b697b("69777a88803b5868928fa7a6a56da3adb5abbbb6bec4c6c7d18b94a7c8e0cdd0a6c6ebe9eff8f4b5", 155, 139)
end if
end sub
sub startPlayback(_l1l1Il1 as Object)
_lIl1Il1 = CreateObject(_l1d_2b697b("0319283743251f21", 117, 252), _l1d_2b697b("94c3c7b0c2d0b9b6d8d2d4", 17, 66))
_lIl1Il1.url = _l1l1Il1.url
_lIl1Il1.StreamFormat = _l1d_2b697b("42492d", 179, 103)
if _l1l1Il1.streamFormat <> invalid then _lIl1Il1.StreamFormat = _l1l1Il1.streamFormat
_lIl1Il1.Title = m.currentConfig.title
if _l1l1Il1.referer <> invalid and _l1l1Il1.referer <> "" then
_llIlIl1 = [
_l1d_2b697b("2d212727192d1f5a73", 249, 130) + _l1l1Il1.referer,
_l1d_2b697b("13f009f5c72e1318100dc2df", 186, 36) + _l1l1Il1.userAgent
]
_lIl1Il1.HttpSendClientHeaders = _llIlIl1
end if
applyFitMode(m.fitMode)
_lIIlIl1 = 0
if m.currentConfig.kind = _l1d_2b697b("7e83", 184, 178) then
_lll1Il1 = 1
_lI1lIl1 = 1
if m.currentConfig.season <> invalid then _lll1Il1 = m.currentConfig.season
if m.currentConfig.episode <> invalid then _lI1lIl1 = m.currentConfig.episode
_l1IlIl1 = W_GetEpisodeProgress(m.currentConfig.imdbId, "", _lll1Il1, _lI1lIl1)
if _l1IlIl1 <> invalid and _l1IlIl1.pos <> invalid and _l1IlIl1.pos > 30 and not _l1IlIl1.done then
_lIIlIl1 = _l1IlIl1.pos
end if
else
_l1IlIl1 = W_GetMovieProgress(m.currentConfig.imdbId, "")
if _l1IlIl1 <> invalid and _l1IlIl1.pos <> invalid and _l1IlIl1.pos > 30 and not _l1IlIl1.done then
_lIIlIl1 = _l1IlIl1.pos
end if
end if
m.videoPlayer.content = _lIl1Il1
m.videoPlayer.control = _l1d_2b697b("a9c0c0bb", 150, 195)
if _lIIlIl1 > 0 then
m.videoPlayer.seek = _lIIlIl1
end if
m.videoPlayer.setFocus(true)
end sub
sub onVideoState()
_ll1Il11 = m.videoPlayer.state
if _ll1Il11 = _l1d_2b697b("42595954676763", 212, 158) then
m.statusOverlay.visible = false
else if _ll1Il11 = _l1d_2b697b("c2b8cccfd1c1dbe3df", 112, 176) then
m.statusOverlay.visible = true
m.statusText.text = _l1d_2b697b("db0bfd00041a16140e58091d2826032b390d3a42507c2c4e53434a51939699", 71, 214)
else if _ll1Il11 = _l1d_2b697b("5355515b5460686a", 158, 91) then
saveProgress()
m.videoPlayer.control = _l1d_2b697b("c0bcdac6", 84, 153)
m.top.closePlayer = true
else if _ll1Il11 = _l1d_2b697b("445a5d5363", 71, 34) then
m.statusOverlay.visible = true
m.statusText.text = _l1d_2b697b("d69dabb6b4b4b9b4febcd6d9bfdf10c8d7dae7f1f4e0e4212e2106f20b0e402405ff0d0a064b", 237, 25)
m.cancelBtn.setFocus(true)
end if
end sub
sub onPositionChange()
_l1l1I11 = m.videoPlayer.position
_ll11I11 = m.videoPlayer.duration
if _ll11I11 > 0 then
_lIl1I11 = formatTime(_l1l1I11) + _l1d_2b697b("45434b", 74, 219) + formatTime(_ll11I11)
m.menuTime.text = _lIl1I11
end if
end sub
sub performSeek(_l1ll1I1 as Integer)
_lIIIlI1 = m.videoPlayer.position
_llll1I1 = m.videoPlayer.duration
_lIll1I1 = _lIIIlI1 + _l1ll1I1
if _lIll1I1 < 0 then _lIll1I1 = 0
if _llll1I1 > 0 and _lIll1I1 > _llll1I1 - 2 then _lIll1I1 = _llll1I1 - 2
m.videoPlayer.seek = _lIll1I1
end sub
sub showMenu()
m.menuOverlay.visible = true
_llI1II1 = m.videoPlayer.duration
m.menuTime.text = formatTime(m.videoPlayer.position) + _l1d_2b697b("7f8d85", 162, 253) + formatTime(_llI1II1)
updateMenuButtons()
m.menuBtnBar.setFocus(true)
if m.menuBtnBar.getChildCount() > 0 then
m.menuBtnBar.getChild(0).setFocus(true)
end if
end sub
sub hideMenu()
m.menuOverlay.visible = false
m.videoPlayer.setFocus(true)
end sub
sub updateMenuButtons()
if ((48608 - 6076 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.menuBtnBar = invalid or m.fitModes = invalid then return
_l11IIlI = m.fitModes[m.fitMode].label
_ll1IIlI = [_l1d_2b697b("61463b0f2025201b5b4e2d233e2c2c313c", 225, 130), _l11IIlI, _l1d_2b697b("e2fdfe0a3de709121b114f5a5e70662f68", 69, 204), _l1d_2b697b("c9bbb0b0c8b8b990cdc4ccd19f00e2e3e4e0e3ede9f5", 190, 221)]
if m.currentConfig <> invalid and m.currentConfig.kind = _l1d_2b697b("5657", 107, 55) then
_ll1IIlI.Push(_l1d_2b697b("2b05231ad131272330271f23e902", 164, 65))
if m.currentConfig.episode <> invalid and m.currentConfig.episode > 1 then
_ll1IIlI.Push(_l1d_2b697b("4e3df011031315121f2458f82e2a332a262a", 70, 212))
end if
end if
_ll1IIlI.Push(_l1d_2b697b("ac8c9e865db0a7a5a0a7a1", 181, 188))
m.menuBtnBar.buttons = _ll1IIlI
for _lI1IIlI = 0 to m.menuBtnBar.getChildCount() - 1
_lIlIIlI = m.menuBtnBar.getChild(_lI1IIlI)
_lIlIIlI.minWidth = 800
_lIlIIlI.height = 48
end for
end sub
sub onMenuBtnSelected()
_l1l111I = m.menuBtnBar.buttonSelected
_lll111I = m.menuBtnBar.buttons
if _lll111I = invalid or _l1l111I < 0 or _l1l111I >= _lll111I.Count() then return
_lIl111I = _lll111I[_l1l111I]
if Left(_lIl111I, 8) = _l1d_2b697b("9ca1766c5d627d78", 240, 206) then
hideMenu()
if m.videoPlayer.state = _l1d_2b697b("566a59626f71", 244, 210) then m.videoPlayer.control = _l1d_2b697b("1f312627423d", 118, 27)
else if Left(_lIl111I, 7) = _l1d_2b697b("9eb1c3b9bcc8fd", 192, 11) or Left(_lIl111I, 4) = _l1d_2b697b("3a280edf", 52, 200) then
onFitClicked()
else if Left(_lIl111I, 10) = _l1d_2b697b("bfeaebe5b8d4fcf5f606", 152, 244) then
hideMenu()
performSeek(85)
else if Left(_lIl111I, 7) = _l1d_2b697b("1b49423e564a47", 148, 85) then
hideMenu()
m.videoPlayer.seek = 0
m.videoPlayer.control = _l1d_2b697b("e2dce9f2dde8", 74, 170)
else if Left(_lIl111I, 7) = _l1d_2b697b("07231b1a690f1f", 83, 234) then
onNextEpClicked()
else if Left(_lIl111I, 6) = _l1d_2b697b("4a312405fd0f", 227, 107) then
onPrevEpClicked()
else if _lIl111I = _l1d_2b697b("d907fb11c8fb02121d142c", 12, 144) then
onStopClicked()
end if
end sub
sub onNextEpClicked()
hideMenu()
saveProgress()
if m.currentConfig <> invalid and m.currentConfig.episode <> invalid then
m.currentConfig.episode = m.currentConfig.episode + 1
m.currentConfig.title = Left(m.currentConfig.title, Instr(1, m.currentConfig.title, _l1d_2b697b("b5bdbb0d", 182, 31)) - 1) + _l1d_2b697b("1d1323f3", 127, 190) + m.currentConfig.season.ToStr() + _l1d_2b697b("f0d6", 121, 151) + m.currentConfig.episode.ToStr()
onPlayConfigChange()
end if
end sub
sub onPrevEpClicked()
if ((49610 - 9922 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
hideMenu()
saveProgress()
if m.currentConfig <> invalid and m.currentConfig.episode <> invalid and m.currentConfig.episode > 1 then
m.currentConfig.episode = m.currentConfig.episode - 1
m.currentConfig.title = Left(m.currentConfig.title, Instr(1, m.currentConfig.title, _l1d_2b697b("1b292195", 161, 154)) - 1) + _l1d_2b697b("8a829006", 44, 126) + m.currentConfig.season.ToStr() + _l1d_2b697b("3edc", 87, 199) + m.currentConfig.episode.ToStr()
onPlayConfigChange()
end if
end sub
sub onStopClicked()
hideMenu()
stopAndExit()
end sub
sub stopAndExit()
saveProgress()
if m.resolveTask <> invalid then m.resolveTask.control = _l1d_2b697b("f4f2defc", 45, 118)
if m.videoPlayer <> invalid then
m.videoPlayer.control = _l1d_2b697b("48463250", 109, 42)
m.videoPlayer.content = invalid
end if
m.top.closePlayer = true
end sub
sub saveProgress()
if m.currentConfig = invalid then return
_lIIll1l = Int(m.videoPlayer.position)
_l111l1l = Int(m.videoPlayer.duration)
if _l111l1l <= 0 or _lIIll1l <= 0 then return
_l1l1l1l = m.currentConfig.kind
if _l1l1l1l = invalid or _l1l1l1l = "" then _l1l1l1l = _l1d_2b697b("0f102c1423", 75, 233)
_lIl1l1l = ""
if m.currentConfig.poster <> invalid then _lIl1l1l = m.currentConfig.poster
W_RememberContext(m.currentConfig.imdbId, {
title:  m.currentConfig.title,
kind:   _l1l1l1l,
imdb:   m.currentConfig.imdbId,
poster: _lIl1l1l
})
if _l1l1l1l = _l1d_2b697b("aaab", 174, 208) then
_ll11l1l = 1
_lll1l1l = 1
if m.currentConfig.season <> invalid then _ll11l1l = m.currentConfig.season
if m.currentConfig.episode <> invalid then _lll1l1l = m.currentConfig.episode
W_SaveEpisodeProgress(m.currentConfig.imdbId, "", _ll11l1l, _lll1l1l, _lIIll1l, _l111l1l, "", m.currentConfig.title, 0, 0)
else
W_SaveMovieProgress(m.currentConfig.imdbId, "", _lIIll1l, _l111l1l)
end if
end sub
sub onCancel()
stopAndExit()
end sub
function formatTime(_l1lIlIl as Float) as String
_lII1lIl = Int(_l1lIlIl)
if _lII1lIl < 0 then _lII1lIl = 0
_l111lIl = _lII1lIl \ 3600
_lI11lIl = (_lII1lIl mod 3600) \ 60
_l1I1lIl = _lII1lIl mod 60
_lllIlIl = _l1I1lIl.ToStr()
if _l1I1lIl < 10 then _lllIlIl = _l1d_2b697b("45", 228, 113) + _lllIlIl
_llI1lIl = _lI11lIl.ToStr()
if _lI11lIl < 10 and _l111lIl > 0 then _llI1lIl = _l1d_2b697b("fa", 70, 132) + _llI1lIl
if _l111lIl > 0 then
return _l111lIl.ToStr() + _l1d_2b697b("11", 131, 88) + _llI1lIl + _l1d_2b697b("77", 66, 255) + _lllIlIl
end if
return _llI1lIl + _l1d_2b697b("ad", 61, 166) + _lllIlIl
end function
function onKeyEvent(_lIllIIl as String, _ll1lIIl as Boolean) as Boolean
if not _ll1lIIl then return false
if m.menuOverlay.visible then
if _lIllIIl = _l1d_2b697b("97999e99", 76, 105) then
hideMenu()
return true
else if _lIllIIl = _l1d_2b697b("4c48485d", 38, 2) or _lIllIIl = _l1d_2b697b("b3bbccc2c1", 249, 40) then
return true
else if _lIllIIl = _l1d_2b697b("5c40475f686a52", 176, 125) then
onFitClicked()
return true
end if
return false
end if
if _lIllIIl = _l1d_2b697b("dcd8cddfe6", 135, 231) or _lIllIIl = _l1d_2b697b("7e7a8f958a949ca28fa59a", 1, 23) then
if not m.statusOverlay.visible then
performSeek(15)
return true
end if
else if _lIllIIl = _l1d_2b697b("68626459", 211, 169) or _lIllIIl = _l1d_2b697b("657f70797d8a", 90, 61) then
if not m.statusOverlay.visible then
performSeek(-15)
return true
end if
end if
if _lIllIIl = _l1d_2b697b("efed", 122, 224) or _lIllIIl = _l1d_2b697b("0e1a2521", 33, 201) then
if not m.statusOverlay.visible then
showMenu()
return true
end if
end if
if _lIllIIl = _l1d_2b697b("f2f6fdf5fe0008", 224, 99) then
onFitClicked()
return true
end if
if _lIllIIl = _l1d_2b697b("c8c7", 184, 209) or _lIllIIl = _l1d_2b697b("a09f97b2", 64, 112) then
if not m.statusOverlay.visible then
if m.videoPlayer.state = _l1d_2b697b("372e2c473a3c36", 165, 98) then
m.videoPlayer.control = _l1d_2b697b("3325343d2a", 197, 126)
else
m.videoPlayer.control = _l1d_2b697b("19091e1f0a15", 47, 188)
end if
return true
end if
end if
if _lIllIIl = _l1d_2b697b("92969792", 203, 233) then
stopAndExit()
return true
end if
return false
end function
function _l1d_2b697b(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function