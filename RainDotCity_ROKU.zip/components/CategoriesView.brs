sub init()
if ((32960 - 6592 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.btnWatchlist = m.top.findNode(_l1d_2b2032("3f4c49734858505a595f6c6a", 37, 248))
m.btnKeyAuth = m.top.findNode(_l1d_2b2032("30212a50392863323645", 255, 147))
m.btnAction = m.top.findNode(_l1d_2b2032("2a1724523723333436", 188, 76))
m.btnScifi = m.top.findNode(_l1d_2b2032("6b807da3767f8185", 161, 168))
m.btnComedy = m.top.findNode(_l1d_2b2032("3c4946644b4c474b69", 165, 117))
m.btnHorror = m.top.findNode(_l1d_2b2032("3b504d6a525a5d5b63", 33, 248))
m.btnThriller = m.top.findNode(_l1d_2b2032("e3f8f5def502fc02050111", 192, 65))
m.btnCrime = m.top.findNode(_l1d_2b2032("edfae71509f1f0fb", 45, 158))
m.btnAnimation = m.top.findNode(_l1d_2b2032("a5b6afd1b5bfbebdcbcbc8ca", 38, 97))
m.btnDrama = m.top.findNode(_l1d_2b2032("d7d0d9c6d3e7e6ed", 155, 222))
m.btnRomance = m.top.findNode(_l1d_2b2032("5c555e3563686f6d737c", 27, 227))
m.btnFantasy = m.top.findNode(_l1d_2b2032("4758516c545a675d6e7b", 167, 130))
m.btnKids = m.top.findNode(_l1d_2b2032("03fc1533181804", 179, 50))
m.btnDoc = m.top.findNode(_l1d_2b2032("31222b18303f", 223, 116))
m.btnHistory = m.top.findNode(_l1d_2b2032("d7e8e10aecf5f7efff0b", 39, 146))
m.btnBio = m.top.findNode(_l1d_2b2032("110a13fa181d", 90, 217))
m.btnSport = m.top.findNode(_l1d_2b2032("b6a7c0d0b4cab8b9", 54, 98))
m.btnWestern = m.top.findNode(_l1d_2b2032("5d6e5753687d7d71856c", 14, 241))
m.btnReality = m.top.findNode(_l1d_2b2032("90a992c9a3a2a0a0beb6", 42, 72))
m.btnMoviesAll = m.top.findNode(_l1d_2b2032("0411fee0051f0d142dfe1417", 140, 22))
m.btnSeriesAll = m.top.findNode(_l1d_2b2032("fbe805d502fa140b04f51b1e", 20, 133))
m.rows = [
[m.btnWatchlist, m.btnKeyAuth],
[m.btnAction, m.btnScifi, m.btnComedy],
[m.btnHorror, m.btnThriller, m.btnCrime],
[m.btnAnimation, m.btnDrama, m.btnRomance],
[m.btnFantasy, m.btnKids, m.btnDoc],
[m.btnHistory, m.btnBio, m.btnSport],
[m.btnWestern, m.btnReality],
[m.btnMoviesAll, m.btnSeriesAll]
]
m.curRow = 0
m.curCol = 0
m.btnWatchlist.observeField(_l1d_2b2032("2c20242733374d423e48493f5155", 249, 145), _l1d_2b2032("171935261c2a262d2d262e4c453f4b48405456", 186, 66))
if m.btnKeyAuth <> invalid then m.btnKeyAuth.observeField(_l1d_2b2032("d3e3e7ead2d6d4e5e1ebf002f4f8", 143, 230), _l1d_2b2032("535735664d485f636a427b77817e788a8e", 91, 31))
m.btnAction.observeField(_l1d_2b2032("99a9adb0a8ac9aabb7b1b6c8babe", 135, 180), _l1d_2b2032("4f51274c405861632b606a66675b6f71", 144, 80))
m.btnScifi.observeField(_l1d_2b2032("dcf6f8fbf5f7dff802fefb130709", 194, 60), _l1d_2b2032("3a3e4c3f4c42525b4c585257495b5f", 183, 98))
m.btnComedy.observeField(_l1d_2b2032("ad9fa1a4bec090c1cbc7ccbcd0d2", 22, 57), _l1d_2b2032("63653d6c6d686a623f747e7a7b6f8385", 144, 100))
m.btnHorror.observeField(_l1d_2b2032("304044472f3371423e484d5f5155", 111, 35), _l1d_2b2032("a3a58eac9a9db5a387b8c2bec3b3c7c9", 150, 170))
m.btnThriller.observeField(_l1d_2b2032("c0ced0d3c1c3c3d0cad6dfebdfe1", 204, 18), _l1d_2b2032("d5d710d7f4dee4e7f30327fcf60203170b0d", 168, 14))
m.btnCrime.observeField(_l1d_2b2032("fdeff1f4fe00e0110b171c0c2022", 158, 1), _l1d_2b2032("3539572b43423d56434f4952405256", 53, 219))
m.btnAnimation.observeField(_l1d_2b2032("d4c2c4c7e5e7f7e4eeeaf3dff3f5", 244, 62), _l1d_2b2032("edef21f5fffe0dfb0b080a2a1b152126162a2c", 254, 92))
m.btnDrama.observeField(_l1d_2b2032("e0ccd0d3eff3c1eefaf4fdebfd01", 213, 41), _l1d_2b2032("b8bc95c6b6c5bcb1c6d2cccde3d5d9", 1, 74))
m.btnRomance.observeField(_l1d_2b2032("acbabcbfbdbfafbcc6c2cbd7cbcd", 132, 198), _l1d_2b2032("c0c493c9cac9d3d1cea7d4e0dae3d1e3e7", 85, 134))
m.btnFantasy.observeField(_l1d_2b2032("ad9b9da0bec090bdc7c3ccb8ccce", 212, 247), _l1d_2b2032("2f315c463a574f605d8657515d62726668", 174, 110))
m.btnKids.observeField(_l1d_2b2032("9886888b999b7ba8a2aeb7a3b7b9", 156, 154), _l1d_2b2032("fbffe50a02f6d90a16101507191d", 87, 195))
m.btnDoc.observeField(_l1d_2b2032("8f898b8ea8aa72abb5b1aea6babc", 210, 223), _l1d_2b2032("a5a7d0aebdf0bdb7c3ccd8ccce", 44, 98))
m.btnHistory.observeField(_l1d_2b2032("b6c2c6c9c5c9f7c4d0cad3e1d3d7", 37, 111), _l1d_2b2032("a4a6c7ab949cb69caac3bcc6c2bfb7cbcd", 242, 7))
m.btnBio.observeField(_l1d_2b2032("a595999ca4a8c6b7b3bdc2b4c6ca", 127, 136), _l1d_2b2032("f6fad90102f1fe0a040d1b0d11", 5, 140))
m.btnSport.observeField(_l1d_2b2032("786c70737f83598e8a94958b9da1", 25, 253), _l1d_2b2032("c5c7efcfd1d7dcfed3ddd9daeee2e4", 32, 118))
m.btnWestern.observeField(_l1d_2b2032("f1e7e9ec0a0c1409130f1004181a", 48, 159), _l1d_2b2032("e6e8b4e9d6def2defdc5fe080401f90d0f", 82, 169))
m.btnReality.observeField(_l1d_2b2032("a0acb0b39fa3a1aeaab4bdcbbdc1", 13, 49), _l1d_2b2032("92948ba1a09e9ebcb4a1b6b0bcbdd1c5c7", 136, 171))
m.btnMoviesAll.observeField(_l1d_2b2032("ece6e8ebf5f7cf08020e0b031719", 90, 180), _l1d_2b2032("4d5171565256655687676a8277737d7e74868a", 121, 55))
m.btnSeriesAll.observeField(_l1d_2b2032("faf2f6f90105db14101a17112327", 219, 65), _l1d_2b2032("85875f988492a18e83a1a47ab3adb9b6aec2c4", 218, 208))
m.top.observeField(_l1d_2b2032("232d243d3a3337", 99, 30), _l1d_2b2032("d1d3fedae9f6ff12eaf6eefafb", 236, 78))
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.btnWatchlist <> invalid then m.btnWatchlist.setFocus(true)
end if
end sub
sub onWatchlistSelected()
m.top.categorySelected = _l1d_2b2032("baabc3afadb4b2cbd5", 75, 126)
end sub
sub onKeyAuthSelected()
if ((14838 - 4946 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("616a7974838574", 46, 28)
end sub
sub onActionSelected()
if ((32352 - 8088 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.categorySelected = _l1d_2b2032("b8b9c9c9c6c8", 70, 145)
end sub
sub onScifiSelected()
if ((51990 - 8665 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.categorySelected = _l1d_2b2032("dbeeebf7f1", 218, 50)
end sub
sub onComedySelected()
if ((9363 - 3121 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("ddd4d9e4e8d6", 127, 193)
end sub
sub onHorrorSelected()
m.top.categorySelected = _l1d_2b2032("03071f221028", 235, 128)
end sub
sub onThrillerSelected()
if ((12906 - 1434 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("8da48da9b1b4ae9c", 179, 198)
end sub
sub onCrimeSelected()
if ((12651 - 4217 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.categorySelected = _l1d_2b2032("51655d5c57", 69, 43)
end sub
sub onAnimationSelected()
if ((18225 - 3645 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.categorySelected = _l1d_2b2032("384246454454525357", 133, 84)
end sub
sub onDramaSelected()
m.top.categorySelected = _l1d_2b2032("5e53675e6d", 159, 99)
end sub
sub onRomanceSelected()
m.top.categorySelected = _l1d_2b2032("3654554c5e5459", 177, 115)
end sub
sub onFantasySelected()
m.top.categorySelected = _l1d_2b2032("b3afc1aab8adb6", 241, 28)
end sub
sub onKidsSelected()
m.top.categorySelected = _l1d_2b2032("95969c96", 60, 62)
end sub
sub onDocSelected()
if ((4077 - 1359 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("ecf8ef04fffa0811ff151d", 97, 231)
end sub
sub onHistorySelected()
m.top.categorySelected = _l1d_2b2032("7779666c887078", 81, 62)
end sub
sub onBioSelected()
m.top.categorySelected = _l1d_2b2032("8b999691a79dafaabe", 102, 135)
end sub
sub onSportSelected()
m.top.categorySelected = _l1d_2b2032("2228442c35", 179, 98)
end sub
sub onWesternSelected()
if ((28676 - 7169 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("2718312f213b32", 5, 181)
end sub
sub onRealitySelected()
m.top.categorySelected = _l1d_2b2032("584c4b5b59696f", 193, 165)
end sub
sub onMoviesAllSelected()
m.top.categorySelected = _l1d_2b2032("020701071607", 184, 45)
end sub
sub onSeriesAllSelected()
m.top.categorySelected = _l1d_2b2032("e1d2e6d4dbf0", 14, 100)
end sub
function getCurrentPosition() as Object
for _lIIlIl1 = 0 to m.rows.Count() - 1
_lll1Il1 = m.rows[_lIIlIl1]
for _l1IlIl1 = 0 to _lll1Il1.Count() - 1
if _lll1Il1[_l1IlIl1] <> invalid and _lll1Il1[_l1IlIl1].hasFocus() then
return { r: _lIIlIl1, c: _l1IlIl1 }
end if
end for
end for
return { r: 0, c: 0 }
end function
function onKeyEvent(_l1IIl11 as String, _llll111 as Boolean) as Boolean
if not _llll111 then return false
_llIIl11 = getCurrentPosition()
_lIll111 = _llIIl11.r
_lI1Il11 = _llIIl11.c
_ll1l111 = m.rows[_lIll111]
if _l1IIl11 = _l1d_2b2032("ede9def0f7", 135, 248) then
if _lI1Il11 < _ll1l111.Count() - 1 then
_ll1l111[_lI1Il11 + 1].setFocus(true)
return true
end if
else if _l1IIl11 = _l1d_2b2032("68626479", 67, 57) then
if _lI1Il11 > 0 then
_ll1l111[_lI1Il11 - 1].setFocus(true)
return true
end if
else if _l1IIl11 = _l1d_2b2032("08101b17", 135, 37) then
if _lIll111 < m.rows.Count() - 1 then
_lIIIl11 = m.rows[_lIll111 + 1]
_l11l111 = _lI1Il11
if _l11l111 >= _lIIIl11.Count() then _l11l111 = _lIIIl11.Count() - 1
_lIIIl11[_l11l111].setFocus(true)
return true
end if
else if _l1IIl11 = _l1d_2b2032("8d93", 118, 138) then
if _lIll111 > 0 then
_l1ll111 = m.rows[_lIll111 - 1]
_l11l111 = _lI1Il11
if _l11l111 >= _l1ll111.Count() then _l11l111 = _l1ll111.Count() - 1
_l1ll111[_l11l111].setFocus(true)
return true
else
return false
end if
end if
return false
end function
function _l1d_2b2032(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function