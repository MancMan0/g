sub init()
m.viewHost = m.top.findNode(_l1d_14a035("d5d1c8ddfbdbeae8", 165, 2))
m.headerBar = m.top.findNode(_l1d_14a035("4a404747496336566c", 5, 221))
m.accentLine = m.top.findNode(_l1d_14a035("0001040d07242f0d131f", 171, 54))
m.topBar = m.top.findNode(_l1d_14a035("04220e032519", 212, 100))
m.bgGradient = m.top.findNode(_l1d_14a035("faf81bf30303110816ff", 117, 227))
m.navHome = m.top.findNode(_l1d_14a035("c8d8c6f7d3d8e3", 255, 55))
m.navMovies = m.top.findNode(_l1d_14a035("a79b95cdb29eb2b1a2", 49, 72))
m.navTv = m.top.findNode(_l1d_14a035("615b6f9475", 162, 149))
m.navCategories = m.top.findNode(_l1d_14a035("353d5361465e50514c64505f6c", 235, 176))
m.navSearch = m.top.findNode(_l1d_14a035("8696846a9ba294a6a4", 223, 213))
m.toastGroup = m.top.findNode(_l1d_14a035("5f7778696b9b7389767e", 183, 156))
m.toastText = m.top.findNode(_l1d_14a035("9492879ca0c397adac", 160, 192))
m.exitModal = m.top.findNode(_l1d_14a035("161628100a2b292f37", 151, 36))
m.btnExitCancel = m.top.findNode(_l1d_14a035("a1b29b89b7abc197bcb0c0c1bb", 14, 53))
m.btnExitConfirm = m.top.findNode(_l1d_14a035("8b98856f9d91a781989aa5a3bfa5", 12, 29))
if m.btnExitCancel <> invalid then m.btnExitCancel.observeField(_l1d_14a035("d4cacccfedefb7ecf6f2f3e7fbfd", 80, 162), _l1d_14a035("53557371656b81666a6a6b75", 38, 10))
if m.btnExitConfirm <> invalid then m.btnExitConfirm.observeField(_l1d_14a035("94a8acaf9b9f95aaa6b0b1c7b9bd", 9, 41), _l1d_14a035("f4f62006fa182a090b160c2816", 168, 45))
m.navHome.observeField(_l1d_14a035("f60e1215fd01f7100c16132d1f23", 139, 13), _l1d_14a035("f2f619fd171c040510", 169, 44))
m.navMovies.observeField(_l1d_14a035("546a6c6f6d6f976c767273877b7d", 96, 82), _l1d_14a035("8f91b48ea2c0a1aba5a4b1", 162, 194))
m.navTv.observeField(_l1d_14a035("bbd3d7dac2c6fcd5d1dbd8f2e4e8", 171, 242), _l1d_14a035("8688ab8d99be9f", 102, 125))
m.navCategories.observeField(_l1d_14a035("00f8fcff070b211a16201d17292d", 59, 167), _l1d_14a035("9a9cbf958dbd9e94a8adb89eb8b7a8", 48, 59))
if m.navSearch <> invalid then m.navSearch.observeField(_l1d_14a035("75636568767858857f8b94809496", 156, 119), _l1d_14a035("f3f7daf2e8c6fffef00210", 147, 247))
m.navBtns = [m.navHome, m.navMovies, m.navTv, m.navCategories, m.navSearch]
m.verifyOverlay = m.top.findNode(_l1d_14a035("9fb5a1afbba59ab4cab6c7cfba", 218, 243))
m.verifyTitle = m.top.findNode(_l1d_14a035("bcacbea6b8bcecb2d2bdc7", 105, 157))
m.verifyDetail = m.top.findNode(_l1d_14a035("6c5e6e68687e8c7082727d83", 32, 22))
m.viewStack = []
m.top.observeField(_l1d_14a035("cad4d3c0c9d6da", 149, 215), _l1d_14a035("fbfd25f8fd090327130a1f20", 32, 172))
m.sessionWatchdogTimer = CreateObject(_l1d_14a035("56563d343e625a5e", 128, 100), _l1d_14a035("cda3aaa5b3", 35, 86))
m.sessionWatchdogTimer.duration = 4
m.sessionWatchdogTimer.repeat = true
m.sessionWatchdogTimer.observeField(_l1d_14a035("42403c4a", 60, 232), _l1d_14a035("242646332c2f38393b574c3a544c53515c6c5c6964", 124, 17))
if KA_IsActivated() then
verifyAndShowHome()
else
showKeyAuthView()
end if
m.initFocusTimer = CreateObject(_l1d_14a035("393f5e6d694b595b", 127, 44), _l1d_14a035("8d656c6773", 226, 215))
m.initFocusTimer.duration = 0.15
m.initFocusTimer.repeat = false
m.initFocusTimer.observeField(_l1d_14a035("5e70786a", 198, 190), _l1d_14a035("41432d4953693a5665767b5b6b6a7589", 14, 224))
m.initFocusTimer.control = _l1d_14a035("c0bcd4c8c5", 156, 209)
end sub
sub verifyAndShowHome()
if ((19917 - 2213 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1Ill1l = KA_GetSavedLicense()
_llIll1l = KA_GetSavedExpiry()
if KA_IsExpired(_llIll1l) then
KA_ClearLicense()
showToast(_l1d_14a035("4b2b242d351d36745c322d49314b4d", 242, 141))
showKeyAuthView()
if m.keyAuthView <> invalid then
_lIIll1l = m.keyAuthView.findNode(_l1d_14a035("bbb7afbdc1cad6baccc4bfbd", 108, 156))
if _lIIll1l <> invalid then
_lIIll1l.text = _l1d_14a035("2e23201c71303039423a324b89445041955d434e5a526c6ea7b083727e7d6e87c58d85829682d79b97e0a4a59da5a1b7f5b4b4bdc6beb6cf0dc7d8bf13", 250, 139)
end if
end if
return
end if
setHeaderVisible(false)
if m.verifyOverlay <> invalid then
m.verifyOverlay.visible = true
if m.verifyTitle <> invalid then m.verifyTitle.text = _l1d_14a035("51617b736d897c7e78be658b888593a18ef0d9", 197, 190) + _l1Ill1l
if m.verifyDetail <> invalid then m.verifyDetail.text = _l1d_14a035("270e121511160826241e68172f714236413f5c443266533b4995445c9e5e656964745e76b67d837c7d877586ce9881d7999a8caa90a4eef1f4", 247, 115)
end if
if m.verifyTask <> invalid then m.verifyTask.control = _l1d_14a035("50526a5c", 183, 108)
m.verifyTask = CreateObject(_l1d_14a035("04fc2b1a24080004", 228, 110), _l1d_14a035("84b59c97aeb2b998c6b7c2", 27, 52))
m.verifyTask.action = _l1d_14a035("55475f59516f", 164, 131)
m.verifyTask.observeField(_l1d_14a035("8c84919a96a1", 67, 91), _l1d_14a035("85896f998799a2a4a4899daba7a5bd97afbcc5c1cc", 195, 217))
m.verifyTask.control = _l1d_14a035("787a92", 182, 148)
end sub
sub onStartupVerifyResult()
if ((79101 - 8789 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.verifyOverlay <> invalid then m.verifyOverlay.visible = false
_lI1I11l = m.verifyTask.result
if _lI1I11l <> invalid and _lI1I11l.success = true then
showToast(_l1d_14a035("f5d3ccd5dfe5de9e00e1fbf1fff3c9b6", 35, 134) + KA_GetSavedLicense())
showHomeView(_l1d_14a035("b8b4b9c4", 191, 225))
startSessionWatchdog()
else
_l11I11l = _l1d_14a035("351d26271f1f30f6322e40413141354b", 62, 195)
if _lI1I11l <> invalid and _lI1I11l.message <> invalid and _lI1I11l.message <> "" then
_l11I11l = KA_CleanAuthMessage(_lI1I11l.message)
end if
KA_ClearLicense()
showToast(_l1d_14a035("ccfe0911ea1800f21b0911d5de", 16, 138) + _l11I11l)
showKeyAuthView()
if m.keyAuthView <> invalid then
_llII11l = m.keyAuthView.findNode(_l1d_14a035("cfd7c7dde1deb6daecdcd7dd", 74, 150))
if _llII11l <> invalid then
_llII11l.text = _l1d_14a035("507290767f884e4b", 139, 139) + _l11I11l + chr(10) + _l1d_14a035("62333c46773e44413e4c5a478f59669861636da4666b79778171b98185c2b7879294ad99a3bba4acbaece9dcb3adb4c9b6febccad3c5df10d2dc19dbe0eeecf6e62ef5fbf8f50311fe4612072658", 101, 38)
end if
end if
end if
end sub
sub onSceneFocus()
if ((30988 - 7747 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.top.hasFocus() then
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then return
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
end sub
sub onInitFocusTimer()
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then return
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
if m.initFocusTimer <> invalid then m.initFocusTimer.control = _l1d_14a035("ccc8b6d2", 44, 109)
end sub
sub showHomeView(_l1I1ll1 = _l1d_14a035("919b9ca7", 168, 209) as String)
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("cbfcf5ff50070d1a1715132068232d227432222d373541458c4444954f4c9e585a556961676facb94c737d847986ce8c8a83958fe0a29ce9abb09eaca6b6feb5bbc8c5c3c1ce16d2d7c622d1dd2befe6eae3f1f3ebfe3c", 221, 71))
return
end if
clearViews()
m.homeView = CreateObject(_l1d_14a035("868e6d7c769aa2a6", 220, 216), _l1d_14a035("92747580b482899e", 44, 46))
m.homeView.category = _l1I1ll1
m.homeView.observeField(_l1d_14a035("e2f701fdfef20608f0fe121d", 16, 127), _l1d_14a035("d2d6f2d2e4dff8ede9f3f4eafc00", 121, 188))
m.homeView.observeField(_l1d_14a035("9a8d9f878b8e7aaaa098b5", 142, 157), _l1d_14a035("22260b2b2c371043373d3f422c42525049", 29, 176))
m.viewHost.appendChild(m.homeView)
m.viewStack.Push(m.homeView)
setHeaderVisible(true)
focusActiveView(m.homeView)
end sub
sub onHomeScrollEvent()
checkLicenseOnInteraction()
end sub
sub showDetailsView(_ll1Il11 as Object)
if ((29952 - 4992 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.detailsView = CreateObject(_l1d_14a035("d9d900f701e5e1e5", 98, 201), _l1d_14a035("b7dbcde5f0eee0befcf3e8", 20, 103))
m.detailsView.content = _ll1Il11
m.detailsView.observeField(_l1d_14a035("bbcad2bdb8d9d1d9dee0", 218, 17), _l1d_14a035("c9cb00cfd7e2fde2f6dee7e9", 104, 194))
m.viewHost.appendChild(m.detailsView)
m.viewStack.Push(m.detailsView)
setHeaderVisible(false)
m.detailsView.setFocus(true)
end sub
sub showPlayerView(_l1l1I11 as Object)
m.playerView = CreateObject(_l1d_14a035("7d8da4bbb599a1a5", 120, 115), _l1d_14a035("486f7f6a817958868d82", 220, 188))
m.playerView.playConfig = _l1l1I11
m.playerView.observeField(_l1d_14a035("13070d0c19ef1626112820", 156, 20), _l1d_14a035("090de31515fc15e5241a152412", 147, 13))
m.viewHost.appendChild(m.playerView)
m.viewStack.Push(m.playerView)
setHeaderVisible(false)
m.playerView.setFocus(true)
end sub
sub showSearchView()
clearViews()
m.searchView = CreateObject(_l1d_14a035("1a30ff0e1a3c3638", 85, 243), _l1d_14a035("0b3c433547451a4a5142", 223, 127))
m.searchView.observeField(_l1d_14a035("d2c3cdc9ceded2d404eadee9", 230, 61), _l1d_14a035("dee0c200f4efe4fdf70300180c0e", 10, 121))
m.viewHost.appendChild(m.searchView)
m.viewStack.Push(m.searchView)
setHeaderVisible(true)
m.searchView.setFocus(true)
end sub
sub showMyListView()
clearViews()
m.myListView = CreateObject(_l1d_14a035("a3c1889fabcdc7c9", 145, 192), _l1d_14a035("465d4d73706e537f867b", 221, 182))
m.myListView.observeField(_l1d_14a035("e9e2eee8e5fff1f5db0bfd08", 67, 185), _l1d_14a035("858971798b966394a09a9f91a3a7", 87, 77))
m.viewHost.appendChild(m.myListView)
m.viewStack.Push(m.myListView)
setHeaderVisible(true)
m.myListView.setFocus(true)
end sub
sub showCategoriesView()
clearViews()
m.categoriesView = CreateObject(_l1d_14a035("674d8c7b77596769", 47, 10), _l1d_14a035("11364e40414c54504f5c445c5b6c", 195, 145))
m.categoriesView.observeField(_l1d_14a035("85867e9095a08890ada2aea8a99fb1b5", 113, 115), _l1d_14a035("bec0a8cdc3d7d8d3c9c7b0e9e3efece4f8fa", 218, 9))
m.viewHost.appendChild(m.categoriesView)
m.viewStack.Push(m.categoriesView)
setHeaderVisible(true)
m.categoriesView.setFocus(true)
end sub
sub showKeyAuthView()
stopSessionWatchdog()
clearViews()
m.keyAuthView = CreateObject(_l1d_14a035("90aeb5ccd8bab4b6", 177, 205), _l1d_14a035("3b180f3a11132a3b313025", 176, 64))
m.keyAuthView.observeField(_l1d_14a035("8d8ea68eaa9cb29a9fa199c2afb2bbc8cb", 202, 226), _l1d_14a035("14183e13123d0c102f3b183134312a2d", 245, 122))
m.keyAuthView.observeField(_l1d_14a035("81797b9a8bbb8d94a5", 110, 116), _l1d_14a035("b1b39bb4d39ecdcfcea8d0d2e1d2", 198, 8))
m.viewHost.appendChild(m.keyAuthView)
m.viewStack.Push(m.keyAuthView)
setHeaderVisible(false)
focusActiveView(m.keyAuthView)
end sub
sub onKeyAuthSuccess()
showToast(_l1d_14a035("516f6c717f657aba5c81778d7f8b839599d86c91a2a5aa9b9eb6a6c2c5b3fe", 81, 52))
showHomeView(_l1d_14a035("201c211c", 103, 17))
startSessionWatchdog()
end sub
sub onKeyAuthClose()
if ((14760 - 2952 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if KA_IsActivated() then
showHomeView(_l1d_14a035("ecf0f500", 219, 57))
else
showExitModal()
end if
end sub
sub onCategorySelected(_llI11II as Object)
_lI111II = _llI11II.getData()
if _lI111II = invalid or _lI111II = "" then return
if _lI111II = _l1d_14a035("687d7c70848c", 16, 5) then
showSearchView()
else if _lI111II = _l1d_14a035("7f94829ca4a3ab9894", 52, 60) then
showMyListView()
else if _lI111II = _l1d_14a035("404d344f464a51", 217, 142) then
showKeyAuthView()
else
showHomeView(_lI111II)
end if
end sub
sub clearViews()
if ((30636 - 3404 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.viewHost.removeChildrenIndex(m.viewHost.getChildCount(), 0)
m.viewStack.Clear()
end sub
sub setHeaderVisible(_l1lI1ll as Boolean)
if ((33328 - 4166 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.headerBar.visible = _l1lI1ll
m.accentLine.visible = _l1lI1ll
m.topBar.visible = _l1lI1ll
if m.bgGradient <> invalid then m.bgGradient.visible = _l1lI1ll
if _l1lI1ll then
m.viewHost.translation = [0, 140]
else
m.viewHost.translation = [0, 0]
end if
end sub
sub onItemSelected(_lIIll1l as Object)
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("dbe8f5fb30f7fdf6f7010f0048130d1e5412322d273121256c3040753f487e4846514951574f98994c635d647566ae6c7683758bc08288c98b8c9e9ca296dea5aba4a5afbdaef6beb7d602d1c90bcbd2d6e3e1dfebde28", 71, 189))
return
end if
_lll1l1l = _lIIll1l.getData()
if _lll1l1l <> invalid then
showDetailsView(_lll1l1l)
end if
end sub
sub onPlayAction(_l1II11l as Object)
if ((7532 - 1883 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llII11l = _l1II11l.getData()
if _llII11l <> invalid then
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("01cedbe116dde3dcdde7f5e62ef9f3043af818130d17070b5216265b252e642e2c372f373d357e7f7249434a5b4c9464615662a36d6bac78798180bb7d83c4868799979d91d9a0a69fa0aab8a9f1b9b2d1fdccc406d6d8ddcdd4db1d", 231, 67))
return
end if
m.pendingPlayConfig = _llII11l
showToast(_l1d_14a035("976b816d738376747ec87f858e8f89a798e0ac9db5a4efe0b4afaddab2d0e4c1d9d705080b", 111, 94))
if m.playVerifyTask <> invalid then m.playVerifyTask.control = _l1d_14a035("5d5d6767", 126, 48)
m.playVerifyTask = CreateObject(_l1d_14a035("e0eec5dcd8fa0406", 89, 181), _l1d_14a035("9fbcb39eb5b7ce9dcdc2dd", 144, 196))
m.playVerifyTask.action = _l1d_14a035("9aaaa4bcb6b2", 213, 247)
m.playVerifyTask.observeField(_l1d_14a035("67556e6b5570", 76, 41), _l1d_14a035("acae97b6aec9a5bbc7c5c1dbb3cddae3dde8", 194, 255))
m.playVerifyTask.control = _l1d_14a035("918f9b", 124, 99)
end if
end sub
sub onPlayVerifyResult()
if m.playVerifyTask = invalid then return
_llI1lIl = m.playVerifyTask.result
if _llI1lIl = invalid then return
if _llI1lIl.success = true then
if _llI1lIl.expiry <> invalid then U_PrefSet(_l1d_14a035("e5de17e0fef9f5010b", 36, 150), _llI1lIl.expiry)
if m.pendingPlayConfig <> invalid then
_l111lIl = m.pendingPlayConfig
m.pendingPlayConfig = invalid
showPlayerView(_l111lIl)
end if
else
_lI11lIl = _l1d_14a035("00e6eff0ea08f9c1120214fe050e12", 47, 157)
if _llI1lIl.message <> invalid and _llI1lIl.message <> "" then _lI11lIl = KA_CleanAuthMessage(_llI1lIl.message)
m.pendingPlayConfig = invalid
kickoutUser(_l1d_14a035("4162656e7b7e32597d858786885d4a869ba8a459a8a8a1aab2bab371bdc67ac7cb83d2d4d6d2d7e398dcddf5edf9efadb8", 130, 126) + _lI11lIl + _l1d_14a035("8086", 211, 134))
end if
end sub
sub onClosePlayer()
if ((13672 - 3418 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.viewStack.Count() > 0 then
_ll1lIIl = m.viewStack.Peek()
if _ll1lIIl <> invalid and _ll1lIIl.isSubtype(_l1d_14a035("acdbe1ccebd9c0e8f7e8", 219, 33)) then
m.viewHost.removeChild(_ll1lIIl)
m.viewStack.Pop()
if m.viewStack.Count() > 0 then
_lIllIIl = m.viewStack.Peek()
focusActiveView(_lIllIIl)
if _lIllIIl <> invalid and _lIllIIl.isSubtype(_l1d_14a035("4b6d6e693d7b7267", 212, 175)) then
_lIllIIl.category = _lIllIIl.category
end if
else
showHomeView(_l1d_14a035("7d858691", 169, 188))
end if
end if
end if
end sub
sub focusActiveView(_l11Ill1 as Object)
if ((20800 - 5200 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _l11Ill1 = invalid then return
if _l11Ill1.isSubtype(_l1d_14a035("8dafa3b1bcc4ac94c8c7bc", 17, 56)) then
setHeaderVisible(false)
_l11Ill1.setFocus(true)
_lllIll1 = _l11Ill1.findNode(_l1d_14a035("3f363651194a43", 70, 9))
if _lllIll1 <> invalid then _lllIll1.setFocus(true)
else if _l11Ill1.isSubtype(_l1d_14a035("3614192434262d1e", 190, 64)) then
setHeaderVisible(true)
_l11Ill1.setFocus(true)
_lllIll1 = _l11Ill1.findNode(_l1d_14a035("eee6fef622f9f914200d0a", 36, 162))
if _lllIll1 <> invalid and _lllIll1.visible then
_lllIll1.setFocus(true)
else
_ll1Ill1 = _l11Ill1.findNode(_l1d_14a035("03f9041e04110f", 229, 108))
if _ll1Ill1 <> invalid then _ll1Ill1.setFocus(true)
end if
else if _l11Ill1.isSubtype(_l1d_14a035("0c39403648421b474e43", 93, 254)) then
setHeaderVisible(true)
_l11Ill1.setFocus(true)
_l1lIll1 = _l11Ill1.findNode(_l1d_14a035("afbcc3c1bfc4dacf", 9, 77))
if _l1lIll1 <> invalid then _l1lIll1.setFocus(true)
else if _l11Ill1.isSubtype(_l1d_14a035("537464767b76767e857e5e8a9186", 221, 181)) then
setHeaderVisible(true)
_l11Ill1.setFocus(true)
_lllIll1 = _l11Ill1.findNode(_l1d_14a035("544d5670615965636a68616b", 59, 251))
if _lllIll1 <> invalid then _lllIll1.setFocus(true)
else if _l11Ill1.isSubtype(_l1d_14a035("352c3a223b3b5c2e3546", 110, 18)) then
setHeaderVisible(true)
_l11Ill1.setFocus(true)
_lIlIll1 = _l11Ill1.findNode(_l1d_14a035("7c7c757daf7d8b99", 186, 166))
if _lIlIll1 <> invalid then _lIlIll1.setFocus(true)
else if _l11Ill1.isSubtype(_l1d_14a035("bce9f0cb0204ebecf20116", 136, 249)) then
setHeaderVisible(false)
_l1lIll1 = _l11Ill1.findNode(_l1d_14a035("77708f777f809081", 70, 74))
if _l1lIll1 <> invalid then
_l1lIll1.setFocus(true)
else
_l11Ill1.setFocus(true)
end if
else
_l11Ill1.setFocus(true)
end if
end sub
sub onNavHome()
showHomeView(_l1d_14a035("abb3b4bf", 233, 42))
end sub
sub onNavMovies()
if ((9771 - 3257 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
showHomeView(_l1d_14a035("c8cdd9cdccdd", 1, 92))
showToast(_l1d_14a035("f7252e342b294437352f79284d3d474452504a943a5b67675e73", 71, 244))
end sub
sub onNavTv()
showHomeView(_l1d_14a035("253a2c444334", 209, 131))
showToast(_l1d_14a035("f0061f25141a25181e28ea1d294349353b4d02393a0b3b494d6867", 11, 161))
end sub
sub onNavCategories()
if ((27712 - 6928 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
showCategoriesView()
end sub
sub onNavSearch()
showSearchView()
end sub
sub onShowToastChange()
_llIl1lI = m.top.showToast
if _llIl1lI <> invalid and _llIl1lI <> "" then
showToast(_llIl1lI)
end if
end sub
sub showToast(_l11IIlI as String)
m.toastText.text = _l11IIlI
m.toastGroup.visible = true
m.toastTimer = CreateObject(_l1d_14a035("1806fdf4f0122022", 11, 159), _l1d_14a035("d9dfe6f1ff", 75, 186))
m.toastTimer.duration = 2.5
m.toastTimer.observeField(_l1d_14a035("f4040efe", 71, 211), _l1d_14a035("12142426fa222b1c26", 27, 159))
m.toastTimer.control = _l1d_14a035("3e48564851", 123, 54)
end sub
sub hideToast()
if ((28197 - 9399 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.toastGroup.visible = false
if m.toastTimer <> invalid then m.toastTimer.control = _l1d_14a035("bebad8c4", 212, 23)
end sub
sub showExitModal()
if ((55512 - 9252 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.exitModal <> invalid then
m.exitModal.visible = true
if m.btnExitCancel <> invalid then m.btnExitCancel.setFocus(true)
end if
end sub
sub hideExitModal()
if ((18316 - 4579 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.exitModal <> invalid then
m.exitModal.visible = false
if m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
end sub
sub onExitCancel()
if ((29274 - 4879 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
hideExitModal()
end sub
sub onExitConfirm()
m.top.exitApp = true
end sub
function onKeyEvent(_lI11l1l as String, _lII1l1l as Boolean) as Boolean
if not _lII1l1l then return false
if m.exitModal <> invalid and m.exitModal.visible then
if _lI11l1l = _l1d_14a035("060c0d08", 74, 222) then
hideExitModal()
return true
else if _lI11l1l = _l1d_14a035("cac6cadb", 32, 126) or _lI11l1l = _l1d_14a035("7177", 70, 62) then
if m.btnExitCancel <> invalid then
m.btnExitCancel.setFocus(true)
return true
end if
else if _lI11l1l = _l1d_14a035("6751625675", 200, 173) or _lI11l1l = _l1d_14a035("5a524d59", 223, 159) then
if m.btnExitConfirm <> invalid then
m.btnExitConfirm.setFocus(true)
return true
end if
else if _lI11l1l = _l1d_14a035("636a", 68, 88) or _lI11l1l = _l1d_14a035("7d96a09c9991", 210, 220) then
if m.btnExitConfirm <> invalid and m.btnExitConfirm.hasFocus() then
onExitConfirm()
return true
else
onExitCancel()
return true
end if
end if
return true
end if
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then
if _lI11l1l = _l1d_14a035("4f515661", 84, 25) then
showExitModal()
return true
end if
return true
end if
if KA_IsActivated() then
checkLicenseOnInteraction()
end if
if m.top.hasFocus() then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
if _lI11l1l = _l1d_14a035("495f664c55596f", 105, 67) then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_lllIl1l = m.viewStack.Peek()
if _lllIl1l <> invalid and _lllIl1l.isSubtype(_l1d_14a035("9d74728d748aa9898091", 167, 166)) then
return false
end if
end if
showSearchView()
return true
end if
if m.topBar <> invalid and m.topBar.isInFocusChain() then
if _lI11l1l = _l1d_14a035("3e4c5751", 32, 250) then
if m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
return true
end if
else if _lI11l1l = _l1d_14a035("80868792", 18, 16) then
if m.viewStack.Count() > 0 then
_lIl1l1l = m.viewStack.Peek()
if _lIl1l1l.isSubtype(_l1d_14a035("0622273224343b4c", 207, 127)) then
showExitModal()
return true
else
focusActiveView(_lIl1l1l)
return true
end if
else
showExitModal()
return true
end if
else if _lI11l1l = _l1d_14a035("101a1c11", 95, 221) or _lI11l1l = _l1d_14a035("544e4f5362", 96, 66) then
_l111l1l = 0
for _ll11l1l = 0 to m.navBtns.Count() - 1
if m.navBtns[_ll11l1l].hasFocus() then
_l111l1l = _ll11l1l
exit for
end if
end for
if _lI11l1l = _l1d_14a035("ddf9ee00e7", 247, 88) then
_llI1l1l = (_l111l1l + 1) Mod m.navBtns.Count()
else
_llI1l1l = (_l111l1l - 1 + m.navBtns.Count()) Mod m.navBtns.Count()
end if
m.navBtns[_llI1l1l].setFocus(true)
return true
else if _lI11l1l = _l1d_14a035("7c7a", 202, 189) then
return true
end if
return false
end if
if _lI11l1l = _l1d_14a035("878b8c87", 203, 222) then
if m.viewStack.Count() > 1 then
_lllIl1l = m.viewStack.Pop()
m.viewHost.removeChild(_lllIl1l)
_l1I1l1l = m.viewStack.Peek()
if _l1I1l1l <> invalid then
focusActiveView(_l1I1l1l)
return true
end if
else if m.viewStack.Count() = 1 and not m.viewStack[0].isSubtype(_l1d_14a035("486c716c5e767586", 131, 125)) then
if m.viewStack[0].isSubtype(_l1d_14a035("b19ea5c0b7b9a0e1a7b6cb", 168, 206)) and not KA_IsActivated() then
showExitModal()
return true
end if
showHomeView(_l1d_14a035("6d777873", 128, 133))
return true
else
showExitModal()
return true
end if
else if _lI11l1l = _l1d_14a035("767c", 158, 139) then
if m.headerBar.visible then
if m.viewStack.Count() > 0 then
_lIl1l1l = m.viewStack.Peek()
if _lIl1l1l <> invalid then
if _lIl1l1l.isSubtype(_l1d_14a035("d1f202f4f9f414fc031cfc080f24", 77, 195)) then
m.navCategories.setFocus(true)
return true
else if _lIl1l1l.isSubtype(_l1d_14a035("d4adacbcb0bce9c3c2d3", 162, 227)) then
m.navSearch.setFocus(true)
return true
else if _lIl1l1l.isSubtype(_l1d_14a035("e0c5d5c7c8c3e3cfd6eb0bdbe2f3", 239, 52)) or _lIl1l1l.isSubtype(_l1d_14a035("cf06d4fc1515f6080f20", 14, 140)) then
m.navCategories.setFocus(true)
return true
else if _lIl1l1l.isSubtype(_l1d_14a035("03ebece7fdf1f0e5", 49, 138)) and _lIl1l1l.category <> invalid then
_l1l1l1l = _lIl1l1l.category
if _l1l1l1l = _l1d_14a035("0f100c1c2318", 95, 221) then
m.navMovies.setFocus(true)
return true
else if _l1l1l1l = _l1d_14a035("5e4b655d546d", 229, 200) or _l1l1l1l = _l1d_14a035("4a4b", 223, 159) then
m.navTv.setFocus(true)
return true
else if _l1l1l1l <> _l1d_14a035("efebf0fb", 143, 8) then
m.navCategories.setFocus(true)
return true
end if
end if
end if
end if
m.navHome.setFocus(true)
return true
end if
end if
return false
end function
sub startSessionWatchdog()
m.watchdogTickCount = 0
if m.sessionWatchdogTimer <> invalid then
m.sessionWatchdogTimer.control = _l1d_14a035("6d716f73", 192, 186)
m.sessionWatchdogTimer.control = _l1d_14a035("e2e4faeced", 63, 150)
end if
end sub
sub stopSessionWatchdog()
if ((33945 - 6789 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.sessionWatchdogTimer <> invalid then
m.sessionWatchdogTimer.control = _l1d_14a035("0e123014", 240, 139)
end if
end sub
sub checkLicenseOnInteraction()
if ((12162 - 4054 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if not KA_IsActivated() then
kickoutUser(_l1d_14a035("6a9b949ceda4acb9b6b2b2bf05c1be0ec7cbc31adee3cfdfd7e92532c5ecf8fff401470703fc1008591d1562262b17271f31772e3643403c3c498f4d524191", 220, 229))
return
end if
_l11lIIl = KA_GetSavedExpiry()
if KA_IsExpired(_l11lIIl) then
kickoutUser(_l1d_14a035("e819020c5d242a272432202d75403a2f813f3f3a54424e529f9c2f6660675c69b16f7d667872c3858fcc8e93819f8999e1a8aeaba8b6a4b1f9c5bab905b4d00ed2d9ddc6e4e6cee129dddbe4f0f7fe0507014d", 213, 92))
return
end if
_lI1lIIl = CreateObject(_l1d_14a035("707ea8867e90a48a919c", 57, 37)).AsSeconds()
if m.lastOnlineVerifyTime = invalid then m.lastOnlineVerifyTime = 0
if (_lI1lIIl - m.lastOnlineVerifyTime) >= 4 then
m.lastOnlineVerifyTime = _lI1lIIl
triggerOnlineVerify()
end if
end sub
sub triggerOnlineVerify()
if not KA_IsActivated() then return
if m.watchdogTask <> invalid and m.watchdogTask.state = _l1d_14a035("1b231d20202620", 227, 138) then return
if m.watchdogTask <> invalid then
m.watchdogTask.unobserveField(_l1d_14a035("dbe9e2dfe9e4", 60, 141))
m.watchdogTask = invalid
end if
m.watchdogTask = CreateObject(_l1d_14a035("4d3d342b25495155", 136, 83), _l1d_14a035("24553c374e525938665762", 219, 148))
m.watchdogTask.action = _l1d_14a035("899f93b1a5a7", 150, 169)
m.watchdogTask.observeField(_l1d_14a035("51435859435e", 174, 117), _l1d_14a035("e0e41ef707fbf900f803370b210d13234d1d32331f3a", 111, 224))
m.watchdogTask.control = _l1d_14a035("a8aeaa", 160, 182)
end sub
sub onSessionWatchdogTick()
if ((63117 - 7013 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if not KA_IsActivated() then
stopSessionWatchdog()
return
end if
_lll1Il1 = KA_GetSavedExpiry()
if KA_IsExpired(_lll1Il1) then
kickoutUser(_l1d_14a035("235855532867656e77716780407b85764c927a858f89a1a55e677aa9b3b2a3bc7cc2bcb9cbb98ed0ce97d9dad4dad8ecacebe9f2fbf5eb04c4fc0df4d0070fd919181c191f252134f4242e2b4342414046500c", 27, 225))
return
end if
triggerOnlineVerify()
end sub
sub onWatchdogVerifyResult()
if m.watchdogTask = invalid then return
_lIll111 = m.watchdogTask.result
if _lIll111 = invalid then return
if _lIll111.success = true then
if _lIll111.expiry <> invalid and _lIll111.expiry <> "" then
U_PrefSet(_l1d_14a035("2c255e2747423c4a52", 165, 94), _lIll111.expiry)
if KA_IsExpired(_lIll111.expiry) then
kickoutUser(_l1d_14a035("667b9894498888919a92aaa3619ca8b96db5bbc6b2cac4c67f88bbcad6d5e6df9de5ddfaeefaaff3efb8fcfd15fd190fcd0c0c151e162e27e51f3037f14832fa3c3b3d5a4246645715676f6c6665646367732d", 138, 147))
return
end if
end if
else
_l1ll111 = _lIll111.message
if _l1ll111 = invalid then _l1ll111 = ""
_llll111 = LCase(_l1ll111)
_lIIIl11 = (InStr(1, _llll111, _l1d_14a035("9ebebdb8ba01c7b4b6", 246, 28)) > 0 or InStr(1, _llll111, _l1d_14a035("7f8d9fa18ca28e", 42, 59)) > 0 or InStr(1, _llll111, _l1d_14a035("382f31343e4733434446", 188, 89)) > 0 or InStr(1, _llll111, _l1d_14a035("899094978f9886dd8ca8", 85, 83)) > 0)
if not _lIIIl11 then
_l1IIl11 = KA_CleanAuthMessage(_l1ll111)
if _l1IIl11 = "" then _l1IIl11 = _l1d_14a035("d7b5aeb7c1a7c000b1c9bbd5d4d5d918e4cc21ebf1e9eae4fae8fc", 115, 152)
kickoutUser(_l1d_14a035("b8999ca5b2b5e9dab4c4b0afc0c20704", 106, 141) + _l1IIl11 + _l1d_14a035("555aed1c28271c316f37332c40308145458a4e53474f4f619f5e5e6b706c6479b7758269c1", 216, 95))
end if
end if
end sub
sub kickoutUser(_lII1I11 as String)
if ((57393 - 8199 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.playerView <> invalid then
_l11II11 = m.playerView.findNode(_l1d_14a035("294341454e16554d485743", 82, 5))
if _l11II11 <> invalid then _l11II11.control = _l1d_14a035("2c361e38", 139, 52)
m.viewHost.removeChild(m.playerView)
m.playerView = invalid
end if
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
for _l1I1I11 = m.viewStack.Count() - 1 to 0 step -1
_lIlII11 = m.viewStack[_l1I1I11]
if _lIlII11 <> invalid and _lIlII11.isSubtype(_l1d_14a035("687f7d987f9574948b9c", 7, 17)) then
_ll1II11 = _lIlII11.findNode(_l1d_14a035("77616f736c64737b868591", 74, 59))
if _ll1II11 <> invalid then _ll1II11.control = _l1d_14a035("0e143016", 113, 12)
m.viewHost.removeChild(_lIlII11)
end if
end for
end if
stopSessionWatchdog()
KA_ClearLicense()
clearViews()
showKeyAuthView()
if m.keyAuthView <> invalid then
_lllII11 = m.keyAuthView.findNode(_l1d_14a035("5c64546a6e6b43677969747a", 2, 235))
if _lllII11 <> invalid then
_lllII11.text = _lII1I11
end if
_llI1I11 = m.keyAuthView.findNode(_l1d_14a035("8f91979d9ebea6", 32, 77))
if _llI1I11 <> invalid then
_llI1I11.color = _l1d_14a035("336e63663f424144484b", 143, 116)
_llI1I11.width = 120
end if
_lI11I11 = m.keyAuthView.findNode(_l1d_14a035("34363c424315493f3e", 208, 130))
if _lI11I11 <> invalid then
_lI11I11.text = _l1d_14a035("544e5e5a595a5c", 66, 68)
_lI11I11.color = _l1d_14a035("a35e5f62b1b4babd7174", 232, 203)
end if
_l1lII11 = m.keyAuthView.findNode(_l1d_14a035("c8d2e0d8dad7c1f7e702fc", 147, 232))
if _l1lII11 <> invalid then _l1lII11.text = _l1d_14a035("4a2f322f484b7d723e544e554a4e", 101, 38)
end if
showToast(_l1d_14a035("513730313b493a827343554f564f53b09d7f606364797cb291737d857c80", 103, 38))
end sub
function _l1d_14a035(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function