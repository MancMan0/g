sub init()
m.heroBackdrop = m.top.findNode(_l1d_462afc("8e8c9a98709495a0a2afadb7", 131, 163))
m.heroBadge = m.top.findNode(_l1d_462afc("eaeadafa10f2f8feff", 112, 210))
m.heroTitle = m.top.findNode(_l1d_462afc("1a223a221a2a402b37", 76, 246))
m.heroMeta = m.top.findNode(_l1d_462afc("f1efddfb20fbeffd", 243, 86))
m.heroDesc = m.top.findNode(_l1d_462afc("bfbfcfcfa7cbdccf", 192, 23))
m.heroPlayBtn = m.top.findNode(_l1d_462afc("1c2a1826402f35205a333c", 187, 73))
m.heroWatchlistBtn = m.top.findNode(_l1d_462afc("1e1e0a2af5261c2a363d3d262e1b344d", 210, 100))
m.rowList = m.top.findNode(_l1d_462afc("9a98a3c19fa8b2", 99, 137))
m.loadingGroup = m.top.findNode(_l1d_462afc("3036333141413d60564e575d", 100, 40))
m.heroPlayBtn.observeField(_l1d_462afc("a3afb3b6b2b6e4b1bdb7c0cec0c4", 37, 92), _l1d_462afc("4b4d2a4a3a5a1e5d5550", 144, 76))
m.heroWatchlistBtn.observeField(_l1d_462afc("97898b8e989abaaba5b1b6a6babc", 190, 187), _l1d_462afc("fbfde6fef20ad50efc121e1d250e0ef12b26293531", 150, 2))
m.rowList.observeField(_l1d_462afc("68806ba86e828d9e8b95919a869a9c", 244, 226), _l1d_462afc("2f3110383320364a4526534d59624e6264", 92, 252))
m.rowList.observeField(_l1d_462afc("70807b6482969179959c9592abad", 90, 72), _l1d_462afc("9498a79d88c58d9faac8b2b19ea7b4b8", 117, 122))
m.top.observeField(_l1d_462afc("8c968d8283989c", 113, 117), _l1d_462afc("7b7d58847b747164908c989499", 18, 254))
loadHomeData()
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.rowList <> invalid then m.rowList.setFocus(true)
end if
end sub
sub onCategoryChange()
loadHomeData()
end sub
sub loadHomeData()
m.loadingGroup.visible = true
if m.catalogTask <> invalid then m.catalogTask.control = _l1d_462afc("3038423a", 122, 7)
m.catalogTask = CreateObject(_l1d_462afc("1220374e4a2c3a3c", 59, 201), _l1d_462afc("7091a797a5aba696a6bbb6", 128, 173))
_lIl1lIl = m.top.category
if _lIl1lIl = invalid or _lIl1lIl = "" then _lIl1lIl = _l1d_462afc("3f3d424d", 62, 233)
m.catalogTask.category = _lIl1lIl
m.catalogTask.observeField(_l1d_462afc("5c76636c7671", 122, 84), _l1d_462afc("c4c8dec3dbc9d9d9d402e2dbe3e5e9", 227, 56))
m.catalogTask.control = _l1d_462afc("eff1d9", 206, 83)
end sub
sub onCatalogLoaded()
if ((71694 - 7966 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.loadingGroup.visible = false
_ll1lIIl = m.catalogTask.result
if _ll1lIIl <> invalid and _ll1lIIl.getChildCount() > 0 then
m.rowList.content = _ll1lIIl
_lIllIIl = _ll1lIIl.getChild(0)
if _lIllIIl <> invalid and _lIllIIl.getChildCount() > 0 then
updateHero(_lIllIIl.getChild(0))
end if
m.rowList.setFocus(true)
else if m.top.category = _l1d_462afc("f9f0f411fffd190c", 143, 13) or m.top.category = _l1d_462afc("f001f705111113", 178, 43) then
_llllIIl = CreateObject(_l1d_462afc("90a8778690b4acb0", 84, 106), _l1d_462afc("74535552665e5b84687478", 186, 123))
_l1llIIl = _llllIIl.createChild(_l1d_462afc("476e725b6d7b6461837d7f", 85, 49))
_l1llIIl.title = _l1d_462afc("01282c39373541347c284151455355534d97a23f61a36e70797b73838fbb957c90ce", 71, 253)
m.rowList.content = _llllIIl
end if
end sub
sub onRowItemFocused()
_lllIll1 = m.rowList.rowItemFocused
if _lllIll1 <> invalid and _lllIll1.Count() >= 2 then
_lIlIll1 = _lllIll1[0]
_l1I1ll1 = _lllIll1[1]
_lII1ll1 = m.rowList.content
if _lII1ll1 <> invalid and _lIlIll1 < _lII1ll1.getChildCount() then
_l1lIll1 = _lII1ll1.getChild(_lIlIll1)
if _l1lIll1 <> invalid and _l1I1ll1 < _l1lIll1.getChildCount() then
updateHero(_l1lIll1.getChild(_l1I1ll1))
end if
end if
end if
m.top.scrollEvent = true
end sub
sub updateHero(_l1IlIl1 as Object)
if _l1IlIl1 = invalid then return
m.currentItem = _l1IlIl1
m.heroBackdrop.uri = _l1IlIl1.HDBackgroundImageUrl
m.heroTitle.text = _l1IlIl1.title
_lIIlIl1 = _l1d_462afc("0304001017", 191, 17)
if _l1IlIl1.kind <> invalid and _l1IlIl1.kind = _l1d_462afc("aaaf", 100, 154) then
_lIIlIl1 = _l1d_462afc("e4e996ecf4fef9", 56, 120)
else if _l1IlIl1.ContentType = 2 then
_lIIlIl1 = _l1d_462afc("50554258606a65", 24, 4)
end if
if m.heroBadge <> invalid then
m.heroBadge.text = _l1d_462afc("969aa1919399a9ad14", 87, 133) + _lIIlIl1
end if
_l1l1Il1 = ""
if _l1IlIl1.Rating <> invalid and _l1IlIl1.Rating <> "" then
_l1l1Il1 = _l1d_462afc("c8c1", 21, 137) + _l1IlIl1.Rating + _l1d_462afc("070a0d", 158, 73)
end if
if _l1IlIl1.ReleaseDate <> invalid and _l1IlIl1.ReleaseDate <> "" then
_l1l1Il1 = _l1l1Il1 + _l1IlIl1.ReleaseDate + _l1d_462afc("6d709f7679", 57, 84)
end if
_l1l1Il1 = _l1l1Il1 + _lIIlIl1
if _l1IlIl1.Categories <> invalid and _l1IlIl1.Categories.Count() > 0 then
_lI1lIl1 = ""
_lll1Il1 = 2
if _l1IlIl1.Categories.Count() <= 2 then _lll1Il1 = _l1IlIl1.Categories.Count() - 1
for _llIlIl1 = 0 to _lll1Il1
if _llIlIl1 > 0 then _lI1lIl1 = _lI1lIl1 + _l1d_462afc("6e75", 10, 72)
_lI1lIl1 = _lI1lIl1 + _l1IlIl1.Categories[_llIlIl1].ToStr()
end for
if _lI1lIl1 <> "" then _l1l1Il1 = _l1l1Il1 + _l1d_462afc("bdc0f7c6c9", 22, 135) + _lI1lIl1
end if
m.heroMeta.text = _l1l1Il1
m.heroDesc.text = _l1IlIl1.description
updateHeroWatchlistBtn()
end sub
sub updateHeroWatchlistBtn()
if ((30556 - 7639 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.currentItem = invalid or m.heroWatchlistBtn = invalid then return
if WL_IsFavorite(m.currentItem.id) then
m.heroWatchlistBtn.text = _l1d_462afc("fc112f000c45354947464c454721", 159, 56)
else
m.heroWatchlistBtn.text = _l1d_462afc("d4dc6ea391aba3a2aaa7a3", 220, 221)
end if
end sub
sub onHeroWatchlistToggle()
if m.currentItem = invalid then return
_lIl1I11 = _l1d_462afc("81827c8695", 250, 234)
if m.currentItem.kind <> invalid and (m.currentItem.kind = _l1d_462afc("4449", 196, 148) or m.currentItem.kind = _l1d_462afc("d3c8dad2d1e2", 161, 1)) then
_lIl1I11 = _l1d_462afc("e0e1", 58, 146)
else if m.currentItem.ContentType = 2 then
_lIl1I11 = _l1d_462afc("fd02", 173, 36)
end if
_l1l1I11 = {
id: m.currentItem.id,
title: m.currentItem.Title,
kind: _lIl1I11,
year: m.currentItem.ReleaseDate,
poster: m.currentItem.HDPosterUrl,
rating: m.currentItem.Rating
}
WL_ToggleFavorite(_l1l1I11)
updateHeroWatchlistBtn()
_ll11I11 = m.top.getScene()
if _ll11I11 <> invalid and _ll11I11.hasField(_l1d_462afc("e5dddfeacae8e5faf6", 4, 110)) then
if WL_IsFavorite(m.currentItem.id) then
_ll11I11.showToast = _l1d_462afc("48796b7b7f4675914f5f94849ca6a5ab98966770", 21, 2) + m.currentItem.Title
else
_ll11I11.showToast = _l1d_462afc("406c777c68787c43847b9192526297879fa9a8ae9b99", 149, 121)
end if
end if
end sub
sub onRowItemSelected()
_l1ll1I1 = m.rowList.rowItemSelected
if _l1ll1I1 <> invalid and _l1ll1I1.Count() >= 2 then
_ll1l1I1 = _l1ll1I1[0]
_lIIIlI1 = _l1ll1I1[1]
_llll1I1 = m.rowList.content
if _llll1I1 <> invalid and _ll1l1I1 < _llll1I1.getChildCount() then
_lIll1I1 = _llll1I1.getChild(_ll1l1I1)
if _lIll1I1 <> invalid and _lIIIlI1 < _lIll1I1.getChildCount() then
m.top.selectedItem = _lIll1I1.getChild(_lIIIlI1)
end if
end if
end if
end sub
sub onHeroPlay()
if m.currentItem <> invalid then
m.top.selectedItem = m.currentItem
end if
end sub
function onKeyEvent(_l11l1lI as String, _lI1l1lI as Boolean) as Boolean
if not _lI1l1lI then return false
if _l11l1lI = _l1d_462afc("816f7c7493", 10, 9) then
if m.heroPlayBtn.hasFocus() then
m.heroWatchlistBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("d6d0d2e7", 99, 199) then
if m.heroWatchlistBtn.hasFocus() then
m.heroPlayBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("979f", 45, 63) then
if m.rowList.hasFocus() and m.rowList.rowItemFocused[0] = 0 then
m.heroPlayBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("06001b05", 74, 216) then
if m.heroPlayBtn.hasFocus() or m.heroWatchlistBtn.hasFocus() then
m.rowList.setFocus(true)
return true
end if
end if
return false
end function
function _l1d_462afc(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function