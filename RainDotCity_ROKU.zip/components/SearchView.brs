sub init()
if ((33895 - 6779 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.keyboard = m.top.findNode(_l1d_9f71f3("d0d5c4e2d8e5dbe8", 125, 186))
m.btnGoResults = m.top.findNode(_l1d_9f71f3("cdc6cfbbd6ace6d3dce6e1df", 218, 21))
m.resultsGrid = m.top.findNode(_l1d_9f71f3("2d3b34314b36406f455f55", 116, 39))
m.resultsHeading = m.top.findNode(_l1d_9f71f3("02100906100b153d252c2a2a2a36", 252, 116))
m.noResults = m.top.findNode(_l1d_9f71f3("787c6278898e889395", 64, 74))
m.keyboard.observeField(_l1d_9f71f3("12040c1b", 105, 245), _l1d_9f71f3("a0a28cb3a6b2c089b5b1bdb9be", 194, 243))
m.keyboard.observeField(_l1d_9f71f3("c9cabec8cfd5", 166, 244), _l1d_9f71f3("f3f7d5f60c040b03", 95, 195))
if m.btnGoResults <> invalid then m.btnGoResults.observeField(_l1d_9f71f3("c7bbbfc2dee2a8dde9e3e4daecf0", 145, 212), _l1d_9f71f3("3f4131524650575d", 134, 86))
m.resultsGrid.observeField(_l1d_9f71f3("4c6a5e594e67616d6a827678", 74, 41), _l1d_9f71f3("6f718f8d817cb58a849091a5999b", 232, 232))
if m.keyboard <> invalid then m.keyboard.setFocus(true)
end sub
sub onQueryChange()
_llIll1l = m.keyboard.text
if _llIll1l = invalid then _llIll1l = ""
_lIIll1l = ""
_l1Ill1l = CreateObject(_l1d_9f71f3("9bb3c1b3b4b9b7", 118, 151), _l1d_9f71f3("3d3e701b674a7c272b", 140, 107), _l1d_9f71f3("76", 213, 196))
if _l1Ill1l <> invalid then _lIIll1l = _l1Ill1l.replaceAll(_llIll1l, "") else _lIIll1l = _llIll1l
if _lIIll1l = "" then
m.resultsGrid.content = invalid
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("21110bfb410b0d4a19181056241938242c293d2a71403e7a503d44584c548f5e5e645f5b74aaadb0", 100, 241)
m.resultsHeading.text = _l1d_9f71f3("79695e5f6b666a", 191, 140)
if m.btnGoResults <> invalid then m.btnGoResults.visible = false
return
end if
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("c7b8bfafc3cfd3cfcb93e4dae5e1fee8d40af7ddedb9bcbf", 182, 226)
if m.searchTask <> invalid then m.searchTask.control = _l1d_9f71f3("10101a1a", 222, 131)
m.searchTask = CreateObject(_l1d_9f71f3("2030071e183c484c", 90, 248), _l1d_9f71f3("c80100f00400df0f000b", 90, 191))
m.searchTask.query = _llIll1l
m.searchTask.observeField(_l1d_9f71f3("daf4e1eaf4ef", 122, 210), _l1d_9f71f3("d1d3abe0dfd3e7dfbcf2e3e8f2edef", 24, 90))
m.searchTask.control = _l1d_9f71f3("707682", 184, 134)
end sub
sub onSearchResults()
_lI1I11l = m.searchTask.result
if _lI1I11l <> invalid and _lI1I11l.getChildCount() > 0 then
m.resultsGrid.content = _lI1I11l
m.noResults.visible = false
_l11I11l = _lI1I11l.getChildCount().ToStr()
m.resultsHeading.text = _l1d_9f71f3("91c9b6bfcbc6c29893", 27, 72) + _l11I11l + _l1d_9f71f3("172121273f5c7533647e797a768a487f8951928595908fa8", 154, 100)
if m.btnGoResults <> invalid then
m.btnGoResults.visible = true
m.btnGoResults.text = _l1d_9f71f3("7245634e4d66a6", 115, 65) + _l11I11l + _l1d_9f71f3("a09169767f7b8682b8d5", 227, 221)
end if
else
m.resultsGrid.content = invalid
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("d0b478afb7b5c0ccbd8dd6d2cbd7e09fdfe6dceee6eaf2febac4", 56, 90) + m.keyboard.text + _l1d_9f71f3("6f", 49, 89)
m.resultsHeading.text = _l1d_9f71f3("80b0a5a6b2adb10702fd07", 95, 115)
if m.btnGoResults <> invalid then m.btnGoResults.visible = false
end if
end sub
sub onSubmit()
if ((22410 - 2490 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
end if
end sub
sub onItemSelected()
_l1llIIl = m.resultsGrid.itemSelected
_llllIIl = m.resultsGrid.content
if _llllIIl <> invalid and _l1llIIl >= 0 and _l1llIIl < _llllIIl.getChildCount() then
m.top.selectedItem = _llllIIl.getChild(_l1llIIl)
end if
end sub
function onKeyEvent(_lllIll1 as String, _l1lIll1 as Boolean) as Boolean
if not _l1lIll1 then return false
if _lllIll1 = _l1d_9f71f3("cedae7e1e0", 219, 37) then
if (m.keyboard <> invalid and m.keyboard.isInFocusChain()) or (m.btnGoResults <> invalid and m.btnGoResults.hasFocus()) then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("45515166", 170, 127) then
if m.resultsGrid <> invalid and (m.resultsGrid.hasFocus() or m.resultsGrid.isInFocusChain()) then
_lII1ll1 = m.resultsGrid.itemFocused
if _lII1ll1 = invalid then _lII1ll1 = 0
_l1I1ll1 = m.resultsGrid.numColumns
if _l1I1ll1 = invalid or _l1I1ll1 <= 0 then _l1I1ll1 = 6
if _lII1ll1 <= 0 or (_lII1ll1 Mod _l1I1ll1) = 0 then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("fd07f20c", 242, 103) then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnGoResults <> invalid and m.btnGoResults.visible then
m.btnGoResults.setFocus(true)
return true
else if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("6a72", 29, 2) then
if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("0b0f101b", 87, 214) then
if m.resultsGrid <> invalid and (m.resultsGrid.isInFocusChain() or m.resultsGrid.hasFocus()) then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
end if
return false
end function
function _l1d_9f71f3(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function