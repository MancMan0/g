sub init()
m.keyboard = m.top.findNode(_l1d_a25f62("191e0d29212e222f", 92, 226))
m.btnActivate = m.top.findNode(_l1d_a25f62("eadffcd0f5eb01f3fff709", 209, 55))
m.hwidText = m.top.findNode(_l1d_a25f62("88748d8da0928a89", 179, 173))
m.statusTitle = m.top.findNode(_l1d_a25f62("c3c1d7c7c9d2b0ded6e1eb", 93, 149))
m.statusDetail = m.top.findNode(_l1d_a25f62("c1cbb9d1d3d0aacce0ced9e1", 131, 209))
m.spinnerLabel = m.top.findNode(_l1d_a25f62("d6d8e2e4e7efe90efc02fefa", 125, 200))
m.badgeText = m.top.findNode(_l1d_a25f62("e6e8eef4f507fbe1f0", 184, 12))
m.activatedActions = m.top.findNode(_l1d_a25f62("f1f20af20e00160a0cec0d250d12142c", 10, 134))
m.btnContinue = m.top.findNode(_l1d_a25f62("aebba896adb1cab8bad2c5", 77, 127))
m.btnDeactivate = m.top.findNode(_l1d_a25f62("0c011ef71b1a1f132b1b291f33", 208, 90))
m.btnActivate.observeField(_l1d_a25f62("4741434660622a636d69665e7274", 82, 23), _l1d_a25f62("5254866757675b7563779c747c8580898b", 190, 129))
m.keyboard.observeField(_l1d_a25f62("464b3b494856", 32, 243), _l1d_a25f62("0305eb10240c2c1a30240521212e293638", 72, 220))
if m.btnContinue <> invalid then m.btnContinue.observeField(_l1d_a25f62("69595d60787c4a7b878186788a8e", 151, 116), _l1d_a25f62("bcbeaec5c7c0d0d0caddc6dae2efeaeff1", 156, 201))
if m.btnDeactivate <> invalid then m.btnDeactivate.observeField(_l1d_a25f62("f1dde1e4f0f4d2fffb050efc0e12", 93, 178), _l1d_a25f62("2a2e0b2d2c2d273d2b3b33452254524b56575b", 211, 110))
_lII11ll = KA_GetHwid()
m.hwidText.text = _lII11ll
refreshLicenseState()
if m.keyboard <> invalid then
if m.keyboard.textEditBox <> invalid then
m.keyboard.textEditBox.hintText = _l1d_a25f62("d1ebe8faf0c5dc020b0c060415ddf51e0d", 159, 247)
m.keyboard.textEditBox.maxTextLength = 64
end if
m.keyboard.setFocus(true)
_lllI1ll = KA_GetSavedLicense()
if _lllI1ll <> "" then m.keyboard.text = _lllI1ll
end if
m.top.observeField(_l1d_a25f62("5652617277686a", 174, 142), _l1d_a25f62("f2f40ffbfaebf0230f0b0f0b10", 182, 25))
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
end if
end if
end sub
sub refreshLicenseState()
if KA_IsActivated() then
_l1II11l = KA_GetSavedLicense()
_l11I11l = U_PrefDefault(_l1d_a25f62("c6d3e0d9d0d4dbefddd3dff5", 59, 118), _l1d_a25f62("6f6c6571706a7974", 226, 216))
m.badgeText.text = _l1d_a25f62("9d9e969e9ab0", 186, 162)
m.statusTitle.text = _l1d_a25f62("3b1b282d294136f4583d5139594b130c", 168, 87) + _l1II11l
_lI1I11l = U_PrefDefault(_l1d_a25f62("b1aaa3accac5c1cdd7", 4, 66), "")
_llII11l = KA_FormatExpiry(_lI1I11l)
_lIII11l = U_PrefDefault(_l1d_a25f62("b9c2b3dadfcf", 136, 214), _l1d_a25f62("3f6367655c6661", 24, 227))
m.statusDetail.text = _l1d_a25f62("c0e9f7e9fcf0fcf8ff050a0e3d5a", 219, 56) + _lIII11l + _l1d_a25f62("2528df2e31d1efea06ee00f53f4c", 214, 47) + _llII11l + chr(10) + _l1d_a25f62("542834378636383d4d544b52505aa466676a6b6063b9736cc2707a7f7f8e899296dd9195e695a4a69ff5b4b6a8b8c1c2fc", 255, 155)
if m.activatedActions <> invalid then m.activatedActions.visible = true
if m.btnActivate <> invalid then m.btnActivate.text = _l1d_a25f62("bb59caa25dd7abb9a5b3bb77d6b4bdc6c0d6cf8ffd", 43, 75)
else
m.badgeText.text = _l1d_a25f62("515255564b4e", 158, 114)
m.statusTitle.text = _l1d_a25f62("362b25332a2f3a002f39095a504b47744e4a805d5353", 62, 205)
m.statusDetail.text = _l1d_a25f62("735f685c742581727b83347b83807d8999864c9a8fae58a7a561a5aaadaac3c676d2c3ccd485ccd4d0e3d5e9f39de1e9e2a9fffb04f2f900be0a0ac7081a1417d64138e5", 164, 146)
if m.activatedActions <> invalid then m.activatedActions.visible = false
if m.btnActivate <> invalid then m.btnActivate.text = _l1d_a25f62("404a3e17182459432d6239356b60303b455e4a54644d5d638f8d", 97, 6)
end if
end sub
sub onActivateClicked()
if ((53361 - 5929 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lIl1lIl = m.keyboard.text
if _lIl1lIl = invalid then _lIl1lIl = ""
_ll11lIl = CreateObject(_l1d_a25f62("aac290bec3c4c2", 212, 4), _l1d_a25f62("c8c9a964b2d5b57066", 37, 77), _l1d_a25f62("79", 53, 39))
if _ll11lIl <> invalid then _lIl1lIl = _ll11lIl.replaceAll(_lIl1lIl, "")
if _lIl1lIl = "" then
if KA_IsActivated() then
_lIl1lIl = KA_GetSavedLicense()
else
m.statusDetail.text = _l1d_a25f62("27eef8ff1001c907011e1026db25122f35ea212730312b493a023a43520e42461766555b235b64736d637486773e7f7f817b9b8b53a39095919997a16ba5a366", 175, 40)
m.keyboard.setFocus(true)
return
end if
end if
m.spinnerLabel.visible = true
m.spinnerLabel.text = _l1d_a25f62("49463b474f4d47115b591a496123746873718e766498856d7b494c4f", 183, 101)
m.statusDetail.text = _l1d_a25f62("643b3d404e5343534f5b23525c2c7d736e6a97716da3807676507f8959869c909ea2946e9aa7a4a87db4bcc5c6bebecf878a8d", 62, 231)
if m.authTask <> invalid then m.authTask.control = _l1d_a25f62("b4bab6bc", 97, 130)
m.authTask = CreateObject(_l1d_a25f62("29374e6561434d4f", 185, 94), _l1d_a25f62("5c31305b2a2e4d544a3f5a", 53, 222))
m.authTask.action = _l1d_a25f62("504e47505a6059", 131, 97)
m.authTask.licenseKey = _lIl1lIl
m.authTask.observeField(_l1d_a25f62("271b2c312d38", 65, 244), _l1d_a25f62("cdcff5eceed512e8f9fee803", 168, 6))
m.authTask.control = _l1d_a25f62("070b09", 1, 180)
end sub
sub onAuthResult()
m.spinnerLabel.visible = false
_l1llIIl = m.authTask.result
if _l1llIIl <> invalid and _l1llIIl.success = true then
m.badgeText.text = _l1d_a25f62("131406240a1e", 55, 157)
m.statusTitle.text = _l1d_a25f62("defcf5fe08ee07c7e90a041a0818102226e5f51e2b2e3724273f334f5240", 19, 127)
m.statusDetail.text = _l1d_a25f62("5c4d475950515c22515f2b80726d6d96746ca67f75755052a9919e9b9797a46a9bada5afb7b5bcbe85c9c1ca91c1cdced4e3dee3e5a2", 60, 241)
refreshLicenseState()
m.top.activationSuccess = true
else
_llllIIl = _l1d_a25f62("edcedecee2dceadad7d9aae7f1eceaf6f8b1c22400080d08d4200d2a2ee31a222b2c244435fb353e4df9", 46, 126)
if _l1llIIl <> invalid and _l1llIIl.message <> invalid and _l1llIIl.message <> "" then
_llllIIl = KA_CleanAuthMessage(_l1llIIl.message)
if _llllIIl = _l1d_a25f62("0f311c30383e36fd444a474452404d15615655", 21, 179) or _llllIIl = _l1d_a25f62("9bbbb8bdc9b1c604d2cfc610e1e5cd1ce5f1daf6ef", 208, 255) then
_llllIIl = _l1d_a25f62("4323202531192e6c3a372e78494d35844d59425e57a4996c6b67665b70ae677969838379c37f988181d2a09d94dea2b2abeaa1a2acf6bac3c0cbd316", 112, 7)
end if
end if
m.badgeText.text = _l1d_a25f62("4347334b444d", 178, 71)
m.statusTitle.text = _l1d_a25f62("4d2a2731ea563af360445048414a", 162, 92)
m.statusDetail.text = _llllIIl
end if
end sub
sub onContinueClicked()
m.top.activationSuccess = true
end sub
sub onDeactivateClicked()
if ((58152 - 9692 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
KA_ClearLicense()
m.keyboard.text = ""
refreshLicenseState()
m.statusDetail.text = _l1d_a25f62("27070409151d12d0171b1a1f332b3b293f3335f44648fd544b4f5c0c53576b615e632f248c7881758536928b94944594949196a2aa9f5daba8bf69c0be72b6bbcfc7d7c5dbcf8dd1dad7e2eaad", 160, 59)
m.keyboard.setFocus(true)
end sub
function onKeyEvent(_ll1Il11 as String, _l11Il11 as Boolean) as Boolean
if not _l11Il11 then return false
if not (m.keyboard.isInFocusChain() or (m.btnActivate <> invalid and m.btnActivate.hasFocus()) or (m.btnContinue <> invalid and m.btnContinue.hasFocus()) or (m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus())) then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
if _ll1Il11 = _l1d_a25f62("0a04ff09", 90, 204) then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
else if m.btnActivate <> invalid and m.btnActivate.hasFocus() then
if m.activatedActions <> invalid and m.activatedActions.visible then
m.btnContinue.setFocus(true)
return true
end if
end if
else if _ll1Il11 = _l1d_a25f62("e2e8", 198, 47) then
if m.btnActivate <> invalid and m.btnActivate.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
else if m.btnContinue <> invalid and m.btnContinue.hasFocus() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
else if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
end if
else if _ll1Il11 = _l1d_a25f62("2945424c3b", 115, 40) then
if m.btnContinue <> invalid and m.btnContinue.hasFocus() and m.btnDeactivate <> invalid and m.btnDeactivate.visible then
m.btnDeactivate.setFocus(true)
return true
end if
else if _ll1Il11 = _l1d_a25f62("becacadf", 174, 252) then
if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() and m.btnContinue <> invalid and m.btnContinue.visible then
m.btnContinue.setFocus(true)
return true
end if
else if _ll1Il11 = _l1d_a25f62("a0a0a5a0", 217, 229) then
if KA_IsActivated() then
m.top.closeView = true
return true
end if
end if
return false
end function
function _l1d_a25f62(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function