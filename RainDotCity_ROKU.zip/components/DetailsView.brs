sub init()
if ((87741 - 9749 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.backdrop = m.top.findNode(_l1d_6bae63("50545550626f5d77", 107, 71))
m.poster = m.top.findNode(_l1d_6bae63("89a58c96a896", 115, 134))
m.title = m.top.findNode(_l1d_6bae63("112717322c", 49, 204))
m.subMeta = m.top.findNode(_l1d_6bae63("2320384e392b43", 124, 20))
m.genres = m.top.findNode(_l1d_6bae63("2627251c3021", 185, 72))
m.description = m.top.findNode(_l1d_6bae63("fafcf508fc1400ff1d1e22", 85, 201))
m.playBtn = m.top.findNode(_l1d_6bae63("e6ddddf800f1ea", 166, 16))
m.favBtn = m.top.findNode(_l1d_6bae63("c4ccdab1e2db", 71, 163))
m.seriesSection = m.top.findNode(_l1d_6bae63("1e33233d3c2d1045463a525b5d", 80, 251))
m.seasonDropdownBtn = m.top.findNode(_l1d_6bae63("041d1c0d2c304d1a382239412c485f3851", 51, 196))
m.seasonInfoLabel = m.top.findNode(_l1d_6bae63("63747b6c83876f8d889278969898a4", 151, 127))
m.episodesGrid = m.top.findNode(_l1d_6bae63("9aaaa4b1b0aaacbd94c4bcbc", 1, 54))
m.seasonDropdownGroup = m.top.findNode(_l1d_6bae63("f90e0d022125fe0f2d132a36213d1727452e2e", 17, 151))
m.seasonList = m.top.findNode(_l1d_6bae63("917e859a9193749ca9a5", 132, 154))
m.loadingNotice = m.top.findNode(_l1d_6bae63("cccccdcddbd9d3ffe1efede6e7", 231, 65))
m.playBtn.observeField(_l1d_6bae63("3e4c4e514f51814e58545d695d5f", 164, 120), _l1d_6bae63("5d61526967824b757b747f787c", 135, 117))
m.favBtn.observeField(_l1d_6bae63("8795979a989aca97a19da6b2a6a8", 164, 193), _l1d_6bae63("aaaed9bdafe5bbc1cec9ced2", 61, 88))
m.seasonDropdownBtn.observeField(_l1d_6bae63("d4c4c8cbd3d7b5e6e2ecf1e3f5f9", 159, 215), _l1d_6bae63("262a30252419383c5526442a414d38546b405d73615f5c676468", 177, 72))
m.seasonList.observeField(_l1d_6bae63("3c5a4e494257515d5e726668", 200, 155), _l1d_6bae63("1b1dfd2e35262d2f143c35351b4c465257475b5d", 30, 170))
m.episodesGrid.observeField(_l1d_6bae63("89798b969b94a09a9791a3a7", 51, 47), _l1d_6bae63("42461e36503d544e502956625c65536569", 85, 8))
m.episodesGrid.observeField(_l1d_6bae63("d9e411f1", 99, 213), _l1d_6bae63("c8cab4c2cecbdae2e6d7cedce6f4daf5ceec", 24, 81))
m.allSeasons = []
m.selectedSeasonIndex = 0
m.top.observeField(_l1d_6bae63("8f9998a9ae9fa3", 39, 78), _l1d_6bae63("d4d803ddecf90215eff9f3fdfe", 173, 18))
end sub
sub onEpisodesGridGoUp()
m.seasonDropdownBtn.setFocus(true)
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.playBtn <> invalid then m.playBtn.setFocus(true)
end if
end sub
sub onContentChange()
_lIl1lIl = m.top.content
if _lIl1lIl = invalid then return
m.backdrop.uri = _lIl1lIl.HDBackgroundImageUrl
m.poster.uri = _lIl1lIl.HDPosterUrl
m.title.text = _lIl1lIl.Title
_l1I1lIl = _l1d_6bae63("363b573b4a", 169, 114)
if _lIl1lIl.kind <> invalid and (_lIl1lIl.kind = _l1d_6bae63("6061", 234, 194) or _lIl1lIl.kind = _l1d_6bae63("f70cfc061506", 216, 76)) then
_l1I1lIl = _l1d_6bae63("3035", 28, 200)
else if _lIl1lIl.ContentType = 2 then
_l1I1lIl = _l1d_6bae63("4c51", 165, 123)
end if
_l1lIlIl = _lIl1lIl.Title
if _l1lIlIl = invalid or _l1lIlIl = "" then _l1lIlIl = _lIl1lIl.title
_lllIlIl = _lIl1lIl.HDPosterUrl
if (_lllIlIl = invalid or _lllIlIl = "") and Left(_lIl1lIl.id, 2) = _l1d_6bae63("5a5d", 128, 102) then
_lllIlIl = _l1d_6bae63("9685888789d3ebeeafb6adb2b7a402c8c3b5c5cfbfcb1ac2c6dadbe42dd5f3dae2f6e242e90a010f1254", 210, 220) + _lIl1lIl.id + _l1d_6bae63("ba777e8b", 72, 83)
end if
W_RememberContext(_lIl1lIl.id, {
title:  _l1lIlIl,
poster: _lllIlIl,
kind:   _l1I1lIl,
imdb:   _lIl1lIl.id,
year:   _lIl1lIl.ReleaseDate,
rating: _lIl1lIl.Rating
})
_lII1lIl = ""
if _lIl1lIl.Rating <> invalid and _lIl1lIl.Rating <> "" then _lII1lIl = _l1d_6bae63("2932", 60, 19) + _lIl1lIl.Rating + _l1d_6bae63("4447ee4d50", 255, 101)
if _lIl1lIl.ReleaseDate <> invalid and _lIl1lIl.ReleaseDate <> "" then _lII1lIl = _lII1lIl + _lIl1lIl.ReleaseDate + _l1d_6bae63("a0a3daa9ac", 182, 10)
_llI1lIl = _l1d_6bae63("bdc2dccad1", 140, 252)
_lI11lIl = false
if _lIl1lIl.kind <> invalid and (_lIl1lIl.kind = _l1d_6bae63("9c9d", 27, 45) or _lIl1lIl.kind = _l1d_6bae63("35423a544b44", 212, 142)) then
_llI1lIl = _l1d_6bae63("20253226202833", 97, 235)
_lI11lIl = true
else if _lIl1lIl.ContentType = 2 then
_llI1lIl = _l1d_6bae63("9ba015a9c3c3ae", 85, 154)
_lI11lIl = true
end if
_lII1lIl = _lII1lIl + _llI1lIl
m.subMeta.text = _lII1lIl
_ll11lIl = ""
if _lIl1lIl.Categories <> invalid and _lIl1lIl.Categories.Count() > 0 then
for _l111lIl = 0 to _lIl1lIl.Categories.Count() - 1
if _l111lIl > 0 then _ll11lIl = _ll11lIl + _l1d_6bae63("261d", 162, 152)
_ll11lIl = _ll11lIl + _lIl1lIl.Categories[_l111lIl].ToStr()
end for
end if
m.genres.text = _ll11lIl
m.description.text = _lIl1lIl.Description
updateFavButton()
if _lI11lIl then
m.seriesSection.visible = true
m.loadingNotice.visible = true
m.seasonDropdownGroup.visible = false
m.allSeasons = []
m.detailsTask = CreateObject(_l1d_6bae63("d5e5fc130df1f9fd", 184, 11), _l1d_6bae63("e9cdbfd7e2e0ceeee6d7f2", 118, 183))
m.detailsTask.imdbId = _lIl1lIl.id
m.detailsTask.observeField(_l1d_6bae63("e9fdeef30ffa", 17, 134), _l1d_6bae63("f8fcd9fb0ffd081014f6160f17191d", 67, 204))
m.detailsTask.control = _l1d_6bae63("909492", 33, 29)
else
m.seriesSection.visible = false
m.loadingNotice.visible = false
m.seasonDropdownGroup.visible = false
end if
m.playBtn.setFocus(true)
end sub
sub updateFavButton()
if ((7731 - 2577 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llllIIl = m.top.content
if _llllIIl = invalid then return
if WL_IsFavorite(_llllIIl.id) then
m.favBtn.text = _l1d_6bae63("0e233f101e57455b57565e575733", 158, 73)
else
m.favBtn.text = _l1d_6bae63("88928257675f59585e7b79", 237, 194)
end if
end sub
sub onFavClicked()
_l1I1ll1 = m.top.content
if _l1I1ll1 = invalid then return
_lllIll1 = _l1d_6bae63("a8adb9b5ac", 229, 32)
if _l1I1ll1.kind <> invalid and (_l1I1ll1.kind = _l1d_6bae63("a5a6", 2, 47) or _l1I1ll1.kind = _l1d_6bae63("e2d7e9e1e0f1", 193, 48)) then
_lllIll1 = _l1d_6bae63("2227", 56, 214)
else if _l1I1ll1.ContentType = 2 then
_lllIll1 = _l1d_6bae63("6d6e", 142, 115)
end if
_lII1ll1 = {
id: _l1I1ll1.id,
title: _l1I1ll1.Title,
kind: _lllIll1,
year: _l1I1ll1.ReleaseDate,
poster: _l1I1ll1.HDPosterUrl,
rating: _l1I1ll1.Rating
}
WL_ToggleFavorite(_lII1ll1)
updateFavButton()
end sub
sub onDetailsLoaded()
if ((18027 - 6009 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.loadingNotice.visible = false
_lI1lIl1 = m.detailsTask.result
if _lI1lIl1 <> invalid and _lI1lIl1.seasons <> invalid and _lI1lIl1.seasons.Count() > 0 then
m.allSeasons = _lI1lIl1.seasons
populateSeasonDropdown()
selectSeason(0)
end if
end sub
sub populateSeasonDropdown()
if ((7269 - 2423 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lI1Il11 = CreateObject(_l1d_6bae63("7c8463726c90989c", 28, 14), _l1d_6bae63("a180827b8f8b84b1959da1", 56, 38))
for _ll1Il11 = 0 to m.allSeasons.Count() - 1
_l1IIl11 = m.allSeasons[_ll1Il11]
_llIIl11 = _lI1Il11.createChild(_l1d_6bae63("ac9b9da69aa6afccb0a8ac", 96, 137))
_l11Il11 = _l1d_6bae63("352e2d1e3d417a", 243, 149) + _l1IIl11.number.ToStr()
if _l1IIl11.label <> invalid and _l1IIl11.label <> "" then _l11Il11 = _l1IIl11.label
_llIIl11.title = _l11Il11
end for
m.seasonList.content = _lI1Il11
end sub
sub onSeasonDropdownBtnClicked()
if m.seasonDropdownGroup.visible then
closeSeasonDropdown()
else
openSeasonDropdown()
end if
end sub
sub openSeasonDropdown()
if m.allSeasons.Count() = 0 then return
m.seasonDropdownGroup.visible = true
m.seasonList.jumpToItem = m.selectedSeasonIndex
m.seasonList.setFocus(true)
end sub
sub closeSeasonDropdown()
m.seasonDropdownGroup.visible = false
m.seasonDropdownBtn.setFocus(true)
end sub
sub onSeasonListSelected()
_l11l1lI = m.seasonList.itemSelected
if _l11l1lI >= 0 and _l11l1lI < m.allSeasons.Count() then
selectSeason(_l11l1lI)
end if
closeSeasonDropdown()
end sub
sub selectSeason(_lIIIIlI as Integer)
if _lIIIIlI < 0 or _lIIIIlI >= m.allSeasons.Count() then return
m.selectedSeasonIndex = _lIIIIlI
_l1IIIlI = m.allSeasons[_lIIIIlI]
_lllll1I = _l1d_6bae63("fff8f7e8f7fb44", 251, 87) + _l1IIIlI.number.ToStr()
if _l1IIIlI.label <> invalid and _l1IIIlI.label <> "" then _lllll1I = _l1IIIlI.label
m.seasonDropdownBtn.text = _lllll1I + _l1d_6bae63("bcbfa78fab", 239, 237)
_ll1IIlI = 0
if _l1IIIlI.episodes <> invalid then _ll1IIlI = _l1IIIlI.episodes.Count()
m.seasonInfoLabel.text = _l1d_6bae63("4e", 47, 71) + _ll1IIlI.ToStr() + _l1d_6bae63("bb21f10bf413111300dd", 51, 168)
_llIIIlI = CreateObject(_l1d_6bae63("b1a7d6c5d1b3adaf", 37, 90), _l1d_6bae63("ac8385a2968eabb498a4a8", 46, 63))
if _l1IIIlI.episodes <> invalid then
for each _lIlIIlI in _l1IIIlI.episodes
_l11IIlI = _llIIIlI.createChild(_l1d_6bae63("81989cb9aba5c28badbbbd", 79, 117))
_lI1IIlI = ""
if _lIlIIlI.episode <> invalid then
_lI1IIlI = _lIlIIlI.episode.ToStr()
end if
_l11IIlI.id = _lI1IIlI
_l11IIlI.Title = _lIlIIlI.title
_l11IIlI.ShortDescriptionLine1 = _l1d_6bae63("05351f3c2b3537f7", 137, 57) + _lI1IIlI
_l11IIlI.HDPosterUrl = _lIlIIlI.thumbnail
if _l11IIlI.HDPosterUrl = "" then _l11IIlI.HDPosterUrl = m.top.content.HDPosterUrl
_l11IIlI.Description = _lIlIIlI.description
end for
end if
m.episodesGrid.content = _llIIIlI
end sub
sub onPlayClicked()
if ((54896 - 6862 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lll111I = m.top.content
if _lll111I = invalid then return
_lIl111I = _l1d_6bae63("30314b3544", 42, 233)
if _lll111I.kind <> invalid and (_lll111I.kind = _l1d_6bae63("aeaf", 42, 80) or _lll111I.kind = _l1d_6bae63("4f485452515e", 162, 126)) then
_lIl111I = _l1d_6bae63("0203", 251, 115)
else if _lll111I.ContentType = 2 then
_lIl111I = _l1d_6bae63("494a", 39, 246)
end if
_l11111I = 1
_l1l111I = 1
if _lIl111I = _l1d_6bae63("3b40", 240, 183) and m.allSeasons.Count() > 0 then
_ll1111I = m.allSeasons[m.selectedSeasonIndex]
if _ll1111I <> invalid then
_l11111I = _ll1111I.number
if _ll1111I.episodes <> invalid and _ll1111I.episodes.Count() > 0 then
_l1l111I = _ll1111I.episodes[0].episode
end if
end if
end if
m.top.playAction = {
imdbId: _lll111I.id,
title: _lll111I.Title,
kind: _lIl111I,
season: _l11111I,
episode: _l1l111I,
poster: _lll111I.HDPosterUrl
}
end sub
sub onEpisodeSelected()
_l1III1I = m.top.content
if _l1III1I = invalid or m.allSeasons.Count() = 0 then return
_l1lllII = m.allSeasons[m.selectedSeasonIndex]
_lllllII = m.episodesGrid.itemSelected
if _lllllII >= 0 and _lllllII < _l1lllII.episodes.Count() then
_lIIII1I = _l1lllII.episodes[_lllllII]
m.top.playAction = {
imdbId: _l1III1I.id,
title: _l1III1I.Title + _l1d_6bae63("67776d63", 96, 39) + _l1lllII.number.ToStr() + _l1d_6bae63("3bd9", 207, 76) + _lIIII1I.episode.ToStr() + _l1d_6bae63("3530", 202, 75) + _lIIII1I.title + _l1d_6bae63("d1", 224, 8),
kind: _l1d_6bae63("464b", 212, 166),
season: _l1lllII.number,
episode: _lIIII1I.episode,
poster: _l1III1I.HDPosterUrl
}
end if
end sub
function onKeyEvent(_llI11II as String, _l1I11II as Boolean) as Boolean
if not _l1I11II then return false
_lI111II = LCase(_llI11II)
if _lI111II = _l1d_6bae63("99838aa0a5a98f", 147, 157) or _lI111II = _l1d_6bae63("5d", 218, 109) then
onFavClicked()
_lII11II = m.top.getScene()
if _lII11II <> invalid and _lII11II.hasField(_l1d_6bae63("827e848f738d86979f", 66, 81)) then
if m.favBtn.text = _l1d_6bae63("4d42662f65768c7a767d7d969e7a", 10, 252) then
_lII11II.showToast = _l1d_6bae63("ab898c9092d9a8a6e2d4a9b7b1b9b8c0cdc901", 228, 6)
else
_lII11II.showToast = _l1d_6bae63("1f4f4a4b475b5fa6635a6065b5417a6a7e7c7b817a7c", 223, 146)
end if
end if
return true
end if
if m.seasonDropdownGroup.visible then
if _lI111II = _l1d_6bae63("18181d18", 217, 93) or _lI111II = _l1d_6bae63("c9c3c5da", 135, 222) or _lI111II = _l1d_6bae63("ac989d9fb6", 79, 111) then
closeSeasonDropdown()
return true
end if
return false
end if
if _lI111II = _l1d_6bae63("837f7f94", 102, 121) then
if m.favBtn.hasFocus() then
m.playBtn.setFocus(true)
return true
else if m.seasonDropdownBtn.hasFocus() then
if m.selectedSeasonIndex > 0 then
selectSeason(m.selectedSeasonIndex - 1)
end if
return true
end if
else if _lI111II = _l1d_6bae63("ae9aa7a1c0", 43, 85) then
if m.playBtn.hasFocus() then
m.favBtn.setFocus(true)
return true
else if m.seasonDropdownBtn.hasFocus() then
if m.selectedSeasonIndex < m.allSeasons.Count() - 1 then
selectSeason(m.selectedSeasonIndex + 1)
end if
return true
end if
else if _lI111II = _l1d_6bae63("808a758f", 178, 170) then
if m.playBtn.hasFocus() or m.favBtn.hasFocus() then
if m.seriesSection.visible then
m.seasonDropdownBtn.setFocus(true)
return true
end if
else if m.seasonDropdownBtn.hasFocus() then
if m.episodesGrid.content <> invalid and m.episodesGrid.content.getChildCount() > 0 then
m.episodesGrid.setFocus(true)
return true
end if
end if
else if _lI111II = _l1d_6bae63("4951", 173, 113) then
if m.seasonDropdownBtn.hasFocus() then
m.playBtn.setFocus(true)
return true
end if
end if
return false
end function
function _l1d_6bae63(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function