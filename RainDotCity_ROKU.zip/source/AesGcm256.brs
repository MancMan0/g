function AGD_Decrypt(_l11I1ll as String, _lIlI1ll as Object, _lII11ll as Object, _lI1I1ll as Object) as Object
if _l11I1ll = invalid or Len(_l11I1ll) <> 64 then return invalid
if _lIlI1ll = invalid or _lIlI1ll.Count() <> 12 then return invalid
if _lII11ll = invalid then return invalid
_ll1I1ll = CreateObject(_l1d_f3d86d("816757838b7d6496998d98", 15, 4))
for _l1lI1ll = 0 to 11
_ll1I1ll.Push(_lIlI1ll[_l1lI1ll])
end for
_ll1I1ll.Push(0)
_ll1I1ll.Push(0)
_ll1I1ll.Push(0)
_ll1I1ll.Push(1)
_lllI1ll = CreateObject(_l1d_f3d86d("5e5e347270644373766c87", 2, 238))
for _l1lI1ll = 0 to 15
_lllI1ll.Push(_ll1I1ll[_l1lI1ll])
end for
AGD_IncrCounter(_lllI1ll)
return AGD_AesCtrCrypt(_l11I1ll, _lllI1ll, _lII11ll)
end function
function AGD_AesCtrCrypt(_l1l1l1l as String, _l1Ill1l as Object, _lIIll1l as Object) as Object
_lI11l1l = CreateObject(_l1d_f3d86d("55452b59675b3a6a6d636e", 202, 157))
_ll11l1l = _lIIll1l.Count()
_l111l1l = 0
while _l111l1l < _ll11l1l
_lIl1l1l = AGD_AesEcbBlock(_l1l1l1l, _l1Ill1l)
if _lIl1l1l = invalid or _lIl1l1l.Count() < 16 then return invalid
_llIll1l = 16
if _l111l1l + _llIll1l > _ll11l1l then _llIll1l = _ll11l1l - _l111l1l
for _lll1l1l = 0 to _llIll1l - 1
_lI11l1l.Push(B_Xor(_lIIll1l[_l111l1l + _lll1l1l], _lIl1l1l[_lll1l1l]))
end for
_l111l1l = _l111l1l + 16
AGD_IncrCounter(_l1Ill1l)
end while
return _lI11l1l
end function
sub AGD_IncrCounter(_l11I11l as Object)
if _l11I11l = invalid or _l11I11l.Count() < 16 then return
for _lI1I11l = 15 to 12 step -1
_l11I11l[_lI1I11l] = (_l11I11l[_lI1I11l] + 1) AND 255
if _l11I11l[_lI1I11l] <> 0 then return
end for
end sub
function AGD_AesEcbBlock(_lI11lIl as String, _lIl1lIl as Object) as Object
_ll11lIl = CreateObject(_l1d_f3d86d("25351e120f253e38435343", 88, 251))
_lllIlIl = _ll11lIl.Setup(true, _l1d_f3d86d("202738657d8387713c3d3f", 104, 23), _lI11lIl, "", 0)
if _lllIlIl <> 0 then return invalid
_llI1lIl = CreateObject(_l1d_f3d86d("d5bdabd5dbcfb6eaeddfea", 140, 215))
_l1I1lIl = _ll11lIl.Process(_lIl1lIl)
if _l1I1lIl <> invalid then
for _l111lIl = 0 to _l1I1lIl.Count() - 1
_llI1lIl.Push(_l1I1lIl[_l111lIl])
end for
end if
_lII1lIl = _ll11lIl.Final()
if _lII1lIl <> invalid then
for _l111lIl = 0 to _lII1lIl.Count() - 1
_llI1lIl.Push(_lII1lIl[_l111lIl])
end for
end if
return _llI1lIl
end function
function _l1d_f3d86d(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function