function S_SyncSections() as Object
return [ _l1d_d37629("ecded9e10ae8e012ebe9e10a0ef3030efc120306", 120, 194), _l1d_d37629("dfafaaacd5b1cbe3bcd4d2f3efd3e5cfefd7efe1fa", 45, 96), _l1d_d37629("441823213e263448353d4b685d444e514757795b516165", 103, 15) ]
end function
function S_HydraSyncKeys() as Object
return [ _l1d_d37629("b6afaebeb2aed1b5ced6c0d6d4", 234, 29) ]
end function
function S_BuildSnapshot() as Object
_llllI1l = {}
for each _lIllI1l in S_SyncSections()
_l1llI1l = CreateObject(_l1d_d37629("b9af9fabb0bdcac8d1d9b6c3ccdad8d9dd", 5, 66), _lIllI1l)
_lIII11l = _l1llI1l.GetKeyList()
if _lIII11l <> invalid then
_l11I11l = {}
for each _l1II11l in _lIII11l
_l11I11l[_l1II11l] = _l1llI1l.Read(_l1II11l)
end for
_llllI1l[_lIllI1l] = _l11I11l
end if
end for
_lI1I11l = CreateObject(_l1d_d37629("f715dd15161f08120f1bf42d2a243a3f43", 19, 150), _l1d_d37629("1ef4fffb18020e24111727", 166, 42))
_llII11l = {}
for each _l1II11l in S_HydraSyncKeys()
if _lI1I11l.Exists(_l1II11l) then _llII11l[_l1II11l] = _lI1I11l.Read(_l1II11l)
end for
if _llII11l.Count() > 0 then _llllI1l[_l1d_d37629("cc020d09e610fcf21f0515", 214, 72)] = _llII11l
return _llllI1l
end function
sub S_ApplySnapshot(_llI1lIl as Object)
if _llI1lIl = invalid then return
for each _lI11lIl in _llI1lIl
_lIl1lIl = _llI1lIl[_lI11lIl]
if _lIl1lIl <> invalid then
_l111lIl = CreateObject(_l1d_d37629("001e261e1f28111b18243d36332d43484c", 115, 255), _lI11lIl)
for each _ll11lIl in _lIl1lIl
if not _l111lIl.Exists(_ll11lIl) then
_l1I1lIl = _lIl1lIl[_ll11lIl]
if _l1I1lIl <> invalid then _l111lIl.Write(_ll11lIl, _l1I1lIl.ToStr())
end if
end for
_l111lIl.Flush()
end if
end for
end sub
function S_ResolverUrl() as String
if ((29205 - 5841 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_llllIIl = U_DefaultResolverUrl()
if _llllIIl = "" then _llllIIl = U_PrefDefault(_l1d_d37629("87778c737992869c7ca28b", 143, 138), "")
return _llllIIl
end function
function S_PullOnBoot() as Boolean
_l1lIll1 = S_ResolverUrl()
if _l1lIll1 = "" then return false
_ll1Ill1 = CreateObject(_l1d_d37629("c4aaa99894b6c0c2", 205, 5), _l1d_d37629("59364452645a4b56", 191, 109))
if _ll1Ill1 = invalid then return false
_ll1Ill1.mode = _l1d_d37629("2d2d474a", 22, 199)
_ll1Ill1.resolverUrl = _l1lIll1
_ll1Ill1.did = U_ClientId()
_lII1ll1 = CreateObject(_l1d_d37629("48365b4653564b505585516972", 107, 47))
_ll1Ill1.observeField(_l1d_d37629("6f7d76737d78", 60, 33), _lII1ll1)
_ll1Ill1.control = _l1d_d37629("3c3e36", 198, 168)
_l1I1ll1 = wait(5000, _lII1ll1)
if _l1I1ll1 = invalid then
_ll1Ill1.control = _l1d_d37629("737b957d", 178, 146)
return false
end if
_lllIll1 = _ll1Ill1.result
if _lllIll1 = invalid or _lllIll1.ok <> true then return false
_lIlIll1 = _lllIll1.snapshot
if _lIlIll1 = invalid then return false
S_ApplySnapshot(_lIlIll1)
return true
end function
sub S_QueuePush()
if ((11556 - 3852 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.global = invalid then return
m.global.addField(_l1d_d37629("2b3844446c4c3d3d64444965", 118, 38), _l1d_d37629("8286a3", 10, 31), false)
m.global.addField(_l1d_d37629("bfb8cad8a6dcd1dc", 29, 81), _l1d_d37629("4d4f595b", 217, 150), false)
_llIlIl1 = CreateObject(_l1d_d37629("dbfbd3f3e9fdcf070e09", 208, 57)).AsSeconds()
_lI1lIl1 = m.global.syncLastPush
if _lI1lIl1 > 0 and (_llIlIl1 - _lI1lIl1) < 5 then return
S_FirePush(_llIlIl1)
end sub
sub S_QueuePushNow()
if ((17409 - 5803 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.global = invalid then return
m.global.addField(_l1d_d37629("9e97b1b7d5bbb0b6d5bbbcc6", 57, 84), _l1d_d37629("030926", 171, 65), false)
m.global.addField(_l1d_d37629("241d373d13413641", 25, 186), _l1d_d37629("0204fe00", 145, 3), false)
S_FirePush(CreateObject(_l1d_d37629("f1f1cded03f7e9010803", 66, 193)).AsSeconds())
end sub
sub S_FirePush(_l1l1I11 as Integer)
_lIl1I11 = S_ResolverUrl()
if _lIl1I11 = "" then return
_ll11I11 = CreateObject(_l1d_d37629("c0a8a79690b4bcc0", 140, 194), _l1d_d37629("c9b6c2c2d2cabbd6", 246, 36))
if _ll11I11 = invalid then return
_ll11I11.mode = _l1d_d37629("5a62637b", 48, 26)
_ll11I11.resolverUrl = _lIl1I11
_ll11I11.did = U_ClientId()
_ll11I11.payload = FormatJson(S_BuildSnapshot())
m.global.syncTask = _ll11I11
m.global.syncLastPush = _l1l1I11
_ll11I11.control = _l1d_d37629("b9b7c3", 188, 203)
end sub
function _l1d_d37629(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function