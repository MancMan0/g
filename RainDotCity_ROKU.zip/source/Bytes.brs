function B_Xor(_lII11ll as Integer, _lllI1ll as Integer) as Integer
return _lII11ll + _lllI1ll - 2 * (_lII11ll AND _lllI1ll)
end function
function B_XorBytes(_llIll1l as Object, _l1Ill1l as Object) as Object
_l1l1l1l = CreateObject(_l1d_aad7fd("afcda5bdbdcfaec4c7d7d2", 81, 140))
if _llIll1l = invalid or _l1Ill1l = invalid then return _l1l1l1l
_lll1l1l = _llIll1l.Count()
if _l1Ill1l.Count() < _lll1l1l then _lll1l1l = _l1Ill1l.Count()
for _lIIll1l = 0 to _lll1l1l - 1
_l1l1l1l.Push(B_Xor(_llIll1l[_lIIll1l], _l1Ill1l[_lIIll1l]))
end for
return _l1l1l1l
end function
function B_StrToLong(_l1II11l as String) as LongInteger
_llII11l# = 0&
if _l1II11l = invalid or _l1II11l = "" then return _llII11l#
for _lI1I11l = 1 to Len(_l1II11l)
_l11I11l = Asc(Mid(_l1II11l, _lI1I11l, 1))
if _l11I11l >= 48 and _l11I11l <= 57 then
_llII11l# = _llII11l# * 10& + (_l11I11l - 48)
end if
end for
return _llII11l#
end function
function B_ByteToHex(_lIl1lIl as Integer) as String
_ll11lIl = StrI(_lIl1lIl AND 255, 16)
_ll11lIl = U_Trim(_ll11lIl)
if Len(_ll11lIl) = 1 then _ll11lIl = _l1d_aad7fd("bd", 174, 31) + _ll11lIl
return LCase(_ll11lIl)
end function
function B_Slice(_llllIIl as Object, _lI1lIIl as Integer, _l1llIIl as Integer) as Object
_l11lIIl = CreateObject(_l1d_aad7fd("b5cdebc9bfd3facacde3de", 118, 177))
if _llllIIl = invalid then return _l11lIIl
_ll1lIIl = _llllIIl.Count()
if _lI1lIIl < 0 then _lI1lIIl = 0
if _l1llIIl > _ll1lIIl then _l1llIIl = _ll1lIIl
if _lI1lIIl >= _l1llIIl then return _l11lIIl
for _lIllIIl = _lI1lIIl to _l1llIIl - 1
_l11lIIl.Push(_llllIIl[_lIllIIl])
end for
return _l11lIIl
end function
function _l1d_aad7fd(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function