function RP_ResolveGeneric(_lII11ll as String, _lIII1ll as String, _llllIll as Object) as Object
_lIlI1ll = {}
if _lIII1ll <> "" then _lIlI1ll[_l1d_55a757("232f35354f3b55", 197, 140)] = _lIII1ll
_l1II1ll = HC_Get(_llllIll, _lII11ll, _lIlI1ll, 8000)
if _l1II1ll = invalid or _l1II1ll.body = "" then return invalid
_l11I1ll = _l1II1ll.body
_lllI1ll = _l1II1ll.finalUrl
if _lllI1ll = invalid or _lllI1ll = "" then _lllI1ll = _lII11ll
_ll1I1ll = CreateObject(_l1d_55a757("2b31513d424333", 125, 28), _l1d_55a757("c18493969597e6e4dcdf8e94", 194, 215) + chr(34) + _l1d_55a757("4af2f5f822600253075c1e773c72181e", 200, 91) + chr(34) + _l1d_55a757("960e1114eebc1eaeb0", 32, 143), _l1d_55a757("19", 57, 201))
_l1lI1ll = _ll1I1ll.match(_l11I1ll)
if _l1lI1ll <> invalid and _l1lI1ll.Count() >= 2 then
return {
url: _l1lI1ll[1]
streamFormat: _l1d_55a757("e7ee08", 136, 7)
qualities: []
subtitles: RP_ExtractSubs(_l11I1ll)
chapters: []
referer: _lIII1ll
userAgent: ""
}
end if
_llII1ll = CreateObject(_l1d_55a757("0f2f352b303127", 112, 13), _l1d_55a757("498c93969d9d646c5a5dd4d4", 39, 58) + chr(34) + _l1d_55a757("fb5356593b01631c681d5f4d0c7e7c", 52, 232) + chr(34) + _l1d_55a757("fc2a2d30541438060a", 11, 208), _l1d_55a757("c3", 146, 200))
_lI1I1ll = _llII1ll.match(_l11I1ll)
if _lI1I1ll <> invalid and _lI1I1ll.Count() >= 2 then
return {
url: _lI1I1ll[1]
streamFormat: _l1d_55a757("f90948", 229, 113)
qualities: []
subtitles: RP_ExtractSubs(_l11I1ll)
chapters: []
referer: _lIII1ll
userAgent: ""
}
end if
return invalid
end function
function RP_ExtractSubs(_llIll1l as String) as Object
if ((78592 - 9824 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_ll11l1l = []
if _llIll1l = invalid or _llIll1l = "" then return _ll11l1l
_l111l1l = CreateObject(_l1d_55a757("52683864696a6a", 149, 107), _l1d_55a757("3b7e75787f7f363e4c4f6666", 31, 4) + chr(34) + _l1d_55a757("24202326fc4a303d3546475d5b1a1f222d23252e6669", 98, 223), _l1d_55a757("f4fd", 156, 255))
_l1l1l1l = _l111l1l.matchAll(_llIll1l)
if _l1l1l1l = invalid then return _ll11l1l
for each _lIl1l1l in _l1l1l1l
if _lIl1l1l.Count() < 2 then continue for
_lI11l1l = _lIl1l1l[1]
_l1Ill1l = _l1d_55a757("ff07", 86, 204)
_lIIll1l = CreateObject(_l1d_55a757("5c744274757a78", 150, 120), _l1d_55a757("3bb245b649b94d86c5775b7cc884d368dfe375e679", 89, 57), _l1d_55a757("19", 86, 218))
_lll1l1l = _lIIll1l.match(_lI11l1l)
if _lll1l1l <> invalid and _lll1l1l.Count() >= 2 then _l1Ill1l = LCase(_lll1l1l[1])
_ll11l1l.Push({ url: _lI11l1l, language: _l1Ill1l, name: UCase(_l1Ill1l) })
end for
return _ll11l1l
end function
function RP_ResolveVidsrcCc(_l1II11l as String, _l1IlI1l as String, _lI11I1l as Object) as Object
_l11lI1l = CreateObject(_l1d_55a757("635949555a5b7b", 133, 108), _l1d_55a757("3c3e323281404e4f44a19ca2aaae6668aeafabb3c2aeb9ba828789e0db8fc9d4d7f2eda1a6aa9e9eb4b60d08bcc1c6c81f1aced3d6cb", 59, 40), _l1d_55a757("ef", 159, 249))
m = _l11lI1l.match(_l1II11l)
if m = invalid or m.Count() < 3 then return invalid
_llllI1l = m[1]
_lI1I11l = m[2]
_lIl1I1l = ""
_lIII11l = ""
if m.Count() >= 5 then
_lIl1I1l = m[3]
_lIII11l = m[4]
end if
_ll1lI1l = HC_OriginOf(_l1II11l)
if _ll1lI1l = "" then return invalid
if _llllI1l = _l1d_55a757("5d62", 25, 240) and _lIl1I1l <> "" and _lIII11l <> "" then
_l111I1l = _ll1lI1l + _l1d_55a757("18d9cde724e1d9f3dcf3f1f33c", 247, 64) + _lI1I11l + _l1d_55a757("ca", 194, 221) + _lIl1I1l + _l1d_55a757("ae", 124, 91) + _lIII11l + _l1d_55a757("e1301d3736264042", 165, 87)
else
_l111I1l = _ll1lI1l + _l1d_55a757("86475b55924f67616a615f61aa", 71, 30) + _lI1I11l + _l1d_55a757("500f201615291f21", 255, 128)
end if
_l11I11l = {
"Referer": _l1II11l
"Origin": _ll1lI1l
"Accept": _l1d_55a757("00f2f5141411120820292bef2d19383afbf2293d33321034534b565e1f16232b29", 144, 15)
"X-Requested-With": _l1d_55a757("95abafae7d807fa098878ea18e98", 179, 170)
}
_lIIlI1l = HC_Get(_lI11I1l, _l111I1l, _l11I11l, 8000)
if _lIIlI1l = invalid or _lIIlI1l.body = "" then return invalid
_lI1lI1l = ParseJSON(_lIIlI1l.body)
if _lI1lI1l = invalid or type(_lI1lI1l) <> _l1d_55a757("0afadf1417060d0611270f2f210034372934", 72, 208) then return invalid
_ll11I1l = invalid
if _lI1lI1l.data <> invalid then _ll11I1l = _lI1lI1l.data
if (_ll11I1l = invalid or type(_ll11I1l) <> _l1d_55a757("2644192f32423d", 81, 3)) and _lI1lI1l.servers <> invalid then _ll11I1l = _lI1lI1l.servers
if _ll11I1l = invalid or type(_ll11I1l) <> _l1d_55a757("4258394b4e625d", 23, 221) then return invalid
for each _lII1I1l in _ll11I1l
if type(_lII1I1l) <> _l1d_55a757("7787708184939a97a298a09cb291a1a4baa5", 154, 143) then continue for
_lllII1l = ""
if _lII1I1l.hash <> invalid then _lllII1l = _lII1I1l.hash
if _lllII1l = "" and _lII1I1l.data_id <> invalid then _lllII1l = _lII1I1l.data_id
if _lllII1l = "" and _lII1I1l.id <> invalid then _lllII1l = _lII1I1l.id
if _lllII1l = "" then continue for
_llI1I1l = _ll1lI1l + _l1d_55a757("97e8dce6a3e2e9e6ecfeffb8", 191, 7) + _lllII1l
_l1I1I1l = HC_Get(_lI11I1l, _llI1I1l, _l11I11l, 8000)
if _l1I1I1l = invalid or _l1I1I1l.body = "" then continue for
_l1l1I1l = ParseJSON(_l1I1I1l.body)
if _l1l1I1l = invalid or type(_l1l1I1l) <> _l1d_55a757("6a729f74777e8d86917f8f8799c09497a994", 188, 156) then continue for
_llII11l = invalid
if _l1l1I1l.data <> invalid and type(_l1l1I1l.data) = _l1d_55a757("9db596a7aac1c0cdc8b6d6bad0b7c7cae0db", 214, 249) then
_llII11l = _l1l1I1l.data
else
_llII11l = _l1l1I1l
end if
_l1lII1l = ""
if _llII11l.stream <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.stream)
if _l1lII1l = "" and _llII11l.source <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.source)
if _l1lII1l = "" and _llII11l.file <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.file)
if _l1lII1l = "" and _llII11l.url <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.url)
if _l1lII1l = "" then continue for
_lIlII1l = []
_llIlI1l = invalid
if _llII11l.subtitles <> invalid then _llIlI1l = _llII11l.subtitles
if _llIlI1l = invalid and _llII11l.captions <> invalid then _llIlI1l = _llII11l.captions
if _llIlI1l <> invalid and type(_llIlI1l) = _l1d_55a757("89715e92958792", 140, 139) then
for each _lll1I1l in _llIlI1l
if type(_lll1I1l) <> _l1d_55a757("a29ab7acafa6a5aea9b7b7bfb1d8cccfc1dc", 36, 76) then continue for
_ll1II1l = ""
if _lll1I1l.file <> invalid then _ll1II1l = _lll1I1l.file
if _ll1II1l = "" and _lll1I1l.url <> invalid then _ll1II1l = _lll1I1l.url
if _ll1II1l = "" and _lll1I1l.src <> invalid then _ll1II1l = _lll1I1l.src
if _ll1II1l = "" then continue for
_l1llI1l = _l1d_55a757("d0da", 195, 42)
if _lll1I1l.language <> invalid then _l1llI1l = LCase(Left(_lll1I1l.language, 2))
if _l1llI1l = "" and _lll1I1l.lang <> invalid then _l1llI1l = LCase(Left(_lll1I1l.lang, 2))
if _l1llI1l = "" and _lll1I1l.label <> invalid then _l1llI1l = LCase(Left(_lll1I1l.label, 2))
_lIllI1l = ""
if _lll1I1l.label <> invalid then _lIllI1l = _lll1I1l.label
if _lIllI1l = "" and _lll1I1l.language <> invalid then _lIllI1l = _lll1I1l.language
if _lIllI1l = "" then _lIllI1l = _l1d_55a757("c8eddff4eafaf5ef00", 193, 54)
_lIlII1l.Push({ url: _ll1II1l, language: _l1llI1l, name: _lIllI1l })
end for
end if
return {
url: _l1lII1l
streamFormat: U_StreamFormat(_l1lII1l)
qualities: []
subtitles: _lIlII1l
chapters: []
referer: _l1II11l
userAgent: ""
}
end for
return invalid
end function
function RP_AsStreamString(_ll11lIl as Dynamic) as String
if _ll11lIl = invalid then return ""
if type(_ll11lIl) = _l1d_55a757("102e371f212b", 141, 50) or type(_ll11lIl) = _l1d_55a757("c2b0a7cdceb6c0ca", 9, 71) then return _ll11lIl
if type(_ll11lIl) = _l1d_55a757("3b437044475944", 60, 237) then
if _ll11lIl.Count() = 0 then return ""
_lIl1lIl = _ll11lIl[0]
if type(_lIl1lIl) = _l1d_55a757("c2e6e7010905", 80, 191) or type(_lIl1lIl) = _l1d_55a757("f8f0dfff0402fefa", 6, 132) then return _lIl1lIl
if type(_lIl1lIl) = _l1d_55a757("74748d7e818077847f958d998fae9ea197b2", 34, 36) then
if _lIl1lIl.file <> invalid then return _lIl1lIl.file
if _lIl1lIl.url <> invalid then return _lIl1lIl.url
end if
end if
return ""
end function
function RP_ResolveAirflix(_l11lIIl as String, _llI1IIl as String, _ll1IIIl as Object) as Object
_l111IIl = CreateObject(_l1d_55a757("aeccd4cccdd2ca", 179, 237), _l1d_55a757("0c49544852541e1e6667516b6a645f603a3f3f6e715c874d856893595e6056546c6c83ae74797e7e95c0868b8e83", 18, 207), _l1d_55a757("12", 241, 122))
m = _l111IIl.match(_l11lIIl)
if m = invalid or m.Count() < 3 then return invalid
_lIl1IIl = m[1]
_l1l1IIl = m[2]
_l1lIIIl = ""
_llIlIIl = ""
if m.Count() >= 5 then
_l1lIIIl = m[3]
_llIlIIl = m[4]
end if
_l1IlIIl = _l1d_55a757("e7d3ddde", 72, 171)
if Left(_l1l1IIl, 2) = _l1d_55a757("a6a9", 84, 134) then _l1IlIIl = _l1d_55a757("ccd3dfdc", 139, 234)
_lIllIIl = _l1d_55a757("555c5f66683222257474796b7279737b898145908a9c9393ae95a960afb16aabbdb975c6c1cc92", 38, 7) + _l1IlIIl + _l1d_55a757("20", 130, 97) + U_UrlEncode(_l1l1IIl) + _l1d_55a757("d3a8b0aaa2fd", 66, 111) + _lIl1IIl
if _lIl1IIl = _l1d_55a757("7075", 128, 124) and _l1lIIIl <> "" and _llIlIIl <> "" then
_lIllIIl = _lIllIIl + _l1d_55a757("4c7c95948594964c", 186, 176) + _l1lIIIl + _l1d_55a757("cc12200c25142024ef", 42, 192) + _llIlIIl
end if
_l1llIIl = _l1d_55a757("3a51545b5b9785884c58686f5f645e6c6666837778808295818ac290878ccd", 111, 51)
_l1I1IIl = HC_Get(_ll1IIIl, _lIllIIl, {
"Referer": _l1llIIl
"Origin": _l1d_55a757("b6adb0b7b7738184c8d4c4cbdbe0dae8e2e2dff3f4fcfef1fd06be0c0308", 191, 223)
}, 8000)
if _l1I1IIl = invalid or _l1I1IIl.body = "" then return invalid
_lI1lIIl = ParseJSON(_l1I1IIl.body)
if _lI1lIIl = invalid or type(_lI1lIIl) <> _l1d_55a757("dee4d5e6e9f0fffc07f705fb0ff6080b1f0a", 223, 49) then return invalid
_lllIIIl = ""
if _lI1lIIl.status_code <> invalid then _lllIIIl = _lI1lIIl.status_code.ToStr()
if _lllIIIl <> _l1d_55a757("929396", 201, 151) then return invalid
_ll1lIIl = _lI1lIIl.data
if _ll1lIIl = invalid or type(_ll1lIIl) <> _l1d_55a757("a9c9e2b3b6d5ccd9d4cae2cee403d3d6ece7", 50, 105) then return invalid
_l11IIIl = _ll1lIIl.stream_urls
if _l11IIIl = invalid or type(_l11IIIl) <> _l1d_55a757("53718a5c5f736e", 51, 18) or _l11IIIl.Count() = 0 then return invalid
_llIIIIl = []
_lIlIIIl = {}
_llllIIl = []
_l1IIIIl = [_lI1lIIl.subs, _ll1lIIl.subs, _lI1lIIl.default_subs, _ll1lIIl.default_subs]
for each _lll1IIl in _l1IIIIl
if _lll1IIl = invalid or type(_lll1IIl) <> _l1d_55a757("aa9a83b3b6acb7", 202, 242) then continue for
for each _lII1IIl in _lll1IIl
if type(_lII1IIl) <> _l1d_55a757("c5b5dacfd2c1c8c1cce2caeadcfbeff2e4ef", 168, 235) then continue for
_lIIIIIl = ""
if _lII1IIl.url <> invalid then _lIIIIIl = _lII1IIl.url
if _lIIIIIl = "" and _lII1IIl.file <> invalid then _lIIIIIl = _lII1IIl.file
if _lIIIIIl = "" then continue for
if _lIlIIIl.DoesExist(_lIIIIIl) then continue for
_lIlIIIl[_lIIIIIl] = true
_lIIlIIl = ""
if _lII1IIl.code <> invalid then _lIIlIIl = LCase(_lII1IIl.code)
if _lIIlIIl = "" and _lII1IIl.language <> invalid then _lIIlIIl = LCase(_lII1IIl.language)
if _lIIlIIl = "" and _lII1IIl.lang <> invalid and Len(_lII1IIl.lang) >= 2 then _lIIlIIl = LCase(Left(_lII1IIl.lang, 2))
if _lIIlIIl = "" then _lIIlIIl = _l1d_55a757("2422", 105, 24)
_ll11IIl = ""
if _lII1IIl.label <> invalid then _ll11IIl = _lII1IIl.label
if _ll11IIl = "" and _lII1IIl.lang <> invalid then _ll11IIl = _lII1IIl.lang
if _ll11IIl = "" and _lII1IIl.language <> invalid then _ll11IIl = _lII1IIl.language
if _ll11IIl = "" then _ll11IIl = UCase(_lIIlIIl)
_llllIIl.Push({ url: _lIIIIIl, language: _lIIlIIl, name: _ll11IIl })
end for
end for
for each _llllll1 in _llllIIl
if _llllll1.language = _l1d_55a757("7d75", 142, 146) then _llIIIIl.Push(_llllll1)
end for
for each _llllll1 in _llllIIl
if _llllll1.language <> _l1d_55a757("9fad", 213, 239) then _llIIIIl.Push(_llllll1)
end for
for each _lI1IIIl in _l11IIIl
if type(_lI1IIIl) <> _l1d_55a757("2046474f5963", 89, 22) and type(_lI1IIIl) <> _l1d_55a757("14faf91b200c0a14", 207, 87) then continue for
if _lI1IIIl = "" then continue for
_lI11IIl = HC_Get(_ll1IIIl, _lI1IIIl, { "Referer": _l1llIIl }, 6000)
if _lI11IIl = invalid or _lI11IIl.body = "" then continue for
if Left(_lI11IIl.body, 7) <> _l1d_55a757("c4adb5c4aee3cc", 107, 124) then continue for
return {
url: _lI1IIIl
streamFormat: _l1d_55a757("dddcce", 244, 65)
qualities: []
subtitles: _llIIIIl
chapters: []
referer: _l1llIIl
userAgent: ""
}
end for
return invalid
end function
function RP_HlsLeadSkip(_l11Ill1 as Object, _lllIll1 as String, _l1lIll1 as String, _ll1Ill1 as String) as Integer
if _l1lIll1 = "" then return 0
_l1I1ll1 = _lllIll1
_l1IIll1 = _l1lIll1
if _l1I1ll1 = "" then
_lIlIll1 = HC_Get(_l11Ill1, _l1IIll1, { "Referer": _ll1Ill1 }, 5000)
if _lIlIll1 = invalid or _lIlIll1.body = "" then return 0
_l1I1ll1 = _lIlIll1.body
end if
if Left(_l1I1ll1, 7) <> _l1d_55a757("9a3f253440993e", 216, 159) then return 0
if Instr(1, _l1I1ll1, _l1d_55a757("47f008076111670c16130b0a197c1b211c", 67, 231)) <= 0 then
return RP_ProbeMediaPlaylist(_l11Ill1, _l1I1ll1, _l1IIll1, _ll1Ill1)
end if
_lII1ll1 = 0
for each line in _l1I1ll1.Tokenize(Chr(10))
_llIIll1 = U_Trim(line)
if _llIIll1 = "" then continue for
if Left(_llIIll1, 1) = _l1d_55a757("f5", 232, 42) then continue for
_llll1l1 = U_AbsUrl(_llIIll1, HC_OriginOf(_l1IIll1))
if _llll1l1 = "" then continue for
_lIIIll1 = HC_Get(_l11Ill1, _llll1l1, { "Referer": _ll1Ill1 }, 5000)
if _lIIIll1 <> invalid and _lIIIll1.body <> "" and Left(_lIIIll1.body, 7) = _l1d_55a757("ed564c4b67ec55", 50, 220) then
_lI1Ill1 = RP_ProbeMediaPlaylist(_l11Ill1, _lIIIll1.body, _llll1l1, _ll1Ill1)
if _lI1Ill1 > 0 then return _lI1Ill1
end if
_lII1ll1 = _lII1ll1 + 1
if _lII1ll1 >= 8 then exit for
end for
return 0
end function
function RP_ProbeMediaPlaylist(_lI11Il1 as Object, _lll1Il1 as String, _l1l1Il1 as String, _l111Il1 as String) as Integer
_l1IlIl1 = 0.0
_lIIlIl1 = ""
_lIl1Il1 = 0.0
_llIlIl1 = CreateObject(_l1d_55a757("02f2e8fe03040a", 136, 8), _l1d_55a757("14fde5f4fa000b1227f7253322380c393e", 123, 188), _l1d_55a757("67", 155, 117))
for each line in _lll1Il1.Tokenize(Chr(10))
_l1I1Il1 = U_Trim(line)
if _l1I1Il1 = "" then continue for
if Left(_l1I1Il1, 1) = _l1d_55a757("1a", 3, 250) then
_lI1lIl1 = _llIlIl1.match(_l1I1Il1)
if _lI1lIl1 <> invalid and _lI1lIl1.Count() >= 2 then _lIl1Il1 = Val(_lI1lIl1[1])
continue for
end if
_lIIlIl1 = U_AbsUrl(_l1I1Il1, HC_OriginOf(_l1l1Il1))
_l1IlIl1 = _lIl1Il1
exit for
end for
if _lIIlIl1 = "" then return 0
_ll11Il1 = HC_GetRange(_lI11Il1, _lIIlIl1, { "Referer": _l111Il1 }, _l1d_55a757("bda5adbfb86d7d8382", 61, 94), 5000)
if _ll11Il1 = invalid then return 0
if _ll11Il1.status <= 0 then return 0
if Len(_ll11Il1.body) > 0 then return 0
_llI1Il1 = Int(_l1IlIl1 + 0.999) + 2
if _llI1Il1 < 4 then _llI1Il1 = 8
if _llI1Il1 > 30 then _llI1Il1 = 30
print _l1d_55a757("ad7d848ebb41949693a09fa19b9d5c6f6fa7c1bfb371bac0ccd0d483d9ced3dcd7e3ec9baba1f0ecebf123feff09d9", 32, 50); _llI1Il1
return _llI1Il1
end function
function RP_VidrockEncrypt(_ll1l111 as String, _l1ll111 as String, _llll111 as String) as String
_l11Il11 = CreateObject(_l1d_55a757("dfe71004091ff8f2fd05fd", 252, 81))
_lI1l111 = _l11Il11.Setup(true, _l1d_55a757("b4bbc8090f171915caced0", 227, 50), _l1ll111, _llll111, 1)
if _lI1l111 <> 0 then return ""
_l11l111 = CreateObject(_l1d_55a757("282e5e2a32446b3d40543f", 127, 27))
_l11l111.FromAsciiString(_ll1l111)
_l1IIl11 = CreateObject(_l1d_55a757("ed0323fbf3052c02051510", 245, 102))
_lI1Il11 = _l11Il11.Process(_l11l111)
if _lI1Il11 <> invalid then
for _lIIIl11 = 0 to _lI1Il11.Count() - 1
_l1IIl11.Push(_lI1Il11[_lIIIl11])
end for
end if
_llIIl11 = _l11Il11.Final()
if _llIIl11 <> invalid then
for _lIIIl11 = 0 to _llIIl11.Count() - 1
_l1IIl11.Push(_llIIl11[_lIIIl11])
end for
end if
if _l1IIl11.Count() = 0 then return ""
_ll1Il11 = _l1IIl11.ToBase64String()
_llIl111 = CreateObject(_l1d_55a757("563c7c4c4d5262", 111, 57), _l1d_55a757("8bc3", 117, 98), "")
_l1Il111 = CreateObject(_l1d_55a757("f6061c16171c02", 186, 46), _l1d_55a757("99", 50, 124), "")
_lIIl111 = CreateObject(_l1d_55a757("36361c3237384e", 192, 132), _l1d_55a757("837872", 103, 41), "")
_lIll111 = _llIl111.ReplaceAll(_ll1Il11, _l1d_55a757("e6", 183, 76))
_lIll111 = _l1Il111.ReplaceAll(_lIll111, _l1d_55a757("3a", 20, 239))
_lIll111 = _lIIl111.ReplaceAll(_lIll111, "")
return _lIll111
end function
function RP_ResolveVidrock(_lI11I11 as String, _lllllI1 as String, _l11llI1 as Object) as Object
_lI1II11 = CreateObject(_l1d_55a757("ff172513181917", 244, 121), _l1d_55a757("c7cdbdc58994969296e2e7d8eeacb19db9b0aca7ac08090f9ec919c7c2c5b0db2b2c302028363ccbf64647484edd0858595c4d", 213, 205), _l1d_55a757("d0", 33, 136))
m = _lI1II11.match(_lI11I11)
if m = invalid or m.Count() < 3 then return invalid
_lIlII11 = m[1]
_ll11I11 = m[2]
_ll1llI1 = ""
_l1I1I11 = ""
if m.Count() >= 5 then
_ll1llI1 = m[3]
_l1I1I11 = m[4]
end if
_l1l1I11 = _l1d_55a757("e3eaedf4fac4b4b701fff50e060510ce1d1b", 164, 23)
if _lIlII11 = _l1d_55a757("c7c8", 86, 165) and _ll1llI1 <> "" and _l1I1I11 <> "" then
_l1III11 = _ll11I11 + _l1d_55a757("1e", 172, 43) + _ll1llI1 + _l1d_55a757("6c", 171, 120) + _l1I1I11
else
_l1III11 = _ll11I11
end if
_l1lII11 = _l1d_55a757("7b757d8488b7898694c99b9b9fa0a7aba7abb1b1b9babdc1c5bcc5c3cf00d8d6d7e0e2e1eae6e9ecf428fcfdfb0306ff0e3c0d111846204d1f292a5f3264312e", 139, 191)
_lllII11  = _l1d_55a757("54645e5d5f366a776b40747a78818082888a8a90929396989eada6b2a881afb7", 214, 115)
_llI1I11 = RP_VidrockEncrypt(_l1III11, _l1lII11, _lllII11)
if _llI1I11 = "" then return invalid
if _lIlII11 = _l1d_55a757("1f20", 226, 137) and _ll1llI1 <> "" and _l1I1I11 <> "" then
_lIl1I11 = _l1l1I11 + _l1d_55a757("86cfc1cd92cecf9b", 186, 241) + _llI1I11
else
_lIl1I11 = _l1l1I11 + _l1d_55a757("0b544652175c5d57617029", 186, 118) + _llI1I11
end if
_lII1I11 = {
"Referer": _l1l1I11 + _l1d_55a757("f0", 205, 14) + _lIlII11 + _l1d_55a757("0e", 225, 64) + _ll11I11
"Origin": _l1l1I11
"Accept": _l1d_55a757("192d30171d262b3b29262a6c344e35397e8d5c4e5e658d6f56645f5da2b1aaa8b0", 79, 235)
"User-Agent": _l1d_55a757("fee3d9ebe9ecfcb5aebab7cac51f0c0c15130e15e53e37eee2e4edeae800523f3ffafbfd1540090a1a24885a5d647085767e9a7b713f3841404a4a485d58bebeb5c1c36675acb4b9be84e6c7d0cbca8f99ffd7d4dcdde8a5a2a6a3b0adb6b3bcb9cc221313190d17d8d1dad9e3e3e1", 60, 141)
}
_l1lllI1 = HC_Get(_l11llI1, _lIl1I11, _lII1I11, 8000)
if _l1lllI1 = invalid or _l1lllI1.body = "" then return invalid
_llIII11 = ParseJSON(_l1lllI1.body)
if _llIII11 = invalid or type(_llIII11) <> _l1d_55a757("cbd3c0d5d8dfeee7f2e0f0e8fae1f5f80af5", 92, 157) then
_l111I11 = RP_TryBase64Decode(U_Trim(_l1lllI1.body))
if _l111I11 <> "" then _llIII11 = ParseJSON(_l111I11)
if _llIII11 = invalid or type(_llIII11) <> _l1d_55a757("76648d7e817077747f977d9b8faea0a397a2", 171, 157) then return invalid
end if
_llIllI1 = []
RP_WalkForStreams(_llIII11, _llIllI1)
if _llIllI1.Count() = 0 then return invalid
_l1IllI1 = []
_lIIII11 = invalid
if _llIII11.subtitle <> invalid then _lIIII11 = _llIII11.subtitle
if _lIIII11 = invalid and _llIII11.subtitles <> invalid then _lIIII11 = _llIII11.subtitles
if _lIIII11 = invalid and _llIII11.captions <> invalid then _lIIII11 = _llIII11.captions
if _lIIII11 <> invalid and type(_lIIII11) = _l1d_55a757("69819e72758782", 180, 163) then
for each _lIlllI1 in _lIIII11
if type(_lIlllI1) <> _l1d_55a757("59614e63666d7c75806e7e76886f83869883", 92, 43) then continue for
_lIIllI1 = ""
if _lIlllI1.file <> invalid then _lIIllI1 = _lIlllI1.file
if _lIIllI1 = "" and _lIlllI1.url <> invalid then _lIIllI1 = _lIlllI1.url
if _lIIllI1 = "" then continue for
_ll1II11 = _l1d_55a757("736d", 219, 181)
if _lIlllI1.language <> invalid then _ll1II11 = LCase(Left(_lIlllI1.language, 2))
if _ll1II11 = "" and _lIlllI1.lang <> invalid then _ll1II11 = LCase(Left(_lIlllI1.lang, 2))
_l11II11 = ""
if _lIlllI1.label <> invalid then _l11II11 = _lIlllI1.label
if _l11II11 = "" and _lIlllI1.language <> invalid then _l11II11 = _lIlllI1.language
if _l11II11 = "" then _l11II11 = _l1d_55a757("62837788888e89859a", 198, 205)
_l1IllI1.Push({ url: _lIIllI1, language: _ll1II11, name: _l11II11 })
end for
end if
_lI1llI1 = _llIllI1[0]
return {
url: _lI1llI1
streamFormat: U_StreamFormat(_lI1llI1)
qualities: []
subtitles: _l1IllI1
chapters: []
referer: _lI11I11
userAgent: ""
}
end function
sub RP_WalkForStreams(_lIll1I1 as Dynamic, _ll1l1I1 as Object)
if ((44166 - 7361 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lIll1I1 = invalid or _ll1l1I1 = invalid then return
_l11l1I1 = type(_lIll1I1)
if _l11l1I1 = _l1d_55a757("d2d0a5dadddcd3dcd7efe5f7e7c6fcffef0a", 1, 95) then
for each _l1ll1I1 in _lIll1I1
_lI1l1I1 = _lIll1I1[_l1ll1I1]
if _lI1l1I1 = invalid then continue for
_llIl1I1 = type(_lI1l1I1)
if _llIl1I1 = _l1d_55a757("34565b67656f", 223, 168) or _llIl1I1 = _l1d_55a757("606645676c787680", 223, 179) then
if Instr(1, _lI1l1I1, _l1d_55a757("b276c384d4", 71, 73)) > 0 or Instr(1, _lI1l1I1, _l1d_55a757("80444483", 95, 15)) > 0 then _ll1l1I1.Push(_lI1l1I1)
else if _llIl1I1 = _l1d_55a757("1d3556272a41404d4836563a5077474a605b", 118, 25) or _llIl1I1 = _l1d_55a757("132b4c1c1f3530", 182, 79) then
RP_WalkForStreams(_lI1l1I1, _ll1l1I1)
end if
end for
else if _l11l1I1 = _l1d_55a757("d7f5cee0e3f7f2", 19, 118) then
for each _llll1I1 in _lIll1I1
if _llll1I1 = invalid then continue for
_lIIIlI1 = type(_llll1I1)
if _lIIIlI1 = _l1d_55a757("ad9192acb4b0", 112, 138) or _lIIIlI1 = _l1d_55a757("5b73425e6781817d", 20, 245) then
if Instr(1, _llll1I1, _l1d_55a757("a4eaa7e8a6", 158, 244)) > 0 or Instr(1, _llll1I1, _l1d_55a757("a3e707c6", 47, 162)) > 0 then _ll1l1I1.Push(_llll1I1)
else if _lIIIlI1 = _l1d_55a757("3e2e53484b3a413a455b43635574686b5d68", 168, 100) or _lIIIlI1 = _l1d_55a757("44325b4d50444f", 43, 235) then
RP_WalkForStreams(_llll1I1, _ll1l1I1)
end if
end for
end if
end sub
function RP_TryBase64Decode(_lII1II1 as String) as String
if ((20244 - 6748 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lII1II1 = invalid or _lII1II1 = "" then return ""
_lllIII1 = _lII1II1
_l1I1II1 = Len(_lllIII1) mod 4
if _l1I1II1 = 1 then return ""
if _l1I1II1 = 2 then _lllIII1 = _lllIII1 + _l1d_55a757("8285", 103, 40)
if _l1I1II1 = 3 then _lllIII1 = _lllIII1 + _l1d_55a757("02", 241, 54)
_llI1II1 = CreateObject(_l1d_55a757("aa9280aab0a48bbfc2b4bf", 12, 44))
_llI1II1.FromBase64String(_lllIII1)
return _llI1II1.ToAsciiString()
end function
function RP_ResolveXpass(_l1l11lI as String, _lI1I1lI as String, _l1II1lI as Object) as Object
_l1111lI = {}
if _lI1I1lI <> "" then _l1111lI[_l1d_55a757("2bf7fdfd17031d", 237, 108)] = _lI1I1lI else _l1111lI[_l1d_55a757("c1b7bbbdadc3b3", 240, 31)] = _l1d_55a757("31303332326e8487493b5b485c5867a0575fa8", 251, 158)
_lllI1lI = HC_Get(_l1II1lI, _l1l11lI, _l1111lI, 8000)
if _lllI1lI = invalid or _lllI1lI.body = "" then return invalid
_lI111lI = _lllI1lI.body
_ll111lI = _lllI1lI.finalUrl
if _ll111lI = invalid or _ll111lI = "" then _ll111lI = _l1l11lI
_llIl1lI = []
_l11I1lI = CreateObject(_l1d_55a757("e6e6cce6e7ec02", 194, 54), chr(34) + _l1d_55a757("6e6d658076768387", 192, 190) + chr(34) + _l1d_55a757("9775cfc2a381db", 118, 109) + chr(34) + _l1d_55a757("cb7f7f", 197, 222) + chr(34) + _l1d_55a757("1acbcc", 176, 45) + chr(34), _l1d_55a757("41", 188, 108))
_ll1I1lI = _l11I1lI.match(_lI111lI)
if _ll1I1lI <> invalid and _ll1I1lI.Count() >= 2 then
_llIl1lI.Push({ label: _l1d_55a757("baa8a9d7aaab9796a5b7b3", 239, 255), url: RP_AbsUrl(_ll1I1lI[1], _ll111lI) })
end if
_l11l1lI = RP_ParseXpassBackups(_lI111lI)
if _l11l1lI <> invalid and type(_l11l1lI) = _l1d_55a757("29375c32354530", 249, 158) then
for each _lIl11lI in _l11l1lI
if type(_lIl11lI) <> _l1d_55a757("6d5d42777a697069748a72928463979a8c97", 200, 179) then continue for
_lIllIlI = _lIl11lI.url
if _lIllIlI = invalid or _lIllIlI = "" then continue for
_lII11lI = ""
if _lIl11lI.name <> invalid then _lII11lI = _lIl11lI.name
if _lII11lI = "" then _lII11lI = _l1d_55a757("1c1e232e3339", 228, 150)
_llIl1lI.Push({ label: _lII11lI, url: RP_AbsUrl(_lIllIlI, _ll111lI) })
end for
end if
_llII1lI = {}
_l1llIlI = []
for each _lI1l1lI in _llIl1lI
if _lI1l1lI.url = "" then continue for
if _llII1lI.DoesExist(_lI1l1lI.url) then continue for
_llII1lI[_lI1l1lI.url] = true
_l1llIlI.Push(_lI1l1lI)
end for
for _llI11lI = 1 to _l1llIlI.Count() - 1
_l1Il1lI = _l1llIlI[_llI11lI]
_lIIl1lI = RP_XpassSrcRank(_l1Il1lI)
_l1I11lI = _llI11lI - 1
while _l1I11lI >= 0
if RP_XpassSrcRank(_l1llIlI[_l1I11lI]) <= _lIIl1lI then exit while
_l1llIlI[_l1I11lI + 1] = _l1llIlI[_l1I11lI]
_l1I11lI = _l1I11lI - 1
end while
_l1llIlI[_l1I11lI + 1] = _l1Il1lI
end for
_llllIlI = RP_FetchXpassSubs(_lI111lI, _l1II1lI)
for each _lI1l1lI in _l1llIlI
_l1lI1lI = _lI1l1lI.url
_lIlI1lI = HC_Get(_l1II1lI, _l1lI1lI, { "Referer": _ll111lI }, 6000)
if _lIlI1lI = invalid or _lIlI1lI.body = "" then continue for
_lll11lI = ParseJSON(_lIlI1lI.body)
if _lll11lI = invalid or type(_lll11lI) <> _l1d_55a757("eae0c1f2f5ecebf8f3030107fbe214170b26", 199, 53) then continue for
_lIII1lI = RP_XpassFirstSource(_lll11lI)
if _lIII1lI = "" then continue for
_lIII1lI = RP_AbsUrl(_lIII1lI, _l1lI1lI)
_ll1lIlI = HC_Get(_l1II1lI, _lIII1lI, { "Referer": _ll111lI }, 6000)
if _ll1lIlI = invalid or _ll1lIlI.body = "" then continue for
if Left(_ll1lIlI.body, 7) <> _l1d_55a757("f9223a39331841", 131, 89) then continue for
return {
url: _lIII1lI
streamFormat: _l1d_55a757("adb4b8", 35, 98)
qualities: []
subtitles: _llllIlI
chapters: []
referer: _ll111lI
userAgent: ""
}
end for
return invalid
end function
function RP_XpassSrcRank(_lIlIIlI as Object) as Integer
if ((11963 - 1709 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_ll1IIlI = ""
_l11IIlI = ""
if _lIlIIlI.label <> invalid then _ll1IIlI = UCase(_lIlIIlI.label)
if _lIlIIlI.url <> invalid then _l11IIlI = LCase(_lIlIIlI.url)
if Instr(1, _ll1IIlI, _l1d_55a757("504045", 44, 216)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("98d9d3d3c9d9aa", 48, 121)) > 0 then return 100
if Instr(1, _ll1IIlI, _l1d_55a757("e1e2ec", 102, 182)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("02030d48521c55", 66, 211)) > 0 then return 0
if Instr(1, _ll1IIlI, _l1d_55a757("b6c8c2", 254, 14)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("b2fefa06be", 37, 168)) > 0 then return 1
if Instr(1, _ll1IIlI, _l1d_55a757("cad8ca", 222, 61)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("c7f60402d3", 52, 172)) > 0 then return 2
return 50
end function
function RP_ParseXpassBackups(_lII111I as String) as Object
if _lII111I = invalid or _lII111I = "" then return []
_l1II11I = CreateObject(_l1d_55a757("acca92c6cbccc4", 209, 9), _l1d_55a757("f2e4f425fb36f0f6f7021311134319536d4f255f5856", 226, 94), _l1d_55a757("00", 121, 240))
_l1I111I = _l1II11I.match(_lII111I)
if _l1I111I = invalid or _l1I111I.Count() < 1 then return []
_ll1I11I = _l1I111I[0]
_llllI1I = Instr(1, _lII111I, _ll1I11I)
if _llllI1I <= 0 then return []
_lll111I = Instr(_llllI1I, _lII111I, _l1d_55a757("b3", 50, 74))
if _lll111I <= 0 then return []
_ll1111I = 0
_l1lI11I = false
_lI1I11I = ""
_llI111I = false
_lI1111I = 0
_lIlI11I = Len(_lII111I)
_l1l111I = chr(92)
_l11111I = chr(34)
_lIII11I = _l1d_55a757("f2", 14, 201)
for _lllI11I = _lll111I to _lIlI11I
_lIl111I = Mid(_lII111I, _lllI11I, 1)
if _l1lI11I then
if _llI111I then
_llI111I = false
else if _lIl111I = _l1l111I then
_llI111I = true
else if _lIl111I = _lI1I11I then
_l1lI11I = false
end if
else
if _lIl111I = _l11111I or _lIl111I = _lIII11I then
_l1lI11I = true
_lI1I11I = _lIl111I
else if _lIl111I = _l1d_55a757("a8", 239, 244) then
_ll1111I = _ll1111I + 1
else if _lIl111I = _l1d_55a757("d7", 186, 240) then
_ll1111I = _ll1111I - 1
if _ll1111I = 0 then
_lI1111I = _lllI11I
exit for
end if
end if
end if
end for
if _lI1111I = 0 then return []
_llII11I = Mid(_lII111I, _lll111I, _lI1111I - _lll111I + 1)
_l11I11I = ParseJSON(_llII11I)
if _l11I11I = invalid or type(_l11I11I) <> _l1d_55a757("222a5b2b2e442f", 62, 214) then return []
return _l11I11I
end function
function RP_XpassFirstSource(_l1III1I as Object) as String
if ((48538 - 6934 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _l1III1I = invalid or type(_l1III1I) <> _l1d_55a757("ced6c3d8dbe2f1eaf5e3f3ebfde4f8fb0df8", 28, 96) then return ""
_l1lllII = _l1III1I.playlist
if _l1lllII = invalid or type(_l1lllII) <> _l1d_55a757("dee6d3e7eafce7", 92, 176) then return ""
for each _lIIII1I in _l1lllII
if type(_lIIII1I) <> _l1d_55a757("f6f60b000302f902fd130b1b0d2c20231530", 96, 228) then continue for
_ll1llII = _lIIII1I.sources
if _ll1llII = invalid or type(_ll1llII) <> _l1d_55a757("fe14f5070a1e19", 151, 25) then continue for
for each _lIlllII in _ll1llII
if type(_lIlllII) <> _l1d_55a757("362e4b40433a39423d4b4b53456c60635570", 100, 32) then continue for
_lllllII = _lIlllII.file
if _lllllII <> invalid and _lllllII <> "" then return _lllllII
end for
end for
return ""
end function
function RP_FetchXpassSubs(_lI111II as String, _lI1I1II as Object) as Object
_lIlI1II = []
if _lI111II = invalid or _lI111II = "" then return _lIlI1II
_ll1I1II = CreateObject(_l1d_55a757("8b83b1838489a7", 166, 183), _l1d_55a757("f402f6d3fdc80308180e0e1bee18e2d8fa24ee", 24, 134) + chr(34) + _l1d_55a757("5a3036", 120, 10) + chr(34) + _l1d_55a757("52e7ec", 46, 223) + chr(34), _l1d_55a757("20", 250, 141))
m = _ll1I1II.match(_lI111II)
if m = invalid or m.Count() < 2 then return _lIlI1II
_l11I1II = HC_Get(_lI1I1II, m[1], invalid, 6000)
if _l11I1II = invalid or _l11I1II.body = "" then return _lIlI1II
_lII11II = ParseJSON(_l11I1II.body)
if _lII11II = invalid or type(_lII11II) <> _l1d_55a757("53714a5c5f736e", 211, 178) then return _lIlI1II
_llII1II = _lII11II.Count()
if _llII1II > 30 then _llII1II = 30
for _llI11II = 0 to _llII1II - 1
_l1I11II = _lII11II[_llI11II]
if type(_l1I11II) <> _l1d_55a757("1715ee1f2221182520382e3c300f41443853", 131, 38) then continue for
_l1II1II = _l1I11II.url
if _l1II1II = invalid or _l1II1II = "" then continue for
_lllI1II = _l1d_55a757("c2ca", 194, 27)
if _l1I11II.language <> invalid then _lllI1II = LCase(_l1I11II.language)
_l1lI1II = ""
if _l1I11II.display <> invalid then _l1lI1II = _l1I11II.display
if _l1lI1II = "" then
if _l1I11II.language <> invalid then _l1lI1II = UCase(_l1I11II.language) else _l1lI1II = _l1d_55a757("e0ea", 151, 14)
end if
_lIlI1II.Push({ url: _l1II1II, language: _lllI1II, name: _l1lI1II })
end for
return _lIlI1II
end function
function RP_ResolveJwplayerPage(_lI1llll as String, _l1Illll as String, _lll1lll as String, _l111lll as Object) as Object
if ((24918 - 4153 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lI1llll = invalid or _lI1llll = "" then return invalid
_l11llll = []
RP_JwExtractInto(_lI1llll, _l11llll)
_llIllll = CreateObject(_l1d_55a757("4e3c74484d4e56", 41, 243), _l1d_55a757("fff1091124db10041e1c0e2c292d42f924fb39013d074b0d47134e691f70724e78747d3221273766796d8975743d", 183, 45), _l1d_55a757("11", 1, 169))
_lIIllll = _llIllll.match(_lI1llll)
if _lIIllll <> invalid and _lIIllll.Count() >= 1 then
_llI1lll = JU_UnpackPacked(_lIIllll[0])
if _llI1lll <> "" then RP_JwExtractInto(_llI1lll, _l11llll)
end if
if _l11llll.Count() = 0 then return invalid
_l1l1lll = _lll1lll
if _l1l1lll = "" then _l1l1lll = _l1Illll
_ll11lll = {}
for each _ll1llll in _l11llll
_lI11lll = RP_AbsUrl(_ll1llll.url, _l1Illll)
if _lI11lll = "" then continue for
if _ll11lll.DoesExist(_lI11lll) then continue for
_ll11lll[_lI11lll] = true
_lIl1lll = HC_Get(_l111lll, _lI11lll, { "Referer": _l1l1lll }, 6000)
if _lIl1lll = invalid or _lIl1lll.body = "" then continue for
if _ll1llll.fmt = _l1d_55a757("272622", 127, 16) and Left(_lIl1lll.body, 7) <> _l1d_55a757("ec8d8d849eeb8c", 215, 248) then continue for
return {
url: _lI11lll
streamFormat: _ll1llll.fmt
qualities: []
subtitles: RP_ExtractSubs(_lI1llll)
chapters: []
referer: _l1l1lll
userAgent: ""
}
end for
return invalid
end function
sub RP_JwExtractInto(_lI1lIll as String, _llII1ll as Object)
if _lI1lIll = invalid or _lI1lIll = "" then return
_l1lI1ll = chr(34)
_llllIll = _l1d_55a757("373737410d39857819459123", 223, 126) + _l1lI1ll + _l1d_55a757("f37cea8086", 88, 116) + _l1lI1ll + _l1d_55a757("9bf4dd9dace0b70c", 52, 136) + _l1lI1ll + _l1d_55a757("5e4b", 106, 17)
_l1llIll = _l1d_55a757("a88fa8b0a4a18bbd677a97c973a7", 140, 169) + _l1lI1ll + _l1d_55a757("8891899d9d", 157, 206) + _l1lI1ll + _l1d_55a757("fcf5de200fe1180d", 101, 186) + _l1lI1ll + _l1d_55a757("dcd9", 99, 152)
_lIllIll = _l1d_55a757("cccee2e6d82215f2e42e02", 252, 61) + _l1lI1ll + _l1d_55a757("5e4b5b4b53", 235, 146) + _l1lI1ll + _l1d_55a757("121f3c00174b2d1e1f15136d226b21687c7239415258", 154, 85) + _l1lI1ll + _l1d_55a757("9401979b0c", 47, 140) + _l1lI1ll + _l1d_55a757("2cc9", 214, 59)
_ll1lIll = _l1d_55a757("15fc0c17fe260bfe30daed0a3ce61a", 140, 25) + _l1lI1ll + _l1d_55a757("726f7d6f75", 226, 173) + _l1lI1ll + _l1d_55a757("0a533cfe0d3f166b", 61, 240) + _l1lI1ll + _l1d_55a757("dc29", 187, 64)
for each _lIII1ll in [_llllIll, _l1llIll, _lIllIll, _ll1lIll]
_l11lIll = CreateObject(_l1d_55a757("d6c4fcd4d5dae2", 107, 189), _lIII1ll, _l1d_55a757("7b", 67, 81))
m = _l11lIll.match(_lI1lIll)
if m <> invalid and m.Count() >= 2 then
_llIlIll = RP_UnescapeSlashes(m[1])
_lIlI1ll = _l1d_55a757("bdc4ce", 192, 21)
if Instr(1, LCase(_llIlIll), _l1d_55a757("d3132bf2", 9, 172)) > 0 then _lIlI1ll = _l1d_55a757("b8b6f5", 222, 5)
_llII1ll.Push({ url: _llIlIll, fmt: _lIlI1ll })
end if
end for
_l11I1ll = CreateObject(_l1d_55a757("f8f81ef4f9fa10", 96, 230), _l1d_55a757("19dcebeeedf140403639e8f0", 65, 176) + _l1lI1ll + _l1d_55a757("ab090c0fe3b317c41ecf13b801c92931", 51, 151) + _l1lI1ll + _l1d_55a757("98d6d9dcf0c0e4b2b6", 3, 116), _l1d_55a757("d8", 183, 250))
_ll1I1ll = _l11I1ll.match(_lI1lIll)
if _ll1I1ll <> invalid and _ll1I1ll.Count() >= 2 then _llII1ll.Push({ url: _ll1I1ll[1], fmt: _l1d_55a757("383759", 44, 244) })
_lI1I1ll = CreateObject(_l1d_55a757("d6d6fcd2d7d8ee", 32, 132), _l1d_55a757("ce11181b2226edf5e3e65d5d", 165, 65) + _l1lI1ll + _l1d_55a757("cdc9cccfa5f3d9e6deefb5bb02e8ee", 98, 136) + _l1lI1ll + _l1d_55a757("50181b1e1046286062", 252, 117), _l1d_55a757("6e", 236, 233))
_l1II1ll = _lI1I1ll.match(_lI1lIll)
if _l1II1ll <> invalid and _l1II1ll.Count() >= 2 then _llII1ll.Push({ url: _l1II1ll[1], fmt: _l1d_55a757("898148", 59, 51) })
end sub
function RP_UnescapeSlashes(_lll1l1l as String) as String
if ((29400 - 7350 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lll1l1l = invalid or _lll1l1l = "" then return ""
_lIIll1l = CreateObject(_l1d_55a757("7b7b617b7c8197", 66, 75), _l1d_55a757("c7ca7e", 57, 98), _l1d_55a757("04", 254, 107))
return _lIIll1l.replaceAll(_lll1l1l, _l1d_55a757("f2", 231, 42))
end function
function RP_AbsUrl(_llllI1l as String, _llII11l as String) as String
if _llllI1l = invalid or _llllI1l = "" then return ""
_lIII11l = U_Trim(_llllI1l)
if Left(_lIII11l, 7) = _l1d_55a757("c9b8bbba839b9e", 178, 239) or Left(_lIII11l, 8) = _l1d_55a757("e8eff2f9fd49373a", 101, 219) then return _lIII11l
if Left(_lIII11l, 2) = _l1d_55a757("5e61", 184, 199) then return _l1d_55a757("877679787c48", 145, 142) + _lIII11l
_ll1lI1l = HC_OriginOf(_llII11l)
if _ll1lI1l = "" then return _lIII11l
if Left(_lIII11l, 1) = _l1d_55a757("c3", 24, 140) then return _ll1lI1l + _lIII11l
_lI1lI1l = Len(_ll1lI1l) + 1
if _lI1lI1l > Len(_llII11l) then return _ll1lI1l + _l1d_55a757("1d", 48, 254) + _lIII11l
_l11lI1l = Mid(_llII11l, _lI1lI1l + 1)
_llIlI1l = Instr(1, _l11lI1l, _l1d_55a757("10", 208, 33))
if _llIlI1l > 0 then _l11lI1l = Left(_l11lI1l, _llIlI1l - 1)
_l1II11l = Instr(1, _l11lI1l, _l1d_55a757("38", 35, 56))
if _l1II11l > 0 then _l11lI1l = Left(_l11lI1l, _l1II11l - 1)
_lIllI1l = 0
for _l1llI1l = 1 to Len(_l11lI1l)
if Mid(_l11lI1l, _l1llI1l, 1) = _l1d_55a757("7c", 39, 116) then _lIllI1l = _l1llI1l
end for
if _lIllI1l = 0 then return _ll1lI1l + _l1d_55a757("1b", 30, 234) + _lIII11l
return _ll1lI1l + _l1d_55a757("68", 145, 170) + Left(_l11lI1l, _lIllI1l) + _lIII11l
end function
function RP_ResolveLookmovie(_l111lIl as String, _l1IIlIl as String, _llll1Il as Object) as Object
_llI1lIl = {}
if _l1IIlIl <> "" then _llI1lIl[_l1d_55a757("3f2f31352b3b31", 55, 218)] = _l1IIlIl else _llI1lIl[_l1d_55a757("0b45454b37513d", 210, 139)] = _l111lIl
_lI1IlIl = HC_Get(_llll1Il, _l111lIl, _llI1lIl, 8000)
if _lI1IlIl = invalid or _lI1IlIl.body = "" then return invalid
_lI11lIl = _lI1IlIl.finalUrl
if _lI11lIl = invalid or _lI11lIl = "" then _lI11lIl = _l111lIl
_l11IlIl = CreateObject(_l1d_55a757("96b4bcb4b5bab2", 115, 149), _l1d_55a757("c0d4cac0b30ad3e5d1e1eddddee0d128032afa300236003c08420df85005013307190e6676766c4b3e503a545390", 204, 23), _l1d_55a757("37", 190, 96))
_llIIlIl = _l11IlIl.match(_lI1IlIl.body)
if _llIIlIl = invalid or _llIIlIl.Count() < 1 then return invalid
_lIll1Il = JU_UnpackPacked(_llIIlIl[0])
if _lIll1Il = "" then return invalid
_lllIlIl = {}
_lII1lIl = CreateObject(_l1d_55a757("f4fcda080d0efc", 220, 70), chr(34) + _l1d_55a757("be0100021dc7cbc723da", 60, 170) + chr(34) + _l1d_55a757("e5b99588f1c5a1", 179, 246) + chr(34) + _l1d_55a757("afc5c3", 148, 243) + chr(34) + _l1d_55a757("d9aaab", 128, 252) + chr(34), _l1d_55a757("929f", 154, 159))
_l1lIlIl = _lII1lIl.matchAll(_lIll1Il)
if _l1lIlIl <> invalid then
for each _lIlIlIl in _l1lIlIl
if _lIlIlIl.Count() < 3 then continue for
_lllIlIl[_lIlIlIl[1]] = RP_UnescapeSlashes(_lIlIlIl[2])
end for
end if
_ll1IlIl = [_l1d_55a757("d8d7c508", 214, 26), _l1d_55a757("bbc2a670", 179, 224), _l1d_55a757("f4f3f1b3", 190, 30)]
for each _l1I1lIl in _ll1IlIl
_l1ll1Il = _lllIlIl[_l1I1lIl]
if _l1ll1Il = invalid or _l1ll1Il = "" then continue for
_l1ll1Il = RP_AbsUrl(_l1ll1Il, _lI11lIl)
_lIIIlIl = HC_Get(_llll1Il, _l1ll1Il, { "Referer": _lI11lIl }, 6000)
if _lIIIlIl = invalid or _lIIIlIl.body = "" then continue for
if Left(_lIIIlIl.body, 7) <> _l1d_55a757("fc1d2b321e1b3c", 142, 79) then continue for
return {
url: _l1ll1Il
streamFormat: _l1d_55a757("dfdeec", 38, 145)
qualities: []
subtitles: RP_ExtractSubs(_lI1IlIl.body)
chapters: []
referer: _lI11lIl
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidora(_lIllIIl as String, _llIlIIl as String, _l1IlIIl as Object) as Object
_l11lIIl = {}
if _llIlIIl <> "" then _l11lIIl[_l1d_55a757("7e96989caaa2b0", 3, 45)] = _llIlIIl else _l11lIIl[_l1d_55a757("c2d0d4d6eedcf4", 204, 36)] = _l1d_55a757("b2a1a4a3a7f3090ccdd2bed2d1c2d3c7e12bd4f033", 241, 25)
_lI1lIIl = HC_Get(_l1IlIIl, _lIllIIl, _l11lIIl, 8000)
if _lI1lIIl = invalid or _lI1lIIl.body = "" then return invalid
_ll1lIIl = _lI1lIIl.finalUrl
if _ll1lIIl = invalid or _ll1lIIl = "" then _ll1lIIl = _lIllIIl
return RP_ResolveJwplayerPage(_lI1lIIl.body, _ll1lIIl, _ll1lIIl, _l1IlIIl)
end function
function RP_Resolve2embed(_lllIll1 as String, _llll1l1 as String, _l1ll1l1 as Object) as Object
if ((10468 - 2617 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lI1Ill1 = {}
if _llll1l1 <> "" then _lI1Ill1[_l1d_55a757("6555575b516157", 247, 192)] = _llll1l1 else _lI1Ill1[_l1d_55a757("cb05050bf711fd", 90, 195)] = _l1d_55a757("02e9ecf3f3bfcdd01a0c14091d2920e91818f1", 183, 35)
_lIIIll1 = HC_Get(_l1ll1l1, _lllIll1, _lI1Ill1, 8000)
if _lIIIll1 = invalid or _lIIIll1.body = "" then return invalid
_ll1Ill1 = _lIIIll1.finalUrl
if _ll1Ill1 = invalid or _ll1Ill1 = "" then _ll1Ill1 = _lllIll1
_lI1l1l1 = CreateObject(_l1d_55a757("4e6c746c6d726a", 51, 13), _l1d_55a757("ef01073c44524a016264585c6e70641d2c95", 172, 107) + chr(34) + _l1d_55a757("69c676b9a8abaaaa79798f92b9c3c0d8d7e6cbcfe1d406b79ef601f7ff031ecf0508d7fe051e07253cdc3b43", 179, 213) + chr(34) + _l1d_55a757("bcc5b6b7cc", 152, 253) + chr(34) + _l1d_55a757("733c", 125, 25), _l1d_55a757("61", 153, 113))
_lIll1l1 = _lI1l1l1.match(_lIIIll1.body)
_llIl1l1 = ""
if _lIll1l1 <> invalid and _lIll1l1.Count() >= 2 then
_llIl1l1 = _lIll1l1[1]
else
_l1lIll1 = CreateObject(_l1d_55a757("bfdda5dddee3db", 211, 30), _l1d_55a757("72352c2f36366d75838645474c5c635a575b6d603aabaa7a7583838752c39194cb8a899a93a170d077777ca8", 223, 123) + chr(34) + _l1d_55a757("ddd5da7cf5f6", 212, 234), _l1d_55a757("83", 218, 208))
_l11Ill1 = _l1lIll1.match(_lIIIll1.body)
if _l11Ill1 <> invalid and _l11Ill1.Count() >= 2 then _llIl1l1 = _l11Ill1[1]
end if
if _llIl1l1 = "" then return invalid
_llIl1l1 = U_HtmlDecode(_llIl1l1)
_ll1l1l1 = HC_Get(_l1ll1l1, _llIl1l1, { "Referer": _ll1Ill1 }, 8000)
if _ll1l1l1 = invalid or _ll1l1l1.body = "" then return invalid
_l11l1l1 = _ll1l1l1.finalUrl
if _l11l1l1 = invalid or _l11l1l1 = "" then _l11l1l1 = _llIl1l1
_llIIll1 = CreateObject(_l1d_55a757("180efe0a0f1030", 5, 161), _l1d_55a757("6ca4a8bfb5acb7a4a285ab80dbddd19abf", 142, 186) + chr(34) + _l1d_55a757("26c33bcbcb", 215, 54) + chr(34) + _l1d_55a757("d37cd5d68b", 205, 233) + chr(34) + _l1d_55a757("214e", 11, 245), _l1d_55a757("00", 146, 5))
_lIlIll1 = _llIIll1.match(_ll1l1l1.body)
if _lIlIll1 = invalid or _lIlIll1.Count() < 2 then return invalid
_l1IIll1 = _lIlIll1[1]
_l1Il1l1 = ""
if Left(_l1IIll1, 4) = _l1d_55a757("455c5f66", 12, 225) then
_l1Il1l1 = _l1IIll1
else
_l1Il1l1 = _l1d_55a757("8180838288c2dadd9da3a6a5aaafa9afbeeefdb5c0c1c90dd613", 120, 113) + _l1IIll1
end if
return RP_ResolveLookmovie(_l1Il1l1, _l11l1l1, _l1ll1l1)
end function
function RP_ResolveCloudnestra(_lll1Il1 as String, _l11ll11 as String, _lll1l11 as Object) as Object
_lI1ll11 = _l11ll11
if _lI1ll11 = "" then _lI1ll11 = _lll1Il1
_lIlIIl1 = HC_Get(_lll1l11, _lll1Il1, { "Referer": _lI1ll11 }, 8000)
if _lIlIIl1 = invalid or _lIlIIl1.body = "" then return invalid
_ll11Il1 = _lIlIIl1.finalUrl
if _ll11Il1 = invalid or _ll11Il1 = "" then _ll11Il1 = _lll1Il1
_lIlll11 = CreateObject(_l1d_55a757("9a98c094999ab2", 33, 71), _l1d_55a757("b4b8aa76dfc36fe1", 171, 220) + chr(34) + _l1d_55a757("b926b4ba121303190d21cf3e44", 170, 44) + chr(34) + _l1d_55a757("9724919627", 219, 155) + chr(34) + _l1d_55a757("7c45", 252, 161), _l1d_55a757("76", 60, 33))
m = _lIlll11.match(_lIlIIl1.body)
if m = invalid or m.Count() < 2 then
_ll1ll11 = CreateObject(_l1d_55a757("dbf301eff4f5f3", 180, 21), _l1d_55a757("69", 239, 181) + chr(34) + _l1d_55a757("9ca59a9ed9dee6e4f8e8b2c9c7", 156, 225) + chr(34) + _l1d_55a757("88e19293e8", 176, 241) + chr(34) + _l1d_55a757("9cb5", 21, 106), _l1d_55a757("a6", 189, 210))
m = _ll1ll11.match(_lIlIIl1.body)
if m = invalid or m.Count() < 2 then return RP_ResolveGeneric(_lll1Il1, _l11ll11, _lll1l11)
end if
_lllll11 = m[1]
if Left(_lllll11, 1) <> _l1d_55a757("0f", 111, 207) then _lllll11 = _l1d_55a757("23", 150, 106) + _lllll11
_l1IIIl1 = RP_AbsUrl(_lllll11, _ll11Il1)
_ll1IIl1 = HC_Get(_lll1l11, _l1IIIl1, { "Referer": _ll11Il1 }, 8000)
if _ll1IIl1 = invalid or _ll1IIl1.body = "" then return invalid
_l111Il1 = _ll1IIl1.finalUrl
if _l111Il1 = invalid or _l111Il1 = "" then _l111Il1 = _l1IIIl1
_lIl1Il1 = CreateObject(_l1d_55a757("1101f70d121319", 200, 87), _l1d_55a757("c7c3c3cd9fbcec98", 13, 92) + chr(34) + _l1d_55a757("18eaf0", 250, 70) + chr(34) + _l1d_55a757("730c0d", 165, 123) + chr(34), _l1d_55a757("63", 88, 50))
_lI11Il1 = _lIl1Il1.match(_ll1IIl1.body)
if _lI11Il1 = invalid or _lI11Il1.Count() < 2 then return invalid
_l1l1Il1 = _lI11Il1[1]
_lllIIl1 = CreateObject(_l1d_55a757("8a82b07e8384a2", 228, 244), chr(34) + _l1d_55a757("f00f1211114d434648271126302d711162102d6c3a8775847a7e317e38893754936149969b", 203, 77) + chr(34), _l1d_55a757("dae3", 28, 101))
_lII1Il1 = _lllIIl1.matchAll(_ll1IIl1.body)
_l1lIIl1 = []
_lIIll11 = {}
if _lII1Il1 <> invalid then
for each _l1I1Il1 in _lII1Il1
if _l1I1Il1.Count() < 2 then continue for
_llI1Il1 = _l1I1Il1[1]
if _lIIll11.DoesExist(_llI1Il1) then continue for
_lIIll11[_llI1Il1] = true
_l1lIIl1.Push(_llI1Il1)
end for
end if
if _l1lIIl1.Count() = 0 then _l1lIIl1.Push(_l1d_55a757("473348504d937f474749665852685c5868757d7a706c708a7cb8807f84", 202, 137))
_l1lll11 = []
_l1l1l11 = CreateObject(_l1d_55a757("4b513161626757", 159, 94), _l1d_55a757("b1c580c7cfc0d48f", 3, 82), _l1d_55a757("45", 42, 2))
_lI1IIl1 = _l1l1l11.split(_l1l1Il1)
if _lI1IIl1 <> invalid then
for each _l11IIl1 in _lI1IIl1
_ll11l11 = U_Trim(_l11IIl1)
if _ll11l11 <> "" then _l1lll11.Push(_ll11l11)
end for
end if
_l1IlIl1 = []
_llIIIl1 = CreateObject(_l1d_55a757("919fb7abb0b199", 57, 70), _l1d_55a757("bfa59bc8b381d1b5", 54, 85), _l1d_55a757("db", 69, 185))
for each _lIIIIl1 in _l1lll11
if Instr(1, _lIIIIl1, _l1d_55a757("3d4d", 43, 237)) > 0 then
for each _llI1Il1 in _l1lIIl1
_lIIlIl1 = Instr(1, _llI1Il1, _l1d_55a757("ff", 214, 7))
if _lIIlIl1 > 0 and _lIIlIl1 < Len(_llI1Il1) then
_lIl1l11 = Mid(_llI1Il1, _lIIlIl1 + 1)
else
_lIl1l11 = _llI1Il1
end if
_l1IlIl1.Push(_llIIIl1.replaceAll(_lIIIIl1, _lIl1l11))
end for
else
_l1IlIl1.Push(_lIIIIl1)
end if
end for
_l1Ill11 = {}
for each _l111l11 in _l1IlIl1
if _l111l11 = "" or _l1Ill11.DoesExist(_l111l11) then continue for
_l1Ill11[_l111l11] = true
_llIll11 = HC_Get(_lll1l11, _l111l11, { "Referer": _l111Il1 }, 6000)
if _llIll11 = invalid or _llIll11.body = "" then continue for
if Left(_llIll11.body, 7) <> _l1d_55a757("3f202017313e1f", 119, 235) then continue for
return {
url: _l111l11
streamFormat: _l1d_55a757("f8f703", 231, 105)
qualities: []
subtitles: RP_ExtractSubs(_ll1IIl1.body)
chapters: []
referer: _l111Il1
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidsrcXyz(_llIIl11 as String, _ll1l111 as String, _llIl111 as Object) as Object
_l11l111 = _ll1l111
if _l11l111 = "" then _l11l111 = _l1d_55a757("352427262672888b374f4f3b3f51a16167a9", 243, 154)
_lIIIl11 = HC_Get(_llIl111, _llIIl11, { "Referer": _l11l111 }, 8000)
if _lIIIl11 = invalid or _lIIIl11.body = "" then return invalid
_l1IIl11 = _lIIIl11.finalUrl
if _l1IIl11 = invalid or _l1IIl11 = "" then _l1IIl11 = _llIIl11
_l1ll111 = CreateObject(_l1d_55a757("374f5d4b50514f", 52, 241), _l1d_55a757("558391a094939e838b6e925fa4b47e9b", 139, 158) + chr(34) + _l1d_55a757("a19a727167827183b17e808f7f8e89c2", 97, 91) + chr(34) + _l1d_55a757("be37403ee143dc27291df25b", 164, 59) + chr(34) + _l1d_55a757("1b08180810", 235, 79) + chr(34) + _l1d_55a757("766f808176", 224, 175) + chr(34) + _l1d_55a757("adb6", 153, 239), _l1d_55a757("40", 74, 29))
m = _l1ll111.match(_lIIIl11.body)
if m = invalid or m.Count() < 2 then
_lIll111 = CreateObject(_l1d_55a757("1f3f053b404137", 208, 125), _l1d_55a757("dadef095fe", 61, 140) + chr(34) + _l1d_55a757("a2af9fa3a6b5bd", 155, 230) + chr(34) + _l1d_55a757("cefbcf1b131532241d2b4040453b2422", 14, 165) + chr(34) + _l1d_55a757("268f202196", 40, 23) + chr(34) + _l1d_55a757("4c59", 26, 15), _l1d_55a757("13", 78, 236))
m = _lIll111.match(_lIIIl11.body)
end if
if m <> invalid and m.Count() >= 2 then
_llll111 = RP_AbsUrl(m[1], _l1IIl11)
_lI1l111 = RP_ResolveCloudnestra(_llll111, _l1IIl11, _llIl111)
if _lI1l111 <> invalid and _lI1l111.url <> "" then return _lI1l111
end if
_lI1Il11 = R_FollowKnownIframes(_lIIIl11.body, _l1IIl11, _l11l111, 0, _llIl111)
if _lI1Il11 <> invalid and _lI1Il11.url <> invalid and _lI1Il11.url <> "" then return _lI1Il11
return RP_ResolveGeneric(_llIIl11, _ll1l111, _llIl111)
end function
function RP_ResolveMoviesapi(_l111I11 as String, _l1I1I11 as String, _lllII11 as Object) as Object
_lII1I11 = _l1I1I11
if _lII1I11 = "" then _lII1I11 = _l1d_55a757("fef5f8ff05bfcfd2160a20192b252ce92826f3", 188, 42)
_llI1I11 = HC_Get(_lllII11, _l111I11, { "Referer": _lII1I11 }, 8000)
if _llI1I11 = invalid or _llI1I11.body = "" then return invalid
_lI11I11 = _llI1I11.finalUrl
if _lI11I11 = invalid or _lI11I11 = "" then _lI11I11 = _l111I11
_ll11I11 = R_FollowKnownIframes(_llI1I11.body, _lI11I11, _lII1I11, 0, _lllII11)
if _ll11I11 <> invalid and _ll11I11.url <> invalid and _ll11I11.url <> "" then return _ll11I11
return RP_ResolveJwplayerPage(_llI1I11.body, _lI11I11, _lII1I11, _lllII11)
end function
function RP_ResolveAutoembed(_l11l1I1 as String, _ll111I1 as String, _l1I11I1 as Object) as Object
_l1ll1I1 = _l1d_55a757("d7bec1c8cc98a6a9ede5e5dcf0f1fffd0307f004090d13061e1be3212829ee", 53, 122)
_l1l11I1 = CreateObject(_l1d_55a757("3b31612d323353", 37, 228), _l1d_55a757("8ec7d2d2d0d2a0a4e4e9f3f1e802fd02c0c1c50c0ffa05d7230611e3e4e6f8feeef2212cfeff0004333e10111425", 4, 99), _l1d_55a757("c9", 192, 32))
m = _l1l11I1.match(_l11l1I1)
if m = invalid or m.Count() < 3 then return invalid
_lll11I1 = m[1]
_lIIl1I1 = m[2]
_llI11I1 = ""
_llIl1I1 = ""
if m.Count() >= 5 then
_llI11I1 = m[3]
_llIl1I1 = m[4]
end if
_l1Il1I1 = _l1d_55a757("e600fc05", 245, 101)
if Left(_lIIl1I1, 2) = _l1d_55a757("f5f8", 156, 13) then _l1Il1I1 = _l1d_55a757("4a49454a", 87, 12)
_lIll1I1 = _l1d_55a757("72696c7373afbdc07f8186969d94a0a696ace29db5a9b0bea9c0b6fdbcbc05d6cad412d3ded90d", 127, 91) + _l1Il1I1 + _l1d_55a757("16", 220, 53) + U_UrlEncode(_lIIl1I1) + _l1d_55a757("80d1d1dbcb96", 140, 214) + _lll11I1
if _lll11I1 = _l1d_55a757("3e43", 12, 198) and _llI11I1 <> "" and _llIl1I1 <> "" then
_lIll1I1 = _lIll1I1 + _l1d_55a757("ae5c7170658488b8", 241, 215) + _llI11I1 + _l1d_55a757("66acc2aec7aebabe89", 174, 222) + _llIl1I1
end if
_l1111I1 = HC_Get(_l1I11I1, _lIll1I1, {
"Referer": _l1ll1I1
"Origin": _l1d_55a757("3e2d302f35ff171a5c564c4b61626e667278617378767a6d8784528a999a", 144, 70)
}, 8000)
if _l1111I1 = invalid or _l1111I1.body = "" then return invalid
_lI1l1I1 = ParseJSON(_l1111I1.body)
if _lI1l1I1 = invalid or type(_lI1l1I1) <> _l1d_55a757("7f7d92878a898089849c92a494b3a9ac9cb7", 225, 236) then return invalid
_lI111I1 = ""
if _lI1l1I1.status_code <> invalid then _lI111I1 = _lI1l1I1.status_code.ToStr()
if _lI111I1 <> _l1d_55a757("2e2f32", 125, 223) then return invalid
_ll1l1I1 = _lI1l1I1.data
if _ll1l1I1 = invalid or type(_ll1l1I1) <> _l1d_55a757("1232471c1f3e353e392f473749683c3f514c", 240, 144) then return invalid
_lII11I1 = _ll1l1I1.stream_urls
if _lII11I1 = invalid or type(_lII11I1) <> _l1d_55a757("3f2754484b3d48", 172, 97) or _lII11I1.Count() = 0 then return invalid
for each _lllI1I1 in _lII11I1
if type(_lllI1I1) <> _l1d_55a757("c39fa8c2c2be", 116, 156) and type(_lllI1I1) <> _l1d_55a757("d3ebfadadffdf9f5", 182, 15) then continue for
if _lllI1I1 = "" then continue for
_lIl11I1 = HC_Get(_l1I11I1, _lllI1I1, { "Referer": _l1ll1I1 }, 6000)
if _lIl11I1 = invalid or _lIl11I1.body = "" then continue for
if Left(_lIl11I1.body, 7) <> _l1d_55a757("aa0bfb020ca90a", 191, 14) then continue for
return {
url: _lllI1I1
streamFormat: _l1d_55a757("b3b2d2", 45, 110)
qualities: []
subtitles: []
chapters: []
referer: _l1ll1I1
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveYthd(_lII1II1 as String, _l1IIII1 as String, _lIIIII1 as Object) as Object
_l1lIII1 = {}
if _l1IIII1 <> "" then _l1lIII1[_l1d_55a757("5e7278788a7e90", 201, 195)] = _l1IIII1
_l11III1 = HC_Get(_lIIIII1, _lII1II1, _l1lIII1, 8000)
if _l11III1 = invalid or _l11III1.body = "" then return invalid
_lIlIII1 = CreateObject(_l1d_55a757("dfe5c5f1f6f7e7", 157, 240), _l1d_55a757("122929242b1f0740342b414843", 86, 236) + chr(34) + _l1d_55a757("dfff3a0509fb50", 69, 198) + chr(34) + _l1d_55a757("d9dcd88e94e8", 192, 234) + chr(34) + _l1d_55a757("d300050ab2c4ba1618e8f0", 243, 37) + chr(34) + _l1d_55a757("c57e7f", 53, 93) + chr(34), _l1d_55a757("e8", 202, 69))
_ll1III1 = _lIlIII1.match(_l11III1.body)
if _ll1III1 <> invalid and _ll1III1.Count() >= 3 then
_lI1III1 = _l1d_55a757("e5eceff6f6423033", 231, 86) + _ll1III1[1] + _l1d_55a757("57ff110763", 243, 123) + _ll1III1[2]
return RP_ResolveCloudnestra(_lI1III1, _lII1II1, _lIIIII1)
end if
_llIIII1 = CreateObject(_l1d_55a757("e6fe0cfaff00fe", 52, 160), _l1d_55a757("f6fcec02c9110bfc1ac8", 55, 163) + chr(34) + _l1d_55a757("a01614", 36, 148) + chr(34) + _l1d_55a757("aadbdc", 240, 253) + chr(34), _l1d_55a757("de", 246, 63))
m = _llIIII1.match(_l11III1.body)
if m = invalid or m.Count() < 2 then return invalid
_lllIII1 = m[1]
_lI1III1 = _l1d_55a757("b1989ba2a4eefe01c0c8cab7c9d3c1d5e1d9ceced3e9edf1dbf539f9000546f408fc52", 214, 243) + _lllIII1
return RP_ResolveCloudnestra(_lI1III1, _lII1II1, _lIIIII1)
end function
function RP_ResolveVidking(_llIl1lI as String, _l1l11lI as String, _l1111lI as Object) as Object
if ((20445 - 6815 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lll11lI = CreateObject(_l1d_55a757("fdebe3fbfc0109", 203, 68), _l1d_55a757("064f4a54585c18165c615d61705c676c3039374e8941778285609b535458505066647bb66e6f78768dc88081847d", 153, 80), _l1d_55a757("55", 152, 100))
m = _lll11lI.match(_llIl1lI)
if m = invalid or m.Count() < 3 then return invalid
_lIIl1lI = m[1]
_lI111lI = m[2]
_lIl11lI = ""
_l1Il1lI = ""
if m.Count() >= 5 then
_lIl11lI = m[3]
_l1Il1lI = m[4]
end if
_ll111lI# = B_StrToLong(_lI111lI)
return RP_VideasyFamilyResolve(_lIIl1lI, _lI111lI, _lIl11lI, _l1Il1lI, _ll111lI#, _lI111lI, _l1111lI)
end function
function RP_ResolveVideasy(_l11IIlI as String, _lIIIIlI as String, _lIlll1I as Object) as Object
if ((49818 - 8303 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1IIIlI = CreateObject(_l1d_55a757("dfcd05d9dedfe7", 233, 68), _l1d_55a757("312df5faf4fa09f3fe0349524e25205a5b5d57556d69403b75767f7b524d87888b84", 248, 90), _l1d_55a757("80", 39, 50))
m = _l1IIIlI.match(_l11IIlI)
if m = invalid or m.Count() < 3 then return invalid
_llIIIlI = m[1]
_ll1ll1I = m[2]
_lllll1I = ""
_lI1IIlI = ""
if m.Count() >= 5 then
_lllll1I = m[3]
_lI1IIlI = m[4]
end if
_l1lll1I# = B_StrToLong(_ll1ll1I)
return RP_VideasyFamilyResolve(_llIIIlI, _ll1ll1I, _lllll1I, _lI1IIlI, _l1lll1I#, _ll1ll1I, _lIlll1I)
end function
function RP_VideasyFamilyResolve(_llI111I as String, _lIl1I1I as String, _llllI1I as String, _l11111I as String, _l1llI1I as LongInteger, _lIllI1I as String, _ll1lI1I as Object) as Object
if ((5185 - 1037 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1lI11I = _l1d_55a757("e6fd00070b473538020b421d0911131a2f285a331f628168", 205, 65) + _llI111I + _l1d_55a757("86", 114, 41) + _lIl1I1I + _l1d_55a757("84293b3e36423b39514f42584e5f5f61636b60bb667c7b6f7f7e748278858395", 64, 5)
_lllI11I = HC_Get(_ll1lI1I, _l1lI11I, {}, 6000)
_l1l1I1I = ""
_l111I1I = ""
_lI1111I = ""
if _lllI11I <> invalid and _lllI11I.body <> "" then
_lII111I = ParseJSON(_lllI11I.body)
if type(_lII111I) = _l1d_55a757("bdd5b6c7cae1e0ede8d6f6daf0d7e7ea00fb", 150, 217) then
if _llI111I = _l1d_55a757("5156705e65", 12, 240) and _lII111I.title <> invalid then _l1l1I1I = _lII111I.title
if _llI111I = _l1d_55a757("abb0", 68, 123) and _lII111I.name <> invalid then _l1l1I1I = _lII111I.name
if _llI111I = _l1d_55a757("d5dac6e2d9", 117, 189) and _lII111I.release_date <> invalid then _l111I1I = Left(_lII111I.release_date, 4)
if _llI111I = _l1d_55a757("f9fe", 125, 240) and _lII111I.first_air_date <> invalid then _l111I1I = Left(_lII111I.first_air_date, 4)
if _lII111I.external_ids <> invalid and type(_lII111I.external_ids) = _l1d_55a757("1f07f8292c13221f2a38283c3219494c424d", 206, 99) then
if _lII111I.external_ids.imdb_id <> invalid then _lI1111I = _lII111I.external_ids.imdb_id
end if
end if
end if
_llII11I = [_l1d_55a757("eff7b501fafaec", 152, 250), _l1d_55a757("3f413a", 95, 3), _l1d_55a757("d8e4efebecf0e5edef01c4", 129, 243)]
_lIl111I = {
"Referer": _l1d_55a757("7c8b8e8d8dd9cfd29c9b91ac9ba9e8b3ababadacbdca00cdc508", 195, 209)
"Origin": _l1d_55a757("b5c4c7c6c8120a0dd5d4cce7d6e221ece6e4e8e7f805390600", 98, 171)
"Accept": _l1d_55a757("dae0e0", 73, 119)
}
for each _lI1I11I in _llII11I
_ll11I1I = _l1d_55a757("3d3c3f3e3e7a90935c505aa05b637375746562b8757dc0", 123, 42) + _lI1I11I + _l1d_55a757("25f4ebf8fef0f1063f080911104e1a18201b156e2c2a322d2782", 231, 93) + U_UrlEncode(_l1l1I1I) + _l1d_55a757("65312c303e39295753419c", 199, 132) + _llI111I + _l1d_55a757("b45e7d7c6cae", 218, 184) + U_UrlEncode(_l111I1I)
if _llI111I = _l1d_55a757("f3f4", 246, 113) then
_ll1111I = _l1d_55a757("d9", 157, 45)
_l11lI1I = _l1d_55a757("b1", 187, 39)
if _l11111I <> "" then _ll1111I = _l11111I
if _llllI1I <> "" then _l11lI1I = _llllI1I
_ll11I1I = _ll11I1I + _l1d_55a757("04465c58655c5458475d39", 4, 226) + _ll1111I + _l1d_55a757("55a39c9bac9b9f7faf79", 139, 168) + _l11lI1I
end if
_ll11I1I = _ll11I1I + _l1d_55a757("7aabb5c1c2daca74", 185, 219) + _lIl1I1I + _l1d_55a757("ca9695919ac29af4", 229, 7) + U_UrlEncode(_lI1111I)
_l1II11I = HC_Get(_ll1lI1I, _ll11I1I, _lIl111I, 8000)
if _l1II11I = invalid or _l1II11I.body = "" then continue for
_l11I11I = RP_VideasyDecrypt(U_Trim(_l1II11I.body), _l1llI1I)
if _l11I11I = "" then continue for
_ll1I11I = ParseJSON(_l11I11I)
if _ll1I11I = invalid or type(_ll1I11I) <> _l1d_55a757("00e8190a0df403000b19091d133a2a2d232e", 110, 228) then continue for
_lI1lI1I = _ll1I11I.sources
if _lI1lI1I = invalid or type(_lI1lI1I) <> _l1d_55a757("36546d3f425651", 115, 53) or _lI1lI1I.Count() = 0 then continue for
_l1IlI1I = ""
for each _llIlI1I in _lI1lI1I
if type(_llIlI1I) <> _l1d_55a757("676d9e6f7279888590808e8498bf9194a893", 63, 26) then continue for
if _llIlI1I.url <> invalid and _llIlI1I.url <> "" then
_l1IlI1I = _llIlI1I.url
exit for
end if
if _llIlI1I.file <> invalid and _llIlI1I.file <> "" then
_l1IlI1I = _llIlI1I.file
exit for
end if
end for
if _l1IlI1I = "" then continue for
_lIIlI1I = []
if _ll1I11I.subtitles <> invalid and type(_ll1I11I.subtitles) = _l1d_55a757("fcfa0f0508f813", 225, 105) then
for each _lIII11I in _ll1I11I.subtitles
if type(_lIII11I) <> _l1d_55a757("b9cfacc1c4dbdae3deceecd6e6cde3e6f6f1", 85, 146) then continue for
_lll1I1I = ""
if _lIII11I.url <> invalid then _lll1I1I = _lIII11I.url
if _lll1I1I = "" and _lIII11I.file <> invalid then _lll1I1I = _lIII11I.file
if _lll1I1I = "" then continue for
_l1I111I = _l1d_55a757("0f1b", 180, 62)
if _lIII11I.language <> invalid then _l1I111I = LCase(Left(_lIII11I.language, 2))
if _l1I111I = "" and _lIII11I.lang <> invalid then _l1I111I = LCase(Left(_lIII11I.lang, 2))
_lIlI11I = ""
if _lIII11I.label <> invalid then _lIlI11I = _lIII11I.label
if _lIlI11I = "" then _lIlI11I = UCase(_l1I111I)
_lIIlI1I.Push({ url: _lll1I1I, language: _l1I111I, name: _lIlI11I })
end for
end if
return {
url: _l1IlI1I
streamFormat: U_StreamFormat(_l1IlI1I)
qualities: []
subtitles: _lIIlI1I
chapters: []
referer: _l1d_55a757("777679787e38505387969e89a89867a2a8b6bab9aea77fc2ccbe8c", 24, 7)
userAgent: ""
}
end for
return invalid
end function
function RP_VideasyDecrypt(_llIllII as String, _llIIlII as LongInteger) as String
if ((46008 - 5112 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _llIllII = invalid or _llIllII = "" then return ""
_l11llII = CreateObject(_l1d_55a757("47677d5b596d8c5c5f7570", 50, 7))
_l11llII.FromHexString(_llIllII)
if _l11llII.Count() = 0 then return ""
_lI11lII = RP_VkLcgBytes(_llIIlII, 50)
_l1I1lII = RP_VkSerializeBytes(_lI11lII)
_llI1lII = CreateObject(_l1d_55a757("f0f0c60402f6d50508fe19", 2, 128))
_llI1lII.FromAsciiString(_l1I1lII)
_l111lII = _l1d_55a757("202724282a78307e3689383d4341484c4d51545859595f5e666a686d747678cc7e80848c8ade9094969a9b9ba1a0a4a8aaaf04b5bf0dc5c0cc15c8cdce27d4d9e0dce4eceaeaefef41f449fc0256", 51, 25)
_ll11lII = CreateObject(_l1d_55a757("75634b738375548a8d7d88", 9, 250))
_ll11lII.FromHexString(_l111lII)
_ll1IlII = R4_KSA(_ll11lII)
_lIIllII = R4_PRGA(_ll1IlII, _llI1lII)
_l11IlII = R4_KSA(_lIIllII)
_l1IIlII = R4_PRGA(_l11IlII, _l11llII)
if _l1IIlII.Count() < 32 then return ""
if _l1IIlII[0] <> 83 or _l1IIlII[1] <> 97 or _l1IIlII[2] <> 108 or _l1IIlII[3] <> 116 then return ""
if _l1IIlII[4] <> 101 or _l1IIlII[5] <> 100 or _l1IIlII[6] <> 95 or _l1IIlII[7] <> 95 then return ""
_lI1IlII = B_Slice(_l1IIlII, 8, 16)
_lllllII = B_Slice(_l1IIlII, 16, _l1IIlII.Count())
_l1lIlII = CreateObject(_l1d_55a757("6d5b836b7b6d8c82857580", 169, 146))
_l1l1lII = EvpBytesToKey(_l1lIlII, _lI1IlII, 32)
if _l1l1lII.Count() < 32 then return ""
_lIl1lII = B_Slice(_l1l1lII, 0, 16)
_lll1lII = B_Slice(_l1l1lII, 16, 32)
_lIlllII = _lIl1lII.ToHexString()
_l1lllII = _lll1lII.ToHexString()
_ll1llII = CreateObject(_l1d_55a757("b29ac7d7e0d2afc9b4bcd0", 238, 22))
_lIlIlII = _ll1llII.Setup(false, _l1d_55a757("35342d8271757e8e4f5155", 116, 32), _lIlllII, _l1lllII, 1)
if _lIlIlII <> 0 then return ""
_lII1lII = CreateObject(_l1d_55a757("140c2a241a0e35292c1e39", 228, 126))
_lllIlII = _ll1llII.Process(_lllllII)
if _lllIlII <> invalid then
for _l1IllII = 0 to _lllIlII.Count() - 1
_lII1lII.Push(_lllIlII[_l1IllII])
end for
end if
_lI1llII = _ll1llII.Final()
if _lI1llII <> invalid then
for _l1IllII = 0 to _lI1llII.Count() - 1
_lII1lII.Push(_lI1llII[_l1IllII])
end for
end if
if _lII1lII.Count() = 0 then return ""
return _lII1lII.ToAsciiString()
end function
function RP_VkLcgBytes(_lIlI1II as LongInteger, _lII11II as Integer) as Object
_l1lI1II = CreateObject(_l1d_55a757("5d6b935b6b7d9c72758570", 185, 146))
_ll1I1II# = _lIlI1II AND 2147483647&
for _lllI1II = 1 to _lII11II
_ll1I1II# = (_ll1I1II# * 1103515245& + 12345&) AND 2147483647&
_l1I11II# = _ll1I1II# mod 255&
_l1lI1II.Push(_l1I11II#)
end for
return _l1lI1II
end function
function RP_VkSerializeBytes(_lI1llll as Object) as String
if ((52815 - 7545 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lI1llll = invalid or _lI1llll.Count() = 0 then return ""
_lIIllll = ""
_l1Illll = _lI1llll.Count()
for _llIllll = 0 to _l1Illll - 1
if _llIllll > 0 then _lIIllll = _lIIllll + _l1d_55a757("07", 113, 170)
_lIIllll = _lIIllll + _lI1llll[_llIllll].ToStr()
end for
return _lIIllll
end function
function RP_ResolvePeachify(_l11I1ll as String, _lll1Ill as String, _l111Ill as Object) as Object
_ll1lIll = CreateObject(_l1d_55a757("b5a5dbb5b6bbc1", 234, 29), _l1d_55a757("6060a8a9a3adbca6b1b27c818198d389c1cccfaae59ba0a29896aeaec500b6bbc0c0d712c8cdd0c5", 154, 171), _l1d_55a757("db", 44, 150))
m = _ll1lIll.match(_l11I1ll)
if m = invalid or m.Count() < 3 then return invalid
_lIII1ll = m[1]
_l1lIIll = m[2]
_ll11Ill = ""
_llII1ll = ""
if m.Count() >= 5 then
_ll11Ill = m[3]
_llII1ll = m[4]
end if
_lIIlIll = [
{ host: _l1d_55a757("444d3ef6404755015f4f565b531474667a", 44, 235),  path: _l1d_55a757("1b23252816", 121, 10) },
{ host: _l1d_55a757("d1d2d70fcdd4e21eecdce3e4f02dfdef03", 198, 30),  path: _l1d_55a757("9293ad9fa6aaa2ba", 46, 79) },
{ host: _l1d_55a757("5d5a4f0b59586e1a706867686429817387", 170, 126),  path: _l1d_55a757("b2cdb9d4c2", 141, 210) },
{ host: _l1d_55a757("58595e8854536b956d63626361a67c7082", 107, 58),  path: _l1d_55a757("ecf8ec", 63, 155) },
{ host: _l1d_55a757("01fe13e11d1c14ee162c2b2c3aff25392b", 51, 187),  path: _l1d_55a757("f2ed0b", 45, 166) }
]
_l1II1ll = {
"Referer": _l1d_55a757("b6cdd0d7d7938184e6d4dbdcdadce2f2a0fde507ab", 15, 79)
"Origin": _l1d_55a757("6a81848b91cbbbbe9a8a91968e929aa8d8b19fbb", 76, 70)
"Accept": _l1d_55a757("6e80837a827f808e8e8f91559ba79ea0", 164, 169)
}
for each _l1IlIll in _lIIlIll
_lIlIIll = _l1d_55a757("bbbabdbcbcf80e11", 123, 168) + _l1IlIll.host + _l1d_55a757("e3", 233, 29) + _l1IlIll.path + _l1d_55a757("97", 116, 60) + _lIII1ll + _l1d_55a757("26", 10, 1) + _l1lIIll
if _lIII1ll = _l1d_55a757("1a1f", 84, 250) and _ll11Ill <> "" and _llII1ll <> "" then
_lIlIIll = _lIlIIll + _l1d_55a757("39", 74, 212) + _ll11Ill + _l1d_55a757("4c", 172, 201) + _llII1ll
end if
_l1l1Ill = HC_Get(_l111Ill, _lIlIIll, _l1II1ll, 8000)
if _l1l1Ill = invalid or _l1l1Ill.body = "" then continue for
_lI1I1ll = ParseJSON(_l1l1Ill.body)
if _lI1I1ll = invalid or type(_lI1I1ll) <> _l1d_55a757("d5bbacdde0c7d6d3deeedcf2e6cdff02f601", 143, 216) then continue for
if _lI1I1ll.isEncrypted <> true then continue for
_ll1I1ll = _lI1I1ll.data
if _ll1I1ll = invalid or type(_ll1I1ll) <> _l1d_55a757("0d1332101921232d", 61, 190) then continue for
_llIlIll = RP_PeachifyDecrypt(_ll1I1ll)
if _llIlIll = "" then continue for
_l11lIll = ParseJSON(_llIlIll)
if _l11lIll = invalid or type(_l11lIll) <> _l1d_55a757("f10f28f9fc1b121f1a1228162a491b1e322d", 51, 176) then continue for
_lI11Ill = _l11lIll.sources
if _lI11Ill = invalid or type(_lI11Ill) <> _l1d_55a757("adc3e0b6b9c9c4", 245, 38) or _lI11Ill.Count() = 0 then continue for
_l1I1Ill = ""
for each _llI1Ill in _lI11Ill
if type(_llI1Ill) <> _l1d_55a757("3a48314245545b58635b615f735264677b66", 219, 145) then continue for
if _llI1Ill.url <> invalid and _llI1Ill.url <> "" then
_l1I1Ill = _llI1Ill.url
exit for
end if
if _llI1Ill.file <> invalid and _llI1Ill.file <> "" then
_l1I1Ill = _llI1Ill.file
exit for
end if
end for
if _l1I1Ill = "" then continue for
_lII1Ill = []
if _l11lIll.subtitles <> invalid and type(_l11lIll.subtitles) = _l1d_55a757("3d5b3046495954", 17, 218) then
for each _lIl1Ill in _l11lIll.subtitles
if type(_lIl1Ill) <> _l1d_55a757("b0b6e7b8bbc2d1ced9c9d7cde108daddf1dc", 255, 35) then continue for
_lllIIll = ""
if _lIl1Ill.url <> invalid then _lllIIll = _lIl1Ill.url
if _lllIIll = "" and _lIl1Ill.file <> invalid then _lllIIll = _lIl1Ill.file
if _lllIIll = "" then continue for
_llllIll = _l1d_55a757("e5ef", 3, 127)
if _lIl1Ill.language <> invalid then _llllIll = LCase(Left(_lIl1Ill.language, 2))
_lIllIll = ""
if _lIl1Ill.label <> invalid then _lIllIll = _lIl1Ill.label
if _lIllIll = "" then _lIllIll = UCase(_llllIll)
_lII1Ill.Push({ url: _lllIIll, language: _llllIll, name: _lIllIll })
end for
end if
_lI1lIll = U_StreamFormat(_l1I1Ill)
_l1llIll = LCase(_l1I1Ill)
if Instr(1, _l1llIll, _l1d_55a757("51a66fa7", 75, 43)) > 0 then
_lI1lIll = _l1d_55a757("1f260e", 81, 230)
else if Instr(1, _l1llIll, _l1d_55a757("cded2c", 205, 45)) > 0 then
_lI1lIll = _l1d_55a757("a1b7fe", 74, 122)
end if
return {
url: _l1I1Ill
streamFormat: _lI1lIll
qualities: []
subtitles: _lII1Ill
chapters: []
referer: _l1d_55a757("473639383e88a0a3475f5e636b6f6f65bd668468ca", 208, 143)
userAgent: ""
}
end for
return invalid
end function
function RP_PeachifyDecrypt(_lI11l1l as String) as String
if _lI11l1l = invalid or _lI11l1l = "" then return ""
_l111l1l = _lI11l1l.Tokenize(_l1d_55a757("9f", 138, 251))
if _l111l1l = invalid or _l111l1l.Count() < 3 then return ""
_lIl1l1l = HC_Base64UrlDecode(_l111l1l[0])
_l1l1l1l = HC_Base64UrlDecode(_l111l1l[1])
_l1I1l1l = HC_Base64UrlDecode(_l111l1l[2])
if _lIl1l1l.Count() <> 12 then return ""
if _l1I1l1l.Count() <> 16 then return ""
_ll11l1l = _l1d_55a757("133f144b1f52245427562f61616b66707041744b7e508358875b8a609165956ea376a87bad80b285b78abf8fc19ac69fcca4a9a9dfaee4b5ecbeeec1f3c8f9cf", 95, 213)
_llI1l1l = AGD_Decrypt(_ll11l1l, _lIl1l1l, _l1l1l1l, _l1I1l1l)
if _llI1l1l = invalid then return ""
return _llI1l1l.ToAsciiString()
end function
function RP_ResolvePrimesrc(_lIII11l as String, _llllI1l as String, _l1llI1l as Object) as Object
if ((24762 - 8254 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return invalid
end function
function RP_ResolveStreamtape(_lIlIlIl as String, _l11l1Il as String, _lI1l1Il as Object) as Object
if ((54684 - 6076 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l11IlIl = CreateObject(_l1d_55a757("2030063c414228", 216, 118), _l1d_55a757("4bfa0b1b095a5a0c19683402711d7a7a892e83368388", 194, 94), _l1d_55a757("6d", 187, 155))
_l1IIlIl = _l11IlIl.match(_lIlIlIl)
if _l1IIlIl = invalid or _l1IIlIl.Count() < 2 then return invalid
_l1lIlIl = _l1d_55a757("d3cacdd4da142427e6e2ebf900f7f109fb0b47170e0f541d5a", 124, 191) + _l1IIlIl[1]
_ll1IlIl = {}
if _l11l1Il <> "" then _ll1IlIl[_l1d_55a757("46606066726c78", 138, 110)] = _l11l1Il
_lIIIlIl = HC_Get(_lI1l1Il, _l1lIlIl, _ll1IlIl, 8000)
if _lIIIlIl = invalid or _lIIIlIl.body = "" then return invalid
_lII1lIl = _l1d_55a757("1b151c35202b234069353a4c603a46414c44616e5c6f5d94a270606666826d6d7171c0b9bd7f838694a0adccb8bae1f1e7ed", 234, 141)
_lI1IlIl = Instr(1, _lIIIlIl.body, _lII1lIl)
if _lI1IlIl <= 0 then return invalid
_llI1lIl = Mid(_lIIIlIl.body, _lI1IlIl + Len(_lII1lIl))
_lIll1Il = Instr(1, _llI1lIl, _l1d_55a757("b0", 255, 216))
if _lIll1Il <= 0 then return invalid
_llll1Il = Left(_llI1lIl, _lIll1Il - 1)
_lllIlIl = _l1d_55a757("d9d3dede94a0a6", 81, 95)
_llIIlIl = Instr(1, _llI1lIl, _lllIlIl)
if _llIIlIl <= 0 then return invalid
_l1I1lIl = Mid(_llI1lIl, _llIIlIl + Len(_lllIlIl))
_ll1l1Il = Instr(1, _l1I1lIl, _l1d_55a757("7b", 235, 175))
if _ll1l1Il <= 0 then return invalid
_l1ll1Il = Left(_l1I1lIl, _ll1l1Il - 1)
_llIl1Il = _l1d_55a757("e2f9fc0309c3", 12, 126) + _llll1Il + _l1ll1Il
return {
url: _llIl1Il
streamFormat: U_StreamFormat(_llIl1Il)
qualities: []
subtitles: []
chapters: []
referer: _l1d_55a757("9b8a8d8c905c72759ca2a3b7b6c5b1bfb3c997cddcdda2", 49, 66)
userAgent: ""
}
end function
function RP_ResolveUqload(_l11lIIl as String, _lIIlIIl as String, _lll1IIl as Object) as Object
_lI1lIIl = {}
if _lIIlIIl <> "" then _lI1lIIl[_l1d_55a757("594d535345594b", 185, 110)] = _lIIlIIl
_llIlIIl = HC_Get(_lll1IIl, _l11lIIl, _lI1lIIl, 8000)
if _llIlIIl = invalid or _llIlIIl.body = "" then return invalid
_l1IlIIl = CreateObject(_l1d_55a757("2b1911292a2f37", 75, 242), _l1d_55a757("a493acaca0a5b692bc66799ec872a7a9", 8, 41) + chr(34) + _l1d_55a757("03939b", 83, 136) + chr(34) + _l1d_55a757("ac8586", 141, 220) + chr(34), _l1d_55a757("67", 202, 196))
m = _l1IlIIl.match(_llIlIIl.body)
if m = invalid or m.Count() < 2 then return invalid
_l1l1IIl = m[1]
if Left(_l1l1IIl, 4) <> _l1d_55a757("e9080b0a", 201, 72) then return invalid
return {
url: _l1l1IIl
streamFormat: U_StreamFormat(_l1l1IIl)
qualities: []
subtitles: []
chapters: []
referer: _l1d_55a757("8e75787f7fcbd9dc8990a8a8a9a9f29ca3fa", 119, 111)
userAgent: ""
}
end function
function RP_ResolveDoodstream(_ll1Ill1 as String, _l1l11l1 as String, _lIl11l1 as Object) as Object
_llIIll1 = {}
if _l1l11l1 <> "" then _llIIll1[_l1d_55a757("c1939399ad9fb3", 238, 5)] = _l1l11l1
_ll1l1l1 = HC_Get(_lIl11l1, _ll1Ill1, _llIIll1, 8000)
if _ll1l1l1 = invalid or _ll1l1l1.body = "" then return invalid
_lI1Ill1 = _ll1l1l1.finalUrl
if _lI1Ill1 = invalid or _lI1Ill1 = "" then _lI1Ill1 = _ll1Ill1
if Instr(1, _ll1l1l1.body, _l1d_55a757("aedceee3e6cdfefaacc9", 21, 116)) <= 0 then return invalid
_lI1l1l1 = CreateObject(_l1d_55a757("3333593334394f", 162, 99), _l1d_55a757("dc1a2c21243b2c38eaf74e4e08", 61, 202) + chr(34) + _l1d_55a757("dfd4", 151, 21), _l1d_55a757("af", 169, 239))
_l11l1l1 = _lI1l1l1.match(_ll1l1l1.body)
if _l11l1l1 = invalid or _l11l1l1.Count() < 1 then return invalid
_llll1l1 = _l11l1l1[0]
_lIlIll1 = HC_OriginOf(_lI1Ill1)
if _lIlIll1 = "" then return invalid
_lIll1l1 = _lIlIll1 + _llll1l1
_lIIIll1 = 0
for _l1IIll1 = 1 to Len(_llll1l1)
if Mid(_llll1l1, _l1IIll1, 1) = _l1d_55a757("b5", 173, 51) then _lIIIll1 = _l1IIll1
end for
if _lIIIll1 = 0 or _lIIIll1 = Len(_llll1l1) then return invalid
_lI111l1 = Mid(_llll1l1, _lIIIll1 + 1)
_l1ll1l1 = HC_Get(_lIl11l1, _lIll1l1, { "Referer": _lI1Ill1 }, 8000)
if _l1ll1l1 = invalid or _l1ll1l1.body = "" then return invalid
_lll11l1 = RP_RandomB62String(10)
_l11Ill1 = RP_NowMillis()
_llI11l1 = _l1ll1l1.body + _lll11l1 + _l1d_55a757("ce18040b100ede", 141, 28) + _lI111l1 + _l1d_55a757("347a78738f778544", 182, 164) + _l11Ill1
_lIIl1l1 = ""
_ll111l1 = CreateObject(_l1d_55a757("7a686078797e86", 139, 129), _l1d_55a757("66313737424c7687575f8466949890a05e64646f79a3", 123, 31), _l1d_55a757("11", 239, 139))
_l1111l1 = _ll111l1.match(_ll1l1l1.body)
if _l1111l1 <> invalid and _l1111l1.Count() >= 2 then
_l1Il1l1 = CreateObject(_l1d_55a757("28164e22272830", 41, 205), _l1d_55a757("ff6e3955100a155f5f19", 167, 112), _l1d_55a757("6c", 182, 141))
_llIl1l1 = _l1Il1l1.match(_l1111l1[1])
if _llIl1l1 <> invalid and _llIl1l1.Count() >= 2 then _lIIl1l1 = _llIl1l1[1]
end if
return {
url: _llI11l1
streamFormat: U_StreamFormat(_llI11l1)
qualities: []
subtitles: []
chapters: []
referer: _lIlIll1 + _l1d_55a757("18", 163, 140)
userAgent: _l1d_55a757("d0b5a5b5bdc0c687808e839691f1d6e0e9e5e0dfb1120bbaacb0c1b6b2cc240913cecfc7e10cdddee4f0522629384257484a644545110a0b121e141c2924888a8993973a41807e839050b8999a959c5965c9a3a0aeafba776c727784798a7f908598ecdde7e3d9e1aaa3a4abb7adb5", 57, 92)
}
end function
function RP_RandomB62String(_ll11Il1 as Integer) as String
_lll1Il1 = _l1d_55a757("3f3f434347474b4b4f4f535357575b7b7f7f838387878b8b8f8f6d6d7171757579797d7d8181858589a9adadb1b1b5b5b9b9bdbd8a8e8e929296969a9a9e", 174, 80)
_l111Il1 = ""
for _l1l1Il1 = 1 to _ll11Il1
_lIl1Il1 = Rnd(62)
_l111Il1 = _l111Il1 + Mid(_lll1Il1, _lIl1Il1, 1)
end for
return _l111Il1
end function
function RP_NowMillis() as String
_l1IIl11 = CreateObject(_l1d_55a757("1a122e1624184a2a2924", 230, 134))
_l1IIl11.Mark()
_l1ll111 = _l1IIl11.AsSeconds()
_lIIIl11 = _l1IIl11.GetMilliseconds()
_llll111 = _lIIIl11.ToStr()
_llll111 = Right(_l1d_55a757("e9ecef", 71, 114) + _llll111, 3)
return _l1ll111.ToStr() + _llll111
end function
function RP_ResolveVoe(_lllII11 as String, _lIlllI1 as String, _l11llI1 as Object) as Object
if ((37472 - 4684 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_ll1II11 = {}
if _lIlllI1 <> "" then _ll1II11[_l1d_55a757("d8080a0e04140a", 159, 11)] = _lIlllI1
_ll1II11[_l1d_55a757("bedfd4e422b9e2e3eff8", 64, 169)] = _l1d_55a757("f1d2c8dedcdfdf2411291a2d38fefffbf802edf4482d1a5145475c4d576331322e595e6c7833686d8d876b3d40575364595d896e54ae9ba09fb9a9a7c0cbadb198b4b6d9d89fa7a8a1e7c5aaafbab902fcdecab3cbd0cb140505061f1025162b1c2f01f6f2fcec0a47343938524240", 118, 182)
_l1III11 = HC_Get(_l11llI1, _lllII11, _ll1II11, 8000)
if _l1III11 = invalid or _l1III11.body = "" then return invalid
_l11II11 = _l1III11.body
_l1lII11 = _l1III11.finalUrl
if _l1lII11 = invalid or _l1lII11 = "" then _l1lII11 = _lllII11
_l1lllI1 = CreateObject(_l1d_55a757("ed05d305060b09", 214, 73), _l1d_55a757("13f8020b0722fcd112161d1e361c25291aef2c493d432c54001438600c1a10444c264f20213239", 137, 21), _l1d_55a757("14", 113, 252))
_ll1llI1 = _l1lllI1.match(_l11II11)
if _ll1llI1 <> invalid and _ll1llI1.Count() >= 2 then
_llIllI1 = RP_AbsUrl(_ll1llI1[1], _l1lII11)
_llIII11 = HC_Get(_l11llI1, _llIllI1, _ll1II11, 8000)
if _llIII11 <> invalid and _llIII11.body <> "" then
_l11II11 = _llIII11.body
_l1lII11 = _llIII11.finalUrl
if _l1lII11 = invalid or _l1lII11 = "" then _l1lII11 = _llIllI1
end if
end if
_lI11I11 = CreateObject(_l1d_55a757("c2d2a8dee3e4ca", 216, 24), _l1d_55a757("c5fd10041c080f373fe242f321272339f4", 177, 56) + chr(34) + _l1d_55a757("bbcdd0bfbfc8cde3cbd0d296d4f0dfe1", 42, 112) + chr(34) + _l1d_55a757("9ca285ab978e9fb1b9dfbfc5c6b2aabbb1c3fa0dff0d070ec7", 154, 219), _l1d_55a757("ac", 144, 179))
_llI1I11 = _lI11I11.match(_l11II11)
if _llI1I11 = invalid or _llI1I11.Count() < 2 then return invalid
_lllllI1 = U_Trim(_llI1I11[1])
if Left(_lllllI1, 2) <> _l1d_55a757("f9", 102, 188) + chr(34) then return invalid
_lllllI1 = Mid(_lllllI1, 3)
_l1I1I11 = 0
for _lI1II11 = Len(_lllllI1) to 1 step -1
if Mid(_lllllI1, _lI1II11, 1) = _l1d_55a757("3f", 102, 4) then
_l1I1I11 = _lI1II11
exit for
end if
end for
if _l1I1I11 <= 1 then return invalid
_lllllI1 = Left(_lllllI1, _l1I1I11 - 1)
if Right(_lllllI1, 1) = chr(34) then _lllllI1 = Left(_lllllI1, Len(_lllllI1) - 1)
_lII1I11 = RP_VoeDecrypt(_lllllI1)
if _lII1I11 = "" then return invalid
_lIIII11 = ParseJSON(_lII1I11)
if _lIIII11 = invalid or type(_lIIII11) <> _l1d_55a757("2111362b2e1d241d283e264638574b4e404b", 232, 135) then return invalid
_lI1llI1 = ""
_lIlII11 = _l1d_55a757("fb0206", 163, 48)
if _lIIII11.source <> invalid and type(_lIIII11.source) = _l1d_55a757("cde5f4d0d9f3f3ef", 52, 135) then
_lI1llI1 = _lIIII11.source
_lIlII11 = _l1d_55a757("373624", 150, 57)
else if _lIIII11.direct_access_url <> invalid and type(_lIIII11.direct_access_url) = _l1d_55a757("7379587a7f8b8993", 223, 198) then
_lI1llI1 = _lIIII11.direct_access_url
_lIlII11 = _l1d_55a757("140c53", 89, 224)
end if
if _lI1llI1 = "" then return invalid
return {
url: _lI1llI1
streamFormat: _lIlII11
qualities: []
subtitles: []
chapters: []
referer: _l1lII11
userAgent: _ll1II11[_l1d_55a757("9cbdd2c290b7e0e1ddd6", 24, 79)]
}
end function
function RP_VoeDecrypt(_llIl1I1 as String) as String
if _llIl1I1 = invalid or _llIl1I1 = "" then return ""
_lIl11I1 = RP_VoeRot13(_llIl1I1)
_l1l11I1 = CreateObject(_l1d_55a757("81676777787d8d", 207, 196), _l1d_55a757("c9e8b30ef1f6f7fc1d22e726d00cf03215e63d3ee4e747eff7", 1, 136), _l1d_55a757("5e", 42, 17))
_lIl11I1 = _l1l11I1.replaceAll(_lIl11I1, _l1d_55a757("58", 50, 235))
_l1111I1 = CreateObject(_l1d_55a757("040cea181d1e0c", 156, 22), _l1d_55a757("23", 132, 72), _l1d_55a757("86", 71, 102))
_lIl11I1 = _l1111I1.replaceAll(_lIl11I1, "")
_l11l1I1 = CreateObject(_l1d_55a757("2a3a202a384c2b3f42543f", 216, 128))
_l11l1I1.FromBase64String(_lIl11I1)
_lll11I1 = _l11l1I1.Count()
if _lll11I1 = 0 then return ""
for _l1Il1I1 = 0 to _lll11I1 - 1
_lI111I1 = _l11l1I1[_l1Il1I1] - 3
if _lI111I1 < 0 then _lI111I1 = _lI111I1 + 256
_l11l1I1[_l1Il1I1] = _lI111I1
end for
_l1Il1I1 = 0
_lIIl1I1 = _lll11I1 - 1
while _l1Il1I1 < _lIIl1I1
_ll111I1 = _l11l1I1[_l1Il1I1]
_l11l1I1[_l1Il1I1] = _l11l1I1[_lIIl1I1]
_l11l1I1[_lIIl1I1] = _ll111I1
_l1Il1I1 = _l1Il1I1 + 1
_lIIl1I1 = _lIIl1I1 - 1
end while
_ll1l1I1 = _l11l1I1.ToAsciiString()
_lI1l1I1 = CreateObject(_l1d_55a757("dcccf2e0eee201f1f4eaf5", 170, 4))
_lI1l1I1.FromBase64String(_ll1l1I1)
if _lI1l1I1.Count() = 0 then return ""
return _lI1l1I1.ToAsciiString()
end function
function RP_VoeRot13(_l11III1 as String) as String
if _l11III1 = "" then return ""
_l1lIII1 = CreateObject(_l1d_55a757("ac9a82aabaac8bc1c4b4bf", 137, 177))
_l1lIII1.FromAsciiString(_l11III1)
for _ll1III1 = 0 to _l1lIII1.Count() - 1
_lIlIII1 = _l1lIII1[_ll1III1]
if _lIlIII1 >= 65 and _lIlIII1 <= 90 then
_l1lIII1[_ll1III1] = ((_lIlIII1 - 65 + 13) mod 26) + 65
else if _lIlIII1 >= 97 and _lIlIII1 <= 122 then
_l1lIII1[_ll1III1] = ((_lIlIII1 - 97 + 13) mod 26) + 97
end if
end for
return _l1lIII1.ToAsciiString()
end function
function RP_ResolveStreamsb(_l1l11lI as String, _lIlI1lI as String, _llII1lI as Object) as Object
if ((48056 - 6007 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lI111lI = CreateObject(_l1d_55a757("d7bdbdc9cecfdf", 205, 24), _l1d_55a757("1a0a12206926582c7570827e823c43475b944b857d546e575d547566797273", 157, 101), _l1d_55a757("4c", 240, 179))
_llI11lI = _lI111lI.match(_l1l11lI)
if _llI11lI = invalid or _llI11lI.Count() < 2 then return invalid
_l1111lI = _llI11lI[1]
_ll111lI = HC_HostOf(_l1l11lI)
if _ll111lI = "" then return invalid
_l1llIlI = _l1d_55a757("f22d441b38043427160b1f632c2f", 230, 110) + _l1111lI + _l1d_55a757("a6a9a7c49dae9cd4b1c9d9b1db15d0d3dde1e2f8f7f6ef01", 216, 2)
_lll11lI = CreateObject(_l1d_55a757("19214f1d23375e2e314732", 190, 77))
_lll11lI.FromAsciiString(_l1llIlI)
_lIl11lI = UCase(_lll11lI.ToHexString())
_lIIl1lI = _l1d_55a757("6352555454203639", 179, 136) + _ll111lI + _l1d_55a757("b39279969a8e8fa4e9e5d1", 78, 82) + _lIl11lI
_ll1I1lI = HC_Get(_llII1lI, _lIIl1lI, {
"Referer": _l1l11lI
"watchsb": _l1d_55a757("8b7f9197988c8b9a", 1, 25)
"Accept": _l1d_55a757("0afcff1e1e1b1c122a33357937234244", 240, 121)
}, 8000)
if _ll1I1lI = invalid or _ll1I1lI.body = "" then return invalid
_lllI1lI = ParseJSON(_ll1I1lI.body)
if _lllI1lI = invalid or type(_lllI1lI) <> _l1d_55a757("7391aa7b7e9d94a19c94aa98accb9da0b4af", 179, 178) then return invalid
_lI1I1lI = _lllI1lI.stream_data
if _lI1I1lI = invalid or type(_lI1I1lI) <> _l1d_55a757("7080657a7d8c938c978d9595a7869a9daf9a", 152, 134) then return invalid
_l1II1lI = ""
if _lI1I1lI.file <> invalid then _l1II1lI = U_Trim(_lI1I1lI.file)
if _l1II1lI = "" then return invalid
_lIII1lI = []
_l1lI1lI = _lI1I1lI.subs
if _l1lI1lI <> invalid and type(_l1lI1lI) = _l1d_55a757("351d0e3e413742", 14, 185) then
for each _l11I1lI in _l1lI1lI
if type(_l11I1lI) <> _l1d_55a757("1513ec1d201f16231e362c3a2e0d3f423651", 67, 228) then continue for
_llllIlI = _l11I1lI.file
if _llllIlI = invalid or _llllIlI = "" then continue for
_l1I11lI = ""
if _l11I1lI.label <> invalid then _l1I11lI = _l11I1lI.label
_lII11lI = _l1d_55a757("3f3b", 136, 82)
if _l1I11lI <> "" then _lII11lI = LCase(Left(_l1I11lI, 2))
_lIII1lI.Push({ url: _llllIlI, language: _lII11lI, name: _l1I11lI })
end for
end if
return {
url: _l1II1lI
streamFormat: _l1d_55a757("0a1129", 233, 137)
qualities: []
subtitles: _lIII1lI
chapters: []
referer: _l1l11lI
userAgent: ""
}
end function
function RP_ResolveMixdrop(_llIIIlI as String, _lIlll1I as String, _lI1ll1I as Object) as Object
if ((29403 - 9801 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1IIIlI = {}
if _lIlll1I <> "" then _l1IIIlI[_l1d_55a757("d1fd0303fd0903", 85, 202)] = _lIlll1I else _l1IIIlI[_l1d_55a757("f2bec4c4decae4", 165, 251)] = _l1d_55a757("50575a6161ad9b9e636a7e657a7082b7757cbf", 71, 33)
_l1IIIlI[_l1d_55a757("b3d4e9db27cef7f8f6ef", 217, 39)] = _l1d_55a757("290e0416141717e0c9e5d2e5f03a3737303e293000695209fdff1805131b6d6a6a151628306b2425453fa375788f8ba09199c5a68c6a535c5b7565637883e9e9d0ecee9190d7dfe4d99f01e2ebf6f5bab41a02ef070803d0bdc1cbdbc8e1cee7d4e73d2e2e34284203ecf5f40efefc", 52, 176)
_lllll1I = HC_Get(_lI1ll1I, _llIIIlI, _l1IIIlI, 8000)
if _lllll1I = invalid or _lllll1I.body = "" then return invalid
_ll1ll1I = CreateObject(_l1d_55a757("7e9ca4989d9e96", 241, 251), _l1d_55a757("d7a1b4a6b0aab18b91f49606fd0adacedcdaacb0dab6c0bd2d25d6e0e201f70dd6da04e0eae7574f5c52681f32242e282f6c", 88, 115), _l1d_55a757("fa", 86, 187))
_llIll1I = _ll1ll1I.match(_lllll1I.body)
if _llIll1I = invalid or _llIll1I.Count() < 2 then
_l11ll1I = CreateObject(_l1d_55a757("e5ed0bfdfe03f1", 62, 153), _l1d_55a757("ee3245394541481c24072b191021313b5f414546342a5f6b67867e965b65896b6f705e54b1a3b3b37f89ad8f93948278898191c8dbcfdbd7de97", 155, 71), _l1d_55a757("47", 47, 1))
_llIll1I = _l11ll1I.match(_lllll1I.body)
if _llIll1I = invalid or _llIll1I.Count() < 2 then return invalid
end if
_lIIIIlI = _llIll1I[1]
_ll11l1I = JU_UnpackPacked(_lIIIIlI)
if _ll11l1I = "" then return invalid
_l111l1I = CreateObject(_l1d_55a757("9f85c595969bab", 239, 2), _l1d_55a757("254c3c48241943444e633656321e42623e", 149, 79) + chr(34) + _l1d_55a757("54868c", 138, 178) + chr(34) + _l1d_55a757("0ac3c4", 52, 161) + chr(34), _l1d_55a757("4a", 240, 177))
_lIl1l1I = _l111l1I.match(_ll11l1I)
if _lIl1l1I = invalid or _lIl1l1I.Count() < 2 then return invalid
_l1lll1I = _lIl1l1I[1]
if Left(_l1lll1I, 2) = _l1d_55a757("5154", 21, 23) then
_lI11l1I = _l1d_55a757("a3a2a5a4aa64", 152, 179) + _l1lll1I
else if Left(_l1lll1I, 4) = _l1d_55a757("634a4d54", 53, 6) then
_lI11l1I = _l1lll1I
else
return invalid
end if
_lll1l1I = []
_lIIll1I = CreateObject(_l1d_55a757("1513fb13141931", 3, 164), _l1d_55a757("56452b415b90374d585d45594a4f5f7c56b0a68862bc", 112, 35) + chr(34) + _l1d_55a757("d9cfcd", 236, 21) + chr(34) + _l1d_55a757("297e83", 70, 14) + chr(34), _l1d_55a757("b5", 25, 69))
_l1Ill1I = _lIIll1I.match(_ll11l1I)
if _l1Ill1I <> invalid and _l1Ill1I.Count() >= 2 then
_l1l1l1I = _l1Ill1I[1]
if Left(_l1l1l1I, 2) = _l1d_55a757("575a", 56, 64) then _l1l1l1I = _l1d_55a757("140b0e151bd5", 188, 64) + _l1l1l1I
if Left(_l1l1l1I, 4) = _l1d_55a757("c9d0d3da", 229, 60) then
_lll1l1I.Push({ url: _l1l1l1I, language: _l1d_55a757("9fa7", 162, 216), name: _l1d_55a757("f217271c34223d392a", 16, 175) })
end if
end if
return {
url: _lI11l1I
streamFormat: U_StreamFormat(_lI11l1I)
qualities: []
subtitles: _lll1l1I
chapters: []
referer: _l1IIIlI[_l1d_55a757("72a4a4aa9eb0a4", 158, 166)]
userAgent: _l1IIIlI[_l1d_55a757("e1fef705c5dc0106101d", 131, 11)]
}
end function
function _l1d_55a757(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function