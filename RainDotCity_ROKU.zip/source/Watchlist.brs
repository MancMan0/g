function W_Section() as Object
_l1lI1ll = CreateObject(_l1d_acf7d9("66848c80858a777d7e86a398998fa5aeb2", 177, 163), _l1d_acf7d9("e9fdf8f6e3fb19ed0a2220fd0f30162139293e41", 143, 12))
_lllI1ll = CreateObject(_l1d_acf7d9("2a40503c414e3b39424a67545d4b696a6e", 181, 99), _l1d_acf7d9("1406fe1307232a3244250b162e1e3336", 47, 173))
if _lllI1ll.GetKeyList() <> invalid and _lllI1ll.GetKeyList().Count() > 0 then
for each _lII11ll in _lllI1ll.GetKeyList()
if not _l1lI1ll.Exists(_lII11ll) then _l1lI1ll.Write(_lII11ll, _lllI1ll.Read(_lII11ll))
end for
_l1lI1ll.Flush()
end if
return _l1lI1ll
end function
function W_ItemKey(_l1Ill1l as String, _llIll1l as String) as String
if _llIll1l <> invalid and _llIll1l <> "" then return _llIll1l
if _l1Ill1l <> invalid and _l1Ill1l <> "" then return _l1Ill1l
return ""
end function
function W_AsInt(_lI1I11l as Dynamic) as Integer
if _lI1I11l = invalid then return 0
_l11I11l = Type(_lI1I11l)
if _l11I11l = _l1d_acf7d9("de020f03040915", 194, 83) or _l11I11l = _l1d_acf7d9("92927397a4", 194, 226) or _l11I11l = _l1d_acf7d9("1a08e50f281a1f2032", 73, 223) then return _lI1I11l
if _l11I11l = _l1d_acf7d9("3861676472", 196, 182) or _l11I11l = _l1d_acf7d9("b3d3add6dcd1c7", 80, 145) or _l11I11l = _l1d_acf7d9("6d4b6454515d", 40, 1) or _l11I11l = _l1d_acf7d9("3d35113b483c4541", 134, 73) then return Int(_lI1I11l)
if _l11I11l = _l1d_acf7d9("21fd060000fc", 100, 234) or _l11I11l = _l1d_acf7d9("dece05e9ead4dce8", 168, 4) then return _lI1I11l.ToInt()
if _l11I11l = _l1d_acf7d9("f9dde1db08ead3e5eaebe5", 245, 64) or _l11I11l = _l1d_acf7d9("2f17371d1f2b482841353a3b53", 108, 17) then return _lI1I11l
return 0
end function
function W_AsBool(_ll11lIl as Dynamic) as Boolean
if ((81783 - 9087 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _ll11lIl = invalid then return false
_lIl1lIl = Type(_ll11lIl)
if _lIl1lIl = _l1d_acf7d9("1141444844434f", 66, 17) or _lIl1lIl = _l1d_acf7d9("3c4232484b4d575e58", 29, 205) then return _ll11lIl
if _lIl1lIl = _l1d_acf7d9("eac6cfd9d9e5", 188, 251) or _lIl1lIl = _l1d_acf7d9("43336a524f3d414d", 106, 43) then return LCase(_ll11lIl) = _l1d_acf7d9("1019172a", 92, 232)
return false
end function
function W_Read(_llllIIl as String) as Object
if _llllIIl = "" then return invalid
_ll1lIIl = W_Section()
if not _ll1lIIl.Exists(_llllIIl) then return invalid
_lIllIIl = _ll1lIIl.Read(_llllIIl)
if _lIllIIl = invalid or _lIllIIl = "" then return invalid
_l1llIIl = ParseJson(_lIllIIl)
if _l1llIIl = invalid then return invalid
return _l1llIIl
end function
sub W_Write(_lII1ll1 as String, _l1I1ll1 as Object)
if ((10010 - 2002 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lII1ll1 = "" then return
_lllIll1 = W_Section()
_lllIll1.Write(_lII1ll1, FormatJson(_l1I1ll1))
_lllIll1.Flush()
end sub
function W_IsFinished(_llIlIl1 as Integer, _lI1lIl1 as Integer) as Boolean
if _lI1lIl1 <= 0 then return false
if _lI1lIl1 >= 840 and _llIlIl1 >= _lI1lIl1 - 420 then return true
if _llIlIl1 >= _lI1lIl1 - 90 then return true
if _llIlIl1 >= Int(_lI1lIl1 * 0.95) then return true
return false
end function
function W_MinResumeSeconds() as Integer
if ((21114 - 3519 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return 30
end function
function W_GetMovieProgress(_lIl1I11 as String, _l1l1I11 as String) as Object
if ((45468 - 5052 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return W_Read(_l1d_acf7d9("5480", 218, 157) + W_ItemKey(_lIl1I11, _l1l1I11))
end function
sub W_SaveMovieProgress(_l1ll1I1 as String, _llll1I1 as String, _ll1l1I1 as Integer, _lIIIlI1 as Integer)
_lIll1I1 = W_ItemKey(_l1ll1I1, _llll1I1)
if _lIll1I1 = "" then return
if _ll1l1I1 < 0 then _ll1l1I1 = 0
W_Write(_l1d_acf7d9("87e1", 101, 127) + _lIll1I1, {
pos:  _ll1l1I1
dur:  _lIIIlI1
done: W_IsFinished(_ll1l1I1, _lIIIlI1)
ts:   CreateObject(_l1d_acf7d9("cce4fce4d2e6f8f8f7f2", 244, 70)).AsSeconds()
})
end sub
function W_GetEpisodeProgress(_lII1II1 as String, _l1I1II1 as String, _lllIII1 as Integer, _llI1II1 as Integer) as Object
if ((18405 - 3681 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return W_Read(_l1d_acf7d9("90e8", 96, 139) + W_ItemKey(_lII1II1, _l1I1II1) + _l1d_acf7d9("aa", 51, 161) + _lllIII1.ToStr() + _l1d_acf7d9("33", 22, 7) + _llI1II1.ToStr())
end function
sub W_SaveEpisodeProgress(_lIIl1lI as String, _l1Il1lI as String, _llI11lI as Integer, _llIl1lI as Integer, _l1111lI as Integer, _l11l1lI as Integer, _lII11lI as String, _ll111lI as String, _lIl11lI as Integer, _l1l11lI as Integer)
_lll11lI = W_ItemKey(_lIIl1lI, _l1Il1lI)
if _lll11lI = "" then return
if _l1111lI < 0 then _l1111lI = 0
_lI1l1lI = W_IsFinished(_l1111lI, _l11l1lI)
_lllI1lI = CreateObject(_l1d_acf7d9("c2c09ebcd4c6bad0d7d2", 3, 81)).AsSeconds()
W_Write(_l1d_acf7d9("e016", 115, 202) + _lll11lI + _l1d_acf7d9("c6", 217, 227) + _llI11lI.ToStr() + _l1d_acf7d9("00", 76, 138) + _llIl1lI.ToStr(), {
pos:  _l1111lI
dur:  _l11l1lI
done: _lI1l1lI
ts:   _lllI1lI
})
_lI111lI = W_Read(_l1d_acf7d9("e52f", 86, 192) + _lll11lI)
if _lIl11lI <= 0 and _lI111lI <> invalid and _lI111lI.lastSeason <> invalid then _lIl11lI = W_AsInt(_lI111lI.lastSeason)
if _l1l11lI <= 0 and _lI111lI <> invalid and _lI111lI.lastEpisode <> invalid then _l1l11lI = W_AsInt(_lI111lI.lastEpisode)
_l1I11lI = false
if _lI1l1lI and _lIl11lI > 0 and _l1l11lI > 0 then
if _llI11lI > _lIl11lI or (_llI11lI = _lIl11lI and _llIl1lI >= _l1l11lI) then
_l1I11lI = true
end if
end if
W_Write(_l1d_acf7d9("e933", 196, 50) + _lll11lI, {
season:      _llI11lI
episode:     _llIl1lI
slug:        _lII11lI
name:        _ll111lI
pos:         _l1111lI
dur:         _l11l1lI
done:        _l1I11lI
lastSeason:  _lIl11lI
lastEpisode: _l1l11lI
ts:          _lllI1lI
})
end sub
function W_GetSeriesProgress(_ll1IIlI as String, _lIlIIlI as String) as Object
return W_Read(_l1d_acf7d9("ce9a", 179, 14) + W_ItemKey(_ll1IIlI, _lIlIIlI))
end function
sub W_MarkWatched(_l1l111I as String, _lll111I as String, _ll1111I as String)
_lIl111I = W_ItemKey(_l1l111I, _lll111I)
if _lIl111I = "" then return
_llI111I = CreateObject(_l1d_acf7d9("0101ddfd1307f9111813", 2, 145)).AsSeconds()
if _ll1111I = _l1d_acf7d9("fe03", 128, 10) then
_lI1111I = W_Read(_l1d_acf7d9("e49e", 152, 249) + _lIl111I)
if _lI1111I = invalid then _lI1111I = {}
_lI1111I.done = true
_lI1111I.ts = _llI111I
W_Write(_l1d_acf7d9("316b", 202, 120) + _lIl111I, _lI1111I)
else
_l11111I = W_Read(_l1d_acf7d9("1aea", 128, 45) + _lIl111I)
if _l11111I = invalid then _l11111I = { pos: 0, dur: 0 }
_l11111I.done = true
_l11111I.ts = _llI111I
W_Write(_l1d_acf7d9("75a9", 94, 66) + _lIl111I, _l11111I)
end if
end sub
function W_ResumePosition(_l1III1I as Object) as Integer
if _l1III1I = invalid then return 0
if W_AsBool(_l1III1I.done) then return 0
_lIIII1I = W_AsInt(_l1III1I.pos)
if _lIIII1I < W_MinResumeSeconds() then return 0
return _lIIII1I
end function
function W_FormatTime(_lII11II as Integer) as String
if _lII11II <= 0 then return _l1d_acf7d9("7cc0", 133, 199)
_lI111II = Int(_lII11II / 3600)
m = Int((_lII11II Mod 3600) / 60)
_l1I11II = _lII11II Mod 60
if _lI111II > 0 then
_llI11II = m.ToStr()
if m < 10 then _llI11II = _l1d_acf7d9("d2", 170, 56) + _llI11II
return _lI111II.ToStr() + _l1d_acf7d9("e29d", 1, 121) + _llI11II + _l1d_acf7d9("8a", 84, 81)
end if
if m > 0 then return m.ToStr() + _l1d_acf7d9("2157", 224, 148) + _l1I11II.ToStr() + _l1d_acf7d9("ee", 68, 183)
return _l1I11II.ToStr() + _l1d_acf7d9("84", 59, 60)
end function
sub W_RememberContext(_lI1llll as String, _ll1llll as Object)
if _lI1llll = "" or _ll1llll = invalid then return
_l11llll = W_Read(_l1d_acf7d9("8a46", 145, 152) + _lI1llll)
_l1Illll = {}
if _l11llll <> invalid then
for each _llIllll in _l11llll
_l1Illll[_llIllll] = _l11llll[_llIllll]
end for
end if
for each _llIllll in _ll1llll
_lIIllll = _ll1llll[_llIllll]
if _lIIllll <> invalid and _lIIllll <> "" then _l1Illll[_llIllll] = _lIIllll
end for
_l1Illll.ts = CreateObject(_l1d_acf7d9("dad2eed6e4d80aeae9e4", 38, 134)).AsSeconds()
W_Write(_l1d_acf7d9("a1dd", 81, 111) + _lI1llll, _l1Illll)
end sub
function W_GetContext(_l1lI1ll as String) as Object
if ((12552 - 2092 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _l1lI1ll = "" then return invalid
return W_Read(_l1d_acf7d9("1662", 107, 14) + _l1lI1ll)
end function
function W_ListInProgress(_lIlIl1l as Integer) as Object
_ll1Il1l = []
_lIIIl1l = W_Section()
_lllIl1l = _lIIIl1l.GetKeyList()
if _lllIl1l = invalid then return _ll1Il1l
_llll11l = {}
for each _lII1l1l in _lllIl1l
_l1lIl1l = ""
_llI1l1l = ""
if Left(_lII1l1l, 2) = _l1d_acf7d9("a75d", 183, 205) then
_l1lIl1l = _l1d_acf7d9("b4b9c5b9b8", 65, 136)
_llI1l1l = Mid(_lII1l1l, 3)
else if Left(_lII1l1l, 2) = _l1d_acf7d9("b26e", 141, 180) then
_l1lIl1l = _l1d_acf7d9("d0d1", 203, 17)
_llI1l1l = Mid(_lII1l1l, 3)
end if
if _l1lIl1l <> "" and not _llll11l.DoesExist(_llI1l1l) then
_llll11l[_llI1l1l] = true
_l1l1l1l = W_Read(_lII1l1l)
if _l1l1l1l <> invalid then
_lI1Il1l = W_AsInt(_l1l1l1l.pos)
_lll1l1l = W_AsInt(_l1l1l1l.dur)
_l111l1l = W_AsBool(_l1l1l1l.done)
if _lI1Il1l >= 5 or _l111l1l then
_lIIll1l = W_GetContext(_llI1l1l)
_l1ll11l = _llI1l1l
_llIIl1l = ""
if _lIIll1l <> invalid then
if _lIIll1l.title <> invalid and _lIIll1l.title <> "" then _l1ll11l = _lIIll1l.title
if _lIIll1l.poster <> invalid and _lIIll1l.poster <> "" then _llIIl1l = _lIIll1l.poster
end if
if _l1ll11l = _llI1l1l or Left(_l1ll11l, 2) = _l1d_acf7d9("8d90", 29, 36) then
if _l1l1l1l.name <> invalid and _l1l1l1l.name <> "" and Left(_l1l1l1l.name, 2) <> _l1d_acf7d9("7679", 11, 247) then
_l1IIl1l = _l1l1l1l.name
_lIl1l1l = Instr(1, _l1IIl1l, _l1d_acf7d9("b7c5bd8d", 243, 228))
if _lIl1l1l > 1 then
_l1ll11l = Left(_l1IIl1l, _lIl1l1l - 1)
else
_l1ll11l = _l1IIl1l
end if
end if
end if
if (_llIIl1l = invalid or _llIIl1l = "") and Left(_llI1l1l, 2) = _l1d_acf7d9("1a1d", 235, 123) then
_llIIl1l = _l1d_acf7d9("ae9da09f9feb0104c5ccc3c8cdba1aded9cddbe7d5e332d8def0f1fa43ed09f0fa0cfa58ff2017272a6a", 211, 243) + _llI1l1l + _l1d_acf7d9("30f9f8f1", 214, 55)
end if
_l11Il1l = W_PercentOf(_lI1Il1l, _lll1l1l)
if _l111l1l and _l11Il1l < 100 then _l11Il1l = 100
_lI11l1l = {
itemKey: _llI1l1l
kind:    _l1lIl1l
title:   _l1ll11l
poster:  _llIIl1l
href:    ""
imdb:    _llI1l1l
tmdb:    ""
pos:     _lI1Il1l
dur:     _lll1l1l
pct:     _l11Il1l
ts:      W_AsInt(_l1l1l1l.ts)
done:    _l111l1l
}
if _l1lIl1l = _l1d_acf7d9("0506", 22, 163) then
_lI11l1l.season  = W_AsInt(_l1l1l1l.season)
_lI11l1l.episode = W_AsInt(_l1l1l1l.episode)
if _l1l1l1l.name <> invalid and _l1l1l1l.name <> "" then _lI11l1l.name = _l1l1l1l.name else _lI11l1l.name = ""
end if
_ll1Il1l.Push(_lI11l1l)
end if
end if
end if
end for
if _ll1Il1l.Count() > 1 then
for _ll11l1l = 0 to _ll1Il1l.Count() - 2
for _l1I1l1l = 0 to _ll1Il1l.Count() - 2 - _ll11l1l
if _ll1Il1l[_l1I1l1l].ts < _ll1Il1l[_l1I1l1l + 1].ts then
_lIll11l = _ll1Il1l[_l1I1l1l]
_ll1Il1l[_l1I1l1l] = _ll1Il1l[_l1I1l1l + 1]
_ll1Il1l[_l1I1l1l + 1] = _lIll11l
end if
end for
end for
end if
if _lIlIl1l > 0 and _ll1Il1l.Count() > _lIlIl1l then
_ll1l11l = []
for _ll11l1l = 0 to _lIlIl1l - 1
_ll1l11l.Push(_ll1Il1l[_ll11l1l])
end for
return _ll1l11l
end if
return _ll1Il1l
end function
function W_PercentOf(_lIII11l as Integer, _llII11l as Integer) as Integer
if _llII11l <= 0 then return 0
_l1II11l = Int((_lIII11l * 100) / _llII11l)
if _l1II11l < 0 then _l1II11l = 0
if _l1II11l > 100 then _l1II11l = 100
return _l1II11l
end function
function W_GetProgressPct(_l1I1lIl as String, _llI1lIl as String, _l1lIlIl as Integer, _lI11lIl as Integer) as Integer
if ((18198 - 3033 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lII1lIl = W_ItemKey(_l1I1lIl, _llI1lIl)
if _lII1lIl = "" then return 0
if _l1lIlIl > 0 and _lI11lIl > 0 then
_l111lIl = W_Read(_l1d_acf7d9("f4c0", 142, 9) + _lII1lIl + _l1d_acf7d9("b3", 193, 184) + _l1lIlIl.ToStr() + _l1d_acf7d9("72", 44, 92) + _lI11lIl.ToStr())
if _l111lIl = invalid or W_AsBool(_l111lIl.done) then return 0
return W_PercentOf(W_AsInt(_l111lIl.pos), W_AsInt(_l111lIl.dur))
end if
m = W_Read(_l1d_acf7d9("002c", 114, 225) + _lII1lIl)
if m <> invalid and not W_AsBool(m.done) then
return W_PercentOf(W_AsInt(m.pos), W_AsInt(m.dur))
end if
_lllIlIl = W_Read(_l1d_acf7d9("216d", 215, 125) + _lII1lIl)
if _lllIlIl <> invalid and not W_AsBool(_lllIlIl.done) then
return W_PercentOf(W_AsInt(_lllIlIl.pos), W_AsInt(_lllIlIl.dur))
end if
return 0
end function
function W_FavSection() as Object
if ((39864 - 4983 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l11lIIl = CreateObject(_l1d_acf7d9("212907353a3734303933204d5642525355", 220, 115), _l1d_acf7d9("f7cdd8dcf9e3effdeaf800250ff105010705130714", 34, 135))
_ll1lIIl = CreateObject(_l1d_acf7d9("bfa5e5b1b6b3d0ced7cffcc9d2e0cecfd3", 173, 224), _l1d_acf7d9("e7b9c9bacaf6f5f1fdd9d3edd5edddefe0", 241, 46))
if _ll1lIIl.GetKeyList() <> invalid and _ll1lIIl.GetKeyList().Count() > 0 then
for each _lIllIIl in _ll1lIIl.GetKeyList()
if not _l11lIIl.Exists(_lIllIIl) then _l11lIIl.Write(_lIllIIl, _ll1lIIl.Read(_lIllIIl))
end for
_l11lIIl.Flush()
end if
return _l11lIIl
end function
function W_IsFavorite(_l1lIll1 as String, _lllIll1 as String) as Boolean
_lIlIll1 = W_ItemKey(_l1lIll1, _lllIll1)
if _lIlIll1 = "" then return false
return W_FavSection().Exists(_lIlIll1)
end function
sub W_AddFavorite(_l1IlIl1 as Object)
if ((12008 - 3002 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _l1IlIl1 = invalid then return
_lll1Il1 = ""
_lIIlIl1 = ""
if _l1IlIl1.imdb <> invalid then _lll1Il1 = _l1IlIl1.imdb
if _l1IlIl1.href <> invalid then _lIIlIl1 = _l1IlIl1.href
_l1l1Il1 = W_ItemKey(_lll1Il1, _lIIlIl1)
if _l1l1Il1 = "" then return
_lIl1Il1 = {
title:  ""
poster: ""
href:   _lIIlIl1
imdb:   _lll1Il1
tmdb:   ""
kind:   ""
ts:     CreateObject(_l1d_acf7d9("bdadd5b5cbbff1b9c0cb", 232, 35)).AsSeconds()
}
if _l1IlIl1.title  <> invalid then _lIl1Il1.title  = _l1IlIl1.title
if _l1IlIl1.poster <> invalid then _lIl1Il1.poster = _l1IlIl1.poster
if _l1IlIl1.tmdb   <> invalid then _lIl1Il1.tmdb   = _l1IlIl1.tmdb
if _l1IlIl1.kind   <> invalid then _lIl1Il1.kind   = _l1IlIl1.kind
_ll11Il1 = W_FavSection()
_ll11Il1.Write(_l1l1Il1, FormatJson(_lIl1Il1))
_ll11Il1.Flush()
end sub
sub W_RemoveFavorite(_llIIl11 as String, _lI1Il11 as String)
if ((62721 - 6969 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1IIl11 = W_ItemKey(_llIIl11, _lI1Il11)
if _l1IIl11 = "" then return
_lIIIl11 = W_FavSection()
if _lIIIl11.Exists(_l1IIl11) then
_lIIIl11.Delete(_l1IIl11)
_lIIIl11.Flush()
end if
end sub
function W_ListFavorites() as Object
if ((23814 - 7938 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1lII11 = []
_ll1II11 = W_FavSection()
_lII1I11 = _ll1II11.GetKeyList()
if _lII1I11 = invalid then return _l1lII11
for each _l1I1I11 in _lII1I11
_lIlII11 = _ll1II11.Read(_l1I1I11)
if _lIlII11 <> invalid and _lIlII11 <> "" then
_lllII11 = ParseJson(_lIlII11)
if _lllII11 <> invalid then
if _lllII11.itemKey = invalid then _lllII11.itemKey = _l1I1I11
_l1lII11.Push(_lllII11)
end if
end if
end for
if _l1lII11.Count() > 1 then
for _lI11I11 = 0 to _l1lII11.Count() - 2
for _llI1I11 = 0 to _l1lII11.Count() - 2 - _lI11I11
_ll11I11 = W_AsInt(_l1lII11[_llI1I11].ts)
_l111I11 = W_AsInt(_l1lII11[_llI1I11 + 1].ts)
if _ll11I11 < _l111I11 then
_l11II11 = _l1lII11[_llI1I11]
_l1lII11[_llI1I11] = _l1lII11[_llI1I11 + 1]
_l1lII11[_llI1I11 + 1] = _l11II11
end if
end for
end for
end if
return _l1lII11
end function
function W_SearchHistoryMax() as Integer
if ((28864 - 3608 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return 12
end function
function W_GetSearchHistory() as Object
_lIlIII1 = CreateObject(_l1d_acf7d9("1e3604363748313136441d4e5343636062", 22, 186), _l1d_acf7d9("01d3cecef7d5ed07e0f6f6", 172, 3))
if not _lIlIII1.Exists(_l1d_acf7d9("606d746a7c86698b787692828a", 21, 250)) then
_lII1II1 = CreateObject(_l1d_acf7d9("0af8300809021b25221e47201d371d2226", 107, 241), _l1d_acf7d9("a0947a9385afa6", 164, 180))
if _lII1II1.Exists(_l1d_acf7d9("3b5453455755385a535d655d59", 219, 147)) then return ParseJson(_lII1II1.Read(_l1d_acf7d9("32434a3a4e5a7d614a4a645260", 246, 173)))
return []
end if
_l1lIII1 = _lIlIII1.Read(_l1d_acf7d9("a4b1b8aec0caedcfbcbad6c6ce", 181, 222))
if _l1lIII1 = invalid or _l1lIII1 = "" then return []
_lllIII1 = ParseJson(_l1lIII1)
if _lllIII1 = invalid then return []
return _lllIII1
end function
sub W_PushSearchQuery(_l1l11lI as String)
if _l1l11lI = invalid then return
_lIl11lI = _l1l11lI
if Type(_lIl11lI) = _l1d_acf7d9("c9a5aec8c8c4", 244, 34) or Type(_lIl11lI) = _l1d_acf7d9("442a294b503c3a44", 15, 199) then
_lIl11lI = U_Trim(_lIl11lI)
end if
if _lIl11lI = "" then return
_l1Il1lI = W_GetSearchHistory()
_lIIl1lI = [_lIl11lI]
_llIl1lI = LCase(_lIl11lI)
for each _lll11lI in _l1Il1lI
if Type(_lll11lI) = _l1d_acf7d9("02202941433d", 21, 188) or Type(_lll11lI) = _l1d_acf7d9("b3c998b6bfd7d9d3", 85, 140) then
if LCase(_lll11lI) <> _llIl1lI and _lIIl1lI.Count() < W_SearchHistoryMax() then
_lIIl1lI.Push(_lll11lI)
end if
end if
end for
_ll111lI = CreateObject(_l1d_acf7d9("716997696a7b84848997b0818696969395", 102, 93), _l1d_acf7d9("1202fdff2804fe360f0705", 125, 227))
_ll111lI.Write(_l1d_acf7d9("7b888f83978fb296938f9d9b95", 188, 172), FormatJson(_lIIl1lI))
_ll111lI.Flush()
end sub
sub W_ClearSearchHistory()
_l11IIlI = CreateObject(_l1d_acf7d9("b2c098d0d1cac3cdcac6afe8e5dfe5eaee", 219, 9), _l1d_acf7d9("03172228052d3b0734444a", 195, 114))
if _l11IIlI.Exists(_l1d_acf7d9("39464d43554f7254514f5b5b53", 189, 107)) then
_l11IIlI.Delete(_l1d_acf7d9("d5c2c9dfd1cbaed0edebd7f7ef", 141, 215))
_l11IIlI.Flush()
end if
end sub
function W_MirrorSection() as Object
if ((57880 - 7235 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return CreateObject(_l1d_acf7d9("1705fd15160f28322f2b142d2a442a2f33", 139, 30), _l1d_acf7d9("cafe090fec1402ee1b0b11f60b2a1417351dff29372f2b", 83, 201))
end function
function W_MirrorRecord(_l1lllII as String) as Object
if _l1lllII = "" then return { ok: 0, fail: 0 }
_lI1llII = W_MirrorSection()
if not _lI1llII.Exists(_l1lllII) then return { ok: 0, fail: 0 }
_l11llII = _lI1llII.Read(_l1lllII)
_ll1llII = _l11llII.Tokenize(_l1d_acf7d9("23", 218, 67))
_lIlllII = 0
_lllllII = 0
if _ll1llII.Count() >= 1 then _lIlllII = _ll1llII[0].ToInt()
if _ll1llII.Count() >= 2 then _lllllII = _ll1llII[1].ToInt()
return { ok: _lIlllII, fail: _lllllII }
end function
sub W_RecordMirrorOutcome(_l1I11II as String, _l1lI1II as Boolean)
if _l1I11II = "" then return
_lII11II = W_MirrorRecord(_l1I11II)
if _l1lI1II then
_lII11II.ok = _lII11II.ok + 1
else
_lII11II.fail = _lII11II.fail + 1
end if
_lllI1II = W_MirrorSection()
_lllI1II.Write(_l1I11II, _lII11II.ok.ToStr() + _l1d_acf7d9("9e", 129, 227) + _lII11II.fail.ToStr())
_lllI1II.Flush()
end sub
function W_MirrorScore(_lI1llll as String) as Float
if ((78354 - 8706 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lI1llll = "" then return -1.0
_llIllll = W_MirrorRecord(_lI1llll)
_l1Illll = _llIllll.ok + _llIllll.fail
if _l1Illll = 0 then return -1.0
return _llIllll.ok / (_l1Illll * 1.0)
end function
function W_MirrorTotal(_ll1I1ll as String) as Integer
_l11I1ll = W_MirrorRecord(_ll1I1ll)
return _l11I1ll.ok + _l11I1ll.fail
end function
function WL_IsFavorite(_l1l1l1l as String) as Boolean
if _l1l1l1l = invalid or _l1l1l1l = "" then return false
return W_IsFavorite(_l1l1l1l, "")
end function
sub WL_ToggleFavorite(_llllI1l as Object)
if ((8988 - 2996 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _llllI1l = invalid or _llllI1l.id = invalid or _llllI1l.id = "" then return
if WL_IsFavorite(_llllI1l.id) then
W_RemoveFavorite(_llllI1l.id, "")
else
_lIII11l = {
imdb: _llllI1l.id,
title: _llllI1l.title,
poster: _llllI1l.poster,
kind: _llllI1l.kind,
year: _llllI1l.year,
rating: _llllI1l.rating
}
W_AddFavorite(_lIII11l)
end if
end sub
function WL_GetFavorites() as Object
_lllIlIl = W_ListFavorites()
_lII1lIl = []
if _lllIlIl <> invalid then
for each _l1I1lIl in _lllIlIl
_llI1lIl = _l1I1lIl.imdb
if _llI1lIl = invalid or _llI1lIl = "" then _llI1lIl = _l1I1lIl.itemKey
_lII1lIl.Push({
id: _llI1lIl,
title: _l1I1lIl.title,
poster: _l1I1lIl.poster,
kind: _l1I1lIl.kind,
year: _l1I1lIl.year,
rating: _l1I1lIl.rating
})
end for
end if
return _lII1lIl
end function
function _l1d_acf7d9(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function