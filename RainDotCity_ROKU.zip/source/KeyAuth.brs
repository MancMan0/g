function KA_GetConfig() as Object
if ((76096 - 9512 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return {
name: _l1d_a500bd("a7c7bed0cae1dde5", 21, 87),
ownerid: _l1d_a500bd("a8b9d810e8d5f4cbda00", 236, 40),
version: _l1d_a500bd("5f4966", 141, 163),
apiUrl: _l1d_a500bd("ddd4d7dee29eacaff6fbea05f4f807c8020f11d320141edfdce6e4eb", 29, 104)
}
end function
function KA_GetChecksum() as String
if ((13248 - 3312 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llIll1l = CreateObject(_l1d_a500bd("c9c9dfd9d7cbeadee1d3ee", 96, 183))
if _llIll1l.ReadFile(_l1d_a500bd("646c73233176857b83898d8284", 159, 117)) then
_l1Ill1l = CreateObject(_l1d_a500bd("30361f151a294750514a48", 29, 193))
if _l1Ill1l <> invalid and _l1Ill1l.Setup(_l1d_a500bd("363264", 117, 30)) = 0 then
return _l1Ill1l.Process(_llIll1l)
end if
end if
return ""
end function
function KA_GetHwid() as String
_lIII11l = U_PrefDefault(_l1d_a500bd("c9d6a3d5d1daea", 219, 25), "")
if _lIII11l <> "" and Len(_lIII11l) >= 20 then return _lIII11l
_lI1I11l = CreateObject(_l1d_a500bd("0e2c4a2c1e362f385f45404a", 179, 77))
_l11I11l = _lI1I11l.GetChannelClientId()
if _l11I11l = invalid or Len(_l11I11l) < 8 then _l11I11l = _lI1I11l.GetRandomUUID()
_l1II11l = _lI1I11l.GetModel()
if _l1II11l = invalid or _l1II11l = "" then _l1II11l = _l1d_a500bd("465c6348", 149, 127)
_llII11l = _l1d_a500bd("a2c2c1aea9", 16, 96) + _l1II11l + _l1d_a500bd("8d", 92, 28) + _l11I11l
while Len(_llII11l) < 24
_llII11l = _llII11l + _l1d_a500bd("c4", 206, 198)
end while
U_PrefSet(_l1d_a500bd("413a5349314e46", 53, 227), _llII11l)
return _llII11l
end function
function KA_HttpPost(_l1lIlIl as Object) as Object
_ll11lIl = KA_GetConfig()
_llIIlIl = CreateObject(_l1d_a500bd("edf310f6ff1aff130907171b11", 255, 96))
_llIIlIl.SetCertificatesFile(_l1d_a500bd("dbd2d3d6dbdf3624f3f00a070f3605063d0f1b09120d1755233734", 205, 45))
_llIIlIl.InitClientCertificates()
_llIIlIl.SetUrl(_ll11lIl.apiUrl)
_llIIlIl.RetainBodyOnError(true)
_llIIlIl.EnableEncodings(true)
_llIIlIl.AddHeader(_l1d_a500bd("5f767a77898380ca6684909e", 223, 195), _l1d_a500bd("3c30334a504d4e3e5c5d6123592754575a33717b6b7f426d778c86949299939599", 21, 200))
_llIIlIl.AddHeader(_l1d_a500bd("ac95a29cf0cfb0b1bfa8", 245, 12), _l1d_a500bd("bef4ff03e00af6e411ff07dee2222112ebd4f0d9", 146, 254))
_llIIlIl.AddHeader(_l1d_a500bd("a4c5c8c9c1c0", 87, 142), _l1d_a500bd("99abaea5ada6abb9b9b6b87cc2cec5c78c8bdaceece39dede4e4efebb0afb8b8be", 134, 178))
_lIl1lIl = ""
_lI11lIl = true
for each _l1I1lIl in _l1lIlIl
if not _lI11lIl then _lIl1lIl = _lIl1lIl + _l1d_a500bd("be", 38, 190)
_lIl1lIl = _lIl1lIl + _l1I1lIl.ToStr() + _l1d_a500bd("ed", 90, 134) + _llIIlIl.Escape(_l1lIlIl[_l1I1lIl].ToStr())
_lI11lIl = false
end for
_lllIlIl = CreateObject(_l1d_a500bd("5a785974656879828353937b80", 145, 119))
_llIIlIl.SetMessagePort(_lllIlIl)
if not _llIIlIl.AsyncPostFromString(_lIl1lIl) then
return { success: false, message: _l1d_a500bd("6f55504e5a5ca37260ac72696b6e78818dc49381cdc2948f8fb896aec8a1b7b7f1c7b4cccbb9c6c3ff", 236, 197) }
end if
_lI1IlIl = CreateObject(_l1d_a500bd("42402e444b4653594b59", 195, 145))
_lI1IlIl.mark()
_l111lIl = 12000
_ll1IlIl = ""
_l11IlIl = 0
while _lI1IlIl.totalMilliseconds() < _l111lIl
_lIlIlIl = _l111lIl - _lI1IlIl.totalMilliseconds()
if _lIlIlIl < 1 then exit while
_lII1lIl = wait(_lIlIlIl, _lllIlIl)
if _lII1lIl = invalid then exit while
if type(_lII1lIl) = _l1d_a500bd("c2e2abcbe8c4d8eaf6df", 80, 160) then
_l11IlIl = _lII1lIl.getResponseCode()
_ll1IlIl = _lII1lIl.getString()
if _ll1IlIl = invalid then _ll1IlIl = ""
exit while
end if
end while
if _ll1IlIl = "" and _l11IlIl = 0 then
_llIIlIl.AsyncCancel()
return { success: false, message: _l1d_a500bd("bad9dbdeece901e9eef03910f8ff0a0c4b092628515afc182825206c382d4a467b373b584c58475567965857595c6a677f676c6eb1", 74, 177) }
end if
_llI1lIl = ParseJson(_ll1IlIl)
if _llI1lIl = invalid then
if _l11IlIl > 0 then
return { success: false, message: _l1d_a500bd("481c1715421a384c29413ffb394f5238580d086b82858c1f", 175, 75) + _l11IlIl.ToStr() + _l1d_a500bd("999ba842647f736b7179c095819a9c8488a693d1", 205, 181) }
else
return { success: false, message: _l1d_a500bd("eccabcbed9bfdb97d9e8eaedebe8e0f8fdffb800ecef0ff5d4cd2f1b1b1823df1b301d19ee3a3e2b3f2b4a483a094b5a5c5f5d5a526a6f7134", 178, 240) }
end if
end if
return _llI1lIl
end function
function KA_Init() as Object
_llllIIl = KA_GetConfig()
_l1llIIl = KA_GetChecksum()
_ll1lIIl = {
"type": _l1d_a500bd("1f1b251b", 126, 8),
"ver": _llllIIl.version,
"hash": _l1llIIl,
"name": _llllIIl.name,
"ownerid": _llllIIl.ownerid
}
_l11lIIl = KA_HttpPost(_ll1lIIl)
if _l11lIIl.success = true and _l11lIIl.sessionid <> invalid and _l11lIIl.sessionid <> "" then
return { success: true, sessionid: _l11lIIl.sessionid, message: _l11lIIl.message }
else
_lIllIIl = _l1d_a500bd("72424d57705c66765f6f7521756a7c8377747939838d89998f8a9a98ae96aea4adb166afabb6beb8bc", 33, 255)
if _l11lIIl.message <> invalid then _lIllIIl = _l11lIIl.message
return { success: false, message: _lIllIIl }
end if
end function
function KA_CleanAuthMessage(_lII1ll1 as String) as String
if ((28280 - 5656 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lII1ll1 = invalid or _lII1ll1 = "" then return ""
_l1I1ll1 = _lII1ll1
_lllIll1 = CreateObject(_l1d_a500bd("8fa5b5a1a6a7a7", 117, 136), _l1d_a500bd("82846f838b9189d07e87948ea5a1a8a37f9ffbf98bab07c7c9b4c8d0d6ce15dce2dfdcead8e52df9eeed", 213, 198), _l1d_a500bd("e5", 225, 93))
if _lllIll1 <> invalid then _l1I1ll1 = _lllIll1.replaceAll(_l1I1ll1, _l1d_a500bd("9cbad5cdc5cbd31ad1d7e0e1dbf9ea32eaf302", 79, 150))
_l1lIll1 = CreateObject(_l1d_a500bd("9ab0c0b0b1b6b6", 183, 213), _l1d_a500bd("e0e803f1efeffd3c14150a1a090f0e1957192f601f1f2c312d453a7836434a", 72, 191), _l1d_a500bd("26", 84, 233))
if _l1lIll1 <> invalid then _l1I1ll1 = _l1lIll1.replaceAll(_l1I1ll1, _l1d_a500bd("452d3826343432f140403d424e564b0957546b", 32, 220))
_l11Ill1 = CreateObject(_l1d_a500bd("ebfb11070c0df3", 56, 161), _l1d_a500bd("9a8c9da09f9aaa9be2a1a9a6bbf9b6f0c6d1c2cfda09ced0de1c18deddede1effefdef000339ff060f0807170b192827230e232a332c2b3b2f3d4c4b3d4e51504b5b4c935960696261716573", 71, 99), _l1d_a500bd("c3", 41, 131))
if _l11Ill1 <> invalid then _l1I1ll1 = _l11Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("a8cedbd8d6f4e1a9e5eaf9b5f4f0f912c4fdff19d00615251d17", 13, 103))
_l1IIll1 = CreateObject(_l1d_a500bd("cce2f2dee3e4e4", 245, 69), _l1d_a500bd("1a1b10201f15241fdd2e323ae9323e47433c57534f835559618f59656e6a63", 32, 197), _l1d_a500bd("a9", 28, 52))
if _l1IIll1 <> invalid then _l1I1ll1 = _l1IIll1.replaceAll(_l1I1ll1, _l1d_a500bd("a18986838f7f8cd2a09594dea7ab93eaabb7a0bcb5", 244, 233))
_lIlIll1 = CreateObject(_l1d_a500bd("ecd2d2dee3e4f4", 77, 173), _l1d_a500bd("4d513c4e5c5c5a99514e6753726c7b76", 114, 50), _l1d_a500bd("b2", 76, 141))
if _lIlIll1 <> invalid then _l1I1ll1 = _lIlIll1.replaceAll(_l1I1ll1, _l1d_a500bd("0fede800f8fe064d040a13140e0c1d651d2615", 255, 89))
_llll1l1 = CreateObject(_l1d_a500bd("4b6b71676c6d63", 240, 201), _l1d_a500bd("312e2733322c3b36f4453f4e554c544e50", 34, 218), _l1d_a500bd("83", 71, 85))
if _llll1l1 <> invalid then _l1I1ll1 = _llll1l1.replaceAll(_l1I1ll1, _l1d_a500bd("230b04050dfd0e541e17166011231a1938203234", 246, 105))
_lI1Ill1 = CreateObject(_l1d_a500bd("b2ba98cacbd0be", 94, 134), _l1d_a500bd("c1d3c4c7ced9d1eaa9daf2e1e8efe90105", 59, 118), _l1d_a500bd("0f", 53, 179))
if _lI1Ill1 <> invalid then _l1I1ll1 = _lI1Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("c7edf6f7f10f00480009185425152c2b1a342428", 79, 196))
_lIIIll1 = CreateObject(_l1d_a500bd("1a024012131826", 238, 126), _l1d_a500bd("7f7c9581909a99a462a0966b9eb2a3a6adb8aec7", 154, 144), _l1d_a500bd("f2", 144, 249))
if _lIIIll1 <> invalid then _l1I1ll1 = _lIIIll1.replaceAll(_l1I1ll1, _l1d_a500bd("c6c6d3d8d4cce19fddead1", 184, 242))
_llIIll1 = CreateObject(_l1d_a500bd("c0d8a6d4d9dad8", 212, 26), _l1d_a500bd("d9e2cfe9d0dcd3de", 13, 97), _l1d_a500bd("75", 62, 30))
if _llIIll1 <> invalid then _l1I1ll1 = _llIIll1.replaceAll(_l1I1ll1, _l1d_a500bd("bee4e1deecdae7afdbf0ef", 21, 101))
_ll1Ill1 = CreateObject(_l1d_a500bd("ea0210fe030402", 116, 228), _l1d_a500bd("f9eb00030af50d02", 41, 160), _l1d_a500bd("92", 121, 130))
if _ll1Ill1 <> invalid then _l1I1ll1 = _ll1Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("b896a3a8a69cb171cdbaa1", 57, 67))
return _l1I1ll1
end function
function KA_License(_lll1Il1 as String) as Object
if _lll1Il1 = invalid or U_Trim(_lll1Il1) = "" then
return { success: false, message: _l1d_a500bd("99c0cad1c2d31bd9d3d0e2d82dd7e4e1e73cf3f90203fdfb0c540c150452", 95, 138) }
end if
_lll1Il1 = U_Trim(_lll1Il1)
_lIIlIl1 = KA_Init()
if not _lIIlIl1.success then
return _lIIlIl1
end if
_lI1lIl1 = KA_GetConfig()
_l1IlIl1 = KA_GetHwid()
_ll11Il1 = {
"type": _l1d_a500bd("1319142121", 164, 75),
"username": _lll1Il1,
"pass": "",
"hwid": _l1IlIl1,
"sessionid": _lIIlIl1.sessionid,
"name": _lI1lIl1.name,
"ownerid": _lI1lIl1.ownerid
}
_lI11Il1 = KA_HttpPost(_ll11Il1)
if _lI11Il1.success = true then
_llIlIl1 = ""
_l1I1Il1 = _l1d_a500bd("afb1b7bbcab6d1", 205, 6)
if _lI11Il1.info <> invalid and _lI11Il1.info.subscriptions <> invalid and _lI11Il1.info.subscriptions.Count() > 0 then
_llI1Il1 = KA_CheckSubscriptions(_lI11Il1.info.subscriptions)
if _llI1Il1.isExpired then
KA_ClearLicense()
return {
success: false,
message: _l1d_a500bd("24f1fe0237fe06ff000818094f1a16275b1b393430382a2c757669403c4354458b5c4e5654659d79667377ac7e7f73877a8c8a9493939092d5", 102, 229)
}
end if
_llIlIl1 = _llI1Il1.expiry
_l1I1Il1 = _llI1Il1.subName
end if
U_PrefSet(_l1d_a500bd("b5c28fc5c3ccd5cfc5dea7d6e7ce", 27, 69), _lll1Il1)
U_PrefSet(_l1d_a500bd("f2fbccf5f60bfd0c100f1a", 89, 192), _lll1Il1)
U_PrefSet(_l1d_a500bd("323b0438323f45", 28, 187), _l1IlIl1)
U_PrefSet(_l1d_a500bd("404d5a534a4e5569574d596f", 123, 48), _l1d_a500bd("353b44453f5d4e", 175, 114))
U_PrefSet(_l1d_a500bd("5e5b305d5d58725c68", 87, 34), _llIlIl1)
U_PrefSet(_l1d_a500bd("5f5c59707965", 194, 182), _l1I1Il1)
U_PrefSet(_l1d_a500bd("b3c0a5b9c9dadab4ded4e8d6dadce3e5", 142, 206), CreateObject(_l1d_a500bd("745c48707e726474737e", 14, 248)).AsSeconds().ToStr())
return {
success: true,
message: _l1d_a500bd("210714110f0d1a621e23126e1f2f29313b373e42893d3a5356534c4f5f4f5b5e54af", 125, 240),
expiry: _llIlIl1,
subscription: _l1I1Il1,
authType: _l1d_a500bd("adb5bebfb7b7c8", 30, 59)
}
end if
_lIl1Il1 = {
"type": _l1d_a500bd("bec6cfd0c8e8d9", 110, 188),
"key": _lll1Il1,
"hwid": _l1IlIl1,
"sessionid": _lIIlIl1.sessionid,
"name": _lI1lIl1.name,
"ownerid": _lI1lIl1.ownerid
}
_l111Il1 = KA_HttpPost(_lIl1Il1)
if _l111Il1.success = true then
_llIlIl1 = ""
_l1I1Il1 = _l1d_a500bd("bbbdc3c7d6c2dd", 77, 146)
if _l111Il1.info <> invalid and _l111Il1.info.subscriptions <> invalid and _l111Il1.info.subscriptions.Count() > 0 then
_llI1Il1 = KA_CheckSubscriptions(_l111Il1.info.subscriptions)
if _llI1Il1.isExpired then
KA_ClearLicense()
return {
success: false,
message: _l1d_a500bd("1e170002d322201d2230162beb363025f73d35304a384c501d1265645e5d5267275c707e766b39738c7577487c819385988ca49097adb6ba7d", 49, 182)
}
end if
_llIlIl1 = _llI1Il1.expiry
_l1I1Il1 = _llI1Il1.subName
end if
U_PrefSet(_l1d_a500bd("1a27342828313a322a434c3b4c33", 186, 73), _lll1Il1)
U_PrefSet(_l1d_a500bd("d7d4c9e3e7e8e0", 71, 171), _l1IlIl1)
U_PrefSet(_l1d_a500bd("9a97d49db4b8afe3c1c7c3b9", 163, 210), _l1d_a500bd("514f58615b516a", 27, 218))
U_PrefSet(_l1d_a500bd("3f4c114e3c47534b49", 30, 202), _llIlIl1)
U_PrefSet(_l1d_a500bd("d3d0cde4edd9", 130, 234), _l1I1Il1)
U_PrefSet(_l1d_a500bd("b0b982b4c2b7b591bdcdc7cfd9d5dce0", 157, 186), CreateObject(_l1d_a500bd("563c264c5c4e42504f5a", 77, 23)).AsSeconds().ToStr())
return {
success: true,
message: _l1d_a500bd("88707d7a769683c9878c9bd5999eaa9ab2a8b6aaacf3c9c6bfc2bfd8dbc9dbc5c8e01b", 108, 104),
expiry: _llIlIl1,
subscription: _l1I1Il1,
authType: _l1d_a500bd("6d73807d7b9986", 205, 204)
}
end if
_l1l1Il1 = _l1d_a500bd("74545f555b635920676f6c6975857238867b9a", 164, 135)
if _l111Il1.message <> invalid and _l111Il1.message <> "" and _l111Il1.message <> _l1d_a500bd("4b35202c3c3a3af948464348563c51115d5a51", 177, 83) then
_l1l1Il1 = KA_CleanAuthMessage(_l111Il1.message)
else if _lI11Il1.message <> invalid and _lI11Il1.message <> "" and _lI11Il1.message <> _l1d_a500bd("fbdbe6dce2eae027f700ed05fcfa01fc", 100, 206) then
_l1l1Il1 = KA_CleanAuthMessage(_lI11Il1.message)
else if _lI11Il1.message <> invalid and _lI11Il1.message <> "" then
_l1l1Il1 = KA_CleanAuthMessage(_lI11Il1.message)
end if
KA_ClearLicense()
return { success: false, message: _l1l1Il1 }
end function
function KA_Login(_l1ll111 as String, _l1IIl11 = "" as String) as Object
if _l1ll111 = invalid or _l1ll111 = "" then
return { success: false, message: _l1d_a500bd("c5e5e2e7f3dbf0aefcf9f0baef05f4fb12fe1416e3", 144, 233) }
end if
_lI1Il11 = KA_Init()
if not _lI1Il11.success then return _lI1Il11
_ll1Il11 = KA_GetConfig()
_l11Il11 = KA_GetHwid()
_lIIIl11 = {
"type": _l1d_a500bd("1c222d2a2a", 156, 44),
"username": _l1ll111,
"pass": _l1IIl11,
"hwid": _l11Il11,
"sessionid": _lI1Il11.sessionid,
"name": _ll1Il11.name,
"ownerid": _ll1Il11.ownerid
}
_llll111 = KA_HttpPost(_lIIIl11)
if _llll111.success = true then
U_PrefSet(_l1d_a500bd("7370857b817a7b8573849d948d8c", 55, 23), _l1ll111)
U_PrefSet(_l1d_a500bd("626b547d86738d74807782", 77, 60), _l1ll111)
U_PrefSet(_l1d_a500bd("ebe8e5f703fcfc", 3, 131), _l11Il11)
U_PrefSet(_l1d_a500bd("f603c809f8fa09d703030d1d", 222, 65), _l1d_a500bd("c7cddad7d5f3e0", 13, 102))
return { success: true, message: _l1d_a500bd("775f6869618172b87c7d8d7d918b998d8fd6a8a99ea1a2b7baa8bea8abc3fe", 238, 213) }
else
KA_ClearLicense()
_llIIl11 = _l1d_a500bd("b8dee7e8e200f1b9fbfc0efc120a1a080509da171f1a1a2428", 143, 245)
if _llll111.message <> invalid then _llIIl11 = KA_CleanAuthMessage(_llll111.message)
return { success: false, message: _llIIl11 }
end if
end function
function KA_IsActivated() as Boolean
if ((12528 - 1566 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lIl1I11 = U_PrefDefault(_l1d_a500bd("666f6072707d8280968b7887949b", 137, 132), "")
if _lIl1I11 = "" or Len(_lIl1I11) < 2 then return false
_l1l1I11 = U_PrefDefault(_l1d_a500bd("5b646d66545f6b6761", 252, 196), "")
if KA_IsExpired(_l1l1I11) then return false
return true
end function
function KA_GetSavedLicense() as String
return U_PrefDefault(_l1d_a500bd("8e9bc89c9ca5aea6beb7e0afc0c7", 234, 13), "")
end function
function KA_GetSavedExpiry() as String
if ((23016 - 3288 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return U_PrefDefault(_l1d_a500bd("18254a2735402c4442", 110, 19), "")
end function
function KA_IsExpired(_l11l1lI as String) as Boolean
if ((87777 - 9753 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _l11l1lI = invalid or _l11l1lI = "" or _l11l1lI = _l1d_a500bd("6f", 174, 209) or _l11l1lI = _l1d_a500bd("4866566c60", 214, 176) or _l11l1lI = _l1d_a500bd("30504c52645c635e", 2, 226) then
return false
end if
_lI1l1lI = _l11l1lI.ToInt()
if _lI1l1lI <= 0 then return false
_llIl1lI = CreateObject(_l1d_a500bd("05fdd5fd0bfff111100b", 132, 15)).AsSeconds()
return (_lI1l1lI <= _llIl1lI)
end function
function KA_FormatExpiry(_ll1IIlI as String) as String
if ((34105 - 6821 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _ll1IIlI = invalid or _ll1IIlI = "" or _ll1IIlI = _l1d_a500bd("ce", 86, 104) or _ll1IIlI = _l1d_a500bd("3460526654", 27, 223) or _ll1IIlI = _l1d_a500bd("96b6c2c8dac2c9d4", 138, 208) then
return _l1d_a500bd("2951595b6d5d5c67", 76, 41)
end if
_l11IIlI = _ll1IIlI.ToInt()
if _l11IIlI <= 0 then return _ll1IIlI
_lIlIIlI = CreateObject(_l1d_a500bd("1e0cf6142c1e12181f2a", 73, 227))
_lIlIIlI.FromSeconds(_l11IIlI)
_llIIIlI = _lIlIIlI.ToISOString()
_lI1IIlI = _llIIIlI
if Len(_llIIIlI) >= 16 then
_lI1IIlI = Mid(_llIIIlI, 1, 10) + _l1d_a500bd("c7", 53, 178) + Mid(_llIIIlI, 12, 5) + _l1d_a500bd("9e363846", 90, 36)
end if
if KA_IsExpired(_ll1IIlI) then
return _lI1IIlI + _l1d_a500bd("1823c3b9b4d0bcd2d43c", 80, 168)
end if
return _lI1IIlI
end function
function KA_CheckSubscriptions(_lII111I as Object) as Object
if _lII111I = invalid or _lII111I.Count() = 0 then
return { isExpired: false, expiry: "", subName: _l1d_a500bd("bfc3c3cddcc6e1", 110, 181) }
end if
_l11111I = CreateObject(_l1d_a500bd("c4dcb8e0cee2b4f4f3ee", 214, 32)).AsSeconds()
_ll1111I = false
_lll111I = 0
_l1l111I = _l1d_a500bd("4042444c3b4742", 31, 197)
for each _llI111I in _lII111I
_lI1111I = ""
if _llI111I.expiry <> invalid then _lI1111I = _llI111I.expiry.ToStr()
_l1I111I = _l1d_a500bd("03050b0f1e0a25", 141, 26)
if _llI111I.subscription <> invalid then _l1I111I = _llI111I.subscription
if _lI1111I = "" or _lI1111I = _l1d_a500bd("72", 237, 149) or _lI1111I = _l1d_a500bd("6c8a9a90a4", 198, 228) or _lI1111I = _l1d_a500bd("4f6d6f6f6379807b", 209, 178) then
_ll1111I = true
_l1l111I = _l1I111I
_lll111I = 0
exit for
else
_lIl111I = _lI1111I.ToInt()
if _lIl111I > _lll111I then
_lll111I = _lIl111I
_l1l111I = _l1I111I
end if
end if
end for
if _ll1111I then
return { isExpired: false, expiry: _l1d_a500bd("aa", 109, 77), subName: _l1l111I }
end if
if _lll111I > 0 then
if _lll111I <= _l11111I then
return { isExpired: true, expiry: _lll111I.ToStr(), subName: _l1l111I }
else
return { isExpired: false, expiry: _lll111I.ToStr(), subName: _l1l111I }
end if
end if
return { isExpired: false, expiry: "", subName: _l1l111I }
end function
function KA_ClearLicense()
U_PrefSet(_l1d_a500bd("98a1aa9ca2afacaaa8b5c2b9bead", 253, 2), "")
U_PrefSet(_l1d_a500bd("c3d095c2c7d8ccd3e5dce7", 94, 142), "")
U_PrefSet(_l1d_a500bd("e8f5daf70510fc1412", 142, 3), "")
U_PrefSet(_l1d_a500bd("e5dedff6fbed", 129, 251), "")
U_PrefSet(_l1d_a500bd("7784518a81838a608c848ea6", 26, 6), "")
end function
function KA_VerifySavedLicense() as Object
_l1I11II = KA_GetSavedLicense()
if _l1I11II = "" then return { success: false, message: _l1d_a500bd("87a9ebb2b8b1b2bcaabb03cbc4c30fbfd4c2d6da", 87, 110) }
_lI111II = KA_GetSavedExpiry()
if KA_IsExpired(_lI111II) then
KA_ClearLicense()
return { success: false, message: _l1d_a500bd("d1eaf3f324f3f3f0f50109fe3c070318481026211d291f216e6316353130453a784d434f495e8a665f6868996f7464786b7d77818880898bce", 192, 56) }
end if
_l1lI1II = KA_License(_l1I11II)
if _l1lI1II = invalid or _l1lI1II.success <> true then
_lllI1II = ""
if _l1lI1II <> invalid and _l1lI1II.message <> invalid then _lllI1II = _l1lI1II.message
_lII11II = LCase(_lllI1II)
_llI11II = (InStr(1, _lII11II, _l1d_a500bd("40383f3a3c7b495658", 66, 10)) > 0 or InStr(1, _lII11II, _l1d_a500bd("021022240f2d19", 14, 162)) > 0 or InStr(1, _lII11II, _l1d_a500bd("959ca0a39fa4b6b4b1b5", 167, 209)) > 0 or InStr(1, _lII11II, _l1d_a500bd("9fa6aaada9aec077c6be", 135, 187)) > 0)
if not _llI11II then
KA_ClearLicense()
end if
end if
return _l1lI1II
end function
function _l1d_a500bd(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function