sub Main()
ShowChannelSGScreen()
end sub
sub ShowChannelSGScreen()
_lll1l1l = CreateObject(_l1d_67ec73("4030675e6d4052484b47", 40, 230))
m.port = CreateObject(_l1d_67ec73("5a426752676a5f5c61975d7b7c", 110, 62))
_lll1l1l.SetMessagePort(m.port)
_lIIll1l = _lll1l1l.CreateScene(_l1d_67ec73("8bbab5b391c4c5bfcb", 159, 185))
_lIIll1l.observeField(_l1d_67ec73("4d55476775696c", 107, 63), m.port)
_lll1l1l.Show()
while true
_llIll1l = wait(0, m.port)
_l1Ill1l = type(_llIll1l)
if _l1Ill1l = _l1d_67ec73("ff1524332a1d1121242e4a1c303a27", 183, 58) then
if _llIll1l.isScreenClosed() then return
else if _l1Ill1l = _l1d_67ec73("dbd900f703e5e3e508faeef805", 163, 10) then
if _llIll1l.getField() = _l1d_67ec73("708e8288a09295", 164, 175) and _llIll1l.getData() = true then
_lll1l1l.close()
return
end if
end if
end while
end sub
function _l1d_67ec73(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function