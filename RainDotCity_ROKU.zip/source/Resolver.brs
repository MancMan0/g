function R_ResolveEmbed(_lII11ll as Object) as Object
if ((39270 - 5610 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lII11ll = invalid then return invalid
_lllI1ll = ""
if _lII11ll.embedUrl <> invalid then _lllI1ll = _lII11ll.embedUrl
if _lllI1ll = "" then return invalid
_lI1I1ll = ""
if _lII11ll.refer <> invalid then _lI1I1ll = _lII11ll.refer
if _lI1I1ll = "" then _lI1I1ll = HC_OriginOf(_lllI1ll)
if U_LooksHls(_lllI1ll) or U_LooksMp4(_lllI1ll) then
_lIlI1ll = 0
if U_LooksHls(_lllI1ll) then
_l11I1ll = HC_NewSession()
_lIlI1ll = RP_HlsLeadSkip(_l11I1ll, "", _lllI1ll, _lI1I1ll)
HC_Close(_l11I1ll)
end if
return {
url: _lllI1ll
streamFormat: U_StreamFormat(_lllI1ll)
qualities: []
subtitles: []
chapters: []
referer: _lI1I1ll
userAgent: ""
leadSkip: _lIlI1ll
}
end if
_llII1ll = HC_NewSession()
_ll1I1ll = invalid
_l1lI1ll = ""
_ll1I1ll = R_DispatchByHost(_lllI1ll, _lI1I1ll, _llII1ll)
if (_ll1I1ll = invalid or _ll1I1ll.url = "") and R_HasContentIds(_lII11ll) then
_ll1I1ll = R_FallbackByContentIds(_lII11ll, _llII1ll)
end if
if _ll1I1ll <> invalid and _ll1I1ll.url <> invalid and _ll1I1ll.url <> "" then
_ll1I1ll = R_EnrichResult(_ll1I1ll, _lII11ll, _lI1I1ll, _llII1ll)
end if
HC_Close(_llII1ll)
if _ll1I1ll = invalid then return invalid
if _ll1I1ll.url = invalid or _ll1I1ll.url = "" then return invalid
return R_NormalizeResult(_ll1I1ll, _lI1I1ll)
end function
function R_EnrichResult(_llI1l1l as Object, _llIll1l as Object, _l1I1l1l as String, _l1lIl1l as Object) as Object
if ((7524 - 1881 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _llI1l1l = invalid or _llI1l1l.url = invalid or _llI1l1l.url = "" then return _llI1l1l
_lIlIl1l = _llI1l1l.url
_l111l1l = U_LooksHls(_lIlIl1l)
_lII1l1l = ""
if _llI1l1l.referer <> invalid and _llI1l1l.referer <> "" then _lII1l1l = _llI1l1l.referer
if _lII1l1l = "" then _lII1l1l = _l1I1l1l
if _lII1l1l = "" then _lII1l1l = _lIlIl1l
_ll11l1l = ""
_ll1Il1l = ""
_lI11l1l = ""
_lllIl1l = 0
_l1Ill1l = 0
if _llIll1l <> invalid then
if _llIll1l.imdb <> invalid then _ll11l1l = _llIll1l.imdb
if _llIll1l.tmdb <> invalid then _ll1Il1l = _llIll1l.tmdb
if _llIll1l.kind <> invalid then _lI11l1l = _llIll1l.kind
if _llIll1l.season <> invalid then _lllIl1l = _llIll1l.season
if _llIll1l.episode <> invalid then _l1Ill1l = _llIll1l.episode
end if
if _l111l1l then
_lll1l1l = invalid
if _llI1l1l.qualities <> invalid and type(_llI1l1l.qualities) = _l1d_f60343("a3c3dcacafc5c0", 50, 99) then _lll1l1l = _llI1l1l.qualities
if _lll1l1l = invalid or _lll1l1l.Count() = 0 then
_llI1l1l.qualities = HM_FetchQualities(_lIlIl1l, _lII1l1l, _l1lIl1l)
end if
_lIIll1l = invalid
if _llI1l1l.chapters <> invalid and type(_llI1l1l.chapters) = _l1d_f60343("49573c52556550", 25, 222) then _lIIll1l = _llI1l1l.chapters
if _lIIll1l = invalid or _lIIll1l.Count() = 0 then
_llI1l1l.chapters = HM_ExtractChaptersHls(_lIlIl1l, _lII1l1l, _l1lIl1l)
end if
if _llI1l1l.leadSkip = invalid then
_llI1l1l.leadSkip = RP_HlsLeadSkip(_l1lIl1l, "", _lIlIl1l, _lII1l1l)
end if
end if
if _llI1l1l.chapters = invalid or type(_llI1l1l.chapters) <> _l1d_f60343("5563485e61715c", 25, 234) or _llI1l1l.chapters.Count() = 0 then
_llI1l1l.chapters = HM_FetchSkipTimes(_ll11l1l, _ll1Il1l, _lI11l1l, _lllIl1l, _l1Ill1l, _l1lIl1l)
end if
if _llI1l1l.subtitles = invalid or type(_llI1l1l.subtitles) <> _l1d_f60343("6250356b6e5e69", 137, 103) then _llI1l1l.subtitles = []
if _l111l1l then
_lIl1l1l = HM_ExtractSubsHls(_lIlIl1l, _lII1l1l, _l1lIl1l)
_llI1l1l.subtitles = HM_MergeSubtitles(_llI1l1l.subtitles, _lIl1l1l)
end if
_l1l1l1l = HM_FetchFreeSubs(_ll11l1l, _ll1Il1l, _lI11l1l, _lllIl1l, _l1Ill1l, _l1lIl1l)
_llI1l1l.subtitles = HM_MergeSubtitles(_llI1l1l.subtitles, _l1l1l1l)
return _llI1l1l
end function
function R_DispatchByHost(_l11I11l as String, _llII11l as String, _l1II11l as Object) as Object
_lI1I11l = HC_HostOf(_l11I11l)
print _l1d_f60343("9c969e8a7a83877b897f8bbbc99492a1a1ed", 102, 95); _lI1I11l; _l1d_f60343("c29a9a87db", 104, 122); _l11I11l
if _lI1I11l = "" then return invalid
if Instr(1, _lI1I11l, _l1d_f60343("6c70765f717e78716d7688d0909798", 84, 53)) > 0 then return RP_ResolveCloudnestra(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("374d4b3d3f53a14e5256", 208, 145)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("75756d818577bf8785", 231, 228)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("f30b0bf7fb0ddd0624", 19, 142)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("2a1a22363a2ce42c29", 15, 177)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("f7ddebfdfff331f4fe10", 104, 217)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("45453a353d434502595f", 8, 199)) > 0 then return RP_ResolveVidsrcXyz(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("96b8aea4a6ba00c0c3", 86, 118)) > 0 then return RP_ResolveVidsrcCc(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("2e4c423b53525d9b5e584a", 244, 172)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("9cbab0aaacc006b1cfb9", 116, 154)) > 0 then return RP_ResolveVidrock(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("d7838e908c90dd9b9e", 197, 224)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("b7e7e2f0f0f4adef0ffd", 15, 122)) > 0 then return RP_Resolve2embed(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("6c6c6f6e7778647c7b29486e898e94", 147, 109)) > 0 then return RP_ResolveLookmovie(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("686953756c61766884c080887488", 246, 205)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("8687a3939aafa4b8a260bda5", 175, 196)) > 0 then return RP_ResolveMoviesapi(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("e0e0d8e0f0e42af8faffeff6fd", 199, 47)) > 0 then return RP_ResolveVidora(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("5e7579756e7973777b", 33, 30)) > 0 then return RP_ResolveAutoembed(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("f4efe3f4f7adfaf404", 166, 22)) > 0 then return RP_ResolveXpass(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("fe09f5040d1507c3db1b2223", 148, 9)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("334644414958574b6158625f5c66606e74326a797e", 162, 115)) > 0 then return RP_ResolveAirflix(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("82a49a9ea596a3efb2b0a2", 118, 130)) > 0 then return RP_ResolveVideasy(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("04f4fcf8fdfb05c1041024", 47, 171)) > 0 then return RP_ResolveVidking(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("afbfc6d58ed0c8de", 59, 109)) > 0 then return RP_ResolveYthd(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("6b7b82837f838779c5828c8c", 126, 93)) > 0 then return RP_ResolvePeachify(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("1d223a413c2d314313534e", 17, 188)) > 0 then return RP_ResolvePrimesrc(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("595f605453626e5c7066", 65, 39)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("fc06031b1a191523611a30", 91, 212)) > 0 then return RP_ResolveStreamtape(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("b9c0c6ccd9d7", 60, 112)) > 0 then return RP_ResolveUqload(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("5c646765", 67, 53)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("93cacdd09f", 253, 250)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("32e9eceff241", 156, 58)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("c8d418ddccd2dd", 107, 185)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("d7cd8fcee0e6eae3", 30, 93)) > 0 then return RP_ResolveDoodstream(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("4e5a679f5f5b", 254, 198)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("eeeae7afeff6fb", 134, 254)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("c2bebbcec6bdce", 2, 78)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("b5bfc803beccd3d0d4dbd6", 249, 38)) > 0 then return RP_ResolveVoe(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("4055455d575367", 253, 182)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("ceccd5c1c8bfe0d4", 205, 16)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("5062645f6b6d6f", 126, 67)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("eadef3f2e803", 227, 90)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("4f433a465a", 175, 115)) > 0 then return RP_ResolveStreamsb(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("7f86987f948c9c", 230, 244)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("ed05fc15fb19", 45, 173)) > 0 then return RP_ResolveMixdrop(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("4125353a364b51fe535846", 41, 226)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("48404052528f5c54", 67, 19)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("b6b1c1bfc1bdccc1bdd1c910d1d9d9e1", 252, 29)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("1f1b1e1e251522ef332131", 52, 192)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("5d6c6671656f713a71818380", 162, 153)) > 0 then return invalid
return RP_ResolveGeneric(_l11I11l, _llII11l, _l1II11l)
end function
function R_FollowKnownIframes(_lI11lIl as String, _l1lIlIl as String, _ll1IlIl as String, _ll11lIl as Integer, _l11IlIl as Object) as Object
if _lI11lIl = invalid or _lI11lIl = "" then return invalid
if _ll11lIl >= 3 then return invalid
_lIlIlIl = CreateObject(_l1d_f60343("9d8dc39d9ea3a9", 106, 133), _l1d_f60343("a5757160768580555bbe64d17c7e92d3", 210, 183) + chr(34) + _l1d_f60343("a2545a", 202, 192) + chr(34) + _l1d_f60343("4cb9be", 83, 62) + chr(34), _l1d_f60343("262f", 93, 242))
_l1I1lIl = _lIlIlIl.matchAll(_lI11lIl)
if _l1I1lIl = invalid then return invalid
for each _lII1lIl in _l1I1lIl
if _lII1lIl.Count() < 2 then continue for
_lIl1lIl = U_AbsUrl(_lII1lIl[1], HC_OriginOf(_l1lIlIl))
if _lIl1lIl = "" then continue for
_l111lIl = R_DispatchByHost(_lIl1lIl, _l1lIlIl, _l11IlIl)
if _l111lIl <> invalid and _l111lIl.url <> invalid and _l111lIl.url <> "" then return _l111lIl
_lllIlIl = HC_Get(_l11IlIl, _lIl1lIl, { "Referer": _l1lIlIl }, 6000)
if _lllIlIl <> invalid and _lllIlIl.body <> "" then
_llI1lIl = R_FollowKnownIframes(_lllIlIl.body, _lIl1lIl, _l1lIlIl, _ll11lIl + 1, _l11IlIl)
if _llI1lIl <> invalid and _llI1lIl.url <> "" then return _llI1lIl
end if
end for
return invalid
end function
function R_FallbackByContentIds(_llllIIl as Object, _lIIlIIl as Object) as Object
if not R_HasContentIds(_llllIIl) then return invalid
_l11lIIl = ""
if _llllIIl.kind <> invalid then _l11lIIl = _llllIIl.kind
_lll1IIl = ""
if _llllIIl.tmdb <> invalid then _lll1IIl = _llllIIl.tmdb
_ll1lIIl = ""
if _llllIIl.imdb <> invalid then _ll1lIIl = _llllIIl.imdb
_l1IlIIl = 1
if _llllIIl.season <> invalid then _l1IlIIl = _llllIIl.season
_lIllIIl = 1
if _llllIIl.episode <> invalid then _lIllIIl = _llllIIl.episode
_llIlIIl = ""
if _llllIIl.refer <> invalid then _llIlIIl = _llllIIl.refer
_l1llIIl = R_BuildFallbackCandidates(_l11lIIl, _lll1IIl, _ll1lIIl, _l1IlIIl, _lIllIIl)
for each _l1l1IIl in _l1llIIl
if _l1l1IIl <> "" then
_lI1lIIl = R_DispatchByHost(_l1l1IIl, _llIlIIl, _lIIlIIl)
if _lI1lIIl <> invalid and _lI1lIIl.url <> invalid and _lI1lIIl.url <> "" then return _lI1lIIl
end if
end for
return invalid
end function
function R_BuildFallbackCandidates(_lIlIll1 as String, _llIIll1 as String, _lllIll1 as String, _l11Ill1 as Integer, _l1I1ll1 as Integer) as Object
_ll1Ill1 = []
_l1lIll1 = (_lIlIll1 <> _l1d_f60343("0b0c", 58, 189))
if _l1lIll1 then
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("0e25282f336f5d603e25333e354f76425155414a455753579462599c6560726e72ae6f74907c83c0", 205, 105) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("756c6f767ab6c4c7858c9a859c96dda9989ca8b1acbebabefbc9c003ccc7d9d5d915d6dbd7e3ea27", 125, 96) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("869598979be7dde095a0aea5aeacc0fafcb2c1c207c0cbc5c9cd19dadfebdfde2b", 97, 125) + _llIIll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("2c13161d1f69797c3d48303f4c54468296565d62a3606b67696bb57a7b65877ec7", 214, 110) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("abb2b5bcc20cfcffcbc2c2ddc4dc13dedcd2d6ddf2fb2beee8fa38f9fe0806fd4a", 100, 159) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("0efd00ff054f676a0e2d252078252034292c8a33513597509d5e634d6362af", 208, 86) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("fde4e7eef4beced1fb190f090b1fe52528ef19e0f8313c3c3a3c0a4b503a584f1c", 180, 33) + _llIIll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("1a292c2b317b737640363446483c8a575b5f97505b53595ba96a6f796f6ecb787f797ad8", 192, 114) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("2f363940408c7a7d49494155594b935b599b5863616165ad72737f7f76bf", 199, 128) + _llIIll1)
else
_lI1Ill1 = _l11Ill1.ToStr()
_lII1ll1 = _l1I1ll1.ToStr()
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("f41316151b554d5024131b262535642a4143313a353d4345824a498c5550585e609e767ba7", 200, 84) + _lllIll1 + _l1d_f60343("de", 27, 170) + _lI1Ill1 + _l1d_f60343("1b", 64, 172) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("e60508070dc7bfc216050d181727d61c3335232c272f3537f43c3bfe47424a505210686d19", 168, 38) + _llIIll1 + _l1d_f60343("a0", 173, 30) + _lI1Ill1 + _l1d_f60343("02", 196, 23) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("271619181ae4fcff38432b424f4f41fd1951606526636e626c6e38646541", 178, 77) + _llIIll1 + _l1d_f60343("5e", 2, 49) + _lI1Ill1 + _l1d_f60343("ae", 198, 197) + _lII1ll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("8c73767d814d5b5e9ba694a3acb2a6607ab8bfc085bec9cbc7cb97c1c6a0", 181, 175) + _lllIll1 + _l1d_f60343("53", 71, 235) + _lI1Ill1 + _l1d_f60343("38", 213, 62) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("5a494c4b4f9bb1b45a796f6a796bca7589898b8a7f88e2a59d91ed979cf6", 241, 193) + _llIIll1 + _l1d_f60343("79", 172, 246) + _lI1Ill1 + _l1d_f60343("9e", 143, 254) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("e7dee1e8e8243235f7fe0cf745fe091b0c0f57141c1e622f68262771", 255, 80) + _llIIll1 + _l1d_f60343("ca", 145, 12) + _lI1Ill1 + _l1d_f60343("4a", 237, 136) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("68676a696f2941447e849284869a58a0a3629c5b6bb4afb7bdbf7db5ba86", 24, 248) + _llIIll1 + _l1d_f60343("53", 22, 26) + _lI1Ill1 + _l1d_f60343("9f", 177, 1) + _lII1ll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("9e95989fa35f6d70acb8c0b8bcce86bbbdc391dad5e7e3e7a3dde29cf1f0fc05a9", 61, 73) + _lllIll1 + _l1d_f60343("9e5461685d646898", 125, 67) + _lI1Ill1 + _l1d_f60343("3d8179937c9391934e", 151, 140) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("ceedf0eff1aba3a600eaf80608fcbafc00c4110c101a1cd63233df", 170, 12) + _llIIll1 + _l1d_f60343("44", 70, 219) + _lI1Ill1 + _l1d_f60343("81", 118, 40) + _lII1ll1)
end if
return _ll1Ill1
end function
function R_HasContentIds(_lI1lIl1 as Object) as Boolean
if _lI1lIl1 = invalid then return false
if _lI1lIl1.tmdb <> invalid and _lI1lIl1.tmdb <> "" then return true
if _lI1lIl1.imdb <> invalid and _lI1lIl1.imdb <> "" then return true
return false
end function
function R_NormalizeResult(_lI1Il11 as Object, _ll1Il11 as String) as Object
if ((19089 - 6363 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l11Il11 = {
url: ""
streamFormat: _l1d_f60343("9291b3", 204, 238)
qualities: []
subtitles: []
chapters: []
referer: ""
userAgent: ""
leadSkip: 0
}
if _lI1Il11 = invalid then return _l11Il11
if _lI1Il11.url <> invalid then _l11Il11.url = _lI1Il11.url
if _lI1Il11.leadSkip <> invalid then _l11Il11.leadSkip = _lI1Il11.leadSkip
if _lI1Il11.streamFormat <> invalid and _lI1Il11.streamFormat <> "" then
_l11Il11.streamFormat = _lI1Il11.streamFormat
else if _l11Il11.url <> "" then
_l11Il11.streamFormat = U_StreamFormat(_l11Il11.url)
end if
if _lI1Il11.qualities <> invalid then _l11Il11.qualities = _lI1Il11.qualities
if _lI1Il11.subtitles <> invalid then _l11Il11.subtitles = _lI1Il11.subtitles
if _lI1Il11.chapters <> invalid then _l11Il11.chapters = _lI1Il11.chapters
if _lI1Il11.referer <> invalid and _lI1Il11.referer <> "" then
_l11Il11.referer = _lI1Il11.referer
else
_l11Il11.referer = _ll1Il11
end if
if _lI1Il11.userAgent <> invalid then _l11Il11.userAgent = _lI1Il11.userAgent
return _l11Il11
end function
function _l1d_f60343(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function