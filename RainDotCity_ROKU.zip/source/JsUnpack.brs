function JU_ToBase(_l1lI1ll as Integer, _lII11ll as Integer) as String
if ((42048 - 4672 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lII11ll < 2 then _lII11ll = 2
if _lII11ll > 62 then _lII11ll = 62
_lllI1ll = _l1d_8bfd24("e4e6eceeeceef4f6040631373937393f414f51575957595f616f71777977797f818f91979fa5a7a5a7adafbdbfc5c7c5c7cdcfdddfe5e7e5e7edeffdff05", 37, 207)
if _l1lI1ll < 0 then _l1lI1ll = 0
if _l1lI1ll < _lII11ll then return Mid(_lllI1ll, _l1lI1ll + 1, 1)
return JU_ToBase(_l1lI1ll \ _lII11ll, _lII11ll) + Mid(_lllI1ll, (_l1lI1ll mod _lII11ll) + 1, 1)
end function
function JU_UnpackPacked(_lII1l1l as String) as String
if _lII1l1l = invalid or _lII1l1l = "" then return ""
_l1lIl1l = CreateObject(_l1d_8bfd24("212947353a3b29", 124, 19), _l1d_8bfd24("07e90d24182a1a1cf8221e273d4b4439474e3d08545959604f1a666b6b63756567436d697288968f84829361675e646c97aea2a083aba9bf", 103, 204), _l1d_8bfd24("2922", 218, 118))
m = _l1lIl1l.match(_lII1l1l)
if m = invalid or m.Count() < 5 then return ""
_l1I1l1l = m[1]
_llIll1l = m[2].ToInt()
_l1Ill1l = m[3].ToInt()
if _llIll1l < 2 then _llIll1l = 2
if _l1Ill1l < 0 then return ""
_lI11l1l = m[4]
_ll11l1l = _lI11l1l.Tokenize(_l1d_8bfd24("bd", 151, 210))
_l111l1l = []
_lll1l1l = ""
_l1l1l1l = 1
while _l1l1l1l <= Len(_lI11l1l)
_lIIll1l = Mid(_lI11l1l, _l1l1l1l, 1)
if _lIIll1l = _l1d_8bfd24("c2", 204, 18) then
_l111l1l.Push(_lll1l1l)
_lll1l1l = ""
else
_lll1l1l = _lll1l1l + _lIIll1l
end if
_l1l1l1l = _l1l1l1l + 1
end while
_l111l1l.Push(_lll1l1l)
_llI1l1l = _l1I1l1l
_lIl1l1l = _l1Ill1l - 1
while _lIl1l1l >= 0
if _lIl1l1l < _l111l1l.Count() then
_lIlIl1l = _l111l1l[_lIl1l1l]
if _lIlIl1l <> "" then
_l11Il1l = JU_ToBase(_lIl1l1l, _llIll1l)
_lllIl1l = _l1d_8bfd24("2320", 191, 64) + _l11Il1l + _l1d_8bfd24("f8dd", 243, 73)
_ll1Il1l = CreateObject(_l1d_8bfd24("dfffc5ff0005fb", 210, 63), _lllIl1l, _l1d_8bfd24("ef", 228, 108))
_llI1l1l = _ll1Il1l.replaceAll(_llI1l1l, _lIlIl1l)
end if
end if
_lIl1l1l = _lIl1l1l - 1
end while
return _llI1l1l
end function
function _l1d_8bfd24(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function