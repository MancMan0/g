function U_Trim(_lllI1ll as String) as String
if ((23004 - 7668 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lllI1ll = invalid then return ""
_lII11ll = CreateObject(_l1d_444dfc("32481844494a4a", 85, 11), _l1d_444dfc("72735b065c7f671220", 169, 123), _l1d_444dfc("8f", 219, 211))
return _lII11ll.replaceAll(_lllI1ll, "")
end function
function U_HtmlDecode(_lIl1l1l as String) as String
if ((7680 - 2560 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lIl1l1l = invalid or _lIl1l1l = "" then return ""
_lll1l1l = _lIl1l1l
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("3072816731", 146, 124), _l1d_444dfc("69", 214, 121))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("878d83839091", 87, 22), _l1d_444dfc("7b", 88, 252))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("ceccbfcccd", 179, 57), _l1d_444dfc("a4", 201, 182))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("82c6dac2e19c", 173, 247), _l1d_444dfc("f4", 163, 112))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("99cfceebd3a5", 52, 135), chr(34))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("24f1dc20", 211, 47), _l1d_444dfc("ce", 61, 205))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("96d8eea2", 139, 233), _l1d_444dfc("14", 166, 124))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("733e35292d77", 210, 127), _l1d_444dfc("22", 90, 168))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("d91a221c1f2721db", 30, 161), _l1d_444dfc("c9cccf", 123, 116))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("60aea8b0a1bd6f", 182, 208), _l1d_444dfc("ba", 160, 45))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("fcb7c4ccddc91b", 78, 148), _l1d_444dfc("67", 217, 115))
_l1l1l1l = CreateObject(_l1d_444dfc("6b635163646987", 134, 119), _l1d_444dfc("7e867eadc8daa389a5e097ac", 12, 84), _l1d_444dfc("74", 11, 8))
_llIll1l = _l1l1l1l.matchAll(_lll1l1l)
if _llIll1l <> invalid then
for each _l1Ill1l in _llIll1l
_lIIll1l = _l1Ill1l[1].ToInt()
if _lIIll1l > 0 and _lIIll1l < 1114112 then
_lll1l1l = _lll1l1l.Replace(_l1Ill1l[0], chr(_lIIll1l))
end if
end for
end if
return _lll1l1l
end function
function U_StripTags(_lI1I11l as String) as String
if _lI1I11l = invalid then return ""
_l11I11l = CreateObject(_l1d_444dfc("4e4c74484d4e66", 161, 123), _l1d_444dfc("f7999f02a4f50b", 64, 123), _l1d_444dfc("6c", 153, 110))
return U_Trim(_l11I11l.replaceAll(_lI1I11l, ""))
end function
function U_FirstMatch(_lIl1lIl as String, _ll11lIl as String) as String
_l111lIl = CreateObject(_l1d_444dfc("c2d2a8dee3e4ca", 24, 88), _ll11lIl, _l1d_444dfc("fde6", 147, 3))
m = _l111lIl.match(_lIl1lIl)
if m <> invalid and m.Count() >= 2 then return m[1]
return ""
end function
function U_AllMatches(_llllIIl as String, _lIllIIl as String) as Object
if ((8080 - 1010 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_ll1lIIl = CreateObject(_l1d_444dfc("6c7a528a8b9078", 91, 67), _lIllIIl, _l1d_444dfc("f801", 227, 110))
_l1llIIl = []
m = _ll1lIIl.matchAll(_llllIIl)
if m = invalid then return _l1llIIl
return m
end function
function U_UrlEncode(_lII1ll1 as String) as String
if _lII1ll1 = invalid then return ""
_l1I1ll1 = CreateObject(_l1d_444dfc("34541d3d5a2546586850666858", 144, 82))
return _l1I1ll1.escape(_lII1ll1)
end function
function U_AbsUrl(_l1IlIl1 as String, _lI1lIl1 as String) as String
if _l1IlIl1 = invalid or _l1IlIl1 = "" then return ""
_llIlIl1 = U_Trim(_l1IlIl1)
if Left(_llIlIl1, 4) = _l1d_444dfc("30474a51", 45, 235) then return _llIlIl1
if Left(_llIlIl1, 2) = _l1d_444dfc("4e51", 94, 221) then return _l1d_444dfc("fcebeeedef39", 82, 194) + _llIlIl1
if Left(_llIlIl1, 1) = _l1d_444dfc("c7", 57, 177) then return _lI1lIl1 + _llIlIl1
return _lI1lIl1 + _l1d_444dfc("5e", 1, 48) + _llIlIl1
end function
function U_TmdbImage(_lI1Il11 as String, _l11Il11 as String) as String
if ((26022 - 4337 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lI1Il11 = invalid or _lI1Il11 = "" then return ""
_ll1Il11 = CreateObject(_l1d_444dfc("7d93a38f949595", 53, 54), _l1d_444dfc("61685f646943b4617d777455c68a7088d37fd981df6e74e87dea", 82, 38), _l1d_444dfc("04", 225, 124))
if _l11Il11 = "" then _l11Il11 = _l1d_444dfc("c4091114", 223, 28)
return _ll1Il11.replace(_lI1Il11, _l1d_444dfc("4746454647955e58545da4667664af79b583bb", 69, 27) + _l11Il11)
end function
function U_DefaultPoster() as String
return _l1d_444dfc("a493969597e1f9fcbdc4bbc0c50dbad6d0cd1ce0c6de29d52fd735e025232644", 242, 10)
end function
function U_LooksHls(_llll1I1 as String) as Boolean
if _llll1I1 = invalid then return false
_lIIIlI1 = LCase(_llll1I1)
return Instr(1, _lIIIlI1, _l1d_444dfc("a3e78cd59d", 51, 134)) > 0 or Instr(1, _lIIIlI1, _l1d_444dfc("af797894bb", 239, 239)) > 0
end function
function U_LooksMp4(_llI1II1 as String) as Boolean
if ((53424 - 5936 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _llI1II1 = invalid then return false
return Instr(1, LCase(_llI1II1), _l1d_444dfc("d41830f7", 171, 79)) > 0
end function
function U_StreamFormat(_l11l1lI as String) as String
if U_LooksHls(_l11l1lI) then return _l1d_444dfc("4b4a56", 71, 28)
if U_LooksMp4(_l11l1lI) then return _l1d_444dfc("e2daa1", 25, 110)
if Instr(1, LCase(_l11l1lI), _l1d_444dfc("2f758b82", 138, 139)) > 0 then return _l1d_444dfc("39394a46", 2, 211)
return _l1d_444dfc("706f8f", 45, 43)
end function
function U_DefaultResolverUrl() as String
return ""
end function
function U_ClientId() as String
if ((14898 - 4966 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1l111I = CreateObject(_l1d_444dfc("9494ac90a49a979cc3aba6b2", 96, 130))
if _l1l111I <> invalid then
_lll111I = _l1l111I.GetChannelClientId()
if _lll111I <> invalid and _lll111I <> "" then return _lll111I
end if
_ll1111I = CreateObject(_l1d_444dfc("9b9981999aa3acb6b3bf98b1aec8bec3c7", 67, 106), _l1d_444dfc("afe3eeecc9f1dfd300e8f6", 151, 234))
if _ll1111I.Exists(_l1d_444dfc("1a1a1a29213e4634", 106, 17)) then return _ll1111I.Read(_l1d_444dfc("000e0c0b1922f818", 193, 94))
_lIl111I = CreateObject(_l1d_444dfc("0f05df011713100dfc1e1923", 133, 24)).GetRandomUUID()
if _lIl111I = invalid or _lIl111I = "" then _lIl111I = _l1d_444dfc("5e6e6d6e39", 26, 246) + CreateObject(_l1d_444dfc("bba1cfb5c5b7ebb9b8c3", 47, 94)).AsSeconds().ToStr()
_ll1111I.Write(_l1d_444dfc("010d0d0c1821f917", 64, 222), _lIl111I)
_ll1111I.Flush()
return _lIl111I
end function
function U_PrefDefault(_lIIII1I as String, _l1III1I as Dynamic) as Dynamic
_l1lllII = CreateObject(_l1d_444dfc("b0aed6aaafb4c1c7c8d0edc2c3d9cfd8dc", 161, 221), _l1d_444dfc("24f4ff09220e1828112127", 225, 113))
if _l1lllII.Exists(_lIIII1I) then
_lIlllII = _l1lllII.Read(_lIIII1I)
if type(_l1III1I) = _l1d_444dfc("ec14171b171e22", 134, 40) then
return _lIlllII = _l1d_444dfc("78757f72", 170, 154)
else if type(_l1III1I) = _l1d_444dfc("f4dec7d9dedfd1", 177, 252) or type(_l1III1I) = _l1d_444dfc("b09e7fa5c2", 75, 119) then
return _lIlllII.ToInt()
end if
return _lIlllII
else
_lllllII = CreateObject(_l1d_444dfc("374f1d4f50614a4a4f5d36676c5c7c797b", 150, 83), _l1d_444dfc("a7b9d1c6dab6bd", 223, 16))
if _lllllII.Exists(_lIIII1I) then
_lIlllII = _lllllII.Read(_lIIII1I)
_l1lllII.Write(_lIIII1I, _lIlllII)
_l1lllII.Flush()
if type(_l1III1I) = _l1d_444dfc("b096999f99a0a6", 39, 75) then
return _lIlllII = _l1d_444dfc("393a4053", 176, 117)
else if type(_l1III1I) = _l1d_444dfc("caaac3b7bcbdd5", 236, 37) or type(_l1III1I) = _l1d_444dfc("f4fce101fa", 156, 6) then
return _lIlllII.ToInt()
end if
return _lIlllII
end if
end if
return _l1III1I
end function
sub U_PrefSet(_lI111II as String, _l1I11II as Dynamic)
if ((26404 - 6601 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_llI11II = CreateObject(_l1d_444dfc("6e6654626774817d86906d7a838f8f9092", 132, 120), _l1d_444dfc("849893917e96b488a5bdbb", 15, 39))
_llI11II.Write(_lI111II, _l1I11II.ToStr())
_llI11II.Flush()
end sub
sub U_BumpCellFavorite(_ll1llll as Object)
if _ll1llll = invalid then return
if not _ll1llll.hasField(_l1d_444dfc("f3fd09e012fd1b", 206, 75)) then
_ll1llll.addField(_l1d_444dfc("bbb9d1e0d6c1d7", 40, 109), _l1d_444dfc("4a503d4f505543", 179, 112), true)
end if
_l11llll = _ll1llll.favBump
if _l11llll = invalid then _l11llll = 0
_ll1llll.favBump = _l11llll + 1
end sub
sub U_SetCellKind(_l1lI1ll as Object, _lIlI1ll as String)
if _l1lI1ll = invalid then return
if not _l1lI1ll.hasField(_l1d_444dfc("eaebf3ec", 112, 207)) then _l1lI1ll.addField(_l1d_444dfc("dddee6ef", 216, 42), _l1d_444dfc("aeb2b3bdc5d1", 120, 163), false)
_l1lI1ll.kind = _lIlI1ll
end sub
function U_GetCellKind(_lIIll1l as Object) as String
if ((38436 - 9609 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lIIll1l = invalid then return ""
if not _lIIll1l.hasField(_l1d_444dfc("989d9ba8", 79, 116)) then return ""
_lll1l1l = _lIIll1l.kind
if _lll1l1l = invalid then return ""
if Type(_lll1l1l) = _l1d_444dfc("c3dfe8d2d2de", 204, 36) or Type(_lll1l1l) = _l1d_444dfc("c7afeeced3c1bdc9", 46, 107) then return _lll1l1l
return ""
end function
sub U_SetCellPct(_llII11l as Object, _l1II11l as Integer)
if _llII11l = invalid then return
if not _llII11l.hasField(_l1d_444dfc("b2c6bca0cdc5d5dfdde1", 17, 81)) then _llII11l.addField(_l1d_444dfc("eadeecd0e5f5edf7edf1", 197, 53), _l1d_444dfc("080a23151a1b35", 77, 228), false)
_llII11l.pctWatched = _l1II11l
end sub
sub U_BumpAllCellsByUrl(_lI11lIl as Object, _lllIlIl as String)
if _lI11lIl = invalid or _lllIlIl = invalid or _lllIlIl = "" then return
_lII1lIl = _lI11lIl.getChildCount()
if _lII1lIl <= 0 then return
for _l1I1lIl = 0 to _lII1lIl - 1
_l111lIl = _lI11lIl.getChild(_l1I1lIl)
if _l111lIl <> invalid then
_llI1lIl = _l111lIl.url
if _llI1lIl <> invalid and _llI1lIl = _lllIlIl then
U_BumpCellFavorite(_l111lIl)
end if
if _l111lIl.getChildCount() > 0 then
U_BumpAllCellsByUrl(_l111lIl, _lllIlIl)
end if
end if
end for
end sub
function U_ToggleFavoriteForCell(_lIllIIl as Object, _ll1lIIl as Object) as Boolean
if _lIllIIl = invalid then return false
_l11lIIl = ""
if _lIllIIl.url <> invalid then _l11lIIl = _lIllIIl.url
if _l11lIIl = "" then return false
_l1IlIIl = ""
if _lIllIIl.title <> invalid then _l1IlIIl = _lIllIIl.title
_llIlIIl = ""
if _lIllIIl.HDPosterUrl <> invalid then _llIlIIl = _lIllIIl.HDPosterUrl
_lIIlIIl = ""
if _lIllIIl.id <> invalid then _lIIlIIl = _lIllIIl.id
_lI1lIIl = U_GetCellKind(_lIllIIl)
if W_IsFavorite("", _l11lIIl) then
W_RemoveFavorite("", _l11lIIl)
else
W_AddFavorite({
title:  _l1IlIIl
poster: _llIlIIl
href:   _l11lIIl
imdb:   ""
tmdb:   _lIIlIIl
kind:   _lI1lIIl
})
end if
U_BumpAllCellsByUrl(_ll1lIIl, _l11lIIl)
return true
end function
function _l1d_444dfc(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function