function HM_FetchQualities(_l11I1ll as String, _l1lI1ll as String, _ll1I1ll as Object) as Object
_lllI1ll = []
if _l11I1ll = invalid or _l11I1ll = "" then return _lllI1ll
if Instr(1, LCase(_l11I1ll), _l1d_f60394("ba00dd1edc", 142, 26)) = 0 then return _lllI1ll
_lII11ll = {}
if _l1lI1ll <> "" then _lII11ll[_l1d_f60394("e6dae0e0d2e6d8", 49, 131)] = _l1lI1ll
_lIlI1ll = HC_Get(_ll1I1ll, _l11I1ll, _lII11ll, 6000)
if _lIlI1ll = invalid or _lIlI1ll.body = "" then return _lllI1ll
if Instr(1, _lIlI1ll.body, _l1d_f60394("07ecd4e30ddd13ecf2f30706052807111c", 121, 173)) = 0 then return _lllI1ll
return HM_ParseMasterPlaylist(_lIlI1ll.body, _l11I1ll)
end function
function HM_ParseMasterPlaylist(_ll1Il1l as String, _l1Ill1l as String) as Object
_lllIl1l = []
if _ll1Il1l = invalid or _ll1Il1l = "" then return _lllIl1l
_l1I1l1l = _ll1Il1l.Tokenize(chr(10))
if _l1I1l1l = invalid then return _lllIl1l
_lII1l1l = _l1I1l1l.Count()
for _l111l1l = 0 to _lII1l1l - 1
line = _l1I1l1l[_l111l1l]
if Left(line, 17) <> _l1d_f60394("4cf1d7e652e058f1f5f60c0b0a6d0c141f", 216, 81) then continue for
_llIll1l = HM_ParseAttrs(line)
_lIIll1l = 0
if _llIll1l.BANDWIDTH <> invalid then _lIIll1l = _llIll1l.BANDWIDTH.ToInt()
_ll11l1l = 0
_lIlIl1l = ""
if _llIll1l.RESOLUTION <> invalid then _lIlIl1l = _llIll1l.RESOLUTION
if _lIlIl1l <> "" then
_lI1Il1l = Instr(1, _lIlIl1l, _l1d_f60394("4e", 172, 122))
if _lI1Il1l > 0 and _lI1Il1l < Len(_lIlIl1l) then
_ll11l1l = Mid(_lIlIl1l, _lI1Il1l + 1).ToInt()
end if
end if
_l11Il1l = ""
for _lI11l1l = _l111l1l + 1 to _lII1l1l - 1
_lll1l1l = U_Trim(_l1I1l1l[_lI11l1l])
if _lll1l1l = "" then continue for
if Left(_lll1l1l, 1) = _l1d_f60394("b4", 47, 168) then continue for
_l11Il1l = _lll1l1l
exit for
end for
if _l11Il1l = "" then continue for
_l11Il1l = RP_AbsUrl(_l11Il1l, _l1Ill1l)
_llI1l1l = _l1d_f60394("f0c8dac6d1c7e4", 47, 119)
if _ll11l1l > 0 then
_llI1l1l = _ll11l1l.ToStr() + _l1d_f60394("56", 255, 199)
else if _lIIll1l > 0 then
_llI1l1l = (_lIIll1l \ 1000).ToStr() + _l1d_f60394("cfdbf0f0", 171, 15)
end if
_lllIl1l.Push({
label: _llI1l1l
height: _ll11l1l
bandwidth: _lIIll1l
url: _l11Il1l
})
end for
for _l111l1l = 1 to _lllIl1l.Count() - 1
_l1l1l1l = _lllIl1l[_l111l1l]
_lIl1l1l = _l1l1l1l.height
if _lIl1l1l = invalid then _lIl1l1l = 0
_lI11l1l = _l111l1l - 1
while _lI11l1l >= 0
_l1lIl1l = _lllIl1l[_lI11l1l].height
if _l1lIl1l = invalid then _l1lIl1l = 0
if _l1lIl1l >= _lIl1l1l then exit while
_lllIl1l[_lI11l1l + 1] = _lllIl1l[_lI11l1l]
_lI11l1l = _lI11l1l - 1
end while
_lllIl1l[_lI11l1l + 1] = _l1l1l1l
end for
return _lllIl1l
end function
function HM_ParseAttrs(line as String) as Object
_llII11l = {}
if line = invalid or line = "" then return _llII11l
_lIII11l = CreateObject(_l1d_f60394("7371596d72738b", 129, 128), _l1d_f60394("84fae38a029b93aa990ca5a6b5ab", 36, 120) + chr(34) + _l1d_f60394("8d93", 200, 250) + chr(34) + _l1d_f60394("fb49", 195, 93) + chr(34) + _l1d_f60394("b7dfdf10e21c1c", 245, 46), _l1d_f60394("0e", 221, 84))
_lI1I11l = _lIII11l.matchAll(line)
if _lI1I11l = invalid then return _llII11l
for each _l1II11l in _lI1I11l
if _l1II11l.Count() < 3 then continue for
_l11I11l = _l1II11l[1]
_llllI1l = _l1II11l[2]
if Len(_llllI1l) >= 2 and Left(_llllI1l, 1) = chr(34) and Right(_llllI1l, 1) = chr(34) then
_llllI1l = Mid(_llllI1l, 2, Len(_llllI1l) - 2)
end if
_llII11l[_l11I11l] = _llllI1l
end for
return _llII11l
end function
function HM_CoerceKind(_lIl1lIl as String) as String
if _lIl1lIl = invalid or _lIl1lIl = "" then return ""
_ll11lIl = LCase(_lIl1lIl)
if Instr(1, _ll11lIl, _l1d_f60394("a9a9a2abb3", 60, 84)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("a28aa2aaacb0ac", 50, 69)) > 0 then return _l1d_f60394("0d0f182117", 197, 97)
if Instr(1, _ll11lIl, _l1d_f60394("6582868b71", 79, 69)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("41334547573d", 118, 44)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("0e16131b1f1b", 34, 199)) > 0 then return _l1d_f60394("aea7abacba", 57, 88)
if Instr(1, _ll11lIl, _l1d_f60394("c4bebbc0d2", 138, 204)) > 0 then return _l1d_f60394("28181d2236", 39, 211)
return ""
end function
function HM_ExtractChaptersHtml(_l1llIIl as String) as Object
_llIlIIl = []
if _l1llIIl = invalid or _l1llIIl = "" then return _llIlIIl
_lll1IIl = {}
_ll1lIIl = CreateObject(_l1d_f60394("08f02efc010210", 44, 170), chr(34) + _l1d_f60394("7c72702c474c369287975b5f4c49695d6f5c5e5b7b6f756781838b7977877c9693988a99ab93abb3b5b9b5b1bdc5c2caceca13", 114, 34) + chr(34) + _l1d_f60394("cdb56174d9c16de2c2e8d07c", 41, 88) + chr(34) + _l1d_f60394("66627a6e6b", 148, 127) + chr(34) + _l1d_f60394("09f7c1b41503cdd2211cdadeccd233e43934f2f7e4fd4b39030457450f", 62, 167) + chr(34) + _l1d_f60394("36423b", 116, 37) + chr(34) + _l1d_f60394("0d37617419436d6e25407a7a9492378c3d589293ac99", 72, 249), _l1d_f60394("1425", 104, 19))
_lIllIIl = _ll1lIIl.matchAll(_l1llIIl)
if _lIllIIl <> invalid then
for each _lI1lIIl in _lIllIIl
if _lI1lIIl.Count() < 4 then continue for
_l11lIIl = HM_CoerceKind(_lI1lIIl[1])
if _l11lIIl = "" or _lll1IIl.DoesExist(_l11lIIl) then continue for
_l1l1IIl = _lI1lIIl[2].ToFloat()
_llllIIl = _lI1lIIl[3].ToFloat()
if _llllIIl > _l1l1IIl then
_llIlIIl.Push({ kind: _l11lIIl, start: _l1l1IIl, end: _llllIIl })
_lll1IIl[_l11lIIl] = true
end if
end for
end if
_l1IlIIl = CreateObject(_l1d_f60394("251b4b1b1c2141", 103, 16), _l1d_f60394("5d2125423f2f433552545141554b5d5759516f6d6d726c696e807f718981797b7f8b97938b989094a0d98a9195e99cfdc4ccbcccd5ab", 202, 123) + chr(34) + _l1d_f60394("ac84505468ba6b6dc4af77797171d68bdcc78f908996ebf1c9f7effcdd97b69fa0a3f1b6c4bcbc21b7d2272e30e235da23312a42", 177, 191) + chr(34) + _l1d_f60394("c6aae6eee2d4e1e7deb9edf30707f001f6d1050a1f10", 107, 143), _l1d_f60394("ff0c", 219, 77))
_lIIlIIl = _l1IlIIl.matchAll(_l1llIIl)
if _lIIlIIl <> invalid then
for each _lI1lIIl in _lIIlIIl
if _lI1lIIl.Count() < 4 then continue for
_l11lIIl = HM_CoerceKind(_lI1lIIl[1])
if _l11lIIl = "" or _lll1IIl.DoesExist(_l11lIIl) then continue for
_l1l1IIl = _lI1lIIl[2].ToFloat()
_llllIIl = _lI1lIIl[3].ToFloat()
if _llllIIl > _l1l1IIl then
_llIlIIl.Push({ kind: _l11lIIl, start: _l1l1IIl, end: _llllIIl })
_lll1IIl[_l11lIIl] = true
end if
end for
end if
return _llIlIIl
end function
function HM_ExtractChaptersHls(_l1Il1l1 as String, _llll1l1 as String, _l11l1l1 as Object) as Object
if ((42896 - 6128 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lIIIll1 = []
if _l1Il1l1 = invalid or _l1Il1l1 = "" then return _lIIIll1
_l11Ill1 = {}
if _llll1l1 <> "" then _l11Ill1[_l1d_f60394("986a6a7084768a", 102, 100)] = _llll1l1
_l1ll1l1 = HC_Get(_l11l1l1, _l1Il1l1, _l11Ill1, 6000)
if _l1ll1l1 = invalid or _l1ll1l1.body = "" then return _lIIIll1
_lIIl1l1 = _l1ll1l1.body
if Instr(1, _lIIl1l1, _l1d_f60394("0c31292822322844423a4c3e4e605a5b", 17, 218)) = 0 then
if Instr(1, _lIIl1l1, _l1d_f60394("2708f6fd29ff2f0c0c11232a21442b2732", 126, 202)) = 0 then return _lIIIll1
_ll1Ill1 = ""
_l1IIll1 = _lIIl1l1.Tokenize(chr(10))
if _l1IIll1 = invalid then return _lIIIll1
for _lI1Ill1 = 0 to _l1IIll1.Count() - 1
_lII1ll1 = U_Trim(_l1IIll1[_lI1Ill1])
if _lII1ll1 = "" or Left(_lII1ll1, 1) = _l1d_f60394("8d", 30, 80) then continue for
_ll1Ill1 = _lII1ll1
exit for
end for
if _ll1Ill1 = "" then return _lIIIll1
_ll1Ill1 = RP_AbsUrl(_ll1Ill1, _l1Il1l1)
_lIll1l1 = HC_Get(_l11l1l1, _ll1Ill1, _l11Ill1, 6000)
if _lIll1l1 = invalid or _lIll1l1.body = "" then return _lIIIll1
_lIIl1l1 = _lIll1l1.body
if Instr(1, _lIIl1l1, _l1d_f60394("2c51696842724864627a6c7e6e807a7b", 129, 138)) = 0 then return _lIIIll1
end if
_ll1l1l1 = {}
_l1IIll1 = _lIIl1l1.Tokenize(chr(10))
if _l1IIll1 = invalid then return _lIIIll1
for _lI1Ill1 = 0 to _l1IIll1.Count() - 1
line = _l1IIll1[_lI1Ill1]
if Left(line, 16) <> _l1d_f60394("82dfedf480f686f0f806fa1204fc0809", 44, 115) then continue for
_l1I1ll1 = HM_ParseAttrs(line)
_lllIll1 = ""
if _l1I1ll1.CLASS <> invalid then _lllIll1 = _l1I1ll1.CLASS
_llIIll1 = HM_CoerceKind(_lllIll1)
if _llIIll1 = "" and _l1I1ll1.ID <> invalid then _llIIll1 = HM_CoerceKind(_l1I1ll1.ID)
if _llIIll1 = "" or _ll1l1l1.DoesExist(_llIIll1) then continue for
_lI1l1l1 = ""
if _l1I1ll1.X_START <> invalid then _lI1l1l1 = _l1I1ll1.X_START
if _lI1l1l1 = "" and _l1I1ll1[_l1d_f60394("11c1221e362a27", 188, 45)] <> invalid then _lI1l1l1 = _l1I1ll1[_l1d_f60394("8f5d9a9c92a4a5", 15, 56)]
if _lI1l1l1 = "" and _l1I1ll1[_l1d_f60394("d361d2c9ca6dd4d6eff8de7f00fef40a07", 45, 94)] <> invalid then _lI1l1l1 = _l1I1ll1[_l1d_f60394("6f258e8d8e31909a9394a2439ca2b0a6ab", 57, 14)]
_llIl1l1 = 0.0
if _lI1l1l1 <> "" then _llIl1l1 = _lI1l1l1.ToFloat()
_l1lIll1 = ""
if _l1I1ll1[_l1d_f60394("f929041009", 116, 205)] <> invalid then _l1lIll1 = _l1I1ll1[_l1d_f60394("03731e1a23", 220, 127)]
if _l1lIll1 = "" and _l1I1ll1[_l1d_f60394("e37bd4e3e487e6eef7f8f899f400f9", 32, 107)] <> invalid then _l1lIll1 = _l1I1ll1[_l1d_f60394("5a704554597c5b616e6b698e697370", 99, 31)]
_lIlIll1 = 0.0
if _l1lIll1 <> "" then
_lIlIll1 = _l1lIll1.ToFloat()
else if _l1I1ll1.DURATION <> invalid then
_lIlIll1 = _llIl1l1 + _l1I1ll1.DURATION.ToFloat()
end if
if _lIlIll1 > _llIl1l1 then
_lIIIll1.Push({ kind: _llIIll1, start: _llIl1l1, end: _lIlIll1 })
_ll1l1l1[_llIIll1] = true
end if
end for
return _lIIIll1
end function
function HM_ExtractSubsHls(_lllIIl1 as String, _lI11Il1 as String, _lII1Il1 as Object) as Object
if ((29320 - 5864 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l111Il1 = []
if _lllIIl1 = invalid or _lllIIl1 = "" then return _l111Il1
if Instr(1, LCase(_lllIIl1), _l1d_f60394("bdffd81dd3", 8, 151)) = 0 then return _l111Il1
_lIIlIl1 = {}
if _lI11Il1 <> "" then _lIIlIl1[_l1d_f60394("e31115170f1d15", 92, 213)] = _lI11Il1
_llI1Il1 = HC_Get(_lII1Il1, _lllIIl1, _lIIlIl1, 6000)
if _llI1Il1 = invalid or _llI1Il1.body = "" then return _l111Il1
_l1lIIl1 = _llI1Il1.body
if Instr(1, _l1lIIl1, _l1d_f60394("acb4aea661babfafc4bccac5c1d2", 160, 184)) = 0 then return _l111Il1
_lIl1Il1 = _l1lIIl1.Tokenize(chr(10))
if _lIl1Il1 = invalid then return _l111Il1
_l1I1Il1 = {}
for _lll1Il1 = 0 to _lIl1Il1.Count() - 1
line = U_Trim(_lIl1Il1[_lll1Il1])
if Left(line, 12) <> _l1d_f60394("e07d9d94eea6f4979296a49f", 69, 122) then continue for
if Instr(1, line, _l1d_f60394("2b312d435e333c4a435949645e4b", 243, 132)) = 0 then continue for
_llIlIl1 = HM_ParseAttrs(line)
_lIlIIl1 = ""
if _llIlIl1.URI <> invalid then _lIlIIl1 = _llIlIl1.URI
if _lIlIIl1 = "" then continue for
_lI1lIl1 = RP_AbsUrl(_lIlIIl1, _lllIIl1)
_l1IlIl1 = HM_ResolveSubPlaylist(_lI1lIl1, _lI11Il1, _lII1Il1)
if _l1IlIl1 = "" then continue for
_l1l1Il1 = _l1d_f60394("9a96", 72, 109)
if _llIlIl1.LANGUAGE <> invalid then _l1l1Il1 = LCase(_llIlIl1.LANGUAGE)
_ll11Il1 = ""
if _llIlIl1.NAME <> invalid then _ll11Il1 = _llIlIl1.NAME
if _ll11Il1 = "" then _ll11Il1 = UCase(_l1l1Il1)
if _l1I1Il1.DoesExist(_l1IlIl1) then continue for
_l1I1Il1[_l1IlIl1] = true
_l111Il1.Push({
url: _l1IlIl1
language: _l1l1Il1
name: _ll11Il1
})
end for
return _l111Il1
end function
function HM_ResolveSubPlaylist(_lIll111 as String, _lIIIl11 as String, _l1ll111 as Object) as String
if ((40248 - 4472 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lIll111 = invalid or _lIll111 = "" then return ""
_llIIl11 = LCase(_lIll111)
if Instr(1, _llIIl11, _l1d_f60394("97e2e7ea", 166, 15)) > 0 then return _lIll111
if Instr(1, _llIIl11, _l1d_f60394("a777797a", 102, 95)) > 0 then return _lIll111
if Instr(1, _llIIl11, _l1d_f60394("33734c9149", 9, 12)) = 0 then return _lIll111
_l11Il11 = {}
if _lIIIl11 <> "" then _l11Il11[_l1d_f60394("ae86888c9a92a0", 235, 245)] = _lIIIl11
_llll111 = HC_Get(_l1ll111, _lIll111, _l11Il11, 5000)
if _llll111 = invalid or _llll111.body = "" then return _lIll111
_l1IIl11 = _llll111.body.Tokenize(chr(10))
if _l1IIl11 = invalid then return _lIll111
for _lI1Il11 = 0 to _l1IIl11.Count() - 1
_ll1Il11 = U_Trim(_l1IIl11[_lI1Il11])
if _ll1Il11 = "" or Left(_ll1Il11, 1) = _l1d_f60394("a5", 26, 108) then continue for
return RP_AbsUrl(_ll1Il11, _lIll111)
end for
return _lIll111
end function
function HM_ScrapeSubs(_l1l1I11 as String) as Object
_l1I1I11 = []
if _l1l1I11 = invalid or _l1l1I11 = "" then return _l1I1I11
_lII1I11 = CreateObject(_l1d_f60394("1309f9050a0b2b", 133, 28), _l1d_f60394("28ebdadddcde2d2b4346151b", 242, 78) + chr(34) + _l1d_f60394("12babdc0f228ca23cf24293b4108090c07191b18484b", 76, 167), _l1d_f60394("252e", 220, 112))
_lI11I11 = _lII1I11.matchAll(_l1l1I11)
if _lI11I11 = invalid then return _l1I1I11
_lllII11 = {}
for each _llI1I11 in _lI11I11
if _llI1I11.Count() < 2 then continue for
_l1lII11 = _llI1I11[1]
if _lllII11.DoesExist(_l1lII11) then continue for
_lllII11[_l1lII11] = true
_lIl1I11 = _l1d_f60394("8e86", 58, 47)
_ll11I11 = CreateObject(_l1d_f60394("75659b7176777d", 232, 219), _l1d_f60394("e79ef1a2f5a5f9f2b1e307e8b4f0bf14cbcf21d225", 185, 5), _l1d_f60394("2b", 167, 93))
_l111I11 = _ll11I11.match(_l1lII11)
if _l111I11 <> invalid and _l111I11.Count() >= 2 then _lIl1I11 = LCase(_l111I11[1])
_l1I1I11.Push({ url: _l1lII11, language: _lIl1I11, name: UCase(_lIl1I11) })
end for
return _l1I1I11
end function
function HM_MergeSubs(_l1ll1I1 as Object, _lIIIlI1 as Object) as Object
if ((36954 - 6159 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llll1I1 = []
_ll1l1I1 = {}
if _l1ll1I1 <> invalid and type(_l1ll1I1) = _l1d_f60394("c2e0b9cbcee2dd", 83, 161) then
for each _lIll1I1 in _l1ll1I1
if type(_lIll1I1) <> _l1d_f60394("e0f015eaedfc03fc07fd050517360a0d1f0a", 120, 214) then continue for
if _lIll1I1.url = invalid or _lIll1I1.url = "" then continue for
if _ll1l1I1.DoesExist(_lIll1I1.url) then continue for
_ll1l1I1[_lIll1I1.url] = true
_llll1I1.Push(_lIll1I1)
end for
end if
if _lIIIlI1 <> invalid and type(_lIIIlI1) = _l1d_f60394("a8c0e1b1b4cac5", 118, 164) then
for each _lIll1I1 in _lIIIlI1
if type(_lIll1I1) <> _l1d_f60394("c4cafbcccfd6e5e2edddebe1f51ceef105f0", 191, 247) then continue for
if _lIll1I1.url = invalid or _lIll1I1.url = "" then continue for
if _ll1l1I1.DoesExist(_lIll1I1.url) then continue for
_ll1l1I1[_lIll1I1.url] = true
_llll1I1.Push(_lIll1I1)
end for
end if
return _llll1I1
end function
function HM_FetchFreeSubs(_l1I1II1 as String, _lIlIII1 as String, _lII1II1 as String, _lllIII1 as Integer, _llI1II1 as Integer, _l1lIII1 as Object) as Object
return HM_QueryOpenSubtitles(_l1I1II1, _lII1II1, _lllIII1, _llI1II1, _l1lIII1)
end function
function HM_QueryOpenSubtitles(_lIIl1lI as String, _l1l11lI as String, _lII11lI as Integer, _l1Il1lI as Integer, _l1lI1lI as Object) as Object
_lI111lI = []
if _lIIl1lI = invalid or _lIIl1lI = "" then return _lI111lI
if Left(_lIIl1lI, 2) <> _l1d_f60394("d5d8", 242, 79) then return _lI111lI
_l11l1lI = Mid(_lIIl1lI, 3)
if _l11l1lI = "" then return _lI111lI
if _l1l11lI = _l1d_f60394("6a6f", 60, 34) and _lII11lI > 0 and _l1Il1lI > 0 then
_ll1I1lI = _l1d_f60394("71686b72742e3e417f9186864f9393a39b9b9cb0a1b1a7b2beb379bdbbcb86c5d6ddcde1dd9be8deeae3eaf6fab5", 190, 155) + _l1Il1lI.ToStr() + _l1d_f60394("fd42414d564e5610", 61, 235) + _l11l1lI + _l1d_f60394("acebfc03f4fbffc3", 191, 28) + _lII11lI.ToStr()
else
_ll1I1lI = _l1d_f60394("2f464950508c7a7d5d4d62648d4f715f5977786e7f6d85707a8fb7799987c2a19299ab9d9bd7a09fabb0acb4ee", 79, 8) + _l11l1lI
end if
_l1I11lI = HC_Get(_l1lI1lI, _ll1I1lI, {
"X-User-Agent": _l1d_f60394("3b3c4e595f5b4b4f2d567435404f", 16, 215)
"Accept": _l1d_f60394("b1a3a6adb5c2c3b1c1c2c488cecad1d3", 28, 52)
}, 6000)
if _l1I11lI = invalid or _l1I11lI.body = "" then return _lI111lI
if _l1I11lI.status < 200 or _l1I11lI.status >= 300 then return _lI111lI
_llI11lI = ParseJSON(_l1I11lI.body)
if _llI11lI = invalid or type(_llI11lI) <> _l1d_f60394("0a283d13162621", 241, 135) then return _lI111lI
_lI1I1lI = CreateObject(_l1d_f60394("9886be96979ca4", 107, 127), _l1d_f60394("67c3cab9757dedca81cba48aa100959a97e3e3e3edf4f4acb62500bcc1", 175, 231), _l1d_f60394("f2", 203, 80))
_lllI1lI = {}
for each _llIl1lI in _llI11lI
if type(_llIl1lI) <> _l1d_f60394("09ffe011140b0a17122220261a0133362a45", 71, 212) then continue for
_lIl11lI = ""
if _llIl1lI.SubLanguageID <> invalid then _lIl11lI = LCase(_llIl1lI.SubLanguageID)
if _lIl11lI = "" then continue for
if _lllI1lI.DoesExist(_lIl11lI) then continue for
_lI1l1lI = ""
if _llIl1lI.SubDownloadLink <> invalid then _lI1l1lI = _llIl1lI.SubDownloadLink
if _lI1l1lI = "" then continue for
_ll111lI = _lI1I1lI.match(_lI1l1lI)
if _ll111lI = invalid or _ll111lI.Count() < 3 then continue for
_l11I1lI = _ll111lI[1]
_lIlI1lI = _ll111lI[2]
_llII1lI = _l1d_f60394("20272a3131fdebee3d3e34fb4556584c430d555215541b", 135, 49) + _l11I1lI + _l1d_f60394("500d1b59", 88, 217) + _lIlI1lI + _l1d_f60394("d8b2aeacb2c1afebb7b8bb10d2ceded5dddddde912fdff142e24", 252, 21)
_lll11lI = ""
if _llIl1lI.ISO639 <> invalid then _lll11lI = LCase(_llIl1lI.ISO639)
if _lll11lI = "" then _lll11lI = Left(_lIl11lI, 2)
_l1111lI = ""
if _llIl1lI.LanguageName <> invalid then _l1111lI = _llIl1lI.LanguageName
if _l1111lI = "" then _l1111lI = UCase(_lIl11lI)
_lI111lI.Push({
url: _llII1lI
language: _lll11lI
name: _l1111lI
})
_lllI1lI[_lIl11lI] = true
end for
return _lI111lI
end function
function HM_MergeSubtitles(_lIlIIlI as Object, _ll1IIlI as Object) as Object
if ((36246 - 5178 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1IIIlI = []
_l1lll1I = {}
_lllll1I = {}
if _lIlIIlI = invalid or type(_lIlIIlI) <> _l1d_f60394("89a7c09295a9a4", 179, 200) then _lIlIIlI = []
if _ll1IIlI = invalid or type(_ll1IIlI) <> _l1d_f60394("d6cce9dfe2d2ed", 165, 255) then _ll1IIlI = []
for each _lIIIIlI in _lIlIIlI
if type(_lIIIIlI) <> _l1d_f60394("253b5c2d304746534e3e5c42567d4f526661", 119, 32) then continue for
_lIlll1I = ""
if _lIIIIlI.url <> invalid then _lIlll1I = _lIIIIlI.url
if _lIlll1I = "" then continue for
if _l1lll1I.DoesExist(_lIlll1I) then continue for
_lI1IIlI = ""
if _lIIIIlI.language <> invalid then _lI1IIlI = LCase(_lIIIIlI.language)
_llIIIlI = ""
if _lIIIIlI.name <> invalid then _llIIIlI = LCase(_lIIIIlI.name)
_l11IIlI = _lI1IIlI + _l1d_f60394("79", 182, 175) + _llIIIlI
if _llIIIlI <> "" and _lllll1I.DoesExist(_l11IIlI) then continue for
_l1lll1I[_lIlll1I] = true
if _llIIIlI <> "" then _lllll1I[_l11IIlI] = true
_l1IIIlI.Push(_lIIIIlI)
end for
for each _lIIIIlI in _ll1IIlI
if type(_lIIIIlI) <> _l1d_f60394("151d4e1f22293835402e3e32486f3f425843", 126, 9) then continue for
_lIlll1I = ""
if _lIIIIlI.url <> invalid then _lIlll1I = _lIIIIlI.url
if _lIlll1I = "" then continue for
if _l1lll1I.DoesExist(_lIlll1I) then continue for
_lI1IIlI = ""
if _lIIIIlI.language <> invalid then _lI1IIlI = LCase(_lIIIIlI.language)
_llIIIlI = ""
if _lIIIIlI.name <> invalid then _llIIIlI = LCase(_lIIIIlI.name)
_l11IIlI = _lI1IIlI + _l1d_f60394("ab", 79, 120) + _llIIIlI
if _llIIIlI <> "" and _lllll1I.DoesExist(_l11IIlI) then continue for
_l1lll1I[_lIlll1I] = true
if _llIIIlI <> "" then _lllll1I[_l11IIlI] = true
_l1IIIlI.Push(_lIIIIlI)
end for
return _l1IIIlI
end function
function HM_FetchSkipTimes(_l1l111I as String, _llI111I as String, _lIl111I as String, _l11111I as Integer, _lll111I as Integer, _lI1111I as Object) as Object
_ll1111I = []
if _lIl111I <> _l1d_f60394("3c41", 156, 84) then return _ll1111I
if _lll111I = invalid or _lll111I <= 0 then return _ll1111I
if _l11111I = invalid then _l11111I = 0
_ll1111I = HM_FetchTheIntroDB(_l1l111I, _llI111I, _l11111I, _lll111I, _lI1111I)
if _ll1111I.Count() > 0 then return _ll1111I
_ll1111I = HM_FetchIntroDB(_l1l111I, _l11111I, _lll111I, _lI1111I)
if _ll1111I.Count() > 0 then return _ll1111I
_ll1111I = HM_FetchAniSkipForEpisode(_llI111I, _lll111I, _lI1111I)
return _ll1111I
end function
function HM_FetchTheIntroDB(_lIIII1I as String, _llIllII as String, _l11llII as Integer, _l1III1I as Integer, _lI1llII as Object) as Object
_lllllII = []
if _l11llII <= 0 or _l1III1I <= 0 then return _lllllII
_lIlllII = ""
if _llIllII <> invalid and _llIllII <> "" then
_lIlllII = _l1d_f60394("7a747079af847c56", 165, 169) + U_UrlEncode(_llIllII)
else if _lIIII1I <> invalid and _lIIII1I <> "" then
_lIlllII = _l1d_f60394("a4a3afb89eb3bb85", 13, 64) + U_UrlEncode(_lIIII1I)
else
return _lllllII
end if
_l1IllII = _l1d_f60394("ddcccfced01a3235eee0fc40ed04040b0ffcf919151261250b236e1857773c3739413c79", 242, 67) + _lIlllII + _l1d_f60394("9ccae3e2d3f2f6aa", 19, 103) + _l11llII.ToStr() + _l1d_f60394("6db3c9b5ceb5c1c590", 46, 101) + _l1III1I.ToStr()
_ll1llII = HC_Get(_lI1llII, _l1IllII, {
"Accept": _l1d_f60394("d4e6e9d0d8e1e6f4e4e1e327ed09f0f2", 206, 37)
"User-Agent": _l1d_f60394("dbcdc8c8f1cfc701dad0d09fffe7eee3b0adb5b2", 188, 237)
}, 5000)
if _ll1llII = invalid or _ll1llII.body = "" then return _lllllII
if _ll1llII.status = 204 or _ll1llII.status = 404 then return _lllllII
_l1lllII = ParseJSON(_ll1llII.body)
if _l1lllII = invalid or type(_l1lllII) <> _l1d_f60394("4a306152553c4b48536351675b8274776b76", 239, 173) then return _lllllII
HM_AppendTheIntroDbSegments(_l1lllII.intro,   _l1d_f60394("f1fb141503", 73, 209),  _lllllII)
HM_AppendTheIntroDbSegments(_l1lllII.recap,   _l1d_f60394("122627281c", 17, 175),  _lllllII)
HM_AppendTheIntroDbSegments(_l1lllII.credits, _l1d_f60394("222f31362e", 70, 249),  _lllllII)
return _lllllII
end function
sub HM_AppendTheIntroDbSegments(_lI111II as Dynamic, _lII11II as String, _lllI1II as Object)
if _lI111II = invalid or type(_lI111II) <> _l1d_f60394("68886171748a85", 146, 136) then return
for each _l1lI1II in _lI111II
if type(_l1lI1II) <> _l1d_f60394("e0deb3e8ebeae1eae5fdf305f5d40a0dfd18", 193, 45) then continue for
_lIlI1II = 0
if _l1lI1II.start_ms <> invalid then _lIlI1II = _l1lI1II.start_ms
_llI11II = invalid
if _l1lI1II.end_ms <> invalid then _llI11II = _l1lI1II.end_ms
if _llI11II = invalid then continue for
_ll1I1II = _lIlI1II / 1000.0
_l1I11II = _llI11II / 1000.0
if _l1I11II <= _ll1I1II then continue for
_lllI1II.Push({ kind: _lII11II, start: _ll1I1II, end: _l1I11II })
end for
end sub
function HM_FetchIntroDB(_lI1llll as String, _ll11lll as Integer, _l11llll as Integer, _lI11lll as Object) as Object
_lll1lll = []
if _lI1llll = invalid or _lI1llll = "" then return _lll1lll
if _ll11lll <= 0 or _l11llll <= 0 then return _lll1lll
_l1I1lll = _l1d_f60394("40474a5155a18f924f635d9f63656e776d6770b773878ac2917e838c87959ea6eda2a19da6dcb1a903", 229, 179) + U_UrlEncode(_lI1llll) + _l1d_f60394("2056636a5f767a2a", 149, 109) + _ll11lll.ToStr() + _l1d_f60394("aff5e3ffe8070307c2", 50, 155) + _l11llll.ToStr()
_lIl1lll = HC_Get(_lI11lll, _l1I1lll, {
"Accept": _l1d_f60394("43575a494754556d535c60a2627c6b6f", 201, 155)
"User-Agent": _l1d_f60394("14e6f6e7f72322cc16141300ddc2e4c9", 177, 27)
}, 5000)
if _lIl1lll = invalid or _lIl1lll.body = "" then return _lll1lll
if _lIl1lll.status = 204 or _lIl1lll.status = 404 then return _lll1lll
_l1l1lll = ParseJSON(_lIl1lll.body)
if _l1l1lll = invalid then return _lll1lll
_l1Illll = invalid
if type(_l1l1lll) = _l1d_f60394("8d7d6296998b96", 136, 147) then
_l1Illll = _l1l1lll
else if type(_l1l1lll) = _l1d_f60394("2311362b2e1d241d2840264838574d50404b", 233, 136) then
if _l1l1lll.segments <> invalid and type(_l1l1lll.segments) = _l1d_f60394("292f2032354934", 159, 60) then _l1Illll = _l1l1lll.segments
if _l1Illll = invalid and _l1l1lll.data <> invalid and type(_l1l1lll.data) = _l1d_f60394("b6a68bbfc2b4bf", 72, 124) then _l1Illll = _l1l1lll.data
if _l1Illll = invalid and _l1l1lll.results <> invalid and type(_l1l1lll.results) = _l1d_f60394("dedef7e7eae0fb", 226, 78) then _l1Illll = _l1l1lll.results
end if
if _l1Illll = invalid then return _lll1lll
for each _llIllll in _l1Illll
if type(_llIllll) <> _l1d_f60394("ebe300f5f8efeef7f2000008fa2115180a25", 228, 85) then continue for
_l111lll = ""
if _llIllll.segment_type <> invalid then _l111lll = LCase(_llIllll.segment_type)
if _l111lll = "" and _llIllll.type <> invalid then _l111lll = LCase(_llIllll.type)
_lIIllll = ""
if _l111lll = _l1d_f60394("858b888593", 219, 211) then _lIIllll = _l1d_f60394("59615a5b6b", 24, 232)
if _l111lll = _l1d_f60394("e5fffc01f3", 210, 69) then _lIIllll = _l1d_f60394("16282d3224", 182, 82)
if _l111lll = _l1d_f60394("133032371f", 78, 242) or _l111lll = _l1d_f60394("5b4d5f6171575d", 22, 230) then _lIIllll = _l1d_f60394("a49da1a2b0", 89, 110)
if _lIIllll = "" then continue for
_llI1lll = HM_ParseClockOrSeconds(_llIllll.start_sec)
_ll1llll = HM_ParseClockOrSeconds(_llIllll.end_sec)
if _ll1llll <= _llI1lll then continue for
_lll1lll.Push({ kind: _lIIllll, start: _llI1lll, end: _ll1llll })
end for
return _lll1lll
end function
function HM_ParseClockOrSeconds(_lI1I1ll as Dynamic) as Float
if ((39123 - 4347 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lI1I1ll = invalid then return 0.0
_l11I1ll = type(_lI1I1ll)
if _l11I1ll = _l1d_f60394("aed0d9cbd0d1eb", 5, 98) or _l11I1ll = _l1d_f60394("7684a58b88", 59, 45) or _l11I1ll = _l1d_f60394("664f534840", 241, 175) or _l11I1ll = _l1d_f60394("82689471718292", 175, 165) or _l11I1ll = _l1d_f60394("496760786d79", 220, 177) or _l11I1ll = _l1d_f60394("686e98746d877c86", 189, 153) then
return _lI1I1ll + 0.0
end if
if _l11I1ll = _l1d_f60394("a7838c868682", 228, 240) or _l11I1ll = _l1d_f60394("e9d7cef8f5e1e7f1", 11, 112) then
_ll1I1ll = _lI1I1ll
if _ll1I1ll = "" then return 0.0
if Instr(1, _ll1I1ll, _l1d_f60394("9c", 145, 241)) = 0 then return _ll1I1ll.ToFloat()
_lIlI1ll = _ll1I1ll.Tokenize(_l1d_f60394("ff", 94, 155))
if _lIlI1ll = invalid then return 0.0
_l1lI1ll = _lIlI1ll.Count()
if _l1lI1ll = 3 then
return _lIlI1ll[0].ToFloat() * 3600.0 + _lIlI1ll[1].ToFloat() * 60.0 + _lIlI1ll[2].ToFloat()
else if _l1lI1ll = 2 then
return _lIlI1ll[0].ToFloat() * 60.0 + _lIlI1ll[1].ToFloat()
else
return _ll1I1ll.ToFloat()
end if
end if
return 0.0
end function
function HM_FetchAniSkipForEpisode(_lI11l1l as String, _lIIll1l as Integer, _ll11l1l as Object) as Object
_lIl1l1l = []
if _lI11l1l = invalid or _lI11l1l = "" then return _lIl1l1l
if _lIIll1l <= 0 then return _lIl1l1l
_l111l1l = HM_FetchTitleFromTmdb(_lI11l1l, _l1d_f60394("a5aa", 125, 156), _ll11l1l)
if _l111l1l = "" then return _lIl1l1l
_lll1l1l = HM_LookupMalIdViaJikan(_l111l1l, _ll11l1l)
if _lll1l1l <> "" then
_lIl1l1l = HM_FetchAniSkipByMal(_lll1l1l, _lIIll1l, _ll11l1l)
if _lIl1l1l.Count() > 0 then return _lIl1l1l
end if
_l1l1l1l = HM_LookupMalIdViaAnilist(_l111l1l, _ll11l1l)
if _l1l1l1l <> "" and _l1l1l1l <> _lll1l1l then
_lIl1l1l = HM_FetchAniSkipByMal(_l1l1l1l, _lIIll1l, _ll11l1l)
end if
return _lIl1l1l
end function
function HM_FetchTitleFromTmdb(_lIllI1l as String, _llII11l as String, _l1llI1l as Object) as String
if _lIllI1l = invalid or _lIllI1l = "" then return ""
_lIII11l = _l1d_f60394("4d6c6f6e742e26297172318c72808483989149a290536a59", 40, 13) + _llII11l + _l1d_f60394("a8", 226, 219) + _lIllI1l
_llllI1l = HC_Get(_l1llI1l, _lIII11l, {}, 5000)
if _llllI1l = invalid or _llllI1l.body = "" then return ""
_l1II11l = ParseJSON(_llllI1l.body)
if _l1II11l = invalid or type(_l1II11l) <> _l1d_f60394("b3c3a8bdc0cfd6cfdad0d8d8eac9dde0f2dd", 88, 137) then return ""
if _llII11l = _l1d_f60394("dcdd", 122, 206) then
if _l1II11l.original_name <> invalid and _l1II11l.original_name <> "" then return _l1II11l.original_name
if _l1II11l.name <> invalid then return _l1II11l.name
else
if _l1II11l.original_title <> invalid and _l1II11l.original_title <> "" then return _l1II11l.original_title
if _l1II11l.title <> invalid then return _l1II11l.title
end if
return ""
end function
function HM_LookupMalIdViaJikan(_lllIlIl as String, _lII1lIl as Object) as String
if _lllIlIl = invalid or _lllIlIl = "" then return ""
_l1lIlIl = _l1d_f60394("849b9ea5a7e1d1d4a5b7a3dfa6acadbaaef1b7b8c5fed81d07d8ccd6d5e029fa31", 238, 254) + U_UrlEncode(_lllIlIl) + _l1d_f60394("ef2c2a313030eaf1", 59, 210)
_l1I1lIl = HC_Get(_lII1lIl, _l1lIlIl, { "Accept": _l1d_f60394("1426291018252634242527eb314d3436", 44, 199) }, 5000)
if _l1I1lIl = invalid or _l1I1lIl.body = "" then return ""
_llI1lIl = ParseJSON(_l1I1lIl.body)
if _llI1lIl = invalid or type(_llI1lIl) <> _l1d_f60394("e3cbf8edf0d7e6dfeaf8e800f2190d10020d", 44, 133) then return ""
_lI11lIl = _llI1lIl.data
if _lI11lIl = invalid or type(_lI11lIl) <> _l1d_f60394("6e7465777a8e79", 159, 129) or _lI11lIl.Count() = 0 then return ""
_l111lIl = _lI11lIl[0]
if type(_l111lIl) <> _l1d_f60394("755b487d8067766f7a8a789282699fa2929d", 77, 54) then return ""
if _l111lIl.mal_id = invalid then return ""
return _l111lIl.mal_id.ToStr()
end function
function HM_LookupMalIdViaAnilist(_lIIlIIl as String, _l1IlIIl as Object) as String
if _lIIlIIl = invalid or _lIIlIIl = "" then return ""
_lIllIIl = _l1d_f60394("b2", 159, 206) + chr(34) + _l1d_f60394("cfcee1d7e3", 151, 233) + chr(34) + _l1d_f60394("71", 223, 140) + chr(34) + _l1d_f60394("6b7285777fd3d282cea88e8fa7b1abf0a5dab5b9bfba06b2c7c6bcced80d1aca28d3d9d5eb250d1f1b221d44f90a0a340b1b0d10", 113, 107) + chr(34) + _l1d_f60394("ef", 41, 234) + chr(34) + _l1d_f60394("8e8498828d918692ab", 172, 180) + chr(34) + _l1d_f60394("28ea", 239, 83) + chr(34) + _l1d_f60394("94", 207, 216) + chr(34) + _l1d_f60394("7f", 241, 180) + chr(34) + HM_JsonEscape(_lIIlIIl) + chr(34) + _l1d_f60394("4447", 36, 235)
_llIlIIl = HC_Post(_l1IlIIl, _l1d_f60394("f8070a090dd9cfd20d1d0d211c2626eb1f312d35334046033948", 33, 175), { "Content-Type": _l1d_f60394("1f33361d232c31412f2c30723a543b3f", 111, 17), "Accept": _l1d_f60394("798b8e858d868b99999698dca2aea5a7", 230, 242) }, _lIllIIl, 5000)
if _llIlIIl = invalid or _llIlIIl.body = "" then return ""
_lI1lIIl = ParseJSON(_llIlIIl.body)
if _lI1lIIl = invalid or type(_lI1lIIl) <> _l1d_f60394("e6e4bdeef1f0e7f4ef07fd0bffde10130722", 67, 181) then return ""
_ll1lIIl = _lI1lIIl.data
if _ll1lIIl = invalid or type(_ll1lIIl) <> _l1d_f60394("dbfbd0e5e807fe0702f8100012f105081a15", 80, 185) then return ""
_l11lIIl = _ll1lIIl.Media
if _l11lIIl = invalid or type(_l11lIIl) <> _l1d_f60394("8dadc6979ab9b0bdb8aec6b2c8e7b7bad0cb", 114, 141) then return ""
if _l11lIIl.idMal = invalid then return ""
return _l11lIIl.idMal.ToStr()
end function
function HM_FetchAniSkipByMal(_l11Ill1 as String, _l1lIll1 as Integer, _l1ll1l1 as Object) as Object
_lI1Ill1 = []
if _l11Ill1 = invalid or _l11Ill1 = "" then return _lI1Ill1
_l11l1l1 = _l1d_f60394("f60508070d574f520719155d1323212e292a34752d3c3d824c8b8b524d4e5898625a615c6dac", 64, 206) + _l11Ill1 + _l1d_f60394("c5", 66, 88) + _l1lIll1.ToStr() + _l1d_f60394("e3b1a7b3a9b6d1dafdaec8fdd2c8d4cad7f2fb1ed9dd", 107, 143)
_lIIIll1 = HC_Get(_l1ll1l1, _l11l1l1, { "Accept": _l1d_f60394("889a9d9c9c999ab0a8b1b377b5c1c0c2", 128, 167) }, 5000)
if _lIIIll1 = invalid or _lIIIll1.body = "" then return _lI1Ill1
_llIIll1 = ParseJSON(_lIIIll1.body)
if _llIIll1 = invalid or type(_llIIll1) <> _l1d_f60394("ede300f5f8efeef7f202000afa21171a0a25", 101, 214) then return _lI1Ill1
if _llIIll1.found <> true then return _lI1Ill1
_llll1l1 = _llIIll1.results
if _llll1l1 = invalid or type(_llll1l1) <> _l1d_f60394("bba1cec4c7b7c2", 45, 92) then return _lI1Ill1
for each _l1IIll1 in _llll1l1
if type(_l1IIll1) <> _l1d_f60394("33532c3d405f56635e546c586e4d5d607671", 18, 211) then continue for
_lIlIll1 = _l1IIll1.interval
if _lIlIll1 = invalid or type(_lIlIll1) <> _l1d_f60394("deee13e8ebfa01fa05fb03031534080b1d08", 184, 20) then continue for
_ll1l1l1 = 0.0
_lllIll1 = 0.0
if _lIlIll1.startTime <> invalid then _ll1l1l1 = _lIlIll1.startTime
if _lIlIll1.endTime <> invalid then _lllIll1 = _lIlIll1.endTime
if _lllIll1 <= _ll1l1l1 then continue for
_lIll1l1 = ""
if _l1IIll1.skipType <> invalid then _lIll1l1 = LCase(_l1IIll1.skipType)
_ll1Ill1 = ""
if _lIll1l1 = _l1d_f60394("a08a", 19, 36) then _ll1Ill1 = _l1d_f60394("545c555666", 88, 35)
if _lIll1l1 = _l1d_f60394("f3f7", 195, 77) then _ll1Ill1 = _l1d_f60394("030c10190f", 229, 121)
if _lIll1l1 = _l1d_f60394("acab9dbdbffbbcb4", 250, 21) then _ll1Ill1 = _l1d_f60394("0e0e273018", 76, 233)
if _lIll1l1 = _l1d_f60394("4e4d415f639d686c", 219, 152) then _ll1Ill1 = _l1d_f60394("e3f0f2efef", 130, 246)
if _lIll1l1 = _l1d_f60394("283a3f4436", 190, 92) then _ll1Ill1 = _l1d_f60394("405455564a", 81, 29)
if _ll1Ill1 = "" then continue for
_lI1Ill1.Push({ kind: _ll1Ill1, start: _ll1l1l1, end: _lllIll1 })
end for
return _lI1Ill1
end function
function HM_JsonEscape(_l111Il1 as String) as String
if _l111Il1 = invalid or _l111Il1 = "" then return ""
_l1IlIl1 = chr(92)
_lIIlIl1 = _l111Il1
_lll1Il1 = CreateObject(_l1d_f60394("34421a52535840", 91, 11), _l1IlIl1 + _l1IlIl1, _l1d_f60394("aa", 248, 11))
_lIIlIl1 = _lll1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1IlIl1)
_l1l1Il1 = CreateObject(_l1d_f60394("67874d87888d83", 18, 7), chr(34), _l1d_f60394("d2", 31, 90))
_lIIlIl1 = _l1l1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + chr(34))
_lIl1Il1 = CreateObject(_l1d_f60394("7d95a395969b99", 246, 249), chr(10), _l1d_f60394("6a", 36, 39))
_lIIlIl1 = _lIl1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1d_f60394("98", 105, 145))
_ll11Il1 = CreateObject(_l1d_f60394("a9b7cfc7c8cdb5", 251, 32), chr(13), _l1d_f60394("d1", 78, 168))
_lIIlIl1 = _ll11Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1d_f60394("1d", 198, 105))
return _lIIlIl1
end function
function _l1d_f60394(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function