function HC_DefaultUA() as String
if ((21468 - 7156 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return _l1d_06eaf4("b3d4c2d8dee1d926132b142732c0f9fdfa04efee42efdc4b3f415e47515df32c305b6066722d6a6f878125373a5955265b57436856b09d9aa1bba3a9bac5676b5a7678dbd2a1a1a2a3e187aca9b4bbfcf698c4adcdd2cd16ffff08210a27102d1629bbf0f4f6e6044936333a543c42", 210, 20)
end function
function HC_NewSession() as Object
_l1Ill1l = CreateObject(_l1d_06eaf4("363e173f441f485a525260625a", 156, 72))
_l1Ill1l.SetCertificatesFile(_l1d_06eaf4("8b9a9b9ea3a7566ca3a89a9f9f7eb5b685bfb3d1cad5cf9dd3c7cc", 145, 153))
_l1Ill1l.AddHeader(_l1d_06eaf4("ab01b7c5c4e510c6deebe4f2f9edf12bd7f90b37d606", 203, 24), "")
_l1Ill1l.InitClientCertificates()
_l1Ill1l.EnableCookies()
_l1Ill1l.RetainBodyOnError(true)
_l1Ill1l.EnableEncodings(true)
_llIll1l = CreateObject(_l1d_06eaf4("2a10f11c3538292a2b232b4b48", 77, 235))
_l1Ill1l.SetMessagePort(_llIll1l)
return {
xfer: _l1Ill1l
port: _llIll1l
}
end function
sub HC_Close(_l11I11l as Object)
if _l11I11l = invalid then return
if _l11I11l.xfer <> invalid then
_l11I11l.xfer.AsyncCancel()
_l11I11l.xfer.ClearCookies()
end if
_l11I11l.xfer = invalid
_l11I11l.port = invalid
end sub
function HC_Request(_lIIIlIl as Object, _lIlIlIl as String, _lIll1Il as String, _lII1lIl as Object, _ll11lIl as String, _lI1IlIl as String, _l111lIl as Integer) as Object
_l1IIlIl = {
ok: false
status: 0
body: ""
finalUrl: _lIll1Il
headers: {}
error: ""
}
if _lIIIlIl = invalid or _lIIIlIl.xfer = invalid then
_l1IIlIl.error = _l1d_06eaf4("d3d78bc1d6c7cae3ecee", 176, 245)
return _l1IIlIl
end if
_lI1l1Il = _lIIIlIl.xfer
_lI1l1Il.AsyncCancel()
if _lIIIlIl.port <> invalid then
while _lIIIlIl.port.GetMessage() <> invalid
end while
end if
_lI1l1Il.SetUrl(_lIll1Il)
_lI1l1Il.SetHeaders({})
_l1ll1Il = HC_DefaultUA()
_lIl1lIl = _l1d_06eaf4("bec6c4", 202, 222)
_lI11lIl = false
_llI1lIl = false
if _lII1lIl <> invalid then
for each _lllIlIl in _lII1lIl
_l11l1Il = _lII1lIl[_lllIlIl]
if _l11l1Il <> invalid then
_l1lIlIl = LCase(_lllIlIl)
if _l1lIlIl = _l1d_06eaf4("f3f4e9fba7eef7f8f60f", 41, 151) then
_l1ll1Il = _l11l1Il
_llI1lIl = true
else if _l1lIlIl = _l1d_06eaf4("d1d2d5d6cecd", 95, 147) then
_lIl1lIl = _l11l1Il
_lI11lIl = true
end if
_lI1l1Il.AddHeader(_lllIlIl, _l11l1Il)
end if
end for
end if
if not _llI1lIl then _lI1l1Il.AddHeader(_l1d_06eaf4("0ce902f0c0270c110b08", 187, 30), _l1ll1Il)
if not _lI11lIl then _lI1l1Il.AddHeader(_l1d_06eaf4("68494c55434a", 50, 245), _lIl1lIl)
if _lI1IlIl <> "" then _lI1l1Il.AddHeader(_l1d_06eaf4("7747414b4c", 45, 248), _lI1IlIl)
if _l111lIl <= 0 then _l111lIl = 8000
_l11IlIl = false
if _lIlIlIl = _l1d_06eaf4("806c838d", 203, 229) then
if _ll11lIl = invalid then _ll11lIl = ""
_l11IlIl = _lI1l1Il.AsyncPostFromString(_ll11lIl)
else if _lIlIlIl = _l1d_06eaf4("0c0c0b11", 128, 68) then
if _lI1IlIl = "" then _lI1l1Il.AddHeader(_l1d_06eaf4("8bbbbdc7c8", 153, 192), _l1d_06eaf4("5860685a73a8b89ebe", 205, 169))
_l11IlIl = _lI1l1Il.AsyncGetToString()
else
_l11IlIl = _lI1l1Il.AsyncGetToString()
end if
if not _l11IlIl then
_l1IIlIl.error = _l1d_06eaf4("cbfc09f5f5d4f90b45f50b1a1a512214262a2e2523256c2933394738", 70, 196)
return _l1IIlIl
end if
_llll1Il = CreateObject(_l1d_06eaf4("eddbd9dfe6f1fe04f6f4", 11, 116))
_llll1Il.mark()
while _llll1Il.totalMilliseconds() < _l111lIl
_llIIlIl = _l111lIl - _llll1Il.totalMilliseconds()
if _llIIlIl < 1 then exit while
_ll1IlIl = wait(_llIIlIl, _lIIIlIl.port)
if _ll1IlIl = invalid then exit while
if type(_ll1IlIl) = _l1d_06eaf4("9b99c2a4a1bbb1a1afb8", 161, 200) then
_l1IIlIl.status = _ll1IlIl.getResponseCode()
_l1IIlIl.body = _ll1IlIl.getString()
if _l1IIlIl.body = invalid then _l1IIlIl.body = ""
_ll1l1Il = _ll1IlIl.getFailureReason()
_l1I1lIl = _ll1IlIl.getResponseHeaders()
if _l1I1lIl <> invalid then _l1IIlIl.headers = _l1I1lIl
_l1IIlIl.ok = (_l1IIlIl.status >= 200 and _l1IIlIl.status < 400)
if _l1IIlIl.status = 0 then
_l1IIlIl.error = _ll1l1Il
end if
exit while
end if
end while
if _l1IIlIl.status = 0 and _l1IIlIl.body = "" then
_lI1l1Il.AsyncCancel()
_l1IIlIl.error = _l1d_06eaf4("090706010e171bd21416271933e4", 133, 24) + _l111lIl.ToStr() + _l1d_06eaf4("7a67", 151, 128)
end if
return _l1IIlIl
end function
function HC_Get(_lIllIIl as Object, _ll1lIIl as String, _l1llIIl as Object, _llllIIl as Integer) as Object
if ((15906 - 5302 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return HC_Request(_lIllIIl, _l1d_06eaf4("636456", 188, 104), _ll1lIIl, _l1llIIl, "", "", _llllIIl)
end function
function HC_Head(_lllIll1 as Object, _l1lIll1 as String, _lII1ll1 as Object, _l1I1ll1 as Integer) as Object
return HC_Request(_lllIll1, _l1d_06eaf4("f8eef5f5", 87, 217), _l1lIll1, _lII1ll1, "", "", _l1I1ll1)
end function
function HC_GetRange(_lIIlIl1 as Object, _lll1Il1 as String, _llIlIl1 as Object, _l1IlIl1 as String, _lI1lIl1 as Integer) as Object
if ((54222 - 7746 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return HC_Request(_lIIlIl1, _l1d_06eaf4("d3d8cc", 91, 183), _lll1Il1, _llIlIl1, "", _l1IlIl1, _lI1lIl1)
end function
function HC_Post(_llIIl11 as Object, _l1IIl11 as String, _lI1Il11 as Object, _ll1Il11 as String, _l11Il11 as Integer) as Object
if ((16611 - 2373 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return HC_Request(_llIIl11, _l1d_06eaf4("5c4a6169", 234, 162), _l1IIl11, _lI1Il11, _ll1Il11, "", _l11Il11)
end function
function HC_Base64UrlDecode(_lI11I11 as String) as Object
_l1l1I11 = CreateObject(_l1d_06eaf4("321848343c2e55474a3e49", 47, 213))
if _lI11I11 = invalid or _lI11I11 = "" then return _l1l1I11
_ll11I11 = CreateObject(_l1d_06eaf4("5f6f857f80856b", 122, 87), _l1d_06eaf4("e3", 250, 12), _l1d_06eaf4("ce", 149, 220))
_l111I11 = CreateObject(_l1d_06eaf4("2a2a50262b2c42", 224, 152), _l1d_06eaf4("14", 77, 2), _l1d_06eaf4("86", 254, 237))
_llI1I11 = _ll11I11.replaceAll(_lI11I11, _l1d_06eaf4("46", 233, 132))
_llI1I11 = _l111I11.replaceAll(_llI1I11, _l1d_06eaf4("4f", 105, 9))
_lIl1I11 = Len(_llI1I11) mod 4
if _lIl1I11 = 2 then _llI1I11 = _llI1I11 + _l1d_06eaf4("a8ab", 136, 243)
if _lIl1I11 = 3 then _llI1I11 = _llI1I11 + _l1d_06eaf4("01", 21, 217)
if _lIl1I11 = 1 then return _l1l1I11
_l1l1I11.FromBase64String(_llI1I11)
return _l1l1I11
end function
function HC_Base64UrlEncode(_lIIIlI1 as Object) as String
if _lIIIlI1 = invalid then return ""
_ll1l1I1 = _lIIIlI1.ToBase64String()
_llll1I1 = CreateObject(_l1d_06eaf4("2a181028292e36", 139, 49), _l1d_06eaf4("43b3", 81, 54), _l1d_06eaf4("6a", 72, 59))
_l1ll1I1 = CreateObject(_l1d_06eaf4("708e568a8f9088", 209, 205), _l1d_06eaf4("c1", 25, 139), _l1d_06eaf4("11", 153, 19))
_lIll1I1 = CreateObject(_l1d_06eaf4("bab8e0b8b9bed6", 163, 233), _l1d_06eaf4("f8f1f7", 141, 72), "")
_ll1l1I1 = _llll1I1.replaceAll(_ll1l1I1, _l1d_06eaf4("66", 90, 239))
_ll1l1I1 = _l1ll1I1.replaceAll(_ll1l1I1, _l1d_06eaf4("fa", 46, 137))
_ll1l1I1 = _lIll1I1.replaceAll(_ll1l1I1, "")
return _ll1l1I1
end function
function HC_HexToBytes(_llI1II1 as String) as Object
_l1I1II1 = CreateObject(_l1d_06eaf4("9484aa94a296b5a9ac9ea9", 104, 122))
if _llI1II1 = invalid or _llI1II1 = "" then return _l1I1II1
_l1I1II1.FromHexString(_llI1II1)
return _l1I1II1
end function
function HC_BytesToHex(_l11l1lI as Object) as String
if _l11l1lI = invalid then return ""
return _l11l1lI.ToHexString()
end function
function HC_StringToBytes(_ll1IIlI as String) as Object
_lIlIIlI = CreateObject(_l1d_06eaf4("47653d59596b4a5c5f736e", 83, 38))
if _ll1IIlI = invalid or _ll1IIlI = "" then return _lIlIIlI
_lIlIIlI.FromAsciiString(_ll1IIlI)
return _lIlIIlI
end function
function HC_BytesToString(_lll111I as Object) as String
if ((42186 - 7031 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lll111I = invalid then return ""
return _lll111I.ToAsciiString()
end function
function HC_HostOf(_lIIII1I as String) as String
if ((32168 - 8042 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lIIII1I = invalid or _lIIII1I = "" then return ""
_l1III1I = CreateObject(_l1d_06eaf4("8c9472a0a5a694", 220, 222), _l1d_06eaf4("e7dcc3c6cdd31a203033370d0b3f3241164f50", 244, 61), _l1d_06eaf4("6e", 220, 185))
m = _l1III1I.match(_lIIII1I)
if m <> invalid and m.Count() >= 2 then return LCase(m[1])
return ""
end function
function HC_OriginOf(_llI11II as String) as String
if _llI11II = invalid or _llI11II = "" then return ""
_lI111II = CreateObject(_l1d_06eaf4("d6d6fcd2d7d8ee", 160, 4), _l1d_06eaf4("33c80b12151c22e9efdfe25957ebfeed62fbfc", 164, 57), _l1d_06eaf4("5d", 48, 4))
m = _lI111II.match(_llI11II)
if m <> invalid and m.Count() >= 2 then return m[1]
return ""
end function
function HC_GetJson(_lll1lll as String, _l11llll = 8000 as Integer) as Object
if _lll1lll = invalid or _lll1lll = "" then return invalid
_l1l1lll = CreateObject(_l1d_06eaf4("8ba9b294b1bc9dadbfa5bdbdaf", 49, 72))
_l1l1lll.SetCertificatesFile(_l1d_06eaf4("5e6566696e70473776738b889249888950909e9a939e9a66a6b8b5", 36, 23))
_l1l1lll.AddHeader(_l1d_06eaf4("a076b0bebdda85bfd3e4d9ebf2e2e6a0ccee04accbfb", 137, 207), "")
_l1l1lll.InitClientCertificates()
_l1l1lll.SetUrl(_lll1lll)
_l1l1lll.AddHeader(_l1d_06eaf4("dbf8f1ff3fd6fb000a17", 67, 197), HC_DefaultUA())
_l1l1lll.AddHeader(_l1d_06eaf4("7152555e4c53", 178, 126), _l1d_06eaf4("b5a9acb3b9c2c7b7c5c2c608d0cad1d51a29d8eadae129ebf200fbf93e4d46444c", 95, 119))
_l1l1lll.EnableEncodings(true)
_llIllll = CreateObject(_l1d_06eaf4("b5ad8ea9c2c5b6b7b8aec8d6d3", 132, 191))
_l1l1lll.SetMessagePort(_llIllll)
if not _l1l1lll.AsyncGetToString() then return invalid
_lIIllll = CreateObject(_l1d_06eaf4("1a203a2827322b2d3f39", 125, 11))
_lIIllll.mark()
_ll1llll = invalid
while _lIIllll.totalMilliseconds() < _l11llll
_l1Illll = _l11llll - _lIIllll.totalMilliseconds()
if _l1Illll < 1 then exit while
_lI1llll = wait(_l1Illll, _llIllll)
if _lI1llll = invalid then exit while
if type(_lI1llll) = _l1d_06eaf4("1d3502263f1b2b414936", 150, 57) then
if _lI1llll.getResponseCode() >= 200 and _lI1llll.getResponseCode() < 300 then
_ll1llll = _lI1llll.getString()
end if
exit while
end if
end while
if _ll1llll = invalid or _ll1llll = "" then
_l1l1lll.AsyncCancel()
return invalid
end if
return ParseJson(_ll1llll)
end function
function _l1d_06eaf4(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function