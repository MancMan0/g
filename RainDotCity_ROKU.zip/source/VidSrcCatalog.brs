function VSC_Base() as String
return _l1d_8ce772("19181b1a20daf2f52feffc453e46504b564858185054556b662a6871", 24, 169)
end function
function VSC_NormalizeItem(_lI11l1l as Object, _l1Ill1l = _l1d_8ce772("8f907c9c93", 215, 213) as String) as Object
if _lI11l1l = invalid then return invalid
_l1l1l1l = ""
if _lI11l1l.imdb_id <> invalid then _l1l1l1l = _lI11l1l.imdb_id
if _l1l1l1l = "" and _lI11l1l.id <> invalid then _l1l1l1l = _lI11l1l.id
_lIl1l1l = _l1Ill1l
if _lI11l1l.type <> invalid and _lI11l1l.type = _l1d_8ce772("394640484f48", 189, 107) then _lIl1l1l = _l1d_8ce772("cfd4", 189, 6)
_llI1l1l = ""
if _lI11l1l.name <> invalid then _llI1l1l = _lI11l1l.name
if _llI1l1l = "" and _lI11l1l.title <> invalid then _llI1l1l = _lI11l1l.title
_l1I1l1l = ""
if _lI11l1l.year <> invalid then _l1I1l1l = _lI11l1l.year.ToStr()
if _l1I1l1l = "" and _lI11l1l.releaseInfo <> invalid then _l1I1l1l = _lI11l1l.releaseInfo
_ll11l1l = ""
if _lI11l1l.poster <> invalid then _ll11l1l = _lI11l1l.poster
if _ll11l1l = "" then _ll11l1l = _l1d_8ce772("7b85943a52939aa1a6ab98679faeb6b7c0b6bcc0cbcfbb8ac3d0dc", 58, 49)
_llIll1l = ""
if _lI11l1l.background <> invalid then _llIll1l = _lI11l1l.background
if _llIll1l = "" then _llIll1l = _ll11l1l
_lIIll1l = ""
if _lI11l1l.description <> invalid then _lIIll1l = _lI11l1l.description
_l111l1l = _l1d_8ce772("786471", 9, 58)
if _lI11l1l.imdbRating <> invalid and _lI11l1l.imdbRating <> "" then _l111l1l = _lI11l1l.imdbRating.ToStr()
_lll1l1l = []
if _lI11l1l.genres <> invalid and type(_lI11l1l.genres) = _l1d_8ce772("8c9c819598aa95", 216, 226) then _lll1l1l = _lI11l1l.genres
return {
id: _l1l1l1l,
imdb: _l1l1l1l,
tmdb: "",
kind: _lIl1l1l,
title: _llI1l1l,
year: _l1I1l1l,
poster: _ll11l1l,
backdrop: _llIll1l,
description: _lIIll1l,
rating: _l111l1l,
genres: _lll1l1l
}
end function
function VSC_FetchTrendingMovies() as Object
if ((12906 - 2151 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lIII11l = VSC_Base() + _l1d_8ce772("935257455d636560ab70715b7d74bd698373c88f7b9294", 118, 58)
_l11I11l = HC_GetJson(_lIII11l, 8000)
_l1II11l = []
if _l11I11l <> invalid and _l11I11l.metas <> invalid and type(_l11I11l.metas) = _l1d_8ce772("76664f7f827883", 202, 190) then
for each _llII11l in _l11I11l.metas
_lI1I11l = VSC_NormalizeItem(_llII11l, _l1d_8ce772("cbd0bcd8cf", 181, 243))
if _lI1I11l <> invalid and _lI1I11l.id <> "" then _l1II11l.Push(_lI1I11l)
end for
end if
return _l1II11l
end function
function VSC_FetchTrendingSeries() as Object
_llI1lIl = VSC_Base() + _l1d_8ce772("762d3228384648438e354e3a585744a34f6951ae6d59787a", 242, 153)
_lIl1lIl = HC_GetJson(_llI1lIl, 8000)
_l111lIl = []
if _lIl1lIl <> invalid and _lIl1lIl.metas <> invalid and type(_lIl1lIl.metas) = _l1d_8ce772("102045191c2e19", 184, 70) then
for each _lI11lIl in _lIl1lIl.metas
_ll11lIl = VSC_NormalizeItem(_lI11lIl, _l1d_8ce772("2227", 100, 18))
if _ll11lIl <> invalid and _ll11lIl.id <> "" then _l111lIl.Push(_ll11lIl)
end for
end if
return _l111lIl
end function
function VSC_FetchByGenre(_l11lIIl as String, _l1llIIl as String) as Object
_ll1lIIl = _l11lIIl
if _ll1lIIl = _l1d_8ce772("f8f9", 55, 181) then _ll1lIIl = _l1d_8ce772("d3c0d8c2c9e2", 172, 244)
_l1IlIIl = VSC_Base() + _l1d_8ce772("26f5fa0a00f8f8033e", 239, 102) + _ll1lIIl + _l1d_8ce772("a57f6b81b17c7d7b9286d1", 201, 191) + U_UrlEncode(_l1llIIl) + _l1d_8ce772("e52c282f31", 62, 213)
_llllIIl = HC_GetJson(_l1IlIIl, 7000)
_llIlIIl = []
if _llllIIl <> invalid and _llllIIl.metas <> invalid and type(_llllIIl.metas) = _l1d_8ce772("927a679b9e909b", 76, 84) then
for each _lI1lIIl in _llllIIl.metas
_lIllIIl = VSC_NormalizeItem(_lI1lIIl, _l11lIIl)
if _lIllIIl <> invalid and _lIllIIl.id <> "" then _llIlIIl.Push(_lIllIIl)
end for
end if
return _llIlIIl
end function
function VSC_FetchHomeRows() as Object
if ((23984 - 5996 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lIlIll1 = VSC_FetchTrendingMovies()
_lI1Ill1 = VSC_FetchTrendingSeries()
_ll1Ill1 = []
if _lIlIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("ceb3a59daaaaa6b2fad2b3cdbfc6db", 238, 20),
items: _lIlIll1
})
end if
if _lI1Ill1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("4020262c281e34655c616e623c444f4e", 97, 15),
items: _lI1Ill1
})
end if
_l11Ill1 = VSC_FetchByGenre(_l1d_8ce772("c3c8e2c8d7", 200, 30), _l1d_8ce772("90c3d017b1d9", 211, 16))
if _l11Ill1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("c1f40148e20a464b4cec09131b095ef42e2e1c301e2039", 211, 65),
items: _l11Ill1
})
end if
_l1I1ll1 = VSC_FetchByGenre(_l1d_8ce772("ddded8e2f1", 58, 134), _l1d_8ce772("1b3c343c4143", 154, 64))
if _l1I1ll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("0cf1fffdfe023f404527071c0c1a23252f1b", 101, 232),
items: _l1I1ll1
})
end if
_lllIll1 = VSC_FetchByGenre(_l1d_8ce772("e4e501e9f8", 43, 158), _l1d_8ce772("553c413c3e5e", 38, 240))
if _lllIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("2b02030e12005c37191119", 125, 237),
items: _lllIll1
})
end if
_l1lIll1 = VSC_FetchByGenre(_l1d_8ce772("32333d3f36", 6, 199), _l1d_8ce772("361c1215251b", 122, 4))
if _l1lIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("12301e213927fcf90211503957555854484c", 22, 180),
items: _l1lIll1
})
end if
_lII1ll1 = VSC_FetchByGenre(_l1d_8ce772("060b27131a", 45, 198), _l1d_8ce772("ff2f2d342b21394244", 80, 238))
if _lII1ll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("c5d9e3e2f1ffefeceebfbcc5e9fd070611", 14, 118),
items: _lII1ll1
})
end if
return _ll1Ill1
end function
function VSC_Search(_lIl1Il1 as String) as Object
_l1l1Il1 = []
if _lIl1Il1 = invalid or _lIl1Il1 = "" then return _l1l1Il1
_lI1lIl1 = U_UrlEncode(_lIl1Il1)
_lll1Il1 = VSC_Base() + _l1d_8ce772("541314021a2026216c2d321c3a317e2644308a39464d41555d8d", 116, 249) + _lI1lIl1 + _l1d_8ce772("09c8e4d3d5", 200, 35)
_l111Il1 = VSC_Base() + _l1d_8ce772("cf8e8f9f959da19ce7b6a3bdb5acc5fcc6c2d008d7c4cbe1d3dd2b", 229, 5) + _lI1lIl1 + _l1d_8ce772("2af1fbf2f6", 69, 191)
_lIIlIl1 = HC_GetJson(_lll1Il1, 6000)
_ll11Il1 = HC_GetJson(_l111Il1, 6000)
if _lIIlIl1 <> invalid and _lIIlIl1.metas <> invalid then
for each _llIlIl1 in _lIIlIl1.metas
_l1IlIl1 = VSC_NormalizeItem(_llIlIl1, _l1d_8ce772("8b8ca8989f", 239, 9))
if _l1IlIl1 <> invalid then _l1l1Il1.Push(_l1IlIl1)
end for
end if
if _ll11Il1 <> invalid and _ll11Il1.metas <> invalid then
for each _llIlIl1 in _ll11Il1.metas
_l1IlIl1 = VSC_NormalizeItem(_llIlIl1, _l1d_8ce772("7273", 74, 52))
if _l1IlIl1 <> invalid then _l1l1Il1.Push(_l1IlIl1)
end for
end if
return _l1l1Il1
end function
function VSC_FetchSeriesDetails(_l1ll111 as String) as Object
if ((29320 - 7330 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1l1111 = VSC_Base() + _l1d_8ce772("7d3e495b4b8c635868526172a1", 104, 54) + _l1ll111 + _l1d_8ce772("e2a995acae", 244, 8)
_l11Il11 = HC_GetJson(_l1l1111, 8000)
_llIl111 = []
if _l11Il11 = invalid or _l11Il11.meta = invalid or _l11Il11.meta.videos = invalid then return _llIl111
_ll11111 = _l11Il11.meta.videos
_ll1Il11 = {}
for each _lIl1111 in _ll11111
_lI1l111 = 1
if _lIl1111.season <> invalid then _lI1l111 = _lIl1111.season
_llIIl11 = 1
if _lIl1111.number <> invalid then _llIIl11 = _lIl1111.number else if _lIl1111.episode <> invalid then _llIIl11 = _lIl1111.episode
_lIIIl11 = _l1d_8ce772("5b49355241494d0b", 40, 238) + _llIIl11.ToStr()
if _lIl1111.name <> invalid and _lIl1111.name <> "" then _lIIIl11 = _lIl1111.name else if _lIl1111.title <> invalid and _lIl1111.title <> "" then _lIIIl11 = _lIl1111.title
_lIIl111 = ""
if _lIl1111.thumbnail <> invalid then _lIIl111 = _lIl1111.thumbnail
_lI1Il11 = ""
if _lIl1111.overview <> invalid then _lI1Il11 = _lIl1111.overview else if _lIl1111.description <> invalid then _lI1Il11 = _lIl1111.description
_l11l111 = _l1d_8ce772("08", 114, 7) + _lI1l111.ToStr()
if not _ll1Il11.DoesExist(_l11l111) then _ll1Il11[_l11l111] = []
_ll1Il11[_l11l111].Push({
season: _lI1l111,
episode: _llIIl11,
title: _lIIIl11,
thumbnail: _lIIl111,
description: _lI1Il11
})
end for
for each _ll1l111 in _ll1Il11
_l1Il111 = Mid(_ll1l111, 2).ToInt()
_l1IIl11 = _ll1Il11[_ll1l111]
_llIl111.Push({
number: _l1Il111,
label: _l1d_8ce772("5e333247464a7f", 97, 44) + _l1Il111.ToStr(),
episodes: _l1IIl11
})
end for
for _llll111 = 1 to _llIl111.Count() - 1
_lIll111 = _llll111
while _lIll111 > 0 and _llIl111[_lIll111].number < _llIl111[_lIll111 - 1].number
_lll1111 = _llIl111[_lIll111]
_llIl111[_lIll111] = _llIl111[_lIll111 - 1]
_llIl111[_lIll111 - 1] = _lll1111
_lIll111 = _lIll111 - 1
end while
end for
return _llIl111
end function
function VSC_FetchTitleMeta(_lI11I11 as String, _llI1I11 as String) as Object
if _lI11I11 = invalid or _lI11I11 = "" then return invalid
_lIlII11 = _l1d_8ce772("2526423239", 15, 195)
if _llI1I11 = _l1d_8ce772("1015", 184, 68) or _llI1I11 = _l1d_8ce772("edfaf2fc03fc", 252, 94) then _lIlII11 = _l1d_8ce772("d8cdddc7d6e7", 168, 253)
_ll1II11 = VSC_Base() + _l1d_8ce772("662732263475", 249, 144) + _lIlII11 + _l1d_8ce772("f6", 228, 43) + _lI11I11 + _l1d_8ce772("e9b0bab1b5", 69, 126)
_ll11I11 = HC_GetJson(_ll1II11, 6000)
if _ll11I11 <> invalid and _ll11I11.meta <> invalid then
_l1I1I11 = _ll11I11.meta
_l1lII11 = ""
if _l1I1I11.name <> invalid and _l1I1I11.name <> "" then
_l1lII11 = _l1I1I11.name
else if _l1I1I11.title <> invalid and _l1I1I11.title <> "" then
_l1lII11 = _l1I1I11.title
end if
_lII1I11 = ""
if _l1I1I11.poster <> invalid and _l1I1I11.poster <> "" then
_lII1I11 = _l1I1I11.poster
else if Left(_lI11I11, 2) = _l1d_8ce772("abae", 182, 233) then
_lII1I11 = _l1d_8ce772("f0eff2f1f7b1c9cc091017202112e0222d1f2f292939f8303044494e0b3f51484c60502057646b696c32", 24, 128) + _lI11I11 + _l1d_8ce772("b7f8ff08", 170, 50)
end if
_lIl1I11 = ""
if _l1I1I11.background <> invalid and _l1I1I11.background <> "" then
_lIl1I11 = _l1I1I11.background
else
_lIl1I11 = _lII1I11
end if
_lI1II11 = ""
if _l1I1I11.year <> invalid then _lI1II11 = _l1I1I11.year.ToStr()
_lllII11 = _l1d_8ce772("5f7b74", 87, 255)
if _l1I1I11.imdbRating <> invalid and _l1I1I11.imdbRating <> "" then _lllII11 = _l1I1I11.imdbRating.ToStr()
return {
title: _l1lII11,
poster: _lII1I11,
backdrop: _lIl1I11,
year: _lI1II11,
rating: _lllII11,
description: _l1I1I11.description
}
end if
_l1l1I11 = _l1d_8ce772("1c0d210f162b", 46, 191)
if _lIlII11 = _l1d_8ce772("24192b132233", 73, 234) then _l1l1I11 = _l1d_8ce772("a4a5b1a9a8", 35, 86)
_l11II11 = VSC_Base() + _l1d_8ce772("09ced9cde318", 95, 153) + _l1l1I11 + _l1d_8ce772("2d", 72, 198) + _lI11I11 + _l1d_8ce772("854c664d51", 79, 36)
_l111I11 = HC_GetJson(_l11II11, 4000)
if _l111I11 <> invalid and _l111I11.meta <> invalid then
_l1I1I11 = _l111I11.meta
_l1lII11 = ""
if _l1I1I11.name <> invalid and _l1I1I11.name <> "" then
_l1lII11 = _l1I1I11.name
else if _l1I1I11.title <> invalid and _l1I1I11.title <> "" then
_l1lII11 = _l1I1I11.title
end if
_lII1I11 = ""
if _l1I1I11.poster <> invalid and _l1I1I11.poster <> "" then
_lII1I11 = _l1I1I11.poster
else if Left(_lI11I11, 2) = _l1d_8ce772("dadd", 245, 89) then
_lII1I11 = _l1d_8ce772("7e7d807f83bfd5d8959ca3acad9eeeaeb9adbbb7b5c706bcbed0d5da17cdddd4daecde2ce3f0f7f7fa3e", 217, 205) + _lI11I11 + _l1d_8ce772("68252c29", 193, 122)
end if
_lIl1I11 = ""
if _l1I1I11.background <> invalid and _l1I1I11.background <> "" then _lIl1I11 = _l1I1I11.background else _lIl1I11 = _lII1I11
_lI1II11 = ""
if _l1I1I11.year <> invalid then _lI1II11 = _l1I1I11.year.ToStr()
_lllII11 = _l1d_8ce772("587469", 117, 22)
if _l1I1I11.imdbRating <> invalid and _l1I1I11.imdbRating <> "" then _lllII11 = _l1I1I11.imdbRating.ToStr()
return {
title: _l1lII11,
poster: _lII1I11,
backdrop: _lIl1I11,
year: _lI1II11,
rating: _lllII11,
description: _l1I1I11.description
}
end if
return invalid
end function
function _l1d_8ce772(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function