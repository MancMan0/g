function TMDB_BuildKey() as String
return ""
end function
function TMDB_Key() as String
if ((18704 - 2338 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_llIll1l = U_PrefDefault(_l1d_9f1519("d9f5efecd8f9f0", 82, 179), "")
if _llIll1l <> invalid and _llIll1l <> "" then return _llIll1l
return TMDB_BuildKey()
end function
function TMDB_Enabled() as Boolean
if ((36120 - 9030 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return TMDB_Key() <> ""
end function
function TMDB_Image(_lIl1lIl as String, _ll11lIl as String) as String
if _lIl1lIl = invalid or _lIl1lIl = "" then return ""
if _ll11lIl = "" then _ll11lIl = _l1d_9f1519("5a9f9da0", 210, 181)
if Left(_lIl1lIl, 4) = _l1d_9f1519("e4cbced5", 116, 200) then return _lIl1lIl
return _l1d_9f1519("e9d0d3dadc263639020100fd024af7130d12591d0b1b66126c1c72", 86, 171) + _ll11lIl + _lIl1lIl
end function
function TMDB_IsNumeric(_l1llIIl as Dynamic) as Boolean
if _l1llIIl = invalid then return false
_lIllIIl = ""
if Type(_l1llIIl) = _l1d_9f1519("133d3a464c56", 91, 11) or Type(_l1llIIl) = _l1d_9f1519("1210371d1e16201a", 225, 127) then
_lIllIIl = _l1llIIl
else
return false
end if
if _lIllIIl = "" then return false
_llllIIl = CreateObject(_l1d_9f1519("faf220eef3f412", 164, 36), _l1d_9f1519("8182adf7f3", 80, 115), "")
return _llllIIl.isMatch(_lIllIIl)
end function
function TMDB_FmtRating(_l1lIll1 as Dynamic) as String
if ((27972 - 4662 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _l1lIll1 = invalid then return ""
_lII1ll1 = 0.0
_lII1ll1 = _l1lIll1
if _lII1ll1 <= 0 then return ""
_lllIll1 = Int(_lII1ll1 * 10 + 0.5)
_lIlIll1 = _lllIll1 \ 10
_l1I1ll1 = _lllIll1 mod 10
return _lIlIll1.ToStr() + _l1d_9f1519("64", 57, 77) + _l1I1ll1.ToStr()
end function
function TMDB_FindId(_lll1Il1 as String, _lIl1Il1 as String, _l1IlIl1 as String) as String
if ((32164 - 8041 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if not TMDB_Enabled() then return ""
if _lll1Il1 = invalid or _lll1Il1 = "" then return ""
_lIIlIl1 = _l1d_9f1519("2b2c26383f", 62, 216)
if _l1IlIl1 = _l1d_9f1519("c9ce", 60, 129) then _lIIlIl1 = _l1d_9f1519("191e", 225, 132)
_l1l1Il1 = _l1d_9f1519("c0c7cad1d7211114d1e3df1fe8e7dfeaeff9f7eef0f9400412024d5c53220f162a1e2668", 228, 52) + _lIIlIl1 + _l1d_9f1519("341509132017200f4e", 127, 244) + TMDB_Key() + _l1d_9f1519("8f6766596f6baa", 111, 70) + U_UrlEncode(_lll1Il1)
if _lIl1Il1 <> invalid and _lIl1Il1 <> "" then
if _l1IlIl1 = _l1d_9f1519("7e83", 109, 101) then
_l1l1Il1 = _l1l1Il1 + _l1d_9f1519("4407fff9fb051d16110b2927251d2f381938372969", 123, 231) + _lIl1Il1
else
_l1l1Il1 = _l1l1Il1 + _l1d_9f1519("8a4c535a4a94", 214, 154) + _lIl1Il1
end if
end if
_lI1lIl1 = HA_GetJson(_l1l1Il1)
if _lI1lIl1 = invalid or _lI1lIl1.results = invalid then return ""
if _lI1lIl1.results.Count() = 0 then return ""
_llIlIl1 = _lI1lIl1.results[0]
if _llIlIl1.id = invalid then return ""
return _llIlIl1.id.ToStr()
end function
function TMDB_Enrich(_llll111 as Object) as Object
if ((28245 - 5649 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _llll111 = invalid then return _llll111
if not TMDB_Enabled() then return _llll111
_ll1l111 = ""
if _llll111.tmdb <> invalid then _ll1l111 = _llll111.tmdb.ToStr()
if not TMDB_IsNumeric(_ll1l111) then
_ll1l111 = TMDB_FindId(_llll111.title, _llll111.year, _llll111.kind)
end if
if not TMDB_IsNumeric(_ll1l111) then return _llll111
_l1ll111 = _l1d_9f1519("fbfc16080f", 206, 88)
if _llll111.kind = _l1d_9f1519("4849", 31, 221) then _l1ll111 = _l1d_9f1519("3d3e", 179, 118)
_l11l111 = _l1d_9f1519("90a7aab1b36d5d60b1c3af6bc8b7bfbabbd5c7ced0d58cd0eede99b89f", 142, 170) + _l1ll111 + _l1d_9f1519("bf", 148, 4) + _ll1l111 + _l1d_9f1519("6e4739451a495a4188", 90, 9) + TMDB_Key() + _l1d_9f1519("07c7dbded4cedb03f1d90cf4ecf9ffebef05fe49fe120a0e04242058151b192338272c317c373175706d", 235, 58)
_lI1Il11 = HA_GetJson(_l11l111)
if _lI1Il11 = invalid then return _llll111
_llll111.tmdb = _ll1l111
if _lI1Il11.overview <> invalid and _lI1Il11.overview <> "" then _llll111.description = _lI1Il11.overview
if _lI1Il11.backdrop_path <> invalid and _lI1Il11.backdrop_path <> "" then _llll111.backdrop = TMDB_Image(_lI1Il11.backdrop_path, _l1d_9f1519("befb01fa05", 89, 144))
if (_llll111.poster = "" or _llll111.poster = invalid) and _lI1Il11.poster_path <> invalid then _llll111.poster = TMDB_Image(_lI1Il11.poster_path, _l1d_9f1519("11565457", 90, 228))
_lIll111 = TMDB_FmtRating(_lI1Il11.vote_average)
if _lIll111 <> "" then _llll111.rating = _lIll111
if _llll111.kind = _l1d_9f1519("5a5b", 243, 211) then
if _lI1Il11.episode_run_time <> invalid and Type(_lI1Il11.episode_run_time) = _l1d_9f1519("5d7b9466697d78", 179, 156) and _lI1Il11.episode_run_time.Count() > 0 then
_llll111.runtime = _lI1Il11.episode_run_time[0].ToStr() + _l1d_9f1519("7e3c3b45", 201, 149)
end if
if _lI1Il11.first_air_date <> invalid and Len(_lI1Il11.first_air_date) >= 4 then _llll111.year = Left(_lI1Il11.first_air_date, 4)
else
if _lI1Il11.runtime <> invalid and _lI1Il11.runtime > 0 then _llll111.runtime = _lI1Il11.runtime.ToStr() + _l1d_9f1519("9464636b", 112, 68)
if _lI1Il11.release_date <> invalid and Len(_lI1Il11.release_date) >= 4 then _llll111.year = Left(_lI1Il11.release_date, 4)
end if
if _lI1Il11.genres <> invalid and _lI1Il11.genres.Count() > 0 then
_l1IIl11 = []
for each _lIIIl11 in _lI1Il11.genres
if _lIIIl11.name <> invalid then _l1IIl11.Push(_lIIIl11.name)
end for
if _l1IIl11.Count() > 0 then _llll111.genres = _l1IIl11
end if
if _lI1Il11.credits <> invalid and _lI1Il11.credits.cast <> invalid and _lI1Il11.credits.cast.Count() > 0 then
_l11Il11 = []
for each _ll1Il11 in _lI1Il11.credits.cast
_llIIl11 = { id: "", name: "", character: "", photo: "" }
if _ll1Il11.id <> invalid then _llIIl11.id = _ll1Il11.id.ToStr()
if _ll1Il11.name <> invalid then _llIIl11.name = _ll1Il11.name
if _ll1Il11.character <> invalid then _llIIl11.character = _ll1Il11.character
if _ll1Il11.profile_path <> invalid and _ll1Il11.profile_path <> "" then _llIIl11.photo = TMDB_Image(_ll1Il11.profile_path, _l1d_9f1519("68292533", 139, 108))
_l11Il11.Push(_llIIl11)
if _l11Il11.Count() >= 18 then exit for
end for
if _l11Il11.Count() > 0 then _llll111.cast = _l11Il11
end if
return _llll111
end function
function _l1d_9f1519(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function