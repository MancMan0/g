function VSR_Resolve(_ll1I1ll as String, _l11I1ll as String, _llII1ll = 1 as Integer, _lIlI1ll = 1 as Integer) as Object
if ((29464 - 7366 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _ll1I1ll = invalid or _ll1I1ll = "" then return invalid
if _l11I1ll = invalid or _l11I1ll = "" then _l11I1ll = _l1d_007d69("d2d3dddfd6", 38, 135)
if _l11I1ll = _l1d_007d69("3435", 58, 230) then
_l1lI1ll = _l1d_007d69("0423262527e1d9dc34232b363541f03a51533d4a454953550e5655186560646e702a868733", 170, 66) + _ll1I1ll + _l1d_007d69("52", 206, 113) + _llII1ll.ToStr() + _l1d_007d69("ad", 173, 43) + _lIlI1ll.ToStr()
else
_l1lI1ll = _l1d_007d69("10171a2123eddde030272742293df4364547413e494547491252591c59646062642e73747e807740", 38, 194) + _ll1I1ll
end if
_lllI1ll = {
embedUrl: _l1lI1ll,
refer: _l1d_007d69("e8070a0909c5bbbe18070d181725d41c33371f2c272d3539f23837fa", 171, 37),
kind: _l11I1ll,
imdb: _ll1I1ll,
season: _llII1ll,
episode: _lIlI1ll
}
print _l1d_007d69("b9c7c7c9c9cfe9f6e5e902f8e3b9f00d0bfe020ecef2292b15021d212b2dec312d43f8", 138, 232); _ll1I1ll; _l1d_007d69("5752", 201, 110); _l11I1ll; _l1d_007d69("02", 221, 14)
_lI1I1ll = R_ResolveEmbed(_lllI1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("1b21292b2331ff18ffff1c0e39573b2a2c1a431e2e2c2e754b484144415a5d9790", 236, 100); Left(_lI1I1ll.url, 60)
return _lI1I1ll
end if
if _l11I1ll = _l1d_007d69("1f24", 17, 186) then
_lII11ll = _l1d_007d69("535a5d646ab4a4a77c727168b5798777c27b86868486d4", 228, 199) + _ll1I1ll + _l1d_007d69("c4", 174, 67) + _llII1ll.ToStr() + _l1d_007d69("67", 118, 12) + _lIlI1ll.ToStr() + _l1d_007d69("61", 214, 104)
else
_lII11ll = _l1d_007d69("9695989799d3ebee9fadb4c3fcc0b6ce09d6d1d5dfe11b", 122, 132) + _ll1I1ll + _l1d_007d69("f9", 98, 172)
end if
_lllI1ll.embedUrl = _lII11ll
_lllI1ll.refer = _l1d_007d69("8685888789435b5e8f9da4b36cb0a6be79", 58, 52)
print _l1d_007d69("d6e6e4e8e6ee021302042111fcd40b2c2417212be90b26443b343246014a445c0d", 9, 132); _ll1I1ll
_lI1I1ll = R_ResolveEmbed(_lllI1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("6a72787c728272676e746d818cccae8983928f9589e49495aaadaea3a6e2ff", 255, 198); Left(_lI1I1ll.url, 60)
return _lI1I1ll
end if
_l1II1ll = HC_NewSession()
_lI1I1ll = VSR_ResolveVidSrcIn(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
HC_Close(_l1II1ll)
print _l1d_007d69("3e444c4e4654627b62627f715c3a6b797f799b8f688855aba8a1a4a1babd", 140, 103)
return _lI1I1ll
end if
_lI1I1ll = VSR_ResolveVidSrcCc(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
HC_Close(_l1II1ll)
print _l1d_007d69("0800060a1010e0f5ecf2fbef2a3a2707ff3317092c0f5525261b1e1f3437", 231, 76)
return _lI1I1ll
end if
_lI1I1ll = VSR_ResolveVidSrcXyz(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
HC_Close(_l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("827a80848a8a766f86887585a050a19d95ad91a3bd9fa56ea29fb8bbb8b1b4", 53, 20)
return _lI1I1ll
end if
print _l1d_007d69("9ea6acb0a6b6e2dbe2e4e1f1bc3cdef6f94806f6fd06161b09151517692a2e292933377e3f39398a", 221, 24); _ll1I1ll
return invalid
end function
function VSR_ResolveVidSrcCc(_lll1l1l as String, _l1l1l1l as String, _llI1l1l as Integer, _l1Ill1l as Integer, _lllIl1l as Object) as Object
_lIl1l1l = _l1d_007d69("f71619181e5850532d1321333529672f32", 200, 87)
_llIll1l = _lIl1l1l + _l1d_007d69("32fc433bf4fffffdff4d0e131d1b125f", 228, 103) + _lll1l1l
if _l1l1l1l = _l1d_007d69("f8f9", 158, 14) then
_llIll1l = _lIl1l1l + _l1d_007d69("ac569db5727d797b7dc77374d0", 86, 51) + _lll1l1l + _l1d_007d69("9f", 19, 99) + _llI1l1l.ToStr() + _l1d_007d69("0f", 99, 195) + _l1Ill1l.ToStr()
_lII1l1l = _lIl1l1l + _l1d_007d69("a3687a66af7886728f7e868ac7", 72, 60) + _lll1l1l + _l1d_007d69("c7", 113, 105) + _llI1l1l.ToStr() + _l1d_007d69("09", 118, 176) + _l1Ill1l.ToStr() + _l1d_007d69("1bcadbd1d0e4dadc", 119, 195)
else
_lII1l1l = _lIl1l1l + _l1d_007d69("d091839fdc998fab94aba7abf4", 86, 87) + _lll1l1l + _l1d_007d69("eb2a372f2e40383c", 156, 56)
end if
_lIIll1l = {
"Referer": _llIll1l,
"Origin": _lIl1l1l,
"Accept": _l1d_007d69("584c4f666c696a5a78797d3f8771888c4d4c7b8d8d84608ea5a3aeb071707d7b83", 21, 228),
"X-Requested-With": _l1d_007d69("f4e4e6ed14171e031128271a332f", 196, 88)
}
_l111l1l = HC_Get(_lllIl1l, _lII1l1l, _lIIll1l, 6000)
if _l111l1l = invalid or _l111l1l.body = "" then return invalid
_ll11l1l = ParseJson(_l111l1l.body)
if _ll11l1l = invalid or type(_ll11l1l) <> _l1d_007d69("939b889da0a7b6afbaa8b8b0c2a9bdc0d2bd", 92, 101) then return invalid
_l1I1l1l = invalid
if _ll11l1l.data <> invalid then _l1I1l1l = _ll11l1l.data
if (_l1I1l1l = invalid or type(_l1I1l1l) <> _l1d_007d69("9aa2cfa3a6b8a3", 252, 12)) and _ll11l1l.servers <> invalid then _l1I1l1l = _ll11l1l.servers
if _l1I1l1l = invalid or type(_l1I1l1l) <> _l1d_007d69("fb0b3404071d08", 186, 51) or _l1I1l1l.Count() = 0 then return invalid
for each _ll1Il1l in _l1I1l1l
if type(_ll1Il1l) <> _l1d_007d69("e6061ff0f312091611071f0b214010132924", 178, 38) then continue for
_l11Il1l = ""
if _ll1Il1l.hash <> invalid then _l11Il1l = _ll1Il1l.hash
if _l11Il1l = "" and _ll1Il1l.data_id <> invalid then _l11Il1l = _ll1Il1l.data_id
if _l11Il1l = "" and _ll1Il1l.id <> invalid then _l11Il1l = _ll1Il1l.id
if _l11Il1l = "" then continue for
_l1lIl1l = _lIl1l1l + _l1d_007d69("ed322630f9303f383a4c510e", 153, 55) + _l11Il1l
_lIlIl1l = HC_Get(_lllIl1l, _l1lIl1l, _lIIll1l, 6000)
if _lIlIl1l = invalid or _lIlIl1l.body = "" then continue for
_lI11l1l = ParseJson(_lIlIl1l.body)
if _lI11l1l = invalid or type(_lI11l1l) <> _l1d_007d69("1329061b1e35343d3828463040273d40504b", 149, 44) then continue for
_lI1Il1l = ""
if _lI11l1l.data <> invalid and type(_lI11l1l.data) = _l1d_007d69("0a28fd1215342b342f273d2f3f1e34374742", 145, 39) and _lI11l1l.data.stream <> invalid then
if type(_lI11l1l.data.stream) = _l1d_007d69("e3cdcac6ccc6", 35, 115) or type(_lI11l1l.data.stream) = _l1d_007d69("8aa06f8d96aeb0aa", 85, 99) then
_lI1Il1l = _lI11l1l.data.stream
end if
end if
if _lI1Il1l = "" and _lI11l1l.stream <> invalid and (type(_lI11l1l.stream) = _l1d_007d69("10eef7ff010b", 189, 34) or type(_lI11l1l.stream) = _l1d_007d69("b7b59cc2c3bbc5bf", 65, 132)) then
_lI1Il1l = _lI11l1l.stream
end if
if _lI1Il1l <> "" then
_l1IIl1l = []
if _lI11l1l.data <> invalid and _lI11l1l.data.subtitles <> invalid and type(_lI11l1l.data.subtitles) = _l1d_007d69("2b230034372944", 4, 181) then
for each _llIIl1l in _lI11l1l.data.subtitles
if _llIIl1l.file <> invalid and _llIIl1l.file <> "" then
_l1IIl1l.Push({
url: _llIIl1l.file,
label: _llIIl1l.label,
language: _llIIl1l.language
})
end if
end for
end if
return {
url: _lI1Il1l,
streamFormat: U_StreamFormat(_lI1Il1l),
subtitles: _l1IIl1l,
referer: _llIll1l,
userAgent: _lllIl1l.userAgent
}
end if
end for
return invalid
end function
function VSR_ResolveVidSrcIn(_lIII11l as String, _llllI1l as String, _lI1lI1l as Integer, _l1II11l as Integer, _llIlI1l as Object) as Object
if ((13803 - 4601 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llII11l = _l1d_007d69("7e7d807f7f3b51549098a89498aa6aaab072bfbac0c8cc84c9cac6cedd96", 155, 139) + _lIII11l
if _llllI1l = _l1d_007d69("b0b5", 121, 163) then
_llII11l = _l1d_007d69("d5c4c7c6ca162c2fdbefefdfe3f545010b4d06110b0f135f090e68", 113, 188) + _lIII11l + _l1d_007d69("fd", 250, 40) + _lI1lI1l.ToStr() + _l1d_007d69("a8", 72, 65) + _l1II11l.ToStr()
end if
_lIllI1l = HC_Get(_llIlI1l, _llII11l, { "Referer": _l1d_007d69("a3a2a5a4aa647c7fb9bfcdbfc1d593d1d99d", 152, 179) }, 7000)
if _lIllI1l = invalid or _lIllI1l.body = "" then return invalid
_ll1lI1l = CreateObject(_l1d_007d69("93b379afb4b5ab", 16, 49), _l1d_007d69("550b152c1c131e0f0f72126b464a3c812a", 205, 100) + chr(34) + _l1d_007d69("f451095959", 55, 228) + chr(34) + _l1d_007d69("ef9cf1f6a7", 207, 7) + chr(34) + _l1d_007d69("9a13", 165, 24), _l1d_007d69("1d", 163, 83))
m = _ll1lI1l.match(_lIllI1l.body)
if m <> invalid and m.Count() >= 2 then
_lI1I11l = U_AbsUrl(m[1], _l1d_007d69("7463666565b1c7ca768e8e7a7e90e0a0a6e8", 243, 217))
_l11I11l = HC_Get(_llIlI1l, _lI1I11l, { "Referer": _llII11l }, 7000)
if _l11I11l <> invalid and _l11I11l.body <> "" then
_l11lI1l = CreateObject(_l1d_007d69("00e826f8f9fe0c", 46, 164), _l1d_007d69("fbbebdc0bfbffefe1417a6aeb3d7", 219, 8) + chr(34) + _l1d_007d69("185122582d6d367b43676f7088", 1, 242) + chr(34) + _l1d_007d69("f22f0309", 6, 209), _l1d_007d69("47", 174, 128))
_l1llI1l = _l11lI1l.match(_l11I11l.body)
if _l1llI1l <> invalid and _l1llI1l.Count() >= 2 then
return {
url: _l1llI1l[1],
streamFormat: _l1d_007d69("1f1e10", 116, 3),
subtitles: [],
referer: _lI1I11l,
userAgent: _llIlI1l.userAgent
}
end if
end if
end if
return invalid
end function
function VSR_ResolveVidSrcXyz(_l111lIl as String, _lI11lIl as String, _lII1lIl as Integer, _ll11lIl as Integer, _lllIlIl as Object) as Object
_lIl1lIl = _l1d_007d69("b0afb2b1b16d8386c2cadac6cadc9ccdcfd1a7f4eff5fd01b9fefffb0312bb0c131f1ccc", 155, 189) + _l111lIl
if _lI11lIl = _l1d_007d69("7d82", 105, 96) then
_lIl1lIl = _l1d_007d69("cdcccfcece0a2023dfe7f7e3e7f939eaecee44110c121a1e5614154f2027333060", 91, 154) + _l111lIl + _l1d_007d69("af7f7877887779cf", 202, 195) + _lII1lIl.ToStr() + _l1d_007d69("72b2aac4b1c8c2c47f", 21, 63) + _ll11lIl.ToStr()
end if
_llI1lIl = HC_Get(_lllIlIl, _lIl1lIl, { "Referer": _l1d_007d69("1e05080f135f6d701c3830282c3e863b3d4391", 245, 129) }, 7000)
if _llI1lIl = invalid or _llI1lIl.body = "" then return invalid
_l1I1lIl = CreateObject(_l1d_007d69("adabd3abacb1c9", 35, 92), _l1d_007d69("3578878a898958584e5180888da1", 3, 10) + chr(34) + _l1d_007d69("c059d25ed395c683d177757698", 212, 205) + chr(34) + _l1d_007d69("515a5454", 29, 23), _l1d_007d69("a3", 203, 1))
m = _l1I1lIl.match(_llI1lIl.body)
if m <> invalid and m.Count() >= 2 then
return {
url: m[1],
streamFormat: _l1d_007d69("111002", 180, 53),
subtitles: [],
referer: _lIl1lIl,
userAgent: _lllIlIl.userAgent
}
end if
return invalid
end function
function _l1d_007d69(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function