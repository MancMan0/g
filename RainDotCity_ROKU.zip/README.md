# RainDotCity | Roku 🎬⚡

[![Roku OS](https://img.shields.io/badge/Roku_OS-9.4+-662d91?style=for-the-badge&logo=roku&logoColor=white)](https://developer.roku.com/)
[![BrightScript](https://img.shields.io/badge/Language-BrightScript-00f5ff?style=for-the-badge)](https://developer.roku.com/docs/developer-program/core-concepts/brightscript-basics.md)
[![SceneGraph](https://img.shields.io/badge/Framework-SceneGraph_XML-ff007f?style=for-the-badge)](https://developer.roku.com/docs/developer-program/scenegraph/about-scenegraph.md)
[![Resolution](https://img.shields.io/badge/Resolution-1080p_FHD_%7C_720p_HD-28a745?style=for-the-badge)]()
[![Hardware Support](https://img.shields.io/badge/Tested_On-Roku_2_(4205EU)-orange?style=for-the-badge)]()

**RainDotCity | Roku** is a native Roku SceneGraph client engineered to bring the sleek, cyberpunk aesthetic of the [RainDotCity](https://raindotcity.com) streaming web platform to your television. Built with a focus on high-speed browsing, legacy hardware optimization (tested on Roku 2), and zero-friction remote navigation.

---

## ✨ Features

### 🌌 Cyberpunk Dark-Neon UI
* **Custom Dark Theme:** Immersive dark-slate background (`#04040d`) with electric cyan accents (`#00f5ff`) and dynamic background scrims.
* **Dual-Tone Brand Header:** Distinctive two-tone typography featuring `RainDotCity` in glowing cyan and `Roku` in crisp white.
* **TV Overscan Safe Area:** Engineered with calibrated `x=80` safe-zone margins, ensuring zero text clipping on older CRT/LCD panels or overscan-heavy HDMI displays (e.g., Technika).

### 🔍 Live Title Discovery & Streaming
* **Dynamic Feed Ingestion:** Asynchronous task threads fetch trending movies, series, and top-rated titles with zero main-thread UI stutter.
* **Comprehensive Metadata:** Renders high-resolution poster artwork, release years, category tags, full synopsis, and star ratings.
* **Streamlined Hero Spotlight:** Featured banner with one-click direct playback and quick watchlist bookmarking.

### 🎮 Seamless Search & Virtual Keyboard
* **Focus-Chain Escape Engine:** Overcomes SceneGraph compound node limitations using `isInFocusChain()`.
* **Directional Handoff:** Pressing **RIGHT** or **DOWN** on the virtual keyboard immediately transfers focus directly onto the searched results grid.
* **Instant Return:** Pressing **LEFT** (from column 0) or **BACK** seamlessly returns focus to the keyboard for rapid query refinement.
* **Direct Remote Shortcut:** Pressing the **`*` (Options)** button from anywhere on the homepage jumps instantly into search.
* **Dynamic Results Button:** Positioned cleanly below the keyboard (`"Browse Results >"`), dynamically updating with exact result counts.

### 📂 18+ Rich Genre Categories + Kids Hub
* Dedicated **CategoriesView** housing 18+ curated entertainment categories:
  * *Action & Adventure*, *Sci-Fi & Cyber Universe*, *Comedy Hits*, *Horror & Supernatural*
  * *Thriller & Suspense*, *Crime & Mystery*, *Animation & Anime*, *Drama & Romance*
  * *Fantasy & Magic*, *Documentary & Reality*, *History & War*, *Sports*, *Western*
* 🧒 **Dedicated Kids Hub:** An isolated **Kids & Family Fun** catalog designed specifically for child-friendly viewing.

### 🛡️ UX Polish & Safeguards
* **Accidental Exit Shield:** Custom modal dialog (*"Close RainDotCity | Roku?"*) prevents accidental exits when tapping the **BACK** key on the home screen.
* **Local Watchlist Persistence:** Bookmarks are saved directly to Roku non-volatile registry memory (`roRegistrySection`), persisting across app launches and device restarts.
* **Adaptive Video Player (`PlayerView`):** Native HLS streaming with automated resolution stepping, stream retry resilience, and remote media controls (Play/Pause, Seek, and Replay).

---

## 🚀 Hardware & Compatibility

* **Target Resolution:** 1920x1080 (FHD) with automatic downscaling for 720p (HD).
* **Legacy Device Support:** Extensively optimized for low-memory legacy devices, including the **Roku 2 (Model 4205EU)**.
* **7-Bit ASCII Compliant:** 100% sanitized source files ensuring error-free BrightScript compilation and eliminating firmware white-screen hangs.

---

## 🛠️ Project Structure

```text
RainDotCity Roku/
├── manifest                     # Roku application metadata (title=RainDotCity)
├── components/                  # SceneGraph XML & BrightScript Controllers
│   ├── MainScene.xml            # Root coordinator & view switcher
│   ├── MainScene.brs            # Main application navigation logic
│   ├── HomeView.xml / .brs      # Hero carousel and horizontal row lists
│   ├── SearchView.xml / .brs    # Virtual keyboard & instant search grid
│   ├── CategoriesView.xml / .brs# 18+ genre category grid hub
│   ├── DetailsView.xml / .brs   # Extended synopsis, metadata, and actions
│   ├── PlayerView.xml / .brs    # Custom video playback interface
│   ├── MyListView.xml / .brs    # Saved user favorites (Watchlist)
│   ├── PosterItem.xml / .brs    # Reusable poster card component
│   └── tasks/                   # Asynchronous network workers
│       ├── HomeFeedTask.xml/.brs# Background feed fetcher
│       └── SearchTask.xml/.brs  # Live title query worker
├── source/                      # Shared BrightScript utility modules
│   ├── main.brs                 # Application entrypoint (`RunUserInterface`)
│   ├── Watchlist.brs            # Persistent registry manager
│   └── utils.brs                # String and JSON helpers
└── images/                      # Channel icons, splash screens, and scrims
```

---

## 📦 Sideloading & Installation

### Step 1: Enable Roku Developer Mode
1. On your Roku remote, press the following sequence:
   * **Home** x3
   * **Up** x2
   * **Right** x1
   * **Left** x1
   * **Right** x1
   * **Left** x1
   * **Right** x1
2. Enable the Developer Server, set an administrative password, and note the device's IP address (e.g., `192.168.0.88`).
3. Allow the Roku to restart.

### Step 2: Build the Deployment Package
Run the automated packaging script to verify 7-bit ASCII compliance and generate a standard deployment archive:
```bash
python scratch/build_package.py
```
This generates `RainDotCity_ROKU.zip` (and aliases `VidSrc_ROKU.zip`) with the `manifest` placed strictly at byte index 0.

### Step 3: Install via Web Application Installer
1. Open your web browser and navigate to `http://<YOUR_ROKU_IP>`.
2. Authenticate using username `rokudev` and your configured password.
3. Click **Browse**, select `RainDotCity_ROKU.zip`, and click **Install**.
4. The channel will launch immediately on your television.

---

## 🎮 Remote Navigation Cheat Sheet

| Button | Context | Action |
| :--- | :--- | :--- |
| *** (Options)** | **Homepage / Non-Video** | **Jump straight to SEARCH view** |
| **UP** | Main Content | Jumps focus to Top Navigation Bar |
| **DOWN** | Top Navigation | Drops focus back into the active view |
| **LEFT / RIGHT** | Top Navigation | Cycles through `HOME`, `MOVIES`, `TV`, `CATEGORIES`, `SEARCH` |
| **RIGHT / DOWN** | Search Keyboard | Jumps focus onto search results grid |
| **LEFT / BACK** | Search Results | Returns focus to the virtual keyboard |
| **BACK** | Home Screen | Opens the *"Close RainDotCity | Roku?"* Exit Confirmation Dialog |
| **OK / Select** | Poster / Button | Opens Title Details or executes action |

---

## 📄 License
This project is developed for personal and private home streaming exploration. Distributed under the MIT License.
