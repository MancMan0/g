function HM_FetchQualities(_l11I1ll as String, _l1lI1ll as String, _ll1I1ll as Object) as Object
if ((56931 - 8133 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lllI1ll = []
if _l11I1ll = invalid or _l11I1ll = "" then return _lllI1ll
if Instr(1, LCase(_l11I1ll), _l1d_f60394("f1b1f2afef", 93, 126)) = 0 then return _lllI1ll
_lII11ll = {}
if _l1lI1ll <> "" then _lII11ll[_l1d_f60394("dff9f9ff0b0511", 74, 199)] = _l1lI1ll
_lIlI1ll = HC_Get(_ll1I1ll, _l11I1ll, _lII11ll, 6000)
if _lIlI1ll = invalid or _lIlI1ll.body = "" then return _lllI1ll
if Instr(1, _lIlI1ll.body, _l1d_f60394("eb505665f15ff77074756b6a690c6b737e", 168, 96)) = 0 then return _lllI1ll
return HM_ParseMasterPlaylist(_lIlI1ll.body, _l11I1ll)
end function
function HM_ParseMasterPlaylist(_ll1Il1l as String, _l1Ill1l as String) as Object
if ((59353 - 8479 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lllIl1l = []
if _ll1Il1l = invalid or _ll1Il1l = "" then return _lllIl1l
_l1I1l1l = _ll1Il1l.Tokenize(chr(10))
if _l1I1l1l = invalid then return _lllIl1l
_lII1l1l = _l1I1l1l.Count()
for _l111l1l = 0 to _lII1l1l - 1
line = _l1I1l1l[_l111l1l]
if Left(line, 17) <> _l1d_f60394("a8513948b242b84d57546c6b6acd6c727d", 219, 176) then continue for
_llIll1l = HM_ParseAttrs(line)
_lIIll1l = 0
if _llIll1l.BANDWIDTH <> invalid then _lIIll1l = _llIll1l.BANDWIDTH.ToInt()
_ll11l1l = 0
_lIlIl1l = ""
if _llIll1l.RESOLUTION <> invalid then _lIlIl1l = _llIll1l.RESOLUTION
if _lIlIl1l <> "" then
_lI1Il1l = Instr(1, _lIlIl1l, _l1d_f60394("f6", 65, 189))
if _lI1Il1l > 0 and _lI1Il1l < Len(_lIlIl1l) then
_ll11l1l = Mid(_lIlIl1l, _lI1Il1l + 1).ToInt()
end if
end if
_l11Il1l = ""
for _lI11l1l = _l111l1l + 1 to _lII1l1l - 1
_lll1l1l = U_Trim(_l1I1l1l[_lI11l1l])
if _lll1l1l = "" then continue for
if Left(_lll1l1l, 1) = _l1d_f60394("19", 149, 99) then continue for
_l11Il1l = _lll1l1l
exit for
end for
if _l11Il1l = "" then continue for
_l11Il1l = RP_AbsUrl(_l11Il1l, _l1Ill1l)
_llI1l1l = _l1d_f60394("7161535f6a6865", 251, 196)
if _ll11l1l > 0 then
_llI1l1l = _ll11l1l.ToStr() + _l1d_f60394("e7", 44, 139)
else if _lIIll1l > 0 then
_llI1l1l = (_lIIll1l \ 1000).ToStr() + _l1d_f60394("aeaabfbf", 71, 130)
end if
_lllIl1l.Push({
label: _llI1l1l
height: _ll11l1l
bandwidth: _lIIll1l
url: _l11Il1l
})
end for
for _l111l1l = 1 to _lllIl1l.Count() - 1
_l1l1l1l = _lllIl1l[_l111l1l]
_lIl1l1l = _l1l1l1l.height
if _lIl1l1l = invalid then _lIl1l1l = 0
_lI11l1l = _l111l1l - 1
while _lI11l1l >= 0
_l1lIl1l = _lllIl1l[_lI11l1l].height
if _l1lIl1l = invalid then _l1lIl1l = 0
if _l1lIl1l >= _lIl1l1l then exit while
_lllIl1l[_lI11l1l + 1] = _lllIl1l[_lI11l1l]
_lI11l1l = _lI11l1l - 1
end while
_lllIl1l[_lI11l1l + 1] = _l1l1l1l
end for
return _lllIl1l
end function
function HM_ParseAttrs(line as String) as Object
if ((59184 - 9864 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llII11l = {}
if line = invalid or line = "" then return _llII11l
_lIII11l = CreateObject(_l1d_f60394("a2b8c8b4b9baba", 245, 27), _l1d_f60394("c0b2afcebae7d7e6ddd0dde2f9e7", 234, 254) + chr(34) + _l1d_f60394("5353", 5, 245) + chr(34) + _l1d_f60394("5965", 234, 162) + chr(34) + _l1d_f60394("ebd1cfa4d8acb2", 142, 249), _l1d_f60394("22", 15, 186))
_lI1I11l = _lIII11l.matchAll(line)
if _lI1I11l = invalid then return _llII11l
for each _l1II11l in _lI1I11l
if _l1II11l.Count() < 3 then continue for
_l11I11l = _l1II11l[1]
_llllI1l = _l1II11l[2]
if Len(_llllI1l) >= 2 and Left(_llllI1l, 1) = chr(34) and Right(_llllI1l, 1) = chr(34) then
_llllI1l = Mid(_llllI1l, 2, Len(_llllI1l) - 2)
end if
_llII11l[_l11I11l] = _llllI1l
end for
return _llII11l
end function
function HM_CoerceKind(_lIl1lIl as String) as String
if _lIl1lIl = invalid or _lIl1lIl = "" then return ""
_ll11lIl = LCase(_lIl1lIl)
if Instr(1, _ll11lIl, _l1d_f60394("91918a939b", 92, 92)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("3d3f4d474f4d57", 255, 173)) > 0 then return _l1d_f60394("b5b3c0c5bb", 71, 135)
if Instr(1, _ll11lIl, _l1d_f60394("919ea2a79d", 135, 169)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("5d7165696f7f", 65, 59)) > 0 or Instr(1, _ll11lIl, _l1d_f60394("ada5b2b2aeba", 254, 18)) > 0 then return _l1d_f60394("121f23201e", 3, 166)
if Instr(1, _ll11lIl, _l1d_f60394("2a3a3f4438", 223, 125)) > 0 then return _l1d_f60394("f400090afe", 53, 173)
return ""
end function
function HM_ExtractChaptersHtml(_l1llIIl as String) as Object
_llIlIIl = []
if _l1llIIl = invalid or _l1llIIl = "" then return _llIlIIl
_lll1IIl = {}
_ll1lIIl = CreateObject(_l1d_f60394("56643c7075765e", 153, 107), chr(34) + _l1d_f60394("8a989edad5dae4a0ada5e9e5f2f7ef03f5020409011503150709191f252d2a1c2126383f31413139433f3b57434b4858545021", 166, 252) + chr(34) + _l1d_f60394("b7d1ab9ec3ddb7cceed2ecc6", 144, 235) + chr(34) + _l1d_f60394("353f2d3f48", 195, 133) + chr(34) + _l1d_f60394("f6e02a1d02ec36370e0943433d3b205526215b5c556238226c71442e78", 248, 82) + chr(34) + _l1d_f60394("a4aeab", 147, 174) + chr(34) + _l1d_f60394("537fabbe5f8bb7bc6b86c2c8d4dc7dce839edadfece5", 207, 192), _l1d_f60394("f805", 75, 214))
_lIllIIl = _ll1lIIl.matchAll(_l1llIIl)
if _lIllIIl <> invalid then
for each _lI1lIIl in _lIllIIl
if _lI1lIIl.Count() < 4 then continue for
_l11lIIl = HM_CoerceKind(_lI1lIIl[1])
if _l11lIIl = "" or _lll1IIl.DoesExist(_l11lIIl) then continue for
_l1l1IIl = _lI1lIIl[2].ToFloat()
_llllIIl = _lI1lIIl[3].ToFloat()
if _llllIIl > _l1l1IIl then
_llIlIIl.Push({ kind: _l11lIIl, start: _l1l1IIl, end: _llllIIl })
_lll1IIl[_l11lIIl] = true
end if
end for
end if
_l1IlIIl = CreateObject(_l1d_f60394("8c847284858aa8", 198, 216), _l1d_f60394("73b7b3d0d5bdd1c3e0e2e7cfe3e1f3e5e7e7fd03fb08faff04160dff1f0f07110d192521192626222eef605f63f76a0b5a5a52626381", 46, 109) + chr(34) + _l1d_f60394("6a98d2d4c67acfd3829ddbdfedf394e59ab5f3f805feafafddb5c3bce12d14313639f1322a383edf4f3aebeaee42f556130b1806", 78, 88) + chr(34) + _l1d_f60394("e8d8949084f68f9100db9b9dadb512a718f3b3b4c5ba", 173, 247), _l1d_f60394("857a", 102, 118))
_lIIlIIl = _l1IlIIl.matchAll(_l1llIIl)
if _lIIlIIl <> invalid then
for each _lI1lIIl in _lIIlIIl
if _lI1lIIl.Count() < 4 then continue for
_l11lIIl = HM_CoerceKind(_lI1lIIl[1])
if _l11lIIl = "" or _lll1IIl.DoesExist(_l11lIIl) then continue for
_l1l1IIl = _lI1lIIl[2].ToFloat()
_llllIIl = _lI1lIIl[3].ToFloat()
if _llllIIl > _l1l1IIl then
_llIlIIl.Push({ kind: _l11lIIl, start: _l1l1IIl, end: _llllIIl })
_lll1IIl[_l11lIIl] = true
end if
end for
end if
return _llIlIIl
end function
function HM_ExtractChaptersHls(_l1Il1l1 as String, _llll1l1 as String, _l11l1l1 as Object) as Object
_lIIIll1 = []
if _l1Il1l1 = invalid or _l1Il1l1 = "" then return _lIIIll1
_l11Ill1 = {}
if _llll1l1 <> "" then _l11Ill1[_l1d_f60394("cde1e7e7f9edff", 129, 250)] = _llll1l1
_l1ll1l1 = HC_Get(_l11l1l1, _l1Il1l1, _l11Ill1, 6000)
if _l1ll1l1 = invalid or _l1ll1l1.body = "" then return _lIIIll1
_lIIl1l1 = _l1ll1l1.body
if Instr(1, _lIIl1l1, _l1d_f60394("5e3f3f367048765258485a50646a6469", 119, 10)) = 0 then
if Instr(1, _lIIl1l1, _l1d_f60394("801d1b128e249425212a383f46a950504b", 212, 137)) = 0 then return _lIIIll1
_ll1Ill1 = ""
_l1IIll1 = _lIIl1l1.Tokenize(chr(10))
if _l1IIll1 = invalid then return _lIIIll1
for _lI1Ill1 = 0 to _l1IIll1.Count() - 1
_lII1ll1 = U_Trim(_l1IIll1[_lI1Ill1])
if _lII1ll1 = "" or Left(_lII1ll1, 1) = _l1d_f60394("9f", 221, 161) then continue for
_ll1Ill1 = _lII1ll1
exit for
end for
if _ll1Ill1 = "" then return _lIIIll1
_ll1Ill1 = RP_AbsUrl(_ll1Ill1, _l1Il1l1)
_lIll1l1 = HC_Get(_l11l1l1, _ll1Ill1, _l11Ill1, 6000)
if _lIll1l1 = invalid or _lIll1l1.body = "" then return _lIIIll1
_lIIl1l1 = _lIll1l1.body
if Instr(1, _lIIl1l1, _l1d_f60394("a0011118a21aa8141a2a1c32261c262b", 47, 148)) = 0 then return _lIIIll1
end if
_ll1l1l1 = {}
_l1IIll1 = _lIIl1l1.Tokenize(chr(10))
if _l1IIll1 = invalid then return _lIIIll1
for _lI1Ill1 = 0 to _l1IIll1.Count() - 1
line = _l1IIll1[_lI1Ill1]
if Left(line, 16) <> _l1d_f60394("2643433a344c3a565c4c5e5868726c6d", 21, 240) then continue for
_l1I1ll1 = HM_ParseAttrs(line)
_lllIll1 = ""
if _l1I1ll1.CLASS <> invalid then _lllIll1 = _l1I1ll1.CLASS
_llIIll1 = HM_CoerceKind(_lllIll1)
if _llIIll1 = "" and _l1I1ll1.ID <> invalid then _llIIll1 = HM_CoerceKind(_l1I1ll1.ID)
if _llIIll1 = "" or _ll1l1l1.DoesExist(_llIIll1) then continue for
_lI1l1l1 = ""
if _l1I1ll1.X_START <> invalid then _lI1l1l1 = _l1I1ll1.X_START
if _lI1l1l1 = "" and _l1I1ll1[_l1d_f60394("1d33182210222b", 227, 98)] <> invalid then _lI1l1l1 = _l1I1ll1[_l1d_f60394("152b141a081e23", 97, 220)]
if _lI1l1l1 = "" and _l1I1ll1[_l1d_f60394("3b8b382f34973e3a575c44a966665e6e6f", 206, 165)] <> invalid then _lI1l1l1 = _l1I1ll1[_l1d_f60394("f46c15141578171f1819298a2327372b30", 88, 244)]
_llIl1l1 = 0.0
if _lI1l1l1 <> "" then _llIl1l1 = _lI1l1l1.ToFloat()
_l1lIll1 = ""
if _l1I1ll1[_l1d_f60394("e9d702fc09", 159, 34)] <> invalid then _l1lIll1 = _l1I1ll1[_l1d_f60394("88409ba7a0", 48, 32)]
if _l1lIll1 = "" and _l1I1ll1[_l1d_f60394("4856373e3f62494b545d53744f5d56", 229, 139)] <> invalid then _l1lIll1 = _l1I1ll1[_l1d_f60394("82b0a19899bca3a59ea7adceb9b7c0", 125, 93)]
_lIlIll1 = 0.0
if _l1lIll1 <> "" then
_lIlIll1 = _l1lIll1.ToFloat()
else if _l1I1ll1.DURATION <> invalid then
_lIlIll1 = _llIl1l1 + _l1I1ll1.DURATION.ToFloat()
end if
if _lIlIll1 > _llIl1l1 then
_lIIIll1.Push({ kind: _llIIll1, start: _llIl1l1, end: _lIlIll1 })
_ll1l1l1[_llIIll1] = true
end if
end for
return _lIIIll1
end function
function HM_ExtractSubsHls(_lllIIl1 as String, _lI11Il1 as String, _lII1Il1 as Object) as Object
_l111Il1 = []
if _lllIIl1 = invalid or _lllIIl1 = "" then return _l111Il1
if Instr(1, LCase(_lllIIl1), _l1d_f60394("5195529353", 31, 32)) = 0 then return _l111Il1
_lIIlIl1 = {}
if _lI11Il1 <> "" then _lIIlIl1[_l1d_f60394("8777797d738379", 183, 162)] = _lI11Il1
_llI1Il1 = HC_Get(_lII1Il1, _lllIIl1, _lIIlIl1, 6000)
if _llI1Il1 = invalid or _llI1Il1.body = "" then return _l111Il1
_l1lIIl1 = _llI1Il1.body
if Instr(1, _l1lIIl1, _l1d_f60394("fbf1fd131e070c1e131919242e1f", 121, 206)) = 0 then return _l111Il1
_lIl1Il1 = _l1lIIl1.Tokenize(chr(10))
if _lIl1Il1 = invalid then return _l111Il1
_l1I1Il1 = {}
for _lll1Il1 = 0 to _lIl1Il1.Count() - 1
line = U_Trim(_lIl1Il1[_lll1Il1])
if Left(line, 12) <> _l1d_f60394("54f90f0e6a1870130e101813", 192, 113) then continue for
if Instr(1, line, _l1d_f60394("393f3b312c414a38514757524c59", 131, 98)) = 0 then continue for
_llIlIl1 = HM_ParseAttrs(line)
_lIlIIl1 = ""
if _llIlIl1.URI <> invalid then _lIlIIl1 = _llIlIl1.URI
if _lIlIIl1 = "" then continue for
_lI1lIl1 = RP_AbsUrl(_lIlIIl1, _lllIIl1)
_l1IlIl1 = HM_ResolveSubPlaylist(_lI1lIl1, _lI11Il1, _lII1Il1)
if _l1IlIl1 = "" then continue for
_l1l1Il1 = _l1d_f60394("8a86", 124, 113)
if _llIlIl1.LANGUAGE <> invalid then _l1l1Il1 = LCase(_llIlIl1.LANGUAGE)
_ll11Il1 = ""
if _llIlIl1.NAME <> invalid then _ll11Il1 = _llIlIl1.NAME
if _ll11Il1 = "" then _ll11Il1 = UCase(_l1l1Il1)
if _l1I1Il1.DoesExist(_l1IlIl1) then continue for
_l1I1Il1[_l1IlIl1] = true
_l111Il1.Push({
url: _l1IlIl1
language: _l1l1Il1
name: _ll11Il1
})
end for
return _l111Il1
end function
function HM_ResolveSubPlaylist(_lIll111 as String, _lIIIl11 as String, _l1ll111 as Object) as String
if ((45444 - 6492 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lIll111 = invalid or _lIll111 = "" then return ""
_llIIl11 = LCase(_lIll111)
if Instr(1, _llIIl11, _l1d_f60394("ab868b8e", 74, 71)) > 0 then return _lIll111
if Instr(1, _llIIl11, _l1d_f60394("95dbdfe8", 3, 104)) > 0 then return _lIll111
if Instr(1, _llIIl11, _l1d_f60394("703293508e", 204, 142)) = 0 then return _lIll111
_l11Il11 = {}
if _lIIIl11 <> "" then _l11Il11[_l1d_f60394("532125273f2d45", 164, 93)] = _lIIIl11
_llll111 = HC_Get(_l1ll111, _lIll111, _l11Il11, 5000)
if _llll111 = invalid or _llll111.body = "" then return _lIll111
_l1IIl11 = _llll111.body.Tokenize(chr(10))
if _l1IIl11 = invalid then return _lIll111
for _lI1Il11 = 0 to _l1IIl11.Count() - 1
_ll1Il11 = U_Trim(_l1IIl11[_lI1Il11])
if _ll1Il11 = "" or Left(_ll1Il11, 1) = _l1d_f60394("b4", 6, 143) then continue for
return RP_AbsUrl(_ll1Il11, _lIll111)
end for
return _lIll111
end function
function HM_ScrapeSubs(_l1l1I11 as String) as Object
_l1I1I11 = []
if _l1l1I11 = invalid or _l1l1I11 = "" then return _l1I1I11
_lII1I11 = CreateObject(_l1d_f60394("d0c0b6ccd1d2d8", 8, 86), _l1d_f60394("fcbfa6a9b0b6fd031316edeb", 244, 32) + chr(34) + _l1d_f60394("267e81845e2c8e3f9348453f3d7c7d808b85878c6467", 48, 15), _l1d_f60394("8481", 82, 73))
_lI11I11 = _lII1I11.matchAll(_l1l1I11)
if _lI11I11 = invalid then return _l1I1I11
_lllII11 = {}
for each _llI1I11 in _lI11I11
if _llI1I11.Count() < 2 then continue for
_l1lII11 = _llI1I11[1]
if _lllII11.DoesExist(_l1lII11) then continue for
_lllII11[_l1lII11] = true
_lIl1I11 = _l1d_f60394("ccd6", 151, 218)
_ll11I11 = CreateObject(_l1d_f60394("24120a1e23242c", 137, 41), _l1d_f60394("eb22f52afd2dfdfa39e70fec38f847184f53255a2d", 251, 75), _l1d_f60394("94", 205, 240))
_l111I11 = _ll11I11.match(_l1lII11)
if _l111I11 <> invalid and _l111I11.Count() >= 2 then _lIl1I11 = LCase(_l111I11[1])
_l1I1I11.Push({ url: _l1lII11, language: _lIl1I11, name: UCase(_lIl1I11) })
end for
return _l1I1I11
end function
function HM_MergeSubs(_l1ll1I1 as Object, _lIIIlI1 as Object) as Object
_llll1I1 = []
_ll1l1I1 = {}
if _l1ll1I1 <> invalid and type(_l1ll1I1) = _l1d_f60394("6684996f72827d", 177, 163) then
for each _lIll1I1 in _l1ll1I1
if type(_lIll1I1) <> _l1d_f60394("bbd3b0c5c8dfdee7e2d0f0d8ead1e5e8faf5", 84, 149) then continue for
if _lIll1I1.url = invalid or _lIll1I1.url = "" then continue for
if _ll1l1I1.DoesExist(_lIll1I1.url) then continue for
_ll1l1I1[_lIll1I1.url] = true
_llll1I1.Push(_lIll1I1)
end for
end if
if _lIIIlI1 <> invalid and type(_lIIIlI1) = _l1d_f60394("47472050534964", 194, 151) then
for each _lIll1I1 in _lIIIlI1
if type(_lIll1I1) <> _l1d_f60394("2543182d304f464f4a42584a5a394f52625d", 17, 194) then continue for
if _lIll1I1.url = invalid or _lIll1I1.url = "" then continue for
if _ll1l1I1.DoesExist(_lIll1I1.url) then continue for
_ll1l1I1[_lIll1I1.url] = true
_llll1I1.Push(_lIll1I1)
end for
end if
return _llll1I1
end function
function HM_FetchFreeSubs(_l1I1II1 as String, _lIlIII1 as String, _lII1II1 as String, _lllIII1 as Integer, _llI1II1 as Integer, _l1lIII1 as Object) as Object
return HM_QueryOpenSubtitles(_l1I1II1, _lII1II1, _lllIII1, _llI1II1, _l1lIII1)
end function
function HM_QueryOpenSubtitles(_lIIl1lI as String, _l1l11lI as String, _lII11lI as Integer, _l1Il1lI as Integer, _l1lI1lI as Object) as Object
_lI111lI = []
if _lIIl1lI = invalid or _lIIl1lI = "" then return _lI111lI
if Left(_lIIl1lI, 2) <> _l1d_f60394("d4d7", 26, 102) then return _lI111lI
_l11l1lI = Mid(_lIIl1lI, 3)
if _l11l1lI = "" then return _lI111lI
if _l1l11lI = _l1d_f60394("080d", 141, 15) and _lII11lI > 0 and _l1Il1lI > 0 then
_ll1I1lI = _l1d_f60394("94a3a6a5a571676ab2aab7c17abcc6bcc6ccd5c3dcd2e2ddd7e4a4e6eee4aff6efee00f200c401110b14131113de", 3, 41) + _l1Il1lI.ToStr() + _l1d_f60394("1fe4e3edf6f0f632", 204, 60) + _l11l1lI + _l1d_f60394("b3f2030afb0204ca", 62, 162) + _lII11lI.ToStr()
else
_ll1I1lI = _l1d_f60394("e900030a0ecab8bb1b07201ecb0d2b191735322c39273f2a344df5375745005f4c53695b55155a59656e666e28", 45, 164) + _l11l1lI
end if
_l1I11lI = HC_Get(_l1lI1lI, _ll1I1lI, {
"X-User-Agent": _l1d_f60394("fe03f7f2f2fc1214bc1901c64138", 175, 35)
"Accept": _l1d_f60394("e6fafdf4faf7f80806070b4d151f161a", 101, 226)
}, 6000)
if _l1I11lI = invalid or _l1I11lI.body = "" then return _lI111lI
if _l1I11lI.status < 200 or _l1I11lI.status >= 300 then return _lI111lI
_llI11lI = ParseJSON(_l1I11lI.body)
if _llI11lI = invalid or type(_llI11lI) <> _l1d_f60394("9ba3d4a4a7bda8", 254, 15) then return _lI111lI
_lI1I1lI = CreateObject(_l1d_f60394("8393a9a3a4a98f", 58, 59), _l1d_f60394("401c23124a52061f5624795f76156e6f703c3838424949858b3a559596", 77, 222), _l1d_f60394("87", 194, 220))
_lllI1lI = {}
for each _llIl1lI in _llI11lI
if type(_llIl1lI) <> _l1d_f60394("7f8778898c93a29faa98a89cb299a9acc2ad", 94, 83) then continue for
_lIl11lI = ""
if _llIl1lI.SubLanguageID <> invalid then _lIl11lI = LCase(_llIl1lI.SubLanguageID)
if _lIl11lI = "" then continue for
if _lllI1lI.DoesExist(_lIl11lI) then continue for
_lI1l1lI = ""
if _llIl1lI.SubDownloadLink <> invalid then _lI1l1lI = _llIl1lI.SubDownloadLink
if _lI1l1lI = "" then continue for
_ll111lI = _lI1I1lI.match(_lI1l1lI)
if _ll111lI = invalid or _ll111lI.Count() < 3 then continue for
_l11I1lI = _ll111lI[1]
_lIlI1lI = _ll111lI[2]
_llII1lI = _l1d_f60394("4e6d706f6faba1a47b8472b18b84867a89c38388cb92d1", 203, 171) + _l11I1lI + _l1d_f60394("fb443c04", 183, 99) + _lIlI1lI + _l1d_f60394("d5ff0b11130a20ec24292cdd232b23322e363a36132e30210f1d", 130, 24)
_lll11lI = ""
if _llIl1lI.ISO639 <> invalid then _lll11lI = LCase(_llIl1lI.ISO639)
if _lll11lI = "" then _lll11lI = Left(_lIl11lI, 2)
_l1111lI = ""
if _llIl1lI.LanguageName <> invalid then _l1111lI = _llIl1lI.LanguageName
if _l1111lI = "" then _l1111lI = UCase(_lIl11lI)
_lI111lI.Push({
url: _llII1lI
language: _lll11lI
name: _l1111lI
})
_lllI1lI[_lIl11lI] = true
end for
return _lI111lI
end function
function HM_MergeSubtitles(_lIlIIlI as Object, _ll1IIlI as Object) as Object
_l1IIIlI = []
_l1lll1I = {}
_lllll1I = {}
if _lIlIIlI = invalid or type(_lIlIIlI) <> _l1d_f60394("2319f62c2f1f3a", 69, 236) then _lIlIIlI = []
if _ll1IIlI = invalid or type(_ll1IIlI) <> _l1d_f60394("0af2e313160c17", 14, 142) then _ll1IIlI = []
for each _lIIIIlI in _lIlIIlI
if type(_lIIIIlI) <> _l1d_f60394("a8a081b2b5acabb8b3c1c1c5bba2d2d5cbe6", 134, 180) then continue for
_lIlll1I = ""
if _lIIIIlI.url <> invalid then _lIlll1I = _lIIIIlI.url
if _lIlll1I = "" then continue for
if _l1lll1I.DoesExist(_lIlll1I) then continue for
_lI1IIlI = ""
if _lIIIIlI.language <> invalid then _lI1IIlI = LCase(_lIIIIlI.language)
_llIIIlI = ""
if _lIIIIlI.name <> invalid then _llIIIlI = LCase(_lIIIIlI.name)
_l11IIlI = _lI1IIlI + _l1d_f60394("66", 14, 244) + _llIIIlI
if _llIIIlI <> "" and _lllll1I.DoesExist(_l11IIlI) then continue for
_l1lll1I[_lIlll1I] = true
if _llIIIlI <> "" then _lllll1I[_l11IIlI] = true
_l1IIIlI.Push(_lIIIIlI)
end for
for each _lIIIIlI in _ll1IIlI
if type(_lIIIIlI) <> _l1d_f60394("5e44716669505f586373617b6b92888b7b86", 237, 191) then continue for
_lIlll1I = ""
if _lIIIIlI.url <> invalid then _lIlll1I = _lIIIIlI.url
if _lIlll1I = "" then continue for
if _l1lll1I.DoesExist(_lIlll1I) then continue for
_lI1IIlI = ""
if _lIIIIlI.language <> invalid then _lI1IIlI = LCase(_lIIIIlI.language)
_llIIIlI = ""
if _lIIIIlI.name <> invalid then _llIIIlI = LCase(_lIIIIlI.name)
_l11IIlI = _lI1IIlI + _l1d_f60394("f6", 81, 201) + _llIIIlI
if _llIIIlI <> "" and _lllll1I.DoesExist(_l11IIlI) then continue for
_l1lll1I[_lIlll1I] = true
if _llIIIlI <> "" then _lllll1I[_l11IIlI] = true
_l1IIIlI.Push(_lIIIIlI)
end for
return _l1IIIlI
end function
function HM_FetchSkipTimes(_l1l111I as String, _llI111I as String, _lIl111I as String, _l11111I as Integer, _lll111I as Integer, _lI1111I as Object) as Object
_ll1111I = []
if _lIl111I <> _l1d_f60394("dbe0", 217, 46) then return _ll1111I
if _lll111I = invalid or _lll111I <= 0 then return _ll1111I
if _l11111I = invalid then _l11111I = 0
_ll1111I = HM_FetchTheIntroDB(_l1l111I, _llI111I, _l11111I, _lll111I, _lI1111I)
if _ll1111I.Count() > 0 then return _ll1111I
_ll1111I = HM_FetchIntroDB(_l1l111I, _l11111I, _lll111I, _lI1111I)
if _ll1111I.Count() > 0 then return _ll1111I
_ll1111I = HM_FetchAniSkipForEpisode(_llI111I, _lll111I, _lI1111I)
return _ll1111I
end function
function HM_FetchTheIntroDB(_lIIII1I as String, _llIllII as String, _l11llII as Integer, _l1III1I as Integer, _lI1llII as Object) as Object
_lllllII = []
if _l11llII <= 0 or _l1III1I <= 0 then return _lllllII
_lIlllII = ""
if _llIllII <> invalid and _llIllII <> "" then
_lIlllII = _l1d_f60394("bdc9d3dca4d9df8b", 156, 213) + U_UrlEncode(_llIllII)
else if _lIIII1I <> invalid and _lIIII1I <> "" then
_lIlllII = _l1d_f60394("dfdee8f1d9eef4c0", 12, 122) + U_UrlEncode(_lIIII1I)
else
return _lllllII
end if
_l1IllII = _l1d_f60394("1c3b3e3d3f7971743d4f3b7f5c43534a4e6b68586461a0647a72ad87c6b67b8688808bd8", 202, 122) + _lIlllII + _l1d_f60394("3b73848b7c93954b", 54, 43) + _l11llII.ToStr() + _l1d_f60394("ca8ca29eaba29a9ef9", 100, 136) + _l1III1I.ToStr()
_ll1llII = HC_Get(_lI1llII, _l1IllII, {
"Accept": _l1d_f60394("b9cbcecdcdcacbe1d9e2e428e6f2f1f3", 224, 56)
"User-Agent": _l1d_f60394("0ee4dfdb08e2fe14f10707b632fa011ac3e4c8e9", 46, 146)
}, 5000)
if _ll1llII = invalid or _ll1llII.body = "" then return _lllllII
if _ll1llII.status = 204 or _ll1llII.status = 404 then return _lllllII
_l1lllII = ParseJSON(_ll1llII.body)
if _l1lllII = invalid or type(_l1lllII) <> _l1d_f60394("725a8b7c7f6675727d8b7b8f85ac9c9f95a0", 174, 150) then return _lllllII
HM_AppendTheIntroDbSegments(_l1lllII.intro,   _l1d_f60394("60624b546a", 85, 36),  _lllllII)
HM_AppendTheIntroDbSegments(_l1lllII.recap,   _l1d_f60394("889c9d9e92", 113, 133),  _lllllII)
HM_AppendTheIntroDbSegments(_l1lllII.credits, _l1d_f60394("a7b0b2b3b3", 32, 88),  _lllllII)
return _lllllII
end function
sub HM_AppendTheIntroDbSegments(_lI111II as Dynamic, _lII11II as String, _lllI1II as Object)
if _lI111II = invalid or type(_lI111II) <> _l1d_f60394("3f2d52484b3b46", 233, 164) then return
for each _l1lI1II in _lI111II
if type(_l1lI1II) <> _l1d_f60394("847c998e918887908b9999a193baaeb1a3be", 100, 110) then continue for
_lIlI1II = 0
if _l1lI1II.start_ms <> invalid then _lIlI1II = _l1lI1II.start_ms
_llI11II = invalid
if _l1lI1II.end_ms <> invalid then _llI11II = _l1lI1II.end_ms
if _llI11II = invalid then continue for
_ll1I1II = _lIlI1II / 1000.0
_l1I11II = _llI11II / 1000.0
if _l1I11II <= _ll1I1II then continue for
_lllI1II.Push({ kind: _lII11II, start: _ll1I1II, end: _l1I11II })
end for
end sub
function HM_FetchIntroDB(_lI1llll as String, _ll11lll as Integer, _l11llll as Integer, _lI11lll as Object) as Object
if ((48635 - 9727 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lll1lll = []
if _lI1llll = invalid or _lI1llll = "" then return _lll1lll
if _ll11lll <= 0 or _l11llll <= 0 then return _lll1lll
_l1I1lll = _l1d_f60394("f8dfe2e9edb9c7ca07fb15d71b1d060f251f28ef2b1f22fa29363b443f4d363e055a59555e7469611b", 53, 155) + U_UrlEncode(_lI1llll) + _l1d_f60394("368c7d84957c8054", 15, 13) + _ll11lll.ToStr() + _l1d_f60394("995b715d7a61696db8", 204, 175) + _l11llll.ToStr()
_lIl1lll = HC_Get(_lI11lll, _l1I1lll, {
"Accept": _l1d_f60394("ebdfe2f1effcfdf5fb0408ca0a041317", 25, 115)
"User-Agent": _l1d_f60394("5f9189a2926e75cf91979eb3e0fde704", 205, 218)
}, 5000)
if _lIl1lll = invalid or _lIl1lll.body = "" then return _lll1lll
if _lIl1lll.status = 204 or _lIl1lll.status = 404 then return _lll1lll
_l1l1lll = ParseJSON(_lIl1lll.body)
if _l1l1lll = invalid then return _lll1lll
_l1Illll = invalid
if type(_l1l1lll) = _l1d_f60394("82829b8b8e849f", 162, 178) then
_l1Illll = _l1l1lll
else if type(_l1l1lll) = _l1d_f60394("bcd2b3c4c7deddeae5d5f3d9edd4e6e9fdf8", 215, 23) then
if _l1l1lll.segments <> invalid and type(_l1l1lll.segments) = _l1d_f60394("2c144535382e39", 238, 144) then _l1Illll = _l1l1lll.segments
if _l1Illll = invalid and _l1l1lll.data <> invalid and type(_l1l1lll.data) = _l1d_f60394("4a485d53564661", 225, 183) then _l1Illll = _l1l1lll.data
if _l1Illll = invalid and _l1l1lll.results <> invalid and type(_l1l1lll.results) = _l1d_f60394("666e5f6f728873", 94, 58) then _l1Illll = _l1l1lll.results
end if
if _l1Illll = invalid then return _lll1lll
for each _llIllll in _l1Illll
if type(_llIllll) <> _l1d_f60394("768e6b80839a99a29d8bab93a58ca0a3b5b0", 84, 80) then continue for
_l111lll = ""
if _llIllll.segment_type <> invalid then _l111lll = LCase(_llIllll.segment_type)
if _l111lll = "" and _llIllll.type <> invalid then _l111lll = LCase(_llIllll.type)
_lIIllll = ""
if _l111lll = _l1d_f60394("353d565747", 232, 180) then _lIIllll = _l1d_f60394("807e7b8086", 31, 10)
if _l111lll = _l1d_f60394("b9cdcecfc3", 209, 22) then _lIIllll = _l1d_f60394("4353585d51", 127, 54)
if _l111lll = _l1d_f60394("3922242545", 16, 186) or _l111lll = _l1d_f60394("b8aab8bacab0ba", 20, 65) then _lIIllll = _l1d_f60394("607d7f7c6c", 202, 187)
if _lIIllll = "" then continue for
_llI1lll = HM_ParseClockOrSeconds(_llIllll.start_sec)
_ll1llll = HM_ParseClockOrSeconds(_llIllll.end_sec)
if _ll1llll <= _llI1lll then continue for
_lll1lll.Push({ kind: _lIIllll, start: _llI1lll, end: _ll1llll })
end for
return _lll1lll
end function
function HM_ParseClockOrSeconds(_lI1I1ll as Dynamic) as Float
if ((7452 - 1242 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lI1I1ll = invalid then return 0.0
_l11I1ll = type(_lI1I1ll)
if _l11I1ll = _l1d_f60394("36182113181933", 165, 74) or _l11I1ll = _l1d_f60394("472d563451", 239, 170) or _l11I1ll = _l1d_f60394("4b282a3329", 186, 79) or _l11I1ll = _l1d_f60394("4e54805d5d6e5e", 63, 1) or _l11I1ll = _l1d_f60394("7d59526c616b", 253, 196) or _l11I1ll = _l1d_f60394("a89e78a4ada7aca6", 133, 177) then
return _lI1I1ll + 0.0
end if
if _l11I1ll = _l1d_f60394("17fbfce6eefa", 168, 28) or _l11I1ll = _l1d_f60394("1503fa202109131d", 137, 26) then
_ll1I1ll = _lI1I1ll
if _ll1I1ll = "" then return 0.0
if Instr(1, _ll1I1ll, _l1d_f60394("71", 241, 166)) = 0 then return _ll1I1ll.ToFloat()
_lIlI1ll = _ll1I1ll.Tokenize(_l1d_f60394("f9", 72, 135))
if _lIlI1ll = invalid then return 0.0
_l1lI1ll = _lIlI1ll.Count()
if _l1lI1ll = 3 then
return _lIlI1ll[0].ToFloat() * 3600.0 + _lIlI1ll[1].ToFloat() * 60.0 + _lIlI1ll[2].ToFloat()
else if _l1lI1ll = 2 then
return _lIlI1ll[0].ToFloat() * 60.0 + _lIlI1ll[1].ToFloat()
else
return _ll1I1ll.ToFloat()
end if
end if
return 0.0
end function
function HM_FetchAniSkipForEpisode(_lI11l1l as String, _lIIll1l as Integer, _ll11l1l as Object) as Object
if ((21784 - 5446 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lIl1l1l = []
if _lI11l1l = invalid or _lI11l1l = "" then return _lIl1l1l
if _lIIll1l <= 0 then return _lIl1l1l
_l111l1l = HM_FetchTitleFromTmdb(_lI11l1l, _l1d_f60394("eff4", 97, 218), _ll11l1l)
if _l111l1l = "" then return _lIl1l1l
_lll1l1l = HM_LookupMalIdViaJikan(_l111l1l, _ll11l1l)
if _lll1l1l <> "" then
_lIl1l1l = HM_FetchAniSkipByMal(_lll1l1l, _lIIll1l, _ll11l1l)
if _lIl1l1l.Count() > 0 then return _lIl1l1l
end if
_l1l1l1l = HM_LookupMalIdViaAnilist(_l111l1l, _ll11l1l)
if _l1l1l1l <> "" and _l1l1l1l <> _lll1l1l then
_lIl1l1l = HM_FetchAniSkipByMal(_l1l1l1l, _lIIll1l, _ll11l1l)
end if
return _lIl1l1l
end function
function HM_FetchTitleFromTmdb(_lIllI1l as String, _llII11l as String, _l1llI1l as Object) as String
if _lIllI1l = invalid or _lIllI1l = "" then return ""
_lIII11l = _l1d_f60394("c7e6e9e8eca89ea1ebecab06eafafcfb1009c31c08cbe2d1", 169, 6) + _llII11l + _l1d_f60394("46", 143, 166) + _lIllI1l
_llllI1l = HC_Get(_l1llI1l, _lIII11l, {}, 5000)
if _llllI1l = invalid or _llllI1l.body = "" then return ""
_l1II11l = ParseJSON(_llllI1l.body)
if _l1II11l = invalid or type(_l1II11l) <> _l1d_f60394("7369867b7e75747d7888869080a79da090ab", 101, 92) then return ""
if _llII11l = _l1d_f60394("b5b6", 10, 55) then
if _l1II11l.original_name <> invalid and _l1II11l.original_name <> "" then return _l1II11l.original_name
if _l1II11l.name <> invalid then return _l1II11l.name
else
if _l1II11l.original_title <> invalid and _l1II11l.original_title <> "" then return _l1II11l.original_title
if _l1II11l.title <> invalid then return _l1II11l.title
end if
return ""
end function
function HM_LookupMalIdViaJikan(_lllIlIl as String, _lII1lIl as Object) as String
if ((14368 - 1796 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lllIlIl = invalid or _lllIlIl = "" then return ""
_l1lIlIl = _l1d_f60394("e8070a0909c5bbbe071b05cb0a0e0f1c1add21222fe84409f13a38383f4a135c1b", 171, 37) + U_UrlEncode(_lllIlIl) + _l1d_f60394("e9b2b2b9b8a6f2e9", 240, 19)
_l1I1lIl = HC_Get(_lII1lIl, _l1lIlIl, { "Accept": _l1d_f60394("2b3d403f3f383d534b50521654605f61", 34, 232) }, 5000)
if _l1I1lIl = invalid or _l1I1lIl.body = "" then return ""
_llI1lIl = ParseJSON(_l1I1lIl.body)
if _llI1lIl = invalid or type(_llI1lIl) <> _l1d_f60394("9b816ea3a68d9c95a0b09eb8a88fc5c8b8c3", 205, 220) then return ""
_lI11lIl = _llI1lIl.data
if _lI11lIl = invalid or type(_lI11lIl) <> _l1d_f60394("1f0d32282b1b26", 169, 68) or _lI11lIl.Count() = 0 then return ""
_l111lIl = _lI11lIl[0]
if type(_l111lIl) <> _l1d_f60394("d2d8c5dadde4f3ecf7e7f5efffe6fcff0ffa", 29, 99) then return ""
if _l111lIl.mal_id = invalid then return ""
return _l111lIl.mal_id.ToStr()
end function
function HM_LookupMalIdViaAnilist(_lIIlIIl as String, _l1IlIIl as Object) as String
if ((61928 - 7741 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lIIlIIl = invalid or _lIIlIIl = "" then return ""
_lIllIIl = _l1d_f60394("80", 223, 220) + chr(34) + _l1d_f60394("d2d9ecd8e6", 18, 111) + chr(34) + _l1d_f60394("50", 200, 94) + chr(34) + _l1d_f60394("0b0a1d151ff1e822ec48242d4747431045724d4f5f5a24525f665a6e762b306a3e6979738343adb5bbbab56499aaa0ccabb1a5a8", 52, 198) + chr(34) + _l1d_f60394("57", 50, 57) + chr(34) + _l1d_f60394("354d3f4b5658515b50", 159, 76) + chr(34) + _l1d_f60394("286c", 22, 252) + chr(34) + _l1d_f60394("21", 69, 235) + chr(34) + _l1d_f60394("eb", 47, 214) + chr(34) + HM_JsonEscape(_lIIlIIl) + chr(34) + _l1d_f60394("5457", 15, 226)
_llIlIIl = HC_Post(_l1IlIIl, _l1d_f60394("1100030208d2eaed2816281a35213f043a4a484e4e3b3f1c5463", 144, 25), { "Content-Type": _l1d_f60394("e9fbfee5edfafb09f9fafc400622090b", 76, 188), "Accept": _l1d_f60394("85999c8b899297af959a9ee0a0baa9ad", 203, 219) }, _lIllIIl, 5000)
if _llIlIIl = invalid or _llIlIIl.body = "" then return ""
_lI1lIIl = ParseJSON(_llIlIIl.body)
if _lI1lIIl = invalid or type(_lI1lIIl) <> _l1d_f60394("3c2a134447363d3a455d4361553466695d68", 11, 195) then return ""
_ll1lIIl = _lI1lIIl.data
if _ll1lIIl = invalid or type(_ll1lIIl) <> _l1d_f60394("2208f92a2d1423202b3b293f331a4c4f434e", 15, 165) then return ""
_l11lIIl = _ll1lIIl.Media
if _l11lIIl = invalid or type(_l11lIIl) <> _l1d_f60394("eee401f6f9f0eff8f303010bfb22181b0b26", 229, 87) then return ""
if _l11lIIl.idMal = invalid then return ""
return _l11lIIl.idMal.ToStr()
end function
function HM_FetchAniSkipByMal(_l11Ill1 as String, _l1lIll1 as Integer, _l1ll1l1 as Object) as Object
_lI1Ill1 = []
if _l11Ill1 = invalid or _l11Ill1 = "" then return _lI1Ill1
_l11l1l1 = _l1d_f60394("c8d7dad9d9251b1ed7ebe52be3f1f1faf5fa0643f9080d4e1a59571e191e2a68342a312c3978", 99, 189) + _l11Ill1 + _l1d_f60394("67", 168, 224) + _l1lIll1.ToStr() + _l1d_f60394("cd858d879f907b80e3b89cf5a6aea8c0b19ca104cfd1", 208, 222)
_lIIIll1 = HC_Get(_l1ll1l1, _l11l1l1, { "Accept": _l1d_f60394("05f7fa1119121705252224682e1a3133", 118, 238) }, 5000)
if _lIIIll1 = invalid or _lIIIll1.body = "" then return _lI1Ill1
_llIIll1 = ParseJSON(_lIIIll1.body)
if _llIIll1 = invalid or type(_llIIll1) <> _l1d_f60394("b3bbecbdc0c7d6d3deccdcd0e60ddde0f6e1", 62, 103) then return _lI1Ill1
if _llIIll1.found <> true then return _lI1Ill1
_llll1l1 = _llIIll1.results
if _llll1l1 = invalid or type(_llll1l1) <> _l1d_f60394("bddbf0c6c9d9d4", 49, 122) then return _lI1Ill1
for each _l1IIll1 in _llll1l1
if type(_l1IIll1) <> _l1d_f60394("391f0c41442b3a333e4e3c56462d63665661", 13, 186) then continue for
_lIlIll1 = _l1IIll1.interval
if _lIlIll1 = invalid or type(_lIlIll1) <> _l1d_f60394("3b512e43465d5c6560506e58684f65687873", 213, 148) then continue for
_ll1l1l1 = 0.0
_lllIll1 = 0.0
if _lIlIll1.startTime <> invalid then _ll1l1l1 = _lIlIll1.startTime
if _lIlIll1.endTime <> invalid then _lllIll1 = _lIlIll1.endTime
if _lllIll1 <= _ll1l1l1 then continue for
_lIll1l1 = ""
if _l1IIll1.skipType <> invalid then _lIll1l1 = LCase(_l1IIll1.skipType)
_ll1Ill1 = ""
if _lIll1l1 = _l1d_f60394("1200", 85, 216) then _ll1Ill1 = _l1d_f60394("e5e7e0e9ef", 189, 17)
if _lIll1l1 = _l1d_f60394("6466", 152, 103) then _ll1Ill1 = _l1d_f60394("4d6a6c6959", 170, 136)
if _lIll1l1 = _l1d_f60394("565d51676ba56668", 223, 164) then _ll1Ill1 = _l1d_f60394("faf6f3f800", 126, 227)
if _lIll1l1 = _l1d_f60394("f1f8ec0206c00b0f", 189, 33) then _ll1Ill1 = _l1d_f60394("6972767775", 65, 59)
if _lIll1l1 = _l1d_f60394("c9bbc0c5d7", 174, 237) then _ll1Ill1 = _l1d_f60394("6d6764697b", 138, 117)
if _ll1Ill1 = "" then continue for
_lI1Ill1.Push({ kind: _ll1Ill1, start: _ll1l1l1, end: _lllIll1 })
end for
return _lI1Ill1
end function
function HM_JsonEscape(_l111Il1 as String) as String
if _l111Il1 = invalid or _l111Il1 = "" then return ""
_l1IlIl1 = chr(92)
_lIIlIl1 = _l111Il1
_lll1Il1 = CreateObject(_l1d_f60394("5a70406c717272", 85, 51), _l1IlIl1 + _l1IlIl1, _l1d_f60394("0f", 117, 253))
_lIIlIl1 = _lll1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1IlIl1)
_l1l1Il1 = CreateObject(_l1d_f60394("b4badac6cbccbc", 253, 37), chr(34), _l1d_f60394("bf", 55, 111))
_lIIlIl1 = _l1l1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + chr(34))
_lIl1Il1 = CreateObject(_l1d_f60394("3b4961595a5f47", 123, 50), chr(10), _l1d_f60394("12", 174, 73))
_lIIlIl1 = _lIl1Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1d_f60394("8a", 214, 210))
_ll11Il1 = CreateObject(_l1d_f60394("a399c9959a9bbb", 229, 12), chr(13), _l1d_f60394("d0", 221, 22))
_lIIlIl1 = _ll11Il1.replaceAll(_lIIlIl1, _l1IlIl1 + _l1d_f60394("02", 31, 149))
return _lIIlIl1
end function
function _l1d_f60394(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function