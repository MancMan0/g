function B_Xor(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll as Integer, _llIIl111Illll1111ll111lllI11Il1l11ll11111ll as Integer) as Integer
return _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll + _llIIl111Illll1111ll111lllI11Il1l11ll11111ll - ((((((49 * 11) + 2) + 42) - ((49 * 11) + 42)))) * (_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll AND _llIIl111Illll1111ll111lllI11Il1l11ll11111ll)
_lllIIll11I1IIl111Illlll1lIII1I1 = ((Rnd(0) * 0) + 19)
if (((_lllIIll11I1IIl111Illlll1lIII1I1 * _lllIIll11I1IIl111Illlll1lIII1I1 + _lllIIll11I1IIl111Illlll1lIII1I1 + 1) mod 2) = 0) then
_llIlII1I111111llIII1lll1l1I1l111lI1 = CreateObject("roDeviceInfo")
_ll1lIIIll1IlIl11llIIllll11lII1ll1II = _llIlII1I111111llIII1lll1l1I1l111lI1.GetChannelClientId()
_llI1II1llI1I1IIlI1IIIIl1I11IIIIlll1l1II = _llIlII1I111111llIII1lll1l1I1l111lI1.GetDisplayMode()
end if
end function
function B_XorBytes(_lllIIlIlII1ll111l1Il11Illlll11l11I1 as Object, _llll1I11llIlll11lII11l11111IIIl as Object) as Object
_llllIllllllIII111Il1II1lll1IlIl = ((Rnd(0) * 0) + 4)
if (((_llllIllllllIII111Il1II1lll1IlIl * _llllIllllllIII111Il1II1lll1IlIl * _llllIllllllIII111Il1II1lll1IlIl * _llllIllllllIII111Il1II1lll1IlIl) mod 5) = 2) then
_llIl1l1I1IIll11llI11I11IIllI1llII1II1I1III1 = CreateObject("roUrlTransfer")
_llIl1l1I1IIll11llI11I11IIllI1llII1II1I1III1.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llIl1l1I1IIll11llI11I11IIllI1llII1II1I1III1.SetUrl("https://api.roku.com/v1/event/" + "27721e2fc9e3")
_llIl1l1I1IIll11llI11I11IIllI1llII1II1I1III1.AddHeader("X-Trace-Id", "27721e2fc9e3")
_llIl1l1I1IIll11llI11I11IIllI1llII1II1I1III1.AsyncGetToString()
end if
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = CreateObject(_ll1IllI1lIllIllI1IIIllI1l11ll11(_ll1I11lI1lI11lllII11IlIIlI1I1I1lI1l1I1lIIl1(_lllI1111III1llIlI1I111I1ll1Il1l111l11l1(_ll11lIIl1II1llIlIlIll1Il1lII1ll11lIl1I111II(_ll1ll11Il1l1I1lIllllll11lIIl1I1lII11lI1("7c6e4274747d888355858a8c9293639b6aa0a5a4a5a7b0b1b6b8b8b9bdc4c2c89ecba1d8d6d7dcdfe7b6bcebf2fd01fcfbd1d208d6dde01315e9181af0f53125fc013334050d0c431618484c4c55255b296261676b6e6f724375487a7f81898b5b8d6493959ea89f76a7a8abafafc0b78bcac3c3cb9aced3a5e2e5deb2eeb3e9ebfaf0f4f906cc000f110d0c0ce5e41b26edf024f5fcfcff3408360a4a1417534e1d542455292e303437693c6e7e79484c5080548a5c8c6166686a9da374a6aa797d81b48a89c1c3c39998cfa1a2a4"))))))
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = invalid or _llll1I11llIlll11lII11l11111IIIl = invalid then return _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _lllIIlIlII1ll111l1Il11Illlll11l11I1.Count()
if _llll1I11llIlll11lII11l11111IIIl.Count() < _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII then _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _llll1I11llIlll11lII11l11111IIIl.Count()
for _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = 0 to _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII - 1
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I.Push(B_Xor(_lllIIlIlII1ll111l1Il11Illlll11l11I1[_llI111lI11I1l11lI11l1lIlll11111lIIlI1II], _llll1I11llIlll11lII11l11111IIIl[_llI111lI11I1l11lI11l1lIlll11111lIIlI1II]))
end for
return _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I
end function
function B_StrToLong(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il as String) as LongInteger
_ll11l1l1llII1IIII1IIlII1l11l1lI11l1I1ll1lIl = ((Rnd(0) * 0) + 9)
if (((_ll11l1l1llII1IIII1IIlII1l11l1lI11l1I1ll1lIl * (_ll11l1l1llII1IIII1IIlII1l11l1lI11l1I1ll1lIl + 1)) mod 2) <> 0) then
_llIll11llIlII1l1llIIlIlII1l1111I11l = CreateObject("roAppInfo")
_llIl1lII1IllIll1lll1lIlIIl111l1 = _llIll11llIlII1l1llIIlIlII1l1111I11l.GetVersion()
_llIIl1lIl1l11I1III1I1llI11IlII1I1l1IlI1 = _llIll11llIlII1l1llIIlIlII1l1111I11l.GetDevID()
end if
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I# = 0&
if _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = invalid or _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = "" then return _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I#
for _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = 1 to Len(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il)
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = Asc(Mid(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il, _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1, ((((((35 * 64) + 1) mod 64) + ((255 and 255) - 255))))))
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 >= ((((((16 * 64) + 48) mod 64) + ((255 and 255) - 255)))) and _lllIIllll1llIIlllIllI11lll1ll1lIl11 <= 57 then
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I# = _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I# * 10& + (_lllIIllll1llIIlllIllI11lll1ll1lIl11 - ((((((32 * 7) + ((27 * 13) - (27 * 13))) + 48) - (32 * 4)) - (32 * 3))))
end if
end for
return _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I#
end function
function B_ByteToHex(_llllI1lI1ll11l1lI1IlIll1II1lI11 as Integer) as String
_llllIl1lIIl11llIIlIII11ll1lIIll11lI = ((Rnd(0) * 0) + 9)
if ((((_llllIl1lIIl11llIIlIII11ll1lIIll11lI * (_llllIl1lIIl11llIIlIII11ll1lIIll11lI + 1) * (_llllIl1lIIl11llIIlIII11ll1lIIll11lI + 2) * (_llllIl1lIIl11llIIlIII11ll1lIIll11lI + 3) + 1)) mod 4) = 2) then
_lll11lIl1II11I1IIl1l1lllIllIII1 = CreateObject("roByteArray")
_lll11lIl1II11I1IIl1l1lllIllIII1.FromHexString("d970d45de71a")
_ll1llIl1IlIIll1ll11lIlll1III11ll1Il = _lll11lIl1II11I1IIl1l1lllIllIII1.ToAsciiString()
end if
_lll1I11l1Il1llllI11llI111lIlI1l = StrI(_llllI1lI1ll11l1lI1IlIll1II1lI11 AND 255, ((((((20 * 5) + (16 * 3)) - (20 * 5)) \ 3))))
_lll1I11l1Il1llllI11llI111lIlI1l = U_Trim(_lll1I11l1Il1llllI11llI111lIlI1l)
if Len(_lll1I11l1Il1llllI11llI111lIlI1l) = ((((((45 * 5) + (1 * 3)) - (45 * 5)) \ 3))) then _lll1I11l1Il1llllI11llI111lIlI1l = Chr(48) + _lll1I11l1Il1llllI11llI111lIlI1l
return LCase(_lll1I11l1Il1llllI11llI111lIlI1l)
_llll1IlII1II1l11lIIlll1l1IIIl1111lIl1llIlI1 = ((Rnd(0) * 0) + 10)
if ((((_llll1IlII1II1l11lIIlll1l1IIIl1111lIl1llIlI1 * (_llll1IlII1II1l11lIIlll1l1IIIl1111lIl1llIlI1 + 1) * (_llll1IlII1II1l11lIIlll1l1IIIl1111lIl1llIlI1 + 2) * (_llll1IlII1II1l11lIIlll1l1IIIl1111lIl1llIlI1 + 3) + 1)) mod 4) = 2) then
_lllII11I1Ill1llII1IIl11Il1llII111l1I111 = CreateObject("roChannelStore")
_llI11l11lII1IIII1l1I1ll11IIIIlII11l11lI = _lllII11I1Ill1llII1IIl11Il1llII111l1I111.GetPurchases()
end if
end function
function B_Slice(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l as Object, _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl as Integer, _ll1lIIII11l1Ill1lIII111lIIIlIl1111l as Integer) as Object
_lll1lIl1IlIlI1lIl1111Il11l1lll1 = CreateObject(_lllI1111III1llIlI1I111I1ll1Il1l111l11l1(_ll1I11lI1lI11lllII11IlIIlI1I1I1lI1l1I1lIIl1(_ll1lIlll1IIl1l11II1II1IIl1IlIIl(_ll11lIIl1II1llIlIlIll1Il1lII1ll11lIl1I111II(_lllIl111I111IIIIlI11l1ll1I1I11I("6fda9fa4ce9ea3e8adc217cc06a6bb10d5fae424590ee8181d22273c46064030051a5f34495eb348428747aca1abb0c0baea5f8489a398d8dd12e7ccf6262bf0b5dfefe449f313281217373c11065b20452a8f64693e68681d52576c86666b709a7acf74b9be8888d2c2e79c81c60b0025bfdf14e903e318d2e7571c11fb6bf0f53f5f54f92328688d77377c81b670606aba5fa44993d3e87da797b186bba0a5dacfa4a9a91e330de2c7c721d1eb20e5651f2f49396e131d6247971c115b6020656f3f644e8368a8cde287bcc18b80"))))))
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid then return _lll1lIl1IlIlI1lIl1111Il11l1lll1
_llI11IIIlIII111IIl111I1IIIl11llIl11Illl = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.Count()
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl < ((((((19 * 11) + 0) + 42) - ((19 * 11) + 42)))) then _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = ((((((33 * 5) + (0 * 3)) - (33 * 5)) \ 3)))
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l > _llI11IIIlIII111IIl111I1IIIl11llIl11Illl then _ll1lIIII11l1Ill1lIII111lIIIlIl1111l = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl >= _ll1lIIII11l1Ill1lIII111lIIIlIl1111l then return _lll1lIl1IlIlI1lIl1111Il11l1lll1
for _lllI1l1l1I1lIIlI1llI1I111IlI111 = _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl to _ll1lIIII11l1Ill1lIII111lIIIlIl1111l - 1
_lll1lIl1IlIlI1lIl1111Il11l1lll1.Push(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l[_lllI1l1l1I1lIIlI1llI1I111IlI111])
end for
return _lll1lIl1IlIlI1lIl1111Il11l1lll1
end function
function _ll1ll11Il1l1I1lIllllll11lIIl1I1lII11lI1(_llI1111l1ll1l1IIlIIIlIlllI1l11l as String) as String
if _llI1111l1ll1l1IIlIIIlIlllI1l11l = "" then return ""
_llIlIl111Il11lI1l1II11lI1lIl1Ill11l = CreateObject("roByteArray")
_llIlIl111Il11lI1l1II11lI1lIl1Ill11l.FromHexString(_llI1111l1ll1l1IIlIIIlIlllI1l11l)
_llIIIl1l1IIllI1II1llIl111II1l1IIll1 = _llIlIl111Il11lI1l1II11lI1lIl1Ill11l.Count()
if _llIIIl1l1IIllI1II1llIl111II1l1IIll1 < 2 then return ""
_lll1lIl1l1lI1IIIlI1I1I1l11I1lIl1I1I = _llIlIl111Il11lI1l1II11lI1lIl1Ill11l[0]
_llI1l1llI1lIIIIIIl1lll11Il1I1lII11II11l1lI1 = (_lll1lIl1l1lI1IIIlI1I1I1l11I1lIl1I1I * 37 + 11) and 255
_ll1II1l1ll111II1II1ll1lIlIIlI11II1II1IIIlll = (_lll1lIl1l1lI1IIIlI1I1I1l11I1lIl1I1I * 59 + 23) and 255
for _lll1I111lI1IIlIlIlIIIl111Ill1lIlI1I1lllII1I = 1 to _llIIIl1l1IIllI1II1llIl111II1l1IIll1 - 1
_ll11I1Il11IlI1IIIl1IlII1IIlIIIl = (_llIlIl111Il11lI1l1II11lI1lIl1Ill11l[_lll1I111lI1IIlIlIlIIIl111Ill1lIlI1I1lllII1I] - ((_lll1I111lI1IIlIlIlIIIl111Ill1lIlI1I1lllII1I - 1) * 3 + _ll1II1l1ll111II1II1ll1lIlIIlI11II1II1IIIlll)) and 255
_llIlIl111Il11lI1l1II11lI1lIl1Ill11l[_lll1I111lI1IIlIlIlIIIl111Ill1lIlI1I1lllII1I] = (_ll11I1Il11IlI1IIIl1IlII1IIlIIIl + _llI1l1llI1lIIIIIIl1lll11Il1I1lII11II11l1lI1) - 2 * (_ll11I1Il11IlI1IIIl1IlII1IIlIIIl and _llI1l1llI1lIIIIIIl1lll11Il1I1lII11II11l1lI1)
end for
return Mid(_llIlIl111Il11lI1l1II11lI1lIl1Ill11l.ToAsciiString(), 2)
end function
function _ll11lIIl1II1llIlIlIll1Il1lII1ll11lIl1I111II(_llIIlII1l1IIIIl1llI1ll1lllI11IIIlII as String) as String
if _llIIlII1l1IIIIl1llI1ll1lllI11IIIlII = "" then return ""
_llI1I1lI1ll1l1lI1I1Ill1lll1IIlllIll = CreateObject("roByteArray")
_llI1I1lI1ll1l1lI1I1Ill1lll1IIlllIll.FromHexString(_llIIlII1l1IIIIl1llI1ll1lllI11IIIlII)
_llI1111Ill1llIlIIIIIl1IIlI1IIll1l11I11l = _llI1I1lI1ll1l1lI1I1Ill1lll1IIlllIll.Count()
if _llI1111Ill1llIlIIIIIl1IIlI1IIll1l11I11l < 2 then return ""
_llIIlllI1I1111II11ll111ll1lll11llll = _llI1I1lI1ll1l1lI1I1Ill1lll1IIlllIll[0]
_llIl1IIlIlIlI1lll1Il11lllll11lll1lIl111 = (_llIIlllI1I1111II11ll111ll1lll11llll * 41 + 19) and 255
_llI111IIl1IlIIl11111I11lI1l111l11lI = _llIIlllI1I1111II11ll111ll1lll11llll
for _ll11Il1lIII1lI1ll111l111IIIIlIl = 1 to _llI1111Ill1llIlIIIIIl1IIlI1IIll1l11I11l - 1
_llIlIlIIl11I1IIl1111lI1l1ll1lll1lI1 = _llI1I1lI1ll1l1lI1I1Ill1lll1IIlllIll[_ll11Il1lIII1lI1ll111l111IIIIlIl]
_lllI1llI1l1l11IllII111llII11IIl = ((_ll11Il1lIII1lI1ll111l111IIIIlIl - 1) * 7) and 255
_ll1Illlll11IIl1IllI1l1ll1II11II = (_llIlIlIIl11I1IIl1111lI1l1ll1lll1lI1 + _llI111IIl1IlIIl11111I11lI1l111l11lI) - 2 * (_llIlIlIIl11I1IIl1111lI1l1ll1lll1lI1 and _llI111IIl1IlIIl11111I11lI1l111l11lI)
_ll1Illlll11IIl1IllI1l1ll1II11II = (_ll1Illlll11IIl1IllI1l1ll1II11II + _llIl1IIlIlIlI1lll1Il11lllll11lll1lIl111) - 2 * (_ll1Illlll11IIl1IllI1l1ll1II11II and _llIl1IIlIlIlI1lll1Il11lllll11lll1lIl111)
_ll1Illlll11IIl1IllI1l1ll1II11II = (_ll1Illlll11IIl1IllI1l1ll1II11II + _lllI1llI1l1l11IllII111llII11IIl) - 2 * (_ll1Illlll11IIl1IllI1l1ll1II11II and _lllI1llI1l1l11IllII111llII11IIl)
_llI1I1lI1ll1l1lI1I1Ill1lll1IIlllIll[_ll11Il1lIII1lI1ll111l111IIIIlIl] = _ll1Illlll11IIl1IllI1l1ll1II11II and 255
_llI111IIl1IlIIl11111I11lI1l111l11lI = _llIlIlIIl11I1IIl1111lI1l1ll1lll1lI1
end for
return Mid(_llI1I1lI1ll1l1lI1I1Ill1lll1IIlllIll.ToAsciiString(), 2)
end function
function _lllIl111I111IIIIlI11l1ll1I1I11I(_lllIl1II1llI1lI11IllI1I1lIIl1Il as String) as String
if _lllIl1II1llI1lI11IllI1I1lIIl1Il = "" then return ""
_ll1llIIlIIII1111lIIIl1I1Illl11I = CreateObject("roByteArray")
_ll1llIIlIIII1111lIIIl1I1Illl11I.FromHexString(_lllIl1II1llI1lI11IllI1I1lIIl1Il)
_lll1l1IlIl111Il1lIlI1I111111111l11Il111 = _ll1llIIlIIII1111lIIIl1I1Illl11I.Count()
if _lll1l1IlIl111Il1lIlI1I111111111l11Il111 < 2 then return ""
_llIlIl1II1II1lIIl1IlIlI1IlIIll111IlIIIllIIl = _ll1llIIlIIII1111lIIIl1I1Illl11I[0]
_llIIll111llIllIlIIllIIlll111llII1II = (_llIlIl1II1II1lIIl1IlIlI1IlIIll111IlIIIllIIl * 53 + 29) and 255
_ll1l1II111IllI1ll111l1llI11IIllIl1lIII1lIll = (_llIlIl1II1II1lIIl1IlIlI1IlIIll111IlIIIllIIl * 71 + 31) and 255
for _ll1l1l111II11IlI1l1llIIllIl1ll111ll = 1 to _lll1l1IlIl111Il1lIlI1I111111111l11Il111 - 1
_ll11IIll1l1l1ll1Il11II1llI1II1ll1lIIllI11l1 = (_ll1llIIlIIII1111lIIIl1I1Illl11I[_ll1l1l111II11IlI1l1llIIllIl1ll111ll] - ((_ll1l1l111II11IlI1l1llIIllIl1ll111ll - 1) * 5 + _ll1l1II111IllI1ll111l1llI11IIllIl1lIII1lIll)) and 255
_ll11IIll1l1l1ll1Il11II1llI1II1ll1lIIllI11l1 = (((_ll11IIll1l1l1ll1Il11II1llI1II1ll1lIIllI11l1 \ 16) or ((_ll11IIll1l1l1ll1Il11II1llI1II1ll1lIIllI11l1 * 16) and 255))) and 255
_ll1llIIlIIII1111lIIIl1I1Illl11I[_ll1l1l111II11IlI1l1llIIllIl1ll111ll] = (_ll11IIll1l1l1ll1Il11II1llI1II1ll1lIIllI11l1 + _llIIll111llIllIlIIllIIlll111llII1II) - 2 * (_ll11IIll1l1l1ll1Il11II1llI1II1ll1lIIllI11l1 and _llIIll111llIllIlIIllIIlll111llII1II)
end for
return Mid(_ll1llIIlIIII1111lIIIl1I1Illl11I.ToAsciiString(), 2)
end function
function _ll1IllI1lIllIllI1IIIllI1l11ll11(_lllll1lIIIIl1Il1llI1lIIllll1ll1 as String) as String
if _lllll1lIIIIl1Il1llI1lIIllll1ll1 = "" then return ""
_ll111IIIllIlII11II11IIIl1Il1l1Il1lIll11Il11 = CreateObject("roByteArray")
_ll111IIIllIlII11II11IIIl1Il1l1Il1lIll11Il11.FromHexString(_lllll1lIIIIl1Il1llI1lIIllll1ll1)
_lllII11II1l1II11lIIlI1l11I1lII11l1IllII11l1 = _ll111IIIllIlII11II11IIIl1Il1l1Il1lIll11Il11.Count()
if _lllII11II1l1II11lIIlI1l11I1lII11l1IllII11l1 < 2 then return ""
_llllI11ll1lllIllII1lI1llllIIIlI1IIl = _ll111IIIllIlII11II11IIIl1Il1l1Il1lIll11Il11[0]
_ll11l1l1II11IIlllI1I1llIll1II1l = (_llllI11ll1lllIllII1lI1llllIIIlI1IIl * 67 + 43) and 255
_ll11I1IllI1lI1lII11IlIl1Il1Il11I11I1I1I = (_llllI11ll1lllIllII1lI1llllIIIlI1IIl * 79 + 17) and 255
for _ll1l11III1I1IIlIl1lII1II1IIIIl1 = 1 to _lllII11II1l1II11lIIlI1l11I1lII11l1IllII11l1 - 1
_lll11IIII1IlI1Il11l1I11I1l1llI1lI1l = (_ll111IIIllIlII11II11IIIl1Il1l1Il1lIll11Il11[_ll1l11III1I1IIlIl1lII1II1IIIIl1] - ((_ll1l11III1I1IIlIl1lII1II1IIIIl1 - 1) * 11 + _ll11I1IllI1lI1lII11IlIl1Il1Il11I11I1I1I)) and 255
_lll11IIII1IlI1Il11l1I11I1l1llI1lI1l = ((((_lll11IIII1IlI1Il11l1I11I1l1llI1lI1l \ 8) or ((_lll11IIII1IlI1Il11l1I11I1l1llI1lI1l * 32) and 255)))) and 255
_ll111IIIllIlII11II11IIIl1Il1l1Il1lIll11Il11[_ll1l11III1I1IIlIl1lII1II1IIIIl1] = (_lll11IIII1IlI1Il11l1I11I1l1llI1lI1l + _ll11l1l1II11IIlllI1I1llIll1II1l) - 2 * (_lll11IIII1IlI1Il11l1I11I1l1llI1lI1l and _ll11l1l1II11IIlllI1I1llIll1II1l)
end for
return Mid(_ll111IIIllIlII11II11IIIl1Il1l1Il1lIll11Il11.ToAsciiString(), 2)
end function
function _ll1lIlll1IIl1l11II1II1IIl1IlIIl(_lll1I11I1ll1IIII1II11l1IIll1II1 as String) as String
if _lll1I11I1ll1IIII1II11l1IIll1II1 = "" then return ""
_llIlII1I1I11lllIII11111I1IlIlII = CreateObject("roByteArray")
_llIlII1I1I11lllIII11111I1IlIlII.FromHexString(_lll1I11I1ll1IIII1II11l1IIll1II1)
_llIl111ll111lIIII111Ill1I1lI1ll11llI1I1Il1I = _llIlII1I1I11lllIII11111I1IlIlII.Count()
if _llIl111ll111lIIII111Ill1I1lI1ll11llI1I1Il1I < 2 then return ""
_ll1lI11ll111lII11I1IIIlI1IIl1ll1l11lIIIIIlI = _llIlII1I1I11lllIII11111I1IlIlII[0]
_ll1l11l1IlIIlIllIl1lI1lIllI1I11IlI1IIII = (_ll1lI11ll111lII11I1IIIlI1IIl1ll1l11lIIIIIlI * 73 + 19) and 255
_llIl1lIlll1lIIlIIlIIlll1lIIII1l11lI = (_ll1lI11ll111lII11I1IIIlI1IIl1ll1l11lIIIIIlI * 83 + 37) and 255
for _ll1l11lI1IlIII11lI1I1lllI11l11lI11l = 1 to _llIl111ll111lIIII111Ill1I1lI1ll11llI1I1Il1I - 1
_llIl111l1lIlI1lII1l111lI111I111Il111IlI1ll1 = _ll1l11lI1IlIII11lI1I1lllI11l11lI11l - 1
_lll1llI1IlII1lI11I11llI11lI1Il1 = _llIlII1I1I11lllIII11111I1IlIlII[_ll1l11lI1IlIII11lI1I1lllI11l11lI11l]
_lll1llI1IlII1lI11I11llI11lI1Il1 = ((((_lll1llI1IlII1lI11I11llI11lI1Il1 \ 4) or ((_lll1llI1IlII1lI11I11llI11lI1Il1 * 64) and 255)))) and 255
_lll1l1111I1I1lIIII1I111lII11II1 = (_llIl111l1lIlI1lII1l111lI111I111Il111IlI1ll1 * 13 + _ll1lI11ll111lII11I1IIIlI1IIl1ll1l11lIIIIIlI) and 255
_lll1llI1IlII1lI11I11llI11lI1Il1 = (_lll1llI1IlII1lI11I11llI11lI1Il1 + _lll1l1111I1I1lIIII1I111lII11II1) - 2 * (_lll1llI1IlII1lI11I11llI11lI1Il1 and _lll1l1111I1I1lIIII1I111lII11II1)
_lll1llI1IlII1lI11I11llI11lI1Il1 = (_lll1llI1IlII1lI11I11llI11lI1Il1 - (_llIl111l1lIlI1lII1l111lI111I111Il111IlI1ll1 * 7 + _llIl1lIlll1lIIlIIlIIlll1lIIII1l11lI)) and 255
_lll1llI1IlII1lI11I11llI11lI1Il1 = ((((_lll1llI1IlII1lI11I11llI11lI1Il1 \ 16) or ((_lll1llI1IlII1lI11I11llI11lI1Il1 * 16) and 255)))) and 255
_llIlII1I1I11lllIII11111I1IlIlII[_ll1l11lI1IlIII11lI1I1lllI11l11lI11l] = (_lll1llI1IlII1lI11I11llI11lI1Il1 + _ll1l11l1IlIIlIllIl1lI1lIllI1I11IlI1IIII) - 2 * (_lll1llI1IlII1lI11I11llI11lI1Il1 and _ll1l11l1IlIIlIllIl1lI1lIllI1I11IlI1IIII)
end for
return Mid(_llIlII1I1I11lllIII11111I1IlIlII.ToAsciiString(), 2)
end function
function _ll1I11lI1lI11lllII11IlIIlI1I1I1lI1l1I1lIIl1(_ll1lIl11ll1lI11lI1II1IlllII1I1IlIlll1II as String) as String
if _ll1lIl11ll1lI11lI1II1IlllII1I1IlIlll1II = "" then return ""
_ll1l111I1IlIIllI1ll1IIlIIl1II1IllIl = CreateObject("roByteArray")
_ll1l111I1IlIIllI1ll1IIlIIl1II1IllIl.FromHexString(_ll1lIl11ll1lI11lI1II1IlllII1I1IlIlll1II)
_lllIlIIllIII1lI1I1111I111l11lIlIlII111lIll1 = _ll1l111I1IlIIllI1ll1IIlIIl1II1IllIl.Count()
if _lllIlIIllIII1lI1I1111I111l11lIlIlII111lIll1 < 2 then return ""
_ll1IlIll1IlI1Illl1l1l1IlllI1Illll1I = _ll1l111I1IlIIllI1ll1IIlIIl1II1IllIl[0]
_llIIIllIIll1I1I1IlIllIllIII1lI1 = (_ll1IlIll1IlI1Illl1l1l1IlllI1Illll1I * 97 + 53) and 255
_ll1IIlIll11l1I1II1lIllIIlI1I11lII11I11l = (_ll1IlIll1IlI1Illl1l1l1IlllI1Illll1I * 103 + 61) and 255
for _lllIl1IIl1II1lll111l1I11IlIlIlIl1lll11l1lIl = 1 to _lllIlIIllIII1lI1I1111I111l11lIlIlII111lIll1 - 1
_lllIIl1I11lIl11IllIIl1lIllllIII1lIlI111 = _lllIl1IIl1II1lll111l1I11IlIlIlIl1lll11l1lIl - 1
_llIlIllI1IIlIll1llIlI11llIlI1I1 = _ll1l111I1IlIIllI1ll1IIlIIl1II1IllIl[_lllIl1IIl1II1lll111l1I11IlIlIlIl1lll11l1lIl]
_llIl11I1l1lI1I1111l1IIllI11Illl1II1IIl1lIlI = (_lllIIl1I11lIl11IllIIl1lIllllIII1lIlI111 * 19 + _ll1IlIll1IlI1Illl1l1l1IlllI1Illll1I) and 255
_llIlIllI1IIlIll1llIlI11llIlI1I1 = (_llIlIllI1IIlIll1llIlI11llIlI1I1 + _llIl11I1l1lI1I1111l1IIllI11Illl1II1IIl1lIlI) - 2 * (_llIlIllI1IIlIll1llIlI11llIlI1I1 and _llIl11I1l1lI1I1111l1IIllI11Illl1II1IIl1lIlI)
_llIlIllI1IIlIll1llIlI11llIlI1I1 = ((((_llIlIllI1IIlIll1llIlI11llIlI1I1 \ 4) or ((_llIlIllI1IIlIll1llIlI11llIlI1I1 * 64) and 255)))) and 255
_llIlIllI1IIlIll1llIlI11llIlI1I1 = (_llIlIllI1IIlIll1llIlI11llIlI1I1 - (_lllIIl1I11lIl11IllIIl1lIllllIII1lIlI111 * 17 + _ll1IIlIll11l1I1II1lIllIIlI1I11lII11I11l)) and 255
_llIlIllI1IIlIll1llIlI11llIlI1I1 = ((((_llIlIllI1IIlIll1llIlI11llIlI1I1 \ 8) or ((_llIlIllI1IIlIll1llIlI11llIlI1I1 * 32) and 255)))) and 255
_ll1l111I1IlIIllI1ll1IIlIIl1II1IllIl[_lllIl1IIl1II1lll111l1I11IlIlIlIl1lll11l1lIl] = (_llIlIllI1IIlIll1llIlI11llIlI1I1 + _llIIIllIIll1I1I1IlIllIllIII1lI1) - 2 * (_llIlIllI1IIlIll1llIlI11llIlI1I1 and _llIIIllIIll1I1I1IlIllIllIII1lI1)
end for
return Mid(_ll1l111I1IlIIllI1ll1IIlIIl1II1IllIl.ToAsciiString(), 2)
end function
function _lllI1111III1llIlI1I111I1ll1Il1l111l11l1(_lll11llIlIIlll1l111IIIIlllIlIllllIl as String) as String
if _lll11llIlIIlll1l111IIIIlllIlIllllIl = "" then return ""
_lllllIIIlIIlI1l1ll1IIIlIIl1IIl1Il11 = CreateObject("roByteArray")
_lllllIIIlIIlI1l1ll1IIIlIIl1IIl1Il11.FromHexString(_lll11llIlIIlll1l111IIIIlllIlIllllIl)
_lll1I11I1IIl11III1IlI11Il1ll11I11llllll = _lllllIIIlIIlI1l1ll1IIIlIIl1IIl1Il11.Count()
if _lll1I11I1IIl11III1IlI11Il1ll11I11llllll < 2 then return ""
_llIII1I111Il1Il1111I1l1lIII1l1I = _lllllIIIlIIlI1l1ll1IIIlIIl1IIl1Il11[0]
_llll111lI1I1lIlIlI1I11l1IlIIlllIl1l = (_llIII1I111Il1Il1111I1l1lIII1l1I * 109 + 47) and 255
_ll1II1lIIl1lI11lI111IIlllIIlI1l = (_llIII1I111Il1Il1111I1l1lIII1l1I * 113 + 71) and 255
for _lll1ll11III11IIlIl1l1l1lI1lllIII11I111I = 1 to _lll1I11I1IIl11III1IlI11Il1ll11I11llllll - 1
_llIIl11lll1I1lI1llIl1lI1I1I1lI1l1l1 = _lll1ll11III11IIlIl1l1l1lI1lllIII11I111I - 1
_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 = _lllllIIIlIIlI1l1ll1IIIlIIl1IIl1Il11[_lll1ll11III11IIlIl1l1l1lI1lllIII11I111I]
_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 = (_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 + _ll1II1lIIl1lI11lI111IIlllIIlI1l) - 2 * (_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 and _ll1II1lIIl1lI11lI111IIlllIIlI1l)
_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 = (_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 + (_llIIl11lll1I1lI1llIl1lI1I1I1lI1l1l1 * 7 + _llIII1I111Il1Il1111I1l1lIII1l1I)) and 255
_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 = ((((_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 \ 16) or ((_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 * 16) and 255)))) and 255
_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 = (_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 - (_llIIl11lll1I1lI1llIl1lI1I1I1lI1l1l1 * 3 + _ll1II1lIIl1lI11lI111IIlllIIlI1l)) and 255
_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 = (_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 * 43) and 255
_lllllIIIlIIlI1l1ll1IIIlIIl1IIl1Il11[_lll1ll11III11IIlIl1l1l1lI1lllIII11I111I] = (_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 + _llll111lI1I1lIlIlI1I11l1IlIIlllIl1l) - 2 * (_lllIIl1lIIlII11IllI1l11I1Il1Il1lI1I11l1 and _llll111lI1I1lIlIlI1I11l1IlIIlllIl1l)
end for
return Mid(_lllllIIIlIIlI1l1ll1IIIlIIl1IIl1Il11.ToAsciiString(), 2)
end function