function KA_GetConfig() as Object
return {
name: _l1d_a500bd("2c1a21152d142218", 172, 67),
ownerid: _l1d_a500bd("463f66f65e3b62514866", 48, 234),
version: _l1d_a500bd("9ab29f", 180, 21),
apiUrl: _l1d_a500bd("c3d2d5d4da241c1fdedbf2ddf4f6ed3602f7ff43f80a064f54545c5b", 192, 27)
}
end function
function KA_GetChecksum() as String
if ((74232 - 8248 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llIll1l = CreateObject(_l1d_a500bd("d8f8cee8e6fad9edf002fd", 144, 246))
if _llIll1l.ReadFile(_l1d_a500bd("eb05fc3a4a0f0e121c10160b0b", 214, 69)) then
_l1Ill1l = CreateObject(_l1d_a500bd("6d5d8a9a9b926a777c8991", 170, 149))
if _l1Ill1l <> invalid and _l1Ill1l.Setup(_l1d_a500bd("e0dcae", 161, 20)) = 0 then
return _l1Ill1l.Process(_llIll1l)
end if
end if
return ""
end function
function KA_GetHwid() as String
_lIII11l = U_PrefDefault(_l1d_a500bd("454e3f4b6d5260", 136, 98), "")
if _lIII11l <> "" and Len(_lIII11l) >= 20 then return _lIII11l
_lI1I11l = CreateObject(_l1d_a500bd("04120022141c252e052b3630", 27, 155))
_l11I11l = _lI1I11l.GetChannelClientId()
if _l11I11l = invalid or Len(_l11I11l) < 8 then _l11I11l = _lI1I11l.GetRandomUUID()
_l1II11l = _lI1I11l.GetModel()
if _l1II11l = invalid or _l1II11l = "" then _l1II11l = _l1d_a500bd("b2d0cfbc", 209, 47)
_llII11l = _l1d_a500bd("556d745d18", 182, 113) + _l1II11l + _l1d_a500bd("17", 137, 115) + _l11I11l
while Len(_llII11l) < 24
_llII11l = _llII11l + _l1d_a500bd("46", 242, 132)
end while
U_PrefSet(_l1d_a500bd("a4addeacccb1c1", 233, 34), _llII11l)
return _llII11l
end function
function KA_HttpPost(_l1lIlIl as Object) as Object
_ll11lIl = KA_GetConfig()
_llIIlIl = CreateObject(_l1d_a500bd("83816e8c8d789589979d9599a7", 131, 146))
_llIIlIl.SetCertificatesFile(_l1d_a500bd("4948494c5153221a6166767b7d2c7374337b917d86818d4991a3a8", 8, 222))
_llIIlIl.InitClientCertificates()
_llIIlIl.SetUrl(_ll11lIl.apiUrl)
_llIIlIl.RetainBodyOnError(true)
_llIIlIl.EnableEncodings(true)
_llIIlIl.AddHeader(_l1d_a500bd("5c4b4d364a563f1b654d475f", 48, 233), _l1d_a500bd("20141726242d322a3035397b2d833c3f428f59534b5b9e595768726c72717f8185", 91, 230))
_llIIlIl.AddHeader(_l1d_a500bd("7f5c5561937a5f645c79", 234, 192), _l1d_a500bd("7c6e7979928068a28b7181d0a0989f84e1cee6d3", 116, 86))
_llIIlIl.AddHeader(_l1d_a500bd("f112151e2c33", 66, 238), _l1d_a500bd("8175788f958e9383a19ea264ac96adb17675a4b6b6ad85b7ceccd7d59a99a2a0a8", 183, 171))
_lIl1lIl = ""
_lI11lIl = true
for each _l1I1lIl in _l1lIlIl
if not _lI11lIl then _lIl1lIl = _lIl1lIl + _l1d_a500bd("f1", 30, 185)
_lIl1lIl = _lIl1lIl + _l1I1lIl.ToStr() + _l1d_a500bd("9d", 18, 110) + _llIIlIl.Escape(_l1lIlIl[_l1I1lIl].ToStr())
_lI11lIl = false
end for
_lllIlIl = CreateObject(_l1d_a500bd("9e9ec39eabaea3a8addbb9bfc8", 162, 206))
_llIIlIl.SetMessagePort(_lllIlIl)
if not _llIIlIl.AsyncPostFromString(_lIl1lIl) then
return { success: false, message: _l1d_a500bd("d6c0cbc9c5c78ebdd797d9e0e2e5e3e8d8afdef8b809ff0a06230df92f1c0212dc0e1f1312342d2ef6", 54, 102) }
end if
_lI1IlIl = CreateObject(_l1d_a500bd("20300830374233334747", 152, 54))
_lI1IlIl.mark()
_l111lIl = 12000
_ll1IlIl = ""
_l11IlIl = 0
while _lI1IlIl.totalMilliseconds() < _l111lIl
_lIlIlIl = _l111lIl - _lI1IlIl.totalMilliseconds()
if _lIlIlIl < 1 then exit while
_lII1lIl = wait(_lIlIlIl, _lllIlIl)
if _lII1lIl = invalid then exit while
if type(_lII1lIl) = _l1d_a500bd("b3bb98bcc5b1c1d7cfcc", 222, 7) then
_l11IlIl = _lII1lIl.getResponseCode()
_ll1IlIl = _lII1lIl.getString()
if _ll1IlIl = invalid then _ll1IlIl = ""
exit while
end if
end while
if _ll1IlIl = "" and _l11IlIl = 0 then
_llIIlIl.AsyncCancel()
return { success: false, message: _l1d_a500bd("2554585b53544a60696da2596f767175b4846d71cec367918f909bd58fa89193e4aeb8a1b3a5c4bcb0ffc3d2d6d9d1d2c8dee7eb2e", 209, 147) }
end if
_llI1lIl = ParseJson(_ll1IlIl)
if _llI1lIl = invalid then
if _l11IlIl > 0 then
return { success: false, message: _l1d_a500bd("d3050000e907fff912080862221a1d2523746f12090c1386", 92, 197) + _l11IlIl.ToStr() + _l1d_a500bd("f9f506a2beb9d3c9d1d71ecfe1d6dae0e2e2f32b", 94, 130) }
else
return { success: false, message: _l1d_a500bd("a7958789948a96e2a4a3a5a8b6b3abb3b8ba03cbb7bacac00f18fad6e6e3de2ad6ebe8e439f5f9f60af6051305541615171a28251d252a2c6f", 250, 243) }
end if
end if
return _llI1lIl
end function
function KA_Init() as Object
_llllIIl = KA_GetConfig()
_l1llIIl = KA_GetChecksum()
_ll1lIIl = {
"type": _l1d_a500bd("3f454555", 67, 21),
"ver": _llllIIl.version,
"hash": _l1llIIl,
"name": _llllIIl.name,
"ownerid": _llllIIl.ownerid
}
_l11lIIl = KA_HttpPost(_ll1lIIl)
if _l11lIIl.success = true and _l11lIIl.sessionid <> invalid and _l11lIIl.sessionid <> "" then
return { success: true, sessionid: _l11lIIl.sessionid, message: _l11lIIl.message }
else
_lIllIIl = _l1d_a500bd("544853516e564478654d5ba757685e5d7d7677bf89878f779590989e909c8caaa7abeca9b1bcbcb6ba", 247, 175)
if _l11lIIl.message <> invalid then _lIllIIl = _l11lIIl.message
return { success: false, message: _lIllIIl }
end if
end function
function KA_CleanAuthMessage(_lII1ll1 as String) as String
if ((25280 - 5056 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lII1ll1 = invalid or _lII1ll1 = "" then return ""
_l1I1ll1 = _lII1ll1
_lllIll1 = CreateObject(_l1d_a500bd("c9b1afbdc2c3d1", 140, 203), _l1d_a500bd("d8dac5d9e1e7dfa6d4ddeae4fbf7fef915f5d1cf2101dd1d1f0a1e262c24eb32383532402e3b034f4443", 181, 252), _l1d_a500bd("2d", 200, 140))
if _lllIll1 <> invalid then _l1I1ll1 = _lllIll1.replaceAll(_l1I1ll1, _l1d_a500bd("405c4761676f652c737b74757d6d7e448e8786", 150, 97))
_l1lIll1 = CreateObject(_l1d_a500bd("ebd311e3e4e9f7", 46, 143), _l1d_a500bd("b1b5a0b2c0c0be7db5b2cbb7d6d0dfda98e6cca1f0f0e9f2fae2fbb90304fb", 146, 182), _l1d_a500bd("ca", 241, 50))
if _l1lIll1 <> invalid then _l1I1ll1 = _l1lIll1.replaceAll(_l1I1ll1, _l1d_a500bd("2c0e291d151b236a212734312f4d3a823e4352", 109, 8))
_l11Ill1 = CreateObject(_l1d_a500bd("f901df0d121301", 156, 11), _l1d_a500bd("99ab9c9fa6c1a9c281c8d0cdba98dd97cdd8e9d6e1a8f5f7e5bbb705fcf4000e05fc0eff02d826250e2f261e2a382f262a554a4932534a424e5c534a5c4d5057725a7332807f688980788492", 179, 214), _l1d_a500bd("dc", 67, 178))
if _l11Ill1 <> invalid then _l1I1ll1 = _l11Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("78a0adaaa6c6b3f9b7bccb05c4c2cbe414cdd1e920d8e7f5efe7", 204, 248))
_l1IIll1 = CreateObject(_l1d_a500bd("56643c7075765e", 89, 43), _l1d_a500bd("cbd4c1d9c0cec5d096cfd3eba2e3dff8e4edf804f024f6fa12300a061f0b14", 44, 114), _l1d_a500bd("d4", 31, 94))
if _l1IIll1 <> invalid then _l1I1ll1 = _l1IIll1.replaceAll(_l1I1ll1, _l1d_a500bd("759daaa7a3c3b076b4b9c882bbbfd78ecfcbe4d0d9", 12, 53))
_lIlIll1 = CreateObject(_l1d_a500bd("343c1a484d4e3c", 156, 70), _l1d_a500bd("2e2a352f353d337a4a4f40544b4d544f", 102, 31), _l1d_a500bd("74", 27, 2))
if _lIlIll1 <> invalid then _l1I1ll1 = _lIlIll1.replaceAll(_l1I1ll1, _l1d_a500bd("fbddc8dce4eae229f0f6f3f0feecf9410d0201", 245, 63))
_llll1l1 = CreateObject(_l1d_a500bd("9280788c91929a", 137, 151), _l1d_a500bd("3237483c53555c571d4e605756755d6f71", 182, 111), _l1d_a500bd("47", 40, 6))
if _llll1l1 <> invalid then _l1I1ll1 = _llll1l1.replaceAll(_l1I1ll1, _l1d_a500bd("78606d6a66667339777c6b457a887f7e8d899799", 188, 136))
_lI1Ill1 = CreateObject(_l1d_a500bd("5f6d857d7e836b", 251, 214), _l1d_a500bd("6e82737675807e8fd68799908f9e96a8aa", 254, 224), _l1d_a500bd("a8", 51, 78))
if _lI1Ill1 <> invalid then _l1I1ll1 = _lI1Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("7da5b2afababb87ebcc1b08abfcdc4c3d2cedcde", 28, 45))
_lIIIll1 = CreateObject(_l1d_a500bd("0c0a32060b0c24", 161, 57), _l1d_a500bd("949daaa2a9b7aeb97fb9b788bbcfc4c7c6d1cfdc", 28, 43), _l1d_a500bd("d2", 152, 225))
if _lIIIll1 <> invalid then _l1I1ll1 = _lIIIll1.replaceAll(_l1I1ll1, _l1d_a500bd("545a575462505da5716665", 85, 27))
_llIIll1 = CreateObject(_l1d_a500bd("ee0e140a0f1006", 176, 44), _l1d_a500bd("b1b6c7bbc2d4cbd6", 62, 102), _l1d_a500bd("36", 19, 188))
if _llIIll1 <> invalid then _l1I1ll1 = _llIIll1.replaceAll(_l1I1ll1, _l1d_a500bd("c0ded7e0eaf0e9a9d1f209", 3, 113))
_ll1Ill1 = CreateObject(_l1d_a500bd("f50ddb0d0e1311", 86, 209), _l1d_a500bd("1b2f24272e492f44", 80, 251), _l1d_a500bd("da", 55, 124))
if _ll1Ill1 <> invalid then _l1I1ll1 = _ll1Ill1.replaceAll(_l1I1ll1, _l1d_a500bd("eacad3dcd4cce523fdeed5", 122, 180))
return _l1I1ll1
end function
function KA_License(_lll1Il1 as String) as Object
if _lll1Il1 = invalid or U_Trim(_lll1Il1) = "" then
return { success: false, message: _l1d_a500bd("ceada7a6b7b070b6c0cdbfcd82dcd1dedc91e0ded7e0eaf0e9a9f1f209bf", 35, 91) }
end if
_lll1Il1 = U_Trim(_lll1Il1)
_lIIlIl1 = KA_Init()
if not _lIIlIl1.success then
return _lIIlIl1
end if
_lI1lIl1 = KA_GetConfig()
_l1IlIl1 = KA_GetHwid()
_ll11Il1 = {
"type": _l1d_a500bd("d1d7d2dfdf", 84, 153),
"username": _lll1Il1,
"pass": "",
"hwid": _l1IlIl1,
"sessionid": _lIIlIl1.sessionid,
"name": _lI1lIl1.name,
"ownerid": _lI1lIl1.ownerid
}
_lI11Il1 = KA_HttpPost(_ll11Il1)
if _lI11Il1.success = true then
_llIlIl1 = ""
_l1I1Il1 = _l1d_a500bd("797b817d94909b", 65, 84)
if _lI11Il1.info <> invalid and _lI11Il1.info.subscriptions <> invalid and _lI11Il1.info.subscriptions.Count() > 0 then
_llI1Il1 = KA_CheckSubscriptions(_lI11Il1.info.subscriptions)
if _llI1Il1.isExpired then
KA_ClearLicense()
return {
success: false,
message: _l1d_a500bd("e2dbd4d627e6e4f1f6f4eaff3ffa04f94b11f9040e0c2024616639283231263b7b3044424a3f8d3750494b9c505567596c6068646b717a7ec1", 121, 194)
}
end if
_llIlIl1 = _llI1Il1.expiry
_l1I1Il1 = _llI1Il1.subName
end if
U_PrefSet(_l1d_a500bd("f6ffe8f8000d0a06261300171c2b", 12, 143), _lll1Il1)
U_PrefSet(_l1d_a500bd("2c35264f504557464a4954", 201, 138), _lll1Il1)
U_PrefSet(_l1d_a500bd("a1aa9ba9c9aebe", 137, 191), _l1IlIl1)
U_PrefSet(_l1d_a500bd("33400d463d41481c4a404c62", 91, 3), _l1d_a500bd("0c120b0c162415", 7, 161))
U_PrefSet(_l1d_a500bd("d7e0f1ead0dbe7e3dd", 184, 4), _llIlIl1)
U_PrefSet(_l1d_a500bd("73706d848d7b", 131, 139), _l1I1Il1)
U_PrefSet(_l1d_a500bd("f70409fd0dfefe1802180c1a1e202729", 190, 34), CreateObject(_l1d_a500bd("a8ae9cc2b2c498c6c5d0", 159, 187)).AsSeconds().ToStr())
return {
success: true,
message: _l1d_a500bd("8b717e7b797784cc888d7cd88999939ba5a1a8acf3a7a4bdc0bdb6b9c9b9c5c8be19", 125, 90),
expiry: _llIlIl1,
subscription: _l1I1Il1,
authType: _l1d_a500bd("5959666b677f74", 40, 21)
}
end if
_lIl1Il1 = {
"type": _l1d_a500bd("c6c4d1d6d4eadf", 73, 161),
"key": _lll1Il1,
"hwid": _l1IlIl1,
"sessionid": _lIIlIl1.sessionid,
"name": _lI1lIl1.name,
"ownerid": _lI1lIl1.ownerid
}
_l111Il1 = KA_HttpPost(_lIl1Il1)
if _l111Il1.success = true then
_llIlIl1 = ""
_l1I1Il1 = _l1d_a500bd("eef2f2f40b0510", 2, 136)
if _l111Il1.info <> invalid and _l111Il1.info.subscriptions <> invalid and _l111Il1.info.subscriptions.Count() > 0 then
_llI1Il1 = KA_CheckSubscriptions(_l111Il1.info.subscriptions)
if _llI1Il1.isExpired then
KA_ClearLicense()
return {
success: false,
message: _l1d_a500bd("ad9a979bf0a7afb8b9b1b1c208c3cfc014d4c2cdd9d1e3e51e2f02e9f5fcedfe44f507ff0dfe56020f0c106517182c203325332d2c3c393b7e", 254, 6)
}
end if
_llIlIl1 = _llI1Il1.expiry
_l1I1Il1 = _llI1Il1.subName
end if
U_PrefSet(_l1d_a500bd("c2bfd4c8d0c9cad2c2d3ece3dcdb", 246, 37), _lll1Il1)
U_PrefSet(_l1d_a500bd("0d1a3f192d1e26", 175, 73), _l1IlIl1)
U_PrefSet(_l1d_a500bd("d3d0add6cdd1e8bcdae0dcf2", 19, 91), _l1d_a500bd("9ba19a9ba5b3a4", 135, 176))
U_PrefSet(_l1d_a500bd("f2ffec090f1a061e1c", 10, 145), _llIlIl1)
U_PrefSet(_l1d_a500bd("adaadfbebfb3", 38, 96), _l1I1Il1)
U_PrefSet(_l1d_a500bd("1d1aef25231416fe1a2e244036463d41", 151, 33), CreateObject(_l1d_a500bd("0218f61c0c1ef2302f2a", 23, 157)).AsSeconds().ToStr())
return {
success: true,
message: _l1d_a500bd("f2d2cfd4e0c8dd9be9e6dda7ebf0e4fcecfaf00406c5fb001114190a0d23152f3222ed", 48, 118),
expiry: _llIlIl1,
subscription: _l1I1Il1,
authType: _l1d_a500bd("42404d5250665b", 73, 29)
}
end if
_l1l1Il1 = _l1d_a500bd("6e908b9f979da5eca3a9b6b3b1afbc04c0c5b4", 221, 218)
if _l111Il1.message <> invalid and _l111Il1.message <> "" and _l111Il1.message <> _l1d_a500bd("806853616f6f6d2c7b7b787d89718644928f86", 48, 7) then
_l1l1Il1 = KA_CleanAuthMessage(_l111Il1.message)
else if _lI11Il1.message <> invalid and _lI11Il1.message <> "" and _lI11Il1.message <> _l1d_a500bd("efd5f0e0e0deeead0300f907f6fefd08", 43, 141) then
_l1l1Il1 = KA_CleanAuthMessage(_lI11Il1.message)
else if _lI11Il1.message <> invalid and _lI11Il1.message <> "" then
_l1l1Il1 = KA_CleanAuthMessage(_lI11Il1.message)
end if
KA_ClearLicense()
return { success: false, message: _l1l1Il1 }
end function
function KA_Login(_l1ll111 as String, _l1IIl11 = "" as String) as Object
if ((43440 - 8688 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _l1ll111 = invalid or _l1ll111 = "" then
return { success: false, message: _l1d_a500bd("dcc4bdbec6b6c70dd7d0cf19cadcd3d2f1d9ebed36", 246, 34) }
end if
_lI1Il11 = KA_Init()
if not _lI1Il11.success then return _lI1Il11
_ll1Il11 = KA_GetConfig()
_l11Il11 = KA_GetHwid()
_lIIIl11 = {
"type": _l1d_a500bd("7d7d888987", 15, 26),
"username": _l1ll111,
"pass": _l1IIl11,
"hwid": _l11Il11,
"sessionid": _lI1Il11.sessionid,
"name": _ll1Il11.name,
"ownerid": _ll1Il11.ownerid
}
_llll111 = KA_HttpPost(_lIIIl11)
if _llll111.success = true then
U_PrefSet(_l1d_a500bd("dae7b4eae8f1faf4ea03ccfb0cf3", 155, 234), _l1ll111)
U_PrefSet(_l1d_a500bd("1e1bf00d1223172e303732", 86, 225), _l1ll111)
U_PrefSet(_l1d_a500bd("524f845c626359", 102, 69), _l11Il11)
U_PrefSet(_l1d_a500bd("33304d362d31485c3a403c52", 243, 155), _l1d_a500bd("3e3e4b504c6459", 104, 58))
return { success: true, message: _l1d_a500bd("6383909591899edca0a599a1a1afa5b9bbfab0b5c6c9cebfc2d8cad4d7c722", 88, 79) }
else
KA_ClearLicense()
_llIIl11 = _l1d_a500bd("9e7c858e889e9757999ab49ab8a8c0a6abaf78bdbdb8c0cace", 171, 183)
if _llll111.message <> invalid then _llIIl11 = KA_CleanAuthMessage(_llll111.message)
return { success: false, message: _llIIl11 }
end if
end function
function KA_IsActivated() as Boolean
if ((21150 - 3525 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lIl1I11 = U_PrefDefault(_l1d_a500bd("d7d009dbe1dedbe9f7e421f8ed0c", 229, 73), "")
if _lIl1I11 = "" or Len(_lIl1I11) < 2 then return false
_l1l1I11 = U_PrefDefault(_l1d_a500bd("525f8c696f7a667e7c", 106, 81), "")
if KA_IsExpired(_l1l1I11) then return false
return true
end function
function KA_GetSavedLicense() as String
return U_PrefDefault(_l1d_a500bd("d9d2ebdbe3e0dde9d9e603faefee", 180, 250), "")
end function
function KA_GetSavedExpiry() as String
return U_PrefDefault(_l1d_a500bd("4744194646415b4551", 151, 75), "")
end function
function KA_IsExpired(_l11l1lI as String) as Boolean
if _l11l1lI = invalid or _l11l1lI = "" or _l11l1lI = _l1d_a500bd("26", 71, 175) or _l11l1lI = _l1d_a500bd("9b75897b8b", 224, 237) or _l11l1lI = _l1d_a500bd("3e261e203232312c", 36, 214) then
return false
end if
_lI1l1lI = _l11l1lI.ToInt()
if _lI1l1lI <= 0 then return false
_llIl1lI = CreateObject(_l1d_a500bd("5f452f5565574b595863", 205, 160)).AsSeconds()
return (_lI1l1lI <= _llIl1lI)
end function
function KA_FormatExpiry(_ll1IIlI as String) as String
if _ll1IIlI = invalid or _ll1IIlI = "" or _ll1IIlI = _l1d_a500bd("af", 26, 133) or _ll1IIlI = _l1d_a500bd("614f5f5569", 46, 1) or _ll1IIlI = _l1d_a500bd("7c625c5c706e6d68", 165, 147) then
return _l1d_a500bd("6a8a969c8e969da8", 90, 84)
end if
_l11IIlI = _ll1IIlI.ToInt()
if _l11IIlI <= 0 then return _ll1IIlI
_lIlIIlI = CreateObject(_l1d_a500bd("c0d8b4dccadeb0f0efea", 214, 28))
_lIlIIlI.FromSeconds(_l11IIlI)
_llIIIlI = _lIlIIlI.ToISOString()
_lI1IIlI = _llIIIlI
if Len(_llIIIlI) >= 16 then
_lI1IIlI = Mid(_llIIIlI, 1, 10) + _l1d_a500bd("c9", 92, 77) + Mid(_llIIIlI, 12, 5) + _l1d_a500bd("1424263c", 30, 214)
end if
if KA_IsExpired(_ll1IIlI) then
return _lI1IIlI + _l1d_a500bd("a5b0d0e6e1dde5dfe1c9", 130, 3)
end if
return _lI1IIlI
end function
function KA_CheckSubscriptions(_lII111I as Object) as Object
if _lII111I = invalid or _lII111I.Count() = 0 then
return { isExpired: false, expiry: "", subName: _l1d_a500bd("6569696b627c67", 18, 239) }
end if
_l11111I = CreateObject(_l1d_a500bd("9989b191a79bcd959ca7", 40, 63)).AsSeconds()
_ll1111I = false
_lll111I = 0
_l1l111I = _l1d_a500bd("e3e7ebe900ea05", 104, 215)
for each _llI111I in _lII111I
_lI1111I = ""
if _llI111I.expiry <> invalid then _lI1111I = _llI111I.expiry.ToStr()
_l1I111I = _l1d_a500bd("474b4b55645e69", 166, 133)
if _llI111I.subscription <> invalid then _l1I111I = _llI111I.subscription
if _lI1111I = "" or _lI1111I = _l1d_a500bd("6e", 29, 65) or _lI1111I = _l1d_a500bd("d8c0d6c6d8", 105, 177) or _lI1111I = _l1d_a500bd("ff272b314333323d", 78, 253) then
_ll1111I = true
_l1l111I = _l1I111I
_lll111I = 0
exit for
else
_lIl111I = _lI1111I.ToInt()
if _lIl111I > _lll111I then
_lll111I = _lIl111I
_l1l111I = _l1I111I
end if
end if
end for
if _ll1111I then
return { isExpired: false, expiry: _l1d_a500bd("0f", 167, 120), subName: _l1l111I }
end if
if _lll111I > 0 then
if _lll111I <= _l11111I then
return { isExpired: true, expiry: _lll111I.ToStr(), subName: _l1l111I }
else
return { isExpired: false, expiry: _lll111I.ToStr(), subName: _l1l111I }
end if
end if
return { isExpired: false, expiry: "", subName: _l1l111I }
end function
function KA_ClearLicense()
U_PrefSet(_l1d_a500bd("797673878780899199928b9a9bb2", 130, 144), "")
U_PrefSet(_l1d_a500bd("acb9e6d3d0c9d7c6cecdd8", 235, 44), "")
U_PrefSet(_l1d_a500bd("d0ddaae7cdd8e4dcda", 90, 159), "")
U_PrefSet(_l1d_a500bd("c4bdb6d5d2ca", 4, 85), "")
U_PrefSet(_l1d_a500bd("65727f786f71788e7a727c94", 122, 84), "")
end function
function KA_VerifySavedLicense() as Object
if ((21519 - 7173 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1I11II = KA_GetSavedLicense()
if _l1I11II = "" then return { success: false, message: _l1d_a500bd("08ea3cf3f90203fdfb0c540c150460102513272b", 127, 215) }
_lI111II = KA_GetSavedExpiry()
if KA_IsExpired(_lI111II) then
KA_ClearLicense()
return { success: false, message: _l1d_a500bd("a3d0bdc116dde5dedfe7d7e82ef9f5e63afaf8f30ff7090b5455e81f1b2213246a1b2d3533247c384532368b3d3e5246594b695352726f71b4", 214, 20) }
end if
_l1lI1II = KA_License(_l1I11II)
if _l1lI1II = invalid or _l1lI1II.success <> true then
_lllI1II = ""
if _l1lI1II <> invalid and _l1lI1II.message <> invalid then _lllI1II = _l1lI1II.message
_lII11II = LCase(_lllI1II)
_llI11II = (InStr(1, _lII11II, _l1d_a500bd("10f8ff0a0ccb092628", 170, 50)) > 0 or InStr(1, _lII11II, _l1d_a500bd("959f9197a2a0ac", 156, 163)) > 0 or InStr(1, _lII11II, _l1d_a500bd("e6edeff2ecf501010204", 228, 95)) > 0 or InStr(1, _lII11II, _l1d_a500bd("6867696c76778b3a917f", 8, 253)) > 0)
if not _llI11II then
KA_ClearLicense()
end if
end if
return _l1lI1II
end function
function _l1d_a500bd(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function