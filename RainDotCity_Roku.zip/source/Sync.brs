function S_SyncSections() as Object
return [ _l1d_d37629("05f7020a2311f92b14020a33270c2c27152b1c1f", 48, 163), _l1d_d37629("aa7e898fac94a2ae9babb1d6c2a2b8b2bab6c6b8c5", 99, 121), _l1d_d37629("6236312f5c345266435b59766b526c6f557597796f7f83", 47, 229) ]
end function
function S_HydraSyncKeys() as Object
return [ _l1d_d37629("6e5b62766a6245698682708e88", 204, 175) ]
end function
function S_BuildSnapshot() as Object
_llllI1l = {}
for each _lIllI1l in S_SyncSections()
_l1llI1l = CreateObject(_l1d_d37629("cae2f0e2e3f4dddde2f009faffef0f0c0e", 246, 70), _lIllI1l)
_lIII11l = _l1llI1l.GetKeyList()
if _lIII11l <> invalid then
_l11I11l = {}
for each _l1II11l in _lIII11l
_l11I11l[_l1II11l] = _l1llI1l.Read(_l1II11l)
end for
_llllI1l[_lIllI1l] = _l11I11l
end if
end for
_lI1I11l = CreateObject(_l1d_d37629("18263e32372c292f3028554a4b41475054", 121, 13), _l1d_d37629("d8cad5d5eedcc4fee7cddd", 180, 242))
_llII11l = {}
for each _l1II11l in S_HydraSyncKeys()
if _lI1I11l.Exists(_l1II11l) then _llII11l[_l1II11l] = _lI1I11l.Read(_l1II11l)
end for
if _llII11l.Count() > 0 then _llllI1l[_l1d_d37629("08f803051e0af42c15fd0b", 53, 161)] = _llII11l
return _llllI1l
end function
sub S_ApplySnapshot(_llI1lIl as Object)
if _llI1lIl = invalid then return
for each _lI11lIl in _llI1lIl
_lIl1lIl = _llI1lIl[_lI11lIl]
if _lIl1lIl <> invalid then
_l111lIl = CreateObject(_l1d_d37629("76645c74756e87918e8a738c89a3898e92", 203, 189), _lI11lIl)
for each _ll11lIl in _lIl1lIl
if not _l111lIl.Exists(_ll11lIl) then
_l1I1lIl = _lIl1lIl[_ll11lIl]
if _l1I1lIl <> invalid then _l111lIl.Write(_ll11lIl, _l1I1lIl.ToStr())
end if
end for
_l111lIl.Flush()
end if
end for
end sub
function S_ResolverUrl() as String
_llllIIl = U_DefaultResolverUrl()
if _llllIIl = "" then _llllIIl = U_PrefDefault(_l1d_d37629("54445950565f5369496f68", 71, 31), "")
return _llllIIl
end function
function S_PullOnBoot() as Boolean
if ((69853 - 9979 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1lIll1 = S_ResolverUrl()
if _l1lIll1 = "" then return false
_ll1Ill1 = CreateObject(_l1d_d37629("3018170600242c30", 12, 178), _l1d_d37629("1532404e20564752", 223, 137))
if _ll1Ill1 = invalid then return false
_ll1Ill1.mode = _l1d_d37629("3c3a4649", 31, 205)
_ll1Ill1.resolverUrl = _l1lIll1
_ll1Ill1.did = U_ClientId()
_lII1ll1 = CreateObject(_l1d_d37629("aba9cea9b6b9aeb3b8e8c4ccd5", 227, 26))
_ll1Ill1.observeField(_l1d_d37629("311f38351f3a", 76, 243), _lII1ll1)
_ll1Ill1.control = _l1d_d37629("101822", 155, 71)
_l1I1ll1 = wait(5000, _lII1ll1)
if _l1I1ll1 = invalid then
_ll1Ill1.control = _l1d_d37629("2f2f3939", 62, 194)
return false
end if
_lllIll1 = _ll1Ill1.result
if _lllIll1 = invalid or _lllIll1.ok <> true then return false
_lIlIll1 = _lllIll1.snapshot
if _lIlIll1 = invalid then return false
S_ApplySnapshot(_lIlIll1)
return true
end function
sub S_QueuePush()
if ((35259 - 5037 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.global = invalid then return
m.global.addField(_l1d_d37629("d8d5e1f1c9f9eaead1f1f602", 158, 235), _l1d_d37629("bcc2cf", 195, 18), false)
m.global.addField(_l1d_d37629("dddaced6cedeefda", 138, 228), _l1d_d37629("888c9498", 72, 98), false)
_llIlIl1 = CreateObject(_l1d_d37629("dbd3afd7e5d9cbebeae5", 134, 231)).AsSeconds()
_lI1lIl1 = m.global.syncLastPush
if _lI1lIl1 > 0 and (_llIlIl1 - _lI1lIl1) < 5 then return
S_FirePush(_llIlIl1)
end sub
sub S_QueuePushNow()
if ((27355 - 5471 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.global = invalid then return
m.global.addField(_l1d_d37629("6d7a86866e8e7f7f66868ba7", 22, 8), _l1d_d37629("fbf906", 167, 45), false)
m.global.addField(_l1d_d37629("b3bcacacd8b0c5c0", 228, 28), _l1d_d37629("32362e32", 132, 72), false)
S_FirePush(CreateObject(_l1d_d37629("667e9a82708496969590", 118, 98)).AsSeconds())
end sub
sub S_FirePush(_l1l1I11 as Integer)
_lIl1I11 = S_ResolverUrl()
if _lIl1I11 = "" then return
_ll11I11 = CreateObject(_l1d_d37629("1232f9101a3e3a3e", 18, 178), _l1d_d37629("b8e5d9d1c9d9eae5", 194, 39))
if _ll11I11 = invalid then return
_ll11I11.mode = _l1d_d37629("d0d6d7f1", 241, 79)
_ll11I11.resolverUrl = _lIl1I11
_ll11I11.did = U_ClientId()
_ll11I11.payload = FormatJson(S_BuildSnapshot())
m.global.syncTask = _ll11I11
m.global.syncLastPush = _l1l1I11
_ll11I11.control = _l1d_d37629("606862", 99, 47)
end sub
function _l1d_d37629(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function