function R_ResolveEmbed(_lII11ll as Object) as Object
if ((40810 - 5830 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lII11ll = invalid then return invalid
_lllI1ll = ""
if _lII11ll.embedUrl <> invalid then _lllI1ll = _lII11ll.embedUrl
if _lllI1ll = "" then return invalid
_lI1I1ll = ""
if _lII11ll.refer <> invalid then _lI1I1ll = _lII11ll.refer
if _lI1I1ll = "" then _lI1I1ll = HC_OriginOf(_lllI1ll)
if U_LooksHls(_lllI1ll) or U_LooksMp4(_lllI1ll) then
_lIlI1ll = 0
if U_LooksHls(_lllI1ll) then
_l11I1ll = HC_NewSession()
_lIlI1ll = RP_HlsLeadSkip(_l11I1ll, "", _lllI1ll, _lI1I1ll)
HC_Close(_l11I1ll)
end if
return {
url: _lllI1ll
streamFormat: U_StreamFormat(_lllI1ll)
qualities: []
subtitles: []
chapters: []
referer: _lI1I1ll
userAgent: ""
leadSkip: _lIlI1ll
}
end if
_llII1ll = HC_NewSession()
_ll1I1ll = invalid
_l1lI1ll = ""
_ll1I1ll = R_DispatchByHost(_lllI1ll, _lI1I1ll, _llII1ll)
if (_ll1I1ll = invalid or _ll1I1ll.url = "") and R_HasContentIds(_lII11ll) then
_ll1I1ll = R_FallbackByContentIds(_lII11ll, _llII1ll)
end if
if _ll1I1ll <> invalid and _ll1I1ll.url <> invalid and _ll1I1ll.url <> "" then
_ll1I1ll = R_EnrichResult(_ll1I1ll, _lII11ll, _lI1I1ll, _llII1ll)
end if
HC_Close(_llII1ll)
if _ll1I1ll = invalid then return invalid
if _ll1I1ll.url = invalid or _ll1I1ll.url = "" then return invalid
return R_NormalizeResult(_ll1I1ll, _lI1I1ll)
end function
function R_EnrichResult(_llI1l1l as Object, _llIll1l as Object, _l1I1l1l as String, _l1lIl1l as Object) as Object
if ((22020 - 3670 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _llI1l1l = invalid or _llI1l1l.url = invalid or _llI1l1l.url = "" then return _llI1l1l
_lIlIl1l = _llI1l1l.url
_l111l1l = U_LooksHls(_lIlIl1l)
_lII1l1l = ""
if _llI1l1l.referer <> invalid and _llI1l1l.referer <> "" then _lII1l1l = _llI1l1l.referer
if _lII1l1l = "" then _lII1l1l = _l1I1l1l
if _lII1l1l = "" then _lII1l1l = _lIlIl1l
_ll11l1l = ""
_ll1Il1l = ""
_lI11l1l = ""
_lllIl1l = 0
_l1Ill1l = 0
if _llIll1l <> invalid then
if _llIll1l.imdb <> invalid then _ll11l1l = _llIll1l.imdb
if _llIll1l.tmdb <> invalid then _ll1Il1l = _llIll1l.tmdb
if _llIll1l.kind <> invalid then _lI11l1l = _llIll1l.kind
if _llIll1l.season <> invalid then _lllIl1l = _llIll1l.season
if _llIll1l.episode <> invalid then _l1Ill1l = _llIll1l.episode
end if
if _l111l1l then
_lll1l1l = invalid
if _llI1l1l.qualities <> invalid and type(_llI1l1l.qualities) = _l1d_f60343("cee6c7d7daf0eb", 150, 234) then _lll1l1l = _llI1l1l.qualities
if _lll1l1l = invalid or _lll1l1l.Count() = 0 then
_llI1l1l.qualities = HM_FetchQualities(_lIlIl1l, _lII1l1l, _l1lIl1l)
end if
_lIIll1l = invalid
if _llI1l1l.chapters <> invalid and type(_llI1l1l.chapters) = _l1d_f60343("344a673d40504b", 181, 109) then _lIIll1l = _llI1l1l.chapters
if _lIIll1l = invalid or _lIIll1l.Count() = 0 then
_llI1l1l.chapters = HM_ExtractChaptersHls(_lIlIl1l, _lII1l1l, _l1lIl1l)
end if
if _llI1l1l.leadSkip = invalid then
_llI1l1l.leadSkip = RP_HlsLeadSkip(_l1lIl1l, "", _lIlIl1l, _lII1l1l)
end if
end if
if _llI1l1l.chapters = invalid or type(_llI1l1l.chapters) <> _l1d_f60343("b9d7ecc2c5d5d0", 49, 118) or _llI1l1l.chapters.Count() = 0 then
_llI1l1l.chapters = HM_FetchSkipTimes(_ll11l1l, _ll1Il1l, _lI11l1l, _lllIl1l, _l1Ill1l, _l1lIl1l)
end if
if _llI1l1l.subtitles = invalid or type(_llI1l1l.subtitles) <> _l1d_f60343("1b391224273b36", 83, 250) then _llI1l1l.subtitles = []
if _l111l1l then
_lIl1l1l = HM_ExtractSubsHls(_lIlIl1l, _lII1l1l, _l1lIl1l)
_llI1l1l.subtitles = HM_MergeSubtitles(_llI1l1l.subtitles, _lIl1l1l)
end if
_l1l1l1l = HM_FetchFreeSubs(_ll11l1l, _ll1Il1l, _lI11l1l, _lllIl1l, _l1Ill1l, _l1lIl1l)
_llI1l1l.subtitles = HM_MergeSubtitles(_llI1l1l.subtitles, _l1l1l1l)
return _llI1l1l
end function
function R_DispatchByHost(_l11I11l as String, _llII11l as String, _l1II11l as Object) as Object
if ((14660 - 2932 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lI1I11l = HC_HostOf(_l11I11l)
print _l1d_f60343("44404e5c422b31433b47556b935e6249539d", 243, 156); _lI1I11l; _l1d_f60343("c800fc1dd1", 178, 54); _l11I11l
if _lI1I11l = "" then return invalid
if Instr(1, _lI1I11l, _l1d_f60343("4b4d4d4a5e5763505a576ba96f6e73", 251, 179)) > 0 then return RP_ResolveCloudnestra(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("5c6674626478b6676b6b", 218, 176)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("d2bacad6dacc8cccd2", 171, 245)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("dde9f1e9edffb7f4fa", 189, 18)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("705e647e8074aa7071", 76, 54)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("545a685a5c70ae717b6d", 88, 38)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("4e4e433e464c4e8b6268", 200, 144)) > 0 then return RP_ResolveVidsrcXyz(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("ded0d6eceee298e8eb", 46, 134)) > 0 then return RP_ResolveVidsrcCc(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("7c9890899f9ea969aca498", 149, 153)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("9abcb2a8aabe04afd1bb", 246, 26)) > 0 then return RP_ResolveVidrock(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("1ff500f8fe004d0508", 112, 221)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("58303b31393d86483046", 115, 23)) > 0 then return RP_Resolve2embed(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("edf3f6fdfaff0907fe564d1d181919", 68, 197)) > 0 then return RP_ResolveLookmovie(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("757a647a796a7b6d89d189958191", 208, 184)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("232822283728392b377f3846", 248, 142)) > 0 then return RP_ResolveMoviesapi(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("2c36443e344a063e46435d5c5b", 154, 64)) > 0 then return RP_ResolveVidora(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("4d5c605c5560625e62", 197, 169)) > 0 then return RP_ResolveAutoembed(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("848fa19699619aa6a4", 157, 159)) > 0 then return RP_ResolveXpass(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("2d38463d46445892944a595a", 65, 13)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("081b050e0a21281c2a1937202923312749ef3f3637", 12, 154)) > 0 then return RP_ResolveAirflix(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("303c44464d423b8d50584c", 93, 5)) > 0 then return RP_ResolveVideasy(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("4a665e6e6f716bb77a7266", 245, 199)) > 0 then return RP_ResolveVidking(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("393f4e550e525060", 190, 114)) > 0 then return RP_ResolveYthd(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("83737a7f878b83a1519a98a4", 164, 175)) > 0 then return RP_ResolvePeachify(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("a1a6b0afbab3b5c9ffc1cc", 92, 117)) > 0 then return RP_ResolvePrimesrc(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("918d96a4aba29cb4a6b6", 156, 162)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("1313180a1108221ace2f1f", 14, 150)) > 0 then return RP_ResolveStreamtape(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("dfdefefef7ff", 51, 153)) > 0 then return RP_ResolveUqload(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("dce4e7e5", 71, 185)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("2980838635", 239, 158)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("a1787b7e81b0", 45, 88)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("80723475848c77", 56, 36)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("1624e62d17252922", 10, 168)) > 0 then return RP_ResolveDoodstream(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("1c28356d2d29", 126, 20)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("132d2a742a393e", 211, 110)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("c9c5bed1cdccd1", 36, 119)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("4b55621d5862716a6a7974", 63, 2)) > 0 then return RP_ResolveVoe(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("cfc4d4ccd6e2d6", 69, 157)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("cad0d1c5c4d3dcd0", 225, 56)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("cfe1dfeaeae8ea", 84, 168)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("334738574d48", 49, 241)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("c9dbd2e0d2", 158, 220)) > 0 then return RP_ResolveStreamsb(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("818072917e8e86", 90, 74)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("2b433a4f3557", 207, 137)) > 0 then return RP_ResolveMixdrop(_l11I11l, _llII11l, _l1II11l)
if Instr(1, _lI1I11l, _l1d_f60343("1432282d332824012e334b", 148, 50)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("d6d4cadee41de6e4", 100, 196)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("1a1525232521304541354df4353d3d45", 140, 49)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("747e8177868c85ce90988e", 227, 236)) > 0 or Instr(1, _lI1I11l, _l1d_f60343("24332d282c3638f138383a47", 10, 184)) > 0 then return invalid
return RP_ResolveGeneric(_l11I11l, _llII11l, _l1II11l)
end function
function R_FollowKnownIframes(_lI11lIl as String, _l1lIlIl as String, _ll1IlIl as String, _ll11lIl as Integer, _l11IlIl as Object) as Object
if _lI11lIl = invalid or _lI11lIl = "" then return invalid
if _ll11lIl >= 3 then return invalid
_lIlIlIl = CreateObject(_l1d_f60343("2d4d134d4e5349", 210, 141), _l1d_f60343("53a1b3a2b2b1bc858d709081bcc0d27f", 153, 174) + chr(34) + _l1d_f60343("80565c", 248, 176) + chr(34) + _l1d_f60343("550207", 178, 102) + chr(34), _l1d_f60343("0112", 136, 32))
_l1I1lIl = _lIlIlIl.matchAll(_lI11lIl)
if _l1I1lIl = invalid then return invalid
for each _lII1lIl in _l1I1lIl
if _lII1lIl.Count() < 2 then continue for
_lIl1lIl = U_AbsUrl(_lII1lIl[1], HC_OriginOf(_l1lIlIl))
if _lIl1lIl = "" then continue for
_l111lIl = R_DispatchByHost(_lIl1lIl, _l1lIlIl, _l11IlIl)
if _l111lIl <> invalid and _l111lIl.url <> invalid and _l111lIl.url <> "" then return _l111lIl
_lllIlIl = HC_Get(_l11IlIl, _lIl1lIl, { "Referer": _l1lIlIl }, 6000)
if _lllIlIl <> invalid and _lllIlIl.body <> "" then
_llI1lIl = R_FollowKnownIframes(_lllIlIl.body, _lIl1lIl, _l1lIlIl, _ll11lIl + 1, _l11IlIl)
if _llI1lIl <> invalid and _llI1lIl.url <> "" then return _llI1lIl
end if
end for
return invalid
end function
function R_FallbackByContentIds(_llllIIl as Object, _lIIlIIl as Object) as Object
if not R_HasContentIds(_llllIIl) then return invalid
_l11lIIl = ""
if _llllIIl.kind <> invalid then _l11lIIl = _llllIIl.kind
_lll1IIl = ""
if _llllIIl.tmdb <> invalid then _lll1IIl = _llllIIl.tmdb
_ll1lIIl = ""
if _llllIIl.imdb <> invalid then _ll1lIIl = _llllIIl.imdb
_l1IlIIl = 1
if _llllIIl.season <> invalid then _l1IlIIl = _llllIIl.season
_lIllIIl = 1
if _llllIIl.episode <> invalid then _lIllIIl = _llllIIl.episode
_llIlIIl = ""
if _llllIIl.refer <> invalid then _llIlIIl = _llllIIl.refer
_l1llIIl = R_BuildFallbackCandidates(_l11lIIl, _lll1IIl, _ll1lIIl, _l1IlIIl, _lIllIIl)
for each _l1l1IIl in _l1llIIl
if _l1l1IIl <> "" then
_lI1lIIl = R_DispatchByHost(_l1l1IIl, _llIlIIl, _lIIlIIl)
if _lI1lIIl <> invalid and _lI1lIIl.url <> invalid and _lI1lIIl.url <> "" then return _lI1lIIl
end if
end for
return invalid
end function
function R_BuildFallbackCandidates(_lIlIll1 as String, _llIIll1 as String, _lllIll1 as String, _l11Ill1 as Integer, _l1I1ll1 as Integer) as Object
_ll1Ill1 = []
_l1lIll1 = (_lIlIll1 <> _l1d_f60343("5358", 168, 119))
if _l1lIll1 then
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("8d84878e8ecad8db9da4b29db4aaf1c1b0b4bcc9c4d2d2d60fddd417e4dfededf129eeefebfb023b", 127, 118) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("604f525155a1b7ba607f75707f71d0847b7f9b949f999da1eea4b3f6afbab4b8bc08c9cebacecd1a", 241, 199) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("5970737a7cb6a6a97a758d7c798193dfc3938a8fd09d98a4a6a8e2a7a8c2b4bbf4", 238, 211) + _llIIll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("c1c8cbd2d6a29093d0dbe9d8e1e7fbb5afedf4f5baf3fe00fc00cc0d121e1a11de", 133, 212) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("6d54575e622e3c3f6d84827d847e55809c94969d929b6db0a89c78b9beaac6bd8a", 53, 16) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("6d64676e742e3e417d84947f4f848fa3989b619aa8a46eb774b5bab4c2c986", 188, 153) + _llIIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("dbdadddce01c3235f1f505f5f90b4b1114530f4e5c25202a2e326e2f3430344380", 89, 170) + _llIIll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("eb02050c0c48363915050d2125174f282a2c5a27223030346c31324e3e458e474652579f", 79, 196) + _lllIll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("b4abaeb5b7f10104bed0d6cccee218e2de22efeaf6f8fa34f9faf4060d46", 94, 126) + _llIIll1)
else
_lI1Ill1 = _l11Ill1.ToStr()
_lII1ll1 = _l1I1ll1.ToStr()
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("745b5e6567314144748b8b868d81589a898ba5a2ada9abad76b6bd80bdc8c4c6c892bebf9b", 182, 150) + _lllIll1 + _l1d_f60343("ef", 227, 35) + _lI1Ill1 + _l1d_f60343("74", 253, 162) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("8b8a8d8c92cce4e79baab29dbcacfbc1b8bac8d1ccd4dadc19e1e023ece7eff5f735edf23e", 216, 219) + _llIIll1 + _l1d_f60343("9d", 31, 109) + _lI1Ill1 + _l1d_f60343("05", 229, 59) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("a5bcbfc6cc867679c6c1ddccc5cddfab93e3dadba0e9e4f4f2f4b20a0fbb", 12, 65) + _llIIll1 + _l1d_f60343("e6", 89, 112) + _lI1Ill1 + _l1d_f60343("8f", 20, 84) + _lII1ll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("fdf4f7fe043e4e511e1915241d2517636b3b323378413c4c4a4c8a424793", 220, 73) + _lllIll1 + _l1d_f60343("72", 13, 80) + _lI1Ill1 + _l1d_f60343("e7", 59, 211) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("2211141319e3fbfe224139344333123d5351555449522a6d6759375f6440", 176, 74) + _llIIll1 + _l1d_f60343("aa", 201, 196) + _lI1Ill1 + _l1d_f60343("ff", 17, 193) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("e8cfd2d9db253538e8fffffa46fffa0eff0258051f0f65226b171874", 214, 42) + _llIIll1 + _l1d_f60343("a6", 132, 251) + _lI1Ill1 + _l1d_f60343("11", 127, 193) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("1e1d201f235f7578343848383c4e8e54579652919f68636d7175b16b70ba", 249, 141) + _llIIll1 + _l1d_f60343("86", 211, 138) + _lI1Ill1 + _l1d_f60343("b6", 104, 111) + _lII1ll1)
if _lllIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("0ef5f8ffffcbd9dc08282014182af22b2d2ffd3a454343470f3d3e0861605c6119", 183, 47) + _lllIll1 + _l1d_f60343("43738c8b7c8b8d43", 26, 7) + _lI1Ill1 + _l1d_f60343("a1677d6982697579c4", 206, 185) + _lII1ll1)
if _llIIll1 <> "" then _ll1Ill1.Push(_l1d_f60343("5241444349132b2e586e6c5e60744280884c8590888e905e868b67", 16, 218) + _llIIll1 + _l1d_f60343("5e", 23, 38) + _lI1Ill1 + _l1d_f60343("93", 183, 251) + _lII1ll1)
end if
return _ll1Ill1
end function
function R_HasContentIds(_lI1lIl1 as Object) as Boolean
if ((46395 - 9279 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lI1lIl1 = invalid then return false
if _lI1lIl1.tmdb <> invalid and _lI1lIl1.tmdb <> "" then return true
if _lI1lIl1.imdb <> invalid and _lI1lIl1.imdb <> "" then return true
return false
end function
function R_NormalizeResult(_lI1Il11 as Object, _ll1Il11 as String) as Object
if ((18999 - 6333 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l11Il11 = {
url: ""
streamFormat: _l1d_f60343("272646", 45, 226)
qualities: []
subtitles: []
chapters: []
referer: ""
userAgent: ""
leadSkip: 0
}
if _lI1Il11 = invalid then return _l11Il11
if _lI1Il11.url <> invalid then _l11Il11.url = _lI1Il11.url
if _lI1Il11.leadSkip <> invalid then _l11Il11.leadSkip = _lI1Il11.leadSkip
if _lI1Il11.streamFormat <> invalid and _lI1Il11.streamFormat <> "" then
_l11Il11.streamFormat = _lI1Il11.streamFormat
else if _l11Il11.url <> "" then
_l11Il11.streamFormat = U_StreamFormat(_l11Il11.url)
end if
if _lI1Il11.qualities <> invalid then _l11Il11.qualities = _lI1Il11.qualities
if _lI1Il11.subtitles <> invalid then _l11Il11.subtitles = _lI1Il11.subtitles
if _lI1Il11.chapters <> invalid then _l11Il11.chapters = _lI1Il11.chapters
if _lI1Il11.referer <> invalid and _lI1Il11.referer <> "" then
_l11Il11.referer = _lI1Il11.referer
else
_l11Il11.referer = _ll1Il11
end if
if _lI1Il11.userAgent <> invalid then _l11Il11.userAgent = _lI1Il11.userAgent
return _l11Il11
end function
function _l1d_f60343(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function