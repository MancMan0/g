function AGD_Decrypt(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI as String, _ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I as Object, _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll as Object, _llI1lllIl111I1IlIII1111lIlII1llllll11II as Object) as Object
if _ll111lllI111Il1l1lII1IlI1lI1II1I1lI = invalid or Len(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI) <> 64 then return invalid
if _ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I = invalid or _ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I.Count() <> ((((((17 * 11) + 12) + 42) - ((17 * 11) + 42)))) then return invalid
if _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = invalid then return invalid
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll = CreateObject(_ll11Ill1l1111II11l1111llIIlllll(_ll1IllIlll1I1ll1lII111Il11IlI1111llIIIlll1I("54df6b4ab383d46ddc7ff18010794e1dd6f539f069c99ef7ac")))
for _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = 0 to 11
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll.Push(_ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I[_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l])
end for
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll.Push(((((((17 * 11) + 0) + 42) - ((17 * 11) + 42)))))
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll.Push(((((((44 * 64) + 0) mod 64) + ((255 and 255) - 255)))))
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll.Push(((((((27 * 64) + 0) mod 64) + ((255 and 255) - 255)))))
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll.Push(((((((43 * 11) + 1) + 42) - ((43 * 11) + 42)))))
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = CreateObject(_lllI1lII1llI11llIII11IllIllIIll(_llIl11IlI111Il11IIl1lII1l11IIIllIlllI1I("4b4131d6bf927bdb2097dc3f445bbbc01f5cc55542c96ed63c")))
for _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = 0 to 15
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll.Push(_llI1Il1l1IIlIl111IllII1lI11l1III11llIll[_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l])
end for
AGD_IncrCounter(_llIIl111Illll1111ll111lllI11Il1l11ll11111ll)
return AGD_AesCtrCrypt(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI, _llIIl111Illll1111ll111lllI11Il1l11ll11111ll, _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll)
end function
function AGD_AesCtrCrypt(_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I as String, _llll1I11llIlll11lII11l11111IIIl as Object, _llI111lI11I1l11lI11l1lIlll11111lIIlI1II as Object) as Object
_llI11Il1II1I1lI1II11I1111II1lIl = CreateObject(_llIl11IlI111Il11IIl1lII1l11IIIllIlllI1I("64e0d7beda2a54c9f7ae48ba"))
_llI1111ll111IlllIlI111lII1IIlIl = _llI111lI11I1l11lI11l1lIlll11111lIIlI1II.Count()
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l = ((((((12 * 5) + (0 * 3)) - (12 * 5)) \ 3)))
while _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l < _llI1111ll111IlllIlI111lII1IIlIl
_llI1lIlIIIlllI1I11Il1I11IlI11Il = AGD_AesEcbBlock(_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I, _llll1I11llIlll11lII11l11111IIIl)
if _llI1lIlIIIlllI1I11Il1I11IlI11Il = invalid or _llI1lIlIIIlllI1I11Il1I11IlI11Il.Count() < ((((((31 * 7) + ((21 * 13) - (21 * 13))) + 16) - (31 * 4)) - (31 * 3))) then return invalid
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = ((((((21 * 5) + (16 * 3)) - (21 * 5)) \ 3)))
if _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l + _lllIIlIlII1ll111l1Il11Illlll11l11I1 > _llI1111ll111IlllIlI111lII1IIlIl then _lllIIlIlII1ll111l1Il11Illlll11l11I1 = _llI1111ll111IlllIlI111lII1IIlIl - _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l
for _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = 0 to _lllIIlIlII1ll111l1Il11Illlll11l11I1 - 1
_llI11Il1II1I1lI1II11I1111II1lIl.Push(B_Xor(_llI111lI11I1l11lI11l1lIlll11111lIIlI1II[_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l + _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII], _llI1lIlIIIlllI1I11Il1I11IlI11Il[_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII]))
end for
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l = _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l + ((((((24 * 64) + 16) mod 64) + ((255 and 255) - 255))))
AGD_IncrCounter(_llll1I11llIlll11lII11l11111IIIl)
end while
return _llI11Il1II1I1lI1II11I1111II1lIl
end function
sub AGD_IncrCounter(_lllIIllll1llIIlllIllI11lll1ll1lIl11 as Object)
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = invalid or _lllIIllll1llIIlllIllI11lll1ll1lIl11.Count() < ((((((17 * 64) + 16) mod 64) + ((255 and 255) - 255)))) then return
for _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = 15 to 12 step -1
_lllIIllll1llIIlllIllI11lll1ll1lIl11[_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1] = (_lllIIllll1llIIlllIllI11lll1ll1lIl11[_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1] + ((((((17 * 64) + 1) mod 64) + ((255 and 255) - 255))))) AND 255
if _lllIIllll1llIIlllIllI11lll1ll1lIl11[_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1] <> ((((((37 * 5) + (0 * 3)) - (37 * 5)) \ 3))) then return
end for
end sub
function AGD_AesEcbBlock(_llllIlll1lIlIII1II1I11lllIl1Il1 as String, _llllI1lI1ll11l1lI1IlIll1II1lI11 as Object) as Object
_lll1I11l1Il1llllI11llI111lIlI1l = CreateObject(_llIl11IlI111Il11IIl1lII1l11IIIllIlllI1I(_ll11Ill1l1111II11l1111llIIlllll("713457824d50737e99ac39c2d5f0b360e9fce7949f489dc8c3")))
_ll111IlIl1I1I1lIIII1l1Il1ll1l1I1II1IIl1 = _lll1I11l1Il1llllI11llI111lIlI1l.Setup(((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2)))), _lllIll1lII11IIlII11l1lll111I11IIl11I11lIlIl(_ll1l11IIllIIl1I1I11l1I1I1IIIl1II1lI111IIIll("77e94de9ae8b61c871dec32a3109ecfdf1dc03ab730b2c080c")), _llllIlll1lIlIII1II1I11lllIl1Il1, "", ((((((18 * 5) + (0 * 3)) - (18 * 5)) \ 3))))
if _ll111IlIl1I1I1lIIII1l1Il1ll1l1I1II1IIl1 <> ((((((23 * 11) + 0) + 42) - ((23 * 11) + 42)))) then return invalid
_ll1IlIll1ll1IIIIIll11I111IIlIl11111I111IlIl = CreateObject(_llIl11IlI111Il11IIl1lII1l11IIIllIlllI1I(_lllI1lII1llI11llIII11IllIllIIll(_ll1l11IIllIIl1I1I11l1I1I1IIIl1II1lI111IIIll("3db776e7db7676c566b5f965c734370725b7b5a5c4f63405d8b5bbe786b43685e6f53626daf576c6e7433565dae23a059a41b6"))))
_llI1l1IIIl1lIl1IIIlIII1llIl1III = _lll1I11l1Il1llllI11llI111lIlI1l.Process(_llllI1lI1ll11l1lI1IlIll1II1lI11)
if _llI1l1IIIl1lIl1IIIlIII1llIl1III <> invalid then
for _ll1l1I1II1lll1l11lIIll1IIIII11l = 0 to _llI1l1IIIl1lIl1IIIlIII1llIl1III.Count() - 1
_ll1IlIll1ll1IIIIIll11I111IIlIl11111I111IlIl.Push(_llI1l1IIIl1lIl1IIIlIII1llIl1III[_ll1l1I1II1lll1l11lIIll1IIIII11l])
end for
end if
_lll1III11lIlIIIl1I1111l11l1I11lIlllllIl1lIl = _lll1I11l1Il1llllI11llI111lIlI1l.Final()
if _lll1III11lIlIIIl1I1111l11l1I11lIlllllIl1lIl <> invalid then
for _ll1l1I1II1lll1l11lIIll1IIIII11l = 0 to _lll1III11lIlIIIl1I1111l11l1I11lIlllllIl1lIl.Count() - 1
_ll1IlIll1ll1IIIIIll11I111IIlIl11111I111IlIl.Push(_lll1III11lIlIIIl1I1111l11l1I11lIlllllIl1lIl[_ll1l1I1II1lll1l11lIIll1IIIII11l])
end for
end if
return _ll1IlIll1ll1IIIIIll11I111IIlIl11111I111IlIl
end function
function _lllI1lII1llI11llIII11IllIllIIll(_llllIIl111IlIl1III1l1Il1llIl11III1l as String) as String
if _llllIIl111IlIl1III1l1Il1llIl11III1l = "" then return ""
_lllI1111111lIll11I1l1lII1lIII1ll1IIlllI = CreateObject("roByteArray")
_lllI1111111lIll11I1l1lII1lIII1ll1IIlllI.FromHexString(_llllIIl111IlIl1III1l1Il1llIl11III1l)
_llIIII1l1111llI1lI111l1II1IllII = _lllI1111111lIll11I1l1lII1lIII1ll1IIlllI.Count()
if _llIIII1l1111llI1lI111l1II1IllII < 2 then return ""
_llIl1ll11lIlllIlIlIlIII11IlIl111II11IlI = _lllI1111111lIll11I1l1lII1lIII1ll1IIlllI[0]
_ll11l1I111I1II11II1Il11ll11ll1l = (_llIl1ll11lIlllIlIlIlIII11IlIl111II11IlI * 41 + 19) and 255
_llI1lI11lIIllIIII1I1lIl1l1IIl111ll1 = _llIl1ll11lIlllIlIlIlIII11IlIl111II11IlI
for _lllI1IIlllIIlIIlI11Ill1III1I1III11l = 1 to _llIIII1l1111llI1lI111l1II1IllII - 1
_llllllIl11Il11IlllII11l1lII11lI = _lllI1111111lIll11I1l1lII1lIII1ll1IIlllI[_lllI1IIlllIIlIIlI11Ill1III1I1III11l]
_ll1lll1l1Ill1IIll1IllI11IIllllI = ((_lllI1IIlllIIlIIlI11Ill1III1I1III11l - 1) * 7) and 255
_llIlII111IIIl1l11l1Il1lIlIlIl11 = (_llllllIl11Il11IlllII11l1lII11lI + _llI1lI11lIIllIIII1I1lIl1l1IIl111ll1) - 2 * (_llllllIl11Il11IlllII11l1lII11lI and _llI1lI11lIIllIIII1I1lIl1l1IIl111ll1)
_llIlII111IIIl1l11l1Il1lIlIlIl11 = (_llIlII111IIIl1l11l1Il1lIlIlIl11 + _ll11l1I111I1II11II1Il11ll11ll1l) - 2 * (_llIlII111IIIl1l11l1Il1lIlIlIl11 and _ll11l1I111I1II11II1Il11ll11ll1l)
_llIlII111IIIl1l11l1Il1lIlIlIl11 = (_llIlII111IIIl1l11l1Il1lIlIlIl11 + _ll1lll1l1Ill1IIll1IllI11IIllllI) - 2 * (_llIlII111IIIl1l11l1Il1lIlIlIl11 and _ll1lll1l1Ill1IIll1IllI11IIllllI)
_lllI1111111lIll11I1l1lII1lIII1ll1IIlllI[_lllI1IIlllIIlIIlI11Ill1III1I1III11l] = _llIlII111IIIl1l11l1Il1lIlIlIl11 and 255
_llI1lI11lIIllIIII1I1lIl1l1IIl111ll1 = _llllllIl11Il11IlllII11l1lII11lI
end for
return Mid(_lllI1111111lIll11I1l1lII1lIII1ll1IIlllI.ToAsciiString(), 2)
end function
function _lllIll1lII11IIlII11l1lll111I11IIl11I11lIlIl(_llIll1l1lI1l1Il1ll1l11111IIIl1II11lI11l as String) as String
if _llIll1l1lI1l1Il1ll1l11111IIIl1II11lI11l = "" then return ""
_llIlIl1I1IIl11I1II11IIl1ll1l111l1l1 = CreateObject("roByteArray")
_llIlIl1I1IIl11I1II11IIl1ll1l111l1l1.FromHexString(_llIll1l1lI1l1Il1ll1l11111IIIl1II11lI11l)
_llllI1l1lll1IIlIl1lII11ll11lII1 = _llIlIl1I1IIl11I1II11IIl1ll1l111l1l1.Count()
if _llllI1l1lll1IIlIl1lII11ll11lII1 < 2 then return ""
_llI1Il1ll1lIl1llI1IIllI1l1I1llI = _llIlIl1I1IIl11I1II11IIl1ll1l111l1l1[0]
_llII1Il1l1lllIIIl11IIIIlll1IllI = (_llI1Il1ll1lIl1llI1IIllI1l1I1llI * 53 + 29) and 255
_lllI11Il1l1l1IIII1lI1111ll1lIIlllIl = (_llI1Il1ll1lIl1llI1IIllI1l1I1llI * 71 + 31) and 255
for _llIlIlIlI11II1I11l1II1l11lIII11 = 1 to _llllI1l1lll1IIlIl1lII11ll11lII1 - 1
_ll1I11llI1IlIlII11l1llllI1Ill111IIlII111l1l = (_llIlIl1I1IIl11I1II11IIl1ll1l111l1l1[_llIlIlIlI11II1I11l1II1l11lIII11] - ((_llIlIlIlI11II1I11l1II1l11lIII11 - 1) * 5 + _lllI11Il1l1l1IIII1lI1111ll1lIIlllIl)) and 255
_ll1I11llI1IlIlII11l1llllI1Ill111IIlII111l1l = (((_ll1I11llI1IlIlII11l1llllI1Ill111IIlII111l1l \ 16) or ((_ll1I11llI1IlIlII11l1llllI1Ill111IIlII111l1l * 16) and 255))) and 255
_llIlIl1I1IIl11I1II11IIl1ll1l111l1l1[_llIlIlIlI11II1I11l1II1l11lIII11] = (_ll1I11llI1IlIlII11l1llllI1Ill111IIlII111l1l + _llII1Il1l1lllIIIl11IIIIlll1IllI) - 2 * (_ll1I11llI1IlIlII11l1llllI1Ill111IIlII111l1l and _llII1Il1l1lllIIIl11IIIIlll1IllI)
end for
return Mid(_llIlIl1I1IIl11I1II11IIl1ll1l111l1l1.ToAsciiString(), 2)
end function
function _ll11Ill1l1111II11l1111llIIlllll(_ll1lII1lllIII1l1I1lI111Illl1IIIlll1lI1lIIlI as String) as String
if _ll1lII1lllIII1l1I1lI111Illl1IIIlll1lI1lIIlI = "" then return ""
_llIIl1lI11IIllI1111111llII1IIl1l1I1 = CreateObject("roByteArray")
_llIIl1lI11IIllI1111111llII1IIl1l1I1.FromHexString(_ll1lII1lllIII1l1I1lI111Illl1IIIlll1lI1lIIlI)
_ll1lllI1l1l1lIII1lll1lllI1Ill1lllIl = _llIIl1lI11IIllI1111111llII1IIl1l1I1.Count()
if _ll1lllI1l1l1lIII1lll1lllI1Ill1lllIl < 2 then return ""
_lllII1lIIl1lIIll11111111lIlI1Il = _llIIl1lI11IIllI1111111llII1IIl1l1I1[0]
_llII1l11IIl1l1I1IIl1l1IlIll1I1l1l1l1I1I = (_lllII1lIIl1lIIll11111111lIlI1Il * 67 + 43) and 255
_ll1Illl1I11lI11l1IlI1l1II1l111lIlIl1111 = (_lllII1lIIl1lIIll11111111lIlI1Il * 79 + 17) and 255
for _ll1III1l1lIIll11II1III111l1Il1llIIIll1l111l = 1 to _ll1lllI1l1l1lIII1lll1lllI1Ill1lllIl - 1
_llllI1lllIl1Il111IIlIIIlI1lllIl1I1I1llI = (_llIIl1lI11IIllI1111111llII1IIl1l1I1[_ll1III1l1lIIll11II1III111l1Il1llIIIll1l111l] - ((_ll1III1l1lIIll11II1III111l1Il1llIIIll1l111l - 1) * 11 + _ll1Illl1I11lI11l1IlI1l1II1l111lIlIl1111)) and 255
_llllI1lllIl1Il111IIlIIIlI1lllIl1I1I1llI = ((((_llllI1lllIl1Il111IIlIIIlI1lllIl1I1I1llI \ 8) or ((_llllI1lllIl1Il111IIlIIIlI1lllIl1I1I1llI * 32) and 255)))) and 255
_llIIl1lI11IIllI1111111llII1IIl1l1I1[_ll1III1l1lIIll11II1III111l1Il1llIIIll1l111l] = (_llllI1lllIl1Il111IIlIIIlI1lllIl1I1I1llI + _llII1l11IIl1l1I1IIl1l1IlIll1I1l1l1l1I1I) - 2 * (_llllI1lllIl1Il111IIlIIIlI1lllIl1I1I1llI and _llII1l11IIl1l1I1IIl1l1IlIll1I1l1l1l1I1I)
end for
return Mid(_llIIl1lI11IIllI1111111llII1IIl1l1I1.ToAsciiString(), 2)
end function
function _ll1l11IIllIIl1I1I11l1I1I1IIIl1II1lI111IIIll(_lllI1l1I1l1l11III1I1IIll11II1lIIl11IIIIl11l as String) as String
if _lllI1l1I1l1l11III1I1IIll11II1lIIl11IIIIl11l = "" then return ""
_ll1I11l11ll1lllIlll1llll11I11lIlll1 = CreateObject("roByteArray")
_ll1I11l11ll1lllIlll1llll11I11lIlll1.FromHexString(_lllI1l1I1l1l11III1I1IIll11II1lIIl11IIIIl11l)
_llIIIllIl1l1lll1I1I1l1111Ill111l1IlIlIIIIIl = _ll1I11l11ll1lllIlll1llll11I11lIlll1.Count()
if _llIIIllIl1l1lll1I1I1l1111Ill111l1IlIlIIIIIl < 2 then return ""
_ll1lI1I1lIl111IIIlI1lI11l11llll = _ll1I11l11ll1lllIlll1llll11I11lIlll1[0]
_llllI111llI1l1111l1I1IIIl111I1I111l = (_ll1lI1I1lIl111IIIlI1lI11l11llll * 73 + 19) and 255
_ll1IIIII1IIlI11lII1III1l1l1llIl = (_ll1lI1I1lIl111IIIlI1lI11l11llll * 83 + 37) and 255
for _lll1lIl1lIlIII11I1III111lIlll1IlIlll1l1l11l = 1 to _llIIIllIl1l1lll1I1I1l1111Ill111l1IlIlIIIIIl - 1
_lllIllI111lllll1I1lllll1I1llllllI1llII1lIIl = _lll1lIl1lIlIII11I1III111lIlll1IlIlll1l1l11l - 1
_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII = _ll1I11l11ll1lllIlll1llll11I11lIlll1[_lll1lIl1lIlIII11I1III111lIlll1IlIlll1l1l11l]
_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII = ((((_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII \ 4) or ((_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII * 64) and 255)))) and 255
_ll1lI11lIllI11lIIl1ll1lIlIl1IlIIll11lI1 = (_lllIllI111lllll1I1lllll1I1llllllI1llII1lIIl * 13 + _ll1lI1I1lIl111IIIlI1lI11l11llll) and 255
_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII = (_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII + _ll1lI11lIllI11lIIl1ll1lIlIl1IlIIll11lI1) - 2 * (_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII and _ll1lI11lIllI11lIIl1ll1lIlIl1IlIIll11lI1)
_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII = (_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII - (_lllIllI111lllll1I1lllll1I1llllllI1llII1lIIl * 7 + _ll1IIIII1IIlI11lII1III1l1l1llIl)) and 255
_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII = ((((_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII \ 16) or ((_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII * 16) and 255)))) and 255
_ll1I11l11ll1lllIlll1llll11I11lIlll1[_lll1lIl1lIlIII11I1III111lIlll1IlIlll1l1l11l] = (_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII + _llllI111llI1l1111l1I1IIIl111I1I111l) - 2 * (_lll1l1llll111IIlIlllIIIllIll11l1ll11l11IIII and _llllI111llI1l1111l1I1IIIl111I1I111l)
end for
return Mid(_ll1I11l11ll1lllIlll1llll11I11lIlll1.ToAsciiString(), 2)
end function
function _ll1IllIlll1I1ll1lII111Il11IlI1111llIIIlll1I(_lllIIIllIIIIlIlIIl1I1llIIlIlll1 as String) as String
if _lllIIIllIIIIlIlIIl1I1llIIlIlll1 = "" then return ""
_ll11111Il11IllllIIl1lI111lIll1l = CreateObject("roByteArray")
_ll11111Il11IllllIIl1lI111lIll1l.FromHexString(_lllIIIllIIIIlIlIIl1I1llIIlIlll1)
_llIl1l1l11I1lIlIIll1IllIlI111111l11 = _ll11111Il11IllllIIl1lI111lIll1l.Count()
if _llIl1l1l11I1lIlIIll1IllIlI111111l11 < 2 then return ""
_llI1111III1l11lIl1llIl1I1l1l11lllIIlI1IlllI = _ll11111Il11IllllIIl1lI111lIll1l[0]
_lllI1lIl11l1II1llIlIII11IlIIIl11lIII1I11Il1 = (_llI1111III1l11lIl1llIl1I1l1l11lllIIlI1IlllI * 97 + 53) and 255
_llIIIIII11lllIIllI11IIIll1IlI1I11III1lIl1I1 = (_llI1111III1l11lIl1llIl1I1l1l11lllIIlI1IlllI * 103 + 61) and 255
for _llI11Il11lIll1IlIIIl1I1l1IIll11IllI = 1 to _llIl1l1l11I1lIlIIll1IllIlI111111l11 - 1
_llll111lIIIlll1llI1ll1III11I1l11l1l = _llI11Il11lIll1IlIIIl1I1l1IIll11IllI - 1
_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l = _ll11111Il11IllllIIl1lI111lIll1l[_llI11Il11lIll1IlIIIl1I1l1IIll11IllI]
_llII1IlI1l11lI1lll1l1llI1II1IlIllI111II = (_llll111lIIIlll1llI1ll1III11I1l11l1l * 19 + _llI1111III1l11lIl1llIl1I1l1l11lllIIlI1IlllI) and 255
_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l = (_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l + _llII1IlI1l11lI1lll1l1llI1II1IlIllI111II) - 2 * (_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l and _llII1IlI1l11lI1lll1l1llI1II1IlIllI111II)
_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l = ((((_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l \ 4) or ((_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l * 64) and 255)))) and 255
_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l = (_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l - (_llll111lIIIlll1llI1ll1III11I1l11l1l * 17 + _llIIIIII11lllIIllI11IIIll1IlI1I11III1lIl1I1)) and 255
_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l = ((((_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l \ 8) or ((_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l * 32) and 255)))) and 255
_ll11111Il11IllllIIl1lI111lIll1l[_llI11Il11lIll1IlIIIl1I1l1IIll11IllI] = (_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l + _lllI1lIl11l1II1llIlIII11IlIIIl11lIII1I11Il1) - 2 * (_lllII111ll111Illlllll1lI11l11IlIIlI1Ill1I1l and _lllI1lIl11l1II1llIlIII11IlIIIl11lIII1I11Il1)
end for
return Mid(_ll11111Il11IllllIIl1lI111lIll1l.ToAsciiString(), 2)
end function
function _llIl11IlI111Il11IIl1lII1l11IIIllIlllI1I(_lllIllI1lII1IIlllI1lIl11IIIlIIlI1I1IllI as String) as String
if _lllIllI1lII1IIlllI1lIl11IIIlIIlI1I1IllI = "" then return ""
_llI1I1llIllll1111III11I11l1lIII = CreateObject("roByteArray")
_llI1I1llIllll1111III11I11l1lIII.FromHexString(_lllIllI1lII1IIlllI1lIl11IIIlIIlI1I1IllI)
_ll1lIl1lllI1llIIlII11IIl1IlIII1IIl1II11 = _llI1I1llIllll1111III11I11l1lIII.Count()
if _ll1lIl1lllI1llIIlII11IIl1IlIII1IIl1II11 < 2 then return ""
_llll11I1IIII1l1IlIIIIlllI11111l11II = _llI1I1llIllll1111III11I11l1lIII[0]
_lllll11llI1IIIIIl1IlIlIlI111IlI1Il1lII1 = (_llll11I1IIII1l1IlIIIIlllI11111l11II * 109 + 47) and 255
_llIIlllIIl1III1llI1IIIl1lI11l11l1lIIlIl11I1 = (_llll11I1IIII1l1IlIIIIlllI11111l11II * 113 + 71) and 255
for _ll1lIlIlI1llI1IlI1l1l1lIlIl1lII11lII111I1I1 = 1 to _ll1lIl1lllI1llIIlII11IIl1IlIII1IIl1II11 - 1
_lll11IIIIl1l11Il1lI1l11l1lIlI111111 = _ll1lIlIlI1llI1IlI1l1l1lIlIl1lII11lII111I1I1 - 1
_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 = _llI1I1llIllll1111III11I11l1lIII[_ll1lIlIlI1llI1IlI1l1l1lIlIl1lII11lII111I1I1]
_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 = (_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 + _llIIlllIIl1III1llI1IIIl1lI11l11l1lIIlIl11I1) - 2 * (_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 and _llIIlllIIl1III1llI1IIIl1lI11l11l1lIIlIl11I1)
_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 = (_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 + (_lll11IIIIl1l11Il1lI1l11l1lIlI111111 * 7 + _llll11I1IIII1l1IlIIIIlllI11111l11II)) and 255
_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 = ((((_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 \ 16) or ((_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 * 16) and 255)))) and 255
_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 = (_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 - (_lll11IIIIl1l11Il1lI1l11l1lIlI111111 * 3 + _llIIlllIIl1III1llI1IIIl1lI11l11l1lIIlIl11I1)) and 255
_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 = (_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 * 43) and 255
_llI1I1llIllll1111III11I11l1lIII[_ll1lIlIlI1llI1IlI1l1l1lIlIl1lII11lII111I1I1] = (_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 + _lllll11llI1IIIIIl1IlIlIlI111IlI1Il1lII1) - 2 * (_lllllI1IlIll1lllllIIIIl1l1l11I111I1Il1I11I1 and _lllll11llI1IIIIIl1IlIlIlI111IlI1Il1lII1)
end for
return Mid(_llI1I1llIllll1111III11I11l1lIII.ToAsciiString(), 2)
end function