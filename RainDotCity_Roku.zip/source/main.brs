sub Main()
ShowChannelSGScreen()
end sub
sub ShowChannelSGScreen()
_lll1l1l = CreateObject(_l1d_67ec73("edebd2c9d8ebfff7fa04", 3, 124))
m.port = CreateObject(_l1d_67ec73("f8deffea0306f7f8f931f91916", 45, 153))
_lll1l1l.SetMessagePort(m.port)
_lIIll1l = _lll1l1l.CreateScene(_l1d_67ec73("8dbcb7b3b3c6c7bfcd", 78, 138))
_lIIll1l.observeField(_l1d_67ec73("7181738b619598", 141, 137), m.port)
_lll1l1l.Show()
while true
_llIll1l = wait(0, m.port)
_l1Ill1l = type(_llIll1l)
if _l1Ill1l = _l1d_67ec73("674d8c7b9265796568668e8474728b", 109, 72) then
if _llIll1l.isScreenClosed() then return
else if _l1Ill1l = _l1d_67ec73("d3d3faf1fbdfd7dbfef2e4f0f9", 96, 193) then
if _llIll1l.getField() = _l1d_67ec73("857b8f7d6d7f82", 210, 206) and _llIll1l.getData() = true then
_lll1l1l.close()
return
end if
end if
end while
end sub
function _l1d_67ec73(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function