function JU_ToBase(_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l as Integer, _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll as Integer) as String
if _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll < ((((((44 * 11) + 2) + 42) - ((44 * 11) + 42)))) then _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = ((((((37 * 5) + (2 * 3)) - (37 * 5)) \ 3)))
if _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll > 62 then _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = 62
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = _llIIlIllI1ll11l1Il1ll1IlIlllI1I111I(_llIIl1llI1I1llII1lllIll1IlIIIIIIIl111ll(_llIlIIllIllI1l1lI1IIIIIII111l11(_ll1lI1IIlIlIl111l1IIlllll1llIl1(_llII11llllIII11Ill11ll11lIIlIlllIII1111("7664dde106fbca135d2e09c0b99344dc8ec8991345fc5e718040ba2b2a7eefc141730c47f69140bb1a2c5cd6d16018db6d9c566863b39387f4c92e78d0c585796fe820338c5dbe8928f8cd727d910800bb554d069909625b92df7ebec8c3a3ec845e70a81afa2a9ff1e960c20c6ddcb768611a0decbcd1d043bd8dc706f1b063a2cdfe5930a342dad59e91a92a5afaa4df7e8bc55def267c19330bda2c0c7936e8835d15a4de9ecae2b5b43959d390aa7a6edef3d12b95556cbe31cb485d172786984b4a4236e699b065a23cf5e619fb33e2f495ef61b3120a344cd9f033625d0caef8f892c5a257690073c884bd546ee0faf39c74ee292030e5e556312edbdbab4296e1e1fbaa9d5db766f9b20542f78ec80398125c77ee8023936aa43cefee601225e4dc8e661a7b243cd6b12072f38d1656a063124492978fa9e3d02585b10e63c395ca473cf0cb9bdae5ff1491ebbb8d6c7e99d12bfbad47c469c8c39a7224e470e0e054a4a6f188419a950c07f868887d2c27c6d15643bdf22c84b94975a2efe47fbe50422cd5ec911383c8cc6fdf79302b3b0d4ffe1933ab428c4f6739c923821507def888c362b43939d0eabc7a14ded14ba895cf0741516baa0217e486b34beaf42ce6b8532a4535ee46e1b833a5f4f7ef78b32afcddc6b81b6a622aacaff873928bdc1769c078b284fc372fe053c5a474d6493b9aea6adc3161db7a0d1d1c2ce118ca8a7c1786c39b4a4236578703ba255c5ecee179336c2a9cf1c1415aac04f6f640437b65273f57401892f2a4894e497a0d92bfcea0bb328cfc796fe820f08c653c30cba25b0c66769100bb2c6c9e7708a95b92a47e89689bb5ec84e4ce20ba52a406d61041a21b05dcf831ca1ad2275fd10ba80314e684b92863a2ecfee6be6b424dc4863ee9835acce706f011a3fd0c4f26383002f48ca77913c91d5d8c0721f852c3d5b487399873aa7ac7a1d94beb7535070651687d02742786b04b68dd2fe6a65308c23fd741e1fb33e2f489814631120afccfce50338a5c77e6615068c5dc5769c1784b1d5c546ee0d8929d5f7629c3fb6de57c8ec6dbd32a423f96d8932d5d7cb766c33b05421f572903ba451c77ee8080ba052af64e46419aac24dcf6e0391a125c5f57a8fb1ba4a4560e633a0d1f5e4fc922d02d8597d1412032ca07bef0cb3bcd4c7d3e362342526c6477c38b6244df47f6eec3127224ffe90bba54a406ded6415a1b6c265151031a4d0d5fb171a8bdf26c84b94975a2efe4e75068c02cd55f913631fbcc6fdfd96bc5fdb44fbe38d2029db2877939c923948ca43ff888c39daf8759f6cb54f56fde3ed1a895cf07d9b649ca3a174e593b4b684214e699b82ba23f77cf1933ca9d7f4eef38312afc1cc64166782bd4776cf81968a5bc75a6269890e3348f08d91392a795eecf3b9aac05560c66a0")))))
if _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l < ((((((24 * 11) + 0) + 42) - ((24 * 11) + 42)))) then _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = ((((((14 * 64) + 0) mod 64) + ((255 and 255) - 255))))
if _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l < _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll then return Mid(_llIIl111Illll1111ll111lllI11Il1l11ll11111ll, _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l + ((((((31 * 7) + ((25 * 13) - (25 * 13))) + 1) - (31 * 4)) - (31 * 3))), ((((((26 * 5) + (1 * 3)) - (26 * 5)) \ 3))))
return JU_ToBase(_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l \ _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll, _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll) + Mid(_llIIl111Illll1111ll111lllI11Il1l11ll11111ll, (_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l mod _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll) + ((((((20 * 7) + ((27 * 13) - (27 * 13))) + 1) - (20 * 4)) - (20 * 3))), ((((((12 * 5) + (1 * 3)) - (12 * 5)) \ 3))))
end function
function JU_UnpackPacked(_llIIlI111l1IllIlI11l11IllIllIl1 as String) as String
if _llIIlI111l1IllIlI11l11IllIllIl1 = invalid or _llIIlI111l1IllIlI11l11IllIllIl1 = "" then return ""
_ll1111llIlIII1IlII1lllI1I1l1Illl11I111I = CreateObject(_llII11llllIII11Ill11ll11lIIlIlllIII1111("6a546a83fd642f5c"), _llIIlIllI1ll11l1Il1ll1IlIlllI1I111I(_ll1lI1IIlIlIl111l1IIlllll1llIl1("4c5e51546f242f803530c946af5cc5d095e6abae07d45deacd0051ee11b227c8abde63f4cf0a7792959809442f5ae7704386eb0e09147dc0a3d65bec81fafd10139819ae2f6255daf5e81bfe9fa295b0abc6f9dce71a1d082b2e4144376adf786b861bac8f9a37a8d3ee53ec07ea9728030e59")), (Chr(105) + Chr(115)))
m = _ll1111llIlIII1IlII1lllI1I1l1Illl11I111I.match(_llIIlI111l1IllIlI11l11IllIllIl1)
if m = invalid or m.Count() < ((((((28 * 64) + 5) mod 64) + ((255 and 255) - 255)))) then return ""
_llIII1I1llII1IIII1lI11l1lI1lIlI = m[((((((20 * 11) + 1) + 42) - ((20 * 11) + 42))))]
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m[((((((37 * 5) + (2 * 3)) - (37 * 5)) \ 3)))].ToInt()
_llll1I11llIlll11lII11l11111IIIl = m[((((((41 * 7) + ((32 * 13) - (32 * 13))) + 3) - (41 * 4)) - (41 * 3)))].ToInt()
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 < ((((((13 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then _lllIIlIlII1ll111l1Il11Illlll11l11I1 = ((((((25 * 7) + ((22 * 13) - (22 * 13))) + 2) - (25 * 4)) - (25 * 3)))
if _llll1I11llIlll11lII11l11111IIIl < ((((((40 * 5) + (0 * 3)) - (40 * 5)) \ 3))) then return ""
_llI11Il1II1I1lI1II11I1111II1lIl = m[((((((29 * 5) + (4 * 3)) - (29 * 5)) \ 3)))]
_llI1111ll111IlllIlI111lII1IIlIl = _llI11Il1II1I1lI1II11I1111II1lIl.Tokenize(Chr(124))
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l = []
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = ""
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = ((((((42 * 64) + 1) mod 64) + ((255 and 255) - 255))))
while _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I <= Len(_llI11Il1II1I1lI1II11I1111II1lIl)
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = Mid(_llI11Il1II1I1lI1II11I1111II1lIl, _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I, ((((((11 * 5) + (1 * 3)) - (11 * 5)) \ 3))))
if _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = Chr(124) then
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l.Push(_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII)
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = ""
else
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII + _llI111lI11I1l11lI11l1lIlll11111lIIlI1II
end if
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I + ((((((20 * 7) + ((32 * 13) - (32 * 13))) + 1) - (20 * 4)) - (20 * 3)))
end while
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l.Push(_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII)
_llIIIII111l11l11IIIllIllIIl1I1l = _llIII1I1llII1IIII1lI11l1lI1lIlI
_llI1lIlIIIlllI1I11Il1I11IlI11Il = _llll1I11llIlll11lII11l11111IIIl - ((((((35 * 5) + (1 * 3)) - (35 * 5)) \ 3)))
while _llI1lIlIIIlllI1I11Il1I11IlI11Il >= ((((((36 * 5) + (0 * 3)) - (36 * 5)) \ 3)))
if _llI1lIlIIIlllI1I11Il1I11IlI11Il < _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l.Count() then
_llIllI1IIl1II1I1I1lIll11l1ll1II11l1IIll = _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l[_llI1lIlIIIlllI1I11Il1I11IlI11Il]
if _llIllI1IIl1II1I1I1lIll11l1ll1II11l1IIll <> "" then
_llIIllIII1I1IllII1lIIlIl1IIIllll1IIIIII = JU_ToBase(_llI1lIlIIIlllI1I11Il1I11IlI11Il, _lllIIlIlII1ll111l1Il11Illlll11l11I1)
_ll1II111ll111I1l1I1ll1Illll11lI1ll11ll1lll1 = (Chr(92) + Chr(98)) + _llIIllIII1I1IllII1lIIlIl1IIIllll1IIIIII + (Chr(92) + Chr(98))
_llIlIIllIlIlIlIl1lIllIIIIlIIIlI11IllllI1I1I = CreateObject(_llII11llllIII11Ill11ll11lIIlIlllIII1111(_llIIl1llI1I1llII1lllIll1IlIIIIIIIl111ll(_llII1lI1I1lIIlIlIIII1l1111lIIl11l1lIlIIllII(_llIIlll1IIIIlllIl111l1I11ll1II1(_llIlIIllIllI1l1lI1IIIIIII111l11("508751dd4982708f648a64f36ab830853693319ec19adbc3b996ebddbbadb1b3bddbe886a5d908844e804feb10f51e8b40c245c071c7639f9f90ccdac5b4ccff9382928b8886b2dead83ac2afd6ea102ff1af91c8c47c14bfc4ef057ffa9f4bda680f18abd8192ded4dad6b0dff1de07d416d01fb84ea817831c87008a3b8021d988dbd597d9acd7bcd2befae0b2b8"))))), _ll1II111ll111I1l1I1ll1Illll11lI1ll11ll1lll1, Chr(103))
_llIIIII111l11l11IIIllIllIIl1I1l = _llIlIIllIlIlIlIl1lIllIIIIlIIIlI11IllllI1I1I.replaceAll(_llIIIII111l11l11IIIllIllIIl1I1l, _llIllI1IIl1II1I1I1lIll11l1ll1II11l1IIll)
end if
end if
_llI1lIlIIIlllI1I11Il1I11IlI11Il = _llI1lIlIIIlllI1I11Il1I11IlI11Il - ((((((26 * 11) + 1) + 42) - ((26 * 11) + 42))))
end while
return _llIIIII111l11l11IIIllIllIIl1I1l
end function
function _llIIlIllI1ll11l1Il1ll1IlIlllI1I111I(_ll1l1lllIlII1111III1IIlI1lIIlllll11I1l1Il1l as String) as String
if _ll1l1lllIlII1111III1IIlI1lIIlllll11I1l1Il1l = "" then return ""
_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11 = CreateObject("roByteArray")
_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11.FromHexString(_ll1l1lllIlII1111III1IIlI1lIIlllll11I1l1Il1l)
_ll11l1Il1I1l1ll1I1IIIllIlI11I1lI1I1 = _llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11.Count()
if _ll11l1Il1I1l1ll1I1IIIllIlI11I1lI1I1 < 2 then return ""
_llIlll1lIII11I1IllIl11Il1IlIl11I1I11I1l = _llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11[0]
_llI1ll11IIII1llIIIl111Il1l1ll111I1IIlllIl1l = (_llIlll1lIII11I1IllIl11Il1IlIl11I1I11I1l * 37 + 11) and 255
_llIIII11llIlI1l1l1lIII1II1Il11l1lIl1IIIIlll = (_llIlll1lIII11I1IllIl11Il1IlIl11I1I11I1l * 59 + 23) and 255
for _lllI11Il111IIllI111l11I1111Il1lIllI = 1 to _ll11l1Il1I1l1ll1I1IIIllIlI11I1lI1I1 - 1
_lllll111lIIl11lIll1I1llIlIIIIl1lI11Ill1 = (_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11[_lllI11Il111IIllI111l11I1111Il1lIllI] - ((_lllI11Il111IIllI111l11I1111Il1lIllI - 1) * 3 + _llIIII11llIlI1l1l1lIII1II1Il11l1lIl1IIIIlll)) and 255
_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11[_lllI11Il111IIllI111l11I1111Il1lIllI] = (_lllll111lIIl11lIll1I1llIlIIIIl1lI11Ill1 + _llI1ll11IIII1llIIIl111Il1l1ll111I1IIlllIl1l) - 2 * (_lllll111lIIl11lIll1I1llIlIIIIl1lI11Ill1 and _llI1ll11IIII1llIIIl111Il1l1ll111I1IIlllIl1l)
end for
return Mid(_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11.ToAsciiString(), 2)
end function
function _llIlIIllIllI1l1lI1IIIIIII111l11(_llIl1lII1IIII1I111llI1ll11IIIll as String) as String
if _llIl1lII1IIII1I111llI1ll11IIIll = "" then return ""
_llIlIllI1l111lI111lI11l1II111l1lIII = CreateObject("roByteArray")
_llIlIllI1l111lI111lI11l1II111l1lIII.FromHexString(_llIl1lII1IIII1I111llI1ll11IIIll)
_llI11I1IllIl11111II11l1I111I1I1l1ll = _llIlIllI1l111lI111lI11l1II111l1lIII.Count()
if _llI11I1IllIl11111II11l1I111I1I1l1ll < 2 then return ""
_ll1lll1IllIl11l1lIlll11IlIIlIll1ll1 = _llIlIllI1l111lI111lI11l1II111l1lIII[0]
_llIlIIlllllIl1IIl1ll111lll111I1I1lllIII1Il1 = (_ll1lll1IllIl11l1lIlll11IlIIlIll1ll1 * 41 + 19) and 255
_llI11l11lIl11l11lI11l11llIIIllIl111lIll = _ll1lll1IllIl11l1lIlll11IlIIlIll1ll1
for _lllIllIIl1IIl11llI1l11lIII11lll = 1 to _llI11I1IllIl11111II11l1I111I1I1l1ll - 1
_lllIl1Il1I1I1IIll11l11Ill1lIlIl = _llIlIllI1l111lI111lI11l1II111l1lIII[_lllIllIIl1IIl11llI1l11lIII11lll]
_llIlIllIllI11lI1II1Illl11I1Il11IIll = ((_lllIllIIl1IIl11llI1l11lIII11lll - 1) * 7) and 255
_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I = (_lllIl1Il1I1I1IIll11l11Ill1lIlIl + _llI11l11lIl11l11lI11l11llIIIllIl111lIll) - 2 * (_lllIl1Il1I1I1IIll11l11Ill1lIlIl and _llI11l11lIl11l11lI11l11llIIIllIl111lIll)
_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I = (_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I + _llIlIIlllllIl1IIl1ll111lll111I1I1lllIII1Il1) - 2 * (_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I and _llIlIIlllllIl1IIl1ll111lll111I1I1lllIII1Il1)
_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I = (_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I + _llIlIllIllI11lI1II1Illl11I1Il11IIll) - 2 * (_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I and _llIlIllIllI11lI1II1Illl11I1Il11IIll)
_llIlIllI1l111lI111lI11l1II111l1lIII[_lllIllIIl1IIl11llI1l11lIII11lll] = _llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I and 255
_llI11l11lIl11l11lI11l11llIIIllIl111lIll = _lllIl1Il1I1I1IIll11l11Ill1lIlIl
end for
return Mid(_llIlIllI1l111lI111lI11l1II111l1lIII.ToAsciiString(), 2)
end function
function _llII1lI1I1lIIlIlIIII1l1111lIIl11l1lIlIIllII(_ll1llI1l111lI111II1I1l1l111ll11lIlllIll as String) as String
if _ll1llI1l111lI111II1I1l1l111ll11lIlllIll = "" then return ""
_ll1IlI1I11lIlll1lIlII11l1IIlIIlIIII = CreateObject("roByteArray")
_ll1IlI1I11lIlll1lIlII11l1IIlIIlIIII.FromHexString(_ll1llI1l111lI111II1I1l1l111ll11lIlllIll)
_llI1I11I11IlI1lllIllIl1111llIlI1l1II1ll = _ll1IlI1I11lIlll1lIlII11l1IIlIIlIIII.Count()
if _llI1I11I11IlI1lllIllIl1111llIlI1l1II1ll < 2 then return ""
_llII1l1II111IIlI1I11Il1IlIll111IIlIIllllIl1 = _ll1IlI1I11lIlll1lIlII11l1IIlIIlIIII[0]
_lll1IIl11III1I1l1IlIlIl11II1I1llI1lI1lI = (_llII1l1II111IIlI1I11Il1IlIll111IIlIIllllIl1 * 53 + 29) and 255
_llI1IllIIIlI11IlIl1IIII1IlIllI1Il1llIl1 = (_llII1l1II111IIlI1I11Il1IlIll111IIlIIllllIl1 * 71 + 31) and 255
for _lllII1llIl1l11IlI1I1I1lI1IllII1 = 1 to _llI1I11I11IlI1lllIllIl1111llIlI1l1II1ll - 1
_llIl1lIIlIIIlIIl1Ill11IIIl1I111II11III1 = (_ll1IlI1I11lIlll1lIlII11l1IIlIIlIIII[_lllII1llIl1l11IlI1I1I1lI1IllII1] - ((_lllII1llIl1l11IlI1I1I1lI1IllII1 - 1) * 5 + _llI1IllIIIlI11IlIl1IIII1IlIllI1Il1llIl1)) and 255
_llIl1lIIlIIIlIIl1Ill11IIIl1I111II11III1 = (((_llIl1lIIlIIIlIIl1Ill11IIIl1I111II11III1 \ 16) or ((_llIl1lIIlIIIlIIl1Ill11IIIl1I111II11III1 * 16) and 255))) and 255
_ll1IlI1I11lIlll1lIlII11l1IIlIIlIIII[_lllII1llIl1l11IlI1I1I1lI1IllII1] = (_llIl1lIIlIIIlIIl1Ill11IIIl1I111II11III1 + _lll1IIl11III1I1l1IlIlIl11II1I1llI1lI1lI) - 2 * (_llIl1lIIlIIIlIIl1Ill11IIIl1I111II11III1 and _lll1IIl11III1I1l1IlIlIl11II1I1llI1lI1lI)
end for
return Mid(_ll1IlI1I11lIlll1lIlII11l1IIlIIlIIII.ToAsciiString(), 2)
end function
function _ll1lI1IIlIlIl111l1IIlllll1llIl1(_llII1lll111111lI1ll1l111I111I11 as String) as String
if _llII1lll111111lI1ll1l111I111I11 = "" then return ""
_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111 = CreateObject("roByteArray")
_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111.FromHexString(_llII1lll111111lI1ll1l111I111I11)
_lll1IIlI1l111I11l11I1I1IIIII11l = _llIIlll11llIII1lII1ll11lllll11IIIllIII1I111.Count()
if _lll1IIlI1l111I11l11I1I1IIIII11l < 2 then return ""
_llIl111IlllIllIl1l1llll11Ill1IIIllI = _llIIlll11llIII1lII1ll11lllll11IIIllIII1I111[0]
_llllll11lI111IIIIIll111llIllIllIlIl1IllII1I = (_llIl111IlllIllIl1l1llll11Ill1IIIllI * 67 + 43) and 255
_ll11IIlllIIlIIllIllIIIIIII1IlIl1lIlIllI = (_llIl111IlllIllIl1l1llll11Ill1IIIllI * 79 + 17) and 255
for _llIIIIlIl11l1IIlIlIIIIlIIIIIlIll1I1I1ll = 1 to _lll1IIlI1l111I11l11I1I1IIIII11l - 1
_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 = (_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111[_llIIIIlIl11l1IIlIlIIIIlIIIIIlIll1I1I1ll] - ((_llIIIIlIl11l1IIlIlIIIIlIIIIIlIll1I1I1ll - 1) * 11 + _ll11IIlllIIlIIllIllIIIIIII1IlIl1lIlIllI)) and 255
_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 = ((((_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 \ 8) or ((_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 * 32) and 255)))) and 255
_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111[_llIIIIlIl11l1IIlIlIIIIlIIIIIlIll1I1I1ll] = (_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 + _llllll11lI111IIIIIll111llIllIllIlIl1IllII1I) - 2 * (_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 and _llllll11lI111IIIIIll111llIllIllIlIl1IllII1I)
end for
return Mid(_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111.ToAsciiString(), 2)
end function
function _llIIlll1IIIIlllIl111l1I11ll1II1(_ll1lIlI1lIIllIl1llIllI1I1IlI1lI as String) as String
if _ll1lIlI1lIIllIl1llIllI1I1IlI1lI = "" then return ""
_lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll = CreateObject("roByteArray")
_lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll.FromHexString(_ll1lIlI1lIIllIl1llIllI1I1IlI1lI)
_ll1lllllI11lI111Il1Illll1llIl11llIl = _lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll.Count()
if _ll1lllllI11lI111Il1Illll1llIl11llIl < 2 then return ""
_llI111IIllII1l11IlIllI1lIIlll11IllIIl1I = _lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll[0]
_llIII1l11lI1lIlIIl1l1llll1I111Il111l1Il1lIl = (_llI111IIllII1l11IlIllI1lIIlll11IllIIl1I * 73 + 19) and 255
_llllI11ll111l1IlllI1llI11I1lI1l = (_llI111IIllII1l11IlIllI1lIIlll11IllIIl1I * 83 + 37) and 255
for _ll11I1lIII1IIll11lII1l1llIl1III = 1 to _ll1lllllI11lI111Il1Illll1llIl11llIl - 1
_ll1I1l1I1IllI1Il1IlI1lIIll1Il1lIIl1ll11 = _ll11I1lIII1IIll11lII1l1llIl1III - 1
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = _lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll[_ll11I1lIII1IIll11lII1l1llIl1III]
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = ((((_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l \ 4) or ((_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l * 64) and 255)))) and 255
_ll1lll11Il1I1IllI1IllIlIIl1lIII111l1ll1 = (_ll1I1l1I1IllI1Il1IlI1lIIll1Il1lIIl1ll11 * 13 + _llI111IIllII1l11IlIllI1lIIlll11IllIIl1I) and 255
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l + _ll1lll11Il1I1IllI1IllIlIIl1lIII111l1ll1) - 2 * (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l and _ll1lll11Il1I1IllI1IllIlIIl1lIII111l1ll1)
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l - (_ll1I1l1I1IllI1Il1IlI1lIIll1Il1lIIl1ll11 * 7 + _llllI11ll111l1IlllI1llI11I1lI1l)) and 255
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = ((((_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l \ 16) or ((_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l * 16) and 255)))) and 255
_lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll[_ll11I1lIII1IIll11lII1l1llIl1III] = (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l + _llIII1l11lI1lIlIIl1l1llll1I111Il111l1Il1lIl) - 2 * (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l and _llIII1l11lI1lIlIIl1l1llll1I111Il111l1Il1lIl)
end for
return Mid(_lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll.ToAsciiString(), 2)
end function
function _llIIl1llI1I1llII1lllIll1IlIIIIIIIl111ll(_lll1I11l111lllI1I1lIIII1I1l1I1ll1l1 as String) as String
if _lll1I11l111lllI1I1lIIII1I1l1I1ll1l1 = "" then return ""
_llI1I1lIll111111II1Il11lI11lI1Ill1Il11I = CreateObject("roByteArray")
_llI1I1lIll111111II1Il11lI11lI1Ill1Il11I.FromHexString(_lll1I11l111lllI1I1lIIII1I1l1I1ll1l1)
_ll1Il11l11lI11l11l1lI1lII1l11II = _llI1I1lIll111111II1Il11lI11lI1Ill1Il11I.Count()
if _ll1Il11l11lI11l11l1lI1lII1l11II < 2 then return ""
_llI1Il1I1ll11l1llIllIl1llIlI1lllIII = _llI1I1lIll111111II1Il11lI11lI1Ill1Il11I[0]
_llI1lIl1lllI11llIlll1l1I1l1I1II11lI = (_llI1Il1I1ll11l1llIllIl1llIlI1lllIII * 97 + 53) and 255
_ll11IIIIIll1l1ll1llIlI1IIl1II11111lI1I1 = (_llI1Il1I1ll11l1llIllIl1llIlI1lllIII * 103 + 61) and 255
for _llllI1I1IlllI11lll111I1IIII111I = 1 to _ll1Il11l11lI11l11l1lI1lII1l11II - 1
_ll11Il1IIIlIIIllllII1lllI1lIlII = _llllI1I1IlllI11lll111I1IIII111I - 1
_ll111ll1llll1I111Il1I1l1III1l11I11I = _llI1I1lIll111111II1Il11lI11lI1Ill1Il11I[_llllI1I1IlllI11lll111I1IIII111I]
_lllIll11IllllI1l1I1lllIIllllll11ll1 = (_ll11Il1IIIlIIIllllII1lllI1lIlII * 19 + _llI1Il1I1ll11l1llIllIl1llIlI1lllIII) and 255
_ll111ll1llll1I111Il1I1l1III1l11I11I = (_ll111ll1llll1I111Il1I1l1III1l11I11I + _lllIll11IllllI1l1I1lllIIllllll11ll1) - 2 * (_ll111ll1llll1I111Il1I1l1III1l11I11I and _lllIll11IllllI1l1I1lllIIllllll11ll1)
_ll111ll1llll1I111Il1I1l1III1l11I11I = ((((_ll111ll1llll1I111Il1I1l1III1l11I11I \ 4) or ((_ll111ll1llll1I111Il1I1l1III1l11I11I * 64) and 255)))) and 255
_ll111ll1llll1I111Il1I1l1III1l11I11I = (_ll111ll1llll1I111Il1I1l1III1l11I11I - (_ll11Il1IIIlIIIllllII1lllI1lIlII * 17 + _ll11IIIIIll1l1ll1llIlI1IIl1II11111lI1I1)) and 255
_ll111ll1llll1I111Il1I1l1III1l11I11I = ((((_ll111ll1llll1I111Il1I1l1III1l11I11I \ 8) or ((_ll111ll1llll1I111Il1I1l1III1l11I11I * 32) and 255)))) and 255
_llI1I1lIll111111II1Il11lI11lI1Ill1Il11I[_llllI1I1IlllI11lll111I1IIII111I] = (_ll111ll1llll1I111Il1I1l1III1l11I11I + _llI1lIl1lllI11llIlll1l1I1l1I1II11lI) - 2 * (_ll111ll1llll1I111Il1I1l1III1l11I11I and _llI1lIl1lllI11llIlll1l1I1l1I1II11lI)
end for
return Mid(_llI1I1lIll111111II1Il11lI11lI1Ill1Il11I.ToAsciiString(), 2)
end function
function _llII11llllIII11Ill11ll11lIIlIlllIII1111(_llllll1lll1llIIlIl11lIlIlll1IlIIIlIlII1 as String) as String
if _llllll1lll1llIIlIl11lIlIlll1IlIIIlIlII1 = "" then return ""
_lllIllIllIl1IIlI1lll111l1Ill111IlI1 = CreateObject("roByteArray")
_lllIllIllIl1IIlI1lll111l1Ill111IlI1.FromHexString(_llllll1lll1llIIlIl11lIlIlll1IlIIIlIlII1)
_lllIlI1I1l1lIl1lIIl1lll11IlllI1IIllllI1 = _lllIllIllIl1IIlI1lll111l1Ill111IlI1.Count()
if _lllIlI1I1l1lIl1lIIl1lll11IlllI1IIllllI1 < 2 then return ""
_llllI1111ll11111lI1I1IlIlI11IlIl11I = _lllIllIllIl1IIlI1lll111l1Ill111IlI1[0]
_ll11lll1I1l1ll1111ll11lIlIlll1I11IIlIl111ll = (_llllI1111ll11111lI1I1IlIlI11IlIl11I * 109 + 47) and 255
_llI1ll1l1111llllIllI1III1111lIIIIII1lIlIIll = (_llllI1111ll11111lI1I1IlIlI11IlIl11I * 113 + 71) and 255
for _llIl1II1l11llI1IlIll1I1lI111l1IlI1IIlll11lI = 1 to _lllIlI1I1l1lIl1lIIl1lll11IlllI1IIllllI1 - 1
_ll1IIII11lI1IIII11I1I11lll1lll1II11I1111IIl = _llIl1II1l11llI1IlIll1I1lI111l1IlI1IIlll11lI - 1
_llIIII1lllI1I1I1IlIIII1I1I1lllI = _lllIllIllIl1IIlI1lll111l1Ill111IlI1[_llIl1II1l11llI1IlIll1I1lI111l1IlI1IIlll11lI]
_llIIII1lllI1I1I1IlIIII1I1I1lllI = (_llIIII1lllI1I1I1IlIIII1I1I1lllI + _llI1ll1l1111llllIllI1III1111lIIIIII1lIlIIll) - 2 * (_llIIII1lllI1I1I1IlIIII1I1I1lllI and _llI1ll1l1111llllIllI1III1111lIIIIII1lIlIIll)
_llIIII1lllI1I1I1IlIIII1I1I1lllI = (_llIIII1lllI1I1I1IlIIII1I1I1lllI + (_ll1IIII11lI1IIII11I1I11lll1lll1II11I1111IIl * 7 + _llllI1111ll11111lI1I1IlIlI11IlIl11I)) and 255
_llIIII1lllI1I1I1IlIIII1I1I1lllI = ((((_llIIII1lllI1I1I1IlIIII1I1I1lllI \ 16) or ((_llIIII1lllI1I1I1IlIIII1I1I1lllI * 16) and 255)))) and 255
_llIIII1lllI1I1I1IlIIII1I1I1lllI = (_llIIII1lllI1I1I1IlIIII1I1I1lllI - (_ll1IIII11lI1IIII11I1I11lll1lll1II11I1111IIl * 3 + _llI1ll1l1111llllIllI1III1111lIIIIII1lIlIIll)) and 255
_llIIII1lllI1I1I1IlIIII1I1I1lllI = (_llIIII1lllI1I1I1IlIIII1I1I1lllI * 43) and 255
_lllIllIllIl1IIlI1lll111l1Ill111IlI1[_llIl1II1l11llI1IlIll1I1lI111l1IlI1IIlll11lI] = (_llIIII1lllI1I1I1IlIIII1I1I1lllI + _ll11lll1I1l1ll1111ll11lIlIlll1I11IIlIl111ll) - 2 * (_llIIII1lllI1I1I1IlIIII1I1I1lllI and _ll11lll1I1l1ll1111ll11lIlIlll1I11IIlIl111ll)
end for
return Mid(_lllIllIllIl1IIlI1lll111l1Ill111IlI1.ToAsciiString(), 2)
end function