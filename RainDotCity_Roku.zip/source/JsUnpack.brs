function JU_ToBase(_l1lI1ll as Integer, _lII11ll as Integer) as String
if _lII11ll < 2 then _lII11ll = 2
if _lII11ll > 62 then _lII11ll = 62
_lllI1ll = _l1d_8bfd24("9fa3a7abafb3b7bbafb38e92969a9ea2a69a9ea2a6aaaeb2b6aaaeb2b6babec2c6babec2fc0004080c1014080c1014181c2024181c2024282c3034282c30", 248, 215)
if _l1lI1ll < 0 then _l1lI1ll = 0
if _l1lI1ll < _lII11ll then return Mid(_lllI1ll, _l1lI1ll + 1, 1)
return JU_ToBase(_l1lI1ll \ _lII11ll, _lII11ll) + Mid(_lllI1ll, (_l1lI1ll mod _lII11ll) + 1, 1)
end function
function JU_UnpackPacked(_lII1l1l as String) as String
if _lII1l1l = invalid or _lII1l1l = "" then return ""
_l1lIl1l = CreateObject(_l1d_8bfd24("dac8c0d4d9dae2", 137, 223), _l1d_8bfd24("1e0024b3b3b92d330b39313ed0e6d3d4dedd541fe7e8f0ef6631f9fa02fe04787e56847c891b311e1f992e7476757383ae3d3db79a46c04e", 161, 33), _l1d_8bfd24("2a43", 239, 164))
m = _l1lIl1l.match(_lII1l1l)
if m = invalid or m.Count() < 5 then return ""
_l1I1l1l = m[1]
_llIll1l = m[2].ToInt()
_l1Ill1l = m[3].ToInt()
if _llIll1l < 2 then _llIll1l = 2
if _l1Ill1l < 0 then return ""
_lI11l1l = m[4]
_ll11l1l = _lI11l1l.Tokenize(_l1d_8bfd24("76", 254, 244))
_l111l1l = []
_lll1l1l = ""
_l1l1l1l = 1
while _l1l1l1l <= Len(_lI11l1l)
_lIIll1l = Mid(_lI11l1l, _l1l1l1l, 1)
if _lIIll1l = _l1d_8bfd24("37", 89, 18) then
_l111l1l.Push(_lll1l1l)
_lll1l1l = ""
else
_lll1l1l = _lll1l1l + _lIIll1l
end if
_l1l1l1l = _l1l1l1l + 1
end while
_l111l1l.Push(_lll1l1l)
_llI1l1l = _l1I1l1l
_lIl1l1l = _l1Ill1l - 1
while _lIl1l1l >= 0
if _lIl1l1l < _l111l1l.Count() then
_lIlIl1l = _l111l1l[_lIl1l1l]
if _lIlIl1l <> "" then
_l11Il1l = JU_ToBase(_lIl1l1l, _llIll1l)
_lllIl1l = _l1d_8bfd24("4b3c", 116, 35) + _l11Il1l + _l1d_8bfd24("7d76", 120, 89)
_ll1Il1l = CreateObject(_l1d_8bfd24("b4d49ad0d5d6cc", 208, 18), _lllIl1l, _l1d_8bfd24("15", 119, 5))
_llI1l1l = _ll1Il1l.replaceAll(_llI1l1l, _lIlIl1l)
end if
end if
_lIl1l1l = _lIl1l1l - 1
end while
return _llI1l1l
end function
function _l1d_8bfd24(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function