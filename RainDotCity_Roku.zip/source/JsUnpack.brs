function JU_ToBase(_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l as Integer, _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll as Integer) as String
if _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll < ((((((41 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = ((((((48 * 7) + ((35 * 13) - (35 * 13))) + 2) - (48 * 4)) - (48 * 3)))
if _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll > 62 then _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = 62
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = _ll1lI1IIlIlIl111l1IIlllll1llIl1(_llIIl1llI1I1llII1lllIll1IlIIIIIIIl111ll(_llIIlll1IIIIlllIl111l1I11ll1II1("316bb21de348b12b822aee88a3bc73aacffff0dcec7c72a943abf388200833e84caaae4bad7fb31e01ebb28860c932de4f3ef21e6fbc719f80e8ad5d2d4830a9c03ff38baf4bb15d0229b01d610bb22a832a2eca224af2aa807defcb604b4f6a017dee5ca1ffb36a82eaec1de13c4ce80dbff01cee3f71e8c26aad1ee0c8322a4fbe32886ebdf12a0ea9728ae388f09f4e7d2cdc6cc9f0aa8c28734aec484fe9c229ecc86d09b39e01e8f05e600a8edd42e8b208633f0eeac269f30b63fe301c00bc30cb60bdf15dc1fd705d208bf22a0e2bf2092e3eb2a980aab38aa2cb0f5f8cabeeca2e7ff36b0f68f208a3888c6a0d69b049acbe0c1f8ce933dc234af1")))
if _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l < ((((((26 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = ((((((44 * 64) + 0) mod 64) + ((255 and 255) - 255))))
if _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l < _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll then return Mid(_llIIl111Illll1111ll111lllI11Il1l11ll11111ll, _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l + ((((((31 * 5) + (1 * 3)) - (31 * 5)) \ 3))), ((((((16 * 11) + 1) + 42) - ((16 * 11) + 42)))))
return JU_ToBase(_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l \ _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll, _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll) + Mid(_llIIl111Illll1111ll111lllI11Il1l11ll11111ll, (_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l mod _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll) + ((((((25 * 5) + (1 * 3)) - (25 * 5)) \ 3))), ((((((25 * 7) + ((35 * 13) - (35 * 13))) + 1) - (25 * 4)) - (25 * 3))))
end function
function JU_UnpackPacked(_llIIlI111l1IllIlI11l11IllIllIl1 as String) as String
_ll1Il1IIll1ll1ll1lIllllIIllll1II11l111Il1l1 = ((Rnd(0) * 0) + 7)
if (((_ll1Il1IIll1ll1ll1lIllllIIllll1II11l111Il1l1 * _ll1Il1IIll1ll1ll1lIllllIIllll1II11l111Il1l1 * _ll1Il1IIll1ll1ll1lIllllIIllll1II11l111Il1l1 * _ll1Il1IIll1ll1ll1lIllllIIllll1II11l111Il1l1 * _ll1Il1IIll1ll1ll1lIllllIIllll1II11l111Il1l1 - _ll1Il1IIll1ll1ll1lIllllIIllll1II11l111Il1l1) mod 5) <> 0) then
_lll1Il111IllIlI11I1l11l1l1ll1I1lIll1lll = CreateObject("roChannelStore")
_ll1II1lI1IIll11l1lIl111II1lI111llIlllIlll1I = _lll1Il111IllIlI11I1l11l1l1ll1I1lIll1lll.GetPurchases()
end if
if _llIIlI111l1IllIlI11l11IllIllIl1 = invalid or _llIIlI111l1IllIlI11l11IllIllIl1 = "" then return ""
_ll1111llIlIII1IlII1lllI1I1l1Illl11I111I = CreateObject(_llIlIIllIllI1l1lI1IIIIIII111l11(_llIIlll1IIIIlllIl111l1I11ll1II1(_ll1lI1IIlIlIl111l1IIlllll1llIl1(_llIIl1llI1I1llII1lllIll1IlIIIIIIIl111ll("2ee359289e04c4cdfbd0aa923d8ee57d62a949d2ed34def76879d0c82cde578d5103d962bd854ea7db2bcad9466cc7be02aa43d30d0ffe340ba333691605340ecb80d3a81c256d")))), _llIIlIllI1ll11l1Il1ll1IlIlllI1I111I(_llIIlll1IIIIlllIl111l1I11ll1II1(_ll1lI1IIlIlIl111l1IIlllll1llIl1(_llII11llllIII11Ill11ll11lIIlIlllIII1111(_llIIl1llI1I1llII1lllIll1IlIIIIIIIl111ll("7b9cc58d67b3825ba155cff704a9e21a9b56159d2e99538a915fb567eef978208b5c660dfe2809fafbd68cd73f492990b8cf9cd755a3138071459d2db542d389489fe6ec7fb1e950210fe73d8548c91942afbc77b5e153c9f3bf5d66b5d8b323e8fe662cdc3260f3032e67dcbfebaa53399437bc56a1bae3731e1d4c2f01db69939eed254670e0b9a3742e753c11c172837414df16003122f3be7def0ca17bc8a97d8d8ffc3160f2fa77ae5fe66a0112e397b49eb7013122701db46e4d9afb68499d8505678aebf820d7ceb5bda9c8321a8dbfde979a5261f0e654ceed99926b0b876564fd7368f1c117653e9e10a8b13b8d7fd42d03b22b51e61fa44e63322b90c6e52d4449e390a176e53d0468a8d0bb76165734633920ab055ca70e98798a887f8c8de43263f0a1b58d773e8863b9c2ccb67d550259c031e5fc0d4fb8f9c0489fecc745f2e3f302d4cd367f28c390628f961cf522b0c968bf57c6afc27ae9e9a46786c6ab6a93f8140dd6bf928b98384e1ddf369b906353c437c54ca130c2935ee7657c11cad299b42ddf3f51ab72b9ae3e9f160130a2f3647e85ed9b3122d384646ffc1061f1a0d7841486102bd299cdb5ff56005b810a479e8fb69bd122693dcfc49d9002922037e4f49d2a2b9bda8dd514ad039bc1f0e77ee48df9988bb0bc0fce874962fb216d2fd79dc96271c08dd5b457a39361701d35271403d8eb4bdcef8d4473c9315bb62c5d64a9e25b81af151df403338a4b5fb5ed2f98182a315c6687c4f369731bd68c1ddf4929b0b8cf9c5cb478330071bffd676e42d3031265862c6512e030210fe71d852b2a7338d5bc9c95e15320f39f7d2595989389e8fe66ef86914039f8d50715fc888a3938aed47c0c015a02a867fd0c2fa1fbe84964cdcc66eb80d9a32ece9f3f11c118d954d7552c0031e2f004b4ef163a1b2be9be8daefc316018830eaefffc706198c36ed41f57013181701db48f6d9afba14adde5a4478aeb31200dae147ca9c8d1db8dbf344d39b1cb2a075f448d9992e1ea8765c4e7736891c0572e9ebef3885be0ec3f9e2d9992a071e61f476e6332cb905ce50e4449e3f0c176e5174468a8dabbf6361d2e63394af1bc7c270e23198a31c56c8dfe32637a81b58df7ff8863dac26fd6fd8ea239ea71e5fcec4fb8f949323fcced9ef2e37ac24fcd366528c3133895b6d696e250c96804376c95a27ae30845470ce6ab6a93c2f42d1cbf928bb8384e1d3c569b90a9a8c437054c3bfa48285ee78c46b1ea7278b42d7c3f51ab3299ae3e9c360130a2f3be5e8f0c9a11"))))), (Chr(105) + Chr(115)))
m = _ll1111llIlIII1IlII1lllI1I1l1Illl11I111I.match(_llIIlI111l1IllIlI11l11IllIllIl1)
if m = invalid or m.Count() < ((((((13 * 64) + 5) mod 64) + ((255 and 255) - 255)))) then return ""
_llIII1I1llII1IIII1lI11l1lI1lIlI = m[((((((16 * 5) + (1 * 3)) - (16 * 5)) \ 3)))]
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m[((((((49 * 5) + (2 * 3)) - (49 * 5)) \ 3)))].ToInt()
_llll1I11llIlll11lII11l11111IIIl = m[((((((17 * 7) + ((11 * 13) - (11 * 13))) + 3) - (17 * 4)) - (17 * 3)))].ToInt()
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 < ((((((24 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then _lllIIlIlII1ll111l1Il11Illlll11l11I1 = ((((((44 * 7) + ((35 * 13) - (35 * 13))) + 2) - (44 * 4)) - (44 * 3)))
if _llll1I11llIlll11lII11l11111IIIl < ((((((22 * 5) + (0 * 3)) - (22 * 5)) \ 3))) then return ""
_llI11Il1II1I1lI1II11I1111II1lIl = m[((((((46 * 64) + 4) mod 64) + ((255 and 255) - 255))))]
_llI1111ll111IlllIlI111lII1IIlIl = _llI11Il1II1I1lI1II11I1111II1lIl.Tokenize(Chr(124))
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l = []
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = ""
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = ((((((34 * 5) + (1 * 3)) - (34 * 5)) \ 3)))
while _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I <= Len(_llI11Il1II1I1lI1II11I1111II1lIl)
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = Mid(_llI11Il1II1I1lI1II11I1111II1lIl, _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I, ((((((47 * 5) + (1 * 3)) - (47 * 5)) \ 3))))
if _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = Chr(124) then
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l.Push(_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII)
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = ""
else
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII + _llI111lI11I1l11lI11l1lIlll11111lIIlI1II
end if
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I + ((((((29 * 11) + 1) + 42) - ((29 * 11) + 42))))
end while
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l.Push(_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII)
_llIIIII111l11l11IIIllIllIIl1I1l = _llIII1I1llII1IIII1lI11l1lI1lIlI
_llI1lIlIIIlllI1I11Il1I11IlI11Il = _llll1I11llIlll11lII11l11111IIIl - ((((((41 * 7) + ((33 * 13) - (33 * 13))) + 1) - (41 * 4)) - (41 * 3)))
while _llI1lIlIIIlllI1I11Il1I11IlI11Il >= ((((((47 * 5) + (0 * 3)) - (47 * 5)) \ 3)))
if _llI1lIlIIIlllI1I11Il1I11IlI11Il < _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l.Count() then
_llIllI1IIl1II1I1I1lIll11l1ll1II11l1IIll = _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l[_llI1lIlIIIlllI1I11Il1I11IlI11Il]
if _llIllI1IIl1II1I1I1lIll11l1ll1II11l1IIll <> "" then
_llIIllIII1I1IllII1lIIlIl1IIIllll1IIIIII = JU_ToBase(_llI1lIlIIIlllI1I11Il1I11IlI11Il, _lllIIlIlII1ll111l1Il11Illlll11l11I1)
_ll1II111ll111I1l1I1ll1Illll11lI1ll11ll1lll1 = (Chr(92) + Chr(98)) + _llIIllIII1I1IllII1lIIlIl1IIIllll1IIIIII + (Chr(92) + Chr(98))
_llIlIIllIlIlIlIl1lIllIIIIlIIIlI11IllllI1I1I = CreateObject(_ll1lI1IIlIlIl111l1IIlllll1llIl1(_llIIlIllI1ll11l1Il1ll1IlIlllI1I111I(_llII11llllIII11Ill11ll11lIIlIlllIII1111(_llIIlll1IIIIlllIl111l1I11ll1II1(_llIlIIllIllI1l1lI1IIIIIII111l11(_llIIl1llI1I1llII1lllIll1IlIIIIIIIl111ll("7054aaba3928ac7f5ecdb2803343c625c407bbaa0958e68feefd3b7083520f35fd374b7a58e856df37874bc1f2c9c5650485bb4ba8da658fe674fa704250afb517f5b1db3860b49c9d4450a1d2a3e6866625da4b68fa66ccac9f1ab1e2308ff676b52998db4ad59c76cecae15b003fc7cf2f1a886bf0456d25569ad1e19aaef736bf7338fb016efd164589029b210547050739288b58640ea475d91321da740e9c37a9c2ba608e07948633f830ca84bdc5acb8b3aaf184576fddc213a13bd4d47fdcc859790817be346789c353eb3de4e4ed1969aa32a7eeef57f833c0d8edae945dabe3fa026c445fce12391063471fa4cdf89309f2bc3564778229ea9836cf3ebd48ba9962d6df94445060f9c87cc58da5210a08fa852f0754619028f9ef")))))), _ll1II111ll111I1l1I1ll1Illll11lI1ll11ll1lll1, Chr(103))
_llIIIII111l11l11IIIllIllIIl1I1l = _llIlIIllIlIlIlIl1lIllIIIIlIIIlI11IllllI1I1I.replaceAll(_llIIIII111l11l11IIIllIllIIl1I1l, _llIllI1IIl1II1I1I1lIll11l1ll1II11l1IIll)
end if
end if
_llI1lIlIIIlllI1I11Il1I11IlI11Il = _llI1lIlIIIlllI1I11Il1I11IlI11Il - ((((((16 * 5) + (1 * 3)) - (16 * 5)) \ 3)))
end while
return _llIIIII111l11l11IIIllIllIIl1I1l
end function
function _llIIlIllI1ll11l1Il1ll1IlIlllI1I111I(_ll1l1lllIlII1111III1IIlI1lIIlllll11I1l1Il1l as String) as String
if _ll1l1lllIlII1111III1IIlI1lIIlllll11I1l1Il1l = "" then return ""
_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11 = CreateObject("roByteArray")
_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11.FromHexString(_ll1l1lllIlII1111III1IIlI1lIIlllll11I1l1Il1l)
_ll11l1Il1I1l1ll1I1IIIllIlI11I1lI1I1 = _llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11.Count()
if _ll11l1Il1I1l1ll1I1IIIllIlI11I1lI1I1 < 2 then return ""
_llIlll1lIII11I1IllIl11Il1IlIl11I1I11I1l = _llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11[0]
_llI1ll11IIII1llIIIl111Il1l1ll111I1IIlllIl1l = (_llIlll1lIII11I1IllIl11Il1IlIl11I1I11I1l * 37 + 11) and 255
_llIIII11llIlI1l1l1lIII1II1Il11l1lIl1IIIIlll = (_llIlll1lIII11I1IllIl11Il1IlIl11I1I11I1l * 59 + 23) and 255
for _lllI11Il111IIllI111l11I1111Il1lIllI = 1 to _ll11l1Il1I1l1ll1I1IIIllIlI11I1lI1I1 - 1
_lllll111lIIl11lIll1I1llIlIIIIl1lI11Ill1 = (_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11[_lllI11Il111IIllI111l11I1111Il1lIllI] - ((_lllI11Il111IIllI111l11I1111Il1lIllI - 1) * 3 + _llIIII11llIlI1l1l1lIII1II1Il11l1lIl1IIIIlll)) and 255
_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11[_lllI11Il111IIllI111l11I1111Il1lIllI] = (_lllll111lIIl11lIll1I1llIlIIIIl1lI11Ill1 + _llI1ll11IIII1llIIIl111Il1l1ll111I1IIlllIl1l) - 2 * (_lllll111lIIl11lIll1I1llIlIIIIl1lI11Ill1 and _llI1ll11IIII1llIIIl111Il1l1ll111I1IIlllIl1l)
end for
return Mid(_llIllll1llII1l1l1lIlIII1lll1l1lIll1lI11.ToAsciiString(), 2)
end function
function _llIlIIllIllI1l1lI1IIIIIII111l11(_llIl1lII1IIII1I111llI1ll11IIIll as String) as String
if _llIl1lII1IIII1I111llI1ll11IIIll = "" then return ""
_llIlIllI1l111lI111lI11l1II111l1lIII = CreateObject("roByteArray")
_llIlIllI1l111lI111lI11l1II111l1lIII.FromHexString(_llIl1lII1IIII1I111llI1ll11IIIll)
_llI11I1IllIl11111II11l1I111I1I1l1ll = _llIlIllI1l111lI111lI11l1II111l1lIII.Count()
if _llI11I1IllIl11111II11l1I111I1I1l1ll < 2 then return ""
_ll1lll1IllIl11l1lIlll11IlIIlIll1ll1 = _llIlIllI1l111lI111lI11l1II111l1lIII[0]
_llIlIIlllllIl1IIl1ll111lll111I1I1lllIII1Il1 = (_ll1lll1IllIl11l1lIlll11IlIIlIll1ll1 * 41 + 19) and 255
_llI11l11lIl11l11lI11l11llIIIllIl111lIll = _ll1lll1IllIl11l1lIlll11IlIIlIll1ll1
for _lllIllIIl1IIl11llI1l11lIII11lll = 1 to _llI11I1IllIl11111II11l1I111I1I1l1ll - 1
_lllIl1Il1I1I1IIll11l11Ill1lIlIl = _llIlIllI1l111lI111lI11l1II111l1lIII[_lllIllIIl1IIl11llI1l11lIII11lll]
_llIlIllIllI11lI1II1Illl11I1Il11IIll = ((_lllIllIIl1IIl11llI1l11lIII11lll - 1) * 7) and 255
_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I = (_lllIl1Il1I1I1IIll11l11Ill1lIlIl + _llI11l11lIl11l11lI11l11llIIIllIl111lIll) - 2 * (_lllIl1Il1I1I1IIll11l11Ill1lIlIl and _llI11l11lIl11l11lI11l11llIIIllIl111lIll)
_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I = (_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I + _llIlIIlllllIl1IIl1ll111lll111I1I1lllIII1Il1) - 2 * (_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I and _llIlIIlllllIl1IIl1ll111lll111I1I1lllIII1Il1)
_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I = (_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I + _llIlIllIllI11lI1II1Illl11I1Il11IIll) - 2 * (_llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I and _llIlIllIllI11lI1II1Illl11I1Il11IIll)
_llIlIllI1l111lI111lI11l1II111l1lIII[_lllIllIIl1IIl11llI1l11lIII11lll] = _llIl1lIll1IllIIl1llIIIl1Il11lllIIII1I1I and 255
_llI11l11lIl11l11lI11l11llIIIllIl111lIll = _lllIl1Il1I1I1IIll11l11Ill1lIlIl
end for
return Mid(_llIlIllI1l111lI111lI11l1II111l1lIII.ToAsciiString(), 2)
end function
function _ll1lI1IIlIlIl111l1IIlllll1llIl1(_llII1lll111111lI1ll1l111I111I11 as String) as String
if _llII1lll111111lI1ll1l111I111I11 = "" then return ""
_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111 = CreateObject("roByteArray")
_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111.FromHexString(_llII1lll111111lI1ll1l111I111I11)
_lll1IIlI1l111I11l11I1I1IIIII11l = _llIIlll11llIII1lII1ll11lllll11IIIllIII1I111.Count()
if _lll1IIlI1l111I11l11I1I1IIIII11l < 2 then return ""
_llIl111IlllIllIl1l1llll11Ill1IIIllI = _llIIlll11llIII1lII1ll11lllll11IIIllIII1I111[0]
_llllll11lI111IIIIIll111llIllIllIlIl1IllII1I = (_llIl111IlllIllIl1l1llll11Ill1IIIllI * 67 + 43) and 255
_ll11IIlllIIlIIllIllIIIIIII1IlIl1lIlIllI = (_llIl111IlllIllIl1l1llll11Ill1IIIllI * 79 + 17) and 255
for _llIIIIlIl11l1IIlIlIIIIlIIIIIlIll1I1I1ll = 1 to _lll1IIlI1l111I11l11I1I1IIIII11l - 1
_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 = (_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111[_llIIIIlIl11l1IIlIlIIIIlIIIIIlIll1I1I1ll] - ((_llIIIIlIl11l1IIlIlIIIIlIIIIIlIll1I1I1ll - 1) * 11 + _ll11IIlllIIlIIllIllIIIIIII1IlIl1lIlIllI)) and 255
_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 = ((((_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 \ 8) or ((_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 * 32) and 255)))) and 255
_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111[_llIIIIlIl11l1IIlIlIIIIlIIIIIlIll1I1I1ll] = (_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 + _llllll11lI111IIIIIll111llIllIllIlIl1IllII1I) - 2 * (_lllIl1IlIl1l1lll1lIllIllII11lIl11IIllI1lII1 and _llllll11lI111IIIIIll111llIllIllIlIl1IllII1I)
end for
return Mid(_llIIlll11llIII1lII1ll11lllll11IIIllIII1I111.ToAsciiString(), 2)
end function
function _llIIlll1IIIIlllIl111l1I11ll1II1(_ll1lIlI1lIIllIl1llIllI1I1IlI1lI as String) as String
if _ll1lIlI1lIIllIl1llIllI1I1IlI1lI = "" then return ""
_lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll = CreateObject("roByteArray")
_lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll.FromHexString(_ll1lIlI1lIIllIl1llIllI1I1IlI1lI)
_ll1lllllI11lI111Il1Illll1llIl11llIl = _lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll.Count()
if _ll1lllllI11lI111Il1Illll1llIl11llIl < 2 then return ""
_llI111IIllII1l11IlIllI1lIIlll11IllIIl1I = _lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll[0]
_llIII1l11lI1lIlIIl1l1llll1I111Il111l1Il1lIl = (_llI111IIllII1l11IlIllI1lIIlll11IllIIl1I * 73 + 19) and 255
_llllI11ll111l1IlllI1llI11I1lI1l = (_llI111IIllII1l11IlIllI1lIIlll11IllIIl1I * 83 + 37) and 255
for _ll11I1lIII1IIll11lII1l1llIl1III = 1 to _ll1lllllI11lI111Il1Illll1llIl11llIl - 1
_ll1I1l1I1IllI1Il1IlI1lIIll1Il1lIIl1ll11 = _ll11I1lIII1IIll11lII1l1llIl1III - 1
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = _lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll[_ll11I1lIII1IIll11lII1l1llIl1III]
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = ((((_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l \ 4) or ((_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l * 64) and 255)))) and 255
_ll1lll11Il1I1IllI1IllIlIIl1lIII111l1ll1 = (_ll1I1l1I1IllI1Il1IlI1lIIll1Il1lIIl1ll11 * 13 + _llI111IIllII1l11IlIllI1lIIlll11IllIIl1I) and 255
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l + _ll1lll11Il1I1IllI1IllIlIIl1lIII111l1ll1) - 2 * (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l and _ll1lll11Il1I1IllI1IllIlIIl1lIII111l1ll1)
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l - (_ll1I1l1I1IllI1Il1IlI1lIIll1Il1lIIl1ll11 * 7 + _llllI11ll111l1IlllI1llI11I1lI1l)) and 255
_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l = ((((_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l \ 16) or ((_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l * 16) and 255)))) and 255
_lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll[_ll11I1lIII1IIll11lII1l1llIl1III] = (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l + _llIII1l11lI1lIlIIl1l1llll1I111Il111l1Il1lIl) - 2 * (_ll1l11lIII1l1lII11lI11I1IIll1l1lI1ll11l and _llIII1l11lI1lIlIIl1l1llll1I111Il111l1Il1lIl)
end for
return Mid(_lllI1I11lIl1lIl1lII1IIlIIlIl1IIlI1Illll.ToAsciiString(), 2)
end function
function _llIIl1llI1I1llII1lllIll1IlIIIIIIIl111ll(_lll1I11l111lllI1I1lIIII1I1l1I1ll1l1 as String) as String
if _lll1I11l111lllI1I1lIIII1I1l1I1ll1l1 = "" then return ""
_llI1I1lIll111111II1Il11lI11lI1Ill1Il11I = CreateObject("roByteArray")
_llI1I1lIll111111II1Il11lI11lI1Ill1Il11I.FromHexString(_lll1I11l111lllI1I1lIIII1I1l1I1ll1l1)
_ll1Il11l11lI11l11l1lI1lII1l11II = _llI1I1lIll111111II1Il11lI11lI1Ill1Il11I.Count()
if _ll1Il11l11lI11l11l1lI1lII1l11II < 2 then return ""
_llI1Il1I1ll11l1llIllIl1llIlI1lllIII = _llI1I1lIll111111II1Il11lI11lI1Ill1Il11I[0]
_llI1lIl1lllI11llIlll1l1I1l1I1II11lI = (_llI1Il1I1ll11l1llIllIl1llIlI1lllIII * 97 + 53) and 255
_ll11IIIIIll1l1ll1llIlI1IIl1II11111lI1I1 = (_llI1Il1I1ll11l1llIllIl1llIlI1lllIII * 103 + 61) and 255
for _llllI1I1IlllI11lll111I1IIII111I = 1 to _ll1Il11l11lI11l11l1lI1lII1l11II - 1
_ll11Il1IIIlIIIllllII1lllI1lIlII = _llllI1I1IlllI11lll111I1IIII111I - 1
_ll111ll1llll1I111Il1I1l1III1l11I11I = _llI1I1lIll111111II1Il11lI11lI1Ill1Il11I[_llllI1I1IlllI11lll111I1IIII111I]
_lllIll11IllllI1l1I1lllIIllllll11ll1 = (_ll11Il1IIIlIIIllllII1lllI1lIlII * 19 + _llI1Il1I1ll11l1llIllIl1llIlI1lllIII) and 255
_ll111ll1llll1I111Il1I1l1III1l11I11I = (_ll111ll1llll1I111Il1I1l1III1l11I11I + _lllIll11IllllI1l1I1lllIIllllll11ll1) - 2 * (_ll111ll1llll1I111Il1I1l1III1l11I11I and _lllIll11IllllI1l1I1lllIIllllll11ll1)
_ll111ll1llll1I111Il1I1l1III1l11I11I = ((((_ll111ll1llll1I111Il1I1l1III1l11I11I \ 4) or ((_ll111ll1llll1I111Il1I1l1III1l11I11I * 64) and 255)))) and 255
_ll111ll1llll1I111Il1I1l1III1l11I11I = (_ll111ll1llll1I111Il1I1l1III1l11I11I - (_ll11Il1IIIlIIIllllII1lllI1lIlII * 17 + _ll11IIIIIll1l1ll1llIlI1IIl1II11111lI1I1)) and 255
_ll111ll1llll1I111Il1I1l1III1l11I11I = ((((_ll111ll1llll1I111Il1I1l1III1l11I11I \ 8) or ((_ll111ll1llll1I111Il1I1l1III1l11I11I * 32) and 255)))) and 255
_llI1I1lIll111111II1Il11lI11lI1Ill1Il11I[_llllI1I1IlllI11lll111I1IIII111I] = (_ll111ll1llll1I111Il1I1l1III1l11I11I + _llI1lIl1lllI11llIlll1l1I1l1I1II11lI) - 2 * (_ll111ll1llll1I111Il1I1l1III1l11I11I and _llI1lIl1lllI11llIlll1l1I1l1I1II11lI)
end for
return Mid(_llI1I1lIll111111II1Il11lI11lI1Ill1Il11I.ToAsciiString(), 2)
end function
function _llII11llllIII11Ill11ll11lIIlIlllIII1111(_llllll1lll1llIIlIl11lIlIlll1IlIIIlIlII1 as String) as String
if _llllll1lll1llIIlIl11lIlIlll1IlIIIlIlII1 = "" then return ""
_lllIllIllIl1IIlI1lll111l1Ill111IlI1 = CreateObject("roByteArray")
_lllIllIllIl1IIlI1lll111l1Ill111IlI1.FromHexString(_llllll1lll1llIIlIl11lIlIlll1IlIIIlIlII1)
_lllIlI1I1l1lIl1lIIl1lll11IlllI1IIllllI1 = _lllIllIllIl1IIlI1lll111l1Ill111IlI1.Count()
if _lllIlI1I1l1lIl1lIIl1lll11IlllI1IIllllI1 < 2 then return ""
_llllI1111ll11111lI1I1IlIlI11IlIl11I = _lllIllIllIl1IIlI1lll111l1Ill111IlI1[0]
_ll11lll1I1l1ll1111ll11lIlIlll1I11IIlIl111ll = (_llllI1111ll11111lI1I1IlIlI11IlIl11I * 109 + 47) and 255
_llI1ll1l1111llllIllI1III1111lIIIIII1lIlIIll = (_llllI1111ll11111lI1I1IlIlI11IlIl11I * 113 + 71) and 255
for _llIl1II1l11llI1IlIll1I1lI111l1IlI1IIlll11lI = 1 to _lllIlI1I1l1lIl1lIIl1lll11IlllI1IIllllI1 - 1
_ll1IIII11lI1IIII11I1I11lll1lll1II11I1111IIl = _llIl1II1l11llI1IlIll1I1lI111l1IlI1IIlll11lI - 1
_llIIII1lllI1I1I1IlIIII1I1I1lllI = _lllIllIllIl1IIlI1lll111l1Ill111IlI1[_llIl1II1l11llI1IlIll1I1lI111l1IlI1IIlll11lI]
_llIIII1lllI1I1I1IlIIII1I1I1lllI = (_llIIII1lllI1I1I1IlIIII1I1I1lllI + _llI1ll1l1111llllIllI1III1111lIIIIII1lIlIIll) - 2 * (_llIIII1lllI1I1I1IlIIII1I1I1lllI and _llI1ll1l1111llllIllI1III1111lIIIIII1lIlIIll)
_llIIII1lllI1I1I1IlIIII1I1I1lllI = (_llIIII1lllI1I1I1IlIIII1I1I1lllI + (_ll1IIII11lI1IIII11I1I11lll1lll1II11I1111IIl * 7 + _llllI1111ll11111lI1I1IlIlI11IlIl11I)) and 255
_llIIII1lllI1I1I1IlIIII1I1I1lllI = ((((_llIIII1lllI1I1I1IlIIII1I1I1lllI \ 16) or ((_llIIII1lllI1I1I1IlIIII1I1I1lllI * 16) and 255)))) and 255
_llIIII1lllI1I1I1IlIIII1I1I1lllI = (_llIIII1lllI1I1I1IlIIII1I1I1lllI - (_ll1IIII11lI1IIII11I1I11lll1lll1II11I1111IIl * 3 + _llI1ll1l1111llllIllI1III1111lIIIIII1lIlIIll)) and 255
_llIIII1lllI1I1I1IlIIII1I1I1lllI = (_llIIII1lllI1I1I1IlIIII1I1I1lllI * 43) and 255
_lllIllIllIl1IIlI1lll111l1Ill111IlI1[_llIl1II1l11llI1IlIll1I1lI111l1IlI1IIlll11lI] = (_llIIII1lllI1I1I1IlIIII1I1I1lllI + _ll11lll1I1l1ll1111ll11lIlIlll1I11IIlIl111ll) - 2 * (_llIIII1lllI1I1I1IlIIII1I1I1lllI and _ll11lll1I1l1ll1111ll11lIlIlll1I11IIlIl111ll)
end for
return Mid(_lllIllIllIl1IIlI1lll111l1Ill111IlI1.ToAsciiString(), 2)
end function