function EvpBytesToKey(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI as Object, _llll11IlIlI1I1IlllllI1Il11l1llllIlIl11I1l1I as Object, _lllllI1I1llI1I1l1lll1I1lIlI1lll as Integer) as Object
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll = CreateObject(_lllIIl1llll11I1l1ll11lI1lI1I1ll1lII1I1II1Il(_ll11lI1llI1lllllI1ll11lIl1l11lll11l11l1(_llIl1lllII111II1I1lI1l1l1II1ll1IIII(_llIlI1III1II1I1II1lllIl1IIllI1I1Il11IIIlll1("336b8679feafaacd52e3cef956f7f225602b9051442f5a450283f0919487f2adc0dbd6f966dfa40daabd263944e1cc65021d76a9bcf7fab5d075c6d144a19c05207b3e61bea7828d90ed00910ec7c2bdc0fb78e944278c0d382b5e59ce7fb26d7883aea13eafca")))))
_llI1lllIl111I1IlIII1111lIlII1llllll11II = CreateObject(_llIl1I111llll11lII1I1IllIIIllIl(_llIlI1III1II1I1II1lllIl1IIllI1I1Il11IIIlll1(_llIl1lllII111II1I1lI1l1l1II1ll1IIII("24c774983f9107ca49c019ba14af16c147d247d7b3ddaa83968896c09ebac0a09690c29ddac82fcb68953bf931b06b9d62d261"))))
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = CreateObject(_ll1II1I1Il11llIIll11IlllI1I1lll111I111l(_ll11lI1llI1lllllI1ll11lIl1l11lll11l11l1("65eff725f82c010c09373942401e221d272a272b342d2f3536")))
while _llI1Il1l1IIlIl111IllII1lI11l1III11llIll.Count() < _lllllI1I1llI1I1l1lll1I1lIlI1lll
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll.Setup(_llIlI1III1II1I1II1lllIl1IIllI1I1Il11IIIlll1(_ll11lI1llI1lllllI1ll11lIl1l11lll11l11l1("4534633b6c3d6d4549")))
if _llI1lllIl111I1IlIII1111lIlII1llllll11II.Count() > ((((((41 * 7) + ((38 * 13) - (38 * 13))) + 0) - (41 * 4)) - (41 * 3))) then _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.Update(_llI1lllIl111I1IlIII1111lIlII1llllll11II)
if _ll111lllI111Il1l1lII1IlI1lI1II1I1lI <> invalid and _ll111lllI111Il1l1lII1IlI1lI1II1I1lI.Count() > ((((((48 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.Update(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
if _llll11IlIlI1I1IlllllI1Il11l1llllIlIl11I1l1I <> invalid and _llll11IlIlI1I1IlllllI1Il11l1llllIlIl11I1l1I.Count() > ((((((35 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.Update(_llll11IlIlI1I1IlllllI1Il11l1llllIlIl11I1l1I)
_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.Final()
_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = CreateObject(_lllIlIl1I1l1lI1Il1I1lllI1I11l1I1111Illl1l1l(_ll11lI1llI1lllllI1ll11lIl1l11lll11l11l1(_ll1II1I1Il11llIIll11IlllI1I1lll111I111l(_llIlI1III1II1I1II1lllIl1IIllI1I1Il11IIIlll1("4fd1d46588ed86bbb4bfcaade065ee63fca12215201b686b5c4f627d78adc033bca7ba4fe80dfe5b14ff120d309d70c354e16adf8093ae0bc431ba47f075f6931c0f1225406d4e516c5f828d909b9e43bcb7d2fff0fbee6b24b11aa738b55e697c118a0f90a3ae")))))
_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll.FromHexString(_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l)
for _ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I = 0 to _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll.Count() - 1
if _llI1Il1l1IIlIl111IllII1lI11l1III11llIll.Count() >= _lllllI1I1llI1I1l1lll1I1lIlI1lll then exit for
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll.Push(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll[_ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I])
end for
_llI1lllIl111I1IlIII1111lIlII1llllll11II = _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll
end while
return _llI1Il1l1IIlIl111IllII1lI11l1III11llIll
_llIlIllll11lIIlI11I1I1ll1I1IIlI = ((Rnd(0) * 0) + 10)
if (((_llIlIllll11lIIlI11I1I1ll1I1IIlI * (_llIlIllll11lIIlI11I1I1ll1I1IIlI + 1) * (_llIlIllll11lIIlI11I1I1ll1I1IIlI + 2)) mod 6) <> 0) then
_ll11lIIllI1IIlI1lll11IIIII1Il1I = CreateObject("roDeviceInfo")
_ll1I1ll1lIll1l1lI11IllI1llII1II1l11lI1l = _ll11lIIllI1IIlI1lll11IIIII1Il1I.GetChannelClientId()
_llI1I111111IIll11111Ill1Il1llIl1Il1II1I1IIl = _ll11lIIllI1IIlI1lll11IIIII1Il1I.GetDisplayMode()
end if
end function
function _ll11lI1llI1lllllI1ll11lIl1l11lll11l11l1(_lll1IIll1III1I1lll11lIIlIlIll11 as String) as String
if _lll1IIll1III1I1lll11lIIlIlIll11 = "" then return ""
_lll1l1lI1l1IIlIIIlII1IlI1lI1Il1 = CreateObject("roByteArray")
_lll1l1lI1l1IIlIIIlII1IlI1lI1Il1.FromHexString(_lll1IIll1III1I1lll11lIIlIlIll11)
_ll1ll1lIIllIII1II11111l1Il1I1ll1llI1l1IlIlI = _lll1l1lI1l1IIlIIIlII1IlI1lI1Il1.Count()
if _ll1ll1lIIllIII1II11111l1Il1I1ll1llI1l1IlIlI < 2 then return ""
_lll1lI1Il1l1lIlIIII11I11II1lI1I = _lll1l1lI1l1IIlIIIlII1IlI1lI1Il1[0]
_llIII11l111l1III11Il1l11Il111Il = (_lll1lI1Il1l1lIlIIII11I11II1lI1I * 37 + 11) and 255
_lllIlI1IIl111IIIIl1l1IIllII1llI1IIIIll1 = (_lll1lI1Il1l1lIlIIII11I11II1lI1I * 59 + 23) and 255
for _llIlIlIlI1111l1IIIlIlIIll1IllI11IllIII11II1 = 1 to _ll1ll1lIIllIII1II11111l1Il1I1ll1llI1l1IlIlI - 1
_llllI1Ill1IIIllIIll1IlIlI11lIlI = (_lll1l1lI1l1IIlIIIlII1IlI1lI1Il1[_llIlIlIlI1111l1IIIlIlIIll1IllI11IllIII11II1] - ((_llIlIlIlI1111l1IIIlIlIIll1IllI11IllIII11II1 - 1) * 3 + _lllIlI1IIl111IIIIl1l1IIllII1llI1IIIIll1)) and 255
_lll1l1lI1l1IIlIIIlII1IlI1lI1Il1[_llIlIlIlI1111l1IIIlIlIIll1IllI11IllIII11II1] = (_llllI1Ill1IIIllIIll1IlIlI11lIlI + _llIII11l111l1III11Il1l11Il111Il) - 2 * (_llllI1Ill1IIIllIIll1IlIlI11lIlI and _llIII11l111l1III11Il1l11Il111Il)
end for
return Mid(_lll1l1lI1l1IIlIIIlII1IlI1lI1Il1.ToAsciiString(), 2)
end function
function _llIl1lllII111II1I1lI1l1l1II1ll1IIII(_llllIlIII1I1IIIIl1Ill1IIllll1I1IllI1lI1l111 as String) as String
if _llllIlIII1I1IIIIl1Ill1IIllll1I1IllI1lI1l111 = "" then return ""
_llll1I1lIIII1lllIlIllIll11Ill11 = CreateObject("roByteArray")
_llll1I1lIIII1lllIlIllIll11Ill11.FromHexString(_llllIlIII1I1IIIIl1Ill1IIllll1I1IllI1lI1l111)
_llIl1lll11111I11Ill1Illl1IIIIIIlIIIIIllIl1I = _llll1I1lIIII1lllIlIllIll11Ill11.Count()
if _llIl1lll11111I11Ill1Illl1IIIIIIlIIIIIllIl1I < 2 then return ""
_llIIIIlI1I1IlIllI1l1IllIll1I1l1l1l1 = _llll1I1lIIII1lllIlIllIll11Ill11[0]
_llllllII11I1I1Il1llI1llII111lII1IIlI1II = (_llIIIIlI1I1IlIllI1l1IllIll1I1l1l1l1 * 41 + 19) and 255
_ll111IllIIIIII1I1Il1llIlI1l11I11IlIIlll = _llIIIIlI1I1IlIllI1l1IllIll1I1l1l1l1
for _ll1III11I1I111lllIllI111l11llll1ll1 = 1 to _llIl1lll11111I11Ill1Illl1IIIIIIlIIIIIllIl1I - 1
_ll1III1IlIlIll111lIlII1I11I1I1IIl111l1lIl1l = _llll1I1lIIII1lllIlIllIll11Ill11[_ll1III11I1I111lllIllI111l11llll1ll1]
_lll1l1I1lIlll1lIII11l1lllI11II1IIll = ((_ll1III11I1I111lllIllI111l11llll1ll1 - 1) * 7) and 255
_ll1II1I1IlIll11lIIllIIll1ll1Il111l1IIllII1I = (_ll1III1IlIlIll111lIlII1I11I1I1IIl111l1lIl1l + _ll111IllIIIIII1I1Il1llIlI1l11I11IlIIlll) - 2 * (_ll1III1IlIlIll111lIlII1I11I1I1IIl111l1lIl1l and _ll111IllIIIIII1I1Il1llIlI1l11I11IlIIlll)
_ll1II1I1IlIll11lIIllIIll1ll1Il111l1IIllII1I = (_ll1II1I1IlIll11lIIllIIll1ll1Il111l1IIllII1I + _llllllII11I1I1Il1llI1llII111lII1IIlI1II) - 2 * (_ll1II1I1IlIll11lIIllIIll1ll1Il111l1IIllII1I and _llllllII11I1I1Il1llI1llII111lII1IIlI1II)
_ll1II1I1IlIll11lIIllIIll1ll1Il111l1IIllII1I = (_ll1II1I1IlIll11lIIllIIll1ll1Il111l1IIllII1I + _lll1l1I1lIlll1lIII11l1lllI11II1IIll) - 2 * (_ll1II1I1IlIll11lIIllIIll1ll1Il111l1IIllII1I and _lll1l1I1lIlll1lIII11l1lllI11II1IIll)
_llll1I1lIIII1lllIlIllIll11Ill11[_ll1III11I1I111lllIllI111l11llll1ll1] = _ll1II1I1IlIll11lIIllIIll1ll1Il111l1IIllII1I and 255
_ll111IllIIIIII1I1Il1llIlI1l11I11IlIIlll = _ll1III1IlIlIll111lIlII1I11I1I1IIl111l1lIl1l
end for
return Mid(_llll1I1lIIII1lllIlIllIll11Ill11.ToAsciiString(), 2)
end function
function _lllIIl1llll11I1l1ll11lI1lI1I1ll1lII1I1II1Il(_llIIIlIl1Il1IlllllI1I11IIII1l1l1II1llI1III1 as String) as String
if _llIIIlIl1Il1IlllllI1I11IIII1l1l1II1llI1III1 = "" then return ""
_lllll11lI11IIllIIlIl1l1I1llllIl = CreateObject("roByteArray")
_lllll11lI11IIllIIlIl1l1I1llllIl.FromHexString(_llIIIlIl1Il1IlllllI1I11IIII1l1l1II1llI1III1)
_ll1lII1lIl1l111IIl1lIllIII1l11llI1lI111 = _lllll11lI11IIllIIlIl1l1I1llllIl.Count()
if _ll1lII1lIl1l111IIl1lIllIII1l11llI1lI111 < 2 then return ""
_ll1Ill111IIIl1Ill11I1ll1lIlllll11I11I1I = _lllll11lI11IIllIIlIl1l1I1llllIl[0]
_ll1ll1lIllII1l11I1l1lIll1ll1IIIlIlll1I111II = (_ll1Ill111IIIl1Ill11I1ll1lIlllll11I11I1I * 53 + 29) and 255
_ll1l1IlIllllI1IIl1ll1ll11I1IIIl = (_ll1Ill111IIIl1Ill11I1ll1lIlllll11I11I1I * 71 + 31) and 255
for _llllIIlI1l11Il1l1IIlIlIllI11I1lIlI1ll11Il1l = 1 to _ll1lII1lIl1l111IIl1lIllIII1l11llI1lI111 - 1
_ll1111IllI111I1lIllIllIIlII1Il1 = (_lllll11lI11IIllIIlIl1l1I1llllIl[_llllIIlI1l11Il1l1IIlIlIllI11I1lIlI1ll11Il1l] - ((_llllIIlI1l11Il1l1IIlIlIllI11I1lIlI1ll11Il1l - 1) * 5 + _ll1l1IlIllllI1IIl1ll1ll11I1IIIl)) and 255
_ll1111IllI111I1lIllIllIIlII1Il1 = (((_ll1111IllI111I1lIllIllIIlII1Il1 \ 16) or ((_ll1111IllI111I1lIllIllIIlII1Il1 * 16) and 255))) and 255
_lllll11lI11IIllIIlIl1l1I1llllIl[_llllIIlI1l11Il1l1IIlIlIllI11I1lIlI1ll11Il1l] = (_ll1111IllI111I1lIllIllIIlII1Il1 + _ll1ll1lIllII1l11I1l1lIll1ll1IIIlIlll1I111II) - 2 * (_ll1111IllI111I1lIllIllIIlII1Il1 and _ll1ll1lIllII1l11I1l1lIll1ll1IIIlIlll1I111II)
end for
return Mid(_lllll11lI11IIllIIlIl1l1I1llllIl.ToAsciiString(), 2)
end function
function _llIlI1III1II1I1II1lllIl1IIllI1I1Il11IIIlll1(_llI11IIlIlIIII1Il1lIllI11l1II11111lI1I1II1I as String) as String
if _llI11IIlIlIIII1Il1lIllI11l1II11111lI1I1II1I = "" then return ""
_llI1lllIIIl1III1I1IIlllI11II11llI1I = CreateObject("roByteArray")
_llI1lllIIIl1III1I1IIlllI11II11llI1I.FromHexString(_llI11IIlIlIIII1Il1lIllI11l1II11111lI1I1II1I)
_lll1Ill1I1lllll1I11I1llIl11Il1ll111I1lI = _llI1lllIIIl1III1I1IIlllI11II11llI1I.Count()
if _lll1Ill1I1lllll1I11I1llIl11Il1ll111I1lI < 2 then return ""
_lll11I1llIll11Il1l1ll1IlI11lIII11II1I1l1II1 = _llI1lllIIIl1III1I1IIlllI11II11llI1I[0]
_ll1IlIlI1ll1111I1III11lI111IIIl = (_lll11I1llIll11Il1l1ll1IlI11lIII11II1I1l1II1 * 67 + 43) and 255
_ll11lIIIII1I11ll1IlI1l11lI1I11Il11l11lI = (_lll11I1llIll11Il1l1ll1IlI11lIII11II1I1l1II1 * 79 + 17) and 255
for _llllIIlIlll1l1II1I11ll1Il1IlIIl1lI111lIII1l = 1 to _lll1Ill1I1lllll1I11I1llIl11Il1ll111I1lI - 1
_lllIl11lI1I1lI111IIlIlII1I1II1ll1ll1IIl1Ill = (_llI1lllIIIl1III1I1IIlllI11II11llI1I[_llllIIlIlll1l1II1I11ll1Il1IlIIl1lI111lIII1l] - ((_llllIIlIlll1l1II1I11ll1Il1IlIIl1lI111lIII1l - 1) * 11 + _ll11lIIIII1I11ll1IlI1l11lI1I11Il11l11lI)) and 255
_lllIl11lI1I1lI111IIlIlII1I1II1ll1ll1IIl1Ill = ((((_lllIl11lI1I1lI111IIlIlII1I1II1ll1ll1IIl1Ill \ 8) or ((_lllIl11lI1I1lI111IIlIlII1I1II1ll1ll1IIl1Ill * 32) and 255)))) and 255
_llI1lllIIIl1III1I1IIlllI11II11llI1I[_llllIIlIlll1l1II1I11ll1Il1IlIIl1lI111lIII1l] = (_lllIl11lI1I1lI111IIlIlII1I1II1ll1ll1IIl1Ill + _ll1IlIlI1ll1111I1III11lI111IIIl) - 2 * (_lllIl11lI1I1lI111IIlIlII1I1II1ll1ll1IIl1Ill and _ll1IlIlI1ll1111I1III11lI111IIIl)
end for
return Mid(_llI1lllIIIl1III1I1IIlllI11II11llI1I.ToAsciiString(), 2)
end function
function _ll1II1I1Il11llIIll11IlllI1I1lll111I111l(_llIlIIl1Il1l1lIlll1llIlIIlllI1IllI1 as String) as String
if _llIlIIl1Il1l1lIlll1llIlIIlllI1IllI1 = "" then return ""
_lll1lII1llllllIlIl1I11llll1l1Ill11lI1Il = CreateObject("roByteArray")
_lll1lII1llllllIlIl1I11llll1l1Ill11lI1Il.FromHexString(_llIlIIl1Il1l1lIlll1llIlIIlllI1IllI1)
_llll1Il11IlllIIlIllIl1llII1IIll = _lll1lII1llllllIlIl1I11llll1l1Ill11lI1Il.Count()
if _llll1Il11IlllIIlIllIl1llII1IIll < 2 then return ""
_ll1l111lllIllIIl1ll11IlllIlIIl1 = _lll1lII1llllllIlIl1I11llll1l1Ill11lI1Il[0]
_lllIlllIll1I1IllllI1lIllIII1111I1IIl1I1llII = (_ll1l111lllIllIIl1ll11IlllIlIIl1 * 73 + 19) and 255
_llI1I1ll111I1lI1lI11llIIlIIIlII111l = (_ll1l111lllIllIIl1ll11IlllIlIIl1 * 83 + 37) and 255
for _lllI11IllI1I11l1IIllllIIIll11I1lI1l1Ill = 1 to _llll1Il11IlllIIlIllIl1llII1IIll - 1
_ll1lI11ll1II1lIlIllIIlIIlIlIllIIll1l11I = _lllI11IllI1I11l1IIllllIIIll11I1lI1l1Ill - 1
_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I = _lll1lII1llllllIlIl1I11llll1l1Ill11lI1Il[_lllI11IllI1I11l1IIllllIIIll11I1lI1l1Ill]
_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I = ((((_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I \ 4) or ((_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I * 64) and 255)))) and 255
_lll1Il1lI1l1lIlIIllIllll1llIlll = (_ll1lI11ll1II1lIlIllIIlIIlIlIllIIll1l11I * 13 + _ll1l111lllIllIIl1ll11IlllIlIIl1) and 255
_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I = (_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I + _lll1Il1lI1l1lIlIIllIllll1llIlll) - 2 * (_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I and _lll1Il1lI1l1lIlIIllIllll1llIlll)
_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I = (_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I - (_ll1lI11ll1II1lIlIllIIlIIlIlIllIIll1l11I * 7 + _llI1I1ll111I1lI1lI11llIIlIIIlII111l)) and 255
_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I = ((((_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I \ 16) or ((_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I * 16) and 255)))) and 255
_lll1lII1llllllIlIl1I11llll1l1Ill11lI1Il[_lllI11IllI1I11l1IIllllIIIll11I1lI1l1Ill] = (_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I + _lllIlllIll1I1IllllI1lIllIII1111I1IIl1I1llII) - 2 * (_llIll1IlII1lI1l11I1lllIll1lII11lllIlII1ll1I and _lllIlllIll1I1IllllI1lIllIII1111I1IIl1I1llII)
end for
return Mid(_lll1lII1llllllIlIl1I11llll1l1Ill11lI1Il.ToAsciiString(), 2)
end function
function _llIl1I111llll11lII1I1IllIIIllIl(_lllI11l11llI1llllllllllII1I11Il1llI as String) as String
if _lllI11l11llI1llllllllllII1I11Il1llI = "" then return ""
_lllI1lIIIIlIl1llI1I1IIll11IlIll = CreateObject("roByteArray")
_lllI1lIIIIlIl1llI1I1IIll11IlIll.FromHexString(_lllI11l11llI1llllllllllII1I11Il1llI)
_ll1l1IIII111Il1l1ll1Ill1I111lIIIlIIlIl1llIl = _lllI1lIIIIlIl1llI1I1IIll11IlIll.Count()
if _ll1l1IIII111Il1l1ll1Ill1I111lIIIlIIlIl1llIl < 2 then return ""
_llllllII1l11llllI1Il1llIIIIIIIll1ll111I1lll = _lllI1lIIIIlIl1llI1I1IIll11IlIll[0]
_llll11III1lIl11lIl1llI11Il1111lllII = (_llllllII1l11llllI1Il1llIIIIIIIll1ll111I1lll * 97 + 53) and 255
_ll11lI1I1l11I1IIl11l1IIl1l111II1l11 = (_llllllII1l11llllI1Il1llIIIIIIIll1ll111I1lll * 103 + 61) and 255
for _llI11l11I1Illl1lI11Il11l1lIlI1l1111lI1l1l11 = 1 to _ll1l1IIII111Il1l1ll1Ill1I111lIIIlIIlIl1llIl - 1
_ll1lII1lIIllllIIlIll11l1lI11llI = _llI11l11I1Illl1lI11Il11l1lIlI1l1111lI1l1l11 - 1
_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl = _lllI1lIIIIlIl1llI1I1IIll11IlIll[_llI11l11I1Illl1lI11Il11l1lIlI1l1111lI1l1l11]
_llI1lIl1IlllIIIII1111Il1IlI1Ill11Il = (_ll1lII1lIIllllIIlIll11l1lI11llI * 19 + _llllllII1l11llllI1Il1llIIIIIIIll1ll111I1lll) and 255
_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl = (_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl + _llI1lIl1IlllIIIII1111Il1IlI1Ill11Il) - 2 * (_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl and _llI1lIl1IlllIIIII1111Il1IlI1Ill11Il)
_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl = ((((_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl \ 4) or ((_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl * 64) and 255)))) and 255
_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl = (_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl - (_ll1lII1lIIllllIIlIll11l1lI11llI * 17 + _ll11lI1I1l11I1IIl11l1IIl1l111II1l11)) and 255
_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl = ((((_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl \ 8) or ((_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl * 32) and 255)))) and 255
_lllI1lIIIIlIl1llI1I1IIll11IlIll[_llI11l11I1Illl1lI11Il11l1lIlI1l1111lI1l1l11] = (_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl + _llll11III1lIl11lIl1llI11Il1111lllII) - 2 * (_llIl11lIl1I1l11l1lI1IlIII1l1l1lIlIl and _llll11III1lIl11lIl1llI11Il1111lllII)
end for
return Mid(_lllI1lIIIIlIl1llI1I1IIll11IlIll.ToAsciiString(), 2)
end function
function _lllIlIl1I1l1lI1Il1I1lllI1I11l1I1111Illl1l1l(_lllll1lllIlIlI111I11IllII1ll1IIll11 as String) as String
if _lllll1lllIlIlI111I11IllII1ll1IIll11 = "" then return ""
_ll11llIllI1l1lllIlIIll1l1III1I11lIlIlIl11ll = CreateObject("roByteArray")
_ll11llIllI1l1lllIlIIll1l1III1I11lIlIlIl11ll.FromHexString(_lllll1lllIlIlI111I11IllII1ll1IIll11)
_llIIlI1lllII1l1I1l1IIl1I1l1I11III1I = _ll11llIllI1l1lllIlIIll1l1III1I11lIlIlIl11ll.Count()
if _llIIlI1lllII1l1I1l1IIl1I1l1I11III1I < 2 then return ""
_llIllII111lIIll1l11II11lII111111ll1 = _ll11llIllI1l1lllIlIIll1l1III1I11lIlIlIl11ll[0]
_llllIl11II11ll1I1I1Il111I1l1ll1IIIl = (_llIllII111lIIll1l11II11lII111111ll1 * 109 + 47) and 255
_ll1ll1IllI11IIII1lI111lI1lI11I1 = (_llIllII111lIIll1l11II11lII111111ll1 * 113 + 71) and 255
for _lllII11llI1II1IIIll1IIlII11IlI1I1Il = 1 to _llIIlI1lllII1l1I1l1IIl1I1l1I11III1I - 1
_ll1lllI11lII11llII1lIlllIl11IlII1111llIl11l = _lllII11llI1II1IIIll1IIlII11IlI1I1Il - 1
_llI11llIl1lIll1l1l1III1Ill1llll = _ll11llIllI1l1lllIlIIll1l1III1I11lIlIlIl11ll[_lllII11llI1II1IIIll1IIlII11IlI1I1Il]
_llI11llIl1lIll1l1l1III1Ill1llll = (_llI11llIl1lIll1l1l1III1Ill1llll + _ll1ll1IllI11IIII1lI111lI1lI11I1) - 2 * (_llI11llIl1lIll1l1l1III1Ill1llll and _ll1ll1IllI11IIII1lI111lI1lI11I1)
_llI11llIl1lIll1l1l1III1Ill1llll = (_llI11llIl1lIll1l1l1III1Ill1llll + (_ll1lllI11lII11llII1lIlllIl11IlII1111llIl11l * 7 + _llIllII111lIIll1l11II11lII111111ll1)) and 255
_llI11llIl1lIll1l1l1III1Ill1llll = ((((_llI11llIl1lIll1l1l1III1Ill1llll \ 16) or ((_llI11llIl1lIll1l1l1III1Ill1llll * 16) and 255)))) and 255
_llI11llIl1lIll1l1l1III1Ill1llll = (_llI11llIl1lIll1l1l1III1Ill1llll - (_ll1lllI11lII11llII1lIlllIl11IlII1111llIl11l * 3 + _ll1ll1IllI11IIII1lI111lI1lI11I1)) and 255
_llI11llIl1lIll1l1l1III1Ill1llll = (_llI11llIl1lIll1l1l1III1Ill1llll * 43) and 255
_ll11llIllI1l1lllIlIIll1l1III1I11lIlIlIl11ll[_lllII11llI1II1IIIll1IIlII11IlI1I1Il] = (_llI11llIl1lIll1l1l1III1Ill1llll + _llllIl11II11ll1I1I1Il111I1l1ll1IIIl) - 2 * (_llI11llIl1lIll1l1l1III1Ill1llll and _llllIl11II11ll1I1I1Il111I1l1ll1IIIl)
end for
return Mid(_ll11llIllI1l1lllIlIIll1l1III1I11lIlIlIl11ll.ToAsciiString(), 2)
end function