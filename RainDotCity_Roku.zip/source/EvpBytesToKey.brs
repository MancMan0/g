function EvpBytesToKey(_l11I1ll as Object, _llII1ll as Object, _l1II1ll as Integer) as Object
_ll1I1ll = CreateObject(_l1d_bf926d("b4baeab6bed0f7c9cce0cb", 127, 167))
_lI1I1ll = CreateObject(_l1d_bf926d("ef0525fdf5072e04071712", 245, 104))
_lllI1ll = CreateObject(_l1d_bf926d("54628b817e956b7c7d6e74", 57, 9))
while _ll1I1ll.Count() < _l1II1ll
_lllI1ll.Setup(_l1d_bf926d("beba6c", 53, 102))
if _lI1I1ll.Count() > 0 then _lllI1ll.Update(_lI1I1ll)
if _l11I1ll <> invalid and _l11I1ll.Count() > 0 then _lllI1ll.Update(_l11I1ll)
if _llII1ll <> invalid and _llII1ll.Count() > 0 then _lllI1ll.Update(_llII1ll)
_l1lI1ll = _lllI1ll.Final()
_lII11ll = CreateObject(_l1d_bf926d("d2e808e4dcee15e7eafef9", 247, 77))
_lII11ll.FromHexString(_l1lI1ll)
for _lIlI1ll = 0 to _lII11ll.Count() - 1
if _ll1I1ll.Count() >= _l1II1ll then exit for
_ll1I1ll.Push(_lII11ll[_lIlI1ll])
end for
_lI1I1ll = _lII11ll
end while
return _ll1I1ll
end function
function _l1d_bf926d(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function