function M3U_GetDefaultUrl() as String
if ((29820 - 5964 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return _l1d_e6c6fd("e5e3e2b8b0eaeceff1bf0308fe09081712d618e126", 128, 245)
end function
function M3U_GetSavedUrl() as String
_llIll1l = CreateObject(_l1d_e6c6fd("564c3c484d5a67656e765360697775767a", 133, 95), _l1d_e6c6fd("fd0d181af31f29012a3240131f1e23", 69, 230))
if _llIll1l.Exists(_l1d_e6c6fd("2f4e464157574448764f4f6c", 240, 175)) then
_l1Ill1l = _llIll1l.Read(_l1d_e6c6fd("b5b4aac5bdbbc8cefad3d5d2", 97, 164))
if _l1Ill1l <> invalid and _l1Ill1l <> "" and _l1Ill1l <> _l1d_e6c6fd("7d94979e9edac8cb94b0afb0dc9dbdabe7b1b2cab9cfc5fcc4c104cde9e8e913e2d9f6e0fd02eef50a310efb3bff5c1d", 111, 118) then return _l1Ill1l
end if
return M3U_GetDefaultUrl()
end function
sub M3U_SaveUrl(_lI1I11l as String)
if ((20214 - 2246 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lI1I11l = invalid or _lI1I11l = "" then return
_l11I11l = CreateObject(_l1d_e6c6fd("0e2e342a2f34212526304d4243374f585a", 112, 12), _l1d_e6c6fd("75abb6ba97c1ad9bc8b6beb19ba2a3", 82, 117))
_l11I11l.Write(_l1d_e6c6fd("baa9afbab2b0cdd3efd8dac7", 41, 97), _lI1I11l)
_l11I11l.Flush()
end sub
function M3U_GetFavorites() as Object
_llI1lIl = CreateObject(_l1d_e6c6fd("ea0810080912fb05020e27201d172d3236", 51, 169), _l1d_e6c6fd("4117221e3b253147343a4a5d676667", 38, 205))
_lIl1lIl = []
if _llI1lIl.Exists(_l1d_e6c6fd("737d69857391778b80", 150, 131)) then
_lI11lIl = _llI1lIl.Read(_l1d_e6c6fd("c4c2dad6dcd6e4d8e9", 192, 30))
if _lI11lIl <> invalid and _lI11lIl <> "" then
_l111lIl = _lI11lIl.Split(_l1d_e6c6fd("da", 129, 221))
for each _ll11lIl in _l111lIl
_l1I1lIl = _ll11lIl.Trim()
if _l1I1lIl <> "" then _lIl1lIl.Push(_l1I1lIl)
end for
end if
end if
return _lIl1lIl
end function
function M3U_IsFavorite(_llllIIl as String) as Boolean
if _llllIIl = invalid or _llllIIl = "" then return false
_lIllIIl = M3U_GetFavorites()
for each _l1llIIl in _lIllIIl
if _l1llIIl = _llllIIl then return true
end for
return false
end function
sub M3U_ToggleFavorite(_l1I1ll1 as String)
if ((16260 - 5420 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _l1I1ll1 = invalid or _l1I1ll1 = "" then return
_lllIll1 = M3U_GetFavorites()
_l11Ill1 = []
_l1lIll1 = false
for each _lII1ll1 in _lllIll1
if _lII1ll1 = _l1I1ll1 then
_l1lIll1 = true
else
_l11Ill1.Push(_lII1ll1)
end if
end for
if not _l1lIll1 then
_l11Ill1.Push(_l1I1ll1)
end if
_ll1Ill1 = ""
for _lIlIll1 = 0 to _l11Ill1.Count() - 1
if _lIlIll1 > 0 then _ll1Ill1 = _ll1Ill1 + _l1d_e6c6fd("4a", 134, 80)
_ll1Ill1 = _ll1Ill1 + _l11Ill1[_lIlIll1]
end for
_lI1Ill1 = CreateObject(_l1d_e6c6fd("d4e2baeef3e8e5ebece4d10607fd030c10", 217, 41), _l1d_e6c6fd("596d7876537b895d8a92a0737f7e7f", 199, 196))
_lI1Ill1.Write(_l1d_e6c6fd("4e4c446046604e6253", 240, 184), _ll1Ill1)
_lI1Ill1.Flush()
end sub
function M3U_ExtractTag(line as String, _lll1Il1 as String) as String
_llIlIl1 = _lll1Il1 + _l1d_e6c6fd("0a16", 86, 159)
_lIIlIl1 = Instr(1, line, _llIlIl1)
if _lIIlIl1 = 0 then
_l1IlIl1 = _lll1Il1 + _l1d_e6c6fd("5b", 171, 197)
_lIIlIl1 = Instr(1, line, _l1IlIl1)
if _lIIlIl1 = 0 then return ""
_lIIlIl1 = _lIIlIl1 + Len(_l1IlIl1)
_lI1lIl1 = Instr(_lIIlIl1, line, _l1d_e6c6fd("60", 58, 70))
if _lI1lIl1 = 0 then _lI1lIl1 = Instr(_lIIlIl1, line, _l1d_e6c6fd("9f", 157, 238))
if _lI1lIl1 = 0 then _lI1lIl1 = Len(line) + 1
return Mid(line, _lIIlIl1, _lI1lIl1 - _lIIlIl1).Trim()
end if
_lIIlIl1 = _lIIlIl1 + Len(_llIlIl1)
_lI1lIl1 = Instr(_lIIlIl1, line, _l1d_e6c6fd("0b", 191, 110))
if _lI1lIl1 = 0 then return ""
return Mid(line, _lIIlIl1, _lI1lIl1 - _lIIlIl1).Trim()
end function
function M3U_ParseContent(_lllI111 as String) as Object
if ((37248 - 9312 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1lI111 = {
groups: [],
channelsByGroup: {},
allChannels: []
}
if _lllI111 = invalid or Len(_lllI111) = 0 then
return _l1lI111
end if
_ll11111 = _lllI111.Split(chr(10))
_lIIIl11 = invalid
_lI1l111 = M3U_GetFavorites()
_l11l111 = {}
for each _l1ll111 in _lI1l111
_l11l111[_l1ll111] = true
end for
_lll1111 = {}
_llIIl11 = 0
for each _lII1111 in _ll11111
line = _lII1111.Trim()
if line = "" then continue for
if Left(line, 7) = _l1d_e6c6fd("5ab7a7aebcbec9", 61, 60) then
_llIIl11 = _llIIl11 + 1
_l111111 = M3U_ExtractTag(line, _l1d_e6c6fd("cacfe1aaeef2edf8", 145, 229))
_lIIl111 = M3U_ExtractTag(line, _l1d_e6c6fd("6777758282c08c82928d87", 195, 195))
if _lIIl111 = "" then _lIIl111 = _l1d_e6c6fd("92776f7d697f7d", 58, 21)
_l1IIl11 = Instr(1, line, _l1d_e6c6fd("b9", 38, 175))
_lI11111 = ""
if _l1IIl11 > 0 then
_lI11111 = Mid(line, _l1IIl11 + 1).Trim()
end if
if _lI11111 = "" then
_lI11111 = M3U_ExtractTag(line, _l1d_e6c6fd("393e50094f5b525d", 157, 80))
end if
if _lI11111 = "" then
_lI11111 = _l1d_e6c6fd("5a36423639474110", 46, 237) + Box(_llIIl11).ToStr()
end if
_lIl1111 = false
if _l11l111.DoesExist(_lI11111) then _lIl1111 = true
_lIIIl11 = {
num: _llIIl11,
name: _lI11111,
logo: _l111111,
group: _lIIl111,
url: "",
isFavorite: _lIl1111
}
else if Left(line, 1) <> _l1d_e6c6fd("10", 176, 125) and _lIIIl11 <> invalid then
if Left(line, 4) = _l1d_e6c6fd("f1f0f3f2", 26, 127) then
_lIIIl11.url = line
_l1lI111.allChannels.Push(_lIIIl11)
_l1l1111 = _lIIIl11.group
if not _lll1111.DoesExist(_l1l1111) then
_lll1111[_l1l1111] = true
_l1lI111.groups.Push(_l1l1111)
_l1lI111.channelsByGroup[_l1l1111] = []
end if
_l1lI111.channelsByGroup[_l1l1111].Push(_lIIIl11)
_lIIIl11 = invalid
end if
end if
end for
_lIll111 = []
for each _lI1Il11 in _l1lI111.allChannels
if _lI1Il11.isFavorite then _lIll111.Push(_lI1Il11)
end for
_llIl111 = []
if _lIll111.Count() > 0 then
_ll1l111 = _l1d_e6c6fd("907a8672907e94889d514c", 174, 168) + Box(_lIll111.Count()).ToStr() + _l1d_e6c6fd("2b", 141, 135)
_llIl111.Push(_ll1l111)
_l1lI111.channelsByGroup[_ll1l111] = _lIll111
end if
_l1I1111 = [
_l1d_e6c6fd("2c1f57fe5d2b3c664647454d47574f", 253, 116),
_l1d_e6c6fd("bdd05ebd64dcd16ddfe3e1e7f0", 34, 86),
_l1d_e6c6fd("60734ba2517f7c5a81878d816987998d97a4a881b1b4b1", 7, 30),
_l1d_e6c6fd("897cac5bb28891bb9f98a2aaa5ac", 121, 77),
_l1d_e6c6fd("d6c9c1f8c7d5f2d0eff7f6e702fd07f4f9150c01", 151, 4),
_l1d_e6c6fd("bbce5ebd64dad36dd3e1eadceef3e1ecf3eefc05", 33, 87),
_l1d_e6c6fd("8c989487ae8da0a3a48cadafb7b7b4abc9bfcfcdc6ce", 29, 65),
_l1d_e6c6fd("d5c3dd30f736d7d3d6eee7e9dfe251040708", 204, 59),
_l1d_e6c6fd("d1e5d184c38ae0f3f9f599eceff8", 49, 106),
_l1d_e6c6fd("908f35843bb3b4a547bdbdafc5cacc", 40, 39),
_l1d_e6c6fd("2c2bd120d74f5041e3565962ec4e4e6e60fe667a6c688183", 168, 67),
_l1d_e6c6fd("f30218f71e1613082a10151d1b271d2b", 226, 80),
_l1d_e6c6fd("1e1dc3f2c9211e33d532403130", 58, 163),
_l1d_e6c6fd("87962c8b32aaa79c3ea0adb1afbab1", 34, 36),
_l1d_e6c6fd("5f6e06650c828374187e8c9587999e8c97a1a19caab3", 161, 127),
_l1d_e6c6fd("e1f046054ce4e5f65800f1f11267fa190506", 208, 80),
_l1d_e6c6fd("433a2a51303e47583c5d565a", 29, 231),
_l1d_e6c6fd("d9ccc2e9c8e4dceee8f8ecf9", 158, 254)
]
_ll1Il11 = {}
for each _llI1111 in _l1I1111
for each _l1Il111 in _l1lI111.groups
if _l1Il111 = _llI1111 or Instr(1, _l1Il111, _llI1111) > 0 then
if not _ll1Il11.DoesExist(_l1Il111) and _l1lI111.channelsByGroup.DoesExist(_l1Il111) then
_ll1Il11[_l1Il111] = true
_llll111 = _l1Il111 + _l1d_e6c6fd("9ba6", 227, 216) + Box(_l1lI111.channelsByGroup[_l1Il111].Count()).ToStr() + _l1d_e6c6fd("03", 161, 123)
_llIl111.Push(_llll111)
_l1lI111.channelsByGroup[_llll111] = _l1lI111.channelsByGroup[_l1Il111]
end if
end if
end for
end for
for each _l1Il111 in _l1lI111.groups
if not _ll1Il11.DoesExist(_l1Il111) and _l1lI111.channelsByGroup.DoesExist(_l1Il111) then
_ll1Il11[_l1Il111] = true
_llll111 = _l1Il111 + _l1d_e6c6fd("524d", 58, 56) + Box(_l1lI111.channelsByGroup[_l1Il111].Count()).ToStr() + _l1d_e6c6fd("8a", 63, 116)
_llIl111.Push(_llll111)
_l1lI111.channelsByGroup[_llll111] = _l1lI111.channelsByGroup[_l1Il111]
end if
end for
_l11Il11 = _l1d_e6c6fd("5b898cc369918d9da09aa48edee9", 80, 74) + Box(_l1lI111.allChannels.Count()).ToStr() + _l1d_e6c6fd("28", 18, 237)
_llIl111.Push(_l11Il11)
_l1lI111.channelsByGroup[_l11Il11] = _l1lI111.allChannels
_l1lI111.groups = _llIl111
return _l1lI111
end function
function _l1d_e6c6fd(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function