function HC_DefaultUA() as String
if ((53730 - 8955 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return _l1d_06eaf4("a7c8e0d4d4d7e59ab7a1c2b5b0e4f5f300f8131ad0e502d9ebefd4f5edeb172826010602004b1015030f3165684f594a5f653f647c24414645314f4f48436369806a6e5160979d9ea76f8bb0b5b0af7884a4c2dbc1c6d18aabadae97b89dbea3c4b7e7fcfa021400bddadfdecae8e8", 143, 229)
end function
function HC_NewSession() as Object
_l1Ill1l = CreateObject(_l1d_06eaf4("fa0a2303102b0c1e1e162c2e1e", 184, 48))
_l1Ill1l.SetCertificatesFile(_l1d_06eaf4("4a595e616266152b626b59625e3d7479487e76908d98925c92868f", 51, 250))
_l1Ill1l.AddHeader(_l1d_06eaf4("afddaba1a891ecbaaa9fb0a6a5b9bd07e3c5b713fad2", 119, 128), "")
_l1Ill1l.InitClientCertificates()
_l1Ill1l.EnableCookies()
_l1Ill1l.RetainBodyOnError(true)
_l1Ill1l.EnableEncodings(true)
_llIll1l = CreateObject(_l1d_06eaf4("3f5778534c4f6061627872605d", 52, 249))
_l1Ill1l.SetMessagePort(_llIll1l)
return {
xfer: _l1Ill1l
port: _llIll1l
}
end function
sub HC_Close(_l11I11l as Object)
if _l11I11l = invalid then return
if _l11I11l.xfer <> invalid then
_l11I11l.xfer.AsyncCancel()
_l11I11l.xfer.ClearCookies()
end if
_l11I11l.xfer = invalid
_l11I11l.port = invalid
end sub
function HC_Request(_lIIIlIl as Object, _lIlIlIl as String, _lIll1Il as String, _lII1lIl as Object, _ll11lIl as String, _lI1IlIl as String, _l111lIl as Integer) as Object
_l1IIlIl = {
ok: false
status: 0
body: ""
finalUrl: _lIll1Il
headers: {}
error: ""
}
if _lIIIlIl = invalid or _lIIIlIl.xfer = invalid then
_l1IIlIl.error = _l1d_06eaf4("f5f7c1110a171a070c10", 139, 16)
return _l1IIlIl
end if
_lI1l1Il = _lIIIlIl.xfer
_lI1l1Il.AsyncCancel()
if _lIIIlIl.port <> invalid then
while _lIIIlIl.port.GetMessage() <> invalid
end while
end if
_lI1l1Il.SetUrl(_lIll1Il)
_lI1l1Il.SetHeaders({})
_l1ll1Il = HC_DefaultUA()
_lIl1lIl = _l1d_06eaf4("e8e8ee", 68, 122)
_lI11lIl = false
_llI1lIl = false
if _lII1lIl <> invalid then
for each _lllIlIl in _lII1lIl
_l11l1Il = _lII1lIl[_lllIlIl]
if _l11l1Il <> invalid then
_l1lIlIl = LCase(_lllIlIl)
if _l1lIlIl = _l1d_06eaf4("888d9e92ecaba8adb5a2", 86, 101) then
_l1ll1Il = _l11l1Il
_llI1lIl = true
else if _l1lIlIl = _l1d_06eaf4("f3f8fbf8f0ef", 53, 159) then
_lIl1lIl = _l11l1Il
_lI11lIl = true
end if
_lI1l1Il.AddHeader(_lllIlIl, _l11l1Il)
end if
end for
end if
if not _llI1lIl then _lI1l1Il.AddHeader(_l1d_06eaf4("4d6a836fd1688d929a87", 210, 198), _l1ll1Il)
if not _lI11lIl then _lI1l1Il.AddHeader(_l1d_06eaf4("0d3235322a29", 157, 49), _lIl1lIl)
if _lI1IlIl <> "" then _lI1l1Il.AddHeader(_l1d_06eaf4("b68c989499", 162, 198), _lI1IlIl)
if _l111lIl <= 0 then _l111lIl = 8000
_l11IlIl = false
if _lIlIlIl = _l1d_06eaf4("6b776e78", 219, 224) then
if _ll11lIl = invalid then _ll11lIl = ""
_l11IlIl = _lI1l1Il.AsyncPostFromString(_ll11lIl)
else if _lIlIlIl = _l1d_06eaf4("14222129", 9, 211) then
if _lI1IlIl = "" then _lI1l1Il.AddHeader(_l1d_06eaf4("b3c3bdc7c8", 205, 20), _l1d_06eaf4("a5a3a1b5a27369896f", 146, 181))
_l11IlIl = _lI1l1Il.AsyncGetToString()
else
_l11IlIl = _lI1l1Il.AsyncGetToString()
end if
if not _l11IlIl then
_l1IIlIl.error = _l1d_06eaf4("c6bbc4b6b4d3b4c884f2cad9d78ee3cfe3e5efe6dee2a9eaeef606f3", 165, 226)
return _l1IIlIl
end if
_llll1Il = CreateObject(_l1d_06eaf4("2e240e2c2b263f41333d", 5, 183))
_llll1Il.mark()
while _llll1Il.totalMilliseconds() < _l111lIl
_llIIlIl = _l111lIl - _llll1Il.totalMilliseconds()
if _llIIlIl < 1 then exit while
_ll1IlIl = wait(_llIIlIl, _lIIIlIl.port)
if _ll1IlIl = invalid then exit while
if type(_ll1IlIl) = _l1d_06eaf4("eaf815f3042e00140e0b", 123, 225) then
_l1IIlIl.status = _ll1IlIl.getResponseCode()
_l1IIlIl.body = _ll1IlIl.getString()
if _l1IIlIl.body = invalid then _l1IIlIl.body = ""
_ll1l1Il = _ll1IlIl.getFailureReason()
_l1I1lIl = _ll1IlIl.getResponseHeaders()
if _l1I1lIl <> invalid then _l1IIlIl.headers = _l1I1lIl
_l1IIlIl.ok = (_l1IIlIl.status >= 200 and _l1IIlIl.status < 400)
if _l1IIlIl.status = 0 then
_l1IIlIl.error = _ll1l1Il
end if
exit while
end if
end while
if _l1IIlIl.status = 0 and _l1IIlIl.body = "" then
_lI1l1Il.AsyncCancel()
_l1IIlIl.error = _l1d_06eaf4("8391909b949195ecaeaca1b3a9fe", 95, 88) + _l111lIl.ToStr() + _l1d_06eaf4("c5c6", 220, 20)
end if
return _l1IIlIl
end function
function HC_Get(_lIllIIl as Object, _ll1lIIl as String, _l1llIIl as Object, _llllIIl as Integer) as Object
return HC_Request(_lIllIIl, _l1d_06eaf4("b7bcd0", 71, 183), _ll1lIIl, _l1llIIl, "", "", _llllIIl)
end function
function HC_Head(_lllIll1 as Object, _l1lIll1 as String, _lII1ll1 as Object, _l1I1ll1 as Integer) as Object
return HC_Request(_lllIll1, _l1d_06eaf4("61676e6e", 189, 108), _l1lIll1, _lII1ll1, "", "", _l1I1ll1)
end function
function HC_GetRange(_lIIlIl1 as Object, _lll1Il1 as String, _llIlIl1 as Object, _l1IlIl1 as String, _lI1lIl1 as Integer) as Object
return HC_Request(_lIIlIl1, _l1d_06eaf4("646577", 100, 65), _lll1Il1, _llIlIl1, "", _l1IlIl1, _lI1lIl1)
end function
function HC_Post(_llIIl11 as Object, _l1IIl11 as String, _lI1Il11 as Object, _ll1Il11 as String, _l11Il11 as Integer) as Object
if ((13605 - 2721 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return HC_Request(_llIIl11, _l1d_06eaf4("2a1e2d2f", 135, 83), _l1IIl11, _lI1Il11, _ll1Il11, "", _l11Il11)
end function
function HC_Base64UrlDecode(_lI11I11 as String) as Object
if ((33352 - 8338 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1l1I11 = CreateObject(_l1d_06eaf4("371f0d373d31184c4f414c", 140, 57))
if _lI11I11 = invalid or _lI11I11 = "" then return _l1l1I11
_ll11I11 = CreateObject(_l1d_06eaf4("3d432353545949", 95, 16), _l1d_06eaf4("1a", 73, 182), _l1d_06eaf4("a1", 145, 171))
_l111I11 = CreateObject(_l1d_06eaf4("d8e0fef0f1f6e4", 62, 140), _l1d_06eaf4("b2", 186, 205), _l1d_06eaf4("f0", 251, 84))
_llI1I11 = _ll11I11.replaceAll(_lI11I11, _l1d_06eaf4("19", 100, 202))
_llI1I11 = _l111I11.replaceAll(_llI1I11, _l1d_06eaf4("6d", 68, 2))
_lIl1I11 = Len(_llI1I11) mod 4
if _lIl1I11 = 2 then _llI1I11 = _llI1I11 + _l1d_06eaf4("0003", 251, 58)
if _lIl1I11 = 3 then _llI1I11 = _llI1I11 + _l1d_06eaf4("ad", 94, 74)
if _lIl1I11 = 1 then return _l1l1I11
_l1l1I11.FromBase64String(_llI1I11)
return _l1l1I11
end function
function HC_Base64UrlEncode(_lIIIlI1 as Object) as String
if ((22992 - 3832 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lIIIlI1 = invalid then return ""
_ll1l1I1 = _lIIIlI1.ToBase64String()
_llll1I1 = CreateObject(_l1d_06eaf4("b39bd9a7acadbb", 108, 149), _l1d_06eaf4("3c88", 67, 29), _l1d_06eaf4("b8", 31, 64))
_l1ll1I1 = CreateObject(_l1d_06eaf4("4e5c74686d6e56", 185, 131), _l1d_06eaf4("6d", 253, 155), _l1d_06eaf4("54", 66, 47))
_lIll1I1 = CreateObject(_l1d_06eaf4("c5ddebd9dedfdd", 244, 63), _l1d_06eaf4("f10610", 63, 239), "")
_ll1l1I1 = _llll1I1.replaceAll(_ll1l1I1, _l1d_06eaf4("51", 46, 78))
_ll1l1I1 = _l1ll1I1.replaceAll(_ll1l1I1, _l1d_06eaf4("d4", 62, 115))
_ll1l1I1 = _lIll1I1.replaceAll(_ll1l1I1, "")
return _ll1l1I1
end function
function HC_HexToBytes(_llI1II1 as String) as Object
_l1I1II1 = CreateObject(_l1d_06eaf4("ff0df50111230214172b16", 27, 150))
if _llI1II1 = invalid or _llI1II1 = "" then return _l1I1II1
_l1I1II1.FromHexString(_llI1II1)
return _l1I1II1
end function
function HC_BytesToHex(_l11l1lI as Object) as String
if ((65680 - 8210 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _l11l1lI = invalid then return ""
return _l11l1lI.ToHexString()
end function
function HC_StringToBytes(_ll1IIlI as String) as Object
_lIlIIlI = CreateObject(_l1d_06eaf4("c6c69cd6d4c8a7dbded0eb", 64, 148))
if _ll1IIlI = invalid or _ll1IIlI = "" then return _lIlIIlI
_lIlIIlI.FromAsciiString(_ll1IIlI)
return _lIlIIlI
end function
function HC_BytesToString(_lll111I as Object) as String
if ((38112 - 9528 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lll111I = invalid then return ""
return _lll111I.ToAsciiString()
end function
function HC_HostOf(_lIIII1I as String) as String
if _lIIII1I = invalid or _lIIII1I = "" then return ""
_l1III1I = CreateObject(_l1d_06eaf4("f3e1d9edf2f3fb", 201, 56), _l1d_06eaf4("93606f727177c6c4bcbfbbb1b7cbdec5c2d3d4", 96, 85), _l1d_06eaf4("9a", 230, 11))
m = _l1III1I.match(_lIIII1I)
if m <> invalid and m.Count() >= 2 then return LCase(m[1])
return ""
end function
function HC_OriginOf(_llI11II as String) as String
if _llI11II = invalid or _llI11II = "" then return ""
_lI111II = CreateObject(_l1d_06eaf4("8b9171a1a2a797", 223, 222), _l1d_06eaf4("0415d8e7eae9eb3a38303322283c4f36374449", 98, 200), _l1d_06eaf4("1c", 86, 221))
m = _lI111II.match(_llI11II)
if m <> invalid and m.Count() >= 2 then return m[1]
return ""
end function
function HC_GetJson(_lll1lll as String, _l11llll = 8000 as Integer) as Object
if _lll1lll = invalid or _lll1lll = "" then return invalid
_l1l1lll = CreateObject(_l1d_06eaf4("0c1af71526011e3230263e4230", 27, 163))
_l1l1lll.SetCertificatesFile(_l1d_06eaf4("eaf9fafd0206d5cb0207191e1edd1415e41e323029342efc32464b", 33, 168))
_l1l1lll.AddHeader(_l1d_06eaf4("c016d0deddfa25dff304f90b12020640ec0e244ceb1b", 201, 47), "")
_l1l1lll.InitClientCertificates()
_l1l1lll.SetUrl(_lll1lll)
_l1l1lll.AddHeader(_l1d_06eaf4("95b2cbb909b0d5dad4d1", 91, 135), HC_DefaultUA())
_l1l1lll.AddHeader(_l1d_06eaf4("0df2f5fa0a11", 233, 101), _l1d_06eaf4("5f737665636c71896f7478ba7a948387ccd3aa9ca4b3dbb5a4aaa5abf0f7f0f6f6", 203, 181))
_l1l1lll.EnableEncodings(true)
_llIllll = CreateObject(_l1d_06eaf4("384e6f4a434657585971695956", 181, 113))
_l1l1lll.SetMessagePort(_llIllll)
if not _l1l1lll.AsyncGetToString() then return invalid
_lIIllll = CreateObject(_l1d_06eaf4("6f6f9b737a7582867a86", 226, 223))
_lIIllll.mark()
_ll1llll = invalid
while _lIIllll.totalMilliseconds() < _l11llll
_l1Illll = _l11llll - _lIIllll.totalMilliseconds()
if _l1Illll < 1 then exit while
_lI1llll = wait(_l1Illll, _llIllll)
if _lI1llll = invalid then exit while
if type(_lI1llll) = _l1d_06eaf4("1b0b0824150131271f3c", 10, 163) then
if _lI1llll.getResponseCode() >= 200 and _lI1llll.getResponseCode() < 300 then
_ll1llll = _lI1llll.getString()
end if
exit while
end if
end while
if _ll1llll = invalid or _ll1llll = "" then
_l1l1lll.AsyncCancel()
return invalid
end if
return ParseJson(_ll1llll)
end function
function _l1d_06eaf4(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function