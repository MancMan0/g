function U_Trim(_lllI1ll as String) as String
if _lllI1ll = invalid then return ""
_lII11ll = CreateObject(_l1d_444dfc("d7f5fdf5f6fbf3", 179, 22), _l1d_444dfc("a3a4945f8db0a06b71", 189, 192), _l1d_444dfc("9b", 208, 228))
return _lII11ll.replaceAll(_lllI1ll, "")
end function
function U_HtmlDecode(_lIl1l1l as String) as String
if ((17694 - 2949 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _lIl1l1l = invalid or _lIl1l1l = "" then return ""
_lll1l1l = _lIl1l1l
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("4c08071f5b", 233, 125), _l1d_444dfc("50", 206, 104))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("7876888c959a", 225, 177), _l1d_444dfc("4a", 91, 206))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("5c62554e53", 125, 1), _l1d_444dfc("2b", 65, 197))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("196175597833", 143, 112), _l1d_444dfc("f2", 75, 134))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("f8c4cbb8d20a", 73, 137), chr(34))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("bb848fd9", 96, 117), _l1d_444dfc("6d", 13, 60))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("c08294d4", 109, 117), _l1d_444dfc("0a", 108, 184))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("a6f1e8fc00ca", 2, 130), _l1d_444dfc("f2", 238, 36))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("4f94949ea1a18b59", 48, 57), _l1d_444dfc("cbced1", 233, 4))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("6ebab6bcadcb7b", 23, 61), _l1d_444dfc("64", 214, 105))
_lll1l1l = _lll1l1l.Replace(_l1d_444dfc("1c6760667b7549", 165, 153), _l1d_444dfc("4e", 88, 217))
_l1l1l1l = CreateObject(_l1d_444dfc("705e966e6f747c", 107, 87), _l1d_444dfc("e3e9e776b19deaf2eca7feef", 95, 106), _l1d_444dfc("8f", 2, 42))
_llIll1l = _l1l1l1l.matchAll(_lll1l1l)
if _llIll1l <> invalid then
for each _l1Ill1l in _llIll1l
_lIIll1l = _l1Ill1l[1].ToInt()
if _lIIll1l > 0 and _lIIll1l < 1114112 then
_lll1l1l = _lll1l1l.Replace(_l1Ill1l[0], chr(_lIIll1l))
end if
end for
end if
return _lll1l1l
end function
function U_StripTags(_lI1I11l as String) as String
if _lI1I11l = invalid then return ""
_l11I11l = CreateObject(_l1d_444dfc("9399b9a5aaab9b", 189, 196), _l1d_444dfc("4561694c705d55", 19, 22), _l1d_444dfc("35", 156, 58))
return U_Trim(_l11I11l.replaceAll(_lI1I11l, ""))
end function
function U_FirstMatch(_lIl1lIl as String, _ll11lIl as String) as String
if ((73548 - 8172 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l111lIl = CreateObject(_l1d_444dfc("a6acccb8bdbeae", 61, 87), _ll11lIl, _l1d_444dfc("5774", 233, 215))
m = _l111lIl.match(_lIl1lIl)
if m <> invalid and m.Count() >= 2 then return m[1]
return ""
end function
function U_AllMatches(_llllIIl as String, _lIllIIl as String) as Object
_ll1lIIl = CreateObject(_l1d_444dfc("c1c7a7d3d8d9c9", 157, 210), _lIllIIl, _l1d_444dfc("b7c4", 100, 170))
_l1llIIl = []
m = _ll1lIIl.matchAll(_llllIIl)
if m = invalid then return _l1llIIl
return m
end function
function U_UrlEncode(_lII1ll1 as String) as String
if _lII1ll1 = invalid then return ""
_l1I1ll1 = CreateObject(_l1d_444dfc("1b1b482425502d232f372d333f", 162, 75))
return _l1I1ll1.escape(_lII1ll1)
end function
function U_AbsUrl(_l1IlIl1 as String, _lI1lIl1 as String) as String
if _l1IlIl1 = invalid or _l1IlIl1 = "" then return ""
_llIlIl1 = U_Trim(_l1IlIl1)
if Left(_llIlIl1, 4) = _l1d_444dfc("87767978", 49, 46) then return _llIlIl1
if Left(_llIlIl1, 2) = _l1d_444dfc("3235", 146, 117) then return _l1d_444dfc("decdd0cfd51f", 112, 198) + _llIlIl1
if Left(_llIlIl1, 1) = _l1d_444dfc("7c", 149, 194) then return _lI1lIl1 + _llIlIl1
return _lI1lIl1 + _l1d_444dfc("00", 45, 254) + _llIlIl1
end function
function U_TmdbImage(_lI1Il11 as String, _l11Il11 as String) as String
if _lI1Il11 = invalid or _lI1Il11 = "" then return ""
_ll1Il11 = CreateObject(_l1d_444dfc("887e6e7e7f84a4", 71, 83), _l1d_444dfc("11100f0c11eb5c09251f24fd6e3220307b278131871e1c90259a", 214, 82), _l1d_444dfc("cb", 155, 217))
if _l11Il11 = "" then _l11Il11 = _l1d_444dfc("41828083", 96, 42)
return _ll1Il11.replace(_lI1Il11, _l1d_444dfc("7d848b9495538c96a2a362a49cb26da773a979", 185, 173) + _l11Il11)
end function
function U_DefaultPoster() as String
return _l1d_444dfc("6d7c7f7e82cec4c7848b828b8cdaa39d999ae9abb3a9f4befac000cb0c0c0f0f", 65, 68)
end function
function U_LooksHls(_llll1I1 as String) as Boolean
if _llll1I1 = invalid then return false
_lIIIlI1 = LCase(_llll1I1)
return Instr(1, _lIIIlI1, _l1d_444dfc("0444256222", 45, 1)) > 0 or Instr(1, _lIIIlI1, _l1d_444dfc("4a1413ff56", 87, 210)) > 0
end function
function U_LooksMp4(_llI1II1 as String) as Boolean
if _llI1II1 = invalid then return false
return Instr(1, LCase(_llI1II1), _l1d_444dfc("571b034a", 243, 122)) > 0
end function
function U_StreamFormat(_l11l1lI as String) as String
if U_LooksHls(_l11l1lI) then return _l1d_444dfc("313052", 172, 109)
if U_LooksMp4(_l11l1lI) then return _l1d_444dfc("fc1259", 106, 245)
if Instr(1, LCase(_l11l1lI), _l1d_444dfc("27ed0bfa", 78, 199)) > 0 then return _l1d_444dfc("5e5c716b", 193, 185)
return _l1d_444dfc("5e654b", 146, 100)
end function
function U_DefaultResolverUrl() as String
if ((22088 - 2761 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return ""
end function
function U_ClientId() as String
if ((12524 - 3131 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1l111I = CreateObject(_l1d_444dfc("f107e507f919121302201b25", 215, 76))
if _l1l111I <> invalid then
_lll111I = _l1l111I.GetChannelClientId()
if _lll111I <> invalid and _lll111I <> "" then return _lll111I
end if
_ll1111I = CreateObject(_l1d_444dfc("2c24122425363f3f44522b3c4151514e50", 70, 248), _l1d_444dfc("e8bec9c5e2ccd8eedbe1f1", 166, 244))
if _ll1111I.Exists(_l1d_444dfc("c5d5d5d4dce901df", 98, 196)) then return _ll1111I.Read(_l1d_444dfc("2b3d3b3a44512747", 131, 75))
_lIl111I = CreateObject(_l1d_444dfc("14fce80c1c0e1718f7131e1a", 206, 88)).GetRandomUUID()
if _lIl111I = invalid or _lIl111I = "" then _lIl111I = _l1d_444dfc("655352731e", 171, 140) + CreateObject(_l1d_444dfc("0a10fe241426fa282732", 95, 221)).AsSeconds().ToStr()
_ll1111I.Write(_l1d_444dfc("051311101e07fd1d", 81, 211), _lIl111I)
_ll1111I.Flush()
return _lIl111I
end function
function U_PrefDefault(_lIIII1I as String, _l1III1I as Dynamic) as Dynamic
if ((64603 - 9229 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1lllII = CreateObject(_l1d_444dfc("4252685e635855595a548176776b737c7e", 120, 56), _l1d_444dfc("e8dad5d5fedcd40ee7dddd", 60, 122))
if _l1lllII.Exists(_lIIII1I) then
_lIlllII = _l1lllII.Read(_lIIII1I)
if type(_l1III1I) = _l1d_444dfc("ed0b0e101a191b", 25, 146) then
return _lIlllII = _l1d_444dfc("514e584b", 130, 91)
else if type(_l1III1I) = _l1d_444dfc("9ab8a5b7b8bdb3", 23, 60) or type(_l1III1I) = _l1d_444dfc("e3011e08f1", 241, 96) then
return _lIlllII.ToInt()
end if
return _lIlllII
else
_lllllII = CreateObject(_l1d_444dfc("faf020f0f1020b0d121e37080d1f1d1a1e", 167, 37), _l1d_444dfc("9d6f878090acb3", 253, 232))
if _lllllII.Exists(_lIIII1I) then
_lIlllII = _lllllII.Read(_lIIII1I)
_l1lllII.Write(_lIIII1I, _lIlllII)
_l1lllII.Flush()
if type(_l1III1I) = _l1d_444dfc("755d60605c636b", 244, 191) then
return _lIlllII = _l1d_444dfc("54515b4e", 66, 30)
else if type(_l1III1I) = _l1d_444dfc("ceea07fbfc0115", 206, 71) or type(_l1III1I) = _l1d_444dfc("bbbbd8c0c9", 224, 41) then
return _lIlllII.ToInt()
end if
return _lIlllII
end if
end if
return _l1III1I
end function
sub U_PrefSet(_lI111II as String, _l1I11II as Dynamic)
_llI11II = CreateObject(_l1d_444dfc("f715dd11161b080e0f17f4292a20363f43", 81, 212), _l1d_444dfc("07192424fd2b330d363c4c", 132, 49))
_llI11II.Write(_lI111II, _l1I11II.ToStr())
_llI11II.Flush()
end sub
sub U_BumpCellFavorite(_ll1llll as Object)
if ((62920 - 7865 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _ll1llll = invalid then return
if not _ll1llll.hasField(_l1d_444dfc("eaf4e017e904f2", 118, 218)) then
_ll1llll.addField(_l1d_444dfc("d8e2eec5f7e200", 142, 240), _l1d_444dfc("ada9c6babbc0d4", 78, 134), true)
end if
_l11llll = _ll1llll.favBump
if _l11llll = invalid then _l11llll = 0
_ll1llll.favBump = _l11llll + 1
end sub
sub U_SetCellKind(_l1lI1ll as Object, _lIlI1ll as String)
if _l1lI1ll = invalid then return
if not _l1lI1ll.hasField(_l1d_444dfc("868b8986", 55, 42)) then _l1lI1ll.addField(_l1d_444dfc("d1d2dcd5", 209, 23), _l1d_444dfc("828a87757985", 138, 137), false)
_l1lI1ll.kind = _lIlI1ll
end sub
function U_GetCellKind(_lIIll1l as Object) as String
if _lIIll1l = invalid then return ""
if not _lIIll1l.hasField(_l1d_444dfc("b9bebab7", 102, 172)) then return ""
_lll1l1l = _lIIll1l.kind
if _lll1l1l = invalid then return ""
if Type(_lll1l1l) = _l1d_444dfc("4e72736d7571", 128, 123) or Type(_lll1l1l) = _l1d_444dfc("e3d3caeeefd9e1ed", 136, 233) then return _lll1l1l
return ""
end function
sub U_SetCellPct(_llII11l as Object, _l1II11l as Integer)
if ((31585 - 6317 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _llII11l = invalid then return
if not _llII11l.hasField(_l1d_444dfc("55695f83706878828084", 241, 212)) then _llII11l.addField(_l1d_444dfc("eafef41805fd0d071519", 249, 97), _l1d_444dfc("41475446474c5a", 3, 215), false)
_llII11l.pctWatched = _l1II11l
end sub
sub U_BumpAllCellsByUrl(_lI11lIl as Object, _lllIlIl as String)
if _lI11lIl = invalid or _lllIlIl = invalid or _lllIlIl = "" then return
_lII1lIl = _lI11lIl.getChildCount()
if _lII1lIl <= 0 then return
for _l1I1lIl = 0 to _lII1lIl - 1
_l111lIl = _lI11lIl.getChild(_l1I1lIl)
if _l111lIl <> invalid then
_llI1lIl = _l111lIl.url
if _llI1lIl <> invalid and _llI1lIl = _lllIlIl then
U_BumpCellFavorite(_l111lIl)
end if
if _l111lIl.getChildCount() > 0 then
U_BumpAllCellsByUrl(_l111lIl, _lllIlIl)
end if
end if
end for
end sub
function U_ToggleFavoriteForCell(_lIllIIl as Object, _ll1lIIl as Object) as Boolean
if _lIllIIl = invalid then return false
_l11lIIl = ""
if _lIllIIl.url <> invalid then _l11lIIl = _lIllIIl.url
if _l11lIIl = "" then return false
_l1IlIIl = ""
if _lIllIIl.title <> invalid then _l1IlIIl = _lIllIIl.title
_llIlIIl = ""
if _lIllIIl.HDPosterUrl <> invalid then _llIlIIl = _lIllIIl.HDPosterUrl
_lIIlIIl = ""
if _lIllIIl.id <> invalid then _lIIlIIl = _lIllIIl.id
_lI1lIIl = U_GetCellKind(_lIllIIl)
if W_IsFavorite("", _l11lIIl) then
W_RemoveFavorite("", _l11lIIl)
else
W_AddFavorite({
title:  _l1IlIIl
poster: _llIlIIl
href:   _l11lIIl
imdb:   ""
tmdb:   _lIIlIIl
kind:   _lI1lIIl
})
end if
U_BumpAllCellsByUrl(_ll1lIIl, _l11lIIl)
return true
end function
function _l1d_444dfc(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function