function VSC_Base() as String
return _l1d_8ce772("a5c4c7c6c602f8fbd71506cbc8cedad5e0f4e220f600fdf5f032f2f7", 203, 2)
end function
function VSC_NormalizeItem(_lI11l1l as Object, _l1Ill1l = _l1d_8ce772("090a060e1d", 187, 51) as String) as Object
if _lI11l1l = invalid then return invalid
_l1l1l1l = ""
if _lI11l1l.imdb_id <> invalid then _l1l1l1l = _lI11l1l.imdb_id
if _l1l1l1l = "" and _lI11l1l.id <> invalid then _l1l1l1l = _lI11l1l.id
_lIl1l1l = _l1Ill1l
if _lI11l1l.type <> invalid and _lI11l1l.type = _l1d_8ce772("e0d9e7d3e2ef", 235, 72) then _lIl1l1l = _l1d_8ce772("4243", 22, 224)
_llI1l1l = ""
if _lI11l1l.name <> invalid then _llI1l1l = _lI11l1l.name
if _llI1l1l = "" and _lI11l1l.title <> invalid then _llI1l1l = _lI11l1l.title
_l1I1l1l = ""
if _lI11l1l.year <> invalid then _l1I1l1l = _lI11l1l.year.ToStr()
if _l1I1l1l = "" and _lI11l1l.releaseInfo <> invalid then _l1I1l1l = _lI11l1l.releaseInfo
_ll11l1l = ""
if _lI11l1l.poster <> invalid then _ll11l1l = _lI11l1l.poster
if _ll11l1l = "" then _ll11l1l = _l1d_8ce772("140209d7c70c0b1a1b1c35dc381f2f34312f31313c4058ff5c4551", 12, 152)
_llIll1l = ""
if _lI11l1l.background <> invalid then _llIll1l = _lI11l1l.background
if _llIll1l = "" then _llIll1l = _ll11l1l
_lIIll1l = ""
if _lI11l1l.description <> invalid then _lIIll1l = _lI11l1l.description
_l111l1l = _l1d_8ce772("060217", 37, 244)
if _lI11l1l.imdbRating <> invalid and _lI11l1l.imdbRating <> "" then _l111l1l = _lI11l1l.imdbRating.ToStr()
_lll1l1l = []
if _lI11l1l.genres <> invalid and type(_lI11l1l.genres) = _l1d_8ce772("101e47191c301b", 123, 7) then _lll1l1l = _lI11l1l.genres
return {
id: _l1l1l1l,
imdb: _l1l1l1l,
tmdb: "",
kind: _lIl1l1l,
title: _llI1l1l,
year: _l1I1l1l,
poster: _ll11l1l,
backdrop: _llIll1l,
description: _lIIll1l,
rating: _l111l1l,
genres: _lll1l1l
}
end function
function VSC_FetchTrendingMovies() as Object
_lIII11l = VSC_Base() + _l1d_8ce772("27dedfd7e5f5f9f43f0005f1050451fb17fd5e1d07262a", 209, 41)
_l11I11l = HC_GetJson(_lIII11l, 8000)
_l1II11l = []
if _l11I11l <> invalid and _l11I11l.metas <> invalid and type(_l11I11l.metas) = _l1d_8ce772("c4b4ddcdd0c6d1", 234, 44) then
for each _llII11l in _l11I11l.metas
_lI1I11l = VSC_NormalizeItem(_llII11l, _l1d_8ce772("dbdce6e0df", 162, 12))
if _lI1I11l <> invalid and _lI1I11l.id <> "" then _l1II11l.Push(_lI1I11l)
end for
end if
return _l1II11l
end function
function VSC_FetchTrendingSeries() as Object
_llI1lIl = VSC_Base() + _l1d_8ce772("703f44324a40424d8847584c5a61569d596363a86f6b7274", 126, 31)
_lIl1lIl = HC_GetJson(_llI1lIl, 8000)
_l111lIl = []
if _lIl1lIl <> invalid and _lIl1lIl.metas <> invalid and type(_lIl1lIl.metas) = _l1d_8ce772("4a524353566c57", 222, 158) then
for each _lI11lIl in _lIl1lIl.metas
_ll11lIl = VSC_NormalizeItem(_lI11lIl, _l1d_8ce772("d7dc", 20, 119))
if _ll11lIl <> invalid and _ll11lIl.id <> "" then _l111lIl.Push(_ll11lIl)
end for
end if
return _l111lIl
end function
function VSC_FetchByGenre(_l11lIIl as String, _l1llIIl as String) as Object
_ll1lIIl = _l11lIIl
if _ll1lIIl = _l1d_8ce772("c9ce", 128, 213) then _ll1lIIl = _l1d_8ce772("536458766d62", 214, 174)
_l1IlIIl = VSC_Base() + _l1d_8ce772("72b9bab2c0c0c4cf8a", 25, 60) + _ll1lIIl + _l1d_8ce772("2b07f111370207ff1e105b", 206, 74) + U_UrlEncode(_l1llIIl) + _l1d_8ce772("054c484f51", 28, 211)
_llllIIl = HC_GetJson(_l1IlIIl, 7000)
_llIlIIl = []
if _llllIIl <> invalid and _llllIIl.metas <> invalid and type(_llllIIl.metas) = _l1d_8ce772("b4c4e9bdc0d2bd", 184, 234) then
for each _lI1lIIl in _llllIIl.metas
_lIllIIl = VSC_NormalizeItem(_lI1lIIl, _l11lIIl)
if _lIllIIl <> invalid and _lIllIIl.id <> "" then _llIlIIl.Push(_lIllIIl)
end for
end if
return _llIlIIl
end function
function VSC_FetchHomeRows() as Object
_lIlIll1 = VSC_FetchTrendingMovies()
_lI1Ill1 = VSC_FetchTrendingSeries()
_ll1Ill1 = []
if _lIlIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("87705c5a6361636db3896e8a767d96", 109, 78),
items: _lIlIll1
})
end if
if _lI1Ill1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("dd1b030b251d0d62f9fa6bfd393f2a29", 210, 91),
items: _lI1Ill1
})
end if
_l11Ill1 = VSC_FetchByGenre(_l1d_8ce772("f0f501fdf4", 69, 200), _l1d_8ce772("ffd2cb92fed4", 40, 132))
if _l11Ill1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("192c39001a42fe030424614b5361164c66667468767871", 3, 201),
items: _l11Ill1
})
end if
_l1I1ll1 = VSC_FetchByGenre(_l1d_8ce772("72738f7f86", 207, 208), _l1d_8ce772("f8d9e9e9e6e8", 38, 145))
if _l1I1ll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("1a3b2d4b484c0d0a133555465a6451535969", 151, 68),
items: _l1I1ll1
})
end if
_lllIll1 = VSC_FetchByGenre(_l1d_8ce772("989d999dac", 121, 132), _l1d_8ce772("d0f7f8f3f515", 68, 201))
if _lllIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("fad9dae5e7ef2904e80608", 104, 207),
items: _lllIll1
})
end if
_l1lIll1 = VSC_FetchByGenre(_l1d_8ce772("91928c96a5", 58, 58), _l1d_8ce772("a37f7f828888", 63, 44))
if _l1lIll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("507a60638369bac3c0578e7b959b9e9a8a8e", 80, 56),
items: _l1lIll1
})
end if
_lII1ll1 = VSC_FetchByGenre(_l1d_8ce772("1a1f3b1f2e", 169, 86), _l1d_8ce772("fed2dcdbead8e8e5e7", 126, 191))
if _lII1ll1.Count() > 0 then
_ll1Ill1.Push({
title: _l1d_8ce772("fc282a31283e363b3d767b7c204c4e5550", 194, 121),
items: _lII1ll1
})
end if
return _ll1Ill1
end function
function VSC_Search(_lIl1Il1 as String) as Object
_l1l1Il1 = []
if _lIl1Il1 = invalid or _lIl1Il1 = "" then return _l1l1Il1
_lI1lIl1 = U_UrlEncode(_lIl1Il1)
_lll1Il1 = VSC_Base() + _l1d_8ce772("4910150b1b191b26612627212b3a732f39317f364f4e3e524e86", 90, 212) + _lI1lIl1 + _l1d_8ce772("2e6d79787a", 34, 34)
_l111Il1 = VSC_Base() + _l1d_8ce772("531217271d2525206b3a2b413d3449804e46588c5b4c53655765b3", 71, 235) + _lI1lIl1 + _l1d_8ce772("af6e5a797b", 112, 81)
_lIIlIl1 = HC_GetJson(_lll1Il1, 6000)
_ll11Il1 = HC_GetJson(_l111Il1, 6000)
if _lIIlIl1 <> invalid and _lIIlIl1.metas <> invalid then
for each _llIlIl1 in _lIIlIl1.metas
_l1IlIl1 = VSC_NormalizeItem(_llIlIl1, _l1d_8ce772("070c18140b", 101, 255))
if _l1IlIl1 <> invalid then _l1l1Il1.Push(_l1IlIl1)
end for
end if
if _ll11Il1 <> invalid and _ll11Il1.metas <> invalid then
for each _llIlIl1 in _ll11Il1.metas
_l1IlIl1 = VSC_NormalizeItem(_llIlIl1, _l1d_8ce772("4d4e", 155, 94))
if _l1IlIl1 <> invalid then _l1l1Il1.Push(_l1IlIl1)
end for
end if
return _l1l1Il1
end function
function VSC_FetchSeriesDetails(_l1ll111 as String) as Object
_l1l1111 = VSC_Base() + _l1d_8ce772("7abbc6b8c889c0d5c5cfdecf9e", 152, 195) + _l1ll111 + _l1d_8ce772("b67d877e82", 229, 235)
_l11Il11 = HC_GetJson(_l1l1111, 8000)
_llIl111 = []
if _l11Il11 = invalid or _l11Il11.meta = invalid or _l11Il11.meta.videos = invalid then return _llIl111
_ll11111 = _l11Il11.meta.videos
_ll1Il11 = {}
for each _lIl1111 in _ll11111
_lI1l111 = 1
if _lIl1111.season <> invalid then _lI1l111 = _lIl1111.season
_llIIl11 = 1
if _lIl1111.number <> invalid then _llIIl11 = _lIl1111.number else if _lIl1111.episode <> invalid then _llIIl11 = _lIl1111.episode
_lIIIl11 = _l1d_8ce772("f9112b142b292bf3", 23, 167) + _llIIl11.ToStr()
if _lIl1111.name <> invalid and _lIl1111.name <> "" then _lIIIl11 = _lIl1111.name else if _lIl1111.title <> invalid and _lIl1111.title <> "" then _lIIIl11 = _lIl1111.title
_lIIl111 = ""
if _lIl1111.thumbnail <> invalid then _lIIl111 = _lIl1111.thumbnail
_lI1Il11 = ""
if _lIl1111.overview <> invalid then _lI1Il11 = _lIl1111.overview else if _lIl1111.description <> invalid then _lI1Il11 = _lIl1111.description
_l11l111 = _l1d_8ce772("25", 40, 202) + _lI1l111.ToStr()
if not _ll1Il11.DoesExist(_l11l111) then _ll1Il11[_l11l111] = []
_ll1Il11[_l11l111].Push({
season: _lI1l111,
episode: _llIIl11,
title: _lIIIl11,
thumbnail: _lIIl111,
description: _lI1Il11
})
end for
for each _ll1l111 in _ll1Il11
_l1Il111 = Mid(_ll1l111, 2).ToInt()
_l1IIl11 = _ll1Il11[_ll1l111]
_llIl111.Push({
number: _l1Il111,
label: _l1d_8ce772("eec3c2d7d6d88d", 32, 123) + _l1Il111.ToStr(),
episodes: _l1IIl11
})
end for
for _llll111 = 1 to _llIl111.Count() - 1
_lIll111 = _llll111
while _lIll111 > 0 and _llIl111[_lIll111].number < _llIl111[_lIll111 - 1].number
_lll1111 = _llIl111[_lIll111]
_llIl111[_lIll111] = _llIl111[_lIll111 - 1]
_llIl111[_lIll111 - 1] = _lll1111
_lIll111 = _lIll111 - 1
end while
end for
return _llIl111
end function
function VSC_FetchTitleMeta(_lI11I11 as String, _llI1I11 as String) as Object
if ((38704 - 4838 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lI11I11 = invalid or _lI11I11 = "" then return invalid
_lIlII11 = _l1d_8ce772("6364806877", 171, 157)
if _llI1I11 = _l1d_8ce772("afb4", 196, 255) or _llI1I11 = _l1d_8ce772("f8f1fffbfa07", 227, 104) then _lIlII11 = _l1d_8ce772("9c8da19f96ab", 70, 103)
_ll1II11 = VSC_Base() + _l1d_8ce772("f73843354d06", 60, 228) + _lIlII11 + _l1d_8ce772("3c", 229, 114) + _lI11I11 + _l1d_8ce772("e7aeb8afb3", 71, 126)
_ll11I11 = HC_GetJson(_ll1II11, 6000)
if _ll11I11 <> invalid and _ll11I11.meta <> invalid then
_l1I1I11 = _ll11I11.meta
_l1lII11 = ""
if _l1I1I11.name <> invalid and _l1I1I11.name <> "" then
_l1lII11 = _l1I1I11.name
else if _l1I1I11.title <> invalid and _l1I1I11.title <> "" then
_l1lII11 = _l1I1I11.title
end if
_lII1I11 = ""
if _l1I1I11.poster <> invalid and _l1I1I11.poster <> "" then
_lII1I11 = _l1I1I11.poster
else if Left(_lI11I11, 2) = _l1d_8ce772("a0a3", 115, 153) then
_lII1I11 = _l1d_8ce772("7c8b8e8d8d594f52939a91969ba868aca7bba9b5c3b180c6ccbebfc891dbd7dee8dae8a6edeee5f5f8b8", 131, 145) + _lI11I11 + _l1d_8ce772("70adb4c1", 24, 57)
end if
_lIl1I11 = ""
if _l1I1I11.background <> invalid and _l1I1I11.background <> "" then
_lIl1I11 = _l1I1I11.background
else
_lIl1I11 = _lII1I11
end if
_lI1II11 = ""
if _l1I1I11.year <> invalid then _lI1II11 = _l1I1I11.year.ToStr()
_lllII11 = _l1d_8ce772("3e3a53", 39, 46)
if _l1I1I11.imdbRating <> invalid and _l1I1I11.imdbRating <> "" then _lllII11 = _l1I1I11.imdbRating.ToStr()
return {
title: _l1lII11,
poster: _lII1I11,
backdrop: _lIl1I11,
year: _lI1II11,
rating: _lllII11,
description: _l1I1I11.description
}
end if
_l1l1I11 = _l1d_8ce772("05fe0c080714", 195, 85)
if _lIlII11 = _l1d_8ce772("4d3a544c435c", 5, 215) then _l1l1I11 = _l1d_8ce772("bfc4e0c4d3", 201, 27)
_l11II11 = VSC_Base() + _l1d_8ce772("c0010cfe0ecf", 184, 41) + _l1l1I11 + _l1d_8ce772("58", 150, 159) + _lI11I11 + _l1d_8ce772("02c9b3cace", 117, 167)
_l111I11 = HC_GetJson(_l11II11, 4000)
if _l111I11 <> invalid and _l111I11.meta <> invalid then
_l1I1I11 = _l111I11.meta
_l1lII11 = ""
if _l1I1I11.name <> invalid and _l1I1I11.name <> "" then
_l1lII11 = _l1I1I11.name
else if _l1I1I11.title <> invalid and _l1I1I11.title <> "" then
_l1lII11 = _l1I1I11.title
end if
_lII1I11 = ""
if _l1I1I11.poster <> invalid and _l1I1I11.poster <> "" then
_lII1I11 = _l1I1I11.poster
else if Left(_lI11I11, 2) = _l1d_8ce772("171a", 52, 215) then
_lII1I11 = _l1d_8ce772("4c6b6e6d6d291f22636a71767b88387c879b8985a39150a6ac9e9fa861bba7bec8bac876cdbec5c5c888", 139, 105) + _lI11I11 + _l1d_8ce772("bcfd04fd", 19, 128)
end if
_lIl1I11 = ""
if _l1I1I11.background <> invalid and _l1I1I11.background <> "" then _lIl1I11 = _l1I1I11.background else _lIl1I11 = _lII1I11
_lI1II11 = ""
if _l1I1I11.year <> invalid then _lI1II11 = _l1I1I11.year.ToStr()
_lllII11 = _l1d_8ce772("fbf50e", 70, 138)
if _l1I1I11.imdbRating <> invalid and _l1I1I11.imdbRating <> "" then _lllII11 = _l1I1I11.imdbRating.ToStr()
return {
title: _l1lII11,
poster: _lII1I11,
backdrop: _lIl1I11,
year: _lI1II11,
rating: _lllII11,
description: _l1I1I11.description
}
end if
return invalid
end function
function _l1d_8ce772(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function