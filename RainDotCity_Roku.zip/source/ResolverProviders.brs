function RP_ResolveGeneric(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll as String, _llII11lIIIII111II1lIIII1I1l1IllI1Il as String, _lllllIlIIll1III1lIl1llII1l111III1llIIIl as Object) as Object
_ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I = {}
if _llII11lIIIII111II1lIIII1I1l1IllI1Il <> "" then _ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I[_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("5df76dfd75e35dfd")] = _llII11lIIIII111II1lIIII1I1l1IllI1Il
_lllllI1I1llI1I1l1lll1I1lIlI1lll = HC_Get(_lllllIlIIll1III1lIl1llII1l111III1llIIIl, _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll, _ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I, 8000)
if _lllllI1I1llI1I1l1lll1I1lIlI1lll = invalid or _lllllI1I1llI1I1l1lll1I1lIlI1lll.body = "" then return invalid
_ll111lllI111Il1l1lII1IlI1lI1II1I1lI = _lllllI1I1llI1I1l1lll1I1lIlI1lll.body
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = _lllllI1I1llI1I1l1lll1I1lIlI1lll.finalUrl
if _llIIl111Illll1111ll111lllI11Il1l11ll11111ll = invalid or _llIIl111Illll1111ll111lllI11Il1l11ll11111ll = "" then _llIIl111Illll1111ll111lllI11Il1l11ll11111ll = _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("2fd2a8da12371c50"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("29a56eb075bd49f857e450e95e") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("492fc9ced306b7f292eccc05258ebfbaef") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("4a29dde2e77ad3e61c31"), Chr(105))
_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = _llI1Il1l1IIlIl111IllII1lI11l1III11llIll.match(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
if _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l <> invalid and _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l.Count() >= 2 then
return {
url: _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l[1]
streamFormat: _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("46528153")
qualities: []
subtitles: RP_ExtractSubs(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
chapters: []
referer: _llII11lIIIII111II1lIIII1I1l1IllI1Il
userAgent: ""
}
end if
_llll11IlIlI1I1IlllllI1Il11l1llllIlIl11I1l1I = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7c66aabddea52c38"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("71fc29c63f299bbe7fdd36d111") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("54f428fd33db41b12ccf59f54fa82f94") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("64e39494a78daf5788e1"), Chr(105))
_llI1lllIl111I1IlIII1111lIlII1llllll11II = _llll11IlIlI1I1IlllllI1Il11l1llllIlIl11I1l1I.match(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
if _llI1lllIl111I1IlIII1111lIlII1llllll11II <> invalid and _llI1lllIl111I1IlIII1111lIlII1llllll11II.Count() >= 2 then
return {
url: _llI1lllIl111I1IlIII1111lIlII1llllll11II[1]
streamFormat: _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7c707f0f")
qualities: []
subtitles: RP_ExtractSubs(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
chapters: []
referer: _llII11lIIIII111II1lIIII1I1l1IllI1Il
userAgent: ""
}
end if
return invalid
end function
function RP_ExtractSubs(_lllIIlIlII1ll111l1Il11Illlll11l11I1 as String) as Object
_llI1111ll111IlllIlI111lII1IIlIl = []
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = invalid or _lllIIlIlII1ll111l1Il11Illlll11l11I1 = "" then return _llI1111ll111IlllIlI111lII1IIlIl
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7b1030f63031362c"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4e8a4d3c3f3e429191a7aa3941") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4e872124273f8f2fa036aba8a0a05f60636e666a6fc5c8"), (Chr(105) + Chr(103)))
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l.matchAll(_lllIIlIlII1ll111l1Il11Illlll11l11I1)
if _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = invalid then return _llI1111ll111IlllIlI111lII1IIlIl
for each _llI1lIlIIIlllI1I11Il1I11IlI11Il in _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I
if _llI1lIlIIIlllI1I11Il1I11IlI11Il.Count() < 2 then continue for
_llI11Il1II1I1lI1II11I1111II1lIl = _llI1lIlIIIlllI1I11Il1I11IlI11Il[1]
_llll1I11llIlll11lII11l11111IIIl = (Chr(101) + Chr(110))
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("28a8dcb4466b5026"), _llllIllII1II1I1ll1lll1lIlIII11I("4f3a82846c6e2658bc85558c6fe8996385cdc2d4bcbe"), Chr(105))
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _llI111lI11I1l11lI11l1lIlll11111lIIlI1II.match(_llI11Il1II1I1lI1II11I1111II1lIl)
if _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII <> invalid and _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII.Count() >= 2 then _llll1I11llIlll11lII11l11111IIIl = LCase(_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII[1])
_llI1111ll111IlllIlI111lII1IIlIl.Push({ url: _llI11Il1II1I1lI1II11I1111II1lIl, language: _llll1I11llIlll11lII11l11111IIIl, name: UCase(_llll1I11llIlll11lII11l11111IIIl) })
end for
return _llI1111ll111IlllIlI111lII1IIlIl
end function
function RP_ResolveVidsrcCc(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il as String, _ll1llllIllI1l1Il1l1IlIlIIIIl1lIlII1 as String, _ll1l1IlIlll1ll1IIl111lllIlII11IIll1 as Object) as Object
_ll1ll1II11IIlIIll1lII1I111IlI1ll1Illl1Illl1 = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5d9ee2c513db43bc"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("5c747b046414b86cb43d137baa8f5e3b3a6cbbcba95661ce16f77e6d60c462167c2a99fd9be1b051b1e41b0e7208961d0c376b018f76f8"), Chr(105))
m = _ll1ll1II11IIlIIll1lII1I111IlI1ll1Illl1Illl1.match(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il)
if m = invalid or m.Count() < 3 then return invalid
_llI1lIl1l1III111ll1l1l1l11I1llI11lII1I1 = m[1]
_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = m[2]
_ll1l11Ill1lIl1lI11II1I1IlllIllII1lIllll11l1 = ""
_llIll1IIIII1ll1l11III111lIII1ll = ""
if m.Count() >= 5 then
_ll1l11Ill1lIl1lI11II1I1IlllIllII1lIllll11l1 = m[3]
_llIll1IIIII1ll1l11III111lIII1ll = m[4]
end if
_llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l = HC_OriginOf(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il)
if _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l = "" then return invalid
if _llI1lIl1l1III111ll1l1l1l11I1llI11lII1I1 = (Chr(116) + Chr(118)) and _ll1l11Ill1lIl1lI11II1I1IlllIllII1lIllll11l1 <> "" and _llIll1IIIII1ll1l11III111lIII1ll <> "" then
_llIl1ll111l11l1111Ill1lll1IIllI = _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l + _llllIllII1II1I1ll1lll1lIlIII11I("67a5c6ba50b91ace6408ce2338e1") + _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 + Chr(47) + _ll1l11Ill1lIl1lI11II1I1IlllIllII1lIllll11l1 + Chr(47) + _llIll1IIIII1ll1l11III111lIII1ll + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2473b2c3b9b8ccc2c4")
else
_llIl1ll111l11l1111Ill1lll1IIllI = _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5fe5a6b8b4f1aec4c0c9c0bcc009") + _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("35e918251d1c2e262a")
end if
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = {
"Referer": _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il
"Origin": _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l
"Accept": _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("336c2565226917621976180e525244774e2c4571af65bc37d822d233de08dd1bd327")
"X-Requested-With": _llllIllII1II1I1ll1lll1lIlIII11I("74e2162bf0b4b97ea5b77dc2c6ace1")
}
_llIlllIlII1III1llll11IIIIIl1l1IlIIIlI1I = HC_Get(_ll1l1IlIlll1ll1IIl111lllIlII11IIll1, _llIl1ll111l11l1111Ill1lll1IIllI, _lllIIllll1llIIlllIllI11lll1ll1lIl11, 8000)
if _llIlllIlII1III1llll11IIIIIl1l1IlIIIlI1I = invalid or _llIlllIlII1III1llll11IIIIIl1l1IlIIIlI1I.body = "" then return invalid
_ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II = ParseJSON(_llIlllIlII1III1llll11IIIIIl1l1IlIIIlI1I.body)
if _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II = invalid or type(_ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II) <> _llllIllII1II1I1ll1lll1lIlIII11I("5f23f71a42470b50b53a70c49a8e51696e62e8") then return invalid
_ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = invalid
if _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II.data <> invalid then _ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II.data
if (_ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = invalid or type(_ll1llIlIIlII1I1llll1Il1llllIllI1ll1) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6994a4c99da0b29d")) and _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II.servers <> invalid then _ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II.servers
if _ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = invalid or type(_ll1llIlIIlII1I1llll1Il1llllIllI1ll1) <> _llllIllII1II1I1ll1lll1lIlIII11I("3a0b41241a1f35b9") then return invalid
for each _ll11IlllllI11Il11llI1lllll1III1lIIlI111 in _ll1llIlIIlII1I1llll1Il1llllIllI1ll1
if type(_ll11IlllllI11Il11llI1lllll1III1lIIlI111) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("5b9acd29c3cef9641f6acd40f376a2343fc20d") then continue for
_ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = ""
if _ll11IlllllI11Il11llI1lllll1III1lIIlI111.hash <> invalid then _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = _ll11IlllllI11Il11llI1lllll1III1lIIlI111.hash
if _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = "" and _ll11IlllllI11Il11llI1lllll1III1lIIlI111.data_id <> invalid then _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = _ll11IlllllI11Il11llI1lllll1III1lIIlI111.data_id
if _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = "" and _ll11IlllllI11Il11llI1lllll1III1lIIlI111.id <> invalid then _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = _ll11IlllllI11Il11llI1lllll1III1lIIlI111.id
if _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = "" then continue for
_lllIl11IIIll11l1lIIIlI1lII111ll111I = _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l + _llllIllII1II1I1ll1lll1lIlIII11I("5260495dd3743c82265b513697") + _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II
_llIIIlI1ll1IIlIlIl1I111111II1IIlll11llll11I = HC_Get(_ll1l1IlIlll1ll1IIl111lllIlII11IIll1, _lllIl11IIIll11l1lIIIlI1lII111ll111I, _lllIIllll1llIIlllIllI11lll1ll1lIl11, 8000)
if _llIIIlI1ll1IIlIlIl1I111111II1IIlll11llll11I = invalid or _llIIIlI1ll1IIlIlIl1I111111II1IIlll11llll11I.body = "" then continue for
_lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1 = ParseJSON(_llIIIlI1ll1IIlIlIl1I111111II1IIlll11llll11I.body)
if _lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1 = invalid or type(_lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("7ead502cc6d17c67a26de0c30679a54752c590") then continue for
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = invalid
if _lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1.data <> invalid and type(_lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1.data) = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("31b4b4c9bec1c0b7c0bbd1c9d9cbeadee1d3ee") then
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1.data
else
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1
end if
_ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = ""
if _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.stream <> invalid then _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = RP_AsStreamString(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.stream)
if _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = "" and _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.source <> invalid then _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = RP_AsStreamString(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.source)
if _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = "" and _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.file <> invalid then _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = RP_AsStreamString(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.file)
if _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = "" and _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.url <> invalid then _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = RP_AsStreamString(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.url)
if _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = "" then continue for
_llIlIl1l1I1IlllIlIIl11Il11I11II = []
_ll1lIlI1II11IIllI1Il1lII111l1II = invalid
if _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.subtitles <> invalid then _ll1lIlI1II11IIllI1Il1lII111l1II = _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.subtitles
if _ll1lIlI1II11IIllI1Il1lII111l1II = invalid and _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.captions <> invalid then _ll1lIlI1II11IIllI1Il1lII111l1II = _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.captions
if _ll1lIlI1II11IIllI1Il1lII111l1II <> invalid and type(_ll1lIlI1II11IIllI1Il1lII111l1II) = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7d545c495d60725d") then
for each _ll1IIlIII111II1llllI1I11lII11lll111l1ll in _ll1lIlI1II11IIllI1Il1lII111l1II
if type(_ll1IIlIII111II1llllI1I11lII11lll111l1ll) <> _llllIllII1II1I1ll1lll1lIlIII11I("39774bb2969b5fa449ce0458ee22e9bdc2f67c") then continue for
_ll1IIIlIl1Il1IIlll1IIllIl1111ll = ""
if _ll1IIlIII111II1llllI1I11lII11lll111l1ll.file <> invalid then _ll1IIIlIl1Il1IIlll1IIllIl1111ll = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.file
if _ll1IIIlIl1Il1IIlll1IIllIl1111ll = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.url <> invalid then _ll1IIIlIl1Il1IIlll1IIllIl1111ll = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.url
if _ll1IIIlIl1Il1IIlll1IIllIl1111ll = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.src <> invalid then _ll1IIIlIl1Il1IIlll1IIllIl1111ll = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.src
if _ll1IIIlIl1Il1IIlll1IIllIl1111ll = "" then continue for
_llIIlllI1l11lI111IIII1IIl111lIII1IllllI = (Chr(101) + Chr(110))
if _ll1IIlIII111II1llllI1I11lII11lll111l1ll.language <> invalid then _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = LCase(Left(_ll1IIlIII111II1llllI1I11lII11lll111l1ll.language, 2))
if _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.lang <> invalid then _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = LCase(Left(_ll1IIlIII111II1llllI1I11lII11lll111l1ll.lang, 2))
if _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.label <> invalid then _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = LCase(Left(_ll1IIlIII111II1llllI1I11lII11lll111l1ll.label, 2))
_llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = ""
if _ll1IIlIII111II1llllI1I11lII11lll111l1ll.label <> invalid then _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.label
if _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.language <> invalid then _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.language
if _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = "" then _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("66e2c1e5b2372204b76b")
_llIlIl1l1I1IlllIlIIl11Il11I11II.Push({ url: _ll1IIIlIl1Il1IIlll1IIllIl1111ll, language: _llIIlllI1l11lI111IIII1IIl111lIII1IllllI, name: _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I })
end for
end if
return {
url: _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il
streamFormat: U_StreamFormat(_ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il)
qualities: []
subtitles: _llIlIl1l1I1IlllIlIIl11Il11I11II
chapters: []
referer: _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il
userAgent: ""
}
end for
return invalid
end function
function RP_AsStreamString(_lll1I11l1Il1llllI11llI111lIlI1l as Dynamic) as String
if _lll1I11l1Il1llllI11llI111lIlI1l = invalid then return ""
if type(_lll1I11l1Il1llllI11llI111lIlI1l) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("57b32e34fef101") or type(_lll1I11l1Il1llllI11llI111lIlI1l) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3b7f668925d2e2f000") then return _lll1I11l1Il1llllI11llI111lIlI1l
if type(_lll1I11l1Il1llllI11llI111lIlI1l) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4fada7382768b898") then
if _lll1I11l1Il1llllI11llI111lIlI1l.Count() = 0 then return ""
_llllI1lI1ll11l1lI1IlIll1II1lI11 = _lll1I11l1Il1llllI11llI111lIlI1l[0]
if type(_llllI1lI1ll11l1lI1IlIll1II1lI11) = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4791b1b6a4a0ac") or type(_llllI1lI1ll11l1lI1IlIll1II1lI11) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5595ce16c070c31ce7") then return _llllI1lI1ll11l1lI1IlIll1II1lI11
if type(_llllI1lI1ll11l1lI1IlIll1II1lI11) = _llllIllII1II1I1ll1lll1lIlIII11I("53075bfe262b6f34991ed4a8fef2354d5246cc") then
if _llllI1lI1ll11l1lI1IlIll1II1lI11.file <> invalid then return _llllI1lI1ll11l1lI1IlIll1II1lI11.file
if _llllI1lI1ll11l1lI1IlIll1II1lI11.url <> invalid then return _llllI1lI1ll11l1lI1IlIll1II1lI11.url
end if
end if
return ""
end function
function RP_ResolveAirflix(_lll1lIl1IlIlI1lIl1111Il11l1lll1 as String, _ll11l111I1I1lllll1II1lIIIIlIIlI111llII1 as String, _lll1Illl1IIl1llI11l1I1lllI1I11I1IlI1lll as Object) as Object
_llIll11IIl11III111II11l1lI1I11l = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4022e67912d96ffc"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("2d548695b4472764c56747117684da10fbd69645b880925507231315e414d4e20857d54836d75765c7a88745659508"), Chr(105))
m = _llIll11IIl11III111II11l1lI1I11l.match(_lll1lIl1IlIlI1lIl1111Il11l1lll1)
if m = invalid or m.Count() < 3 then return invalid
_llIl1l1I1IlII1l1l1IlI1IIll1IIlI = m[1]
_ll1IlllII1111lI1lI111lIllIl111Il1l1l11IIl1I = m[2]
_lll11lll1lIllIll1I11lIlllIllIlIl1lll1lllII1 = ""
_lllII1lII1IlIIIIIIll1II1ll1Illl = ""
if m.Count() >= 5 then
_lll11lll1lIllIll1I11lIlllIllIlIl1lll1lllII1 = m[3]
_lllII1lII1IlIIIIIIll1II1ll1Illl = m[4]
end if
_llI1I1lIl1llI1IIIIlIl11Il111lIl111IIl1llIl1 = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("71b440c31d")
if Left(_ll1IlllII1111lI1lI111lIllIl111Il1l1l11IIl1I, 2) = (Chr(116) + Chr(116)) then _llI1I1lIl1llI1IIIIlIl11Il111lIl111IIl1llIl1 = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("223f297ab5")
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _llllIllII1II1I1ll1lll1lIlIII11I("7b0b4f5499ce3f151ae277dc92d71c91e69af041c9fff3390e92d82c6e36eb8d362ac09139bf43b4") + _llI1I1lIl1llI1IIIIlIl11Il111lIl111IIl1llIl1 + Chr(61) + U_UrlEncode(_ll1IlllII1111lI1lI111lIllIl111Il1l1l11IIl1I) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("35836087729b15") + _llIl1l1I1IlII1l1l1IlI1IIll1IIlI
if _llIl1l1I1IlII1l1l1IlI1IIll1IIlI = (Chr(116) + Chr(118)) and _lll11lll1lIllIll1I11lIlllIllIlIl1lll1lllII1 <> "" and _lllII1lII1IlIIIIIIll1II1ll1Illl <> "" then
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _lllI1l1l1I1lIIlI1llI1I111IlI111 + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3b3fd41e6450b4b5ca") + _lll11lll1lIllIll1I11lIlllIllIlIl1lll1lllII1 + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("316e6e5aacf94c1f0d2b") + _lllII1lII1IlIIIIIIll1II1ll1Illl
end if
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("2fdd34d42bde5dc2468a4aee4de440d646c042d3a8d8b0d29bc09694d0e1ddba")
_llIlllllll1lllll1l1I1II1I11IIlIIlIl11l1 = HC_Get(_lll1Illl1IIl1llI11l1I1lllI1I11I1IlI1lll, _lllI1l1l1I1lIIlI1llI1I111IlI111, {
"Referer": _ll1lIIII11l1Ill1lIII111lIIIlIl1111l
"Origin": _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7719f1a61f0cf39cb2bf7abe150197a644d5d2ead62e2fbc5615e8acb62fa4")
}, 8000)
if _llIlllllll1lllll1l1I1II1I11IIlIIlIl11l1 = invalid or _llIlllllll1lllll1l1I1II1I11IIlIIlIl11l1.body = "" then return invalid
_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = ParseJSON(_llIlllllll1lllll1l1I1II1I11IIlIIlIl11l1.body)
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = invalid or type(_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("79177c7aea34c169937b482f1b1f3f57a0a40c") then return invalid
_ll11I1lllIIIlllIIIIIII1I1IIlllIl1II = ""
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.status_code <> invalid then _ll11I1lllIIIlllIIIIIII1I1IIlllIl1II = _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.status_code.ToStr()
if _ll11I1lllIIIlllIIIIIII1I1IIlllIl1II <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("52f525c5") then return invalid
_llI11IIIlIII111IIl111I1IIIl11llIl11Illl = _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.data
if _llI11IIIlIII111IIl111I1IIIl11llIl11Illl = invalid or type(_llI11IIIlIII111IIl111I1IIIl11llIl11Illl) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("267dc5b15b3a8b4afd25afc73123f52314ef97") then return invalid
_llIllIlIIIIll1l11lIlI1111l11lll = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.stream_urls
if _llIllIlIIIIll1l11lIlI1111l11lll = invalid or type(_llIllIlIIIIll1l11lIlI1111l11lll) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("77d0d809d9dcf2dd") or _llIllIlIIIIll1l11lIlI1111l11lll.Count() = 0 then return invalid
_ll1llIllII11I1lI1III1llll1l1Il1l1I1lI1IlI1l = []
_ll1ll11l1l1II1l1l111111II1lll1lIl11Illl = {}
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = []
_ll1ll1I1l1lIIlllIII1l1IlIllllII11lIlll1 = [_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.subs, _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.subs, _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.default_subs, _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.default_subs]
for each _llIIlII1111Ill111Il1II1lIIII1lIl11I1I1III1l in _ll1ll1I1l1lIIlllIII1l1IlIllllII11lIlll1
if _llIIlII1111Ill111Il1II1lIIII1lIl11I1I1III1l = invalid or type(_llIIlII1111Ill111Il1II1lIIII1lIl11I1I1III1l) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("5c7226eaeed568cc") then continue for
for each _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1 in _llIIlII1111Ill111Il1II1lIIII1lIl11I1I1III1l
if type(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6dd13cb80cf699834abdecce5e5ac5917a46a3") then continue for
_llI1I11l1lIIl11lllll1Il1l1lIllI = ""
if _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.url <> invalid then _llI1I11l1lIIl11lllll1Il1l1lIllI = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.url
if _llI1I11l1lIIl11lllll1Il1l1lIllI = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.file <> invalid then _llI1I11l1lIIl11lllll1Il1l1lIllI = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.file
if _llI1I11l1lIIl11lllll1Il1l1lIllI = "" then continue for
if _ll1ll11l1l1II1l1l111111II1lll1lIl11Illl.DoesExist(_llI1I11l1lIIl11lllll1Il1l1lIllI) then continue for
_ll1ll11l1l1II1l1l111111II1lll1lIl11Illl[_llI1I11l1lIIl11lllll1Il1l1lIllI] = true
_ll111IlIlll1lI1l1ll11l11I1I1lII = ""
if _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.code <> invalid then _ll111IlIlll1lI1l1ll11l11I1I1lII = LCase(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.code)
if _ll111IlIlll1lI1l1ll11l11I1I1lII = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.language <> invalid then _ll111IlIlll1lI1l1ll11l11I1I1lII = LCase(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.language)
if _ll111IlIlll1lI1l1ll11l11I1I1lII = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang <> invalid and Len(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang) >= 2 then _ll111IlIlll1lI1l1ll11l11I1I1lII = LCase(Left(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang, 2))
if _ll111IlIlll1lI1l1ll11l11I1I1lII = "" then _ll111IlIlll1lI1l1ll11l11I1I1lII = (Chr(101) + Chr(110))
_lll1I1llIlll1I1l111llll111lll1lIl1l11II = ""
if _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.label <> invalid then _lll1I1llIlll1I1l111llll111lll1lIl1l11II = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.label
if _lll1I1llIlll1I1l111llll111lll1lIl1l11II = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang <> invalid then _lll1I1llIlll1I1l111llll111lll1lIl1l11II = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang
if _lll1I1llIlll1I1l111llll111lll1lIl1l11II = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.language <> invalid then _lll1I1llIlll1I1l111llll111lll1lIl1l11II = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.language
if _lll1I1llIlll1I1l111llll111lll1lIl1l11II = "" then _lll1I1llIlll1I1l111llll111lll1lIl1l11II = UCase(_ll111IlIlll1lI1l1ll11l11I1I1lII)
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l.Push({ url: _llI1I11l1lIIl11lllll1Il1l1lIllI, language: _ll111IlIlll1lI1l1ll11l11I1I1lII, name: _lll1I1llIlll1I1l111llll111lll1lIl1l11II })
end for
end for
for each _lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll in _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
if _lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll.language = (Chr(101) + Chr(110)) then _ll1llIllII11I1lI1III1llll1l1Il1l1I1lI1IlI1l.Push(_lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll)
end for
for each _lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll in _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
if _lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll.language <> (Chr(101) + Chr(110)) then _ll1llIllII11I1lI1III1llll1l1Il1l1I1lI1IlI1l.Push(_lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll)
end for
for each _lllIIlIIl1IIIIII1IIl11Il1IIlIII in _llIllIlIIIIll1l11lIlI1111l11lll
if type(_lllIIlIIl1IIIIII1IIl11Il1IIlIII) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3d8ee737d960f9") and type(_lllIIlIIl1IIIIII1IIl11Il1IIlIII) <> _llllIllII1II1I1ll1lll1lIlIII11I("6f8e64a6bda2186d02") then continue for
if _lllIIlIIl1IIIIII1IIl11Il1IIlIII = "" then continue for
_llIIIllllI11I1llI11lII11II11l1I = HC_Get(_lll1Illl1IIl1llI11l1I1lllI1I11I1IlI1lll, _lllIIlIIl1IIIIII1IIl11Il1IIlIII, { "Referer": _ll1lIIII11l1Ill1lIII111lIIIlIl1111l }, 6000)
if _llIIIllllI11I1llI11lII11II11l1I = invalid or _llIIIllllI11I1llI11lII11II11l1I.body = "" then continue for
if Left(_llIIIllllI11I1llI11lII11II11l1I.body, 7) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("334f43f003af41fd") then continue for
return {
url: _lllIIlIIl1IIIIII1IIl11Il1IIlIII
streamFormat: _llllIllII1II1I1ll1lll1lIlIII11I("5b25eade")
qualities: []
subtitles: _ll1llIllII11I1lI1III1llll1l1Il1l1I1lI1IlI1l
chapters: []
referer: _ll1lIIII11l1Ill1lIII111lIIIlIl1111l
userAgent: ""
}
end for
return invalid
end function
function RP_HlsLeadSkip(_llIIIll1lI1II1l1I1I1IIIII1II1lI as Object, _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 as String, _ll1llIl11ll1l1lllIl1l1I11ll1llI as String, _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 as String) as Integer
if _ll1llIl11ll1l1lllIl1l1I11ll1llI = "" then return 0
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11
_lll1IllIIII1lll11l1l1IllIlllII1l1I111ll = _ll1llIl11ll1l1lllIl1l1I11ll1llI
if _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = "" then
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = HC_Get(_llIIIll1lI1II1l1I1I1IIIII1II1lI, _lll1IllIIII1lll11l1l1IllIlllII1l1I111ll, { "Referer": _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 }, 5000)
if _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = invalid or _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI.body = "" then return 0
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI.body
end if
if Left(_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill, 7) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("39572a57beb75912") then return 0
if Instr(1, _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill, _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5784fe8992e7c2945009a10f1c6dc6ed5ecc")) <= 0 then
return RP_ProbeMediaPlaylist(_llIIIll1lI1II1l1I1I1IIIII1II1lI, _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill, _lll1IllIIII1lll11l1l1IllIlllII1l1I111ll, _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1)
end if
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = 0
for each line in _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.Tokenize(Chr(10))
_lll11IIl1lIl11lI111I11lllIl1I11 = U_Trim(line)
if _lll11IIl1lIl11lI111I11lllIl1I11 = "" then continue for
if Left(_lll11IIl1lIl11lI111I11lllIl1I11, 1) = Chr(35) then continue for
_llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI = U_AbsUrl(_lll11IIl1lIl11lI111I11lllIl1I11, HC_OriginOf(_lll1IllIIII1lll11l1l1IllIlllII1l1I111ll))
if _llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI = "" then continue for
_lllI11lll11I1lIlIIl11llIllIII111Ill = HC_Get(_llIIIll1lI1II1l1I1I1IIIII1II1lI, _llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI, { "Referer": _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 }, 5000)
if _lllI11lll11I1lIlIIl11llIllIII111Ill <> invalid and _lllI11lll11I1lIlIIl11llIllIII111Ill.body <> "" and Left(_lllI11lll11I1lIlIIl11llIllIII111Ill.body, 7) = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("662c073810285147") then
_lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 = RP_ProbeMediaPlaylist(_llIIIll1lI1II1l1I1I1IIIII1II1lI, _lllI11lll11I1lIlIIl11llIllIII111Ill.body, _llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI, _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1)
if _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 > 0 then return _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1
end if
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I + 1
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I >= 8 then exit for
end for
return 0
end function
function RP_ProbeMediaPlaylist(_ll1IlI11II1Il1ll1Ill1ll1lIIIlII as Object, _ll1lllIIlll11l1IlIlIlI1I11lIl1lI111 as String, _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1 as String, _ll11lII1l11l1111lIllI11lIll11I11lllI1Il as String) as Integer
_llIIII1I1lII1IIIIIII111l1lI1l1I = 0.0
_ll1lIl1l1llllIII1l1llII1I1III1I = ""
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII = 0.0
_llI1111l1I1l11I1lIl1lllII1III1l1llll1ll = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("2c4136751a7e276a"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("5a043b102c041405731e070c1101094b7450"), Chr(105))
for each line in _ll1lllIIlll11l1IlIlIlI1I11lIl1lI111.Tokenize(Chr(10))
_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl = U_Trim(line)
if _llII1Illl1IlI1lI11IlIII1lIlll1I1lIl = "" then continue for
if Left(_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl, 1) = Chr(35) then
_ll11lIl11l1ll1Ill1II1IllIlIllII = _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll.match(_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl)
if _ll11lIl11l1ll1Ill1II1IllIlIllII <> invalid and _ll11lIl11l1ll1Ill1II1IllIlIllII.Count() >= 2 then _ll111111lI1Il11lII111lllllIII1lIlI11II1lIII = Val(_ll11lIl11l1ll1Ill1II1IllIlIllII[1])
continue for
end if
_ll1lIl1l1llllIII1l1llII1I1III1I = U_AbsUrl(_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl, HC_OriginOf(_lllII1Il1lIIlllIlIll1llIllI1I1I1lI1))
_llIIII1I1lII1IIIIIII111l1lI1l1I = _ll111111lI1Il11lII111lllllIII1lIlI11II1lIII
exit for
end for
if _ll1lIl1l1llllIII1l1llII1I1III1I = "" then return 0
_llIIII1III11l1I1111Il1lIlI1IIlI11lI = HC_GetRange(_ll1IlI11II1Il1ll1Ill1ll1lIIIlII, _ll1lIl1l1llllIII1l1llII1I1III1I, { "Referer": _ll11lII1l11l1111lIllI11lIll11I11lllI1Il }, _llIIlIll1llIlII1lI1lIlI1l1lI111("2a6194078a05de11741f"), 5000)
if _llIIII1III11l1I1111Il1lIlI1IIlI11lI = invalid then return 0
if _llIIII1III11l1I1111Il1lIlI1IIlI11lI.status <= 0 then return 0
if Len(_llIIII1III11l1I1111Il1lIlI1IIlI11lI.body) > 0 then return 0
_llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl = Int(_llIIII1I1lII1IIIIIII111l1lI1l1I + 0.999) + 2
if _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl < 4 then _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl = 8
if _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl > 30 then _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl = 30
return _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl
end function
function RP_VidrockEncrypt(_llll111lllllI111l1lllII11lllIlI as String, _llIIl1II11lIlIlIlI1II1IIll11lll11l1l1IIIIll as String, _ll1lIIIllllll1l11l1lIlI11l1l1l1IIll11Il as String) as String
_llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2aac62d4626df1b1ec3acac8"))
_lllllI1I1IIIl1Il1I11ll1l1ll111II1ll1lll1IIl = _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1.Setup(true, _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6544665b234d1b471b001d78"), _llIIl1II11lIlIlIlI1II1IIll11lll11l1l1IIIIll, _ll1lIIIllllll1l11l1lIlI11l1l1l1IIll11Il, 1)
if _lllllI1I1IIIl1Il1I11ll1l1ll111II1ll1lll1IIl <> 0 then return ""
_lllI1111II1lIIll1llIl11Il1111IlI111IIlI = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("2b4679dd1f42d501939e216c"))
_lllI1111II1lIIll1llIl11Il1111IlI111IIlI.FromAsciiString(_llll111lllllI111l1lllII11lllIlI)
_ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("36ac60b34b2014d7cfd4e86e"))
_ll11Illl11I1llllII1l11IIlll1l11lIllIIIl = _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1.Process(_lllI1111II1lIIll1llIl11Il1111IlI111IIlI)
if _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl <> invalid then
for _lllII1ll1ll1l1l1llI1IlIIlIlIllIlII1lII11l1I = 0 to _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl.Count() - 1
_ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il.Push(_ll11Illl11I1llllII1l11IIlll1l11lIllIIIl[_lllII1ll1ll1l1l1llI1IlIIlIlIllIlII1lII11l1I])
end for
end if
_llIl1lII11llllIll1Ill11lI1I11lllI11 = _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1.Final()
if _llIl1lII11llllIll1Ill11lI1I11lllI11 <> invalid then
for _lllII1ll1ll1l1l1llI1IlIIlIlIllIlII1lII11l1I = 0 to _llIl1lII11llllIll1Ill11lI1I11lllI11.Count() - 1
_ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il.Push(_llIl1lII11llllIll1Ill11lI1I11lllI11[_lllII1ll1ll1l1l1llI1IlIIlIlIllIlII1lII11l1I])
end for
end if
if _ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il.Count() = 0 then return ""
_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il.ToBase64String()
_ll1Il1IlI1I11I1ll1IlI1I1ll1llIl1l1I1II1lIIl = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("54a74abe302b4639"), (Chr(92) + Chr(43)), "")
_llIlll1l111lIIl111lI111Il11IIlI = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2f3bd28303c85110"), Chr(47), "")
_ll1IlIl1ll1lIllI11l1l11l1llII1l = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("2baf319b1d902084"), _llIIlIll1llIlII1lI1lIlI1l1lI111("54cd682b"), "")
_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1 = _ll1Il1IlI1I11I1ll1IlI1I1ll1llIl1l1I1II1lIIl.ReplaceAll(_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1, Chr(45))
_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1 = _llIlll1l111lIIl111lI111Il11IIlI.ReplaceAll(_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1, Chr(95))
_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1 = _ll1IlIl1ll1lIllI11l1l11l1llII1l.ReplaceAll(_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1, "")
return _llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1
end function
function RP_ResolveVidrock(_llI11II111lIIll111II11l11II1Il1lI1ll1lI as String, _lll111lIllI1I1III1I1lI1l11Il1Il as String, _llII11IlllI1llI11II1111l1ll11IlIlIl as Object) as Object
_llII11l1111l1ll111l1l1l1111I1111Ill1lllll1I = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("3a947aba868b8c9c"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("635d5d5351332e323c3e78796e7e4647414b5a444f509a9f9f3671a75f6a6d4883b9bec0b6b4cccc639ed4d9dede75b0e6ebeee3"), Chr(105))
m = _llII11l1111l1ll111l1l1l1111I1111Ill1lllll1I.match(_llI11II111lIIll111II11l11II1Il1lI1ll1lI)
if m = invalid or m.Count() < 3 then return invalid
_lllI1llIlIIlIIIIIIl1lllII1111l1 = m[1]
_llI111l111lII1lIIIlIl1II1Il1ll1 = m[2]
_ll1II1llIIlIl1IlIlIIIlI11IIIllI = ""
_llIIllllllIII1lIIIII1l1Il1IlIIl = ""
if m.Count() >= 5 then
_ll1II1llIIlIl1IlIlIIIlI11IIIllI = m[3]
_llIIllllllIII1lIIIII1l1Il1IlIIl = m[4]
end if
_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("40634cfc2ddd7c61191fc9712e80aaf098dd8e")
if _lllI1llIlIIlIIIIIIl1lllII1111l1 = (Chr(116) + Chr(118)) and _ll1II1llIIlIl1IlIlIIIlI11IIIllI <> "" and _llIIllllllIII1lIIIII1l1Il1IlIIl <> "" then
_llIl1IllI11II1llI11IlllI1ll11llIlIl = _llI111l111lII1lIIIlIl1II1Il1ll1 + Chr(95) + _ll1II1llIIlIl1IlIlIIIlI11IIIllI + Chr(95) + _llIIllllllIII1lIIIII1l1Il1IlIIl
else
_llIl1IllI11II1llI11IlllI1ll11llIlIl = _llI111l111lII1lIIIlIl1II1Il1ll1
end if
_llI11111I1lllI11I1l11I1lIlll1I1IlI11l1l = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("54e45ce643ee28b639b06c9862866bbb61a567a999a784aebea4b5b7b5c1ec8de2b6e3bcfcb304ba1fb64bde42c248bb4dae1ff525f86fa6c2fec2e59b8cc5c3c4")
_ll1lI1III1llIIl1II1lIIllII1I1Ill11I  = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4cf7706573d2b189a175fbf312c10816f5258bda796f567ddcb29b410176a44313")
_llIlllII1lIl1l1I1l1111llI11lI11lIll = RP_VidrockEncrypt(_llIl1IllI11II1llI11IlllI1ll11llIlIl, _llI11111I1lllI11I1l11I1lIlll1I1IlI11l1l, _ll1lI1III1llIIl1II1lIIllII1I1Ill11I)
if _llIlllII1lIl1l1I1l1111llI11lI11lIll = "" then return invalid
if _lllI1llIlIIlIIIIIIl1lllII1111l1 = (Chr(116) + Chr(118)) and _ll1II1llIIlIl1IlIlIIIlI11IIIllI <> "" and _llIIllllllIII1lIIIII1l1Il1IlIIl <> "" then
_lll1l1lIlIllIII1l1l1lIIllI1lII1 = _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("5a081310115f755437") + _llIlllII1lIl1l1I1l1111llI11lI11lIll
else
_lll1l1lIlIllIII1l1l1lIIllI1lII1 = _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("51b1667874bd7e838d8382cf") + _llIlllII1lIl1l1I1l1111llI11lI11lIll
end if
_llI111ll1lIlII1lllIIIlII1Il11IIlll1II11 = {
"Referer": _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII + Chr(47) + _lllI1llIlIIlIIIIIIl1lllII1111l1 + Chr(47) + _llI111l111lII1lIIIlIl1II1Il1ll1
"Origin": _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII
"Accept": _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4defed976a8b9ee72537faeb480464c839167f523f63d69560cbf51d2f745e660030")
"User-Agent": _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7161e1a65494cd51e421cedc32ea1e69c9047421dba5fa082175768a98c928dad5b56f382908972de643c6151f496c0f8652a44e1dc10b58920bb71e4ec5bc7cddfa8687e31e096be57e2c2bea249c049a0cccd12f3bf4afb3b1d22a2f3e72408492c8bb7728992eaa6fbcf76fec72b3")
}
_ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1 = HC_Get(_llII11IlllI1llI11II1111l1ll11IlIlIl, _lll1l1lIlIllIII1l1l1lIIllI1lII1, _llI111ll1lIlII1lllIIIlII1Il11IIlll1II11, 8000)
if _ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1 = invalid or _ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1.body = "" then return invalid
_llI1lIllIlllI11II1l1IllIllI1lII = ParseJSON(_ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1.body)
if _llI1lIllIlllI11II1l1IllIllI1lII = invalid or type(_llI1lIllIlllI11II1l1IllIllI1lII) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("25ac573f28cbf8d66eb77c7202927f6ec77d05") then
_llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I = RP_TryBase64Decode(U_Trim(_ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1.body))
if _llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I <> "" then _llI1lIllIlllI11II1l1IllIllI1lII = ParseJSON(_llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I)
if _llI1lIllIlllI11II1l1IllIllI1lII = invalid or type(_llI1lIllIlllI11II1l1IllIllI1lII) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("66082b85212c57c27dc83b9e61d4fea2ad206b") then return invalid
end if
_lllIl11llIIllII1lII1lIlll111lI1IIllllII1llI = []
RP_WalkForStreams(_llI1lIllIlllI11II1l1IllIllI1lII, _lllIl11llIIllII1lII1lIlll111lI1IIllllII1llI)
if _lllIl11llIIllII1lII1lIlll111lI1IIllllII1llI.Count() = 0 then return invalid
_llI1IlII1l11ll1IlI11lI11ll1l1I1 = []
_lllI1I1ll1llIII11lI1IIlIlllIl11 = invalid
if _llI1lIllIlllI11II1l1IllIllI1lII.subtitle <> invalid then _lllI1I1ll1llIII11lI1IIlIlllIl11 = _llI1lIllIlllI11II1l1IllIllI1lII.subtitle
if _lllI1I1ll1llIII11lI1IIlIlllIl11 = invalid and _llI1lIllIlllI11II1l1IllIllI1lII.subtitles <> invalid then _lllI1I1ll1llIII11lI1IIlIlllIl11 = _llI1lIllIlllI11II1l1IllIllI1lII.subtitles
if _lllI1I1ll1llIII11lI1IIlIlllIl11 = invalid and _llI1lIllIlllI11II1l1IllIllI1lII.captions <> invalid then _lllI1I1ll1llIII11lI1IIlIlllIl11 = _llI1lIllIlllI11II1l1IllIllI1lII.captions
if _lllI1I1ll1llIII11lI1IIlIlllIl11 <> invalid and type(_lllI1I1ll1llIII11lI1IIlIlllIl11) = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6ab4baa7bdc0d0bb") then
for each _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1 in _lllI1I1ll1llIII11lI1IIlIlllIl11
if type(_llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("584326e25c6752fd5823d679dc6f5bdde87b46") then continue for
_lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = ""
if _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.file <> invalid then _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.file
if _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = "" and _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.url <> invalid then _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.url
if _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = "" then continue for
_llIIl1Ill1I1lllI1II111ll1IIII1lI1Il = (Chr(101) + Chr(110))
if _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.language <> invalid then _llIIl1Ill1I1lllI1II111ll1IIII1lI1Il = LCase(Left(_llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.language, 2))
if _llIIl1Ill1I1lllI1II111ll1IIII1lI1Il = "" and _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.lang <> invalid then _llIIl1Ill1I1lllI1II111ll1IIII1lI1Il = LCase(Left(_llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.lang, 2))
_ll1lIll1111IlIlll111I11llIll1II = ""
if _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.label <> invalid then _ll1lIll1111IlIlll111I11llIll1II = _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.label
if _ll1lIll1111IlIlll111I11llIll1II = "" and _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.language <> invalid then _ll1lIll1111IlIlll111I11llIll1II = _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.language
if _ll1lIll1111IlIlll111I11llIll1II = "" then _ll1lIll1111IlIlll111I11llIll1II = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("22da483e481d287e6c11")
_llI1IlII1l11ll1IlI11lI11ll1l1I1.Push({ url: _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I, language: _llIIl1Ill1I1lllI1II111ll1IIII1lI1Il, name: _ll1lIll1111IlIlll111I11llIll1II })
end for
end if
_lllIIIll1lI11ll111l1I1l11lIIl11Il1l = _lllIl11llIIllII1lII1lIlll111lI1IIllllII1llI[0]
return {
url: _lllIIIll1lI11ll111l1I1l11lIIl11Il1l
streamFormat: U_StreamFormat(_lllIIIll1lI11ll111l1I1l11lIIl11Il1l)
qualities: []
subtitles: _llI1IlII1l11ll1IlI11lI11ll1l1I1
chapters: []
referer: _llI11II111lIIll111II11l11II1Il1lI1ll1lI
userAgent: ""
}
end function
sub RP_WalkForStreams(_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl as Dynamic, _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 as Object)
if _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = invalid or _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = invalid then return
_llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 = type(_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl)
if _llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("74907667989b82918e99a997ada188babdb1bc") then
for each _llll1IIlllIlllIlI1Illl1ll1Il11I111l in _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl
_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl[_llll1IIlllIlllIlI1Illl1ll1Il11I111l]
if _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = invalid then continue for
_llIIllIIIIIlI111llll1IlI11lI1lI = type(_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI)
if _llIIllIIIIIlI111llll1IlI11lI1lI = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2135595a747c78") or _llIIllIIIIIlI111llll1IlI11lI1lI = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("79de82e58c1d63fb10") then
if Instr(1, _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI, _llIIlIll1llIlII1lI1lIlI1l1lI111("5e7263e0b92e")) > 0 or Instr(1, _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI, _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("368040387f")) > 0 then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1.Push(_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI)
else if _llIIllIIIIIlI111llll1IlI11lI1lI = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("23a95abd2bd4ffd7ed31e3f3011ff96fc6fb8b") or _llIIllIIIIIlI111llll1IlI11lI1lI = _llIIlIll1llIlII1lI1lIlI1l1lI111("3194c743b5c063ae") then
RP_WalkForStreams(_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI, _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1)
end if
end for
else if _llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 = _llllIllII1II1I1ll1lll1lIlIII11I("3dd62c13e5ea20a4") then
for each _llll1II1IllII1IllIllI1l1111IlI1II1I in _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl
if _llll1II1IllII1IllIllI1l1111IlI1II1I = invalid then continue for
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = type(_llll1II1IllII1IllIllI1l1111IlI1II1I)
if _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llllIllII1II1I1ll1lll1lIlIII11I("3343d63baf8419") or _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("64017e34423b663574") then
if Instr(1, _llll1II1IllII1IllIllI1l1111IlI1II1I, _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("76a132f66fb2")) > 0 or Instr(1, _llll1II1IllII1IllIllI1l1111IlI1II1I, _llllIllII1II1I1ll1lll1lIlIII11I("3c3d166cad")) > 0 then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1.Push(_llll1II1IllII1IllIllI1l1111IlI1II1I)
else if _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("7d94ea3b67d4cb61889115c3a713022606d395") or _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("75053aea57e7fb34") then
RP_WalkForStreams(_llll1II1IllII1IllIllI1l1111IlI1II1I, _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1)
end if
end for
end if
end sub
function RP_TryBase64Decode(_lllIII1IIl11Ill111lIll1l1lIlIll1ll1 as String) as String
if _lllIII1IIl11Ill111lIll1l1lIlIll1ll1 = invalid or _lllIII1IIl11Ill111lIll1l1lIlIll1ll1 = "" then return ""
_llIlI1II11ll1II1I111ll11l1l11111lI1 = _lllIII1IIl11Ill111lIll1l1lIlIll1ll1
_llI1l11llI1lII11Il11lIII1l1l1ll = Len(_llIlI1II11ll1II1I111ll11l1l11111lI1) mod 4
if _llI1l11llI1lII11Il11lIII1l1l1ll = 1 then return ""
if _llI1l11llI1lII11Il11lIII1l1l1ll = 2 then _llIlI1II11ll1II1I111ll11l1l11111lI1 = _llIlI1II11ll1II1I111ll11l1l11111lI1 + (Chr(61) + Chr(61))
if _llI1l11llI1lII11Il11lIII1l1l1ll = 3 then _llIlI1II11ll1II1I111ll11l1l11111lI1 = _llIlI1II11ll1II1I111ll11l1l11111lI1 + Chr(61)
_llIl11IIl1IlII1lII1IIllIlllllIl1111IIll = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2e7492aa828294b3898c9c97"))
_llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.FromBase64String(_llIlI1II11ll1II1I111ll11l1l11111lI1)
return _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.ToAsciiString()
end function
function RP_ResolveXpass(_lll1111IlllII1ll11lllII11I1IIIl11lll11l as String, _lll1Il11llIIlIl11Ill11IIIl11IlIlllllIll as String, _lll11I1I1lllIIlIIllI11I1lIIl1l1 as Object) as Object
_llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll = {}
if _lll1Il11llIIlIl11Ill11IIIl11IlIlllllIll <> "" then _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll[_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("795f4955514b7955")] = _lll1Il11llIIlIl11Ill11IIIl11IlIlllllIll else _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll[_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7a34000606200c26")] = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6e0af9fcfbff4b6164221424152531307d242885")
_llIlIlIlIl11II11llIllI11I1ll1Il1III = HC_Get(_lll11I1I1lllIIlIIllI11I1lIIl1l1, _lll1111IlllII1ll11lllII11I1IIIl11lll11l, _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll, 8000)
if _llIlIlIlIl11II11llIllI11I1ll1Il1III = invalid or _llIlIlIlIl11II11llIllI11I1ll1Il1III.body = "" then return invalid
_ll11Il1111II1lll1Il1II1I111l1II = _llIlIlIlIl11II11llIllI11I1ll1Il1III.body
_llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il = _llIlIlIlIl11II11llIllI11I1ll1Il1III.finalUrl
if _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il = invalid or _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il = "" then _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il = _lll1111IlllII1ll11lllII11I1IIIl11lll11l
_ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 = []
_llIl11llI1l111l111I1IIII1IIIl1ll11IlIIl = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("34c478d0e207ec42"), chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("5e0f450b46177c0460") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("67a94ff9449654c6") + chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("450b3c62") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("4c7b674c") + chr(34), Chr(105))
_ll11l1lI1IIllllI1111l1I1Il1I1I1 = _llIl11llI1l111l111I1IIII1IIIl1ll11IlIIl.match(_ll11Il1111II1lll1Il1II1I111l1II)
if _ll11l1lI1IIllllI1111l1I1Il1I1I1 <> invalid and _ll11l1lI1IIllllI1111l1I1Il1I1I1.Count() >= 2 then
_ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1.Push({ label: _llllIllII1II1I1ll1lll1lIlIII11I("6e1c5035eceed367acf1e77c"), url: RP_AbsUrl(_ll11l1lI1IIllllI1111l1I1Il1I1I1[1], _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il) })
end if
_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII = RP_ParseXpassBackups(_ll11Il1111II1lll1Il1II1I111l1II)
if _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII <> invalid and type(_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII) = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("43c59ed9401e52ea") then
for each _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII in _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII
if type(_ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII) <> _llllIllII1II1I1ll1lll1lIlIII11I("4583d7bea2a7ebb055da90647aaef5c9ce0288") then continue for
_lll1ll1ll1l1lll1III11III1I1I111Ill11lI1 = _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII.url
if _lll1ll1ll1l1lll1III11III1I1I111Ill11lI1 = invalid or _lll1ll1ll1l1lll1III11III1I1I111Ill11lI1 = "" then continue for
_ll11111l11ll1lIIllIl1I11ll1I1IIIlII = ""
if _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII.name <> invalid then _ll11111l11ll1lIIllIl1I11ll1I1IIIlII = _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII.name
if _ll11111l11ll1lIIllIl1I11ll1I1IIIlII = "" then _ll11111l11ll1lIIllIl1I11ll1I1IIIlII = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4491ee54fc954b")
_ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1.Push({ label: _ll11111l11ll1lIIllIl1I11ll1I1IIIlII, url: RP_AbsUrl(_lll1ll1ll1l1lll1III11III1I1I111Ill11lI1, _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il) })
end for
end if
_llllI1I11l1I1II1Ill11II1IIllII1lII111l1Il11 = {}
_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1 = []
for each _ll1lllllI1llllIlI1II1l1lllI1l11 in _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1
if _ll1lllllI1llllIlI1II1l1lllI1l11.url = "" then continue for
if _llllI1I11l1I1II1Ill11II1IIllII1lII111l1Il11.DoesExist(_ll1lllllI1llllIlI1II1l1lllI1l11.url) then continue for
_llllI1I11l1I1II1Ill11II1IIllII1lII111l1Il11[_ll1lllllI1llllIlI1II1l1lllI1l11.url] = true
_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1.Push(_ll1lllllI1llllIlI1II1l1lllI1l11)
end for
for _llIl1lII11lI1llllIII1l1lI1llIllIIll = 1 to _llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1.Count() - 1
_lll1IIll1l1I1l1IIll1lI11IlIll1l = _llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_llIl1lII11lI1llllIII1l1lI1llIllIIll]
_llIl111IIII1IlllIIlI11III11Il1lIII1 = RP_XpassSrcRank(_lll1IIll1l1I1l1IIll1lI11IlIll1l)
_ll11II1lIII1Il1III1IlllI111lIIl111l = _llIl1lII11lI1llllIII1l1lI1llIllIIll - 1
while _ll11II1lIII1Il1III1IlllI111lIIl111l >= 0
if RP_XpassSrcRank(_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_ll11II1lIII1Il1III1IlllI111lIIl111l]) <= _llIl111IIII1IlllIIlI11III11Il1lIII1 then exit while
_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_ll11II1lIII1Il1III1IlllI111lIIl111l + 1] = _llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_ll11II1lIII1Il1III1IlllI111lIIl111l]
_ll11II1lIII1Il1III1IlllI111lIIl111l = _ll11II1lIII1Il1III1IlllI111lIIl111l - 1
end while
_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_ll11II1lIII1Il1III1IlllI111lIIl111l + 1] = _lll1IIll1l1I1l1IIll1lI11IlIll1l
end for
_ll111IIll1I1I1I1I1IIlII1l11IlIl = RP_FetchXpassSubs(_ll11Il1111II1lll1Il1II1I111l1II, _lll11I1I1lllIIlIIllI11I1lIIl1l1)
for each _ll1lllllI1llllIlI1II1l1lllI1l11 in _llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1
_llIIIlI1lIIlIlIIlIIll11l111IlII = _ll1lllllI1llllIlI1II1l1lllI1l11.url
_lllIlllIIIl1lIl1I1llIIll111111l1lIl = HC_Get(_lll11I1I1lllIIlIIllI11I1lIIl1l1, _llIIIlI1lIIlIlIIlIIll11l111IlII, { "Referer": _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il }, 6000)
if _lllIlllIIIl1lIl1I1llIIll111111l1lIl = invalid or _lllIlllIIIl1lIl1I1llIIll111111l1lIl.body = "" then continue for
_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = ParseJSON(_lllIlllIIIl1lIl1I1llIIll111111l1lIl.body)
if _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = invalid or type(_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I) <> _llllIllII1II1I1ll1lll1lIlIII11I("24590f32585d2368cd52a6dcd0a6699fa47afe") then continue for
_lllIIl11I1IllI1IIIIl11IIIl1lIll = RP_XpassFirstSource(_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I)
if _lllIIl11I1IllI1IIIIl11IIIl1lIll = "" then continue for
_lllIIl11I1IllI1IIIIl11IIIl1lIll = RP_AbsUrl(_lllIIl11I1IllI1IIIIl11IIIl1lIll, _llIIIlI1lIIlIlIIlIIll11l111IlII)
_llIIIll111lllIIIIlllllIlIll1ll1I11l = HC_Get(_lll11I1I1lllIIlIIllI11I1lIIl1l1, _lllIIl11I1IllI1IIIIl11IIIl1lIll, { "Referer": _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il }, 6000)
if _llIIIll111lllIIIIlllllIlIll1ll1I11l = invalid or _llIIIll111lllIIIIlllllIlIll1ll1I11l.body = "" then continue for
if Left(_llIIIll111lllIIIIlllllIlIll1ll1I11l.body, 7) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("62840390148055ef") then continue for
return {
url: _lllIIl11I1IllI1IIIIl11IIIl1lIll
streamFormat: _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5aab40e4")
qualities: []
subtitles: _ll111IIll1I1I1I1I1IIlII1l11IlIl
chapters: []
referer: _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il
userAgent: ""
}
end for
return invalid
end function
function RP_XpassSrcRank(_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 as Object) as Integer
_ll1lllll11llIll11Il111I1IIll1l1 = ""
_llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = ""
if _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.label <> invalid then _ll1lllll11llIll11Il111I1IIll1l1 = UCase(_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.label)
if _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.url <> invalid then _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = LCase(_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.url)
if Instr(1, _ll1lllll11llIll11Il111I1IIll1l1, _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("288e788f")) > 0 or Instr(1, _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("25e9aaa4acbab2fb")) > 0 then return 100
if Instr(1, _ll1lllll11llIll11Il111I1IIll1l1, _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7a151a36")) > 0 or Instr(1, _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("57385228113e677d")) > 0 then return 0
if Instr(1, _ll1lllll11llIll11Il111I1IIll1l1, _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("406c0fd9")) > 0 or Instr(1, _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("60b75528c212")) > 0 then return 1
if Instr(1, _ll1lllll11llIll11Il111I1IIll1l1, _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6a383559")) > 0 or Instr(1, _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("27f2477177b3")) > 0 then return 2
return 50
end function
function RP_ParseXpassBackups(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI as String) as Object
if _lll111llIIIIlI1lI1Ill1l1lIlllIlIllI = invalid or _lll111llIIIIlI1lI1Ill1l1lIlllIlIllI = "" then return []
_ll11I11IIlII1lI1IlIlI1lIIlI1lIII1I1 = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("7ead50c416312c1f"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5938263a57416c36383d38555359755f899f816b958a8c"), Chr(105))
_llIllI11II1llIIIl1I111lllIlI111IllI1IIlll11 = _ll11I11IIlII1lI1IlIlI1lIIlI1lIII1I1.match(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI)
if _llIllI11II1llIIIl1I111lllIlI111IllI1IIlll11 = invalid or _llIllI11II1llIIIl1I111lllIlI111IllI1IIlll11.Count() < 1 then return []
_ll1l1IIIIII1lI1Il11I11II11IIIl1llIl = _llIllI11II1llIIIl1I111lllIlI111IllI1IIlll11[0]
_llII1lII11Ill1I11II1Il1ll1l11Il = Instr(1, _lll111llIIIIlI1lI1Ill1l1lIlllIlIllI, _ll1l1IIIIII1lI1Il11I11II11IIIl1llIl)
if _llII1lII11Ill1I11II1Il1ll1l11Il <= 0 then return []
_lllIIl11I1l11III111l1Il11lII1I1l1II11Il = Instr(_llII1lII11Ill1I11II1Il1ll1l11Il, _lll111llIIIIlI1lI1Ill1l1lIlllIlIllI, Chr(91))
if _lllIIl11I1l11III111l1Il11lII1I1l1II11Il <= 0 then return []
_llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = 0
_lllI11Il11111I11Illl1l111lI11Il1III1Il1l11l = false
_lll1lIIllIllI111IlI1Il1IlI11l1Il11ll1llIllI = ""
_llIIIll1Ill11ll11l1111l1I111l1II1IllIII = false
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = 0
_lllIlI1I1lIlIlIII1l1111IIl1llllIlll = Len(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI)
_llIllI1lIl1IlI111Il1lI1II1111111l1l1lll = chr(92)
_lllll11lIl1ll11llI11II1Ill1l1I1 = chr(34)
_llIll111llll1llIllIl1l11llII11llI11II11IIll = Chr(39)
for _llI1II11ll1lll11Il11I1I1II1Ill1Ill1I1lII1II = _lllIIl11I1l11III111l1Il11lII1I1l1II11Il to _lllIlI1I1lIlIlIII1l1111IIl1llllIlll
_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = Mid(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI, _llI1II11ll1lll11Il11I1I1II1Ill1Ill1I1lII1II, 1)
if _lllI11Il11111I11Illl1l111lI11Il1III1Il1l11l then
if _llIIIll1Ill11ll11l1111l1I111l1II1IllIII then
_llIIIll1Ill11ll11l1111l1I111l1II1IllIII = false
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _llIllI1lIl1IlI111Il1lI1II1111111l1l1lll then
_llIIIll1Ill11ll11l1111l1I111l1II1IllIII = true
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _lll1lIIllIllI111IlI1Il1IlI11l1Il11ll1llIllI then
_lllI11Il11111I11Illl1l111lI11Il1III1Il1l11l = false
end if
else
if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _lllll11lIl1ll11llI11II1Ill1l1I1 or _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _llIll111llll1llIllIl1l11llII11llI11II11IIll then
_lllI11Il11111I11Illl1l111lI11Il1III1Il1l11l = true
_lll1lIIllIllI111IlI1Il1IlI11l1Il11ll1llIllI = _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = Chr(91) then
_llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 + 1
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = Chr(93) then
_llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 - 1
if _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = 0 then
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = _llI1II11ll1lll11Il11I1I1II1Ill1Ill1I1lII1II
exit for
end if
end if
end if
end for
if _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = 0 then return []
_lll1II11ll1l1I1IIl1Il1IlIII1lIl = Mid(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI, _lllIIl11I1l11III111l1Il11lII1I1l1II11Il, _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll - _lllIIl11I1l11III111l1Il11lII1I1l1II11Il + 1)
_llIII1lIlIIlIIl1IIlIll11lIlI1I1lII1 = ParseJSON(_lll1II11ll1l1I1IIl1Il1IlIII1lIl)
if _llIII1lIlIIlIIl1IIlIll11lIlI1I1lII1 = invalid or type(_llIII1lIlIIlIIl1IIlIll11lIlI1I1lII1) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("2eb503b134f46107") then return []
return _llIII1lIlIIlIIl1IIlIll11lIlI1I1lII1
end function
function RP_XpassFirstSource(_ll1I1I11I11lll1l111I1lllIIIl1l111I1 as Object) as String
if _ll1I1I11I11lll1l111I1lllIIIl1l111I1 = invalid or type(_ll1I1I11I11lll1l111I1lllIIIl1l111I1) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("2e7d20fc96a14c37723db093d6497517229560") then return ""
_llIlI1IlI111I1lIIl1lIlIIl11ll11l11ll11I = _ll1I1I11I11lll1l111I1lllIIIl1l111I1.playlist
if _llIlI1IlI111I1lIIl1lIlIIl11ll11l11ll11I = invalid or type(_llIlI1IlI111I1lIIl1lIlIIl11ll11l11ll11I) <> _llllIllII1II1I1ll1lll1lIlIII11I("73ed41e8fc01f57b") then return ""
for each _llIllIlI1l11lI111lIII1l11111l1I in _llIlI1IlI111I1lIIl1lIlIIl11ll11l11ll11I
if type(_llIllIlI1l11lI111lIII1l11111l1I) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5a5483115757e00b916a87e8d60bf98696ea84") then continue for
_ll1IlllIIlI1IlllIllllII1llIII1l1I1lI1lI = _llIllIlI1l11lI111lIII1l11111l1I.sources
if _ll1IlllIIlI1IlllIllllII1llIII1l1I1lI1lI = invalid or type(_ll1IlllIIlI1IlllIllllII1llIII1l1I1lI1lI) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4da5304018c13d5a") then continue for
for each _lll11llllI1IIIl11lI1111IlIl1Ill1l1lI1l1 in _ll1IlllIIlI1IlllIllllII1llIII1l1I1lI1lI
if type(_lll11llllI1IIIl11lI1111IlIl1Ill1l1lI1l1) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6cbd099a6ebeeb9208620fd0af80e11d0de20d") then continue for
_llIlI1l11IIII1IllIIlllI1I1I11IIIlII = _lll11llllI1IIIl11lI1111IlIl1Ill1l1lI1l1.file
if _llIlI1l11IIII1IllIIlllI1I1I11IIIlII <> invalid and _llIlI1l11IIII1IllIIlllI1I1I11IIIlII <> "" then return _llIlI1l11IIII1IllIIlllI1I1I11IIIlII
end for
end for
return ""
end function
function RP_FetchXpassSubs(_lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II as String, _lllIII1IIIllI1III1llI1lIIIlIlIl11llIlIIIll1 as Object) as Object
_ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI = []
if _lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II = invalid or _lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II = "" then return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
_llIll11l1Il1IlIlIlI11IllIIII1IIIIIIII1I = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6770589668696e7c"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("4ca49357bdc4e29404a9d59422ce141a55ad945a") + chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3887555c") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("34e5babf") + chr(34), Chr(105))
m = _llIll11l1Il1IlIlIlI11IllIIII1IIIIIIII1I.match(_lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II)
if m = invalid or m.Count() < 2 then return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
_lllI1IlI1I1llll1l1Il1lI1lIIIIlIlII111l1lIlI = HC_Get(_lllIII1IIIllI1III1llI1lIIIlIlIl11llIlIIIll1, m[1], invalid, 6000)
if _lllI1IlI1I1llll1l1Il1lI1lIIIIlIlII111l1lIlI = invalid or _lllI1IlI1I1llll1l1Il1lI1lIIIIlIlII111l1lIlI.body = "" then return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I = ParseJSON(_lllI1IlI1I1llll1l1Il1lI1lIIIIlIlII111l1lIlI.body)
if _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I = invalid or type(_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("5008c6849ca30eaa") then return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
_llllIIlllllI11I1lIIl11I11I1ll1I11Il = _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I.Count()
if _llllIIlllllI11I1lIIl11I11I1ll1I11Il > 30 then _llllIIlllllI11I1lIIl11I11I1ll1I11Il = 30
for _lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1 = 0 to _llllIIlllllI11I1lIIl11I11I1ll1I11Il - 1
_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1 = _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I[_lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1]
if type(_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3d1a5b6966dd8471a272a2d69c14c09979a889") then continue for
_ll1I1lIl1Il111IIlIl1Il1111lIl11IIlI1Ill = _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.url
if _ll1I1lIl1Il111IIlIl1Il1111lIl11IIlI1Ill = invalid or _ll1I1lIl1Il111IIlIl1Il1111lIl11IIlI1Ill = "" then continue for
_lll1IIlIlIllIlII1I11l1I1lIl1Il1lIllI111 = (Chr(101) + Chr(110))
if _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.language <> invalid then _lll1IIlIlIllIlII1I11l1I1lIl1Il1lIllI111 = LCase(_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.language)
_llIl1lI1IIlI111lI1IlI1ll11IIlII = ""
if _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.display <> invalid then _llIl1lI1IIlI111lI1IlI1ll11IIlII = _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.display
if _llIl1lI1IIlI111lI1IlI1ll11IIlII = "" then
if _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.language <> invalid then _llIl1lI1IIlI111lI1IlI1ll11IIlII = UCase(_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.language) else _llIl1lI1IIlI111lI1IlI1ll11IIlII = (Chr(69) + Chr(78))
end if
_ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI.Push({ url: _ll1I1lIl1Il111IIlIl1Il1111lIl11IIlI1Ill, language: _lll1IIlIlIllIlII1I11l1I1lIl1Il1lIllI111, name: _llIl1lI1IIlI111lI1IlI1ll11IIlII })
end for
return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
end function
function RP_ResolveJwplayerPage(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I as String, _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II as String, _llIll1lII1l1I1Ill1lIII1I111Il1l1l1I as String, _llIl11Illl1llIlI1I11lllI1IIIIIlllllllIlIII1 as Object) as Object
if _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I = invalid or _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I = "" then return invalid
_llI1II1II1Ill1I1I1111IlIIII1l1I = []
RP_JwExtractInto(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I, _llI1II1II1Ill1I1I1111IlIIII1l1I)
_llll1I1I11IIll1I11llllll11I1l111IlIllll = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7c901fdb6e94bba9"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5827b3b425336634c1e7f6c8e7c6752275eb8636b78767f4f4a645f75955baa083f37840f61b60c640a43036200962"), Chr(105))
_lll1IIllII11l1ll11l1l1lIl11lII1 = _llll1I1I11IIll1I11llllll11I1l111IlIllll.match(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I)
if _lll1IIllII11l1ll11l1l1lIl11lII1 <> invalid and _lll1IIllII11l1ll11l1l1lIl11lII1.Count() >= 1 then
_llllI1llIIIlIll1IIlIlIl1I111l1I = JU_UnpackPacked(_lll1IIllII11l1ll11l1l1lIl11lII1[0])
if _llllI1llIIIlIll1IIlIlIl1I111l1I <> "" then RP_JwExtractInto(_llllI1llIIIlIll1IIlIlIl1I111l1I, _llI1II1II1Ill1I1I1111IlIIII1l1I)
end if
if _llI1II1II1Ill1I1I1111IlIIII1l1I.Count() = 0 then return invalid
_lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I = _llIll1lII1l1I1Ill1lIII1I111Il1l1l1I
if _lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I = "" then _lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I = _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II
_llIl1ll1IIIl1l1I1lIlIIlIIlIIIlI111lIIllI11l = {}
for each _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11 in _llI1II1II1Ill1I1I1111IlIIII1l1I
_llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11 = RP_AbsUrl(_llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11.url, _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II)
if _llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11 = "" then continue for
if _llIl1ll1IIIl1l1I1lIlIIlIIlIIIlI111lIIllI11l.DoesExist(_llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11) then continue for
_llIl1ll1IIIl1l1I1lIlIIlIIlIIIlI111lIIllI11l[_llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11] = true
_lllI1l11Il1II1lIll11I1l1ll1IlIl = HC_Get(_llIl11Illl1llIlI1I11lllI1IIIIIlllllllIlIII1, _llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11, { "Referer": _lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I }, 6000)
if _lllI1l11Il1II1lIll11I1l1ll1IlIl = invalid or _lllI1l11Il1II1lIll11I1l1ll1IlIl.body = "" then continue for
if _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11.fmt = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("5ea215a8") and Left(_lllI1l11Il1II1lIll11I1l1ll1IlIl.body, 7) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("729d09358e1356c3") then continue for
return {
url: _llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11
streamFormat: _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11.fmt
qualities: []
subtitles: RP_ExtractSubs(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I)
chapters: []
referer: _lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I
userAgent: ""
}
end for
return invalid
end function
sub RP_JwExtractInto(_ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il as String, _ll1I1IIIIlI1llIl1lIlII1I1I1lI111l111Ill as Object)
if _ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il = invalid or _ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il = "" then return
_ll1ll1I1IIIIlllIIl1IIl1llllll11 = chr(34)
_llII1lIlllI1IllIlII11IIlll1lI11l111Il1IIl11 = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("789ece7c6ed8282e1a59884e71") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("3b6582708288") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllII1II1I1ll1lll1lIlIII11I("5f76d6bd96daecb4d4") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + (Chr(39) + Chr(93))
_llI1lIlIl11llI1llIIII11I111lII1lI1IlI111lII = _llllIllII1II1I1ll1lll1lIlIII11I("78cf1579eee4891ff28c903306a092") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllII1II1I1ll1lll1lIlIII11I("4b2490befaaf") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2dc113d2b65bf61dea") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + (Chr(39) + Chr(93))
_ll1ll1l1I1lIlIl1IIIllI1lII1lIlI1lIIlII1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2f9193a77f9df7ea8ba90397") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllII1II1I1ll1lll1lIlIII11I("4371d30b3df2") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("2cb0a0cdaef6238f2adbd50fbd5dea803ac915c57cc0f6") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7da9cc1ed4a1") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + (Chr(39) + Chr(93))
_llIl1lIlIl11I1l1IIl1llIIl11IIlllI111l1I = _llIIlIll1llIlII1lI1lIlI1l1lI111("6f94ff327de9db36c20445d0ee307107") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("432572207278") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("692ceada624d016e4a") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + (Chr(39) + Chr(93))
for each _lllllIIlI1l1II1lIll1Ill1II11I1IIll11lIlIIIl in [_llII1lIlllI1IllIlII11IIlll1lI11l111Il1IIl11, _llI1lIlIl11llI1llIIII11I111lII1lI1IlI111lII, _ll1ll1l1I1lIlIl1IIIllI1lII1lIlI1lIIlII1, _llIl1lIlIl11I1l1IIl1llIIl11IIlllI111l1I]
_llIIII111111IlI11IIl1l11lII111I = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4022e67912d96ffc"), _lllllIIlI1l1II1lIll1Ill1II11I1IIll11lIlIIIl, Chr(105))
m = _llIIII111111IlI11IIl1l11lII111I.match(_ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il)
if m <> invalid and m.Count() >= 2 then
_lllII1lIllIl1lIlll1lIIIllIIIIll = RP_UnescapeSlashes(m[1])
_lll1llI11IlIllI11ll1lIlI1111ll1l1llI1lIl111 = _llllIllII1II1I1ll1lll1lIlIII11I("4f094ec2")
if Instr(1, LCase(_lllII1lIllIl1lIlll1lIIIllIIIIll), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4d0b091f56")) > 0 then _lll1llI11IlIllI11ll1lIlI1111ll1l1llI1lIl111 = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3fba7983")
_ll1I1IIIIlI1llIl1lIlII1I1I1lI111l111Ill.Push({ url: _lllII1lIllIl1lIlll1lIIIllIIIIll, fmt: _lll1llI11IlIllI11ll1lIlI1111ll1l1llI1lIl111 })
end if
end for
_llIIl111Ill1IIllIIl1IIIl1IlllI1lIII = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("34ca6ddf534e695c"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6ef729e232ef0eaa10b617bb19") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("3b658184879d6b917e9687cd72bb81a3a9") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6ef8b7ee19a7c68be273"), Chr(105))
_lllI11llI1lIl11lIllIII1I1llIllllI1IIIll = _llIIl111Ill1IIllIIl1IIIl1IlllI1lIII.match(_ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il)
if _lllI11llI1lIl11lIllIII1I1llIllllI1IIIll <> invalid and _lllI11llI1lIl11lIllIII1I1llIllllI1IIIll.Count() >= 2 then _ll1I1IIIIlI1llIl1lIlII1I1I1lI111l111Ill.Push({ url: _lllI11llI1lIl11lIllIII1I1llIllllI1IIIll[1], fmt: _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("78cad1d5") })
_llIl1lIIlll1lIll1llIlIll1IIl11llI11lll11Ill = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7c30465646474c4c"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("532514300f3d33782d642a6924") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llIIlIll1llIlII1lI1lIlI1l1lI111("73a959646f73989856a64445a89515f8") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llIIlIll1llIlII1lI1lIlI1l1lI111("2240040f1ace3f33b5a8"), Chr(105))
_lll1l1I1l1l11II1l1IllIIIIIIIl11IlI1 = _llIl1lIIlll1lIll1llIlIll1IIl11llI11lll11Ill.match(_ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il)
if _lll1l1I1l1l11II1l1IllIIIIIIIl11IlI1 <> invalid and _lll1l1I1l1l11II1l1IllIIIIIIIl11IlI1.Count() >= 2 then _ll1I1IIIIlI1llIl1lIlII1I1I1lI111l111Ill.Push({ url: _lll1l1I1l1l11II1l1IllIIIIIIIl11IlI1[1], fmt: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6eb7d3a7") })
end sub
function RP_UnescapeSlashes(_llII1lIllll111111l1llII1I1l1I1l as String) as String
if _llII1lIllll111111l1llII1I1l1I1l = invalid or _llII1lIllll111111l1llII1I1l1I1l = "" then return ""
_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("3bbdf0d236514caf"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("24af23d5"), Chr(103))
return _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l.replaceAll(_llII1lIllll111111l1llII1I1l1I1l, Chr(47))
end function
function RP_AbsUrl(_lllI11lII1llII1lIll1Il1I1lllII1 as String, _llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI as String) as String
if _lllI11lII1llII1lIll1Il1I1lllII1 = invalid or _lllI11lII1llII1lIll1Il1I1lllII1 = "" then return ""
_llIlll11I1llIIII1IIlI1111l1l1Il = U_Trim(_lllI11lII1llII1lIll1Il1I1lllII1)
if Left(_llIlll11I1llIIII1IIlI1111l1l1Il, 7) = _llllIllII1II1I1ll1lll1lIlIII11I("6b8ed4d91ec79ba0") or Left(_llIlll11I1llIIII1IIlI1111l1l1Il, 8) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("66f52e17c0f16b897e") then return _llIlll11I1llIIII1IIlI1111l1l1Il
if Left(_llIlll11I1llIIII1IIlI1111l1l1Il, 2) = (Chr(47) + Chr(47)) then return _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("363a393c3b3f7b") + _llIlll11I1llIIII1IIlI1111l1l1Il
_llIlIlI11llIIlIIIlII11IlIlIIl1I = HC_OriginOf(_llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI)
if _llIlIlI11llIIlIIIlII11IlIlIIl1I = "" then return _llIlll11I1llIIII1IIlI1111l1l1Il
if Left(_llIlll11I1llIIII1IIlI1111l1l1Il, 1) = Chr(47) then return _llIlIlI11llIIlIIIlII11IlIlIIl1I + _llIlll11I1llIIII1IIlI1111l1l1Il
_llIllll1llI111llIllIIIIIl1111I11lII = Len(_llIlIlI11llIIlIIIlII11IlIlIIl1I) + 1
if _llIllll1llI111llIllIIIIIl1111I11lII > Len(_llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI) then return _llIlIlI11llIIlIIIlII11IlIlIIl1I + Chr(47) + _llIlll11I1llIIII1IIlI1111l1l1Il
_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11 = Mid(_llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI, _llIllll1llI111llIllIIIIIl1111I11lII + 1)
_llll1llI1lIlIlIl1I11llIlII1III1lI111lIl = Instr(1, _llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, Chr(63))
if _llll1llI1lIlIlIl1I11llIlII1III1lI111lIl > 0 then _llll11Ill1IIIllI11l111I1lI1IlIlI1llII11 = Left(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, _llll1llI1lIlIlIl1I11llIlII1III1lI111lIl - 1)
_ll1llI1IllllIl1II11llII11l1lI1IIIlI = Instr(1, _llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, Chr(35))
if _ll1llI1IllllIl1II11llII11l1lI1IIIlI > 0 then _llll11Ill1IIIllI11l111I1lI1IlIlI1llII11 = Left(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, _ll1llI1IllllIl1II11llII11l1lI1IIIlI - 1)
_ll1lIl1l1lIll1l11I111IlI1l1Il11IllIIIIllIIl = 0
for _lllI1ll1III1IIl1lI1I1ll1IlIl1lI11l11I1I = 1 to Len(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11)
if Mid(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, _lllI1ll1III1IIl1lI1I1ll1IlIl1lI11l11I1I, 1) = Chr(47) then _ll1lIl1l1lIll1l11I111IlI1l1Il11IllIIIIllIIl = _lllI1ll1III1IIl1lI1I1ll1IlIl1lI11l11I1I
end for
if _ll1lIl1l1lIll1l11I111IlI1l1Il11IllIIIIllIIl = 0 then return _llIlIlI11llIIlIIIlII11IlIlIIl1I + Chr(47) + _llIlll11I1llIIII1IIlI1111l1l1Il
return _llIlIlI11llIIlIIIlII11IlIlIIl1I + Chr(47) + Left(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, _ll1lIl1l1lIll1l11I111IlI1l1Il11IllIIIIllIIl) + _llIlll11I1llIIII1IIlI1111l1l1Il
end function
function RP_ResolveLookmovie(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1 as String, _ll1l1IIIl1lII1I11I1I11lI1lIllIl11I11I1I as String, _ll1lll1l11IIIIlIl11l11I1llIll11I1Illl1Il111 as Object) as Object
_ll1ll11lllIlIIlllllI1IlIII11IlI1ll1 = {}
if _ll1l1IIIl1lII1I11I1I11lI1lIllIl11I11I1I <> "" then _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1[_llllIllII1II1I1ll1lll1lIlIII11I("40cf679c71e57bef")] = _ll1l1IIIl1lII1I11I1I11lI1lIllIl11I11I1I else _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1[_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("318f0185199b3185")] = _llI1ll1Il1llIlIIll1l11Il1llllIlllI1
_ll1l11lIlll11lIIl11111Ill11Il1I = HC_Get(_ll1lll1l11IIIIlIl11l11I1llIll11I1Illl1Il111, _llI1ll1Il1llIlIIll1l11Il1llllIlllI1, _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1, 8000)
if _ll1l11lIlll11lIIl11111Ill11Il1I = invalid or _ll1l11lIlll11lIIl11111Ill11Il1I.body = "" then return invalid
_lllII1lII1III1I1l1lllIIIIlI1lI1 = _ll1l11lIlll11lIIl11111Ill11Il1I.finalUrl
if _lllII1lII1III1I1l1lllIIIIlI1lI1 = invalid or _lllII1lII1III1I1l1lllIIIIlI1lI1 = "" then _lllII1lII1III1I1l1lllIIIIlI1lI1 = _llI1ll1Il1llIlIIll1l11Il1llllIlllI1
_ll1IIlIllIl1Il1ll1IIllIlIlIl1II = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6197cabf0b93eb86"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("456e92cf3c40ce2ec22c1d4bfecc9c51cdabafccaf0cceee0eef2e4cba5dda53012359d2ac99c1fe426e528c230a80"), Chr(105))
_ll1Il1lI11l1I1II1lIl1111lI111IIl11lllI111Il = _ll1IIlIllIl1Il1ll1IIllIlIlIl1II.match(_ll1l11lIlll11lIIl11111Ill11Il1I.body)
if _ll1Il1lI11l1I1II1lIl1111lI111IIl11lllI111Il = invalid or _ll1Il1lI11l1I1II1lIl1111lI111IIl11lllI111Il.Count() < 1 then return invalid
_llIllIl111ll1l1111111IIll11l1IlllIlI1II = JU_UnpackPacked(_ll1Il1lI11l1I1II1lIl1111lI111IIl11lllI111Il[0])
if _llIllIl111ll1l1111111IIll11l1IlllIlI1II = "" then return invalid
_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I = {}
_lll1IIl1llIlII1IlII1l11lll111II = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("37a35f077b30c98d"), chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5afa3d3c5c372325233d14") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("49684c119c94783d") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("2f9d5b91") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3fe09f2e") + chr(34), (Chr(105) + Chr(103)))
_ll1llII1I1l1II11lllIl11llII11I1Il1I = _lll1IIl1llIlII1IlII1l11lll111II.matchAll(_llIllIl111ll1l1111111IIll11l1IlllIlI1II)
if _ll1llII1I1l1II11lllIl11llII11I1Il1I <> invalid then
for each _ll1lIlIIll1l1lI1ll11I1I1Il1IIIl in _ll1llII1I1l1II11lllIl11llII11I1Il1I
if _ll1lIlIIll1l1lI1ll11I1I1Il1IIIl.Count() < 3 then continue for
_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I[_ll1lIlIIll1l1lI1ll11I1I1Il1IIIl[1]] = RP_UnescapeSlashes(_ll1lIlIIll1l1lI1ll11I1I1Il1IIIl[2])
end for
end if
_llI11II1Il1I1llIll1I1llI1IIl1lI = [_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("78738aa782"), _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7e5162f036"), _llllIllII1II1I1ll1lll1lIlIII11I("39165b918a")]
for each _llll11lII1IlIllll11I1lIlIIIII111llI1II1 in _llI11II1Il1I1llIll1I1llI1IIl1lI
_llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l = _lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I[_llll11lII1IlIllll11I1lIlIIIII111llI1II1]
if _llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l = invalid or _llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l = "" then continue for
_llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l = RP_AbsUrl(_llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l, _lllII1lII1III1I1l1lllIIIIlI1lI1)
_llllIlllIll1IIl1l111Ill1llllIl1lllI11I1 = HC_Get(_ll1lll1l11IIIIlIl11l11I1llIll11I1Illl1Il111, _llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l, { "Referer": _lllII1lII1III1I1l1lllIIIIlI1lI1 }, 6000)
if _llllIlllIll1IIl1l111Ill1llllIl1lllI11I1 = invalid or _llllIlllIll1IIl1l111Ill1llllIl1lllI11I1.body = "" then continue for
if Left(_llllIlllIll1IIl1l111Ill1llllIl1lllI11I1.body, 7) <> _llllIllII1II1I1ll1lll1lIlIII11I("6291744a8f03ab8e") then continue for
return {
url: _llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l
streamFormat: _llIIlIll1llIlII1lI1lIlI1l1lI111("4da5d0f3")
qualities: []
subtitles: RP_ExtractSubs(_ll1l11lIlll11lIIl11111Ill11Il1I.body)
chapters: []
referer: _lllII1lII1III1I1l1lllIIIIlI1lI1
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidora(_lll1I1I1IIl1I1IlIII1l1I111l11lI as String, _llI1lll1ll1Il1111Ill1I111Il111I as String, _llll1I11Ill11IlI11ll1lllIll1I1ll1l1 as Object) as Object
_ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l = {}
if _llI1lll1ll1Il1111Ill1I111Il111I <> "" then _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l[_llllIllII1II1I1ll1lll1lIlIII11I("65675d32677d7187")] = _llI1lll1ll1Il1111Ill1I111Il111I else _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l[_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4cf00002061c0c22")] = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6e0af9fcfbff4b6164252a162a291a2b1f39832c488b")
_llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI = HC_Get(_llll1I11Ill11IlI11ll1lllIll1I1ll1l1, _lll1I1I1IIl1I1IlIII1l1I111l11lI, _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l, 8000)
if _llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI = invalid or _llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI.body = "" then return invalid
_ll11Illlll11l1I1IIlIl11II11lIlII1III11I = _llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI.finalUrl
if _ll11Illlll11l1I1IIlIl11II11lIlII1III11I = invalid or _ll11Illlll11l1I1IIlIl11II11lIlII1III11I = "" then _ll11Illlll11l1I1IIlIl11II11lIlII1III11I = _lll1I1I1IIl1I1IlIII1l1I111l11lI
return RP_ResolveJwplayerPage(_llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI.body, _ll11Illlll11l1I1IIlIl11II11lIlII1III11I, _ll11Illlll11l1I1IIlIl11II11lIlII1III11I, _llll1I11Ill11IlI11ll1lllIll1I1ll1l1)
end function
function RP_Resolve2embed(_lllIIIl1ll1ll1IllIllll11l11l111Ill11111 as String, _llIIlIIlII1IIII1l1l1l1l1l1l1IlIlI11IIlIllll as String, _ll1111l1I11llII1l1ll1I1I11I111I1I1I as Object) as Object
_llllI1IlIlII1lIlll1Il1IIlII1I11II1lllll1Il1 = {}
if _llIIlIIlII1IIII1l1l1l1l1l1l1IlIlI11IIlIllll <> "" then _llllI1IlIlII1lIlll1Il1IIlII1I11II1lllll1Il1[_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("3ab4808686a08ca6")] = _llIIlIIlII1IIII1l1l1l1l1l1l1IlIlI11IIlIllll else _llllI1IlIlII1lIlll1Il1IIlII1I11II1lllll1Il1[_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("79d60038d01d60fc")] = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("39bc04d323f0382d7476ee5b39c8c8fe9eedd43a")
_ll1IlIIIllIlllII1lllI1llllII11I11l1 = HC_Get(_ll1111l1I11llII1l1ll1I1I11I111I1I1I, _lllIIIl1ll1ll1IllIllll11l11l111Ill11111, _llllI1IlIlII1lIlll1Il1IIlII1I11II1lllll1Il1, 8000)
if _ll1IlIIIllIlllII1lllI1llllII11I11l1 = invalid or _ll1IlIIIllIlllII1lllI1llllII11I11l1.body = "" then return invalid
_ll11I1I11l1I11I1lI1IlI1I1llII1111I1 = _ll1IlIIIllIlllII1lllI1llllII11I11l1.finalUrl
if _ll11I1I11l1I11I1lI1IlI1I1llII1111I1 = invalid or _ll11I1I11l1I11I1lI1IlI1I1llII1111I1 = "" then _ll11I1I11l1I11I1lI1IlI1I1llII1111I1 = _lllIIIl1ll1ll1IllIllll11l11l111Ill11111
_llIIII1111lI11IlII1I11lll1Ill1llIlI111l1III = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2965742de46eb76d"), _llllIllII1II1I1ll1lll1lIlIII11I("32f286db3d72467cc5657a70e4798e842df114") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("6eed9167682e33f8cd966b9fa4e65b005419de04190d130af036860b4095aa3218494e17599e02681c643bfe53") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("55cb7595baa4") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
_llIlIlI111lIllI1IlI1l11l1IllIIlIlIIIIllI1ll = _llIIII1111lI11IlII1I11lll1Ill1llIlI111l1III.match(_ll1IlIIIllIlllII1lllI1llllII11I11l1.body)
_ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = ""
if _llIlIlI111lIllI1IlI1l11l1IllIIlIlIIIIllI1ll <> invalid and _llIlIlI111lIllI1IlI1l11l1IllIIlIlIIIIllI1ll.Count() >= 2 then
_ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = _llIlIlI111lIllI1IlI1l11l1IllIIlIlIIIIllI1ll[1]
else
_lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4dafa61c080bbb06"), _llllIllII1II1I1ll1lll1lIlIII11I("338c95dbe0255a9bd0a4a973086d2166ab91869aa0b7d59b53d8ad6257dffdd6db1ce6ab4ff54911408b402518") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4658df562b740f"), Chr(105))
_lllII1llI1lI11IIII1Ill11IlII1l111II = _lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I.match(_ll1IlIIIllIlllII1lllI1llllII11I11l1.body)
if _lllII1llI1lI11IIII1Ill11IlII1l111II <> invalid and _lllII1llI1lI11IIII1Ill11IlII1l111II.Count() >= 2 then _ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = _lllII1llI1lI11IIII1Ill11IlII1l111II[1]
end if
if _ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = "" then return invalid
_ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = U_HtmlDecode(_ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l)
_lllIII1lIIIlllIIllIlI1llIlIllllIlll = HC_Get(_ll1111l1I11llII1l1ll1I1I11I111I1I1I, _ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l, { "Referer": _ll11I1I11l1I11I1lI1IlI1I1llII1111I1 }, 8000)
if _lllIII1lIIIlllIIllIlI1llIlIllllIlll = invalid or _lllIII1lIIIlllIIllIlI1llIlIllllIlll.body = "" then return invalid
_llI1I1Il1lI1I1II1II11IllIlIll11 = _lllIII1lIIIlllIIllIlI1llIlIllllIlll.finalUrl
if _llI1I1Il1lI1I1II1II11IllIlIll11 = invalid or _llI1I1Il1lI1I1II1II11IllIlIll11 = "" then _llI1I1Il1lI1I1II1II11IllIlIll11 = _ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l
_ll1llll1llIll11IlI11IlIlIl11l111III = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("607add8f433e598c"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3b816987669d559c7090178a6acb64e3319c") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7e1803646b68") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("779efee8cded") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
_llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = _ll1llll1llIll11IlI11IlIlIl11l111III.match(_lllIII1lIIIlllIIllIlI1llIlIllllIlll.body)
if _llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = invalid or _llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1.Count() < 2 then return invalid
_llIl1lIll1l1l1I1I11IIl1IIII11lI1l1I1Il11lll = _llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1[1]
_llII1lllIlI11lIl1II1l11l1111I1IIlI1II1IIl11 = ""
if Left(_llIl1lIll1l1l1I1I11IIl1IIII11lI1l1I1Il11lll, 4) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("490c542393") then
_llII1lllIlI11lIl1II1l11l1111I1IIlI1II1IIl11 = _llIl1lIll1l1l1I1I11IIl1IIII11lI1l1I1Il11lll
else
_llII1lllIlI11lIl1II1l11l1111I1IIlI1II1IIl11 = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2a70d6e1493b00547e7d2cf75ec973ae02eaec4d85d01bec935445") + _llIl1lIll1l1l1I1I11IIl1IIII11lI1l1I1Il11lll
end if
return RP_ResolveLookmovie(_llII1lllIlI11lIl1II1l11l1111I1IIlI1II1IIl11, _llI1I1Il1lI1I1II1II11IllIlIll11, _ll1111l1I11llII1l1ll1I1I11I111I1I1I)
end function
function RP_ResolveCloudnestra(_lllIlIIII1IIIIllI1IlI1111IlIllIIl1l as String, _lll1lIllll11l1lll1l1lIl1l11l111I1lI1ll1 as String, _lllIIIlII1IIIl1IlIIllll11111lllIIII as Object) as Object
_lllIllIlllI1Il1IllIIIIIIIlI1I1lllII = _lll1lIllll11l1lll1l1lIl1l11l111I1lI1ll1
if _lllIllIlllI1Il1IllIIIIIIIlI1I1lllII = "" then _lllIllIlllI1Il1IllIIIIIIIlI1I1lllII = _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l
_llI111l111lIII1lIIII1lllIIll1l1l1l11IlI = HC_Get(_lllIIIlII1IIIl1IlIIllll11111lllIIII, _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l, { "Referer": _lllIllIlllI1Il1IllIIIIIIIlI1I1lllII }, 8000)
if _llI111l111lIII1lIIII1lllIIll1l1l1l11IlI = invalid or _llI111l111lIII1lIIII1lllIIll1l1l1l11IlI.body = "" then return invalid
_ll1l11Ill1IIIIII1IlIl1lIII11I1l = _llI111l111lIII1lIIII1lllIIll1l1l1l11IlI.finalUrl
if _ll1l11Ill1IIIIII1IlIl1lIII11I1l = invalid or _ll1l11Ill1IIIIII1IlIl1lIII11I1l = "" then _ll1l11Ill1IIIIII1IlIl1lIII11I1l = _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l
_llIl1I1II1Il11lIIll1I1Il11Il11lIl1ll11l = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("4ca7124fe3cb50d7"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("57111327d1f220eafe") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6d04823456f2ab866af68a77f3f8") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("3202a4ccf1d3") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
m = _llIl1I1II1Il11lIIll1I1Il11Il11lIl1ll11l.match(_llI111l111lIII1lIIII1lllIIll1l1l1l11IlI.body)
if m = invalid or m.Count() < 2 then
_lll11lIl11IllIIl1I1l1Il1IIIllIIIlllIlI11I1l = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("38ced0dd91e1fee5"), Chr(91) + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5de1aadfe39ea3aba9bdadf7cecc") + chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("64cdc53a298f") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
m = _lll11lIl11IllIIl1I1l1Il1IIIllIIIlllIlI11I1l.match(_llI111l111lIII1lIIII1lllIIll1l1l1l11IlI.body)
if m = invalid or m.Count() < 2 then return RP_ResolveGeneric(_lllIlIIII1IIIIllI1IlI1111IlIllIIl1l, _lll1lIllll11l1lll1l1lIl1l11l111I1lI1ll1, _lllIIIlII1IIIl1IlIIllll11111lllIIII)
end if
_llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l = m[1]
if Left(_llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l, 1) <> Chr(47) then _llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l = Chr(47) + _llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l
_llIlIl111lllll1llI11ll1I1ll11I1IIl1lllI1I1l = RP_AbsUrl(_llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l, _ll1l11Ill1IIIIII1IlIl1lIII11I1l)
_ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il = HC_Get(_lllIIIlII1IIIl1IlIIllll11111lllIIII, _llIlIl111lllll1llI11ll1I1ll11I1IIl1lllI1I1l, { "Referer": _ll1l11Ill1IIIIII1IlIl1lIII11I1l }, 8000)
if _ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il = invalid or _ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.body = "" then return invalid
_ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll = _ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.finalUrl
if _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll = invalid or _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll = "" then _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll = _llIlIl111lllll1llI11ll1I1ll11I1IIl1lllI1I1l
_llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5e2e65704849d99b"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("61e8eef4f0a8cde7c1") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("57daecea") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("276b62db") + chr(34), Chr(105))
_ll1llII1l1I1IlIIl11I1I11I1l11l1II1I = _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.match(_ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.body)
if _ll1llII1l1I1IlIIl11I1I11I1l11l1II1I = invalid or _ll1llII1l1I1IlIIl11I1I11I1l11l1II1I.Count() < 2 then return invalid
_ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111 = _ll1llII1l1I1IlIIl11I1I11I1l11l1II1I[1]
_ll1l11llIllllIll11II1l1lIll1I1llI1llI1111Il = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6bb0b096b0b1b6cc"), chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("385b23523c584a44514a0a2a1f34164e70250216b548e05ccf42cb2bb625cb49fa3caa12c719") + chr(34), (Chr(105) + Chr(103)))
_ll11I11IIl1IIlIll1I111IlI111lIl11Il = _ll1l11llIllllIll11II1l1lIll1I1llI1llI1111Il.matchAll(_ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.body)
_ll11111llIllIl111llIIl1lI111lIIll1I = []
_lll1llII1lIl11l11IIIIIl11I1II1lI1lIIl1I = {}
if _ll11I11IIl1IIlIll1I111IlI111lIl11Il <> invalid then
for each _ll11I1I11ll1l1lI1I111lI1IIlI1IIl1l1 in _ll11I11IIl1IIlIll1I111IlI111lIl11Il
if _ll11I1I11ll1l1lI1I111lI1IIlI1IIl1l1.Count() < 2 then continue for
_llII1I11111I11I1l1IIIl1I1llll11lIII = _ll11I1I11ll1l1lI1I111lI1IIlI1IIl1l1[1]
if _lll1llII1lIl11l11IIIIIl11I1II1lI1lIIl1I.DoesExist(_llII1I11111I11I1l1IIIl1I1llll11lIII) then continue for
_lll1llII1lIl11l11IIIIIl11I1II1lI1lIIl1I[_llII1I11111I11I1l1IIIl1I1llll11lIII] = true
_ll11111llIllIl111llIIl1lI111lIIll1I.Push(_llII1I11111I11I1l1IIIl1I1llll11lIII)
end for
end if
if _ll11111llIllIl111llIIl1lI111lIIll1I.Count() = 0 then _ll11111llIllIl111llIIl1lI111lIIll1I.Push(_llIIlIll1llIlII1lI1lIlI1l1lI111("305fa23d805b6ccff4f7eac5580bbe412487e225009376794cbfa0c5b0cb"))
_ll1l1lIl1I1IIII1l1111III11lIIl1IIIIlII1 = []
_llII11I1I1III1l1llIl11lI1l1II1IIl1llllI11ll = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("77d0d8f6e8e9eedc"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("42bb6aea35fe24d867"), Chr(105))
_llIl1Il1lIlI1I11l11lI1l1lI11llIllll1IIlIlI1 = _llII11I1I1III1l1llIl11lI1l1II1IIl1llllI11ll.split(_ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111)
if _llIl1Il1lIlI1I11l11lI1l1lI11llIllll1IIlIlI1 <> invalid then
for each _llIl111II111ll111Il1lIll1Ill11I11ll in _llIl1Il1lIlI1I11l11lI1l1lI11llIllll1IIlIlI1
_llll1Il1I1I111lI1I1llIIIllll1ll1Il1IIII = U_Trim(_llIl111II111ll111Il1lIll1Ill11I11ll)
if _llll1Il1I1I111lI1I1llIIIllll1ll1Il1IIII <> "" then _ll1l1lIl1I1IIII1l1111III11lIIl1IIIIlII1.Push(_llll1Il1I1I111lI1I1llIIIllll1ll1Il1IIII)
end for
end if
_ll111IlI111II11ll1llIl11I1II11l = []
_llIll1l1111ll11IlIII1IIIIlllI11IIII = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("691d7cb5ec763f75"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("327b127f234e533069"), Chr(103))
for each _llI1IlI1lII11lll1IlI1llll1llIIl in _ll1l1lIl1I1IIII1l1111III11lIIl1IIIIlII1
if Instr(1, _llI1IlI1lII11lll1IlI1llll1llIIl, (Chr(123) + Chr(118))) > 0 then
for each _llII1I11111I11I1l1IIIl1I1llll11lIII in _ll11111llIllIl111llIIl1lI111lIIll1I
_ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l = Instr(1, _llII1I11111I11I1l1IIIl1I1llll11lIII, Chr(46))
if _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l > 0 and _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l < Len(_llII1I11111I11I1l1IIIl1I1llll11lIII) then
_lllI1lI11IIIlllll1I1I11lIlI1l1I1Ill = Mid(_llII1I11111I11I1l1IIIl1I1llll11lIII, _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l + 1)
else
_lllI1lI11IIIlllll1I1I11lIlI1l1I1Ill = _llII1I11111I11I1l1IIIl1I1llll11lIII
end if
_ll111IlI111II11ll1llIl11I1II11l.Push(_llIll1l1111ll11IlIII1IIIIlllI11IIII.replaceAll(_llI1IlI1lII11lll1IlI1llll1llIIl, _lllI1lI11IIIlllll1I1I11lIlI1l1I1Ill))
end for
else
_ll111IlI111II11ll1llIl11I1II11l.Push(_llI1IlI1lII11lll1IlI1llll1llIIl)
end if
end for
_llI1I11IllI11l1IlIIl1lIl1I1I11II1Il1l1I1lIl = {}
for each _ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I in _ll111IlI111II11ll1llIl11I1II11l
if _ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I = "" or _llI1I11IllI11l1IlIIl1lIl1I1I11II1Il1l1I1lIl.DoesExist(_ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I) then continue for
_llI1I11IllI11l1IlIIl1lIl1I1I11II1Il1l1I1lIl[_ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I] = true
_lll111I111l11111l11I1IIIIIII11lIlI1 = HC_Get(_lllIIIlII1IIIl1IlIIllll11111lllIIII, _ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I, { "Referer": _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll }, 6000)
if _lll111I111l11111l11I1IIIIIII11lIlI1 = invalid or _lll111I111l11111l11I1IIIIIII11lIlI1.body = "" then continue for
if Left(_lll111I111l11111l11I1IIIIIII11lIlI1.body, 7) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("5f363e222932685d") then continue for
return {
url: _ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I
streamFormat: _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5c6c9b5b")
qualities: []
subtitles: RP_ExtractSubs(_ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.body)
chapters: []
referer: _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidsrcXyz(_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111 as String, _lllIIll1l111Ill1II1l1111I1lll1111I1111l as String, _llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll as Object) as Object
_ll1IlI1lIIIII111II1111lII1I1llIllI1 = _lllIIll1l111Ill1II1l1111I1lll1111I1111l
if _ll1IlI1lIIIII111II1111lII1I1llIllI1 = "" then _ll1IlI1lIIIII111II1111lII1I1llIllI1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4beaf9fcfbfd473f420c060412140856181c60")
_lll1II1IlIllI11ll11lII111I1llI1Il1l = HC_Get(_llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll, _llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111, { "Referer": _ll1IlI1lIIIII111II1111lII1I1llIllI1 }, 8000)
if _lll1II1IlIllI11ll11lII111I1llI1Il1l = invalid or _lll1II1IlIllI11ll11lII111I1llI1Il1l.body = "" then return invalid
_ll1Il111l1111I1III1l1I111I1lI1III111l1I = _lll1II1IlIllI11ll11lII111I1llI1Il1l.finalUrl
if _ll1Il111l1111I1III1l1I111I1lI1III111l1I = invalid or _ll1Il111l1111I1III1l1I111I1lI1III111l1I = "" then _ll1Il111l1111I1III1l1I111I1lI1III111l1I = _llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111
_ll1lllI1llI1I1lIIlll11l1lll1lIIl11I = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("2e7d2094e601fcef"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("66e81895f21f74a9f90935431b5771e0b0") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("6b0262195d32b8fc52a5cb20665a9f2408") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4647b0b1b95cbc4da8ac9e6bcc") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5b8f288f4823") + chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("612abed64f7a") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
m = _ll1lllI1llI1I1lIIlll11l1lll1lIIl11I.match(_lll1II1IlIllI11ll11lII111I1llI1Il1l.body)
if m = invalid or m.Count() < 2 then
_llI1l11I1I11llI1IlII1l1I11l11I1l1IlIlll1lI1 = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("3194c7ab2d2843a6"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6a3028df387a") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("2ed39141343fede0") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("6206be4405687bb649a457d2f5f0633d70") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("4eb8742e29c5") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
m = _llI1l11I1I11llI1IlII1l1I11l11I1l1IlIlll1lI1.match(_lll1II1IlIllI11ll11lII111I1llI1Il1l.body)
end if
if m <> invalid and m.Count() >= 2 then
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l = RP_AbsUrl(m[1], _ll1Il111l1111I1III1l1I111I1lI1III111l1I)
_lllllllII1Il11l1IlI11IlllII1I1l = RP_ResolveCloudnestra(_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l, _ll1Il111l1111I1III1l1I111I1lI1III111l1I, _llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll)
if _lllllllII1Il11l1IlI11IlllII1I1l <> invalid and _lllllllII1Il11l1IlI11IlllII1I1l.url <> "" then return _lllllllII1Il11l1IlI11IlllII1I1l
end if
_ll1llll1lIlllll11III1lI11I1IIII11lll111 = R_FollowKnownIframes(_lll1II1IlIllI11ll11lII111I1llI1Il1l.body, _ll1Il111l1111I1III1l1I111I1lI1III111l1I, _ll1IlI1lIIIII111II1111lII1I1llIllI1, 0, _llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll)
if _ll1llll1lIlllll11III1lI11I1IIII11lll111 <> invalid and _ll1llll1lIlllll11III1lI11I1IIII11lll111.url <> invalid and _ll1llll1lIlllll11III1lI11I1IIII11lll111.url <> "" then return _ll1llll1lIlllll11III1lI11I1IIII11lll111
return RP_ResolveGeneric(_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111, _lllIIll1l111Ill1II1l1111I1lll1111I1111l, _llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll)
end function
function RP_ResolveMoviesapi(_ll1l1Ill1lI1lI11II1I1l1lII1Ill1 as String, _llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I as String, _lll11Illl1IlI1lIII11IllII1lllII as Object) as Object
_llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = _llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I
if _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = "" then _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("33daf9fcfbfd372f32f206041107011049202a53")
_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I = HC_Get(_lll11Illl1IlI1lIII11IllII1lllII, _ll1l1Ill1lI1lI11II1I1l1lII1Ill1, { "Referer": _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 }, 8000)
if _lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I = invalid or _lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I.body = "" then return invalid
_llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = _lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I.finalUrl
if _llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = invalid or _llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = "" then _llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = _ll1l1Ill1lI1lI11II1I1l1lII1Ill1
_llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl = R_FollowKnownIframes(_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I.body, _llll111111lII1III1I1Il11I1Ill1l1II1I1I1, _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1, 0, _lll11Illl1IlI1lIII11IllII1lllII)
if _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl <> invalid and _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl.url <> invalid and _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl.url <> "" then return _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl
return RP_ResolveJwplayerPage(_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I.body, _llll111111lII1III1I1Il11I1Ill1l1II1I1I1, _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1, _lll11Illl1IlI1lIII11IllII1lllII)
end function
function RP_ResolveAutoembed(_lllI11Il1ll1llllIllIIIIlIllIllll1lll1ll as String, _llIlIl11III1l1II1IlI11111l1IIlIIllI as String, _llll1llII1II1I1lI1Illl1lll11lll as Object) as Object
_llllIl1III1IlIII1IIIIl11l11lIIl = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("42eb9873ebbdd907f1849648e4b2cd8dffbf4e1cba344487734e5ba7ed85dc22")
_llI111lIl1I11ll1I1IlIll11I1ll11l1ll = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3ecac9e517ee757f"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6d471d455791827e9e7cc675b75acf32bbf1bbdb40299ac67214c723dee7e090502d4d62de4992244499d54089723a"), Chr(105))
m = _llI111lIl1I11ll1I1IlIll11I1ll11l1ll.match(_lllI11Il1ll1llllIllIIIIlIllIllll1lll1ll)
if m = invalid or m.Count() < 3 then return invalid
_lll1l1lIlIII1111IlIIII11I1lI1lIIll1 = m[1]
_ll1I1II111lll1IlI1lI1l11llI1III = m[2]
_lllI1II11l1II11llIIIIlIlIlI1ll1II1l = ""
_lll1lIll1l1II11lIlIlIllIll1Il11lIIlll1l11l1 = ""
if m.Count() >= 5 then
_lllI1II11l1II11llIIIIlIlIlI1ll1II1l = m[3]
_lll1lIll1l1II11lIlIlIllIll1Il11lIIlll1l11l1 = m[4]
end if
_llllI1Ill1IIlII11IlII111IIlIIl1 = _llllIllII1II1I1ll1lll1lIlIII11I("5f43d74c31")
if Left(_ll1I1II111lll1IlI1lI1l11llI1III, 2) = (Chr(116) + Chr(116)) then _llllI1Ill1IIlII11IlII111IIlIIl1 = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("28f3a44f67")
_ll1lIIIl1Ill11Illl1l1lll1I1l11Il1lII1Il = _llIIlIll1llIlII1lI1lIlI1l1lI111("5477a2add8cb1c7f8af7fa1588b3deb1d447ea0b580b9e492cf722c56edbce878417dabb38034e5f") + _llllI1Ill1IIlII11IlII111IIlIIl1 + Chr(61) + U_UrlEncode(_ll1I1II111lll1IlI1lI1l11llI1III) + _llllIllII1II1I1ll1lll1lIlIII11I("484933e87d31b3") + _lll1l1lIlIII1111IlIIII11I1lI1lIIll1
if _lll1l1lIlIII1111IlIIII11I1lI1lIIll1 = (Chr(116) + Chr(118)) and _lllI1II11l1II11llIIIIlIlIlI1ll1II1l <> "" and _lll1lIll1l1II11lIlIlIllIll1Il11lIIlll1l11l1 <> "" then
_ll1lIIIl1Ill11Illl1l1lll1I1l11Il1lII1Il = _ll1lIIIl1Ill11Illl1l1lll1I1l11Il1lII1Il + _llIIlIll1llIlII1lI1lIlI1l1lI111("403fa05b46c12c3fd4") + _lllI1II11l1II11llIIIIlIlIlI1ll1II1l + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("53b3ed26760c2747145a") + _lll1lIll1l1II11lIlIlIllIll1Il11lIIlll1l11l1
end if
_lll1III111I11IIIIIIl1IIIII11lIIIl1II1II = HC_Get(_llll1llII1II1I1lI1Illl1lll11lll, _ll1lIIIl1Ill11Illl1l1lll1I1l11Il1lII1Il, {
"Referer": _llllIl1III1IlIII1IIIIl11l11lIIl
"Origin": _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6c5b775268581e44050c09680e62035005460155eb5ef354d846d51293679e")
}, 8000)
if _lll1III111I11IIIIIIl1IIIII11lIIIl1II1II = invalid or _lll1III111I11IIIIIIl1IIIII11lIIIl1II1II.body = "" then return invalid
_ll1l11IlI1I1Il111lllIl1lI1l1llI = ParseJSON(_lll1III111I11IIIIIIl1IIIII11lIIIl1II1II.body)
if _ll1l11IlI1I1Il111lllIl1lI1l1llI = invalid or type(_ll1l11IlI1I1Il111lllIl1lI1l1llI) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("57274d006409470c560d446950637b6970636f") then return invalid
_lllll11II1lI11IlllIIll1III1lIIlIIlIIlI1 = ""
if _ll1l11IlI1I1Il111lllIl1lI1l1llI.status_code <> invalid then _lllll11II1lI11IlllIIll1III1lIIlIIlIIlI1 = _ll1l11IlI1I1Il111lllIl1lI1l1llI.status_code.ToStr()
if _lllll11II1lI11IlllIIll1III1lIIlIIlIIlI1 <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("65f4f5f8") then return invalid
_llI1ll1I1ll1I1lIlI1l1l1lIII1Il1I1IIl1l11lIl = _ll1l11IlI1I1Il111lllIl1lI1l1llI.data
if _llI1ll1I1ll1I1lIlI1l1l1lIII1Il1I1IIl1l11lIl = invalid or type(_llI1ll1I1ll1I1lIlI1l1l1lIII1Il1I1IIl1l11lIl) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("665442275c5f4e554e5971577969487e81717c") then return invalid
_ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I = _llI1ll1I1ll1I1lIlI1l1l1lIII1Il1I1IIl1l11lIl.stream_urls
if _ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I = invalid or type(_ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4959787ad4fdfba9") or _ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I.Count() = 0 then return invalid
for each _llI1I111IlIII1I1I1l1lII11III1ll in _ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I
if type(_llI1I111IlIII1I1I1l1lII11III1ll) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4b11f9f6f4f8f4") and type(_llI1I111IlIII1I1I1l1lII11III1ll) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("5008c6573ca380d05d") then continue for
if _llI1I111IlIII1I1I1l1lII11III1ll = "" then continue for
_lllllllIIIIIIIlll1Il11111IIIlIIIlI1I1II = HC_Get(_llll1llII1II1I1lI1Illl1lll11lll, _llI1I111IlIII1I1I1l1lII11III1ll, { "Referer": _llllIl1III1IlIII1IIIIl11l11lIIl }, 6000)
if _lllllllIIIIIIIlll1Il11111IIIlIIIlI1I1II = invalid or _lllllllIIIIIIIlll1Il11111IIIlIIIlI1I1II.body = "" then continue for
if Left(_lllllllIIIIIIIlll1Il11111IIIlIIIlI1I1II.body, 7) <> _llllIllII1II1I1ll1lll1lIlIII11I("2b7e25db20b4983f") then continue for
return {
url: _llI1I111IlIII1I1I1l1lII11III1ll
streamFormat: _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2c4a4955")
qualities: []
subtitles: []
chapters: []
referer: _llllIl1III1IlIII1IIIIl11l11lIIl
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveYthd(_lll1l1IllIIlll1IIl1l1ll1llI11l1 as String, _llII1Il1l1IIllI1lllI1ll11llIlII111lIlII as String, _llII1l1111l11Il111IIl1IIIII1I111I1lIlllII11 as Object) as Object
_llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = {}
if _llII1Il1l1IIllI1lllI1ll11llIlII111lIlII <> "" then _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l[_llllIllII1II1I1ll1lll1lIlIII11I("3979ebc0f58bff95")] = _llII1Il1l1IIllI1lllI1ll11llIlII111lIlII
_llll11lI1IIl1ll1Illll1111lI11IIIIIl = HC_Get(_llII1l1111l11Il111IIl1IIIII1I111I1lIlllII11, _lll1l1IllIIlll1IIl1l1ll1llI11l1, _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l, 8000)
if _llll11lI1IIl1ll1Illll1111lI11IIIIIl = invalid or _llll11lI1IIl1ll1Illll1111lI11IIIIIl.body = "" then return invalid
_lll11lll1l1lII1I1IIlllI1ll1IIll = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("35142c3a282d2e2c"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3ae68ecf3da0d48f9c8f3b96026a") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("280f005e43566d01") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("519ba6d9593cd2") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("5ed795908bfc7f02b7da6a5d") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("7ad9534e") + chr(34), Chr(105))
_lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I = _lll11lll1l1lII1I1IIlllI1ll1IIll.match(_llll11lI1IIl1ll1Illll1111lI11IIIIIl.body)
if _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I <> invalid and _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I.Count() >= 3 then
_ll1I1lI1ll11IlIIl11I1lIIIlI1llIII111II1 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3d8d2684398e4f9254") + _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I[1] + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("33ed9476db06") + _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I[2]
return RP_ResolveCloudnestra(_ll1I1lI1ll11IlIIl11I1lIIIlI1llIII111II1, _lll1l1IllIIlll1IIl1l1ll1llI11l1, _llII1l1111l11Il111IIl1IIIII1I111I1lIlllII11)
end if
_llII1I1111I1l1Ill11I1IlI11llI11I1lI11Il = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("41340a3cb499bef2"), _llllIllII1II1I1ll1lll1lIlIII11I("749f54aa5e1ff86d930739") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("48a21649") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3ed8fe0e") + chr(34), Chr(105))
m = _llII1I1111I1l1Ill11I1IlI11llI11I1lI11Il.match(_llll11lI1IIl1ll1Illll1111lI11IIIIIl.body)
if m = invalid or m.Count() < 2 then return invalid
_llI1lIIII1l1l1IlIII1ll1IIlIlll1 = m[1]
_ll1I1lI1ll11IlIIl11I1lIIIlI1llIII111II1 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6d8d7684698e1f9204d70cad1da519810393098cf583f985c395d3c395b698edcec5da93") + _llI1lIIII1l1l1IlIII1ll1IIlIlll1
return RP_ResolveCloudnestra(_ll1I1lI1ll11IlIIl11I1lIIIlI1llIII111II1, _lll1l1IllIIlll1IIl1l1ll1llI11l1, _llII1l1111l11Il111IIl1IIIII1I111I1lIlllII11)
end function
function RP_ResolveVidking(_lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1 as String, _llIl11lI11ll1II11Ill11I1IIII1Il as String, _llIll1lIlll1l1IlIll11l11lI1lIll as Object) as Object
_llIll1l1llllllIlIIIl1l1l11l1I1l1lII = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6f31c37720b6df55"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6b6daab5a9b3b57f7fc7c8d2cccbe5e0e19ba0a0d7e2a800fbfee9f4babfc1d7d5cdcd040fd5dadfdf1621e7ecef04"), Chr(105))
m = _llIll1l1llllllIlIIIl1l1l11l1I1l1lII.match(_lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1)
if m = invalid or m.Count() < 3 then return invalid
_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1 = m[1]
_lll1IlI1I1IlII1lllIIl111llIlII1 = m[2]
_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = ""
_lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1 = ""
if m.Count() >= 5 then
_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = m[3]
_lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1 = m[4]
end if
_llIlIIlllI1I1IlII1II1IIIIllII11# = B_StrToLong(_lll1IlI1I1IlII1lllIIl111llIlII1)
return RP_VideasyFamilyResolve(_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1, _lll1IlI1I1IlII1lllIIl111llIlII1, _llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il, _lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1, _llIlIIlllI1I1IlII1II1IIIIllII11#, _lll1IlI1I1IlII1lllIIl111llIlII1, _llIll1lIlll1l1IlIll11l11lI1lIll)
end function
function RP_ResolveVideasy(_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I as String, _lll1lIllllIII1lIlII1IlIl1IIl11111l11l11 as String, _lll1Il1I11Il11l1IIl1IIIIlIII11IIllII1Il1lll as Object) as Object
_lll1ll111ll1I11lIll1lI1llIIIl1IIIlI11Illll1 = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("227acb949da4cea7"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("64737d3b3c38484f3b464797949e6d68a4a9ad99a1afb98883bfc4c1cb9a95d1d6d9c6"), Chr(105))
m = _lll1ll111ll1I11lIll1lI1llIIIl1IIIlI11Illll1.match(_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I)
if m = invalid or m.Count() < 3 then return invalid
_ll1l111IIIl1l11I1I1I1II11lII111ll11111I1III = m[1]
_ll111I11l111lI1lIIIIII11ll111IllI1l = m[2]
_lll111lIl1l1111l1llIllIllIllIll1lllll1IIIIl = ""
_llIlIl11lIIlIllIll1I1Il1Il1lI1l = ""
if m.Count() >= 5 then
_lll111lIl1l1111l1llIllIllIllIll1lllll1IIIIl = m[3]
_llIlIl11lIIlIllIll1I1Il1Il1lI1l = m[4]
end if
_llII1lIIIllIIIII11lllI1l1Il1I1l# = B_StrToLong(_ll111I11l111lI1lIIIIII11ll111IllI1l)
return RP_VideasyFamilyResolve(_ll1l111IIIl1l11I1I1I1II11lII111ll11111I1III, _ll111I11l111lI1lIIIIII11ll111IllI1l, _lll111lIl1l1111l1llIllIllIllIll1lllll1IIIIl, _llIlIl11lIIlIllIll1I1Il1Il1lI1l, _llII1lIIIllIIIII11lllI1l1Il1I1l#, _ll111I11l111lI1lIIIIII11ll111IllI1l, _lll1Il1I11Il11l1IIl1IIIIlIII11IIllII1Il1lll)
end function
function RP_VideasyFamilyResolve(_ll1I1I1IlIlII11I11I1lII1I1Il11Il111 as String, _llI11I11l111IlllllIlIllllllII1llII1l11l as String, _llII1lIl1ll1lIlI1Ill1l1lIIlI1I1 as String, _llII1IlllIIl11Il1llllII1lIl11I1 as String, _llllIllIll11IllI1l1Il1IlIIllI11 as LongInteger, _lll11l1ll11lIl1IlIIllII1lllIIII1111 as String, _llIIlIl111l1I1I1I1Il1lllll11llllII1llI1 as Object) as Object
_lllI11I1ll1l11IIl111I1IIIIlll111III = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("2c135ccdbccc2e9388d39891bf935962b86d1d503ed0e81e09") + _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 + Chr(47) + _llI11I11l111IlllllIlIllllllII1llII1l11l + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("62983b80209c149f34bd28f40efa17c003d819c7ba96b893928d899b8fd1b6c5aa")
_lllI11IlIlll11IIII1l1lIIll1111Ill1II11llllI = HC_Get(_llIIlIl111l1I1I1I1Il1lllll11llllII1llI1, _lllI11I1ll1l11IIl111I1IIIIlll111III, {}, 6000)
_lll11l1I1llI11II11III1IIIlIllIl1II1lllI = ""
_lllIl1I1lIll1I111lI1III11IIIII1lIIl1lllIlIl = ""
_ll1lIIlIlIllIl1l1lI1IlIl1Ill11IlllI = ""
if _lllI11IlIlll11IIII1l1lIIll1111Ill1II11llllI <> invalid and _lllI11IlIlll11IIII1l1lIIll1111Ill1II11llllI.body <> "" then
_llII11II1IIIIlIIlIl1I1IIl111I1l = ParseJSON(_lllI11IlIlll11IIII1l1lIIll1111Ill1II11llllI.body)
if type(_llII11II1IIIIlIIlIl1I1IIl111I1l) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("52c1534eb71ef6cf5b394849de566817e073a0") then
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("239fa09aa4b3") and _llII11II1IIIIlIIlIl1I1IIl111I1l.title <> invalid then _lll11l1I1llI11II11III1IIIlIllIl1II1lllI = _llII11II1IIIIlIIlIl1I1IIl111I1l.title
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = (Chr(116) + Chr(118)) and _llII11II1IIIIlIIlIl1I1IIl111I1l.name <> invalid then _lll11l1I1llI11II11III1IIIlIllIl1II1lllI = _llII11II1IIIIlIIlIl1I1IIl111I1l.name
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = _llllIllII1II1I1ll1lll1lIlIII11I("6c54790d23e8") and _llII11II1IIIIlIIlIl1I1IIl111I1l.release_date <> invalid then _lllIl1I1lIll1I111lI1III11IIIII1lIIl1lllIlIl = Left(_llII11II1IIIIlIIlIl1I1IIl111I1l.release_date, 4)
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = (Chr(116) + Chr(118)) and _llII11II1IIIIlIIlIl1I1IIl111I1l.first_air_date <> invalid then _lllIl1I1lIll1I111lI1III11IIIII1lIIl1lllIlIl = Left(_llII11II1IIIIlIIlIl1I1IIl111I1l.first_air_date, 4)
if _llII11II1IIIIlIIlIl1I1IIl111I1l.external_ids <> invalid and type(_llII11II1IIIIlIIlIl1I1IIl111I1l.external_ids) = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("77276d004409670c760d646970635b6950634f") then
if _llII11II1IIIIlIIlIl1I1IIl111I1l.external_ids.imdb_id <> invalid then _ll1lIIlIlIllIl1l1lI1IlIl1Ill11IlllI = _llII11II1IIIIlIIlIl1I1IIl111I1l.external_ids.imdb_id
end if
end if
end if
_ll1lIlII1ll1lI1lI1l11IllIIIIlllllIl = [_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4af507bb090208fc"), _llIIlIll1llIlII1lI1lIlI1l1lI111("5084c782"), _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4582b2452d465f4b6bdb9bb4")]
_ll1l1111Illllll11ll1I11IlI11I111111 = {
"Referer": _llllIllII1II1I1ll1lll1lIlIII11I("79d2989d6257c81c217b3f941ade7434be32e7fcc1a74c5c067a7b")
"Origin": _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("75cd6ec471ce07d21c8407f014f50c905f96559eaa85bfdbdec9")
"Accept": _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("416c7472")
}
for each _lll1IIl1lI1llll1IllII1I11II1lIllI1l11l1 in _ll1lIlII1ll1lI1lI1l11IllIIIIlllllIl
_llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2e8a797c7b7f4b6164998da7719cb0b0b2b1a6af89b2ce91") + _lll1IIl1lI1llll1IllII1I11II1lIllI1l11l1 + _llIIlIll1llIlII1lI1lIlI1l1lI111("2f4cf5601b0ea1bc37946d886b96cb8cbfa2ed409dce01e42f82cf") + U_UrlEncode(_lll11l1I1llI11II11III1IIIlIllIl1II1lllI) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7ad0de96299b535c1939e658") + _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 + _llllIllII1II1I1ll1lll1lIlIII11I("7c8193571c52eb") + U_UrlEncode(_lllIl1I1lIll1I111lI1III11IIIII1lIIl1lllIlIl)
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = (Chr(116) + Chr(118)) then
_llI11I111I111IIlIlIllI111I1lI11 = Chr(49)
_lllIlIllllII11llI11IlII1lIIlI1llII1llIl = Chr(49)
if _llII1IlllIIl11Il1llllII1lIl11I1 <> "" then _llI11I111I111IIlIlIllI111I1lI11 = _llII1IlllIIl11Il1llllII1lIl11I1
if _llII1lIl1ll1lIlI1Ill1l1lIIlI1I1 <> "" then _lllIlIllllII11llI11IlII1lIIlI1llII1llIl = _llII1lIl1ll1lIlI1Ill1l1lIIlI1I1
_llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 = _llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 + _llllIllII1II1I1ll1lll1lIlIII11I("3ba394c85e02489db275ac44") + _llI11I111I111IIlIlIllI111I1lI11 + _llIIlIll1llIlII1lI1lIlI1l1lI111("4f69da7560fb66694baf04") + _lllIlIllllII11llI11IlII1lIIlI1llII1llIl
end if
_llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 = _llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("34aadfe74ea79d49a0") + _llI11I11l111IlllllIlIllllllII1llII1l11l + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("75e0aeada7b0dab0ec") + U_UrlEncode(_ll1lIIlIlIllIl1l1lI1IlIl1Ill11IlllI)
_llI11llIl11l11I1IIIIIl111II1ll1II1I1II1 = HC_Get(_llIIlIl111l1I1I1I1Il1lllll11llllII1llI1, _llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11, _ll1l1111Illllll11ll1I11IlI11I111111, 8000)
if _llI11llIl11l11I1IIIIIl111II1ll1II1I1II1 = invalid or _llI11llIl11l11I1IIIIIl111II1ll1II1I1II1.body = "" then continue for
_llll11lII1lI1I1I1Il1III1I11lI1I1111IlIIlll1 = RP_VideasyDecrypt(U_Trim(_llI11llIl11l11I1IIIIIl111II1ll1II1I1II1.body), _llllIllIll11IllI1l1Il1IlIIllI11)
if _llll11lII1lI1I1I1Il1III1I11lI1I1111IlIIlll1 = "" then continue for
_lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111 = ParseJSON(_llll11lII1lI1I1I1Il1III1I11lI1I1111IlIIlll1)
if _lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111 = invalid or type(_lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("2fe255710b1681ac67b255887bfeea7c870a55") then continue for
_llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI = _lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111.sources
if _llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI = invalid or type(_llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("31af2b8803812f90") or _llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI.Count() = 0 then continue for
_ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l = ""
for each _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I in _llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI
if type(_ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("26d4c2a7dcdfced5ced9f1d7f9e9c8fe01f1fc") then continue for
if _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.url <> invalid and _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.url <> "" then
_ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l = _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.url
exit for
end if
if _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.file <> invalid and _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.file <> "" then
_ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l = _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.file
exit for
end if
end for
if _ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l = "" then continue for
_llII1111IlIIIlll1llII1I1111l111 = []
if _lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111.subtitles <> invalid and type(_lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111.subtitles) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3b7f66cb65d2e113") then
for each _lll11Il1111lI1l1I1I1l11Il1lIIlI in _lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111.subtitles
if type(_lll11Il1111lI1l1I1I1l11Il1lIIlI) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("36fd2cda05d326d637d725b331b91ab311b90e") then continue for
_ll1I111l1lIlII1I11lIlIl1lllIIII = ""
if _lll11Il1111lI1l1I1I1l11Il1lIIlI.url <> invalid then _ll1I111l1lIlII1I11lIlIl1lllIIII = _lll11Il1111lI1l1I1I1l11Il1lIIlI.url
if _ll1I111l1lIlII1I11lIlIl1lllIIII = "" and _lll11Il1111lI1l1I1I1l11Il1lIIlI.file <> invalid then _ll1I111l1lIlII1I11lIlIl1lllIIII = _lll11Il1111lI1l1I1I1l11Il1lIIlI.file
if _ll1I111l1lIlII1I11lIlIl1lllIIII = "" then continue for
_lll1lll1II1III1l11lIll1111I1l1lI11I1llI = (Chr(101) + Chr(110))
if _lll11Il1111lI1l1I1I1l11Il1lIIlI.language <> invalid then _lll1lll1II1III1l11lIll1111I1l1lI11I1llI = LCase(Left(_lll11Il1111lI1l1I1I1l11Il1lIIlI.language, 2))
if _lll1lll1II1III1l11lIll1111I1l1lI11I1llI = "" and _lll11Il1111lI1l1I1I1l11Il1lIIlI.lang <> invalid then _lll1lll1II1III1l11lIll1111I1l1lI11I1llI = LCase(Left(_lll11Il1111lI1l1I1I1l11Il1lIIlI.lang, 2))
_llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl = ""
if _lll11Il1111lI1l1I1I1l11Il1lIIlI.label <> invalid then _llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl = _lll11Il1111lI1l1I1I1l11Il1lIIlI.label
if _llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl = "" then _llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl = UCase(_lll1lll1II1III1l11lIll1111I1l1lI11I1llI)
_llII1111IlIIIlll1llII1I1111l111.Push({ url: _ll1I111l1lIlII1I11lIlIl1lllIIII, language: _lll1lll1II1III1l11lIll1111I1l1lI11I1llI, name: _llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl })
end for
end if
return {
url: _ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l
streamFormat: U_StreamFormat(_ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l)
qualities: []
subtitles: _llII1111IlIIIlll1llII1I1111l111
chapters: []
referer: _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("5a4f41465e4c2850330628723b77231270147a1c85079059eb5bfd19")
userAgent: ""
}
end for
return invalid
end function
function RP_VideasyDecrypt(_ll1I1Il1III1Ill1I11lIl1lIlIl1lIl1ll as String, _llII1lIl11II11lI11IlIIIlII1IIIlI111 as LongInteger) as String
if _ll1I1Il1III1Ill1I11lIl1lIlIl1lIl1ll = invalid or _ll1I1Il1III1Ill1I11lIl1lIlIl1lIl1ll = "" then return ""
_llll11IllI11II111ll1lI1l1III1lII1ll1l1l = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3224e990862b2f8cd4ee03a6"))
_llll11IllI11II111ll1lI1l1III1lII1ll1l1l.FromHexString(_ll1I1Il1III1Ill1I11lIl1lIlIl1lIl1ll)
if _llll11IllI11II111ll1lI1l1III1lII1ll1l1l.Count() = 0 then return ""
_lllIlIIIll1II111I1I1I11lII1I1I1I1lIlI1l1II1 = RP_VkLcgBytes(_llII1lIl11II11lI11IlIIIlII1IIIlI111, 50)
_llllllI1lIllI111llII1lI11III1IlIlIllIIl1ll1 = RP_VkSerializeBytes(_lllIlIIIll1II111I1I1I11lII1I1I1I1lIlI1l1II1)
_lllIlI1II1I111llIIIIl1IIl1lIlIlI11l1111IlIl = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("68ac17e086e793838be20ee6"))
_lllIlI1II1I111llIIIIl1IIl1lIlIlI11l1111IlIl.FromAsciiString(_llllllI1lIllI111llII1lI11III1IlIlIllIIl1ll1)
_llIll1IIl1I1Il1IlI1lI1lI11Ill1lIII1 = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("74338d965e5491fb33a9ec9ff40e1141b203bf86ed449b2b28d9868f843e41d1a8d0cf76ff3530dbd84a751cd7af11e1d2c3dcfc6d27c089c8389faca71e7a71a2706f571e156b5b58c095a697af8a")
_ll1I1Il1l1lI11IIl1lll1lIIIII1I111l11IIll1lI = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("589657c0a0d1d3a3b5cc2ec0"))
_ll1I1Il1l1lI11IIl1lll1lIIIII1I111l11IIll1lI.FromHexString(_llIll1IIl1I1Il1IlI1lI1lI11Ill1lIII1)
_llI11IlI1l1IlIl1lll1lIIIII111IlI1I1llll11Il = R4_KSA(_ll1I1Il1l1lI11IIl1lll1lIIIII1I111l11IIll1lI)
_llllllIIlIlI1lI11111I1lIlllIII1l111llIlI1I1 = R4_PRGA(_llI11IlI1l1IlIl1lll1lIIIII111IlI1I1llll11Il, _lllIlI1II1I111llIIIIl1IIl1lIlIlI11l1111IlIl)
_llII1111lIIIlIlII1l1l11l1lIII1llIIlII11ll11 = R4_KSA(_llllllIIlIlI1lI11111I1lIlllIII1l111llIlI1I1)
_llIlI1Illlll1Ill1lII1llllIl11Il = R4_PRGA(_llII1111lIIIlIlII1l1l11l1lIII1llIIlII11ll11, _llll11IllI11II111ll1lI1l1III1lII1ll1l1l)
if _llIlI1Illlll1Ill1lII1llllIl11Il.Count() < 32 then return ""
if _llIlI1Illlll1Ill1lII1llllIl11Il[0] <> 83 or _llIlI1Illlll1Ill1lII1llllIl11Il[1] <> 97 or _llIlI1Illlll1Ill1lII1llllIl11Il[2] <> 108 or _llIlI1Illlll1Ill1lII1llllIl11Il[3] <> 116 then return ""
if _llIlI1Illlll1Ill1lII1llllIl11Il[4] <> 101 or _llIlI1Illlll1Ill1lII1llllIl11Il[5] <> 100 or _llIlI1Illlll1Ill1lII1llllIl11Il[6] <> 95 or _llIlI1Illlll1Ill1lII1llllIl11Il[7] <> 95 then return ""
_llIIIII1lI1II11IllIIlI1l1IlI11I = B_Slice(_llIlI1Illlll1Ill1lII1llllIl11Il, 8, 16)
_lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = B_Slice(_llIlI1Illlll1Ill1lII1llllIl11Il, 16, _llIlI1Illlll1Ill1lII1llllIl11Il.Count())
_lll11l1IIIlIl1I11IlI1I1lIl1I1II11l11II11III = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("43f4a78b4df083af414ccf9a"))
_ll11ll1l11ll1IlI1lllII1I1lIl1l11lIIIlll = EvpBytesToKey(_lll11l1IIIlIl1I11IlI1I1lIl1I1II11l11II11III, _llIIIII1lI1II11IllIIlI1l1IlI11I, 32)
if _ll11ll1l11ll1IlI1lllII1I1lIl1l11lIIIlll.Count() < 32 then return ""
_lll1IlIIIIlI1l1l1I1lIIIlI11lII1IlI1IIII = B_Slice(_ll11ll1l11ll1IlI1lllII1I1lIl1l11lIIIlll, 0, 16)
_llI11l1lll1I1Il1ll1l1l1IlI1I11I1llI1l111IlI = B_Slice(_ll11ll1l11ll1IlI1lllII1I1lIl1l11lIIIlll, 16, 32)
_llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll = _lll1IlIIIIlI1l1l1I1lIIIlI11lII1IlI1IIII.ToHexString()
_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11 = _llI11l1lll1I1Il1ll1l1l1IlI1I11I1llI1l111IlI.ToHexString()
_llI111llI1I1llII1lllI1I11II11IlIll1 = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("30b0beebdddeeecbc7d2e0ce"))
_llI11II1III111I1lIIlIll1ll11II11111 = _llI111llI1I1llII1lllI1I11II11IlIll1.Setup(false, _llIIlIll1llIlII1lI1lIlI1l1lI111("53dac5801d889bd649424558"), _llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll, _ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11, 1)
if _llI11II1III111I1lIIlIll1ll11II11111 <> 0 then return ""
_ll1lIl1IlI1I1lllII11l1I1ll1I11I = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6bb0b086c4c2b695c5c8bed9"))
_llII1111l11lll1lllIlll1II1lIlll1I1l = _llI111llI1I1llII1lllI1I11II11IlIll1.Process(_lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1)
if _llII1111l11lll1lllIlll1II1lIlll1I1l <> invalid then
for _ll1III11llIl1lIIlIl1lI1l1IlllII = 0 to _llII1111l11lll1lllIlll1II1lIlll1I1l.Count() - 1
_ll1lIl1IlI1I1lllII11l1I1ll1I11I.Push(_llII1111l11lll1lllIlll1II1lIlll1I1l[_ll1III11llIl1lIIlIl1lI1l1IlllII])
end for
end if
_lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II = _llI111llI1I1llII1lllI1I11II11IlIll1.Final()
if _lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II <> invalid then
for _ll1III11llIl1lIIlIl1lI1l1IlllII = 0 to _lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II.Count() - 1
_ll1lIl1IlI1I1lllII11l1I1ll1I11I.Push(_lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II[_ll1III11llIl1lIIlIl1lI1l1IlllII])
end for
end if
if _ll1lIl1IlI1I1lllII11l1I1ll1I11I.Count() = 0 then return ""
return _ll1lIl1IlI1I1lllII11l1I1ll1I11I.ToAsciiString()
end function
function RP_VkLcgBytes(_llIl1Il111I1Il11I1l1IllIl1lIlI1II111l1l as LongInteger, _llI1lIlI11llI11lI11I11I11I111I1lIl1 as Integer) as Object
_ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("7d92e89f51869ce3b5baf074"))
_ll1lI1I11IIll1I11lIl1llI111Il1l1lIll1Il# = _llIl1Il111I1Il11I1l1IllIl1lIlI1II111l1l AND 2147483647&
for _lll1111I11lIl1ll1llI11IIl1IIIl1l1ll1I11II1I = 1 to _llI1lIlI11llI11lI11I11I11I111I1lIl1
_ll1lI1I11IIll1I11lIl1llI111Il1l1lIll1Il# = (_ll1lI1I11IIll1I11lIl1llI111Il1l1lIll1Il# * 1103515245& + 12345&) AND 2147483647&
_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I# = _ll1lI1I11IIll1I11lIl1llI111Il1l1lIll1Il# mod 255&
_ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl.Push(_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I#)
end for
return _ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl
end function
function RP_VkSerializeBytes(_lllIIlIII1lIl11lI1II1lIIIIl1lIl as Object) as String
if _lllIIlIII1lIl11lI1II1lIIIIl1lIl = invalid or _lllIIlIII1lIl11lI1II1lIIIIl1lIl.Count() = 0 then return ""
_ll11IlIII111IlI11Il1III1III11I1lIIl = ""
_ll11IllI11lI1lIl11llI1lll1IlI1I = _lllIIlIII1lIl11lI1II1lIIIIl1lIl.Count()
for _llI1IIlll111Il1ll1IlI1I1llII111 = 0 to _ll11IllI11lI1lIl11llI1lll1IlI1I - 1
if _llI1IIlll111Il1ll1IlI1I1llII111 > 0 then _ll11IlIII111IlI11Il1III1III11I1lIIl = _ll11IlIII111IlI11Il1III1III11I1lIIl + Chr(44)
_ll11IlIII111IlI11Il1III1III11I1lIIl = _ll11IlIII111IlI11Il1III1III11I1lIIl + _lllIIlIII1lIl11lI1II1lIIIIl1lIl[_llI1IIlll111Il1ll1IlI1I1llII111].ToStr()
end for
return _ll11IlIII111IlI11Il1III1III11I1lIIl
end function
function RP_ResolvePeachify(_ll11I1I11lI11lIll111l1lII1Il1Il as String, _ll1IIIllIll11IIlll1lllIII1ll1l1IllI as String, _ll1I1I1l1l1ll1III111IlIlII111I1I11llllIII1l as Object) as Object
_ll11lI1llIII1lIllI11I11lll1111l = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("36682ca3b903fa97"), _llIIlIll1llIlII1lI1lIlI1l1lI111("63778a7f9addc06b2ef914f5f0036fbb3c915c67b1fd7e797cff2295a81460e1dcd7ea56a2231e29a4"), Chr(105))
m = _ll11lI1llIII1lIllI11I11lll1111l.match(_ll11I1I11lI11lIll111l1lII1Il1Il)
if m = invalid or m.Count() < 3 then return invalid
_ll11lIlIl11l1Il1lIl1lII1Il1ll11 = m[1]
_ll11III1llIlIlI11IIIIll11I1l1Ill1ll1lll1l11 = m[2]
_lll1IlI1I1I1l11llI11I11lIII1l1IllIIlll1 = ""
_lllIIlllI1IIII1l1lII11Il1Il1l1l = ""
if m.Count() >= 5 then
_lll1IlI1I1I1l11llI11I11lIII1l1IllIIlll1 = m[3]
_lllIIlllI1IIII1l1lII11Il1Il1l1l = m[4]
end if
_llIIlll1I1I1ll111l1IlI11I1lllIl = [
{ host: _llIIlIll1llIlII1lI1lIlI1l1lI111("61dffa95268bb6196a4fc2ede8bb94890c9f"),  path: _llllIllII1II1I1ll1lll1lIlIII11I("4522d7ecf147") },
{ host: _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("48b5b6bb15d1d0c822cae0dfe0ee33d9eddf"),  path: _llIIlIll1llIlII1lI1lIlI1l1lI111("6b203bfe618cbf7205") },
{ host: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3d4b7c3a9615bd0a2be4db63d5c40a6b7986"),  path: _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("29e036f035e4") },
{ host: _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6eaa6ba12be310ff52ab40d649c400a01aa8"),  path: _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("581d5405") },
{ host: _llllIllII1II1I1ll1lll1lIlIII11I("777b60441d8e53892153a76c91e64fa195ab"),  path: _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5601fcfa") }
]
_lllII1lIlII111ll1l1111l1I1lIIIlIl1I = {
"Referer": _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7365686c7766017a1a2c085101430f751b3b4629a27f")
"Origin": _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2b5f466f555ac16512a73a2069491efceec9d54be8")
"Accept": _llIIlIll1llIlII1lI1lIlI1l1lI111("2a49dce75235908b3e619cafb0a568d3e6")
}
for each _ll1II1I1l11l11111IlIIl11llIlI1lIIlI in _llIIlll1I1I1ll111l1IlI11I1lllIl
_ll11II11lI1llIlIll111lllll1l1l1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6ccad1d4dbdba79598") + _ll1II1I1l11l11111IlIIl11llIlI1lIIlI.host + Chr(47) + _ll1II1I1l11l11111IlIIl11llIlI1lIIlI.path + Chr(47) + _ll11lIlIl11l1Il1lIl1lII1Il1ll11 + Chr(47) + _ll11III1llIlIlI11IIIIll11I1l1Ill1ll1lll1l11
if _ll11lIlIl11l1Il1lIl1lII1Il1ll11 = (Chr(116) + Chr(118)) and _lll1IlI1I1I1l11llI11I11lIII1l1IllIIlll1 <> "" and _lllIIlllI1IIII1l1lII11Il1Il1l1l <> "" then
_ll11II11lI1llIlIll111lllll1l1l1 = _ll11II11lI1llIlIll111lllll1l1l1 + Chr(47) + _lll1IlI1I1I1l11llI11I11lIII1l1IllIIlll1 + Chr(47) + _lllIIlllI1IIII1l1lII11Il1Il1l1l
end if
_ll1111111lllll1IllIlI1IIl111lIl = HC_Get(_ll1I1I1l1l1ll1III111IlIlII111I1I11llllIII1l, _ll11II11lI1llIlIll111lllll1l1l1, _lllII1lIlII111ll1l1111l1I1lIIIlIl1I, 8000)
if _ll1111111lllll1IllIlI1IIl111lIl = invalid or _ll1111111lllll1IllIlI1IIl111lIl.body = "" then continue for
_llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1 = ParseJSON(_ll1111111lllll1IllIlI1IIl111lIl.body)
if _llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1 = invalid or type(_llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6b819755255238a7af5a972b853e1eb6dfa344") then continue for
if _llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1.isEncrypted <> true then continue for
_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I = _llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1.data
if _llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I = invalid or type(_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("70016a34563b723560") then continue for
_ll1l1III11I11I111111IIl1l1l1IlI = RP_PeachifyDecrypt(_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I)
if _ll1l1III11I11I111111IIl1l1l1IlI = "" then continue for
_lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I = ParseJSON(_ll1l1III11I11I111111IIl1l1l1IlI)
if _lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I = invalid or type(_lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("6b083b97313c67d28dd83bae61e410a2ad307b") then continue for
_ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l = _lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I.sources
if _ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l = invalid or type(_ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("500c6fa92d38cb16") or _ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l.Count() = 0 then continue for
_ll1Illl1l11Il1lII11I1IIlIIIIlII = ""
for each _llIIIIlI11III111Illlll1lI1l1111I1lI in _ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l
if type(_llIIIIlI11III111Illlll1lI1l1111I1lI) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5ffdf7881778288bbb554e353d70ad33e24fa6") then continue for
if _llIIIIlI11III111Illlll1lI1l1111I1lI.url <> invalid and _llIIIIlI11III111Illlll1lI1l1111I1lI.url <> "" then
_ll1Illl1l11Il1lII11I1IIlIIIIlII = _llIIIIlI11III111Illlll1lI1l1111I1lI.url
exit for
end if
if _llIIIIlI11III111Illlll1lI1l1111I1lI.file <> invalid and _llIIIIlI11III111Illlll1lI1l1111I1lI.file <> "" then
_ll1Illl1l11Il1lII11I1IIlIIIIlII = _llIIIIlI11III111Illlll1lI1l1111I1lI.file
exit for
end if
end for
if _ll1Illl1l11Il1lII11I1IIlIIIIlII = "" then continue for
_ll1I11Il1lIllIlllIII1lIII1llllIIl11 = []
if _lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I.subtitles <> invalid and type(_lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I.subtitles) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("599ac8d11e75cf73") then
for each _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI in _lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I.subtitles
if type(_llIlI1IlIIIIlI1ll1lll1IIlIIlIlI) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("665442275c5f4e554e5971577969487e81717c") then continue for
_lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = ""
if _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.url <> invalid then _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.url
if _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = "" and _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.file <> invalid then _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.file
if _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = "" then continue for
_ll1llI111l1I1I11IIIlllI1l1ll11I1llI = (Chr(101) + Chr(110))
if _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.language <> invalid then _ll1llI111l1I1I11IIIlllI1l1ll11I1llI = LCase(Left(_llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.language, 2))
_ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 = ""
if _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.label <> invalid then _ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 = _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.label
if _ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 = "" then _ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 = UCase(_ll1llI111l1I1I11IIIlllI1l1ll11I1llI)
_ll1I11Il1lIllIlllIII1lIII1llllIIl11.Push({ url: _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI, language: _ll1llI111l1I1I11IIIlllI1l1ll11I1llI, name: _ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 })
end for
end if
_lllII1l1I1l1I11lI11IIll11l11l11Il1lIlI1llII = U_StreamFormat(_ll1Illl1l11Il1lII11I1IIlIIIIlII)
_lll11ll1IIllIII1lII1I1l111ll11III1l = LCase(_ll1Illl1l11Il1lII11I1IIlIIIIlII)
if Instr(1, _lll11ll1IIllIII1lII1I1l111ll11III1l, _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("52b9e59677")) > 0 then
_lllII1l1I1l1I11lI11IIll11l11l11Il1lIlI1llII = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("4dbdcc1a")
else if Instr(1, _lll11ll1IIllIII1lII1I1l111ll11III1l, _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7e52641f")) > 0 then
_lllII1l1I1l1I11lI11IIll11l11l11Il1lIlI1llII = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("52726371")
end if
return {
url: _ll1Illl1l11Il1lII11I1IIlIIIIlII
streamFormat: _lllII1l1I1l1I11lI11IIll11l11l11Il1lIlI1llII
qualities: []
subtitles: _ll1I11Il1lIllIlllIII1lIII1llllIIl11
chapters: []
referer: _llllIllII1II1I1ll1lll1lIlIII11I("3390d6db2055c69a9f390d5277cce136ecbc26da70e0")
userAgent: ""
}
end for
return invalid
end function
function RP_PeachifyDecrypt(_ll1III11llI1lIIlI1lllIIlIl1Illl as String) as String
if _ll1III11llI1lIIlI1lllIIlIl1Illl = invalid or _ll1III11llI1lIIlI1lllIIlIl1Illl = "" then return ""
_lllIIl1Il1I1IlIll1I1I1IlIl11111 = _ll1III11llI1lIIlI1lllIIlIl1Illl.Tokenize(Chr(46))
if _lllIIl1Il1I1IlIll1I1I1IlIl11111 = invalid or _lllIIl1Il1I1IlIll1I1I1IlIl11111.Count() < 3 then return ""
_ll1lIIll1111l1I1IIl1l1Il11II1ll = HC_Base64UrlDecode(_lllIIl1Il1I1IlIll1I1I1IlIl11111[0])
_ll1lI11ll11ll1lll11IlI1IlIllIlI = HC_Base64UrlDecode(_lllIIl1Il1I1IlIll1I1I1IlIl11111[1])
_lll1I1Il11l111ll1l11lII1IIlII1I = HC_Base64UrlDecode(_lllIIl1Il1I1IlIll1I1I1IlIl11111[2])
if _ll1lIIll1111l1I1IIl1l1Il11II1ll.Count() <> 12 then return ""
if _lll1I1Il11l111ll1l11lII1IIlII1I.Count() <> 16 then return ""
_ll1Il1IlIlIlI1I11l1Ill1lII1111IlIl1I11I1llI = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("25951a86b8141824b8d4990438c0195339a0141027c317d2c6e1d550e6c317900663d793a682959186e29613a7c2545244a154c4a581949004211750a440d49145")
_ll1lIII1IlI1III11I1I11I1l1Ill1I11ll = AGD_Decrypt(_ll1Il1IlIlIlI1I11l1Ill1lII1111IlIl1I11I1llI, _ll1lIIll1111l1I1IIl1l1Il11II1ll, _ll1lI11ll11ll1lll11IlI1IlIllIlI, _lll1I1Il11l111ll1l11lII1IIlII1I)
if _ll1lIII1IlI1III11I1I11I1l1Ill1I11ll = invalid then return ""
return _ll1lIII1IlI1III11I1I11I1l1Ill1I11ll.ToAsciiString()
end function
function RP_ResolvePrimesrc(_lllI11I1ll1I1I1ll1l1IllI11IIlIl as String, _ll1lIllII1II11I1l11111I1IllI11l as String, _llllI11I1llIllIIIll1lIlIl1111I1lIll1Ill as Object) as Object
return invalid
end function
function RP_ResolveStreamtape(_ll11IIlIIIlI1ll1IIl111IIIll1I1Ill11 as String, _ll11ll11lIlIll1lllI1I1lIlIll1l1 as String, _llIIl11lIIl11II11lIIlI1lll1I1l1 as Object) as Object
_llIIllll1lII1l11lllI1IIII1lII11 = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("733ff254b8d3ceb1"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("51b1606d816bc0bc727bca9a64d383dcdceb94e598e9ea"), Chr(105))
_ll11IIl1l11IIll1II111I1II11I1llIlIl = _llIIllll1lII1l11lllI1IIII1lII11.match(_ll11IIlIIIlI1ll1IIl111IIIll1I1Ill11)
if _ll11IIl1l11IIll1II111I1II11I1llIlIl = invalid or _ll11IIl1l11IIll1II111I1II11I1llIlIl.Count() < 2 then return invalid
_lllI1I1ll1II1Il11llIII1l1II1111lI1l = _llIIlIll1llIlII1lI1lIlI1l1lI111("4af6e1ecd7eabb5e69163934c7b29d70d36609ea0ffaf50e4b24") + _ll11IIl1l11IIll1II111I1II11I1llIlIl[1]
_llIlllII1lI111l1Ill1l111lI1I1llIllll1l11lII = {}
if _ll11ll11lIlIll1lllI1I1lIlIll1l1 <> "" then _llIlllII1lI111l1Ill1l111lI1I1llIllll1l11lII[_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("22760b2a9d07ce65")] = _ll11ll11lIlIll1lllI1I1lIlIll1l1
_llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1 = HC_Get(_llIIl11lIIl11II11lIIlI1lll1I1l1, _lllI1I1ll1II1Il11llIII1l1II1111lI1l, _llIlllII1lI111l1Ill1l111lI1I1llIllll1l11lII, 8000)
if _llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1 = invalid or _llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1.body = "" then return invalid
_lllI1llll11Il1I1I1III1111111lIIIIlI11II = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3bbd668f053361f0a20eafb47fcec81bfb8d36dcebc17e81e93efce74d185a0aebdf8626bcaa02d002766d73832ce593a2753d")
_llI1l1lIlII1Il1l1IlI11Ill1I1IIIlIlllIIlI1l1 = Instr(1, _llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1.body, _lllI1llll11Il1I1I1III1111111lIIIIlI11II)
if _llI1l1lIlII1Il1l1IlI11Ill1I1IIIlIlllIIlI1l1 <= 0 then return invalid
_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = Mid(_llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1.body, _llI1l1lIlII1Il1l1IlI11Ill1I1IIIlIlllIIlI1l1 + Len(_lllI1llll11Il1I1I1III1111111lIIIIlI11II))
_lll11II1l1IIIIlII11llI1IIII1I11 = Instr(1, _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1, Chr(39))
if _lll11II1l1IIIIlII11llI1IIII1I11 <= 0 then return invalid
_ll11Illl1II1Illl11I1lI1l1ll11111Ill = Left(_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1, _lll11II1l1IIIIlII11llI1IIII1I11 - 1)
_ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("284745504c060e18")
_llIlIIl1lI11IllI1lIlIIlIIIII11ll1ll = Instr(1, _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1, _ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII)
if _llIlIIl1lI11IllI1lIlIIlIIIII11ll1ll <= 0 then return invalid
_lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I = Mid(_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1, _llIlIIl1lI11IllI1lIlIIlIIIII11ll1ll + Len(_ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII))
_ll1lII1lll1l1IIllI11II1l11I11llI11IIlI1I1ll = Instr(1, _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I, Chr(39))
if _ll1lII1lll1l1IIllI11II1l11I11llI11IIlI1I1ll <= 0 then return invalid
_lll1IIl1lIlllIIIl1IIIllI11llllIl1l1IlI1I1I1 = Left(_lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I, _ll1lII1lll1l1IIllI11II1l11I11llI11IIlI1I1ll - 1)
_lllI1lllll111l1IllIlllI1IIllIl1I1I11IIlI1lI = _llIIlIll1llIlII1lI1lIlI1l1lI111("53123d487396db") + _ll11Illl1II1Illl11I1lI1l1ll11111Ill + _lll1IIl1lIlllIIIl1IIIllI11llllIl1l1IlI1I1I1
return {
url: _lllI1lllll111l1IllIlllI1IIllIl1I1I11IIlI1lI
streamFormat: U_StreamFormat(_lllI1lllll111l1IllIlllI1IIllIl1I1I11IIlI1lI)
qualities: []
subtitles: []
chapters: []
referer: _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6a0f71066e0c18100345033a1f271c07020f104da648bb03")
userAgent: ""
}
end function
function RP_ResolveUqload(_llIIllll1ll1Il111IIl1lIIl1lIl11l1llIIII as String, _ll11IllII11I1lll11II1I11Il1ll1I11l11IlI as String, _llIlI11I1lIlI1l1I1lI1lIll1lllll as Object) as Object
_llII1l11llI11l111IIIl11II1I11llIIII = {}
if _ll11IllII11I1lll11II1I11Il1ll1I11l11IlI <> "" then _llII1l11llI11l111IIIl11II1I11llIIII[_llllIllII1II1I1ll1lll1lIlIII11I("2643978ca155ab5f")] = _ll11IllII11I1lll11II1I11Il1ll1I11l11IlI
_llI1Il1lI1lIl11lllllIII1lIIllI1II11IlIl = HC_Get(_llIlI11I1lIlI1l1I1lI1lIll1lllll, _llIIllll1ll1Il111IIl1lIIl1lIl11l1llIIII, _llII1l11llI11l111IIIl11II1I11llIIII, 8000)
if _llI1Il1lI1lIl11lllllIII1lIIllI1II11IlIl = invalid or _llI1Il1lI1lIl11lllllIII1lIIllI1II11IlIl.body = "" then return invalid
_ll1111IIllllll1lIlI1I1IIl1ll1I11IIl111I = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7e4d647948727566"), _llllIllII1II1I1ll1lll1lIlIII11I("4b69ad13687c21879e910107b2a515c136") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("35b5ab60") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("22345277") + chr(34), Chr(105))
m = _ll1111IIllllll1lIlI1I1IIl1ll1I11IIl111I.match(_llI1Il1lI1lIl11lllllIII1lIIllI1II11IlIl.body)
if m = invalid or m.Count() < 2 then return invalid
_llllIIllI1111I1I1II11lIllI1111Illl1llII11ll = m[1]
if Left(_llllIIllI1111I1I1II11lIllI1111Illl1llII11ll, 4) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2d3aa28b3c") then return invalid
return {
url: _llllIIllI1111I1I1II11lIllI1111Illl1llII11ll
streamFormat: U_StreamFormat(_llllIIllI1111I1I1II11lIllI1111Illl1llII11ll)
qualities: []
subtitles: []
chapters: []
referer: _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("26a69178a199c2e556db92f666469526809965")
userAgent: ""
}
end function
function RP_ResolveDoodstream(_llI1I1I1111IlIl1IlII1l11IlIIll1 as String, _ll11IIllI1IIl1lIlI1II1l11l11l11IIII as String, _llIIlIl1IIlI11IIl1l111I11lI1I11Il11I1ll1IlI as Object) as Object
_ll11ll1l11l11llIlI1l11IIIIll1lIll1II1IllI11 = {}
if _ll11IIllI1IIl1lIlI1II1l11l11l11IIII <> "" then _ll11ll1l11l11llIlI1l11IIIIll1lIll1II1IllI11[_llIIlIll1llIlII1lI1lIlI1l1lI111("2fe385989b0eb124")] = _ll11IIllI1IIl1lIlI1II1l11l11l11IIII
_ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill = HC_Get(_llIIlIl1IIlI11IIl1l111I11lI1I11Il11I1ll1IlI, _llI1I1I1111IlIl1IlII1l11IlIIll1, _ll11ll1l11l11llIlI1l11IIIIll1lIll1II1IllI11, 8000)
if _ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill = invalid or _ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.body = "" then return invalid
_llll111IIIIll1IIl11I1I1lllII1II = _ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.finalUrl
if _llll111IIIIll1IIl11I1I1lllII1II = invalid or _llll111IIIIll1IIl11I1I1lllII1II = "" then _llll111IIIIll1IIl11I1I1lllII1II = _llI1I1I1111IlIl1IlII1l11IlIIll1
if Instr(1, _ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.body, _llllIllII1II1I1ll1lll1lIlIII11I("2dae80947a7fc6e85d77db")) <= 0 then return invalid
_ll1IllIIl1IIIlll11llllIl1l1l11l1IllIII1 = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("44ec93bb429910cb"), _llIIlIll1llIlII1lI1lIlI1l1lI111("32f21396313ca622f57a55bdf036") + chr(34) + (Chr(93) + Chr(43)), Chr(105))
_llIl1IIlI1IIIIl1IIllI1llIII1IIIIl11l1Il = _ll1IllIIl1IIIlll11llllIl1l1l11l1IllIII1.match(_ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.body)
if _llIl1IIlI1IIIIl1IIllI1llIII1IIIIl11l1Il = invalid or _llIl1IIlI1IIIIl1IIllI1llIII1IIIIl11l1Il.Count() < 1 then return invalid
_lll1I1IlllI111IIllIlll1Il1I1lI11III = _llIl1IIlI1IIIIl1IIllI1llIII1IIIIl11l1Il[0]
_llII11IIlI11IlIllI11lIlll1IllIIII11 = HC_OriginOf(_llll111IIIIll1IIl11I1I1lllII1II)
if _llII11IIlI11IlIllI11lIlll1IllIIII11 = "" then return invalid
_lllII1111l1lIlI1lllIlllIl1111l1lllI = _llII11IIlI11IlIllI11lIlll1IllIIII11 + _lll1I1IlllI111IIllIlll1Il1I1lI11III
_llll1l1lIIIIIll1l1l111I1II1l111 = 0
for _lllIIIlIIII1Il1II1llIlIl1IIl1I1I11I = 1 to Len(_lll1I1IlllI111IIllIlll1Il1I1lI11III)
if Mid(_lll1I1IlllI111IIllIlll1Il1I1lI11III, _lllIIIlIIII1Il1II1llIlIl1IIl1I1I11I, 1) = Chr(47) then _llll1l1lIIIIIll1l1l111I1II1l111 = _lllIIIlIIII1Il1II1llIlIl1IIl1I1I11I
end for
if _llll1l1lIIIIIll1l1l111I1II1l111 = 0 or _llll1l1lIIIIIll1l1l111I1II1l111 = Len(_lll1I1IlllI111IIllIlll1Il1I1lI11III) then return invalid
_llllIIl1IIll11I1I11lll1II1I1lll = Mid(_lll1I1IlllI111IIllIlll1Il1I1lI11III, _llll1l1lIIIIIll1l1l111I1II1l111 + 1)
_llIIl1IllI1I11lllI1I1lI11ll111IlIlI = HC_Get(_llIIlIl1IIlI11IIl1l111I11lI1I11Il11I1ll1IlI, _lllII1111l1lIlI1lllIlllIl1111l1lllI, { "Referer": _llll111IIIIll1IIl11I1I1lllII1II }, 8000)
if _llIIl1IllI1I11lllI1I1lI11ll111IlIlI = invalid or _llIIl1IllI1I11lllI1I1lI11ll111IlIlI.body = "" then return invalid
_lllII1IlII11lllI1IIl1l11l1IIIllIlIIllll11l1 = RP_RandomB62String(10)
_ll1lII1lI111ll11I1I1ll1l11I1IllI1Il1IIIlll1 = RP_NowMillis()
_llII1IlIl11l1I1l1IlI1111lII1I1ll1lII1llI1ll = _llIIl1IllI1I11lllI1I1lI11ll111IlIlI.body + _lllII1IlII11lllI1IIl1l11l1IIIllIlIIllll11l1 + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7217514d54495727") + _llllIIl1IIll11I1I11lll1II1I1lll + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4f17e65de7499a98c1") + _ll1lII1lI111ll11I1I1ll1l11I1IllI1Il1IIIlll1
_ll1lI1III1II1llI1lIIl1I1IlI11l1ll1I1lI1lll1 = ""
_llI1Ill1llIll1lIlllII1l111l1l1lI1IlIl11 = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("49d4e4baf0f5f6dc"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("475d1f2a3f49213e8275567ec69b333e81afc1ecb2896f"), Chr(105))
_lllI1I11IlI1lII1lIllIlll1lIII11 = _llI1Ill1llIll1lIlllII1l111l1l1lI1IlIl11.match(_ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.body)
if _lllI1I11IlI1lII1lIllIlll1lIII11 <> invalid and _lllI1I11IlI1lII1lIllIlll1lIII11.Count() >= 2 then
_llIl1l1IIlll1lI111II1l111lllIll = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("42344a1a464b4c4c"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5b2a816c621d3d28746a46"), Chr(105))
_llI1I1lI1llI1IllI11Ill1l1llIIIlIlll = _llIl1l1IIlll1lI111II1l111lllIll.match(_lllI1I11IlI1lII1lIllIlll1lIII11[1])
if _llI1I1lI1llI1IllI11Ill1l1llIIIlIlll <> invalid and _llI1I1lI1llI1IllI11Ill1l1llIIIlIlll.Count() >= 2 then _ll1lI1III1II1llI1lIIl1I1IlI11l1ll1I1lI1lll1 = _llI1I1lI1llI1IllI11Ill1l1llIIIlIlll[1]
end if
return {
url: _llII1IlIl11l1I1l1IlI1111lII1I1ll1lII1llI1ll
streamFormat: U_StreamFormat(_llII1IlIl11l1I1l1IlI1111lII1I1ll1lII1llI1ll)
qualities: []
subtitles: []
chapters: []
referer: _llII11IIlI11IlIllI11lIlll1IllIIII11 + Chr(47)
userAgent: _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4642635e6b52545601451d22063376347a277636896cf87fb767b160a412b07c8542da49ce5b691c70087e50444957396e126e3277263335ce38d03cde13d969d10ccf04b401c70dde0a9c94b58bb2b6ffa69b84fa90e79196869299837e9279875e9024b92ac130c17fdc40d340c1bc")
}
end function
function RP_RandomB62String(_ll11l1Il11IlI1II1l11ll111IIllII as Integer) as String
_ll1ll11l1I1lllII11I1lII1IlIl1ll = _llIIlIll1llIlII1lI1lIlI1l1lI111("7a799c9fc2c5e8eb8e91b4b7dadd0003a6a9cccff2f5181bbec1e498bbbee1e4070aadb0d3d6f9fc1f22c5c8ebee1114373adde0033c3f6265888baeb15457")
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = ""
for _ll1IlIIII11l1I11Ill1Illl1lII1Il1III = 1 to _ll11l1Il11IlI1II1l11ll111IIllII
_lllIll1IlII1I1IlI1lIllI1II1l1lI = Rnd(62)
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill + Mid(_ll1ll11l1I1lllII11I1lII1IlIl1ll, _lllIll1IlII1I1IlI1lIllI1II1l1lI, 1)
end for
return _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill
end function
function RP_NowMillis() as String
_lllll1lllIIllllIlIII1lI11lI1II1 = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4efe3583181809c77e944c"))
_lllll1lllIIllllIlIII1lI11lI1II1.Mark()
_lllllII11llI1Illl11I1llll11IlIlll11llII = _lllll1lllIIllllIlIII1lI11lI1II1.AsSeconds()
_lllIIIIl1111l1IIl1IllI1IIl11IllIlII = _lllll1lllIIllllIlIII1lI11lI1II1.GetMilliseconds()
_llll111l1IIIII1I1I1ll1llIlllI11Il11 = _lllIIIIl1111l1IIl1IllI1IIl11IllIlII.ToStr()
_llll111l1IIIII1I1I1ll1llIlllI11Il11 = Right(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("2c3d4ddc") + _llll111l1IIIII1I1I1ll1llIlllI11Il11, 3)
return _lllllII11llI1Illl11I1llll11IlIlll11llII.ToStr() + _llll111l1IIIII1I1I1ll1llIlllI11Il11
end function
function RP_ResolveVoe(_ll1IlI11lIIlll1lIlIII1IlI11llIlllIllll1IIIl as String, _llllIlIlII1lIIIIIIllIlI1I1I1lll as String, _llIlIll1IlI1ll1lII11IIII11llIlII1I11I1I as Object) as Object
_lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II = {}
if _llllIlIlII1lIIIIIIllIlI1I1I1lll <> "" then _lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II[_llllIllII1II1I1ll1lll1lIlIII11I("7935a77cb147bb51")] = _llllIlIlII1lIIIIIIllIlI1I1I1lll
_lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II[_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("71e6263b10d87130c9e926")] = _llIIlIll1llIlII1lI1lIlI1l1lI111("384d49bc4f828d308de8abe671bc0cc8ebc6f9442fd42c87f5788b66a1d437c783a6f30e21844d2a45e8bbbb4f5a4508821e01435fd287e2bde8bbde118cd7c7ea55182b39e44d302b261b2b47226d98956858bcf7daf5c0fd383b76316c47825d9823932f5245c89bb813ee19ec0f42")
_lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1 = HC_Get(_llIlIll1IlI1ll1lII11IIII11llIlII1I11I1I, _ll1IlI11lIIlll1lIlIII1IlI11llIlllIllll1IIIl, _lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II, 8000)
if _lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1 = invalid or _lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1.body = "" then return invalid
_ll111I1IllIl111lIlIl11IIII1lII1l1lIIIlI1lI1 = _lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1.body
_lll1l1lI1lII11llll1lI1lIllllII1lI1I = _lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1.finalUrl
if _lll1l1lI1lII11llll1lI1lIllllII1lI1I = invalid or _lll1l1lI1lII11llll1lI1lIllllII1lI1I = "" then _lll1l1lI1lII11llll1lI1lIllllII1lI1I = _ll1IlI11lIIlll1lIlIII1IlI11llIlllIllll1IIIl
_lll1ll111l1lII1Ill1111lI1I11I111IlI = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7ce166d54ade77ca"), _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4c5ecbcb39bacc3ad6f780302311849e4453229b0be91e2aae1f4aeff178cce6530373053021d6be"), Chr(105))
_llIIIll11lIl1II1lI11I1Ill1l1lIIIlll1ll1 = _lll1ll111l1lII1Ill1111lI1I11I111IlI.match(_ll111I1IllIl111lIlIl11IIII1lII1l1lIIIlI1lI1)
if _llIIIll11lIl1II1lI11I1Ill1l1lIIIlll1ll1 <> invalid and _llIIIll11lIl1II1lI11I1Ill1l1lIIIlll1ll1.Count() >= 2 then
_lllll1I1l11lIIIIIIl1lllIlIII1llI1IlIlI1 = RP_AbsUrl(_llIIIll11lIl1II1lI11I1Ill1l1lIIIlll1ll1[1], _lll1l1lI1lII11llll1lI1lIllllII1lI1I)
_lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I = HC_Get(_llIlIll1IlI1ll1lII11IIII11llIlII1I11I1I, _lllll1I1l11lIIIIIIl1lllIlIII1llI1IlIlI1, _lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II, 8000)
if _lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I <> invalid and _lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I.body <> "" then
_ll111I1IllIl111lIlIl11IIII1lII1l1lIIIlI1lI1 = _lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I.body
_lll1l1lI1lII11llll1lI1lIllllII1lI1I = _lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I.finalUrl
if _lll1l1lI1lII11llll1lI1lIllllII1lI1I = invalid or _lll1l1lI1lII11llll1lI1lIllllII1lI1I = "" then _lll1l1lI1lII11llll1lI1lIllllII1lI1I = _lllll1I1l11lIIIIIIl1lllIlIII1llI1IlIlI1
end if
end if
_llIII1I1lI1llIIII1ll11111IIl111II11lIll = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("55fe540afee308bc"), _llIIlIll1llIlII1lI1lIlI1l1lI111("458cb13cbf22e510b4d7df055d520548fb44") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6881757897958e938ba1a6aa6cac96b5b9") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("371d52554c1e64084055cc5fd4794ba1457baff9fdf367dd22c3"), Chr(105))
_llI11ll1IIll11II1Illll111llllllIlII = _llIII1I1lI1llIIII1ll11111IIl111II11lIll.match(_ll111I1IllIl111lIlIl11IIII1lII1l1lIIIlI1lI1)
if _llI11ll1IIll11II1Illll111llllllIlII = invalid or _llI11ll1IIll11II1Illll111llllllIlII.Count() < 2 then return invalid
_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI = U_Trim(_llI11ll1IIll11II1Illll111llllllIlII[1])
if Left(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, 2) <> Chr(91) + chr(34) then return invalid
_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI = Mid(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, 3)
_lll1IIII11IIIIllI1lllIII111ll1I1l11l1l1 = 0
for _lllIl1Illll1IlllI1llllIII1l1II1IIllll11 = Len(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI) to 1 step -1
if Mid(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, _lllIl1Illll1IlllI1llllIII1l1II1IIllll11, 1) = Chr(93) then
_lll1IIII11IIIIllI1lllIII111ll1I1l11l1l1 = _lllIl1Illll1IlllI1llllIII1l1II1IIllll11
exit for
end if
end for
if _lll1IIII11IIIIllI1lllIII111ll1I1l11l1l1 <= 1 then return invalid
_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI = Left(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, _lll1IIII11IIIIllI1lllIII111ll1I1l11l1l1 - 1)
if Right(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, 1) = chr(34) then _ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI = Left(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, Len(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI) - 1)
_ll1IIIl1Il11l1Il11lll111lI11IIIIII1I1II = RP_VoeDecrypt(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI)
if _ll1IIIl1Il11l1Il11lll111lI11IIIIII1I1II = "" then return invalid
_llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l = ParseJSON(_ll1IIIl1Il11l1Il11lll111lI11IIIIII1I1II)
if _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l = invalid or type(_llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("774bab3f99aee41e0633c3f2e297e376acf919") then return invalid
_ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l = ""
_llllI11l11111IlII111l1Ill1lIlI11l11 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("79dae1fb")
if _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.source <> invalid and type(_llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.source) = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("651987997db5032d0d") then
_ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l = _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.source
_llllI11l11111IlII111l1Ill1lIlI11l11 = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7a6c1668")
else if _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.direct_access_url <> invalid and type(_llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.direct_access_url) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("29a1517a77ecb739aa") then
_ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l = _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.direct_access_url
_llllI11l11111IlII111l1Ill1lIlI11l11 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("65487f05")
end if
if _ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l = "" then return invalid
return {
url: _ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l
streamFormat: _llllI11l11111IlII111l1Ill1lIlI11l11
qualities: []
subtitles: []
chapters: []
referer: _lll1l1lI1lII11llll1lI1lIllllII1lI1I
userAgent: _lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II[_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("605cddf7a2b22032b9293b")]
}
end function
function RP_VoeDecrypt(_ll1II1IIl1l11lIl1lll11I11lI1llIlllll1I11Ill as String) as String
if _ll1II1IIl1l11lIl1lll11I11lI1llIlllll1I11Ill = invalid or _ll1II1IIl1l11lIl1lll11I11lI1llIlllll1I11Ill = "" then return ""
_ll1l1lI1II1lll1III1I1l1Il1II11I = RP_VoeRot13(_ll1II1IIl1l11lIl1lll11I11lI1llIlllll1I11Ill)
_ll11I1Il11ll1I1l11IIIII1l11l1I1llI1llI1Il1l = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("642e59167990192c"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("35b98db3c57dac1fef37775886a0ae35e53ef9a6c623fa8719c0"), Chr(103))
_ll1l1lI1II1lll1III1I1l1Il1II11I = _ll11I1Il11ll1I1l11IIIII1l11l1I1llI1llI1Il1l.replaceAll(_ll1l1lI1II1lll1III1I1l1Il1II11I, Chr(95))
_llllIIIIIlII1llIIllII1lllIIlIIlll1lI1I1Il11 = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("61e71afc807b96f9"), Chr(95), Chr(103))
_ll1l1lI1II1lll1III1I1l1Il1II11I = _llllIIIIIlII1llIIllII1lllIIlIIlll1lI1I1Il11.replaceAll(_ll1l1lI1II1lll1III1I1l1Il1II11I, "")
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11 = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("584326daac9f220e909b2ef9"))
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11.FromBase64String(_ll1l1lI1II1lll1III1I1l1Il1II11I)
_ll1II11I1Il1lIl1lll1I1l11I111llIIlI1lll = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11.Count()
if _ll1II11I1Il1lIl1lll1I1l11I111llIIlI1lll = 0 then return ""
for _llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI = 0 to _ll1II11I1Il1lIl1lll1I1l11I111llIIlI1lll - 1
_llIIlIl1l11lIlI1lIlI1I1ll11l1l1 = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI] - 3
if _llIIlIl1l11lIlI1lIlI1I1ll11l1l1 < 0 then _llIIlIl1l11lIlI1lIlI1I1ll11l1l1 = _llIIlIl1l11lIlI1lIlI1I1ll11l1l1 + 256
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI] = _llIIlIl1l11lIlI1lIlI1I1ll11l1l1
end for
_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI = 0
_llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl = _ll1II11I1Il1lIl1lll1I1l11I111llIIlI1lll - 1
while _llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI < _llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl
_llllll1lIllll1l111IlIl11ll1IlII = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI]
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI] = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl]
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl] = _llllll1lIllll1l111IlIl11ll1IlII
_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI = _llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI + 1
_llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl = _llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl - 1
end while
_lll1I1I1111I11lIIIllIIIlI1IlllI111I1I1l = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11.ToAsciiString()
_lll1l1l1II1IIIlll1IllIllIIIIIl1lII1Il1lll11 = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("214e245b0dc2d89f7176ac30"))
_lll1l1l1II1IIIlll1IllIllIIIIIl1lII1Il1lll11.FromBase64String(_lll1I1I1111I11lIIIllIIIlI1IlllI111I1I1l)
if _lll1l1l1II1IIIlll1IllIllIIIIIl1lII1Il1lll11.Count() = 0 then return ""
return _lll1l1l1II1IIIlll1IllIllIIIIIl1lII1Il1lll11.ToAsciiString()
end function
function RP_VoeRot13(_llIllllIlIllI1llIlIIIlIl1I1Il1IIlllII1I as String) as String
if _llIllllIlIllI1llIlIIIlIl1I1Il1IIlllII1I = "" then return ""
_lll1llIllIlllI1IlllllI11IIII1IlllII = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("23a95a5c6ab4bc93cc1300f1"))
_lll1llIllIlllI1IlllllI11IIII1IlllII.FromAsciiString(_llIllllIlIllI1llIlIIIlIl1I1Il1IIlllII1I)
for _llIllI1lI1l11llI1I11ll1lIl11l11l1IlIIlI = 0 to _lll1llIllIlllI1IlllllI11IIII1IlllII.Count() - 1
_ll1III1II1lllIl1II111llIll1l1llIIlIIIll = _lll1llIllIlllI1IlllllI11IIII1IlllII[_llIllI1lI1l11llI1I11ll1lIl11l11l1IlIIlI]
if _ll1III1II1lllIl1II111llIll1l1llIIlIIIll >= 65 and _ll1III1II1lllIl1II111llIll1l1llIIlIIIll <= 90 then
_lll1llIllIlllI1IlllllI11IIII1IlllII[_llIllI1lI1l11llI1I11ll1lIl11l11l1IlIIlI] = ((_ll1III1II1lllIl1II111llIll1l1llIIlIIIll - 65 + 13) mod 26) + 65
else if _ll1III1II1lllIl1II111llIll1l1llIIlIIIll >= 97 and _ll1III1II1lllIl1II111llIll1l1llIIlIIIll <= 122 then
_lll1llIllIlllI1IlllllI11IIII1IlllII[_llIllI1lI1l11llI1I11ll1lIl11l11l1IlIIlI] = ((_ll1III1II1lllIl1II111llIll1l1llIIlIIIll - 97 + 13) mod 26) + 97
end if
end for
return _lll1llIllIlllI1IlllllI11IIII1IlllII.ToAsciiString()
end function
function RP_ResolveStreamsb(_llIll1I1ll1lIlI11I1lI111l1III1lIII1 as String, _llI1lIlI1lllIIII11I111III1111lIlI1II1ll as String, _ll1lIlIlIIlI11IlI1IIl111l1llI1lIl1I as Object) as Object
_llIlI1IIlIl11llIIIlllllllIIIlI1I11l1I1l = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("22ca89957df4cfd1"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("379d4c8c9990e74a324de442b0b19df2f3fffb6f3474d3becb56b043da0e0b81"), Chr(105))
_llII11IIllII11IIIl1l1l1Ill111I1II1II1Il1l1l = _llIlI1IIlIl11llIIIlllllllIIIlI1I11l1I1l.match(_llIll1I1ll1lIlI11I1lI111l1III1lIII1)
if _llII11IIllII11IIIl1l1l1Ill111I1II1II1Il1l1l = invalid or _llII11IIllII11IIIl1l1l1Ill111I1II1II1Il1l1l.Count() < 2 then return invalid
_llIlIl1lIIlIIlllI1IlI111lllll11 = _llII11IIllII11IIIl1l1l1Ill111I1II1II1Il1l1l[1]
_ll1I1Il111l1lII1lIl1llI11llIIlIlIl1Il1III11 = HC_HostOf(_llIll1I1ll1lIlI11I1lI111l1III1lIII1)
if _ll1I1Il111l1lII1lIl1llI11llIIlIlIl1Il1III11 = "" then return invalid
_ll1IIIl11lll1l11ll111I1llII1111l1l1I11I = _llllIllII1II1I1ll1lll1lIlIII11I("3330b8f741a739515519fd13648d92") + _llIlIl1lIIlIIlllI1IlI111lllll11 + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("5f98e17f3aa9136e44f4a91ab1f701d821f0dec656fe028b8d")
_llII1I1II1IlIIII1IIlllllIIIlIIlII1IlllI = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("79de8221cf9c6080ac9f40fd"))
_llII1I1II1IlIIII1IIlllllIIIlIIlII1IlllI.FromAsciiString(_ll1IIIl11lll1l11ll111I1llII1111l1l1I11I)
_llI11ll11IIllI1IlIlIlIIIlll1I1IlI1Ill11 = UCase(_llII1I1II1IlIIII1IIlllllIIIlIIlII1IlllI.ToHexString())
_llIllI1IlI1lllllll1I11I1llI1Il1Illl = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("31fda25bf2f9f36c9f") + _ll1I1Il111l1lII1lIl1llI11llIIlIlIl1Il1III11 + _llIIlIll1llIlII1lI1lIlI1l1lI111("64b019c41f42c5c05b785b1e") + _llI11ll11IIllI1IlIlIlIIIlll1I1IlI1Ill11
_lll1III1IlIlIlIl11IIIII1lII11lI = HC_Get(_ll1lIlIlIIlI11IlI1IIl111l1llI1lIl1I, _llIllI1IlI1lllllll1I11I1llI1Il1Illl, {
"Referer": _llIll1I1ll1lIlI11I1lI111l1III1lIII1
"watchsb": _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3d2b3945f7bf7e872f")
"Accept": _llllIllII1II1I1ll1lll1lIlIII11I("4f998d92582dd2b7eb41a69bb465f9bfb4")
}, 8000)
if _lll1III1IlIlIlIl11IIIII1lII11lI = invalid or _lll1III1IlIlIlIl11IIIII1lII11lI.body = "" then return invalid
_lllII1111lIl1l1llIl1llI1I1lllIIIIIl = ParseJSON(_lll1III1IlIlIlIl11IIIII1lII11lI.body)
if _lllII1111lIl1l1llIl1llI1I1lllIIIIIl = invalid or type(_lllII1111lIl1l1llIl1llI1I1lllIIIIIl) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("302f92ce4853bee9c40fc2e5c85b47c9d467b2") then return invalid
_ll11lII11Ill111Il1Il1I11Illl111ll11 = _lllII1111lIl1l1llIl1llI1I1lllIIIIIl.stream_data
if _ll11lII11Ill111Il1Il1I11Illl111ll11 = invalid or type(_ll11lII11Ill111Il1Il1I11Illl111ll11) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("469482a79c9f8e958e99b197b9a9c8bec1b1bc") then return invalid
_llIlIll11lI1I1I1lI11llllIIlI1Illl1IIlIl = ""
if _ll11lII11Ill111Il1Il1I11Illl111ll11.file <> invalid then _llIlIll11lI1I1I1lI11llllIIlI1Illl1IIlIl = U_Trim(_ll11lII11Ill111Il1Il1I11Illl111ll11.file)
if _llIlIll11lI1I1I1lI11llllIIlI1Illl1IIlIl = "" then return invalid
_lllI1I1l1lI1I1IIlIl1lIIIIIlIllIl11I = []
_llI1llII1lIlIlllIIl1l1l1IllllllII1I1l1l = _ll11lII11Ill111Il1Il1I11Illl111ll11.subs
if _llI1llII1lIlIlllIIl1l1l1IllllllII1I1l1l <> invalid and type(_llI1llII1lIlIlllIIl1l1l1IllllllII1I1l1l) = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("36682c2fec07b54f") then
for each _ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il in _llI1llII1lIlIlllIIl1l1l1IllllllII1I1l1l
if type(_ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5170f79c28f3b4640537ab47eaf68da28a3668") then continue for
_llII1Illll1IIl11lIIIllIlIlI1IlI = _ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il.file
if _llII1Illll1IIl11lIIIllIlIlI1IlI = invalid or _llII1Illll1IIl11lIIIllIlIlI1IlI = "" then continue for
_ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII = ""
if _ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il.label <> invalid then _ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII = _ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il.label
_ll1IlI1lIlI111I1llII1IIIllI1IlllIl111I1 = (Chr(101) + Chr(110))
if _ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII <> "" then _ll1IlI1lIlI111I1llII1IIIllI1IlllIl111I1 = LCase(Left(_ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII, 2))
_lllI1I1l1lI1I1IIlIl1lIIIIIlIllIl11I.Push({ url: _llII1Illll1IIl11lIIIllIlIlI1IlI, language: _ll1IlI1lIlI111I1llII1IIIllI1IlllIl111I1, name: _ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII })
end for
end if
return {
url: _llIlIll11lI1I1I1lI11llllIIlI1Illl1IIlIl
streamFormat: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("386b022f")
qualities: []
subtitles: _lllI1I1l1lI1I1IIlIl1lIIIIIlIllIl11I
chapters: []
referer: _llIll1I1ll1lIlI11I1lI111l1III1lIII1
userAgent: ""
}
end function
function RP_ResolveMixdrop(_ll1l1lIIllIII1lI1llIlIII1l1I1l1111ll1IlIlll as String, _llIl1IllIII1I111l1111l1I1l1llll111Ill1IllI1 as String, _lllI1l11lI1IlIl1lIlI1Il1ll1111llll1II1lll1l as Object) as Object
_llIIllIlIIIIIllIIIlll1lllI1llIl = {}
if _llIl1IllIII1I111l1111l1I1l1llll111Ill1IllI1 <> "" then _llIIllIlIIIIIllIIIlll1lllI1llIl[_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5656fa915aadb92d")] = _llIl1IllIII1I111l1111l1I1l1llll111Ill1IllI1 else _llIIllIlIIIIIllIIIlll1lllI1llIl[_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6b0f5b05431b6b05")] = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("54bb4fb250b826a43def3e8729883bae6efa65b3")
_llIIllIlIIIIIllIIIlll1lllI1llIl[_llllIllII1II1I1ll1lll1lIlIII11I("321f42285cb6791c41b65a")] = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2d35b4eae6a7889ba7ef8a10442c23a38dc707ef17f7bec56bb9ba4ed405629767712df565422bf3bb9500a7538528cb4b65f6885f8fce15dec073520317febe0fb75243b658cc5d272a6eeead76dec0dc4e0e1b63ff806a76cd1e9eeb72058c50de02c78193d372ec2b723b2dafbe78")
_lllII1I1IIl11lllll1I1l1l1lIl111 = HC_Get(_lllI1l11lI1IlIl1lIlI1Il1ll1111llll1II1lll1l, _ll1l1lIIllIII1lI1llIlIII1l1I1l1111ll1IlIlll, _llIIllIlIIIIIllIIIlll1lllI1llIl, 8000)
if _lllII1I1IIl11lllll1I1l1l1lIl111 = invalid or _lllII1I1IIl11lllll1I1l1l1lIl111.body = "" then return invalid
_lll1I1lII11llll11III1ll11I1IlI11Ill = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("5f23f72b61866ba1"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("4486a47bf7590564ee5df67f02e7b139b658e17d4dd68cbd6c4bb7700a220366f3dcec864fddcf88e78975eab798c43b351477"), Chr(105))
_llI1I11ll1111II1lI11lII11lII111lllI1l1I = _lll1I1lII11llll11III1ll11I1IlI11Ill.match(_lllII1I1IIl11lllll1I1l1l1lIl111.body)
if _llI1I11ll1111II1lI11lII11lII111lllI1l1I = invalid or _llI1I11ll1111II1lI11lII11lII111lllI1l1I.Count() < 2 then
_ll1II1III1I1IIl1II1IIIII1I1I11I = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("29ff33cb1fc022d4"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2b17defaf4a82b904a0a25613fa1726a8bb4590cd4b2cc56c50b68281c2b4b750ecd94738c922ca6e015aa67783f875defb87569da86f0b7278f62"), Chr(105))
_llI1I11ll1111II1lI11lII11lII111lllI1l1I = _ll1II1III1I1IIl1II1IIIII1I1I11I.match(_lllII1I1IIl11lllll1I1l1l1lIl111.body)
if _llI1I11ll1111II1lI11lII11lII111lllI1l1I = invalid or _llI1I11ll1111II1lI11lII11lII111lllI1l1I.Count() < 2 then return invalid
end if
_llI1lIII1III1IIlllll1llIlll1lIIl1Illl11lIII = _llI1I11ll1111II1lI11lII11lII111lllI1l1I[1]
_llII1Il1IIII11lllIII1l1II1llIII1lII = JU_UnpackPacked(_llI1lIII1III1IIlllll1llIlll1lIIl1Illl11lIII)
if _llII1Il1IIII11lllIII1l1II1llIII1lII = "" then return invalid
_lllllIlII1lIllIIIl1Illlllll1lI1 = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("77d0d8f6e8e9eedc"), _llllIllII1II1I1ll1lll1lIlIII11I("54975eb4c85c7ef8ddd2767ad161778ee575") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("73f19174") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("27079ca1") + chr(34), Chr(105))
_ll1IIl11l11I1lIIl1l1l111l1lIIlI = _lllllIlII1lIllIIIl1Illlllll1lI1.match(_llII1Il1IIII11lllIII1l1II1llIII1lII)
if _ll1IIl11l11I1lIIl1l1l111l1lIIlI = invalid or _ll1IIl11l11I1lIIl1l1l111l1lIIlI.Count() < 2 then return invalid
_lll1I1l1III11II1l11I111Il1II1ll = _ll1IIl11l11I1lIIl1l1l111l1lIIlI[1]
if Left(_lll1I1l1III11II1l11I111Il1II1ll, 2) = (Chr(47) + Chr(47)) then
_llllIII1IIllIIIlll11l1lIlI1l1Il1l1lIII1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("652a31343b410b") + _lll1I1l1III11II1l11I111Il1II1ll
else if Left(_lll1I1l1III11II1l11I111Il1II1ll, 4) = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("531208e11f") then
_llllIII1IIllIIIlll11l1lIlI1l1Il1l1lIII1 = _lll1I1l1III11II1l11I111Il1II1ll
else
return invalid
end if
_lll1l1lI1Il1l1l1IIlIIIIlII11II1lllIIlll = []
_ll111IlIl1IlIl11II11llllI1111IIlII1 = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("78df15eb7fa4895d"), _llIIlIll1llIlII1lI1lIlI1l1lI111("42006a9d3004a0c95ca7c20588031ea17d2f0497a95b30") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("50e28231") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("676c4933") + chr(34), Chr(105))
_llI111I111III1lI1lll1I1l1lI1I11I1lI = _ll111IlIl1IlIl11II11llllI1111IIlII1.match(_llII1Il1IIII11lllIII1l1II1llIII1lII)
if _llI111I111III1lI1lll1I1l1lI1I11I1lI <> invalid and _llI111I111III1lI1lll1I1l1lI1I11I1lI.Count() >= 2 then
_llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI = _llI111I111III1lI1lll1I1l1lI1I11I1lI[1]
if Left(_llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI, 2) = (Chr(47) + Chr(47)) then _llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("27daf1f4fbfdb7") + _llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI
if Left(_llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI, 4) = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("54bb4fb250") then
_lll1l1lI1Il1l1l1IIlIIIIlII11II1lllIIlll.Push({ url: _llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI, language: (Chr(101) + Chr(110)), name: _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7922ef5a7968887e046c") })
end if
end if
return {
url: _llllIII1IIllIIIlll11l1lIlI1l1Il1l1lIII1
streamFormat: U_StreamFormat(_llllIII1IIllIIIlll11l1lIlI1l1Il1l1lIII1)
qualities: []
subtitles: _lll1l1lI1Il1l1l1IIlIIIIlII11II1lllIIlll
chapters: []
referer: _llIIllIlIIIIIllIIIlll1lllI1llIl[_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6e5e92a33c87ed25")]
userAgent: _llIIllIlIIIIIllIIIlll1lllI1llIl[_llllIllII1II1I1ll1lll1lIlIII11I("55f013f90d7f4aed12670b")]
}
end function
function _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I(_lll11I1ll1111lIIl1lIIIll1I1lllIll1ll1l1III1 as String) as String
if _lll11I1ll1111lIIl1lIIIll1I1lllIll1ll1l1III1 = "" then return ""
_ll1111Ill1Il1IIllII11II1lIllII11lll = CreateObject("roByteArray")
_ll1111Ill1Il1IIllII11II1lIllII11lll.FromHexString(_lll11I1ll1111lIIl1lIIIll1I1lllIll1ll1l1III1)
_llll1lI1IIlIl11lllI1IIII1lII1lI11lI = _ll1111Ill1Il1IIllII11II1lIllII11lll.Count()
if _llll1lI1IIlIl11lllI1IIII1lII1lI11lI < 2 then return ""
_llII1I11lI1l111Ill11lIll1lIIIll = _ll1111Ill1Il1IIllII11II1lIllII11lll[0]
_llII1I1ll1l1lI1IlIIIlllIlI11IIll1I1 = (_llII1I11lI1l111Ill11lIll1lIIIll * 37 + 11) and 255
_ll1Ill1l1llIIllIIl111l1l1I1lIlI = (_llII1I11lI1l111Ill11lIll1lIIIll * 59 + 23) and 255
for _lll1llI1l1ll1llll111lI11IlI1III1lIIlI1IlllI = 1 to _llll1lI1IIlIl11lllI1IIII1lII1lI11lI - 1
_llIlllIII1Ill1l11IlIIllI1l1II1IllI1lI11 = (_ll1111Ill1Il1IIllII11II1lIllII11lll[_lll1llI1l1ll1llll111lI11IlI1III1lIIlI1IlllI] - ((_lll1llI1l1ll1llll111lI11IlI1III1lIIlI1IlllI - 1) * 3 + _ll1Ill1l1llIIllIIl111l1l1I1lIlI)) and 255
_ll1111Ill1Il1IIllII11II1lIllII11lll[_lll1llI1l1ll1llll111lI11IlI1III1lIIlI1IlllI] = (_llIlllIII1Ill1l11IlIIllI1l1II1IllI1lI11 + _llII1I1ll1l1lI1IlIIIlllIlI11IIll1I1) - 2 * (_llIlllIII1Ill1l11IlIIllI1l1II1IllI1lI11 and _llII1I1ll1l1lI1IlIIIlllIlI11IIll1I1)
end for
return Mid(_ll1111Ill1Il1IIllII11II1lIllII11lll.ToAsciiString(), 2)
end function
function _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I(_llIl1II1l11IlIl1Ill1I11I11I1IIIl111II111l1I as String) as String
if _llIl1II1l11IlIl1Ill1I11I11I1IIIl111II111l1I = "" then return ""
_ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1 = CreateObject("roByteArray")
_ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1.FromHexString(_llIl1II1l11IlIl1Ill1I11I11I1IIIl111II111l1I)
_ll1II11I111ll11I11III1I1l11ll1Ill1IIIllIl1l = _ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1.Count()
if _ll1II11I111ll11I11III1I1l11ll1Ill1IIIllIl1l < 2 then return ""
_llIII11Illl1I1Ill1l1Il1ll1lllII = _ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1[0]
_llIIIll1111IIIll1II1IlIl111Il1lIlIl = (_llIII11Illl1I1Ill1l1Il1ll1lllII * 41 + 19) and 255
_llIIllI1lllI111IIlI1llll111IIIIlI1Il1l111lI = _llIII11Illl1I1Ill1l1Il1ll1lllII
for _llIlI11l1III1IIll1I111l1IIIII1l1I11l11l111l = 1 to _ll1II11I111ll11I11III1I1l11ll1Ill1IIIllIl1l - 1
_llI1IlIllI1IIlI1lIl1lI11IIII1Il = _ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1[_llIlI11l1III1IIll1I111l1IIIII1l1I11l11l111l]
_llIlIlII1lI1IlIl1IlI1lII11lIl11IIIl11lIlIIl = ((_llIlI11l1III1IIll1I111l1IIIII1l1I11l11l111l - 1) * 7) and 255
_ll1IlIl1II1lI1I11llIl1Illlll111II1l = (_llI1IlIllI1IIlI1lIl1lI11IIII1Il + _llIIllI1lllI111IIlI1llll111IIIIlI1Il1l111lI) - 2 * (_llI1IlIllI1IIlI1lIl1lI11IIII1Il and _llIIllI1lllI111IIlI1llll111IIIIlI1Il1l111lI)
_ll1IlIl1II1lI1I11llIl1Illlll111II1l = (_ll1IlIl1II1lI1I11llIl1Illlll111II1l + _llIIIll1111IIIll1II1IlIl111Il1lIlIl) - 2 * (_ll1IlIl1II1lI1I11llIl1Illlll111II1l and _llIIIll1111IIIll1II1IlIl111Il1lIlIl)
_ll1IlIl1II1lI1I11llIl1Illlll111II1l = (_ll1IlIl1II1lI1I11llIl1Illlll111II1l + _llIlIlII1lI1IlIl1IlI1lII11lIl11IIIl11lIlIIl) - 2 * (_ll1IlIl1II1lI1I11llIl1Illlll111II1l and _llIlIlII1lI1IlIl1IlI1lII11lIl11IIIl11lIlIIl)
_ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1[_llIlI11l1III1IIll1I111l1IIIII1l1I11l11l111l] = _ll1IlIl1II1lI1I11llIl1Illlll111II1l and 255
_llIIllI1lllI111IIlI1llll111IIIIlI1Il1l111lI = _llI1IlIllI1IIlI1lIl1lI11IIII1Il
end for
return Mid(_ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1.ToAsciiString(), 2)
end function
function _llllIllII1II1I1ll1lll1lIlIII11I(_ll1I1Il111l111I1IIII111lllI11lll1II1ll1 as String) as String
if _ll1I1Il111l111I1IIII111lllI11lll1II1ll1 = "" then return ""
_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1 = CreateObject("roByteArray")
_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1.FromHexString(_ll1I1Il111l111I1IIII111lllI11lll1II1ll1)
_llI1111I1llIllI1I1I1IIIIlI1l11l = _lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1.Count()
if _llI1111I1llIllI1I1I1IIIIlI1l11l < 2 then return ""
_llIllIIIl1IlIl1I11III11IlIlI1l1 = _lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1[0]
_llIIl1lllII1lll1lllIlIIIIllIIIl = (_llIllIIIl1IlIl1I11III11IlIlI1l1 * 53 + 29) and 255
_lll1ll1Il1l1I1lllllllllII1lI1llI11I = (_llIllIIIl1IlIl1I11III11IlIlI1l1 * 71 + 31) and 255
for _lllll11Il1II1Il11lI111l1IIIll1I111l1l11 = 1 to _llI1111I1llIllI1I1I1IIIIlI1l11l - 1
_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI = (_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1[_lllll11Il1II1Il11lI111l1IIIll1I111l1l11] - ((_lllll11Il1II1Il11lI111l1IIIll1I111l1l11 - 1) * 5 + _lll1ll1Il1l1I1lllllllllII1lI1llI11I)) and 255
_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI = (((_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI \ 16) or ((_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI * 16) and 255))) and 255
_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1[_lllll11Il1II1Il11lI111l1IIIll1I111l1l11] = (_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI + _llIIl1lllII1lll1lllIlIIIIllIIIl) - 2 * (_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI and _llIIl1lllII1lll1lllIlIIIIllIIIl)
end for
return Mid(_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1.ToAsciiString(), 2)
end function
function _llIIlIll1llIlII1lI1lIlI1l1lI111(_llIIlIIl11Ill11I1l11I1llIIII1I111ll11II as String) as String
if _llIIlIIl11Ill11I1l11I1llIIII1I111ll11II = "" then return ""
_lll1l1I1II1I1111II1I1l111lIlIl1 = CreateObject("roByteArray")
_lll1l1I1II1I1111II1I1l111lIlIl1.FromHexString(_llIIlIIl11Ill11I1l11I1llIIII1I111ll11II)
_lll11lIIIIl1lllll1lIl1IIll11111 = _lll1l1I1II1I1111II1I1l111lIlIl1.Count()
if _lll11lIIIIl1lllll1lIl1IIll11111 < 2 then return ""
_llI1Il1llIII1II1IIIlIlI1I1l1l1l1II1 = _lll1l1I1II1I1111II1I1l111lIlIl1[0]
_lll11IIlI1lIIIIllIIIl11I11lI11l11lI1II11IIl = (_llI1Il1llIII1II1IIIlIlI1I1l1l1l1II1 * 67 + 43) and 255
_ll1llIIIlI1IlllI1ll1IlIlI1IlllIl1IIl1l11IIl = (_llI1Il1llIII1II1IIIlIlI1I1l1l1l1II1 * 79 + 17) and 255
for _llllI11Illl1lll1lI1lI1IIIIIIl11Ill1 = 1 to _lll11lIIIIl1lllll1lIl1IIll11111 - 1
_lllll1Illl1IIllIllI11l1I1l11l11 = (_lll1l1I1II1I1111II1I1l111lIlIl1[_llllI11Illl1lll1lI1lI1IIIIIIl11Ill1] - ((_llllI11Illl1lll1lI1lI1IIIIIIl11Ill1 - 1) * 11 + _ll1llIIIlI1IlllI1ll1IlIlI1IlllIl1IIl1l11IIl)) and 255
_lllll1Illl1IIllIllI11l1I1l11l11 = ((((_lllll1Illl1IIllIllI11l1I1l11l11 \ 8) or ((_lllll1Illl1IIllIllI11l1I1l11l11 * 32) and 255)))) and 255
_lll1l1I1II1I1111II1I1l111lIlIl1[_llllI11Illl1lll1lI1lI1IIIIIIl11Ill1] = (_lllll1Illl1IIllIllI11l1I1l11l11 + _lll11IIlI1lIIIIllIIIl11I11lI11l11lI1II11IIl) - 2 * (_lllll1Illl1IIllIllI11l1I1l11l11 and _lll11IIlI1lIIIIllIIIl11I11lI11l11lI1II11IIl)
end for
return Mid(_lll1l1I1II1I1111II1I1l111lIlIl1.ToAsciiString(), 2)
end function
function _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il(_ll111l1lI1ll111IlII1lI1IlIlI1l1I1Il as String) as String
if _ll111l1lI1ll111IlII1lI1IlIlI1l1I1Il = "" then return ""
_lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l = CreateObject("roByteArray")
_lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l.FromHexString(_ll111l1lI1ll111IlII1lI1IlIlI1l1I1Il)
_ll111IIII1IlI1ll1II11I1l1111IIII1Il = _lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l.Count()
if _ll111IIII1IlI1ll1II11I1l1111IIII1Il < 2 then return ""
_lll1IllIlllIlIIIIll11I1I11II1l1I1l11II1 = _lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l[0]
_lllIIlI1I1I1I1IIl1I1Il1II111IlI1l1IIIllI1Il = (_lll1IllIlllIlIIIIll11I1I11II1l1I1l11II1 * 73 + 19) and 255
_lll1Il1II1l1lllll11I1l1l1lllII11lI1l11l = (_lll1IllIlllIlIIIIll11I1I11II1l1I1l11II1 * 83 + 37) and 255
for _llI1IIl11Illllll11IlIl1Ill1lllIIIllIl1I = 1 to _ll111IIII1IlI1ll1II11I1l1111IIII1Il - 1
_ll1I1111Il1lIlI1ll1lllI1lIlIll1l1I111II1I11 = _llI1IIl11Illllll11IlIl1Ill1lllIIIllIl1I - 1
_llI11111111IlIlII11Illll1Illlllll111I1l = _lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l[_llI1IIl11Illllll11IlIl1Ill1lllIIIllIl1I]
_llI11111111IlIlII11Illll1Illlllll111I1l = ((((_llI11111111IlIlII11Illll1Illlllll111I1l \ 4) or ((_llI11111111IlIlII11Illll1Illlllll111I1l * 64) and 255)))) and 255
_ll1l1II1Il111IIll1I1I111IIll1IlI11I1111 = (_ll1I1111Il1lIlI1ll1lllI1lIlIll1l1I111II1I11 * 13 + _lll1IllIlllIlIIIIll11I1I11II1l1I1l11II1) and 255
_llI11111111IlIlII11Illll1Illlllll111I1l = (_llI11111111IlIlII11Illll1Illlllll111I1l + _ll1l1II1Il111IIll1I1I111IIll1IlI11I1111) - 2 * (_llI11111111IlIlII11Illll1Illlllll111I1l and _ll1l1II1Il111IIll1I1I111IIll1IlI11I1111)
_llI11111111IlIlII11Illll1Illlllll111I1l = (_llI11111111IlIlII11Illll1Illlllll111I1l - (_ll1I1111Il1lIlI1ll1lllI1lIlIll1l1I111II1I11 * 7 + _lll1Il1II1l1lllll11I1l1l1lllII11lI1l11l)) and 255
_llI11111111IlIlII11Illll1Illlllll111I1l = ((((_llI11111111IlIlII11Illll1Illlllll111I1l \ 16) or ((_llI11111111IlIlII11Illll1Illlllll111I1l * 16) and 255)))) and 255
_lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l[_llI1IIl11Illllll11IlIl1Ill1lllIIIllIl1I] = (_llI11111111IlIlII11Illll1Illlllll111I1l + _lllIIlI1I1I1I1IIl1I1Il1II111IlI1l1IIIllI1Il) - 2 * (_llI11111111IlIlII11Illll1Illlllll111I1l and _lllIIlI1I1I1I1IIl1I1Il1II111IlI1l1IIIllI1Il)
end for
return Mid(_lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l.ToAsciiString(), 2)
end function
function _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1(_lll1llI1III1I1lIlII11IlI1lII11I as String) as String
if _lll1llI1III1I1lIlII11IlI1lII11I = "" then return ""
_lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I = CreateObject("roByteArray")
_lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I.FromHexString(_lll1llI1III1I1lIlII11IlI1lII11I)
_llI1I1I1lII11IIll1I1IIll11II1I1II1lII1I = _lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I.Count()
if _llI1I1I1lII11IIll1I1IIll11II1I1II1lII1I < 2 then return ""
_lllll1llII11I1lI1llIlII111IllI11IIIll1IIIl1 = _lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I[0]
_llI111ll11l1I1IllIl1IlI1IIllII1l1l1 = (_lllll1llII11I1lI1llIlII111IllI11IIIll1IIIl1 * 97 + 53) and 255
_ll1l111l1l1ll1l1III1l11lIIllIlIIIIl1llI1l1l = (_lllll1llII11I1lI1llIlII111IllI11IIIll1IIIl1 * 103 + 61) and 255
for _lllI1lll111l1llI1lIlII11lllIl1111lIllIl = 1 to _llI1I1I1lII11IIll1I1IIll11II1I1II1lII1I - 1
_lll1IIl11111I1IlIlllI1ll1lI1lllll111III = _lllI1lll111l1llI1lIlII11lllIl1111lIllIl - 1
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = _lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I[_lllI1lll111l1llI1lIlII11lllIl1111lIllIl]
_llIllIlll11l111lIll1l1lI1l1l11II1IIlII1 = (_lll1IIl11111I1IlIlllI1ll1lI1lllll111III * 19 + _lllll1llII11I1lI1llIlII111IllI11IIIll1IIIl1) and 255
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l + _llIllIlll11l111lIll1l1lI1l1l11II1IIlII1) - 2 * (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l and _llIllIlll11l111lIll1l1lI1l1l11II1IIlII1)
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = ((((_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l \ 4) or ((_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l * 64) and 255)))) and 255
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l - (_lll1IIl11111I1IlIlllI1ll1lI1lllll111III * 17 + _ll1l111l1l1ll1l1III1l11lIIllIlIIIIl1llI1l1l)) and 255
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = ((((_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l \ 8) or ((_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l * 32) and 255)))) and 255
_lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I[_lllI1lll111l1llI1lIlII11lllIl1111lIllIl] = (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l + _llI111ll11l1I1IllIl1IlI1IIllII1l1l1) - 2 * (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l and _llI111ll11l1I1IllIl1IlI1IIllII1l1l1)
end for
return Mid(_lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I.ToAsciiString(), 2)
end function
function _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl(_ll11lIIll1lIlllllI1IllIIIl1IlIll1l11l1l as String) as String
if _ll11lIIll1lIlllllI1IllIIIl1IlIll1l11l1l = "" then return ""
_llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl = CreateObject("roByteArray")
_llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl.FromHexString(_ll11lIIll1lIlllllI1IllIIIl1IlIll1l11l1l)
_llIIl11lll1II1IllIlIIlIll1III1111lI11l1111l = _llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl.Count()
if _llIIl11lll1II1IllIlIIlIll1III1111lI11l1111l < 2 then return ""
_ll1I1111ll1II1lIlll1IIIII1IIlII1ll1 = _llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl[0]
_lll1III1I11lI1lIlllI11IIII1I111 = (_ll1I1111ll1II1lIlll1IIIII1IIlII1ll1 * 109 + 47) and 255
_lll1lll1lll1I1lIlIIl1lIl111IIIlIlIl11ll11l1 = (_ll1I1111ll1II1lIlll1IIIII1IIlII1ll1 * 113 + 71) and 255
for _llIl1l111I11I1I1IlIl11IlIII1l1Il1I1l1IlIl11 = 1 to _llIIl11lll1II1IllIlIIlIll1III1111lI11l1111l - 1
_llllIIllI1lllIl11l1IlllII1I1l1ll1II = _llIl1l111I11I1I1IlIl11IlIII1l1Il1I1l1IlIl11 - 1
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = _llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl[_llIl1l111I11I1I1IlIl11IlIII1l1Il1I1l1IlIl11]
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I + _lll1lll1lll1I1lIlIIl1lIl111IIIlIlIl11ll11l1) - 2 * (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I and _lll1lll1lll1I1lIlIIl1lIl111IIIlIlIl11ll11l1)
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I + (_llllIIllI1lllIl11l1IlllII1I1l1ll1II * 7 + _ll1I1111ll1II1lIlll1IIIII1IIlII1ll1)) and 255
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = ((((_llIlIl11l111lI1II111I1IIIll1111l1I1I11I \ 16) or ((_llIlIl11l111lI1II111I1IIIll1111l1I1I11I * 16) and 255)))) and 255
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I - (_llllIIllI1lllIl11l1IlllII1I1l1ll1II * 3 + _lll1lll1lll1I1lIlIIl1lIl111IIIlIlIl11ll11l1)) and 255
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I * 43) and 255
_llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl[_llIl1l111I11I1I1IlIl11IlIII1l1Il1I1l1IlIl11] = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I + _lll1III1I11lI1lIlllI11IIII1I111) - 2 * (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I and _lll1III1I11lI1lIlllI11IIII1I111)
end for
return Mid(_llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl.ToAsciiString(), 2)
end function