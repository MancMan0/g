function RP_ResolveGeneric(_lII11ll as String, _lIII1ll as String, _llllIll as Object) as Object
_lIlI1ll = {}
if _lIII1ll <> "" then _lIlI1ll[_l1d_55a757("94828688808e86", 60, 38)] = _lIII1ll
_l1II1ll = HC_Get(_llllIll, _lII11ll, _lIlI1ll, 8000)
if _l1II1ll = invalid or _l1II1ll.body = "" then return invalid
_l11I1ll = _l1II1ll.body
_lllI1ll = _l1II1ll.finalUrl
if _lllI1ll = invalid or _lllI1ll = "" then _lllI1ll = _lII11ll
_ll1I1ll = CreateObject(_l1d_55a757("361c1c282d2e3e", 13, 183), _l1d_55a757("6db0979aa1a168707e819898", 23, 46) + chr(34) + _l1d_55a757("70686b6e489678897d92549d62a88e94", 96, 41) + chr(34) + _l1d_55a757("3c74777a9c62845c5e", 4, 25), _l1d_55a757("c4", 54, 101))
_l1lI1ll = _ll1I1ll.match(_l11I1ll)
if _l1lI1ll <> invalid and _l1lI1ll.Count() >= 2 then
return {
url: _l1lI1ll[1]
streamFormat: _l1d_55a757("2f361a", 147, 52)
qualities: []
subtitles: RP_ExtractSubs(_l11I1ll)
chapters: []
referer: _lIII1ll
userAgent: ""
}
end if
_llII1ll = CreateObject(_l1d_55a757("4b333143444957", 78, 15), _l1d_55a757("7a3d3c3f3e3e7d7d9396656d", 251, 167) + chr(34) + _l1d_55a757("a1bbbec1d9a9c9bad0c505edb4dce4", 17, 107) + chr(34) + _l1d_55a757("ad979a9d8dc5a5bfbf", 237, 227), _l1d_55a757("90", 155, 158))
_lI1I1ll = _llII1ll.match(_l11I1ll)
if _lI1I1ll <> invalid and _lI1I1ll.Count() >= 2 then
return {
url: _lI1I1ll[1]
streamFormat: _l1d_55a757("88a6e5", 108, 135)
qualities: []
subtitles: RP_ExtractSubs(_l11I1ll)
chapters: []
referer: _lIII1ll
userAgent: ""
}
end if
return invalid
end function
function RP_ExtractSubs(_llIll1l as String) as Object
_ll11l1l = []
if _llIll1l = invalid or _llIll1l = "" then return _ll11l1l
_l111l1l = CreateObject(_l1d_55a757("e2da08d6dbdcfa", 100, 204), _l1d_55a757("13d6bdc0c7c910162629c0be", 86, 149) + chr(34) + _l1d_55a757("1c484b4e743258255d2e2f454392979a959b9da64e51", 10, 239), _l1d_55a757("262b", 254, 143))
_l1l1l1l = _l111l1l.matchAll(_llIll1l)
if _l1l1l1l = invalid then return _ll11l1l
for each _lIl1l1l in _l1l1l1l
if _lIl1l1l.Count() < 2 then continue for
_lI11l1l = _lIl1l1l[1]
_l1Ill1l = _l1d_55a757("e2de", 104, 213)
_lIIll1l = CreateObject(_l1d_55a757("8f9db5a9aeaf97", 121, 132), _l1d_55a757("0fde11e215ed213af14b27501c50073c0b0f411245", 13, 185), _l1d_55a757("47", 197, 155))
_lll1l1l = _lIIll1l.match(_lI11l1l)
if _lll1l1l <> invalid and _lll1l1l.Count() >= 2 then _l1Ill1l = LCase(_lll1l1l[1])
_ll11l1l.Push({ url: _lI11l1l, language: _l1Ill1l, name: UCase(_l1Ill1l) })
end for
return _ll11l1l
end function
function RP_ResolveVidsrcCc(_l1II11l as String, _l1IlI1l as String, _lI11I1l as Object) as Object
_l11lI1l = CreateObject(_l1d_55a757("f0f8d608090efc", 30, 132), _l1d_55a757("a4aabac289d0b6bbcc8580928e92ced49297b39fa6b2bdc2eeeff5a4bfffcdd8dbb6d1111216262e1c22d1ec2c2d2e34e3fe3e3f4253", 205, 194), _l1d_55a757("c3", 204, 30))
m = _l11lI1l.match(_l1II11l)
if m = invalid or m.Count() < 3 then return invalid
_llllI1l = m[1]
_lI1I11l = m[2]
_lIl1I1l = ""
_lIII11l = ""
if m.Count() >= 5 then
_lIl1I1l = m[3]
_lIII11l = m[4]
end if
_ll1lI1l = HC_OriginOf(_l1II11l)
if _ll1lI1l = "" then return invalid
if _llllI1l = _l1d_55a757("3031", 154, 66) and _lIl1I1l <> "" and _lIII11l <> "" then
_l111I1l = _ll1lI1l + _l1d_55a757("59aa9ea865b2aab4adb4c2c47d", 159, 169) + _lI1I11l + _l1d_55a757("ce", 135, 38) + _lIl1I1l + _l1d_55a757("93", 149, 217) + _lIII11l + _l1d_55a757("cb1207171e102024", 160, 60)
else
_l111I1l = _ll1lI1l + _l1d_55a757("23e0d4ee2fe8e0fae7fef8fa47", 85, 169) + _lI1I11l + _l1d_55a757("62413246453b4f53", 110, 33)
end if
_l11I11l = {
"Referer": _l1II11l
"Origin": _ll1lI1l
"Accept": _l1d_55a757("07191c1b1b18192f273032f634403f4102f950445a59175b5a525d65261d2a3230", 160, 70)
"X-Requested-With": _l1d_55a757("c2dadcdbfafdfce117060d201115", 152, 2)
}
_lIIlI1l = HC_Get(_lI11I1l, _l111I1l, _l11I11l, 8000)
if _lIIlI1l = invalid or _lIIlI1l.body = "" then return invalid
_lI1lI1l = ParseJSON(_lIIlI1l.body)
if _lI1lI1l = invalid or type(_lI1lI1l) <> _l1d_55a757("67755a6f728188818c848a8c9c7b9194a48f", 153, 124) then return invalid
_ll11I1l = invalid
if _lI1lI1l.data <> invalid then _ll11I1l = _lI1lI1l.data
if (_ll11I1l = invalid or type(_ll11I1l) <> _l1d_55a757("07edde10130712", 15, 138)) and _lI1lI1l.servers <> invalid then _ll11I1l = _lI1lI1l.servers
if _ll11I1l = invalid or type(_ll11I1l) <> _l1d_55a757("d0e6c3d9dcece7", 21, 105) then return invalid
for each _lII1I1l in _ll11I1l
if type(_lII1I1l) <> _l1d_55a757("6d83a075788f8e979282a08a9ac1979aaaa5", 181, 166) then continue for
_lllII1l = ""
if _lII1I1l.hash <> invalid then _lllII1l = _lII1I1l.hash
if _lllII1l = "" and _lII1I1l.data_id <> invalid then _lllII1l = _lII1I1l.data_id
if _lllII1l = "" and _lII1I1l.id <> invalid then _lllII1l = _lII1I1l.id
if _lllII1l = "" then continue for
_llI1I1l = _ll1lI1l + _l1d_55a757("57241622632229222a3e3b78", 92, 228) + _lllII1l
_l1I1I1l = HC_Get(_lI11I1l, _llI1I1l, _l11I11l, 8000)
if _l1I1I1l = invalid or _l1I1I1l.body = "" then continue for
_l1l1I1l = ParseJSON(_l1I1I1l.body)
if _l1l1I1l = invalid or type(_l1l1I1l) <> _l1d_55a757("eb03e4f5f80f0e1b160424081e0515182e29", 22, 135) then continue for
_llII11l = invalid
if _l1l1I1l.data <> invalid and type(_l1l1I1l.data) = _l1d_55a757("a18976abae95a49da8b6a6beb097cbcec0cb", 76, 99) then
_llII11l = _l1l1I1l.data
else
_llII11l = _l1l1I1l
end if
_l1lII1l = ""
if _llII11l.stream <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.stream)
if _l1lII1l = "" and _llII11l.source <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.source)
if _l1lII1l = "" and _llII11l.file <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.file)
if _l1lII1l = "" and _llII11l.url <> invalid then _l1lII1l = RP_AsStreamString(_llII11l.url)
if _l1lII1l = "" then continue for
_lIlII1l = []
_llIlI1l = invalid
if _llII11l.subtitles <> invalid then _llIlI1l = _llII11l.subtitles
if _llIlI1l = invalid and _llII11l.captions <> invalid then _llIlI1l = _llII11l.captions
if _llIlI1l <> invalid and type(_llIlI1l) = _l1d_55a757("464c3d4f526651", 223, 153) then
for each _lll1I1l in _llIlI1l
if type(_lll1I1l) <> _l1d_55a757("becef3c8cbdae1dae5dbe3e3f514e8ebfde8", 248, 52) then continue for
_ll1II1l = ""
if _lll1I1l.file <> invalid then _ll1II1l = _lll1I1l.file
if _ll1II1l = "" and _lll1I1l.url <> invalid then _ll1II1l = _lll1I1l.url
if _ll1II1l = "" and _lll1I1l.src <> invalid then _ll1II1l = _lll1I1l.src
if _ll1II1l = "" then continue for
_l1llI1l = _l1d_55a757("534d", 171, 133)
if _lll1I1l.language <> invalid then _l1llI1l = LCase(Left(_lll1I1l.language, 2))
if _l1llI1l = "" and _lll1I1l.lang <> invalid then _l1llI1l = LCase(Left(_lll1I1l.lang, 2))
if _l1llI1l = "" and _lll1I1l.label <> invalid then _l1llI1l = LCase(Left(_lll1I1l.label, 2))
_lIllI1l = ""
if _lll1I1l.label <> invalid then _lIllI1l = _lll1I1l.label
if _lIllI1l = "" and _lll1I1l.language <> invalid then _lIllI1l = _lll1I1l.language
if _lIllI1l = "" then _lIllI1l = _l1d_55a757("f015051a02200b1728", 8, 149)
_lIlII1l.Push({ url: _ll1II1l, language: _l1llI1l, name: _lIllI1l })
end for
end if
return {
url: _l1lII1l
streamFormat: U_StreamFormat(_l1lII1l)
qualities: []
subtitles: _lIlII1l
chapters: []
referer: _l1II11l
userAgent: ""
}
end for
return invalid
end function
function RP_AsStreamString(_ll11lIl as Dynamic) as String
if ((22782 - 3797 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _ll11lIl = invalid then return ""
if type(_ll11lIl) = _l1d_55a757("5a3a3f3d3935", 230, 165) or type(_ll11lIl) = _l1d_55a757("fcfa210b08040a04", 35, 171) then return _ll11lIl
if type(_ll11lIl) = _l1d_55a757("2f2f48383b314c", 226, 159) then
if _ll11lIl.Count() = 0 then return ""
_lIl1lIl = _ll11lIl[0]
if type(_lIl1lIl) = _l1d_55a757("a2808971737d", 109, 100) or type(_lIl1lIl) = _l1d_55a757("8167a6848d757781", 45, 34) then return _lIl1lIl
if type(_lIl1lIl) = _l1d_55a757("d1d7c4d9dce3f2ebf6e6f4eefee5fbfe0ef9", 29, 98) then
if _lIl1lIl.file <> invalid then return _lIl1lIl.file
if _lIl1lIl.url <> invalid then return _lIl1lIl.url
end if
end if
return ""
end function
function RP_ResolveAirflix(_l11lIIl as String, _llI1IIl as String, _ll1IIIl as Object) as Object
if ((49399 - 7057 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l111IIl = CreateObject(_l1d_55a757("6c849284858a88", 54, 40), _l1d_55a757("01cac5d7d3d71319d7dcd8e4ebd7e2e733343af1f4cf0a4af8db1656575b4b536167f63171727379084383848778", 221, 15), _l1d_55a757("7c", 214, 189))
m = _l111IIl.match(_l11lIIl)
if m = invalid or m.Count() < 3 then return invalid
_lIl1IIl = m[1]
_l1l1IIl = m[2]
_l1lIIIl = ""
_llIlIIl = ""
if m.Count() >= 5 then
_l1lIIIl = m[3]
_llIlIIl = m[4]
end if
_l1IlIIl = _l1d_55a757("d7c1cdd2", 111, 188)
if Left(_l1l1IIl, 2) = _l1d_55a757("5154", 202, 147) then _l1IlIIl = _l1d_55a757("23222c35", 220, 110)
_lIllIIl = _l1d_55a757("a4b3b6b5bb05fd00c7cbccc2c1d0cacae0d020ebd9ebeae2fdecfc3b020845fa0c085015101b6d", 192, 252) + _l1IlIIl + _l1d_55a757("ae", 53, 166) + U_UrlEncode(_l1l1IIl) + _l1d_55a757("a7585e5a70ab", 241, 208) + _lIl1IIl
if _lIl1IIl = _l1d_55a757("9a9f", 173, 193) and _l1lIIIl <> "" and _llIlIIl <> "" then
_lIllIIl = _lIllIIl + _l1d_55a757("8a424f564b525486", 92, 16) + _l1lIIIl + _l1d_55a757("f1b1c9b3d0b7c1c30e", 237, 38) + _llIlIIl
end if
_l1llIIl = _l1d_55a757("869da0a7abe7d5d89ca4b4bbafb0aebcb2b6cfc3c8ccd2e5cdda12e0d7d81d", 77, 97)
_l1I1IIl = HC_Get(_ll1IIIl, _lIllIIl, {
"Referer": _l1llIIl
"Origin": _l1d_55a757("1b2a2d2c30fcf2f5393149483c3d4b414f535c505551576a625f2f657475", 1, 178)
}, 8000)
if _l1I1IIl = invalid or _l1I1IIl.body = "" then return invalid
_lI1lIIl = ParseJSON(_l1I1IIl.body)
if _lI1lIIl = invalid or type(_lI1lIIl) <> _l1d_55a757("674f7c71745b6a636e7c6c84769d91948691", 108, 73) then return invalid
_lllIIIl = ""
if _lI1lIIl.status_code <> invalid then _lllIIIl = _lI1lIIl.status_code.ToStr()
if _lllIIIl <> _l1d_55a757("646568", 13, 37) then return invalid
_ll1lIIl = _lI1lIIl.data
if _ll1lIIl = invalid or type(_ll1lIIl) <> _l1d_55a757("c3d1bacbcedde4e1ece4eae8fcdbedf004ef", 155, 218) then return invalid
_l11IIIl = _ll1lIIl.stream_urls
if _l11IIIl = invalid or type(_l11IIIl) <> _l1d_55a757("696f5c72758570", 221, 186) or _l11IIIl.Count() = 0 then return invalid
_llIIIIl = []
_lIlIIIl = {}
_llllIIl = []
_l1IIIIl = [_lI1lIIl.subs, _ll1lIIl.subs, _lI1lIIl.default_subs, _ll1lIIl.default_subs]
for each _lll1IIl in _l1IIIIl
if _lll1IIl = invalid or type(_lll1IIl) <> _l1d_55a757("a7bd9ab0b3c3be", 149, 192) then continue for
for each _lII1IIl in _lll1IIl
if type(_lII1IIl) <> _l1d_55a757("bcccf1c6c9d8dfd8e3d9e1e1f312e6e9fbe6", 120, 178) then continue for
_lIIIIIl = ""
if _lII1IIl.url <> invalid then _lIIIIIl = _lII1IIl.url
if _lIIIIIl = "" and _lII1IIl.file <> invalid then _lIIIIIl = _lII1IIl.file
if _lIIIIIl = "" then continue for
if _lIlIIIl.DoesExist(_lIIIIIl) then continue for
_lIlIIIl[_lIIIIIl] = true
_lIIlIIl = ""
if _lII1IIl.code <> invalid then _lIIlIIl = LCase(_lII1IIl.code)
if _lIIlIIl = "" and _lII1IIl.language <> invalid then _lIIlIIl = LCase(_lII1IIl.language)
if _lIIlIIl = "" and _lII1IIl.lang <> invalid and Len(_lII1IIl.lang) >= 2 then _lIIlIIl = LCase(Left(_lII1IIl.lang, 2))
if _lIIlIIl = "" then _lIIlIIl = _l1d_55a757("908c", 252, 247)
_ll11IIl = ""
if _lII1IIl.label <> invalid then _ll11IIl = _lII1IIl.label
if _ll11IIl = "" and _lII1IIl.lang <> invalid then _ll11IIl = _lII1IIl.lang
if _ll11IIl = "" and _lII1IIl.language <> invalid then _ll11IIl = _lII1IIl.language
if _ll11IIl = "" then _ll11IIl = UCase(_lIIlIIl)
_llllIIl.Push({ url: _lIIIIIl, language: _lIIlIIl, name: _ll11IIl })
end for
end for
for each _llllll1 in _llllIIl
if _llllll1.language = _l1d_55a757("3442", 85, 4) then _llIIIIl.Push(_llllll1)
end for
for each _llllll1 in _llllIIl
if _llllll1.language <> _l1d_55a757("c9c7", 105, 189) then _llIIIIl.Push(_llllll1)
end for
for each _lI1IIIl in _l11IIIl
if type(_lI1IIIl) <> _l1d_55a757("406065736f7b", 222, 179) and type(_lI1IIIl) <> _l1d_55a757("737198827f7b817b", 227, 226) then continue for
if _lI1IIIl = "" then continue for
_lI11IIl = HC_Get(_ll1IIIl, _lI1IIIl, { "Referer": _l1llIIl }, 6000)
if _lI11IIl = invalid or _lI11IIl.body = "" then continue for
if Left(_lI11IIl.body, 7) <> _l1d_55a757("b617252c18d536", 46, 169) then continue for
return {
url: _lI1IIIl
streamFormat: _l1d_55a757("3b422c", 240, 163)
qualities: []
subtitles: _llIIIIl
chapters: []
referer: _l1llIIl
userAgent: ""
}
end for
return invalid
end function
function RP_HlsLeadSkip(_l11Ill1 as Object, _lllIll1 as String, _l1lIll1 as String, _ll1Ill1 as String) as Integer
if _l1lIll1 = "" then return 0
_l1I1ll1 = _lllIll1
_l1IIll1 = _l1lIll1
if _l1I1ll1 = "" then
_lIlIll1 = HC_Get(_l11Ill1, _l1IIll1, { "Referer": _ll1Ill1 }, 5000)
if _lIlIll1 = invalid or _lIlIll1.body = "" then return 0
_l1I1ll1 = _lIlIll1.body
end if
if Left(_l1I1ll1, 7) <> _l1d_55a757("4a27473e386946", 101, 4) then return 0
if Instr(1, _l1I1ll1, _l1d_55a757("157e84931f8d259aa29f9998973a999da8", 170, 140)) <= 0 then
return RP_ProbeMediaPlaylist(_l11Ill1, _l1I1ll1, _l1IIll1, _ll1Ill1)
end if
_lII1ll1 = 0
for each line in _l1I1ll1.Tokenize(Chr(10))
_llIIll1 = U_Trim(line)
if _llIIll1 = "" then continue for
if Left(_llIIll1, 1) = _l1d_55a757("24", 37, 30) then continue for
_llll1l1 = U_AbsUrl(_llIIll1, HC_OriginOf(_l1IIll1))
if _llll1l1 = "" then continue for
_lIIIll1 = HC_Get(_l11Ill1, _llll1l1, { "Referer": _ll1Ill1 }, 5000)
if _lIIIll1 <> invalid and _lIIIll1.body <> "" and Left(_lIIIll1.body, 7) = _l1d_55a757("0728281f390627", 23, 211) then
_lI1Ill1 = RP_ProbeMediaPlaylist(_l11Ill1, _lIIIll1.body, _llll1l1, _ll1Ill1)
if _lI1Ill1 > 0 then return _lI1Ill1
end if
_lII1ll1 = _lII1ll1 + 1
if _lII1ll1 >= 8 then exit for
end for
return 0
end function
function RP_ProbeMediaPlaylist(_lI11Il1 as Object, _lll1Il1 as String, _l1l1Il1 as String, _l111Il1 as String) as Integer
_l1IlIl1 = 0.0
_lIIlIl1 = ""
_lIl1Il1 = 0.0
_llIlIl1 = CreateObject(_l1d_55a757("21274733383929", 61, 210), _l1d_55a757("9fc0e0d7d5d3cecdc2f2d0c6ddcbffd4d9", 135, 251), _l1d_55a757("ff", 120, 238))
for each line in _lll1Il1.Tokenize(Chr(10))
_l1I1Il1 = U_Trim(line)
if _l1I1Il1 = "" then continue for
if Left(_l1I1Il1, 1) = _l1d_55a757("17", 138, 110) then
_lI1lIl1 = _llIlIl1.match(_l1I1Il1)
if _lI1lIl1 <> invalid and _lI1lIl1.Count() >= 2 then _lIl1Il1 = Val(_lI1lIl1[1])
continue for
end if
_lIIlIl1 = U_AbsUrl(_l1I1Il1, HC_OriginOf(_l1l1Il1))
_l1IlIl1 = _lIl1Il1
exit for
end for
if _lIIlIl1 = "" then return 0
_ll11Il1 = HC_GetRange(_lI11Il1, _lIIlIl1, { "Referer": _l111Il1 }, _l1d_55a757("fa140afe17dcdad2e1", 4, 148), 5000)
if _ll11Il1 = invalid then return 0
if _ll11Il1.status <= 0 then return 0
if Len(_ll11Il1.body) > 0 then return 0
_llI1Il1 = Int(_l1IlIl1 + 0.999) + 2
if _llI1Il1 < 4 then _llI1Il1 = 8
if _llI1Il1 > 30 then _llI1Il1 = 30
print _l1d_55a757("b4c8cfd5c60cdfdddee7e6e8e6e8273a3aee0c0afe3c010b13171f4e20191a27222a3766766c3b37363c2a454a54a4", 66, 155); _llI1Il1
return _llI1Il1
end function
function RP_VidrockEncrypt(_ll1l111 as String, _l1ll111 as String, _llll111 as String) as String
_l11Il11 = CreateObject(_l1d_55a757("9eacd5cbc8dcb5b1bccabc", 57, 83))
_lI1l111 = _l11Il11.Setup(true, _l1d_55a757("d2d9ea272f353933eceef2", 96, 209), _l1ll111, _llll111, 1)
if _lI1l111 <> 0 then return ""
_l11l111 = CreateObject(_l1d_55a757("cec4a4e0d8cab1e3e6daf5", 71, 153))
_l11l111.FromAsciiString(_ll1l111)
_l1IIl11 = CreateObject(_l1d_55a757("8a9a808e9cb08f9fa2b8a3", 154, 162))
_lI1Il11 = _l11Il11.Process(_l11l111)
if _lI1Il11 <> invalid then
for _lIIIl11 = 0 to _lI1Il11.Count() - 1
_l1IIl11.Push(_lI1Il11[_lIIIl11])
end for
end if
_llIIl11 = _l11Il11.Final()
if _llIIl11 <> invalid then
for _lIIIl11 = 0 to _llIIl11.Count() - 1
_l1IIl11.Push(_llIIl11[_lIIIl11])
end for
end if
if _l1IIl11.Count() = 0 then return ""
_ll1Il11 = _l1IIl11.ToBase64String()
_llIl111 = CreateObject(_l1d_55a757("ed05d301060705", 148, 7), _l1d_55a757("4cd8", 43, 213), "")
_l1Il111 = CreateObject(_l1d_55a757("473d6d3d3e4363", 39, 242), _l1d_55a757("08", 17, 202), "")
_lIIl111 = CreateObject(_l1d_55a757("554b3b474c4d6d", 69, 30), _l1d_55a757("cddada", 242, 254), "")
_lIll111 = _llIl111.ReplaceAll(_ll1Il11, _l1d_55a757("5b", 1, 47))
_lIll111 = _l1Il111.ReplaceAll(_lIll111, _l1d_55a757("a0", 29, 94))
_lIll111 = _lIIl111.ReplaceAll(_lIll111, "")
return _lIll111
end function
function RP_ResolveVidrock(_lI11I11 as String, _lllllI1 as String, _l11llI1 as Object) as Object
_lI1II11 = CreateObject(_l1d_55a757("4b63715f646563", 244, 197), _l1d_55a757("656d7b813b364244468089968e4e4f695b626c7778aaa7af9e79b7879295b08bc9ced0dee4d4dccba6e4e9e6eeddb8f6fbfe0b", 110, 36), _l1d_55a757("a8", 163, 222))
m = _lI1II11.match(_lI11I11)
if m = invalid or m.Count() < 3 then return invalid
_lIlII11 = m[1]
_ll11I11 = m[2]
_ll1llI1 = ""
_l1I1I11 = ""
if m.Count() >= 5 then
_ll1llI1 = m[3]
_l1I1I11 = m[4]
end if
_l1l1I11 = _l1d_55a757("d2e9ecf3f5af9fa2fceef409f100fbb9181a", 174, 12)
if _lIlII11 = _l1d_55a757("393a", 75, 250) and _ll1llI1 <> "" and _l1I1I11 <> "" then
_l1III11 = _ll11I11 + _l1d_55a757("93", 38, 26) + _ll1llI1 + _l1d_55a757("8e", 14, 61) + _l1I1I11
else
_l1III11 = _ll11I11
end if
_l1lII11 = _l1d_55a757("bfbdc9c8cca3d5ced8a9dbe3e3e8e7ebf3f7f5fdf9fe01050504110b13e8181e2320262d2a32353838083c4147474a474e24595d5c3260396b696e3f72447d76", 125, 117)
_lllII11  = _l1d_55a757("93a19d9ca0d7a9b2acddafb7b7bcbbbfc7cbc9d1cdd2d5d9d9e8e5efe71cecf2", 37, 129)
_llI1I11 = RP_VidrockEncrypt(_l1III11, _l1lII11, _lllII11)
if _llI1I11 = "" then return invalid
if _lIlII11 = _l1d_55a757("1318", 244, 147) and _ll1llI1 <> "" and _l1I1I11 <> "" then
_lIl1I11 = _l1l1I11 + _l1d_55a757("70ada1bb7ca6ab85", 21, 54) + _llI1I11
else
_lIl1I11 = _l1l1I11 + _l1d_55a757("0f50445e1b60614d6d642d", 183, 119) + _llI1I11
end if
_lII1I11 = {
"Referer": _l1l1I11 + _l1d_55a757("b2", 127, 98) + _lIlII11 + _l1d_55a757("96", 20, 91) + _ll11I11
"Origin": _l1l1I11
"Accept": _l1d_55a757("5a6e71686e6b6c7c7a7b7fc189938a8ecfce9d8fafa6e2b0a7a5b0b2f3f2fffd05", 101, 86)
"User-Agent": _l1d_55a757("6d92a092989ba3e4fde9fef1ecaeb3bbc4c2dddc0cadc615292b1c312f27e1e6ee494a443c075859414bef2124131f1425250122406e87888f799197847f2525443032959c5b5b606dab5576777279b6c0667e9b8b8c97d4e9edf2dff4e5faeb00f3a9bac2c0d4be07202128122a30", 200, 232)
}
_l1lllI1 = HC_Get(_l11llI1, _lIl1I11, _lII1I11, 8000)
if _l1lllI1 = invalid or _l1lllI1.body = "" then return invalid
_llIII11 = ParseJSON(_l1lllI1.body)
if _llIII11 = invalid or type(_llIII11) <> _l1d_55a757("464c7d4e515867646f5f6d63779e70738772", 191, 121) then
_l111I11 = RP_TryBase64Decode(U_Trim(_l1lllI1.body))
if _l111I11 <> "" then _llIII11 = ParseJSON(_l111I11)
if _llIII11 = invalid or type(_llIII11) <> _l1d_55a757("b3b388bdc0bfb6bfbad0c8d8caa9dde0d2ed", 128, 193) then return invalid
end if
_llIllI1 = []
RP_WalkForStreams(_llIII11, _llIllI1)
if _llIllI1.Count() = 0 then return invalid
_l1IllI1 = []
_lIIII11 = invalid
if _llIII11.subtitle <> invalid then _lIIII11 = _llIII11.subtitle
if _lIIII11 = invalid and _llIII11.subtitles <> invalid then _lIIII11 = _llIII11.subtitles
if _lIIII11 = invalid and _llIII11.captions <> invalid then _lIIII11 = _llIII11.captions
if _lIIII11 <> invalid and type(_lIIII11) = _l1d_55a757("3c3a0f45483853", 65, 9) then
for each _lIlllI1 in _lIIII11
if type(_lIlllI1) <> _l1d_55a757("abc19eb3b6cdccd5d0c0dec8d8bfd5d8e8e3", 21, 68) then continue for
_lIIllI1 = ""
if _lIlllI1.file <> invalid then _lIIllI1 = _lIlllI1.file
if _lIIllI1 = "" and _lIlllI1.url <> invalid then _lIIllI1 = _lIlllI1.url
if _lIIllI1 = "" then continue for
_ll1II11 = _l1d_55a757("2820", 254, 141)
if _lIlllI1.language <> invalid then _ll1II11 = LCase(Left(_lIlllI1.language, 2))
if _ll1II11 = "" and _lIlllI1.lang <> invalid then _ll1II11 = LCase(Left(_lIlllI1.lang, 2))
_l11II11 = ""
if _lIlllI1.label <> invalid then _l11II11 = _lIlllI1.label
if _l11II11 = "" and _lIlllI1.language <> invalid then _l11II11 = _lIlllI1.language
if _l11II11 = "" then _l11II11 = _l1d_55a757("90b5a7bca2c2adb7c8", 137, 182)
_l1IllI1.Push({ url: _lIIllI1, language: _ll1II11, name: _l11II11 })
end for
end if
_lI1llI1 = _llIllI1[0]
return {
url: _lI1llI1
streamFormat: U_StreamFormat(_lI1llI1)
qualities: []
subtitles: _l1IllI1
chapters: []
referer: _lI11I11
userAgent: ""
}
end function
sub RP_WalkForStreams(_lIll1I1 as Dynamic, _ll1l1I1 as Object)
if _lIll1I1 = invalid or _ll1l1I1 = invalid then return
_l11l1I1 = type(_lIll1I1)
if _l11l1I1 = _l1d_55a757("0301d60b0e0d040d0820162818f72d30203b", 193, 80) then
for each _l1ll1I1 in _lIll1I1
_lI1l1I1 = _lIll1I1[_l1ll1I1]
if _lI1l1I1 = invalid then continue for
_llIl1I1 = type(_lI1l1I1)
if _llIl1I1 = _l1d_55a757("ddc5c2b0b4c0", 42, 100) or _llIl1I1 = _l1d_55a757("a99190acb59f9fab", 140, 171) then
if Instr(1, _lI1l1I1, _l1d_55a757("90d481c292", 23, 87)) > 0 or Instr(1, _lI1l1I1, _l1d_55a757("93d7d796", 31, 98)) > 0 then _ll1l1I1.Push(_lI1l1I1)
else if _llIl1I1 = _l1d_55a757("4331164b4e3d443d4860466858376d70606b", 137, 72) or _llIl1I1 = _l1d_55a757("01f7140a0dfd18", 229, 106) then
RP_WalkForStreams(_lI1l1I1, _ll1l1I1)
end if
end for
else if _l11l1I1 = _l1d_55a757("fcf20f0508f813", 37, 165) then
for each _llll1I1 in _lIll1I1
if _llll1I1 = invalid then continue for
_lIIIlI1 = type(_llll1I1)
if _lIIIlI1 = _l1d_55a757("bfe1e6d2d0da", 207, 35) or _lIIIlI1 = _l1d_55a757("e6e4cbf5f2eef4ee", 67, 181) then
if Instr(1, _llll1I1, _l1d_55a757("b7f9da17d5", 12, 149)) > 0 or Instr(1, _llll1I1, _l1d_55a757("74b8b077", 27, 63)) > 0 then _ll1l1I1.Push(_llll1I1)
else if _lIIIlI1 = _l1d_55a757("1202eb1c1f0e15121d331b372d0c3c3f3540", 74, 218) or _lIIIlI1 = _l1d_55a757("bcd2afc5c8d8d3", 85, 149) then
RP_WalkForStreams(_llll1I1, _ll1l1I1)
end if
end for
end if
end sub
function RP_TryBase64Decode(_lII1II1 as String) as String
if _lII1II1 = invalid or _lII1II1 = "" then return ""
_lllIII1 = _lII1II1
_l1I1II1 = Len(_lllIII1) mod 4
if _l1I1II1 = 1 then return ""
if _l1I1II1 = 2 then _lllIII1 = _lllIII1 + _l1d_55a757("2c2f", 68, 179)
if _l1I1II1 = 3 then _lllIII1 = _lllIII1 + _l1d_55a757("5f", 193, 99)
_llI1II1 = CreateObject(_l1d_55a757("73816975859776888b9f8a", 155, 138))
_llI1II1.FromBase64String(_lllIII1)
return _llI1II1.ToAsciiString()
end function
function RP_ResolveXpass(_l1l11lI as String, _lI1I1lI as String, _l1II1lI as Object) as Object
_l1111lI = {}
if _lI1I1lI <> "" then _l1111lI[_l1d_55a757("2d67676d59735f", 90, 37)] = _lI1I1lI else _l1111lI[_l1d_55a757("cfc5c9cbbbd1c1", 48, 109)] = _l1d_55a757("4c43464d4d89979a64566e6377737ab37272bb", 223, 149)
_lllI1lI = HC_Get(_l1II1lI, _l1l11lI, _l1111lI, 8000)
if _lllI1lI = invalid or _lllI1lI.body = "" then return invalid
_lI111lI = _lllI1lI.body
_ll111lI = _lllI1lI.finalUrl
if _ll111lI = invalid or _ll111lI = "" then _ll111lI = _l1l11lI
_llIl1lI = []
_l11I1lI = CreateObject(_l1d_55a757("0b0931090a0f27", 163, 58), chr(34) + _l1d_55a757("7b72728d7b83908c", 132, 135) + chr(34) + _l1d_55a757("1c0a3447281640", 238, 106) + chr(34) + _l1d_55a757("677b7b", 149, 170) + chr(34) + _l1d_55a757("a0f1f2", 200, 11) + chr(34), _l1d_55a757("48", 133, 92))
_ll1I1lI = _l11I1lI.match(_lI111lI)
if _ll1I1lI <> invalid and _ll1I1lI.Count() >= 2 then
_llIl1lI.Push({ label: _l1d_55a757("d5e3e4520506121120120e", 95, 202), url: RP_AbsUrl(_ll1I1lI[1], _ll111lI) })
end if
_l11l1lI = RP_ParseXpassBackups(_lI111lI)
if _l11l1lI <> invalid and type(_l11l1lI) = _l1d_55a757("91a98a9a9db3ae", 22, 45) then
for each _lIl11lI in _l11l1lI
if type(_lIl11lI) <> _l1d_55a757("ef0fe8f9fc1b121f1a1028142a09191c322d", 82, 207) then continue for
_lIllIlI = _lIl11lI.url
if _lIllIlI = invalid or _lIllIlI = "" then continue for
_lII11lI = ""
if _lIl11lI.name <> invalid then _lII11lI = _lIl11lI.name
if _lII11lI = "" then _lII11lI = _l1d_55a757("a9afb0bbacaa", 114, 153)
_llIl1lI.Push({ label: _lII11lI, url: RP_AbsUrl(_lIllIlI, _ll111lI) })
end for
end if
_llII1lI = {}
_l1llIlI = []
for each _lI1l1lI in _llIl1lI
if _lI1l1lI.url = "" then continue for
if _llII1lI.DoesExist(_lI1l1lI.url) then continue for
_llII1lI[_lI1l1lI.url] = true
_l1llIlI.Push(_lI1l1lI)
end for
for _llI11lI = 1 to _l1llIlI.Count() - 1
_l1Il1lI = _l1llIlI[_llI11lI]
_lIIl1lI = RP_XpassSrcRank(_l1Il1lI)
_l1I11lI = _llI11lI - 1
while _l1I11lI >= 0
if RP_XpassSrcRank(_l1llIlI[_l1I11lI]) <= _lIIl1lI then exit while
_l1llIlI[_l1I11lI + 1] = _l1llIlI[_l1I11lI]
_l1I11lI = _l1I11lI - 1
end while
_l1llIlI[_l1I11lI + 1] = _l1Il1lI
end for
_llllIlI = RP_FetchXpassSubs(_lI111lI, _l1II1lI)
for each _lI1l1lI in _l1llIlI
_l1lI1lI = _lI1l1lI.url
_lIlI1lI = HC_Get(_l1II1lI, _l1lI1lI, { "Referer": _ll111lI }, 6000)
if _lIlI1lI = invalid or _lIlI1lI.body = "" then continue for
_lll11lI = ParseJSON(_lIlI1lI.body)
if _lll11lI = invalid or type(_lll11lI) <> _l1d_55a757("8fa586979ab1b0bdb8a8c6acc0a7b9bcd0cb", 87, 106) then continue for
_lIII1lI = RP_XpassFirstSource(_lll11lI)
if _lIII1lI = "" then continue for
_lIII1lI = RP_AbsUrl(_lIII1lI, _l1lI1lI)
_ll1lIlI = HC_Get(_l1II1lI, _lIII1lI, { "Referer": _ll111lI }, 6000)
if _ll1lIlI = invalid or _ll1lIlI.body = "" then continue for
if Left(_ll1lIlI.body, 7) <> _l1d_55a757("22ffedf40021fe", 252, 67) then continue for
return {
url: _lIII1lI
streamFormat: _l1d_55a757("949ba1", 194, 234)
qualities: []
subtitles: _llllIlI
chapters: []
referer: _ll111lI
userAgent: ""
}
end for
return invalid
end function
function RP_XpassSrcRank(_lIlIIlI as Object) as Integer
_ll1IIlI = ""
_l11IIlI = ""
if _lIlIIlI.label <> invalid then _ll1IIlI = UCase(_lIlIIlI.label)
if _lIlIIlI.url <> invalid then _l11IIlI = LCase(_lIlIIlI.url)
if Instr(1, _ll1IIlI, _l1d_55a757("6b5b60", 140, 147)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("0d4e4a48604e1f", 1, 223)) > 0 then return 100
if Instr(1, _ll1IIlI, _l1d_55a757("686d77", 100, 63)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("1112fe5949154e", 247, 119)) > 0 then return 0
if Instr(1, _ll1IIlI, _l1d_55a757("d6e2de", 61, 107)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("e2bea6c2ee", 107, 158)) > 0 then return 1
if Instr(1, _ll1IIlI, _l1d_55a757("9d8bad", 134, 200)) > 0 or Instr(1, _l11IIlI, _l1d_55a757("e79eb69ef3", 123, 147)) > 0 then return 2
return 50
end function
function RP_ParseXpassBackups(_lII111I as String) as Object
if ((19860 - 3972 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lII111I = invalid or _lII111I = "" then return []
_l1II11I = CreateObject(_l1d_55a757("01f727f3f8f919", 229, 106), _l1d_55a757("daeadc0de1bcf8fcfd08f9f9f92bffdbd3370be7403c", 51, 149), _l1d_55a757("bc", 251, 42))
_l1I111I = _l1II11I.match(_lII111I)
if _l1I111I = invalid or _l1I111I.Count() < 1 then return []
_ll1I11I = _l1I111I[0]
_llllI1I = Instr(1, _lII111I, _ll1I11I)
if _llllI1I <= 0 then return []
_lll111I = Instr(_llllI1I, _lII111I, _l1d_55a757("e9", 35, 113))
if _lll111I <= 0 then return []
_ll1111I = 0
_l1lI11I = false
_lI1I11I = ""
_llI111I = false
_lI1111I = 0
_lIlI11I = Len(_lII111I)
_l1l111I = chr(92)
_l11111I = chr(34)
_lIII11I = _l1d_55a757("52", 41, 68)
for _lllI11I = _lll111I to _lIlI11I
_lIl111I = Mid(_lII111I, _lllI11I, 1)
if _l1lI11I then
if _llI111I then
_llI111I = false
else if _lIl111I = _l1l111I then
_llI111I = true
else if _lIl111I = _lI1I11I then
_l1lI11I = false
end if
else
if _lIl111I = _l11111I or _lIl111I = _lIII11I then
_l1lI11I = true
_lI1I11I = _lIl111I
else if _lIl111I = _l1d_55a757("19", 8, 198) then
_ll1111I = _ll1111I + 1
else if _lIl111I = _l1d_55a757("cd", 38, 82) then
_ll1111I = _ll1111I - 1
if _ll1111I = 0 then
_lI1111I = _lllI11I
exit for
end if
end if
end if
end for
if _lI1111I = 0 then return []
_llII11I = Mid(_lII111I, _lll111I, _lI1111I - _lll111I + 1)
_l11I11I = ParseJSON(_llII11I)
if _l11I11I = invalid or type(_l11I11I) <> _l1d_55a757("4f3d22585b4b56", 201, 148) then return []
return _l11I11I
end function
function RP_XpassFirstSource(_l1III1I as Object) as String
if _l1III1I = invalid or type(_l1III1I) <> _l1d_55a757("39274c4144333a333e563c5e4e6d63665661", 169, 94) then return ""
_l1lllII = _l1III1I.playlist
if _l1lllII = invalid or type(_l1lllII) <> _l1d_55a757("5e4c75676a5e69", 107, 69) then return ""
for each _lIIII1I in _l1lllII
if type(_lIIII1I) <> _l1d_55a757("0212fb0c0f1e25222d232b273d1c2c2f4530", 90, 218) then continue for
_ll1llII = _lIIII1I.sources
if _ll1llII = invalid or type(_ll1llII) <> _l1d_55a757("37354e40433752", 227, 166) then continue for
for each _lIlllII in _ll1llII
if type(_lIlllII) <> _l1d_55a757("1e2657282b32413e4937473b5178484b614c", 254, 146) then continue for
_lllllII = _lIlllII.file
if _lllllII <> invalid and _lllllII <> "" then return _lllllII
end for
end for
return ""
end function
function RP_FetchXpassSubs(_lI111II as String, _lI1I1II as Object) as Object
if ((28956 - 4826 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lIlI1II = []
if _lI111II = invalid or _lI111II = "" then return _lIlI1II
_ll1I1II = CreateObject(_l1d_55a757("d4e4baf4f5fae0", 26, 108), _l1d_55a757("bcd4c6efcba6d1d2e8d8def70ae6c2b216f2ce", 55, 123) + chr(34) + _l1d_55a757("2c9e9c", 46, 38) + chr(34) + _l1d_55a757("eaff04", 231, 48) + chr(34), _l1d_55a757("0b", 145, 19))
m = _ll1I1II.match(_lI111II)
if m = invalid or m.Count() < 2 then return _lIlI1II
_l11I1II = HC_Get(_lI1I1II, m[1], invalid, 6000)
if _l11I1II = invalid or _l11I1II.body = "" then return _lIlI1II
_lII11II = ParseJSON(_l11I1II.body)
if _lII11II = invalid or type(_lII11II) <> _l1d_55a757("6268596b6e826d", 95, 53) then return _lIlI1II
_llII1II = _lII11II.Count()
if _llII1II > 30 then _llII1II = 30
for _llI11II = 0 to _llII1II - 1
_l1I11II = _lII11II[_llI11II]
if type(_l1I11II) <> _l1d_55a757("58764f606382798681798f7d917082859994", 147, 119) then continue for
_l1II1II = _l1I11II.url
if _l1II1II = invalid or _l1II1II = "" then continue for
_lllI1II = _l1d_55a757("1f27", 214, 108)
if _l1I11II.language <> invalid then _lllI1II = LCase(_l1I11II.language)
_l1lI1II = ""
if _l1I11II.display <> invalid then _l1lI1II = _l1I11II.display
if _l1lI1II = "" then
if _l1I11II.language <> invalid then _l1lI1II = UCase(_l1I11II.language) else _l1lI1II = _l1d_55a757("a6b0", 131, 224)
end if
_lIlI1II.Push({ url: _l1II1II, language: _lllI1II, name: _l1lI1II })
end for
return _lIlI1II
end function
function RP_ResolveJwplayerPage(_lI1llll as String, _l1Illll as String, _lll1lll as String, _l111lll as Object) as Object
if ((37312 - 4664 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lI1llll = invalid or _lI1llll = "" then return invalid
_l11llll = []
RP_JwExtractInto(_lI1llll, _l11llll)
_llIllll = CreateObject(_l1d_55a757("3220182c31323a", 9, 183), _l1d_55a757("b2c2b4b2e5f4c1d7bfc7dfc7ccce0312ed1ce422e828e62efa34ff2a3a2b3319393f404d64685a312436243e457e", 106, 163), _l1d_55a757("b5", 129, 205))
_lIIllll = _llIllll.match(_lI1llll)
if _lIIllll <> invalid and _lIIllll.Count() >= 1 then
_llI1lll = JU_UnpackPacked(_lIIllll[0])
if _llI1lll <> "" then RP_JwExtractInto(_llI1lll, _l11llll)
end if
if _l11llll.Count() = 0 then return invalid
_l1l1lll = _lll1lll
if _l1l1lll = "" then _l1l1lll = _l1Illll
_ll11lll = {}
for each _ll1llll in _l11llll
_lI11lll = RP_AbsUrl(_ll1llll.url, _l1Illll)
if _lI11lll = "" then continue for
if _ll11lll.DoesExist(_lI11lll) then continue for
_ll11lll[_lI11lll] = true
_lIl1lll = HC_Get(_l111lll, _lI11lll, { "Referer": _l1l1lll }, 6000)
if _lIl1lll = invalid or _lIl1lll.body = "" then continue for
if _ll1llll.fmt = _l1d_55a757("9aa1b5", 43, 87) and Left(_lIl1lll.body, 7) <> _l1d_55a757("52f3f1e80451f2", 214, 93) then continue for
return {
url: _lI11lll
streamFormat: _ll1llll.fmt
qualities: []
subtitles: RP_ExtractSubs(_lI1llll)
chapters: []
referer: _l1l1lll
userAgent: ""
}
end for
return invalid
end function
sub RP_JwExtractInto(_lI1lIll as String, _llII1ll as Object)
if _lI1lIll = invalid or _lI1lIll = "" then return
_l1lI1ll = chr(34)
_llllIll = _l1d_55a757("9393939d6995e1d475a1ed7f", 95, 90) + _l1lI1ll + _l1d_55a757("ee1bf32323", 143, 70) + _l1lI1ll + _l1d_55a757("c1caebabc2f6c5da", 24, 130) + _l1lI1ll + _l1d_55a757("9942", 204, 174)
_l1llIll = _l1d_55a757("fefd0a06fa03fd13cde0091fd90d", 130, 13) + _l1lI1ll + _l1d_55a757("cd96cea2a2", 125, 115) + _l1lI1ll + _l1d_55a757("c310edb1c8fccb1c", 58, 166) + _l1lI1ll + _l1d_55a757("3dda", 215, 77)
_lIllIll = _l1d_55a757("babed0b2c62215bed22ec0", 211, 26) + _l1lI1ll + _l1d_55a757("a6d3a3d3db", 11, 122) + _l1lI1ll + _l1d_55a757("b2ffdca2b9eb0fc0c1b5b50dc20bc30a1c14dbe1323a", 187, 22) + _l1lI1ll + _l1d_55a757("ea47f3f94a", 50, 213) + _l1lI1ll + _l1d_55a757("3b38", 227, 119)
_ll1lIll = _l1d_55a757("a3a298b3d2b0b1e4b8f407f0c400f2", 227, 16) + _l1lI1ll + _l1d_55a757("3770467c7a", 132, 148) + _l1lI1ll + _l1d_55a757("299273352c7e2da2", 169, 155) + _l1lI1ll + _l1d_55a757("4946", 102, 8)
for each _lIII1ll in [_llllIll, _l1llIll, _lIllIll, _ll1lIll]
_l11lIll = CreateObject(_l1d_55a757("4e463442474866", 196, 152), _lIII1ll, _l1d_55a757("de", 153, 238))
m = _l11lIll.match(_lI1lIll)
if m <> invalid and m.Count() >= 2 then
_llIlIll = RP_UnescapeSlashes(m[1])
_lIlI1ll = _l1d_55a757("848381", 190, 174)
if Instr(1, LCase(_llIlIll), _l1d_55a757("cf111fde", 164, 69)) > 0 then _lIlI1ll = _l1d_55a757("1a1057", 120, 5)
_llII1ll.Push({ url: _llIlIll, fmt: _lIlI1ll })
end if
end for
_l11I1ll = CreateObject(_l1d_55a757("2f471547484d4b", 214, 139), _l1d_55a757("3cffe6e9f0f43b4351542b2b", 117, 223) + _l1lI1ll + _l1d_55a757("96c4c7caf6aed2a7d9aaeecb0cccecec", 15, 110) + _l1lI1ll + _l1d_55a757("534f52552b795f6b71", 226, 142), _l1d_55a757("b3", 129, 203))
_ll1I1ll = _l11I1ll.match(_lI1lIll)
if _ll1I1ll <> invalid and _ll1I1ll.Count() >= 2 then _llII1ll.Push({ url: _ll1I1ll[1], fmt: _l1d_55a757("c6cdd1", 67, 155) })
_lI1I1ll = CreateObject(_l1d_55a757("61778777787d7d", 119, 92), _l1d_55a757("c3867d80878dc4cadaddb4b2", 252, 239) + _l1lI1ll + _l1d_55a757("442e3134245c3c5543581838775757", 109, 250) + _l1lI1ll + _l1d_55a757("c12d303319d73dc9cf", 170, 52), _l1d_55a757("d4", 127, 190))
_l1II1ll = _lI1I1ll.match(_lI1lIll)
if _l1II1ll <> invalid and _l1II1ll.Count() >= 2 then _llII1ll.Push({ url: _l1II1ll[1], fmt: _l1d_55a757("cbdb9a", 7, 97) })
end sub
function RP_UnescapeSlashes(_lll1l1l as String) as String
if _lll1l1l = invalid or _lll1l1l = "" then return ""
_lIIll1l = CreateObject(_l1d_55a757("483e2e3e3f4464", 135, 83), _l1d_55a757("e3e616", 243, 52), _l1d_55a757("fd", 1, 151))
return _lIIll1l.replaceAll(_lll1l1l, _l1d_55a757("11", 136, 106))
end function
function RP_AbsUrl(_llllI1l as String, _llII11l as String) as String
if _llllI1l = invalid or _llllI1l = "" then return ""
_lIII11l = U_Trim(_llllI1l)
if Left(_lIII11l, 7) = _l1d_55a757("a09fa2a15e7679", 184, 208) or Left(_lIII11l, 8) = _l1d_55a757("c7dee1e8eaa49497", 174, 1) then return _lIII11l
if Left(_lIII11l, 2) = _l1d_55a757("d5d8", 71, 109) then return _l1d_55a757("59585b5a609a", 216, 169) + _lIII11l
_ll1lI1l = HC_OriginOf(_llII11l)
if _ll1lI1l = "" then return _lIII11l
if Left(_lIII11l, 1) = _l1d_55a757("12", 241, 52) then return _ll1lI1l + _lIII11l
_lI1lI1l = Len(_ll1lI1l) + 1
if _lI1lI1l > Len(_llII11l) then return _ll1lI1l + _l1d_55a757("01", 78, 160) + _lIII11l
_l11lI1l = Mid(_llII11l, _lI1lI1l + 1)
_llIlI1l = Instr(1, _l11lI1l, _l1d_55a757("28", 179, 156))
if _llIlI1l > 0 then _l11lI1l = Left(_l11lI1l, _llIlI1l - 1)
_l1II11l = Instr(1, _l11lI1l, _l1d_55a757("a2", 201, 184))
if _l1II11l > 0 then _l11lI1l = Left(_l11lI1l, _l1II11l - 1)
_lIllI1l = 0
for _l1llI1l = 1 to Len(_l11lI1l)
if Mid(_l11lI1l, _l1llI1l, 1) = _l1d_55a757("1e", 214, 37) then _lIllI1l = _l1llI1l
end for
if _lIllI1l = 0 then return _ll1lI1l + _l1d_55a757("ea", 227, 30) + _lIII11l
return _ll1lI1l + _l1d_55a757("d3", 240, 244) + Left(_l11lI1l, _lIllI1l) + _lIII11l
end function
function RP_ResolveLookmovie(_l111lIl as String, _l1IIlIl as String, _llll1Il as Object) as Object
_llI1lIl = {}
if _l1IIlIl <> "" then _llI1lIl[_l1d_55a757("f70b1111231729", 129, 36)] = _l1IIlIl else _llI1lIl[_l1d_55a757("619393998d9f93", 158, 149)] = _l111lIl
_lI1IlIl = HC_Get(_llll1Il, _l111lIl, _llI1lIl, 8000)
if _lI1IlIl = invalid or _lI1IlIl.body = "" then return invalid
_lI11lIl = _lI1IlIl.finalUrl
if _lI11lIl = invalid or _lI11lIl = "" then _lI11lIl = _l111lIl
_l11IlIl = CreateObject(_l1d_55a757("0a2a30262b2c22", 112, 8), _l1d_55a757("a0b2aaa2d56cb1c5afbdcfbdbabef38ae58cda92de98dc9ee8a4ef1ab021230f29352ec4d2d8c8271a2e1a3635ee", 175, 214), _l1d_55a757("88", 48, 47))
_llIIlIl = _l11IlIl.match(_lI1IlIl.body)
if _llIIlIl = invalid or _llIIlIl.Count() < 1 then return invalid
_lIll1Il = JU_UnpackPacked(_llIIlIl[0])
if _lIll1Il = "" then return invalid
_lllIlIl = {}
_lII1lIl = CreateObject(_l1d_55a757("f5dbdbe7ecedfd", 13, 118), chr(34) + _l1d_55a757("0f52515d482426285229", 135, 96) + chr(34) + _l1d_55a757("d5ebc5b8e1f7d1", 18, 135) + chr(34) + _l1d_55a757("e73b3b", 61, 210) + chr(34) + _l1d_55a757("667b80", 111, 52) + chr(34), _l1d_55a757("161f", 92, 225))
_l1lIlIl = _lII1lIl.matchAll(_lIll1Il)
if _l1lIlIl <> invalid then
for each _lIlIlIl in _l1lIlIl
if _lIlIlIl.Count() < 3 then continue for
_lllIlIl[_lIlIlIl[1]] = RP_UnescapeSlashes(_lIlIlIl[2])
end for
end if
_ll1IlIl = [_l1d_55a757("94938fd2", 95, 93), _l1d_55a757("a9a8b8f6", 197, 252), _l1d_55a757("1a21296d", 97, 17)]
for each _l1I1lIl in _ll1IlIl
_l1ll1Il = _lllIlIl[_l1I1lIl]
if _l1ll1Il = invalid or _l1ll1Il = "" then continue for
_l1ll1Il = RP_AbsUrl(_l1ll1Il, _lI11lIl)
_lIIIlIl = HC_Get(_llll1Il, _l1ll1Il, { "Referer": _lI11lIl }, 6000)
if _lIIIlIl = invalid or _lIIIlIl.body = "" then continue for
if Left(_lIIIlIl.body, 7) <> _l1d_55a757("311a000f1b3019", 122, 216) then continue for
return {
url: _l1ll1Il
streamFormat: _l1d_55a757("ff0610", 32, 183)
qualities: []
subtitles: RP_ExtractSubs(_lI1IlIl.body)
chapters: []
referer: _lI11lIl
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidora(_lIllIIl as String, _llIlIIl as String, _l1IlIIl as Object) as Object
_l11lIIl = {}
if _llIlIIl <> "" then _l11lIIl[_l1d_55a757("5787898d839389", 223, 202)] = _llIlIIl else _l11lIIl[_l1d_55a757("fd2b2f3129372f", 212, 119)] = _l1d_55a757("7a999c9b9d574f529798b29cabb8adbfab6fccb679", 10, 24)
_lI1lIIl = HC_Get(_l1IlIIl, _lIllIIl, _l11lIIl, 8000)
if _lI1lIIl = invalid or _lI1lIIl.body = "" then return invalid
_ll1lIIl = _lI1lIIl.finalUrl
if _ll1lIIl = invalid or _ll1lIIl = "" then _ll1lIIl = _lIllIIl
return RP_ResolveJwplayerPage(_lI1lIIl.body, _ll1lIIl, _ll1lIIl, _l1IlIIl)
end function
function RP_Resolve2embed(_lllIll1 as String, _llll1l1 as String, _l1ll1l1 as Object) as Object
_lI1Ill1 = {}
if _llll1l1 <> "" then _lI1Ill1[_l1d_55a757("2f3f41455b4b61", 79, 18)] = _llll1l1 else _lI1Ill1[_l1d_55a757("c9b5bbbbb5c1bb", 181, 226)] = _l1d_55a757("474649484e88a0a35f537162746e7dba7177c4", 248, 183)
_lIIIll1 = HC_Get(_l1ll1l1, _lllIll1, _lI1Ill1, 8000)
if _lIIIll1 = invalid or _lIIIll1.body = "" then return invalid
_ll1Ill1 = _lIIIll1.finalUrl
if _ll1Ill1 = invalid or _ll1Ill1 = "" then _ll1Ill1 = _lllIll1
_lI1l1l1 = CreateObject(_l1d_55a757("58767e72777870", 113, 85), _l1d_55a757("627c7a37374d3d7c55574b5761635790a748", 200, 130) + chr(34) + _l1d_55a757("6e8b83c6adb0b7b77e869497c6c8cddde4ebd8dceee1cbbcabfb06040408e3d41215dc0b0a2b143201e10808", 23, 62) + chr(34) + _l1d_55a757("15ae1f20b5", 81, 159) + chr(34) + _l1d_55a757("3663", 14, 13), _l1d_55a757("9e", 106, 155))
_lIll1l1 = _lI1l1l1.match(_lIIIll1.body)
_llIl1l1 = ""
if _lIll1l1 <> invalid and _lIll1l1.Count() >= 2 then
_llIl1l1 = _lIll1l1[1]
else
_l1lIll1 = CreateObject(_l1d_55a757("d8befececfd4e4", 47, 123), _l1d_55a757("64a7aeb1b8b87f877578c7c9cebec5ccd9ddcfe2cc9dacdce7e5e5e9e4b5f3f6bd0c0b0c151302e209090e2a", 7, 53) + chr(34) + _l1d_55a757("665455396e73", 255, 142), _l1d_55a757("bc", 155, 202))
_l11Ill1 = _l1lIll1.match(_lIIIll1.body)
if _l11Ill1 <> invalid and _l11Ill1.Count() >= 2 then _llIl1l1 = _l11Ill1[1]
end if
if _llIl1l1 = "" then return invalid
_llIl1l1 = U_HtmlDecode(_llIl1l1)
_ll1l1l1 = HC_Get(_l1ll1l1, _llIl1l1, { "Referer": _ll1Ill1 }, 8000)
if _ll1l1l1 = invalid or _ll1l1l1.body = "" then return invalid
_l11l1l1 = _ll1l1l1.finalUrl
if _l11l1l1 = invalid or _l11l1l1 = "" then _l11l1l1 = _llIl1l1
_llIIll1 = CreateObject(_l1d_55a757("9aba80b6bbbcb2", 144, 184), _l1d_55a757("7c4a4c3b4b5a552e369939aa55596ba849", 81, 15) + chr(34) + _l1d_55a757("fd960ca2a0", 84, 138) + chr(34) + _l1d_55a757("5c09565b0c", 202, 111) + chr(34) + _l1d_55a757("154e", 129, 111), _l1d_55a757("24", 37, 216))
_lIlIll1 = _llIIll1.match(_ll1l1l1.body)
if _lIlIll1 = invalid or _lIlIll1.Count() < 2 then return invalid
_l1IIll1 = _lIlIll1[1]
_l1Il1l1 = ""
if Left(_l1IIll1, 4) = _l1d_55a757("67767978", 96, 95) then
_l1Il1l1 = _l1IIll1
else
_l1Il1l1 = _l1d_55a757("bebdc0bfc1fb1316dadcdfdee7e8e2ecfb2736eef9fe0246134c", 218, 12) + _l1IIll1
end if
return RP_ResolveLookmovie(_l1Il1l1, _l11l1l1, _l1ll1l1)
end function
function RP_ResolveCloudnestra(_lll1Il1 as String, _l11ll11 as String, _lll1l11 as Object) as Object
_lI1ll11 = _l11ll11
if _lI1ll11 = "" then _lI1ll11 = _lll1Il1
_lIlIIl1 = HC_Get(_lll1l11, _lll1Il1, { "Referer": _lI1ll11 }, 8000)
if _lIlIIl1 = invalid or _lIlIIl1.body = "" then return invalid
_ll11Il1 = _lIlIIl1.finalUrl
if _ll11Il1 = invalid or _ll11Il1 = "" then _ll11Il1 = _lll1Il1
_lIlll11 = CreateObject(_l1d_55a757("b5bb9bcbccd1c1", 31, 72), _l1d_55a757("5f6355315a6e2a5c", 3, 239) + chr(34) + _l1d_55a757("d17eced2acad9bb3a5bbe7969e", 75, 101) + chr(34) + _l1d_55a757("88d58a8fe0", 62, 111) + chr(34) + _l1d_55a757("e962", 165, 103), _l1d_55a757("94", 89, 100))
m = _lIlll11.match(_lIlIIl1.body)
if m = invalid or m.Count() < 2 then
_ll1ll11 = CreateObject(_l1d_55a757("d1f1b7f1f2f7ed", 146, 241), _l1d_55a757("67", 161, 109) + chr(34) + _l1d_55a757("510e5f5f2a2b2b31253977262c", 194, 108) + chr(34) + _l1d_55a757("d57ed7d88d", 77, 107) + chr(34) + _l1d_55a757("e310", 10, 182), _l1d_55a757("a2", 140, 189))
m = _ll1ll11.match(_lIlIIl1.body)
if m = invalid or m.Count() < 2 then return RP_ResolveGeneric(_lll1Il1, _l11ll11, _lll1l11)
end if
_lllll11 = m[1]
if Left(_lllll11, 1) <> _l1d_55a757("9c", 250, 199) then _lllll11 = _l1d_55a757("2d", 9, 7) + _lllll11
_l1IIIl1 = RP_AbsUrl(_lllll11, _ll11Il1)
_ll1IIl1 = HC_Get(_lll1l11, _l1IIIl1, { "Referer": _ll11Il1 }, 8000)
if _ll1IIl1 = invalid or _ll1IIl1.body = "" then return invalid
_l111Il1 = _ll1IIl1.finalUrl
if _l111Il1 = invalid or _l111Il1 = "" then _l111Il1 = _l1IIIl1
_lIl1Il1 = CreateObject(_l1d_55a757("a9978fa3a8a9b1", 73, 110), _l1d_55a757("897f8591597ea852", 136, 155) + chr(34) + _l1d_55a757("104644", 140, 108) + chr(34) + _l1d_55a757("622f34", 130, 131) + chr(34), _l1d_55a757("cb", 89, 155))
_lI11Il1 = _lIl1Il1.match(_ll1IIl1.body)
if _lI11Il1 = invalid or _lI11Il1.Count() < 2 then return invalid
_l1l1Il1 = _lI11Il1[1]
_lllIIl1 = CreateObject(_l1d_55a757("becca4d8dddec6", 25, 83), chr(34) + _l1d_55a757("ab92959ca26c7c7f83aac6b7b3bc7ea499b1daa1d992aaa1b1b3c6bfcbc0d801c800ded7d8", 148, 175) + chr(34), _l1d_55a757("7176", 255, 219))
_lII1Il1 = _lllIIl1.matchAll(_ll1IIl1.body)
_l1lIIl1 = []
_lIIll11 = {}
if _lII1Il1 <> invalid then
for each _l1I1Il1 in _lII1Il1
if _l1I1Il1.Count() < 2 then continue for
_llI1Il1 = _l1I1Il1[1]
if _lIIll11.DoesExist(_llI1Il1) then continue for
_lIIll11[_llI1Il1] = true
_l1lIIl1.Push(_llI1Il1)
end for
end if
if _l1lIIl1.Count() = 0 then _l1lIIl1.Push(_l1d_55a757("ece8edf5f23834ecfcfe0bfd070d010d0d1a221f1521252f216d253439", 194, 54))
_l1lll11 = []
_l1l1l11 = CreateObject(_l1d_55a757("7a82a092939886", 254, 238), _l1d_55a757("29417c434b38508b", 65, 12), _l1d_55a757("48", 94, 17))
_lI1IIl1 = _l1l1l11.split(_l1l1Il1)
if _lI1IIl1 <> invalid then
for each _l11IIl1 in _lI1IIl1
_ll11l11 = U_Trim(_l11IIl1)
if _ll11l11 <> "" then _l1lll11.Push(_ll11l11)
end for
end if
_l1IlIl1 = []
_llIIIl1 = CreateObject(_l1d_55a757("48686e68696e64", 242, 200), _l1d_55a757("c8a6a4d19ce2dabe", 226, 10), _l1d_55a757("5f", 114, 74))
for each _lIIIIl1 in _l1lll11
if Instr(1, _lIIIIl1, _l1d_55a757("b8be", 188, 241)) > 0 then
for each _llI1Il1 in _l1lIIl1
_lIIlIl1 = Instr(1, _llI1Il1, _l1d_55a757("a0", 2, 116))
if _lIIlIl1 > 0 and _lIIlIl1 < Len(_llI1Il1) then
_lIl1l11 = Mid(_llI1Il1, _lIIlIl1 + 1)
else
_lIl1l11 = _llI1Il1
end if
_l1IlIl1.Push(_llIIIl1.replaceAll(_lIIIIl1, _lIl1l11))
end for
else
_l1IlIl1.Push(_lIIIIl1)
end if
end for
_l1Ill11 = {}
for each _l111l11 in _l1IlIl1
if _l111l11 = "" or _l1Ill11.DoesExist(_l111l11) then continue for
_l1Ill11[_l111l11] = true
_llIll11 = HC_Get(_lll1l11, _l111l11, { "Referer": _l111Il1 }, 6000)
if _llIll11 = invalid or _llIll11.body = "" then continue for
if Left(_llIll11.body, 7) <> _l1d_55a757("1d7a6a717b1c79", 61, 255) then continue for
return {
url: _l111l11
streamFormat: _l1d_55a757("3b4226", 19, 192)
qualities: []
subtitles: RP_ExtractSubs(_ll1IIl1.body)
chapters: []
referer: _l111Il1
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidsrcXyz(_llIIl11 as String, _ll1l111 as String, _llIl111 as Object) as Object
if ((22446 - 2494 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l11l111 = _ll1l111
if _l11l111 = "" then _l11l111 = _l1d_55a757("08171a191de9dfe22e2222323628f8343e00", 161, 63)
_lIIIl11 = HC_Get(_llIl111, _llIIl11, { "Referer": _l11l111 }, 8000)
if _lIIIl11 = invalid or _lIIIl11.body = "" then return invalid
_l1IIl11 = _lIIIl11.finalUrl
if _l1IIl11 = invalid or _l1IIl11 = "" then _l1IIl11 = _llIIl11
_l1ll111 = CreateObject(_l1d_55a757("0715ed25262b13", 27, 158), _l1d_55a757("1a484655495853485033572469694360", 3, 219) + chr(34) + _l1d_55a757("ef5c4a31414c43576f484c6359505b88", 174, 102) + chr(34) + _l1d_55a757("9a17141abd23b0fbfdf1d22f", 162, 21) + chr(34) + _l1d_55a757("ea73eb7f7f", 221, 240) + chr(34) + _l1d_55a757("30e93a3bf0", 193, 74) + chr(34) + _l1d_55a757("a5fe", 176, 14), _l1d_55a757("67", 22, 232))
m = _l1ll111.match(_lIIIl11.body)
if m = invalid or m.Count() < 2 then
_lIll111 = CreateObject(_l1d_55a757("66868c86878c82", 50, 38), _l1d_55a757("090dff48ed", 79, 205) + chr(34) + _l1d_55a757("effceaf0f30208", 154, 50) + chr(34) + _l1d_55a757("0f0c22dce6e6f3e7f0ec010308fc3535", 231, 79) + chr(34) + _l1d_55a757("f2cffc01d2", 115, 158) + chr(34) + _l1d_55a757("6f58", 105, 33), _l1d_55a757("19", 126, 2))
m = _lIll111.match(_lIIIl11.body)
end if
if m <> invalid and m.Count() >= 2 then
_llll111 = RP_AbsUrl(m[1], _l1IIl11)
_lI1l111 = RP_ResolveCloudnestra(_llll111, _l1IIl11, _llIl111)
if _lI1l111 <> invalid and _lI1l111.url <> "" then return _lI1l111
end if
_lI1Il11 = R_FollowKnownIframes(_lIIIl11.body, _l1IIl11, _l11l111, 0, _llIl111)
if _lI1Il11 <> invalid and _lI1Il11.url <> invalid and _lI1Il11.url <> "" then return _lI1Il11
return RP_ResolveGeneric(_llIIl11, _ll1l111, _llIl111)
end function
function RP_ResolveMoviesapi(_l111I11 as String, _l1I1I11 as String, _lllII11 as Object) as Object
_lII1I11 = _l1I1I11
if _lII1I11 = "" then _lII1I11 = _l1d_55a757("7b6a6d6c6e3850539387958298a2a16a919b74", 50, 33)
_llI1I11 = HC_Get(_lllII11, _l111I11, { "Referer": _lII1I11 }, 8000)
if _llI1I11 = invalid or _llI1I11.body = "" then return invalid
_lI11I11 = _llI1I11.finalUrl
if _lI11I11 = invalid or _lI11I11 = "" then _lI11I11 = _l111I11
_ll11I11 = R_FollowKnownIframes(_llI1I11.body, _lI11I11, _lII1I11, 0, _lllII11)
if _ll11I11 <> invalid and _ll11I11.url <> invalid and _ll11I11.url <> "" then return _ll11I11
return RP_ResolveJwplayerPage(_llI1I11.body, _lI11I11, _lII1I11, _lllII11)
end function
function RP_ResolveAutoembed(_l11l1I1 as String, _ll111I1 as String, _l1I11I1 as Object) as Object
_l1ll1I1 = _l1d_55a757("afaeb1b0b2ec0407c9d7bdccdee3dbe3e3e5e2f4f5f7f7eaf8013f07060b4c", 250, 29)
_l1l11I1 = CreateObject(_l1d_55a757("121af8262b2c1a", 92, 228), _l1d_55a757("1edbe6dce4e83032f8f905fdfc1813144c51532225101b5f391c276b707488887e803742868b90924954989da0b5", 67, 178), _l1d_55a757("48", 252, 179))
m = _l1l11I1.match(_l11l1I1)
if m = invalid or m.Count() < 3 then return invalid
_lll11I1 = m[1]
_lIIl1I1 = m[2]
_llI11I1 = ""
_llIl1I1 = ""
if m.Count() >= 5 then
_llI11I1 = m[3]
_llIl1I1 = m[4]
end if
_l1Il1I1 = _l1d_55a757("25211b24", 228, 149)
if Left(_lIIl1I1, 2) = _l1d_55a757("9b9e", 41, 62) then _l1Il1I1 = _l1d_55a757("8c938f90", 33, 68)
_lIll1I1 = _l1d_55a757("efe6e9f0f02c3a3dfcfe03131a111d2313295f1a32262d3b263d337a3939825347518f505b568a", 255, 88) + _l1Il1I1 + _l1d_55a757("bd", 27, 151) + U_UrlEncode(_lIIl1I1) + _l1d_55a757("ab7c827e74cf", 193, 196) + _lll11I1
if _lll11I1 = _l1d_55a757("9596", 138, 151) and _llI11I1 <> "" and _llIl1I1 <> "" then
_lIll1I1 = _lIll1I1 + _l1d_55a757("c19186859a999bed", 96, 123) + _llI11I1 + _l1d_55a757("b47868826b8a888ac5", 115, 95) + _llIl1I1
end if
_l1111I1 = HC_Get(_l1I11I1, _lIll1I1, {
"Referer": _l1ll1I1
"Origin": _l1d_55a757("7d94979e9edac8cb8f9babb2a2a7a1afa9a9c6babbc3c5d8c4cd05d3cacf", 239, 246)
}, 8000)
if _l1111I1 = invalid or _l1111I1.body = "" then return invalid
_lI1l1I1 = ParseJSON(_l1111I1.body)
if _lI1l1I1 = invalid or type(_lI1l1I1) <> _l1d_55a757("f9e9d20306f5fcf9041a021e14f323261c27", 74, 193) then return invalid
_lI111I1 = ""
if _lI1l1I1.status_code <> invalid then _lI111I1 = _lI1l1I1.status_code.ToStr()
if _lI111I1 <> _l1d_55a757("57585b", 93, 232) then return invalid
_ll1l1I1 = _lI1l1I1.data
if _ll1l1I1 = invalid or type(_ll1l1I1) <> _l1d_55a757("0911fe13161d2c25301e2e26381f33364833", 92, 219) then return invalid
_lII11I1 = _ll1l1I1.stream_urls
if _lII11I1 = invalid or type(_lII11I1) <> _l1d_55a757("19391222253b36", 18, 185) or _lII11I1.Count() = 0 then return invalid
for each _lllI1I1 in _lII11I1
if type(_lllI1I1) <> _l1d_55a757("80a2a7a3a19b", 71, 108) and type(_lllI1I1) <> _l1d_55a757("66844b75728e948e", 211, 197) then continue for
if _lllI1I1 = "" then continue for
_lIl11I1 = HC_Get(_l1I11I1, _lllI1I1, { "Referer": _l1ll1I1 }, 6000)
if _lIl11I1 = invalid or _lIl11I1.body = "" then continue for
if Left(_lIl11I1.body, 7) <> _l1d_55a757("8b6c7c836daa8b", 239, 191) then continue for
return {
url: _lllI1I1
streamFormat: _l1d_55a757("fd04fe", 24, 141)
qualities: []
subtitles: []
chapters: []
referer: _l1ll1I1
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveYthd(_lII1II1 as String, _l1IIII1 as String, _lIIIII1 as Object) as Object
_l1lIII1 = {}
if _l1IIII1 <> "" then _l1lIII1[_l1d_55a757("917d83837d8983", 125, 98)] = _l1IIII1
_l11III1 = HC_Get(_lIIIII1, _lII1II1, _l1lIII1, 8000)
if _l11III1 = invalid or _l11III1.body = "" then return invalid
_lIlIII1 = CreateObject(_l1d_55a757("270f4d1b20212f", 236, 137), _l1d_55a757("4d6c645f6e5a4a7b77667c8b86", 146, 107) + chr(34) + _l1d_55a757("d8f2cdf8fa0ecb", 144, 12) + chr(34) + _l1d_55a757("eaede99fa5f9", 192, 251) + chr(34) + _l1d_55a757("e350555a1024186666f8fe", 218, 92) + chr(34) + _l1d_55a757("91464b", 190, 174) + chr(34), _l1d_55a757("86", 24, 21))
_ll1III1 = _lIlIII1.match(_l11III1.body)
if _ll1III1 <> invalid and _ll1III1.Count() >= 3 then
_lI1III1 = _l1d_55a757("565d606769332326", 134, 104) + _ll1III1[1] + _l1d_55a757("51291b315d", 75, 237) + _ll1III1[2]
return RP_ResolveCloudnestra(_lI1III1, _lII1II1, _lIIIII1)
end if
_llIIII1 = CreateObject(_l1d_55a757("b5d3dbd3d4d9d1", 179, 244), _l1d_55a757("6b718177ae7680917fcd", 207, 192) + chr(34) + _l1d_55a757("d9adad", 117, 124) + chr(34) + _l1d_55a757("7ac7cc", 74, 99) + chr(34), _l1d_55a757("84", 180, 167))
m = _llIIII1.match(_l11III1.body)
if m = invalid or m.Count() < 2 then return invalid
_lllIII1 = m[1]
_lI1III1 = _l1d_55a757("11f8fb0202cedcdf1e2828152931213341372c2e33474d4f3b5319575e632454665c30", 55, 178) + _lllIII1
return RP_ResolveCloudnestra(_lI1III1, _lII1II1, _lIIIII1)
end function
function RP_ResolveVidking(_llIl1lI as String, _l1l11lI as String, _l1111lI as Object) as Object
_lll11lI = CreateObject(_l1d_55a757("6151875d626369", 232, 199), _l1d_55a757("f9c2bdc7cbcf0b09cfd4f0d4e3effaff232c2ae1fc340a1518f30e46474b636359570e2961626b69203b73747790", 73, 147), _l1d_55a757("af", 115, 149))
m = _lll11lI.match(_llIl1lI)
if m = invalid or m.Count() < 3 then return invalid
_lIIl1lI = m[1]
_lI111lI = m[2]
_lIl11lI = ""
_l1Il1lI = ""
if m.Count() >= 5 then
_lIl11lI = m[3]
_l1Il1lI = m[4]
end if
_ll111lI# = B_StrToLong(_lI111lI)
return RP_VideasyFamilyResolve(_lIIl1lI, _lI111lI, _lIl11lI, _l1Il1lI, _ll111lI#, _lI111lI, _l1111lI)
end function
function RP_ResolveVideasy(_l11IIlI as String, _lIIIIlI as String, _lIlll1I as Object) as Object
if ((13722 - 2287 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1IIIlI = CreateObject(_l1d_55a757("888eae9a9fa090", 189, 185), _l1d_55a757("9b995f645064635f5a5fb3bcba917cc4c5c9c1c1d7d5ac97dfe0e9e7bea9f1f2f5ee", 113, 61), _l1d_55a757("35", 89, 5))
m = _l1IIIlI.match(_l11IIlI)
if m = invalid or m.Count() < 3 then return invalid
_llIIIlI = m[1]
_ll1ll1I = m[2]
_lllll1I = ""
_lI1IIlI = ""
if m.Count() >= 5 then
_lllll1I = m[3]
_lI1IIlI = m[4]
end if
_l1lll1I# = B_StrToLong(_ll1ll1I)
return RP_VideasyFamilyResolve(_llIIIlI, _ll1ll1I, _lllll1I, _lI1IIlI, _l1lll1I#, _ll1ll1I, _lIlll1I)
end function
function RP_VideasyFamilyResolve(_llI111I as String, _lIl1I1I as String, _llllI1I as String, _l11111I as String, _l1llI1I as LongInteger, _lIllI1I as String, _ll1lI1I as Object) as Object
_l1lI11I = _l1d_55a757("858487868a465c5fa9aa69a4a8b8bab9aea781bac689808f", 57, 52) + _llI111I + _l1d_55a757("f9", 85, 127) + _lIl1I1I + _l1d_55a757("fbc4b8bbd1dbd8b0cee6b9d1e9d6dcf8fce2fb3601f9f80af8170f1fef20200c", 83, 143)
_lllI11I = HC_Get(_ll1lI1I, _l1lI11I, {}, 6000)
_l1l1I1I = ""
_l111I1I = ""
_lI1111I = ""
if _lllI11I <> invalid and _lllI11I.body <> "" then
_lII111I = ParseJSON(_lllI11I.body)
if type(_lII111I) = _l1d_55a757("49573c5154636a636e666c6e7e5d73768671", 89, 30) then
if _llI111I = _l1d_55a757("696a866e7d", 75, 67) and _lII111I.title <> invalid then _l1l1I1I = _lII111I.title
if _llI111I = _l1d_55a757("272c", 141, 46) and _lII111I.name <> invalid then _l1l1I1I = _lII111I.name
if _llI111I = _l1d_55a757("484965555c", 15, 230) and _lII111I.release_date <> invalid then _l111I1I = Left(_lII111I.release_date, 4)
if _llI111I = _l1d_55a757("a9aa", 114, 163) and _lII111I.first_air_date <> invalid then _l111I1I = Left(_lII111I.first_air_date, 4)
if _lII111I.external_ids <> invalid and type(_lII111I.external_ids) = _l1d_55a757("a8b8ddb2b5c4cbc4cfc5cdcddffed2d5e7d2", 248, 30) then
if _lII111I.external_ids.imdb_id <> invalid then _lI1111I = _lII111I.external_ids.imdb_id
end if
end if
end if
_llII11I = [_l1d_55a757("8d85538f98988a", 144, 144), _l1d_55a757("1c1c15", 206, 111), _l1d_55a757("0612fd191a1e1b1b1d17da", 53, 181)]
_lIl111I = {
"Referer": _l1d_55a757("32414443430f050852514762515f1e6961616362738036837b3e", 3, 199)
"Origin": _l1d_55a757("7e7d807f85bfd7da8e9da590af9feea9afbdc1c0b5ae06bfcd", 216, 206)
"Accept": _l1d_55a757("a2a0a8", 37, 147)
}
for each _lI1I11I in _llII11I
_ll11I1I = _l1d_55a757("d0eff2f1f1ada3a6ef03edb30ef60608071815cb2810d3", 171, 13) + _lI1I11I + _l1d_55a757("8158476462545d6a9b745d7d64aa866c8c7781ca987e9e8993de", 75, 29) + U_UrlEncode(_l1l1I1I) + _l1d_55a757("76323d413f4a3a5864529d", 207, 141) + _llI111I + _l1d_55a757("0fedd4dbef35", 68, 173) + U_UrlEncode(_l111I1I)
if _llI111I = _l1d_55a757("b5ba", 152, 201) then
_ll1111I = _l1d_55a757("b8", 72, 63)
_l11lI1I = _l1d_55a757("58", 219, 110)
if _l11111I <> "" then _ll1111I = _l11111I
if _llllI1I <> "" then _l11lI1I = _llllI1I
_ll11I1I = _ll11I1I + _l1d_55a757("c004fc06ff061416351dc7", 191, 39) + _ll1111I + _l1d_55a757("74c2b7b6cbcaceaacaa4", 1, 77) + _l11lI1I
end if
_ll11I1I = _ll11I1I + _l1d_55a757("7449453f3c6a48a4", 226, 176) + _lIl1I1I + _l1d_55a757("e131302c315d35ef", 55, 208) + U_UrlEncode(_lI1111I)
_l1II11I = HC_Get(_ll1lI1I, _ll11I1I, _lIl111I, 8000)
if _l1II11I = invalid or _l1II11I.body = "" then continue for
_l11I11I = RP_VideasyDecrypt(U_Trim(_l1II11I.body), _l1llI1I)
if _l11I11I = "" then continue for
_ll1I11I = ParseJSON(_l11I11I)
if _ll1I11I = invalid or type(_ll1I11I) <> _l1d_55a757("2444592e315047504b4159495b7a4e51635e", 48, 226) then continue for
_lI1lI1I = _ll1I11I.sources
if _lI1lI1I = invalid or type(_lI1lI1I) <> _l1d_55a757("e1c7b8eaede1ec", 79, 164) or _lI1lI1I.Count() = 0 then continue for
_l1IlI1I = ""
for each _llIlI1I in _lI1lI1I
if type(_llIlI1I) <> _l1d_55a757("ebe300f5f8efeef7f2000008fa2115180a25", 100, 213) then continue for
if _llIlI1I.url <> invalid and _llIlI1I.url <> "" then
_l1IlI1I = _llIlI1I.url
exit for
end if
if _llIlI1I.file <> invalid and _llIlI1I.file <> "" then
_l1IlI1I = _llIlI1I.file
exit for
end if
end for
if _l1IlI1I = "" then continue for
_lIIlI1I = []
if _ll1I11I.subtitles <> invalid and type(_ll1I11I.subtitles) = _l1d_55a757("0917fc12152510", 25, 158) then
for each _lIII11I in _ll1I11I.subtitles
if type(_lIII11I) <> _l1d_55a757("7080657a7d8c938c978d9595a7869a9daf9a", 24, 6) then continue for
_lll1I1I = ""
if _lIII11I.url <> invalid then _lll1I1I = _lIII11I.url
if _lll1I1I = "" and _lIII11I.file <> invalid then _lll1I1I = _lIII11I.file
if _lll1I1I = "" then continue for
_l1I111I = _l1d_55a757("373f", 98, 48)
if _lIII11I.language <> invalid then _l1I111I = LCase(Left(_lIII11I.language, 2))
if _l1I111I = "" and _lIII11I.lang <> invalid then _l1I111I = LCase(Left(_lIII11I.lang, 2))
_lIlI11I = ""
if _lIII11I.label <> invalid then _lIlI11I = _lIII11I.label
if _lIlI11I = "" then _lIlI11I = UCase(_l1I111I)
_lIIlI1I.Push({ url: _lll1I1I, language: _l1I111I, name: _lIlI11I })
end for
end if
return {
url: _l1IlI1I
streamFormat: U_StreamFormat(_l1IlI1I)
qualities: []
subtitles: _lIIlI1I
chapters: []
referer: _l1d_55a757("c0bfc2c1c3fd1518d0dfe7d2f1dd2ce7f1ff0302f3f04407150751", 122, 174)
userAgent: ""
}
end for
return invalid
end function
function RP_VideasyDecrypt(_llIllII as String, _llIIlII as LongInteger) as String
if ((10700 - 2675 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _llIllII = invalid or _llIllII = "" then return ""
_l11llII = CreateObject(_l1d_55a757("43593951495b42585b6b66", 149, 92))
_l11llII.FromHexString(_llIllII)
if _l11llII.Count() = 0 then return ""
_lI11lII = RP_VkLcgBytes(_llIIlII, 50)
_l1I1lII = RP_VkSerializeBytes(_lI11lII)
_llI1lII = CreateObject(_l1d_55a757("06ecdc040cfee51b1e0e19", 205, 71))
_llI1lII.FromAsciiString(_l1I1lII)
_l111lII = _l1d_55a757("2221262a2c023208380b4247454b4a4e4f53565a5b636168686c727776787a4e808286868c609296989c9da5a3aaaeb2b4b986bfb98fbfcac69fd2d7d8a9dee3e2e6e6e6ecf4f1f9cbfed30604d8", 223, 55)
_ll11lII = CreateObject(_l1d_55a757("eff525f1f90b3204071b06", 63, 162))
_ll11lII.FromHexString(_l111lII)
_ll1IlII = R4_KSA(_ll11lII)
_lIIllII = R4_PRGA(_ll1IlII, _llI1lII)
_l11IlII = R4_KSA(_lIIllII)
_l1IIlII = R4_PRGA(_l11IlII, _l11llII)
if _l1IIlII.Count() < 32 then return ""
if _l1IIlII[0] <> 83 or _l1IIlII[1] <> 97 or _l1IIlII[2] <> 108 or _l1IIlII[3] <> 116 then return ""
if _l1IIlII[4] <> 101 or _l1IIlII[5] <> 100 or _l1IIlII[6] <> 95 or _l1IIlII[7] <> 95 then return ""
_lI1IlII = B_Slice(_l1IIlII, 8, 16)
_lllllII = B_Slice(_l1IIlII, 16, _l1IIlII.Count())
_l1lIlII = CreateObject(_l1d_55a757("72728886847897878a809b", 226, 226))
_l1l1lII = EvpBytesToKey(_l1lIlII, _lI1IlII, 32)
if _l1l1lII.Count() < 32 then return ""
_lIl1lII = B_Slice(_l1l1lII, 0, 16)
_lll1lII = B_Slice(_l1l1lII, 16, 32)
_lIlllII = _lIl1lII.ToHexString()
_l1lllII = _lll1lII.ToHexString()
_ll1llII = CreateObject(_l1d_55a757("a6bed7cbd0e6cfb9d4ccc4", 244, 32))
_lIlIlII = _ll1llII.Setup(false, _l1d_55a757("9fa697f4dbe1ea00b9bdbf", 81, 111), _lIlllII, _l1lllII, 1)
if _lIlIlII <> 0 then return ""
_lII1lII = CreateObject(_l1d_55a757("fc0af2fa0a1cfb1114240f", 217, 81))
_lllIlII = _ll1llII.Process(_lllllII)
if _lllIlII <> invalid then
for _l1IllII = 0 to _lllIlII.Count() - 1
_lII1lII.Push(_lllIlII[_l1IllII])
end for
end if
_lI1llII = _ll1llII.Final()
if _lI1llII <> invalid then
for _l1IllII = 0 to _lI1llII.Count() - 1
_lII1lII.Push(_lI1llII[_l1IllII])
end for
end if
if _lII1lII.Count() = 0 then return ""
return _lII1lII.ToAsciiString()
end function
function RP_VkLcgBytes(_lIlI1II as LongInteger, _lII11II as Integer) as Object
if ((62344 - 7793 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1lI1II = CreateObject(_l1d_55a757("f9f1cf0d03f7de0e110722", 70, 197))
_ll1I1II# = _lIlI1II AND 2147483647&
for _lllI1II = 1 to _lII11II
_ll1I1II# = (_ll1I1II# * 1103515245& + 12345&) AND 2147483647&
_l1I11II# = _ll1I1II# mod 255&
_l1lI1II.Push(_l1I11II#)
end for
return _l1lI1II
end function
function RP_VkSerializeBytes(_lI1llll as Object) as String
if _lI1llll = invalid or _lI1llll.Count() = 0 then return ""
_lIIllll = ""
_l1Illll = _lI1llll.Count()
for _llIllll = 0 to _l1Illll - 1
if _llIllll > 0 then _lIIllll = _lIIllll + _l1d_55a757("69", 8, 69)
_lIIllll = _lIIllll + _lI1llll[_llIllll].ToStr()
end for
return _lIIllll
end function
function RP_ResolvePeachify(_l11I1ll as String, _lll1Ill as String, _l111Ill as Object) as Object
_ll1lIll = CreateObject(_l1d_55a757("b8b09eb0b1b6d4", 70, 132), _l1d_55a757("686c2c314b39404a555a88898d3c57996570734e69abacaec0c6b6ba6984c6c7c8cc7b96d8d9dced", 76, 5), _l1d_55a757("70", 211, 182))
m = _ll1lIll.match(_l11I1ll)
if m = invalid or m.Count() < 3 then return invalid
_lIII1ll = m[1]
_l1lIIll = m[2]
_ll11Ill = ""
_llII1ll = ""
if m.Count() >= 5 then
_ll11Ill = m[3]
_llII1ll = m[4]
end if
_lIIlIll = [
{ host: _l1d_55a757("23283df33f463600404e555654114f6355", 63, 217),  path: _l1d_55a757("19171b1e36", 6, 171) },
{ host: _l1d_55a757("9ea3a472bac1b17bbbc9d0d5cf90cee2d4", 29, 54),  path: _l1d_55a757("d5d6e0dad9d5e5f5", 98, 198) },
{ host: _l1d_55a757("a8a59a56a4a3b965bbb3b2b3af74ccbed2", 138, 169),  path: _l1d_55a757("1c37213c2c", 12, 187) },
{ host: _l1d_55a757("b8bdbe6ab4b3c975cbc3c2c7bf88e0d2e6", 40, 91),  path: _l1d_55a757("151105", 19, 152) },
{ host: _l1d_55a757("4a4f6498666d5ba765757c7d79b676887c", 222, 159),  path: _l1d_55a757("46413d", 56, 237) }
]
_l1II1ll = {
"Referer": _l1d_55a757("6281848385bfb7ba928a898a868a96a0d4b19bb3e1", 234, 224)
"Origin": _l1d_55a757("8e7d807f83cfe5e88ea4a3a8b2b4b6aa04adc9af", 81, 85)
"Accept": _l1d_55a757("cbbfc2d9dfd8ddcdebe8ec2ef6e0f7fb", 215, 21)
}
for each _l1IlIll in _lIIlIll
_lIlIIll = _l1d_55a757("1d2c2f2e327e7477", 193, 116) + _l1IlIll.host + _l1d_55a757("32", 207, 82) + _l1IlIll.path + _l1d_55a757("f0", 113, 146) + _lIII1ll + _l1d_55a757("64", 41, 94) + _l1lIIll
if _lIII1ll = _l1d_55a757("a1a2", 23, 62) and _ll11Ill <> "" and _llII1ll <> "" then
_lIlIIll = _lIlIIll + _l1d_55a757("f8", 152, 65) + _ll11Ill + _l1d_55a757("81", 134, 216) + _llII1ll
end if
_l1l1Ill = HC_Get(_l111Ill, _lIlIIll, _l1II1ll, 8000)
if _l1l1Ill = invalid or _l1l1Ill.body = "" then continue for
_lI1I1ll = ParseJSON(_l1l1Ill.body)
if _lI1I1ll = invalid or type(_lI1I1ll) <> _l1d_55a757("0806df101312091611291f2d210032352944", 131, 23) then continue for
if _lI1I1ll.isEncrypted <> true then continue for
_ll1I1ll = _lI1I1ll.data
if _ll1I1ll = invalid or type(_ll1I1ll) <> _l1d_55a757("02f2e9110efc000c", 74, 202) then continue for
_llIlIll = RP_PeachifyDecrypt(_ll1I1ll)
if _llIlIll = "" then continue for
_l11lIll = ParseJSON(_llIlIll)
if _l11lIll = invalid or type(_l11lIll) <> _l1d_55a757("bba1d2c3c6adbcb9c4d4c2d8ccf3e5e8dce7", 239, 30) then continue for
_lI11Ill = _l11lIll.sources
if _lI11Ill = invalid or type(_lI11Ill) <> _l1d_55a757("574f6c60635570", 228, 193) or _lI11Ill.Count() = 0 then continue for
_l1I1Ill = ""
for each _llI1Ill in _lI11Ill
if type(_llI1Ill) <> _l1d_55a757("5f4572676a5160596474627c6c93898c7c87", 173, 128) then continue for
if _llI1Ill.url <> invalid and _llI1Ill.url <> "" then
_l1I1Ill = _llI1Ill.url
exit for
end if
if _llI1Ill.file <> invalid and _llI1Ill.file <> "" then
_l1I1Ill = _llI1Ill.file
exit for
end if
end for
if _l1I1Ill = "" then continue for
_lII1Ill = []
if _l11lIll.subtitles <> invalid and type(_l11lIll.subtitles) = _l1d_55a757("05253a0e11231e", 176, 67) then
for each _lIl1Ill in _l11lIll.subtitles
if type(_lIl1Ill) <> _l1d_55a757("e6eedbf0f3fa09020dfb0b0315fc10132510", 220, 56) then continue for
_lllIIll = ""
if _lIl1Ill.url <> invalid then _lllIIll = _lIl1Ill.url
if _lllIIll = "" and _lIl1Ill.file <> invalid then _lllIIll = _lIl1Ill.file
if _lllIIll = "" then continue for
_llllIll = _l1d_55a757("fb09", 181, 43)
if _lIl1Ill.language <> invalid then _llllIll = LCase(Left(_lIl1Ill.language, 2))
_lIllIll = ""
if _lIl1Ill.label <> invalid then _lIllIll = _lIl1Ill.label
if _lIllIll = "" then _lIllIll = UCase(_llllIll)
_lII1Ill.Push({ url: _lllIIll, language: _llllIll, name: _lIllIll })
end for
end if
_lI1lIll = U_StreamFormat(_l1I1Ill)
_l1llIll = LCase(_l1I1Ill)
if Instr(1, _l1llIll, _l1d_55a757("c0edaefc", 214, 5)) > 0 then
_lI1lIll = _l1d_55a757("767d83", 98, 108)
else if Instr(1, _l1llIll, _l1d_55a757("4e3e7d", 119, 52)) > 0 then
_lI1lIll = _l1d_55a757("262cf3", 32, 217)
end if
return {
url: _l1I1Ill
streamFormat: _lI1lIll
qualities: []
subtitles: _lII1Ill
chapters: []
referer: _l1d_55a757("60777a81813d2b2e907e858684868c9c4aa78fb155", 143, 121)
userAgent: ""
}
end for
return invalid
end function
function RP_PeachifyDecrypt(_lI11l1l as String) as String
if _lI11l1l = invalid or _lI11l1l = "" then return ""
_l111l1l = _lI11l1l.Tokenize(_l1d_55a757("f2", 89, 123))
if _l111l1l = invalid or _l111l1l.Count() < 3 then return ""
_lIl1l1l = HC_Base64UrlDecode(_l111l1l[0])
_l1l1l1l = HC_Base64UrlDecode(_l111l1l[1])
_l1I1l1l = HC_Base64UrlDecode(_l111l1l[2])
if _lIl1l1l.Count() <> 12 then return ""
if _l1I1l1l.Count() <> 16 then return ""
_ll11l1l = _l1d_55a757("88e293e294e79bf1a4fba8fc02fe09050bc013c215c91ccd24d62ddd32e43ae738eb3ff246f94d005407580e620f69166f1d1e24742b7b307f33893c90419646", 192, 231)
_llI1l1l = AGD_Decrypt(_ll11l1l, _lIl1l1l, _l1l1l1l, _l1I1l1l)
if _llI1l1l = invalid then return ""
return _llI1l1l.ToAsciiString()
end function
function RP_ResolvePrimesrc(_lIII11l as String, _llllI1l as String, _l1llI1l as Object) as Object
if ((40065 - 8013 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
return invalid
end function
function RP_ResolveStreamtape(_lIlIlIl as String, _l11l1Il as String, _lI1l1Il as Object) as Object
_l11IlIl = CreateObject(_l1d_55a757("a4b28abec3c4ac", 89, 121), _l1d_55a757("5970998977687082af76aa987f9370887f9c91a4999e", 150, 160), _l1d_55a757("97", 60, 66))
_l1IIlIl = _l11IlIl.match(_lIlIlIl)
if _l1IIlIl = invalid or _l1IIlIl.Count() < 2 then return invalid
_l1lIlIl = _l1d_55a757("fbeaedecf0bcd2d5fc0203171625111f1329f72d3c3d023b08", 17, 130) + _l1IIlIl[1]
_ll1IlIl = {}
if _l11l1Il <> "" then _ll1IlIl[_l1d_55a757("3b4b4d5167576d", 15, 222)] = _l11l1Il
_lIIIlIl = HC_Get(_lI1l1Il, _l1lIlIl, _ll1IlIl, 8000)
if _lIIIlIl = invalid or _lIIIlIl.body = "" then return invalid
_lII1lIl = _l1d_55a757("9993a2b39ea9a1be67b3b8ca9eb8c4bfcac2dfb4e2b5db9aa0f6deece400ebf3eff7bebfbb0501041226f30af6f8e7efedeb", 142, 175)
_lI1IlIl = Instr(1, _lIIIlIl.body, _lII1lIl)
if _lI1IlIl <= 0 then return invalid
_llI1lIl = Mid(_lIIIlIl.body, _lI1IlIl + Len(_lII1lIl))
_lIll1Il = Instr(1, _llI1lIl, _l1d_55a757("6d", 165, 235))
if _lIll1Il <= 0 then return invalid
_llll1Il = Left(_llI1lIl, _lIll1Il - 1)
_lllIlIl = _l1d_55a757("49555056062020", 94, 212)
_llIIlIl = Instr(1, _llI1lIl, _lllIlIl)
if _llIIlIl <= 0 then return invalid
_l1I1lIl = Mid(_llI1lIl, _llIIlIl + Len(_lllIlIl))
_ll1l1Il = Instr(1, _l1I1lIl, _l1d_55a757("d0", 220, 213))
if _ll1l1Il <= 0 then return invalid
_l1ll1Il = Left(_l1I1lIl, _ll1l1Il - 1)
_llIl1Il = _l1d_55a757("3c4b4e4d4d99", 195, 145) + _llll1Il + _l1ll1Il
return {
url: _llIl1Il
streamFormat: U_StreamFormat(_llIl1Il)
qualities: []
subtitles: []
chapters: []
referer: _l1d_55a757("4544474648829a9d545c597372716b7b6d85bd858489ca", 90, 19)
userAgent: ""
}
end function
function RP_ResolveUqload(_l11lIIl as String, _lIIlIIl as String, _lll1IIl as Object) as Object
_lI1lIIl = {}
if _lIIlIIl <> "" then _lI1lIIl[_l1d_55a757("c0babac0acc6b2", 50, 96)] = _lIIlIIl
_llIlIIl = HC_Get(_lll1IIl, _l11lIIl, _lI1lIIl, 8000)
if _llIlIIl = invalid or _llIlIIl.body = "" then return invalid
_l1IlIIl = CreateObject(_l1d_55a757("545c3a6c6d7260", 94, 40), _l1d_55a757("576e5b5f737469516f493c5d7b55666c", 22, 242) + chr(34) + _l1d_55a757("d1858d", 65, 104) + chr(34) + _l1d_55a757("daeff4", 238, 39) + chr(34), _l1d_55a757("58", 254, 193))
m = _l1IlIIl.match(_llIlIIl.body)
if m = invalid or m.Count() < 2 then return invalid
_l1l1IIl = m[1]
if Left(_l1l1IIl, 4) <> _l1d_55a757("7c63666d", 149, 127) then return invalid
return {
url: _l1l1IIl
streamFormat: U_StreamFormat(_l1l1IIl)
qualities: []
subtitles: []
chapters: []
referer: _l1d_55a757("808f929191ddd3d6a3a2a2a29ba3ecb6b5f4", 67, 85)
userAgent: ""
}
end function
function RP_ResolveDoodstream(_ll1Ill1 as String, _l1l11l1 as String, _lIl11l1 as Object) as Object
_llIIll1 = {}
if _l1l11l1 <> "" then _llIIll1[_l1d_55a757("80545a5a6c6072", 233, 197)] = _l1l11l1
_ll1l1l1 = HC_Get(_lIl11l1, _ll1Ill1, _llIIll1, 8000)
if _ll1l1l1 = invalid or _ll1l1l1.body = "" then return invalid
_lI1Ill1 = _ll1l1l1.finalUrl
if _lI1Ill1 = invalid or _lI1Ill1 = "" then _lI1Ill1 = _ll1Ill1
if Instr(1, _ll1l1l1.body, _l1d_55a757("0034483d405f505a0e1b", 56, 233)) <= 0 then return invalid
_lI1l1l1 = CreateObject(_l1d_55a757("b6be9ccecfd4c2", 30, 74), _l1d_55a757("e4182c212443343ef2ff4e5410", 56, 205) + chr(34) + _l1d_55a757("4ec7", 93, 78), _l1d_55a757("87", 3, 29))
_l11l1l1 = _lI1l1l1.match(_ll1l1l1.body)
if _l11l1l1 = invalid or _l11l1l1.Count() < 1 then return invalid
_llll1l1 = _l11l1l1[0]
_lIlIll1 = HC_OriginOf(_lI1Ill1)
if _lIlIll1 = "" then return invalid
_lIll1l1 = _lIlIll1 + _llll1l1
_lIIIll1 = 0
for _l1IIll1 = 1 to Len(_llll1l1)
if Mid(_llll1l1, _l1IIll1, 1) = _l1d_55a757("d7", 130, 42) then _lIIIll1 = _l1IIll1
end for
if _lIIIll1 = 0 or _lIIIll1 = Len(_llll1l1) then return invalid
_lI111l1 = Mid(_llll1l1, _lIIIll1 + 1)
_l1ll1l1 = HC_Get(_lIl11l1, _lIll1l1, { "Referer": _lI1Ill1 }, 8000)
if _l1ll1l1 = invalid or _l1ll1l1.body = "" then return invalid
_lll11l1 = RP_RandomB62String(10)
_l11Ill1 = RP_NowMillis()
_llI11l1 = _l1ll1l1.body + _lll11l1 + _l1d_55a757("69353f464f477d", 126, 40) + _lI111l1 + _l1d_55a757("5416fc07130f0950", 88, 214) + _l11Ill1
_lIIl1l1 = ""
_ll111l1 = CreateObject(_l1d_55a757("44626a5e63645c", 49, 1), _l1d_55a757("ac67856d8882c0d56969ca6ce6e6d6ea94b29ab5afed", 213, 195), _l1d_55a757("2c", 54, 205))
_l1111l1 = _ll111l1.match(_ll1l1l1.body)
if _l1111l1 <> invalid and _l1111l1.Count() >= 2 then
_l1Il1l1 = CreateObject(_l1d_55a757("6b6951656a6b83", 65, 56), _l1d_55a757("e716313d08f20d475701", 15, 192), _l1d_55a757("83", 168, 194))
_llIl1l1 = _l1Il1l1.match(_l1111l1[1])
if _llIl1l1 <> invalid and _llIl1l1.Count() >= 2 then _lIIl1l1 = _llIl1l1[1]
end if
return {
url: _llI11l1
streamFormat: U_StreamFormat(_llI11l1)
qualities: []
subtitles: []
chapters: []
referer: _lIlIll1 + _l1d_55a757("9b", 3, 111)
userAgent: _l1d_55a757("f71c2c1c24272d6e87758a7d78383d47504c6766983952a1b3b7a8bdb9b36b707ad5d6cec893e4e5cbd779adb09fa99eafb18bacccf8111219051b23100bafb1d0babe2128e7e5eaf737df0001fc03404cf00a271516215e73797e6b807186778c7f33444e4a604891aaabb29eb4bc", 201, 115)
}
end function
function RP_RandomB62String(_ll11Il1 as Integer) as String
_lll1Il1 = _l1d_55a757("dfe5e7edeff5f7edeff5f7fdff0507fdff05070d0f15170d0f150d13151b1d23251b1d23252b2d33352b2d33353b3d43453b3d430c0e14161c1e24261c1e", 185, 231)
_l111Il1 = ""
for _l1l1Il1 = 1 to _ll11Il1
_lIl1Il1 = Rnd(62)
_l111Il1 = _l111Il1 + Mid(_lll1Il1, _lIl1Il1, 1)
end for
return _l111Il1
end function
function RP_NowMillis() as String
if ((56980 - 8140 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1IIl11 = CreateObject(_l1d_55a757("e806e0fef608dc121914", 81, 197))
_l1IIl11.Mark()
_l1ll111 = _l1IIl11.AsSeconds()
_lIIIl11 = _l1IIl11.GetMilliseconds()
_llll111 = _lIIIl11.ToStr()
_llll111 = Right(_l1d_55a757("323538", 239, 83) + _llll111, 3)
return _l1ll111.ToStr() + _llll111
end function
function RP_ResolveVoe(_lllII11 as String, _lIlllI1 as String, _l11llI1 as Object) as Object
if ((20704 - 5176 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_ll1II11 = {}
if _lIlllI1 <> "" then _ll1II11[_l1d_55a757("fc0c0e1228182e", 199, 103)] = _lIlllI1
_ll1II11[_l1d_55a757("bde2d3e791c0dde2daf7", 14, 98)] = _l1d_55a757("3c213121292c22737c7a7f727d6d424c45515c5b8d7e8796a8acadb2bea8a0757fcacbd3bd98d9dad0ccaea2a5a49ed3a4a6d0b1c1fd06070e0a10180510f4f605ff03261deceaefec2c14f5f601084541250f1c1a1b1663686e737075767b7c81746839433f554d969fa0a7a3a9b1", 225, 144)
_l1III11 = HC_Get(_l11llI1, _lllII11, _ll1II11, 8000)
if _l1III11 = invalid or _l1III11.body = "" then return invalid
_l11II11 = _l1III11.body
_l1lII11 = _l1III11.finalUrl
if _l1lII11 = invalid or _l1lII11 = "" then _l1lII11 = _lllII11
_l1lllI1 = CreateObject(_l1d_55a757("cbc3f1c3c4c9e7", 230, 55), _l1d_55a757("caebe9e6eed907b8fdfdfc01f10f0c1025d61f08181a3713efdf431ffbf1035353fd5a0f140908", 55, 138), _l1d_55a757("1b", 10, 184))
_ll1llI1 = _l1lllI1.match(_l11II11)
if _ll1llI1 <> invalid and _ll1llI1.Count() >= 2 then
_llIllI1 = RP_AbsUrl(_ll1llI1[1], _l1lII11)
_llIII11 = HC_Get(_l11llI1, _llIllI1, _ll1II11, 8000)
if _llIII11 <> invalid and _llIII11.body <> "" then
_l11II11 = _llIII11.body
_l1lII11 = _llIII11.finalUrl
if _l1lII11 = invalid or _l1lII11 = "" then _l1lII11 = _llIllI1
end if
end if
_lI11I11 = CreateObject(_l1d_55a757("868c6c989d9e8e", 93, 87), _l1d_55a757("65271a2c26302f615f82647d41514b3b96", 228, 141) + chr(34) + _l1d_55a757("4d61644b515a5f6f5d5a5e206882696d", 15, 223) + chr(34) + _l1d_55a757("4343e64ae0efe8585a36605c65fb0902120251445854605f28", 167, 71), _l1d_55a757("1f", 32, 214))
_llI1I11 = _lI11I11.match(_l11II11)
if _llI1I11 = invalid or _llI1I11.Count() < 2 then return invalid
_lllllI1 = U_Trim(_llI1I11[1])
if Left(_lllllI1, 2) <> _l1d_55a757("9e", 223, 26) + chr(34) then return invalid
_lllllI1 = Mid(_lllllI1, 3)
_l1I1I11 = 0
for _lI1II11 = Len(_lllllI1) to 1 step -1
if Mid(_lllllI1, _lI1II11, 1) = _l1d_55a757("d4", 141, 4) then
_l1I1I11 = _lI1II11
exit for
end if
end for
if _l1I1I11 <= 1 then return invalid
_lllllI1 = Left(_lllllI1, _l1I1I11 - 1)
if Right(_lllllI1, 1) = chr(34) then _lllllI1 = Left(_lllllI1, Len(_lllllI1) - 1)
_lII1I11 = RP_VoeDecrypt(_lllllI1)
if _lII1I11 = "" then return invalid
_lIIII11 = ParseJSON(_lII1I11)
if _lIIII11 = invalid or type(_lIIII11) <> _l1d_55a757("e5fd1aeff20908110cfa1a02143b0f12241f", 244, 95) then return invalid
_lI1llI1 = ""
_lIlII11 = _l1d_55a757("b4bbcf", 203, 17)
if _lIIII11.source <> invalid and type(_lIIII11.source) = _l1d_55a757("ceb4b3d1dac2c4ce", 13, 79) then
_lI1llI1 = _lIIII11.source
_lIlII11 = _l1d_55a757("6a717b", 192, 194)
else if _lIIII11.direct_access_url <> invalid and type(_lIIII11.direct_access_url) = _l1d_55a757("0efcf31d1a060c16", 203, 85) then
_lI1llI1 = _lIIII11.direct_access_url
_lIlII11 = _l1d_55a757("a39352", 55, 73)
end if
if _lI1llI1 = "" then return invalid
return {
url: _lI1llI1
streamFormat: _lIlII11
qualities: []
subtitles: []
chapters: []
referer: _l1lII11
userAgent: _ll1II11[_l1d_55a757("f2d3c8da86edd6d7d5ee", 169, 246)]
}
end function
function RP_VoeDecrypt(_llIl1I1 as String) as String
if _llIl1I1 = invalid or _llIl1I1 = "" then return ""
_lIl11I1 = RP_VoeRot13(_llIl1I1)
_l1l11I1 = CreateObject(_l1d_55a757("9d9b839b9ca1b9", 131, 172), _l1d_55a757("6968934e717277785d5e8766b28cae7295c2797ec6c987cdd3", 242, 183), _l1d_55a757("b4", 35, 112))
_lIl11I1 = _l1l11I1.replaceAll(_lIl11I1, _l1d_55a757("2e", 47, 190))
_l1111I1 = CreateObject(_l1d_55a757("eb03d103040907", 150, 7), _l1d_55a757("dc", 101, 162), _l1d_55a757("39", 26, 188))
_lIl11I1 = _l1111I1.replaceAll(_lIl11I1, "")
_l11l1I1 = CreateObject(_l1d_55a757("49391f49574b2a5e61535e", 136, 79))
_l11l1I1.FromBase64String(_lIl11I1)
_lll11I1 = _l11l1I1.Count()
if _lll11I1 = 0 then return ""
for _l1Il1I1 = 0 to _lll11I1 - 1
_lI111I1 = _l11l1I1[_l1Il1I1] - 3
if _lI111I1 < 0 then _lI111I1 = _lI111I1 + 256
_l11l1I1[_l1Il1I1] = _lI111I1
end for
_l1Il1I1 = 0
_lIIl1I1 = _lll11I1 - 1
while _l1Il1I1 < _lIIl1I1
_ll111I1 = _l11l1I1[_l1Il1I1]
_l11l1I1[_l1Il1I1] = _l11l1I1[_lIIl1I1]
_l11l1I1[_lIIl1I1] = _ll111I1
_l1Il1I1 = _l1Il1I1 + 1
_lIIl1I1 = _lIIl1I1 - 1
end while
_ll1l1I1 = _l11l1I1.ToAsciiString()
_lI1l1I1 = CreateObject(_l1d_55a757("4e4e246260543363665c77", 2, 222))
_lI1l1I1.FromBase64String(_ll1l1I1)
if _lI1l1I1.Count() = 0 then return ""
return _lI1l1I1.ToAsciiString()
end function
function RP_VoeRot13(_l11III1 as String) as String
if _l11III1 = "" then return ""
_l1lIII1 = CreateObject(_l1d_55a757("7b8b717b899d7c9093a590", 152, 145))
_l1lIII1.FromAsciiString(_l11III1)
for _ll1III1 = 0 to _l1lIII1.Count() - 1
_lIlIII1 = _l1lIII1[_ll1III1]
if _lIlIII1 >= 65 and _lIlIII1 <= 90 then
_l1lIII1[_ll1III1] = ((_lIlIII1 - 65 + 13) mod 26) + 65
else if _lIlIII1 >= 97 and _lIlIII1 <= 122 then
_l1lIII1[_ll1III1] = ((_lIlIII1 - 97 + 13) mod 26) + 97
end if
end for
return _l1lIII1.ToAsciiString()
end function
function RP_ResolveStreamsb(_l1l11lI as String, _lIlI1lI as String, _llII1lI as Object) as Object
if ((6568 - 1642 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lI111lI = CreateObject(_l1d_55a757("0826ee22272820", 17, 165), _l1d_55a757("fcf0f006c30cc212cfdad0d8dc262529b9e635e3cf3ecc294736db50e35055", 83, 129), _l1d_55a757("15", 214, 86))
_llI11lI = _lI111lI.match(_l1l11lI)
if _llI11lI = invalid or _llI11lI.Count() < 2 then return invalid
_l1111lI = _llI11lI[1]
_ll111lI = HC_HostOf(_l1l11lI)
if _ll111lI = "" then return invalid
_l1llIlI = _l1d_55a757("372291202d49392c63586ca8696c", 202, 143) + _l1111lI + _l1d_55a757("2427614a576c62526b475f6b59934e515f5f64767d747183", 254, 162)
_lll11lI = CreateObject(_l1d_55a757("d2d808d0d8ea11e7eafae5", 61, 131))
_lll11lI.FromAsciiString(_l1llIlI)
_lIl11lI = UCase(_lll11lI.ToHexString())
_lIIl1lI = _l1d_55a757("aac1c4cbd18b7b7e", 12, 70) + _ll111lI + _l1d_55a757("9b7a617a8276738ccdcdb9", 204, 184) + _lIl11lI
_ll1I1lI = HC_Get(_llII1lI, _lIIl1lI, {
"Referer": _l1l11lI
"watchsb": _l1d_55a757("e1f3e7e7ecfe050c", 150, 252)
"Accept": _l1d_55a757("180a0d242c292a1838393bff4531484a", 20, 163)
}, 8000)
if _ll1I1lI = invalid or _ll1I1lI.body = "" then return invalid
_lllI1lI = ParseJSON(_ll1I1lI.body)
if _lllI1lI = invalid or type(_lllI1lI) <> _l1d_55a757("6454796e716067606b8169897b9a8e91838e", 232, 202) then return invalid
_lI1I1lI = _lllI1lI.stream_data
if _lI1I1lI = invalid or type(_lI1I1lI) <> _l1d_55a757("e6f41deef10007040f070d0b1f3e10132712", 187, 29) then return invalid
_l1II1lI = ""
if _lI1I1lI.file <> invalid then _l1II1lI = U_Trim(_lI1I1lI.file)
if _l1II1lI = "" then return invalid
_lIII1lI = []
_l1lI1lI = _lI1I1lI.subs
if _l1lI1lI <> invalid and type(_l1lI1lI) = _l1d_55a757("051d3a0e11231e", 180, 63) then
for each _l11I1lI in _l1lI1lI
if type(_l11I1lI) <> _l1d_55a757("674d3e6f7259686570806e84785f91948893", 207, 170) then continue for
_llllIlI = _l11I1lI.file
if _llllIlI = invalid or _llllIlI = "" then continue for
_l1I11lI = ""
if _l11I1lI.label <> invalid then _l1I11lI = _l11I1lI.label
_lII11lI = _l1d_55a757("b2aa", 74, 131)
if _l1I11lI <> "" then _lII11lI = LCase(Left(_l1I11lI, 2))
_lIII1lI.Push({ url: _llllIlI, language: _lII11lI, name: _l1I11lI })
end for
end if
return {
url: _l1II1lI
streamFormat: _l1d_55a757("d9d8ea", 4, 109)
qualities: []
subtitles: _lIII1lI
chapters: []
referer: _l1l11lI
userAgent: ""
}
end function
function RP_ResolveMixdrop(_llIIIlI as String, _lIlll1I as String, _lI1ll1I as Object) as Object
if ((3477 - 1159 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1IIIlI = {}
if _lIlll1I <> "" then _l1IIIlI[_l1d_55a757("41777b7d6d8373", 152, 119)] = _lIlll1I else _l1IIIlI[_l1d_55a757("531f25253f2b45", 173, 84)] = _l1d_55a757("584f5259591523266b72667d72787a3f8d8447", 31, 225)
_l1IIIlI[_l1d_55a757("e0c1b6c604dbc4c5d1da", 224, 43)] = _l1d_55a757("735866585e61592a332f342732a479817a88939242b3bc4b5f616267755dd7acb47f808a72cd8e8f8781e5d7dad9d50adbdb07e8f6b4bdbec5bfc7cdbac52b2b3a3638dbd221212623e14b2c2d383ffcf65c445151524d1a1f232d252a2b303136299f7078768a844d56575e586066", 32, 6)
_lllll1I = HC_Get(_lI1ll1I, _llIIIlI, _l1IIIlI, 8000)
if _lllll1I = invalid or _lllll1I.body = "" then return invalid
_ll1ll1I = CreateObject(_l1d_55a757("1000360c111218", 40, 182), _l1d_55a757("a8f2e5f7e1fb02dce2c5e7b7cebb0b1f0d0bfd012b07110edef607111332483e272b55313b3808200d23197063755f79803d", 8, 116), _l1d_55a757("dd", 93, 169))
_llIll1I = _ll1ll1I.match(_lllll1I.body)
if _llIll1I = invalid or _llIll1I.Count() < 2 then
_l11ll1I = CreateObject(_l1d_55a757("d4eafaeaebf0f0", 183, 15), _l1d_55a757("9ce2f5e7f5eff6ccd2b5dbc7becfe1e90feff5f6e2da0f1917362c460b1339191f200c04615163612f375d3d43443028392f41788b7d8b858c45", 154, 246), _l1d_55a757("47", 6, 216))
_llIll1I = _l11ll1I.match(_lllll1I.body)
if _llIll1I = invalid or _llIll1I.Count() < 2 then return invalid
end if
_lIIIIlI = _llIll1I[1]
_ll11l1I = JU_UnpackPacked(_lIIIIlI)
if _ll11l1I = "" then return invalid
_l111l1I = CreateObject(_l1d_55a757("28400e3c414240", 148, 66), _l1d_55a757("1605ed011dd2fcfdff1c2f07e3d73b13ef", 49, 164) + chr(34) + _l1d_55a757("c55555", 95, 78) + chr(34) + _l1d_55a757("717e83", 227, 179) + chr(34), _l1d_55a757("fb", 230, 108))
_lIl1l1I = _l111l1I.match(_ll11l1I)
if _lIl1l1I = invalid or _lIl1l1I.Count() < 2 then return invalid
_l1lll1I = _lIl1l1I[1]
if Left(_l1lll1I, 2) = _l1d_55a757("7073", 25, 58) then
_lI11l1I = _l1d_55a757("9d9c9f9ea0da", 218, 235) + _l1lll1I
else if Left(_l1lll1I, 4) = _l1d_55a757("c2c9ccd3", 6, 84) then
_lI11l1I = _l1lll1I
else
return invalid
end if
_lll1l1I = []
_lIIll1I = CreateObject(_l1d_55a757("e907cf07080d05", 19, 136), _l1d_55a757("08efdfef0b3cebfb0607f507fcfd132c086454381470", 119, 212) + chr(34) + _l1d_55a757("956565", 127, 62) + chr(34) + _l1d_55a757("1b080d", 155, 85) + chr(34), _l1d_55a757("96", 207, 240))
_l1Ill1I = _lIIll1I.match(_ll11l1I)
if _l1Ill1I <> invalid and _l1Ill1I.Count() >= 2 then
_l1l1l1I = _l1Ill1I[1]
if Left(_l1l1l1I, 2) = _l1d_55a757("a7aa", 163, 27) then _l1l1l1I = _l1d_55a757("524144434993", 80, 26) + _l1l1l1I
if Left(_l1l1l1I, 4) = _l1d_55a757("52494c53", 31, 219) then
_lll1l1I.Push({ url: _l1l1l1I, language: _l1d_55a757("a19d", 248, 4), name: _l1d_55a757("ddc6d4cde3d3eee8d5", 243, 61) })
end if
end if
return {
url: _lI11l1I
streamFormat: U_StreamFormat(_lI11l1I)
qualities: []
subtitles: _lll1l1I
chapters: []
referer: _l1IIIlI[_l1d_55a757("e5f9ffff110517", 201, 74)]
userAgent: _l1IIIlI[_l1d_55a757("86677c6ebaa18a8b8982", 249, 218)]
}
end function
function _l1d_55a757(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function