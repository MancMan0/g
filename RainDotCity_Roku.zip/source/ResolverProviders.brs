function RP_ResolveGeneric(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll as String, _llII11lIIIII111II1lIIII1I1l1IllI1Il as String, _lllllIlIIll1III1lIl1llII1l111III1llIIIl as Object) as Object
_ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I = {}
if _llII11lIIIII111II1lIIII1I1l1IllI1Il <> "" then _ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I[_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("2671072e991aca68")] = _llII11lIIIII111II1lIIII1I1l1IllI1Il
_lllllI1I1llI1I1l1lll1I1lIlI1lll = HC_Get(_lllllIlIIll1III1lIl1llII1l111III1llIIIl, _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll, _ll1II1IIlI11ll11IllI1lIlIllII1II1l1ll1I, 8000)
if _lllllI1I1llI1I1l1lll1I1lIlI1lll = invalid or _lllllI1I1llI1I1l1lll1I1lIlI1lll.body = "" then return invalid
_ll111lllI111Il1l1lII1IlI1lI1II1I1lI = _lllllI1I1llI1I1l1lll1I1lIlI1lll.body
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = _lllllI1I1llI1I1l1lll1I1lIlI1lll.finalUrl
if _llIIl111Illll1111ll111lllI11Il1l11ll11111ll = invalid or _llIIl111Illll1111ll111lllI11Il1l11ll11111ll = "" then _llIIl111Illll1111ll111lllI11Il1l11ll11111ll = _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll
_llI1Il1l1IIlIl111IllII1lI11l1III11llIll = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("70f3fc489dcd3da3"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6fea2d14171e20e7edfd001715") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("64663a11cf93f38c851952e47f081a645a") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("52981af5cfb71b808ef1"), Chr(105))
_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = _llI1Il1l1IIlIl111IllII1lI11l1III11llIll.match(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
if _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l <> invalid and _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l.Count() >= 2 then
return {
url: _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l[1]
streamFormat: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3d26d845")
qualities: []
subtitles: RP_ExtractSubs(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
chapters: []
referer: _llII11lIIIII111II1lIIII1I1l1IllI1Il
userAgent: ""
}
end if
_llll11IlIlI1I1IlllllI1Il11l1llllIlIl11I1l1I = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5595ce36e2d1405e"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("22eb8e7f168160cc6fac4722c4") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("30be8a51385f3cd55e6a9437964a54c3") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4b25212427fd4b313d43"), Chr(105))
_llI1lllIl111I1IlIII1111lIlII1llllll11II = _llll11IlIlI1I1IlllllI1Il11l1llllIlIl11I1l1I.match(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
if _llI1lllIl111I1IlIII1111lIlII1llllll11II <> invalid and _llI1lllIl111I1IlIII1111lIlII1llllll11II.Count() >= 2 then
return {
url: _llI1lllIl111I1IlIII1111lIlII1llllll11II[1]
streamFormat: _llllIllII1II1I1ll1lll1lIlIII11I("261266af")
qualities: []
subtitles: RP_ExtractSubs(_ll111lllI111Il1l1lII1IlI1lI1II1I1lI)
chapters: []
referer: _llII11lIIIII111II1lIIII1I1l1IllI1Il
userAgent: ""
}
end if
return invalid
end function
function RP_ExtractSubs(_lllIIlIlII1ll111l1Il11Illlll11l11I1 as String) as Object
_llI1111ll111IlllIlI111lII1IIlIl = []
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = invalid or _lllIIlIlII1ll111l1Il11Illlll11l11I1 = "" then return _llI1111ll111IlllIlI111lII1IIlIl
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("610ae0168a6f94c8"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("731a5d7c7f7e803f3d3538a7ad") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("5ea41639e00513ad7136bbc250725fa649f212ecf4ae51"), (Chr(105) + Chr(103)))
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = _ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l.matchAll(_lllIIlIlII1ll111l1Il11Illlll11l11I1)
if _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = invalid then return _llI1111ll111IlllIlI111lII1IIlIl
for each _llI1lIlIIIlllI1I11Il1I11IlI11Il in _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I
if _llI1lIlIIIlllI1I11Il1I11IlI11Il.Count() < 2 then continue for
_llI11Il1II1I1lI1II11I1111II1lIl = _llI1lIlIIIlllI1I11Il1I11IlI11Il[1]
_llll1I11llIlll11lII11l11111IIIl = (Chr(101) + Chr(110))
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("63c2f1a750fe972c"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4f79a87bb083b98b78bf73957ab47ed5a6d5d7abe0b3"), Chr(105))
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _llI111lI11I1l11lI11l1lIlll11111lIIlI1II.match(_llI11Il1II1I1lI1II11I1111II1lIl)
if _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII <> invalid and _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII.Count() >= 2 then _llll1I11llIlll11lII11l11111IIIl = LCase(_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII[1])
_llI1111ll111IlllIlI111lII1IIlIl.Push({ url: _llI11Il1II1I1lI1II11I1111II1lIl, language: _llll1I11llIlll11lII11l11111IIIl, name: UCase(_llll1I11llIlll11lII11l11111IIIl) })
end for
return _llI1111ll111IlllIlI111lII1IIlIl
end function
function RP_ResolveVidsrcCc(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il as String, _ll1llllIllI1l1Il1l1IlIlIIIIl1lIlII1 as String, _ll1l1IlIlll1ll1IIl111lllIlII11IIll1 as Object) as Object
_ll1ll1II11IIlIIll1lII1I111IlI1ll1Illl1Illl1 = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("3974645a7075767c"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("380b0d2121601f1d1e33606b61696d35377d7e8a82819d9899515658cf9a5eb8b3b6e1ac7075798d8d8385fcc78b9095970ed99da2a5ba"), Chr(105))
m = _ll1ll1II11IIlIIll1lII1I111IlI1ll1Illl1Illl1.match(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il)
if m = invalid or m.Count() < 3 then return invalid
_llI1lIl1l1III111ll1l1l1l11I1llI11lII1I1 = m[1]
_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = m[2]
_ll1l11Ill1lIl1lI11II1I1IlllIllII1lIllll11l1 = ""
_llIll1IIIII1ll1l11III111lIII1ll = ""
if m.Count() >= 5 then
_ll1l11Ill1lIl1lI11II1I1IlllIllII1lIllll11l1 = m[3]
_llIll1IIIII1ll1l11III111lIII1ll = m[4]
end if
_llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l = HC_OriginOf(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il)
if _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l = "" then return invalid
if _llI1lIl1l1III111ll1l1l1l11I1llI11lII1I1 = (Chr(116) + Chr(118)) and _ll1l11Ill1lIl1lI11II1I1IlllIllII1lIllll11l1 <> "" and _llIll1IIIII1ll1l11III111lIII1ll <> "" then
_llIl1ll111l11l1111Ill1lll1IIllI = _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l + _llIIlIll1llIlII1lI1lIlI1l1lI111("5576af3285a2fb5eb16cd72a3dfa") + _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 + Chr(47) + _ll1l11Ill1lIl1lI11II1I1IlllIllII1lIllll11l1 + Chr(47) + _llIll1IIIII1ll1l11III111lIII1ll + _llIIlIll1llIlII1lI1lIlI1l1lI111("4c8673ee917c0fb2b5")
else
_llIl1ll111l11l1111Ill1lll1IIllI = _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("64734438427f4c444e474e5c5e97") + _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7184263b1089a79c2d")
end if
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = {
"Referer": _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il
"Origin": _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l
"Accept": _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("736c6565626957625976580e125204770e2c0571ef65fc37982292339e089d1b9327")
"X-Requested-With": _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("35be9d8e26508921bd6a9db7eda1c2")
}
_llIlllIlII1III1llll11IIIIIl1l1IlIIIlI1I = HC_Get(_ll1l1IlIlll1ll1IIl111lllIlII11IIll1, _llIl1ll111l11l1111Ill1lll1IIllI, _lllIIllll1llIIlllIllI11lll1ll1lIl11, 8000)
if _llIlllIlII1III1llll11IIIIIl1l1IlIIIlI1I = invalid or _llIlllIlII1III1llll11IIIIIl1l1IlIIIlI1I.body = "" then return invalid
_ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II = ParseJSON(_llIlllIlII1III1llll11IIIIIl1l1IlIIIlI1I.body)
if _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II = invalid or type(_ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("2e7d20fc96a14c37723db093d6497517229560") then return invalid
_ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = invalid
if _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II.data <> invalid then _ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II.data
if (_ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = invalid or type(_ll1llIlIIlII1I1llll1Il1llllIllI1ll1) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("37c87e441129bc69")) and _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II.servers <> invalid then _ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = _ll1l111I1l11111IIlIl1I1IIl1lllIlI1llIll11II.servers
if _ll1llIlIIlII1I1llll1Il1llllIllI1ll1 = invalid or type(_ll1llIlIIlII1I1llll1Il1llllIllI1ll1) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("467d5c5a74535842") then return invalid
for each _ll11IlllllI11Il11llI1lllll1III1lIIlI111 in _ll1llIlIIlII1I1llll1Il1llllIllI1ll1
if type(_ll11IlllllI11Il11llI1lllll1III1lIIlI111) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7ce166c64fcf6cca7dcb6faf7ba550af5ba544") then continue for
_ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = ""
if _ll11IlllllI11Il11llI1lllll1III1lIIlI111.hash <> invalid then _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = _ll11IlllllI11Il11llI1lllll1III1lIIlI111.hash
if _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = "" and _ll11IlllllI11Il11llI1lllll1III1lIIlI111.data_id <> invalid then _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = _ll11IlllllI11Il11llI1lllll1III1lIIlI111.data_id
if _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = "" and _ll11IlllllI11Il11llI1lllll1III1lIIlI111.id <> invalid then _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = _ll11IlllllI11Il11llI1lllll1III1lIIlI111.id
if _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II = "" then continue for
_lllIl11IIIll11l1lIIIlI1lII111ll111I = _llIllIIlI1llll1I1l11l111l111I1I1lll1IlIIl1l + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("36e11e7af9bd16e221a2b0a8dc") + _ll11IIlIllIll1II11IIlIIlI1l1lIl1lI1l1Il11II
_llIIIlI1ll1IIlIlIl1I111111II1IIlll11llll11I = HC_Get(_ll1l1IlIlll1ll1IIl111lllIlII11IIll1, _lllIl11IIIll11l1lIIIlI1lII111ll111I, _lllIIllll1llIIlllIllI11lll1ll1lIl11, 8000)
if _llIIIlI1ll1IIlIlIl1I111111II1IIlll11llll11I = invalid or _llIIIlI1ll1IIlIlIl1I111111II1IIlll11llll11I.body = "" then continue for
_lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1 = ParseJSON(_llIIIlI1ll1IIlIlIl1I111111II1IIlll11llll11I.body)
if _lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1 = invalid or type(_lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1) <> _llllIllII1II1I1ll1lll1lIlIII11I("6f8e6487adb278bd22a7db3105fbbed4d9cf53") then continue for
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = invalid
if _lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1.data <> invalid and type(_lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1.data) = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("68441160c7649388e34817eac768db17270b17") then
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1.data
else
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _lllI1I111II1II11IllllIIII1I1Ill1I1I1111l1I1
end if
_ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = ""
if _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.stream <> invalid then _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = RP_AsStreamString(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.stream)
if _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = "" and _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.source <> invalid then _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = RP_AsStreamString(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.source)
if _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = "" and _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.file <> invalid then _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = RP_AsStreamString(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.file)
if _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = "" and _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.url <> invalid then _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = RP_AsStreamString(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.url)
if _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il = "" then continue for
_llIlIl1l1I1IlllIlIIl11Il11I11II = []
_ll1lIlI1II11IIllI1Il1lII111l1II = invalid
if _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.subtitles <> invalid then _ll1lIlI1II11IIllI1Il1lII111l1II = _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.subtitles
if _ll1lIlI1II11IIllI1Il1lII111l1II = invalid and _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.captions <> invalid then _ll1lIlI1II11IIllI1Il1lII111l1II = _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.captions
if _ll1lIlI1II11IIllI1Il1lII111l1II <> invalid and type(_ll1lIlI1II11IIllI1Il1lII111l1II) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6c41afc95c86ebb9") then
for each _ll1IIlIII111II1llllI1I11lII11lll111l1ll in _ll1lIlI1II11IIllI1Il1lII111l1II
if type(_ll1IIlIII111II1llllI1I11lII11lll111l1ll) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4c4406ca38c7aab0b8c5f834ceaf0d0bd2b3d9") then continue for
_ll1IIIlIl1Il1IIlll1IIllIl1111ll = ""
if _ll1IIlIII111II1llllI1I11lII11lll111l1ll.file <> invalid then _ll1IIIlIl1Il1IIlll1IIllIl1111ll = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.file
if _ll1IIIlIl1Il1IIlll1IIllIl1111ll = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.url <> invalid then _ll1IIIlIl1Il1IIlll1IIllIl1111ll = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.url
if _ll1IIIlIl1Il1IIlll1IIllIl1111ll = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.src <> invalid then _ll1IIIlIl1Il1IIlll1IIllIl1111ll = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.src
if _ll1IIIlIl1Il1IIlll1IIllIl1111ll = "" then continue for
_llIIlllI1l11lI111IIII1IIl111lIII1IllllI = (Chr(101) + Chr(110))
if _ll1IIlIII111II1llllI1I11lII11lll111l1ll.language <> invalid then _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = LCase(Left(_ll1IIlIII111II1llllI1I11lII11lll111l1ll.language, 2))
if _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.lang <> invalid then _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = LCase(Left(_ll1IIlIII111II1llllI1I11lII11lll111l1ll.lang, 2))
if _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.label <> invalid then _llIIlllI1l11lI111IIII1IIl111lIII1IllllI = LCase(Left(_ll1IIlIII111II1llllI1I11lII11lll111l1ll.label, 2))
_llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = ""
if _ll1IIlIII111II1llllI1I11lII11lll111l1ll.label <> invalid then _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.label
if _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = "" and _ll1IIlIII111II1llllI1I11lII11lll111l1ll.language <> invalid then _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = _ll1IIlIII111II1llllI1I11lII11lll111l1ll.language
if _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = "" then _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6846ce56ffb421f2a050")
_llIlIl1l1I1IlllIlIIl11Il11I11II.Push({ url: _ll1IIIlIl1Il1IIlll1IIllIl1111ll, language: _llIIlllI1l11lI111IIII1IIl111lIII1IllllI, name: _llIIlI1111Illl1lIllI1lII111lII1IllI1I1I })
end for
end if
return {
url: _ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il
streamFormat: U_StreamFormat(_ll111lIllllI1Il1l1Il1l1l11IllIl11IIIllI11Il)
qualities: []
subtitles: _llIlIl1l1I1IlllIlIIl11Il11I11II
chapters: []
referer: _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il
userAgent: ""
}
end for
return invalid
end function
function RP_AsStreamString(_lll1I11l1Il1llllI11llI111lIlI1l as Dynamic) as String
if _lll1I11l1Il1llllI11llI111lIlI1l = invalid then return ""
if type(_lll1I11l1Il1llllI11llI111lIlI1l) = _llllIllII1II1I1ll1lll1lIlIII11I("289a4db206fb70") or type(_lll1I11l1Il1llllI11llI111lIlI1l) = _llllIllII1II1I1ll1lll1lIlIII11I("3a0b4103fa1fb56adf") then return _lll1I11l1Il1llllI11llI111lIlI1l
if type(_lll1I11l1Il1llllI11llI111lIlI1l) = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2f90a889999cb2ad") then
if _lll1I11l1Il1llllI11llI111lIlI1l.Count() = 0 then return ""
_llllI1lI1ll11l1lI1IlIll1II1lI11 = _lll1I11l1Il1llllI11llI111lIlI1l[0]
if type(_llllI1lI1ll11l1lI1IlIll1II1lI11) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5638fe67f383f3") or type(_llllI1lI1ll11l1lI1IlIll1II1lI11) = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("765561ce1756802b51") then return _llllI1lI1ll11l1lI1IlIll1II1lI11
if type(_llllI1lI1ll11l1lI1IlIll1II1lI11) = _llllIllII1II1I1ll1lll1lIlIII11I("7e25db422429ef34d95eb2e89cb2796b70860a") then
if _llllI1lI1ll11l1lI1IlIll1II1lI11.file <> invalid then return _llllI1lI1ll11l1lI1IlIll1II1lI11.file
if _llllI1lI1ll11l1lI1IlIll1II1lI11.url <> invalid then return _llllI1lI1ll11l1lI1IlIll1II1lI11.url
end if
end if
return ""
end function
function RP_ResolveAirflix(_lll1lIl1IlIlI1lIl1111Il11l1lll1 as String, _ll11l111I1I1lllll1II1lIIIIlIIlI111llII1 as String, _lll1Illl1IIl1llI11l1I1lllI1I11I1IlI1lll as Object) as Object
_llIll11IIl11III111II11l1lI1I11l = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6d3136dac7b47740"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("41712a352d3335837f474c364c4b4540459ba4a04f527d68b2668974bebfc1bbb9d1cda48fd9dae3dfb6a1ebecefe8"), Chr(105))
m = _llIll11IIl11III111II11l1lI1I11l.match(_lll1lIl1IlIlI1lIl1111Il11l1lll1)
if m = invalid or m.Count() < 3 then return invalid
_llIl1l1I1IlII1l1l1IlI1IIll1IIlI = m[1]
_ll1IlllII1111lI1lI111lIllIl111Il1l1l11IIl1I = m[2]
_lll11lll1lIllIll1I11lIlllIllIlIl1lll1lllII1 = ""
_lllII1lII1IlIIIIIIll1II1ll1Illl = ""
if m.Count() >= 5 then
_lll11lll1lIllIll1I11lIlllIllIlIl1lll1lllII1 = m[3]
_lllII1lII1IlIIIIIIll1II1ll1Illl = m[4]
end if
_llI1I1lIl1llI1IIIIlIl11Il111lIl111IIl1llIl1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5e96908c8d")
if Left(_ll1IlllII1111lI1lI111lIllIl111Il1l1l11IIl1I, 2) = (Chr(116) + Chr(116)) then _llI1I1lIl1llI1IIIIlIl11Il111lIl111IIl1llIl1 = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("54649320d3")
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _llllIllII1II1I1ll1lll1lIlIII11I("4522686db2a720f4f9bb90b5a9ee33a8fdb30720a2160c5025abef054d0f046c4d43d77052d65c95") + _llI1I1lIl1llI1IIIIlIl11Il111lIl111IIl1llIl1 + Chr(61) + U_UrlEncode(_ll1IlllII1111lI1lI111lIllIl111Il1l1l11IIl1I) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("57c7ba419b958b") + _llIl1l1I1IlII1l1l1IlI1IIll1IIlI
if _llIl1l1I1IlII1l1l1IlI1IIll1IIlI = (Chr(116) + Chr(118)) and _lll11lll1lIllIll1I11lIlllIllIlIl1lll1lllII1 <> "" and _lllII1lII1IlIIIIIIll1II1ll1Illl <> "" then
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _lllI1l1l1I1lIIlI1llI1I111IlI111 + _llIIlIll1llIlII1lI1lIlI1l1lI111("590abb3661dc878a2f") + _lll11lll1lIllIll1I11lIlllIllIlIl1lll1lllII1 + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7e193a0538161b140145") + _lllII1lII1IlIIIIIIll1II1ll1Illl
end if
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = _llllIllII1II1I1ll1lll1lIlIII11I("35b9fd02473cad83888136ea2f254a9f74c9be62583db2878b41a6d7b0f51afb")
_llIlllllll1lllll1l1I1II1I11IIlIIlIl11l1 = HC_Get(_lll1Illl1IIl1llI11l1I1lllI1I11I1IlI1lll, _lllI1l1l1I1lIIlI1llI1I111IlI111, {
"Referer": _ll1lIIII11l1Ill1lIII111lIIIlIl1111l
"Origin": _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("32702ddc6efe1cb2fa73e81fed7089624b71e91f6bb0c9e0ccb26831ab7108")
}, 8000)
if _llIlllllll1lllll1l1I1II1I11IIlIIlIl11l1 = invalid or _llIlllllll1lllll1l1I1II1I11IIlIIlIl11l1.body = "" then return invalid
_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = ParseJSON(_llIlllllll1lllll1l1I1II1I11IIlIIlIl11l1.body)
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = invalid or type(_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3bd2b66e5b53f505e75578e45914ff001894ba") then return invalid
_ll11I1lllIIIlllIIIIIII1I1IIlllIl1II = ""
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.status_code <> invalid then _ll11I1lllIIIlllIIIIIII1I1IIlllIl1II = _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.status_code.ToStr()
if _ll11I1lllIIIlllIIIIIII1I1IIlllIl1II <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5c327a22") then return invalid
_llI11IIIlIII111IIl111I1IIIl11llIl11Illl = _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.data
if _llI11IIIlIII111IIl111I1IIIl11llIl11Illl = invalid or type(_llI11IIIlIII111IIl111I1IIIl11llIl11Illl) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("737060897a7d6c73707b9179958baa9a9d939e") then return invalid
_llIllIlIIIIll1l11lIlI1111l11lll = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.stream_urls
if _llIllIlIIIIll1l11lIlI1111l11lll = invalid or type(_llIllIlIIIIll1l11lIlI1111l11lll) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("76fd6cda44d368c2") or _llIllIlIIIIll1l11lIlI1111l11lll.Count() = 0 then return invalid
_ll1llIllII11I1lI1III1llll1l1Il1l1I1lI1IlI1l = []
_ll1ll11l1l1II1l1l111111II1lll1lIl11Illl = {}
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = []
_ll1ll1I1l1lIIlllIII1l1IlIllllII11lIlll1 = [_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.subs, _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.subs, _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl.default_subs, _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.default_subs]
for each _llIIlII1111Ill111Il1II1lIIII1lIl11I1I1III1l in _ll1ll1I1l1lIIlllIII1l1IlIllllII11lIlll1
if _llIIlII1111Ill111Il1II1lIIII1lIl11I1I1III1l = invalid or type(_llIIlII1111Ill111Il1II1lIIII1lIl11I1I1III1l) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2ee0a1a3648f2df0") then continue for
for each _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1 in _llIIlII1111Ill111Il1II1lIIII1lIl11I1I1III1l
if type(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("60d0bee7d8dbcad1ced9f1d7f5e908fafdf1fc") then continue for
_llI1I11l1lIIl11lllll1Il1l1lIllI = ""
if _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.url <> invalid then _llI1I11l1lIIl11lllll1Il1l1lIllI = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.url
if _llI1I11l1lIIl11lllll1Il1l1lIllI = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.file <> invalid then _llI1I11l1lIIl11lllll1Il1l1lIllI = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.file
if _llI1I11l1lIIl11lllll1Il1l1lIllI = "" then continue for
if _ll1ll11l1l1II1l1l111111II1lll1lIl11Illl.DoesExist(_llI1I11l1lIIl11lllll1Il1l1lIllI) then continue for
_ll1ll11l1l1II1l1l111111II1lll1lIl11Illl[_llI1I11l1lIIl11lllll1Il1l1lIllI] = true
_ll111IlIlll1lI1l1ll11l11I1I1lII = ""
if _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.code <> invalid then _ll111IlIlll1lI1l1ll11l11I1I1lII = LCase(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.code)
if _ll111IlIlll1lI1l1ll11l11I1I1lII = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.language <> invalid then _ll111IlIlll1lI1l1ll11l11I1I1lII = LCase(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.language)
if _ll111IlIlll1lI1l1ll11l11I1I1lII = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang <> invalid and Len(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang) >= 2 then _ll111IlIlll1lI1l1ll11l11I1I1lII = LCase(Left(_lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang, 2))
if _ll111IlIlll1lI1l1ll11l11I1I1lII = "" then _ll111IlIlll1lI1l1ll11l11I1I1lII = (Chr(101) + Chr(110))
_lll1I1llIlll1I1l111llll111lll1lIl1l11II = ""
if _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.label <> invalid then _lll1I1llIlll1I1l111llll111lll1lIl1l11II = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.label
if _lll1I1llIlll1I1l111llll111lll1lIl1l11II = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang <> invalid then _lll1I1llIlll1I1l111llll111lll1lIl1l11II = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.lang
if _lll1I1llIlll1I1l111llll111lll1lIl1l11II = "" and _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.language <> invalid then _lll1I1llIlll1I1l111llll111lll1lIl1l11II = _lll1lIIlIl1IIl1III1l1l1IllIlllIll11III1.language
if _lll1I1llIlll1I1l111llll111lll1lIl1l11II = "" then _lll1I1llIlll1I1l111llll111lll1lIl1l11II = UCase(_ll111IlIlll1lI1l1ll11l11I1I1lII)
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l.Push({ url: _llI1I11l1lIIl11lllll1Il1l1lIllI, language: _ll111IlIlll1lI1l1ll11l11I1I1lII, name: _lll1I1llIlll1I1l111llll111lll1lIl1l11II })
end for
end for
for each _lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll in _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
if _lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll.language = (Chr(101) + Chr(110)) then _ll1llIllII11I1lI1III1llll1l1Il1l1I1lI1IlI1l.Push(_lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll)
end for
for each _lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll in _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
if _lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll.language <> (Chr(101) + Chr(110)) then _ll1llIllII11I1lI1III1llll1l1Il1l1I1lI1IlI1l.Push(_lllI1llI111lll1I1lllIll1lI1Illl1lIIIlIIl1ll)
end for
for each _lllIIlIIl1IIIIII1IIl11Il1IIlIII in _llIllIlIIIIll1l11lIlI1111l11lll
if type(_lllIIlIIl1IIIIII1IIl11Il1IIlIII) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("67c37e848ea1b1") and type(_lllIIlIIl1IIIIII1IIl11Il1IIlIII) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3f1858ae4bbfc58e66") then continue for
if _lllIIlIIl1IIIIII1IIl11Il1IIlIII = "" then continue for
_llIIIllllI11I1llI11lII11II11l1I = HC_Get(_lll1Illl1IIl1llI11l1I1lllI1I11I1IlI1lll, _lllIIlIIl1IIIIII1IIl11Il1IIlIII, { "Referer": _ll1lIIII11l1Ill1lIII111lIIIlIl1111l }, 6000)
if _llIIIllllI11I1llI11lII11II11l1I = invalid or _llIIIllllI11I1llI11lII11II11l1I.body = "" then continue for
if Left(_llIIIllllI11I1llI11lII11II11l1I.body, 7) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("21e1e43361f394b7") then continue for
return {
url: _lllIIlIIl1IIIIII1IIl11Il1IIlIII
streamFormat: _llIIlIll1llIlII1lI1lIlI1l1lI111("69eed93c")
qualities: []
subtitles: _ll1llIllII11I1lI1III1llll1l1Il1l1I1lI1IlI1l
chapters: []
referer: _ll1lIIII11l1Ill1lIII111lIIIlIl1111l
userAgent: ""
}
end for
return invalid
end function
function RP_HlsLeadSkip(_llIIIll1lI1II1l1I1I1IIIII1II1lI as Object, _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 as String, _ll1llIl11ll1l1lllIl1l1I11ll1llI as String, _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 as String) as Integer
if _ll1llIl11ll1l1lllIl1l1I11ll1llI = "" then return 0
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11
_lll1IllIIII1lll11l1l1IllIlllII1l1I111ll = _ll1llIl11ll1l1lllIl1l1I11ll1llI
if _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = "" then
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = HC_Get(_llIIIll1lI1II1l1I1I1IIIII1II1lI, _lll1IllIIII1lll11l1l1IllIlllII1l1I111ll, { "Referer": _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 }, 5000)
if _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = invalid or _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI.body = "" then return 0
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI.body
end if
if Left(_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill, 7) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("560fed608bcec6a4") then return 0
if Instr(1, _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill, _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5e0422b26e83be61c9b9dba9567dda2f90a1")) <= 0 then
return RP_ProbeMediaPlaylist(_llIIIll1lI1II1l1I1I1IIIII1II1lI, _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill, _lll1IllIIII1lll11l1l1IllIlllII1l1I111ll, _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1)
end if
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = 0
for each line in _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.Tokenize(Chr(10))
_lll11IIl1lIl11lI111I11lllIl1I11 = U_Trim(line)
if _lll11IIl1lIl11lI111I11lllIl1I11 = "" then continue for
if Left(_lll11IIl1lIl11lI111I11lllIl1I11, 1) = Chr(35) then continue for
_llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI = U_AbsUrl(_lll11IIl1lIl11lI111I11lllIl1I11, HC_OriginOf(_lll1IllIIII1lll11l1l1IllIlllII1l1I111ll))
if _llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI = "" then continue for
_lllI11lll11I1lIlIIl11llIllIII111Ill = HC_Get(_llIIIll1lI1II1l1I1I1IIIII1II1lI, _llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI, { "Referer": _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 }, 5000)
if _lllI11lll11I1lIlIIl11llIllIII111Ill <> invalid and _lllI11lll11I1lIlIIl11llIllIII111Ill.body <> "" and Left(_lllI11lll11I1lIlIIl11llIllIII111Ill.body, 7) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("334f43f003af41fd") then
_lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 = RP_ProbeMediaPlaylist(_llIIIll1lI1II1l1I1I1IIIII1II1lI, _lllI11lll11I1lIlIIl11llIllIII111Ill.body, _llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI, _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1)
if _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 > 0 then return _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1
end if
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I + 1
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I >= 8 then exit for
end for
return 0
end function
function RP_ProbeMediaPlaylist(_ll1IlI11II1Il1ll1Ill1ll1lIIIlII as Object, _ll1lllIIlll11l1IlIlIlI1I11lIl1lI111 as String, _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1 as String, _ll11lII1l11l1111lIllI11lIll11I11lllI1Il as String) as Integer
_llIIII1I1lII1IIIIIII111l1lI1l1I = 0.0
_ll1lIl1l1llllIII1l1llII1I1III1I = ""
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII = 0.0
_llI1111l1I1l11I1lIl1lllII1III1l1llll1ll = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("41675dcdaa59f94f"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("4f486a56d6628a905d4a678d51ee429651c9"), Chr(105))
for each line in _ll1lllIIlll11l1IlIlIlI1I11lIl1lI111.Tokenize(Chr(10))
_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl = U_Trim(line)
if _llII1Illl1IlI1lI11IlIII1lIlll1I1lIl = "" then continue for
if Left(_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl, 1) = Chr(35) then
_ll11lIl11l1ll1Ill1II1IllIlIllII = _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll.match(_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl)
if _ll11lIl11l1ll1Ill1II1IllIlIllII <> invalid and _ll11lIl11l1ll1Ill1II1IllIlIllII.Count() >= 2 then _ll111111lI1Il11lII111lllllIII1lIlI11II1lIII = Val(_ll11lIl11l1ll1Ill1II1IllIlIllII[1])
continue for
end if
_ll1lIl1l1llllIII1l1llII1I1III1I = U_AbsUrl(_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl, HC_OriginOf(_lllII1Il1lIIlllIlIll1llIllI1I1I1lI1))
_llIIII1I1lII1IIIIIII111l1lI1l1I = _ll111111lI1Il11lII111lllllIII1lIlI11II1lIII
exit for
end for
if _ll1lIl1l1llllIII1l1llII1I1III1I = "" then return 0
_llIIII1III11l1I1111Il1lIlI1IIlI11lI = HC_GetRange(_ll1IlI11II1Il1ll1Ill1ll1lIIIlII, _ll1lIl1l1llllIII1l1llII1I1III1I, { "Referer": _ll11lII1l11l1111lIllI11lIll11I11lllI1Il }, _llllIllII1II1I1ll1lll1lIlIII11I("747fd5aa9e84257a2e74"), 5000)
if _llIIII1III11l1I1111Il1lIlI1IIlI11lI = invalid then return 0
if _llIIII1III11l1I1111Il1lIlI1IIlI11lI.status <= 0 then return 0
if Len(_llIIII1III11l1I1111Il1lIlI1IIlI11lI.body) > 0 then return 0
_llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl = Int(_llIIII1I1lII1IIIIIII111l1lI1l1I + 0.999) + 2
if _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl < 4 then _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl = 8
if _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl > 30 then _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl = 30
print _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("39ee4cd4e2522bf58bf4fa06079798be8479de6dac409ecb9ebb6d8c95e8d35d076f82365f31f12f4f5929aff63fccaa"); _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl
return _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl
end function
function RP_VidrockEncrypt(_llll111lllllI111l1lllII11lllIlI as String, _llIIl1II11lIlIlIlI1II1IIll11lll11l1l1IIIIll as String, _ll1lIIIllllll1l11l1lIlI11l1l1l1IIll11Il as String) as String
_llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("2a10e30ce1f1e06cfb5beb08"))
_lllllI1I1IIIl1Il1I11ll1l1ll111II1ll1lll1IIl = _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1.Setup(true, _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("765a79ea2fe5ddc46a0053a2"), _llIIl1II11lIlIlIlI1II1IIll11lll11l1l1IIIIll, _ll1lIIIllllll1l11l1lIlI11l1l1l1IIll11Il, 1)
if _lllllI1I1IIIl1Il1I11ll1l1ll111II1ll1lll1IIl <> 0 then return ""
_lllI1111II1lIIll1llIl11Il1111IlI111IIlI = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6fc775e355e77bca53c347a2"))
_lllI1111II1lIIll1llIl11Il1111IlI111IIlI.FromAsciiString(_llll111lllllI111l1lllII11lllIlI)
_ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6994a4ca94a2b6d5a9acbea9"))
_ll11Illl11I1llllII1l11IIlll1l11lIllIIIl = _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1.Process(_lllI1111II1lIIll1llIl11Il1111IlI111IIlI)
if _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl <> invalid then
for _lllII1ll1ll1l1l1llI1IlIIlIlIllIlII1lII11l1I = 0 to _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl.Count() - 1
_ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il.Push(_ll11Illl11I1llllII1l11IIlll1l11lIllIIIl[_lllII1ll1ll1l1l1llI1IlIIlIlIllIlII1lII11l1I])
end for
end if
_llIl1lII11llllIll1Ill11lI1I11lllI11 = _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1.Final()
if _llIl1lII11llllIll1Ill11lI1I11lllI11 <> invalid then
for _lllII1ll1ll1l1l1llI1IlIIlIlIllIlII1lII11l1I = 0 to _llIl1lII11llllIll1Ill11lI1I11lllI11.Count() - 1
_ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il.Push(_llIl1lII11llllIll1Ill11lI1I11lllI11[_lllII1ll1ll1l1l1llI1IlIIlIlIllIlII1lII11l1I])
end for
end if
if _ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il.Count() = 0 then return ""
_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _ll1l11ll1lllllI1IIII1ll1I11lI1111ll11Il.ToBase64String()
_ll1Il1IlI1I11I1ll1IlI1I1ll1llIl1l1I1II1lIIl = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7e4d647948727566"), (Chr(92) + Chr(43)), "")
_llIlll1l111lIIl111lI111Il11IIlI = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7670b4db01bbf21f"), Chr(47), "")
_ll1IlIl1ll1lIllI11l1l11l1llII1l = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("3e691f75c9aed327"), _llIIlIll1llIlII1lI1lIlI1l1lI111("58a90407"), "")
_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1 = _ll1Il1IlI1I11I1ll1IlI1I1ll1llIl1l1I1II1lIIl.ReplaceAll(_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1, Chr(45))
_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1 = _llIlll1l111lIIl111lI111Il11IIlI.ReplaceAll(_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1, Chr(95))
_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1 = _ll1IlIl1ll1lIllI11l1l11l1llII1l.ReplaceAll(_llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1, "")
return _llIlIIIlI1l1Il11lIl1l1III1IlIIlI11lll11I1I1
end function
function RP_ResolveVidrock(_llI11II111lIIll111II11l11II1Il1lI1ll1lI as String, _lll111lIllI1I1III1I1lI1l11Il1Il as String, _llII11IlllI1llI11II1111l1ll11IlIlIl as Object) as Object
_llII11l1111l1ll111l1l1l1111I1111Ill1lllll1I = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("737060967071767c"), _llllIllII1II1I1ll1lll1lIlIII11I("26f6ebffd4a62b60b5ca23082c225338cc22e77b00e53f64599b1f38a82d32b93d567b90a479afa4e66a83a8cdc20488a1c6cbef"), Chr(105))
m = _llII11l1111l1ll111l1l1l1111I1111Ill1lllll1I.match(_llI11II111lIIll111II11l11II1Il1lI1ll1lI)
if m = invalid or m.Count() < 3 then return invalid
_lllI1llIlIIlIIIIIIl1lllII1111l1 = m[1]
_llI111l111lII1lIIIlIl1II1Il1ll1 = m[2]
_ll1II1llIIlIl1IlIlIIIlI11IIIllI = ""
_llIIllllllIII1lIIIII1l1Il1IlIIl = ""
if m.Count() >= 5 then
_ll1II1llIIlIl1IlIlIIIlI11IIIllI = m[3]
_llIIllllllIII1lIIIII1l1Il1IlIIl = m[4]
end if
_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII = _llIIlIll1llIlII1lI1lIlI1l1lI111("2ce38e99c4b788ebf6cb3e710c2f9a65564336")
if _lllI1llIlIIlIIIIIIl1lllII1111l1 = (Chr(116) + Chr(118)) and _ll1II1llIIlIl1IlIlIIIlI11IIIllI <> "" and _llIIllllllIII1lIIIII1l1Il1IlIIl <> "" then
_llIl1IllI11II1llI11IlllI1ll11llIlIl = _llI111l111lII1lIIIlIl1II1Il1ll1 + Chr(95) + _ll1II1llIIlIl1IlIlIIIlI11IIIllI + Chr(95) + _llIIllllllIII1lIIIII1l1Il1IlIIl
else
_llIl1IllI11II1llI11IlllI1ll11llIlIl = _llI111l111lII1lIIIlIl1II1Il1ll1
end if
_llI11111I1lllI11I1l11I1lIlll1I1IlI11l1l = _llllIllII1II1I1ll1lll1lIlIII11I("427c71c68ba0e0da7fb4d4ce23b81de2f70c21d62b00e5eaff14d93ef3086842775c41367b60757a7f54647e63986d72579cccb6cb90c0badad4c9aeced8c8f297")
_ll1lI1III1llIIl1II1lIIllII1I1Ill11I  = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2dd664a7497aea0c4b27f73979f4fce6e79091e3239d6748497a61744b47560999")
_llIlllII1lIl1l1I1l1111llI11lI11lIll = RP_VidrockEncrypt(_llIl1IllI11II1llI11IlllI1ll11llIlIl, _llI11111I1lllI11I1l11I1lIlll1I1IlI11l1l, _ll1lI1III1llIIl1II1lIIllII1I1Ill11I)
if _llIlllII1lIl1l1I1l1111llI11lI11lIll = "" then return invalid
if _lllI1llIlIIlIIIIIIl1lllII1111l1 = (Chr(116) + Chr(118)) and _ll1II1llIIlIl1IlIlIIIlI11IIIllI <> "" and _llIIllllllIII1lIIIII1l1Il1IlIIl <> "" then
_lll1l1lIlIllIII1l1l1lIIllI1lII1 = _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7c78c91b9823571e9f") + _llIlllII1lIl1l1I1l1111llI11lI11lIll
else
_lll1l1lIlIllIII1l1l1lIIllI1lII1 = _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("57d1686a398a04dc5cca7eb5") + _llIlllII1lIl1l1I1l1111llI11lI11lIll
end if
_llI111ll1lIlII1lllIIIlII1Il11IIlll1II11 = {
"Referer": _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII + Chr(47) + _lllI1llIlIIlIIIIIIl1lllII1111l1 + Chr(47) + _llI111l111lII1lIIIlIl1II1Il1ll1
"Origin": _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII
"Accept": _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3be8fc8a9e8c7ae0b7d0d9de8bcd270a0b8d18f85a6e77cc6b4f923a6a9f6bd24380")
"User-Agent": _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("488a1a2fba915a0369bcaade49a355c339d399efbe22d0d5aa3dad504dff0b5779512f9dcda05e5d2f4228e87caf9ac0e410dae83b2c0b9f6ebf299ece22084920c690a989a258017a522b69b9105a436ac090227c529a816a3d2ddcca3d891fa9ffabd7ba111a4efbc06f1d0e204f1e")
}
_ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1 = HC_Get(_llII11IlllI1llI11II1111l1ll11IlIlIl, _lll1l1lIlIllIII1l1l1lIIllI1lII1, _llI111ll1lIlII1lllIIIlII1Il11IIlll1II11, 8000)
if _ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1 = invalid or _ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1.body = "" then return invalid
_llI1lIllIlllI11II1l1IllIllI1lII = ParseJSON(_ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1.body)
if _llI1lIllIlllI11II1l1IllIllI1lII = invalid or type(_llI1lIllIlllI11II1l1IllIllI1lII) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4eecada328730890daa21e5ee84e6e2f76d44b") then
_llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I = RP_TryBase64Decode(U_Trim(_ll11ll1ll1l1IIII1lll1l1I1l1l1lllII1.body))
if _llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I <> "" then _llI1lIllIlllI11II1l1IllIllI1lII = ParseJSON(_llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I)
if _llI1lIllIlllI11II1l1IllIllI1lII = invalid or type(_llI1lIllIlllI11II1l1IllIllI1lII) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6b141d70cc1bbaeac87c342cd642ae42f3064e") then return invalid
end if
_lllIl11llIIllII1lII1lIlll111lI1IIllllII1llI = []
RP_WalkForStreams(_llI1lIllIlllI11II1l1IllIllI1lII, _lllIl11llIIllII1lII1lIlll111lI1IIllllII1llI)
if _lllIl11llIIllII1lII1lIlll111lI1IIllllII1llI.Count() = 0 then return invalid
_llI1IlII1l11ll1IlI11lI11ll1l1I1 = []
_lllI1I1ll1llIII11lI1IIlIlllIl11 = invalid
if _llI1lIllIlllI11II1l1IllIllI1lII.subtitle <> invalid then _lllI1I1ll1llIII11lI1IIlIlllIl11 = _llI1lIllIlllI11II1l1IllIllI1lII.subtitle
if _lllI1I1ll1llIII11lI1IIlIlllIl11 = invalid and _llI1lIllIlllI11II1l1IllIllI1lII.subtitles <> invalid then _lllI1I1ll1llIII11lI1IIlIlllIl11 = _llI1lIllIlllI11II1l1IllIllI1lII.subtitles
if _lllI1I1ll1llIII11lI1IIlIlllIl11 = invalid and _llI1lIllIlllI11II1l1IllIllI1lII.captions <> invalid then _lllI1I1ll1llIII11lI1IIlIlllIl11 = _llI1lIllIlllI11II1l1IllIllI1lII.captions
if _lllI1I1ll1llIII11lI1IIlIlllIl11 <> invalid and type(_lllI1I1ll1llIII11lI1IIlIlllIl11) = _llIIlIll1llIlII1lI1lIlI1l1lI111("352fa2dc505bfe49") then
for each _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1 in _lllI1I1ll1llIII11lI1IIlIlllIl11
if type(_llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1) <> _llllIllII1II1I1ll1lll1lIlIII11I("4ceda3c6ecf1b7fc61e63a70643afd33380e92") then continue for
_lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = ""
if _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.file <> invalid then _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.file
if _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = "" and _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.url <> invalid then _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.url
if _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I = "" then continue for
_llIIl1Ill1I1lllI1II111ll1IIII1lI1Il = (Chr(101) + Chr(110))
if _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.language <> invalid then _llIIl1Ill1I1lllI1II111ll1IIII1lI1Il = LCase(Left(_llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.language, 2))
if _llIIl1Ill1I1lllI1II111ll1IIII1lI1Il = "" and _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.lang <> invalid then _llIIl1Ill1I1lllI1II111ll1IIII1lI1Il = LCase(Left(_llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.lang, 2))
_ll1lIll1111IlIlll111I11llIll1II = ""
if _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.label <> invalid then _ll1lIll1111IlIlll111I11llIll1II = _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.label
if _ll1lIll1111IlIlll111I11llIll1II = "" and _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.language <> invalid then _ll1lIll1111IlIlll111I11llIll1II = _llIIl1l1ll1IllI11lIIII1lI111lI1ll1IIIl1.language
if _ll1lIll1111IlIlll111I11llIll1II = "" then _ll1lIll1111IlIlll111I11llIll1II = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("75f654e859fc7bed69f2")
_llI1IlII1l11ll1IlI11lI11ll1l1I1.Push({ url: _lllIllIlI1lIII11ll1l11I1II11llIlI1Ill1I, language: _llIIl1Ill1I1lllI1II111ll1IIII1lI1Il, name: _ll1lIll1111IlIlll111I11llIll1II })
end for
end if
_lllIIIll1lI11ll111l1I1l11lIIl11Il1l = _lllIl11llIIllII1lII1lIlll111lI1IIllllII1llI[0]
return {
url: _lllIIIll1lI11ll111l1I1l11lIIl11Il1l
streamFormat: U_StreamFormat(_lllIIIll1lI11ll111l1I1l11lIIl11Il1l)
qualities: []
subtitles: _llI1IlII1l11ll1IlI11lI11ll1l1I1
chapters: []
referer: _llI11II111lIIll111II11l11II1Il1lI1ll1lI
userAgent: ""
}
end function
sub RP_WalkForStreams(_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl as Dynamic, _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 as Object)
if _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = invalid or _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = invalid then return
_llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 = type(_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl)
if _llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("49ff53d87ad159d448d55ab14ebb65b16ebb71") then
for each _llll1IIlllIlllIlI1Illl1ll1Il11I111l in _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl
_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl[_llll1IIlllIlllIlI1Illl1ll1Il11I111l]
if _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = invalid then continue for
_llIIllIIIIIlI111llll1IlI11lI1lI = type(_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI)
if _llIIllIIIIIlI111llll1IlI11lI1lI = _llIIlIll1llIlII1lI1lIlI1l1lI111("2e76589346490c") or _llIIllIIIIIlI111llll1IlI11lI1lI = _llllIllII1II1I1ll1lll1lIlIII11I("2b73c78b2287fbd065") then
if Instr(1, _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI, _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("585d1c0a414e")) > 0 or Instr(1, _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI, _llllIllII1II1I1ll1lll1lIlIII11I("7dd708bc85")) > 0 then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1.Push(_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI)
else if _llIIllIIIIIlI111llll1IlI11lI1lI = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5bdaac75425a0f3eed5e73fc401fc579219eb0") or _llIIllIIIIIlI111llll1IlI11lI1lI = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("77da4cb521d9ae79") then
RP_WalkForStreams(_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI, _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1)
end if
end for
else if _llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 = _llllIllII1II1I1ll1lll1lIlIII11I("324d836a5c6177fb") then
for each _llll1II1IllII1IllIllI1l1111IlI1II1I in _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl
if _llll1II1IllII1IllIllI1l1111IlI1II1I = invalid then continue for
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = type(_llll1II1IllII1IllIllI1l1111IlI1II1I)
if _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llllIllII1II1I1ll1lll1lIlIII11I("4fbacdb2287d12") or _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("2baf319a0d95299b3b") then
if Instr(1, _llll1II1IllII1IllIllI1l1111IlI1II1I, _llIIlIll1llIlII1lI1lIlI1l1lI111("39698ee7e445")) > 0 or Instr(1, _llll1II1IllII1IllIllI1l1111IlI1II1I, _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("462102355d")) > 0 then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1.Push(_llll1II1IllII1IllIllI1l1111IlI1II1I)
else if _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("597f43586a51495458554a315e3b75317e3b61") or _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("7c59a77f72db87b8") then
RP_WalkForStreams(_llll1II1IllII1IllIllI1l1111IlI1II1I, _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1)
end if
end for
end if
end sub
function RP_TryBase64Decode(_lllIII1IIl11Ill111lIll1l1lIlIll1ll1 as String) as String
if _lllIII1IIl11Ill111lIll1l1lIlIll1ll1 = invalid or _lllIII1IIl11Ill111lIll1l1lIlIll1ll1 = "" then return ""
_llIlI1II11ll1II1I111ll11l1l11111lI1 = _lllIII1IIl11Ill111lIll1l1lIlIll1ll1
_llI1l11llI1lII11Il11lIII1l1l1ll = Len(_llIlI1II11ll1II1I111ll11l1l11111lI1) mod 4
if _llI1l11llI1lII11Il11lIII1l1l1ll = 1 then return ""
if _llI1l11llI1lII11Il11lIII1l1l1ll = 2 then _llIlI1II11ll1II1I111ll11l1l11111lI1 = _llIlI1II11ll1II1I111ll11l1l11111lI1 + (Chr(61) + Chr(61))
if _llI1l11llI1lII11Il11lIII1l1l1ll = 3 then _llIlI1II11ll1II1I111ll11l1l11111lI1 = _llIlI1II11ll1II1I111ll11l1l11111lI1 + Chr(61)
_llIl11IIl1IlII1lII1IIllIlllllIl1111IIll = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("2813e4f3c7ff2af4b899ec66"))
_llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.FromBase64String(_llIlI1II11ll1II1I111ll11l1l11111lI1)
return _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.ToAsciiString()
end function
function RP_ResolveXpass(_lll1111IlllII1ll11lllII11I1IIIl11lll11l as String, _lll1Il11llIIlIl11Ill11IIIl11IlIlllllIll as String, _lll11I1I1lllIIlIIllI11I1lIIl1l1 as Object) as Object
_llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll = {}
if _lll1Il11llIIlIl11Ill11IIIl11IlIlllllIll <> "" then _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll[_llIIlIll1llIlII1lI1lIlI1l1lI111("60792d3043a659bc")] = _lll1Il11llIIlIl11Ill11IIIl11IlIlllllIll else _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll[_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("548bbfaf9f71fc01")] = _llIIlIll1llIlII1lI1lIlI1l1lI111("3bed98a3cef1b2253045d87b36b97ca7806d50a9")
_llIlIlIlIl11II11llIllI11I1ll1Il1III = HC_Get(_lll11I1I1lllIIlIIllI11I1lIIl1l1, _lll1111IlllII1ll11lllII11I1IIIl11lll11l, _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll, 8000)
if _llIlIlIlIl11II11llIllI11I1ll1Il1III = invalid or _llIlIlIlIl11II11llIllI11I1ll1Il1III.body = "" then return invalid
_ll11Il1111II1lll1Il1II1I111l1II = _llIlIlIlIl11II11llIllI11I1ll1Il1III.body
_llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il = _llIlIlIlIl11II11llIllI11I1ll1Il1III.finalUrl
if _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il = invalid or _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il = "" then _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il = _lll1111IlllII1ll11lllII11I1IIIl11lll11l
_ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 = []
_llIl11llI1l111l111I1IIII1IIIl1ll11IlIIl = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("27ae545bd74bba78"), chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7592a9a9a4b2baa7a3") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("31b4be2f1be91383") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("5a63f92c") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("760f50bb") + chr(34), Chr(105))
_ll11l1lI1IIllllI1111l1I1Il1I1I1 = _llIl11llI1l111l111I1IIII1IIIl1ll11IlIIl.match(_ll11Il1111II1lll1Il1II1I111l1II)
if _ll11l1lI1IIllllI1111l1I1Il1I1I1 <> invalid and _ll11l1lI1IIllllI1111l1I1Il1I1I1.Count() >= 2 then
_ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1.Push({ label: _llllIllII1II1I1ll1lll1lIlIII11I("23542a4faaaacf450acfe358"), url: RP_AbsUrl(_ll11l1lI1IIllllI1111l1I1Il1I1I1[1], _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il) })
end if
_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII = RP_ParseXpassBackups(_ll11Il1111II1lll1Il1II1I111l1II)
if _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII <> invalid and type(_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII) = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("2d1737301f393328") then
for each _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII in _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII
if type(_ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3e4d246a0d632e663f672d0339091203190906") then continue for
_lll1ll1ll1l1lll1III11III1I1I111Ill11lI1 = _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII.url
if _lll1ll1ll1l1lll1III11III1I1I111Ill11lI1 = invalid or _lll1ll1ll1l1lll1III11III1I1I111Ill11lI1 = "" then continue for
_ll11111l11ll1lIIllIl1I11ll1I1IIIlII = ""
if _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII.name <> invalid then _ll11111l11ll1lIIllIl1I11ll1I1IIIlII = _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII.name
if _ll11111l11ll1lIIllIl1I11ll1I1IIIlII = "" then _ll11111l11ll1lIIllIl1I11ll1I1IIIlII = _llllIllII1II1I1ll1lll1lIlIII11I("6eb9ceb3381ef3")
_ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1.Push({ label: _ll11111l11ll1lIIllIl1I11ll1I1IIIlII, url: RP_AbsUrl(_lll1ll1ll1l1lll1III11III1I1I111Ill11lI1, _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il) })
end for
end if
_llllI1I11l1I1II1Ill11II1IIllII1lII111l1Il11 = {}
_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1 = []
for each _ll1lllllI1llllIlI1II1l1lllI1l11 in _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1
if _ll1lllllI1llllIlI1II1l1lllI1l11.url = "" then continue for
if _llllI1I11l1I1II1Ill11II1IIllII1lII111l1Il11.DoesExist(_ll1lllllI1llllIlI1II1l1lllI1l11.url) then continue for
_llllI1I11l1I1II1Ill11II1IIllII1lII111l1Il11[_ll1lllllI1llllIlI1II1l1lllI1l11.url] = true
_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1.Push(_ll1lllllI1llllIlI1II1l1lllI1l11)
end for
for _llIl1lII11lI1llllIII1l1lI1llIllIIll = 1 to _llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1.Count() - 1
_lll1IIll1l1I1l1IIll1lI11IlIll1l = _llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_llIl1lII11lI1llllIII1l1lI1llIllIIll]
_llIl111IIII1IlllIIlI11III11Il1lIII1 = RP_XpassSrcRank(_lll1IIll1l1I1l1IIll1lI11IlIll1l)
_ll11II1lIII1Il1III1IlllI111lIIl111l = _llIl1lII11lI1llllIII1l1lI1llIllIIll - 1
while _ll11II1lIII1Il1III1IlllI111lIIl111l >= 0
if RP_XpassSrcRank(_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_ll11II1lIII1Il1III1IlllI111lIIl111l]) <= _llIl111IIII1IlllIIlI11III11Il1lIII1 then exit while
_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_ll11II1lIII1Il1III1IlllI111lIIl111l + 1] = _llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_ll11II1lIII1Il1III1IlllI111lIIl111l]
_ll11II1lIII1Il1III1IlllI111lIIl111l = _ll11II1lIII1Il1III1IlllI111lIIl111l - 1
end while
_llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1[_ll11II1lIII1Il1III1IlllI111lIIl111l + 1] = _lll1IIll1l1I1l1IIll1lI11IlIll1l
end for
_ll111IIll1I1I1I1I1IIlII1l11IlIl = RP_FetchXpassSubs(_ll11Il1111II1lll1Il1II1I111l1II, _lll11I1I1lllIIlIIllI11I1lIIl1l1)
for each _ll1lllllI1llllIlI1II1l1lllI1l11 in _llIl1II111111IIl1lII11l1IlI1l11I1lIllIII1l1
_llIIIlI1lIIlIlIIlIIll11l111IlII = _ll1lllllI1llllIlI1II1l1lllI1l11.url
_lllIlllIIIl1lIl1I1llIIll111111l1lIl = HC_Get(_lll11I1I1lllIIlIIllI11I1lIIl1l1, _llIIIlI1lIIlIlIIlIIll11l111IlII, { "Referer": _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il }, 6000)
if _lllIlllIIIl1lIl1I1llIIll111111l1lIl = invalid or _lllIlllIIIl1lIl1I1llIIll111111l1lIl.body = "" then continue for
_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = ParseJSON(_lllIlllIIIl1lIl1I1llIIll111111l1lIl.body)
if _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = invalid or type(_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("70e94c88020d78a37ec97c9f821501838e216c") then continue for
_lllIIl11I1IllI1IIIIl11IIIl1lIll = RP_XpassFirstSource(_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I)
if _lllIIl11I1IllI1IIIIl11IIIl1lIll = "" then continue for
_lllIIl11I1IllI1IIIIl11IIIl1lIll = RP_AbsUrl(_lllIIl11I1IllI1IIIIl11IIIl1lIll, _llIIIlI1lIIlIlIIlIIll11l111IlII)
_llIIIll111lllIIIIlllllIlIll1ll1I11l = HC_Get(_lll11I1I1lllIIlIIllI11I1lIIl1l1, _lllIIl11I1IllI1IIIIl11IIIl1lIll, { "Referer": _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il }, 6000)
if _llIIIll111lllIIIIlllllIlIll1ll1I11l = invalid or _llIIIll111lllIIIIlllllIlIll1ll1I11l.body = "" then continue for
if Left(_llIIIll111lllIIIIlllllIlIll1ll1I11l.body, 7) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("7e2301f49f62dab8") then continue for
return {
url: _lllIIl11I1IllI1IIIIl11IIIl1lIll
streamFormat: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("31f89097")
qualities: []
subtitles: _ll111IIll1I1I1I1I1IIlII1l11IlIl
chapters: []
referer: _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il
userAgent: ""
}
end for
return invalid
end function
function RP_XpassSrcRank(_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 as Object) as Integer
_ll1lllll11llIll11Il111I1IIll1l1 = ""
_llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = ""
if _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.label <> invalid then _ll1lllll11llIll11Il111I1IIll1l1 = UCase(_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.label)
if _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.url <> invalid then _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = LCase(_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.url)
if Instr(1, _ll1lllll11llIll11Il111I1IIll1l1, _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4bdb3e47")) > 0 or Instr(1, _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2a5f82e2b2536754")) > 0 then return 100
if Instr(1, _ll1lllll11llIll11Il111I1IIll1l1, _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2d373c56")) > 0 or Instr(1, _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _llIIlIll1llIlII1lI1lIlI1l1lI111("2404ff521b8ee39c")) > 0 then return 0
if Instr(1, _ll1lllll11llIll11Il111I1IIll1l1, _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6b90e052")) > 0 or Instr(1, _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2c834f4f5b8f")) > 0 then return 1
if Instr(1, _ll1lllll11llIll11Il111I1IIll1l1, _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("49de5bc8")) > 0 or Instr(1, _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _llIIlIll1llIlII1lI1lIlI1l1lI111("768c79ec3fb8")) > 0 then return 2
return 50
end function
function RP_ParseXpassBackups(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI as String) as Object
if _lll111llIIIIlI1lI1Ill1l1lIlllIlIllI = invalid or _lll111llIIIIlI1lI1Ill1l1lIlllIlIllI = "" then return []
_ll11I11IIlII1lI1IlIlI1lIIlI1lIII1I1 = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("34212e15021e3f0a"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("23982db9cb985e7c6f1c2e7b0058c8b93f4b687b7d2049"), Chr(105))
_llIllI11II1llIIIl1I111lllIlI111IllI1IIlll11 = _ll11I11IIlII1lI1IlIlI1lIIlI1lIII1I1.match(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI)
if _llIllI11II1llIIIl1I111lllIlI111IllI1IIlll11 = invalid or _llIllI11II1llIIIl1I111lllIlI111IllI1IIlll11.Count() < 1 then return []
_ll1l1IIIIII1lI1Il11I11II11IIIl1llIl = _llIllI11II1llIIIl1I111lllIlI111IllI1IIlll11[0]
_llII1lII11Ill1I11II1Il1ll1l11Il = Instr(1, _lll111llIIIIlI1lI1Ill1l1lIlllIlIllI, _ll1l1IIIIII1lI1Il11I11II11IIIl1llIl)
if _llII1lII11Ill1I11II1Il1ll1l11Il <= 0 then return []
_lllIIl11I1l11III111l1Il11lII1I1l1II11Il = Instr(_llII1lII11Ill1I11II1Il1ll1l11Il, _lll111llIIIIlI1lI1Ill1l1lIlllIlIllI, Chr(91))
if _lllIIl11I1l11III111l1Il11lII1I1l1II11Il <= 0 then return []
_llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = 0
_lllI11Il11111I11Illl1l111lI11Il1III1Il1l11l = false
_lll1lIIllIllI111IlI1Il1IlI11l1Il11ll1llIllI = ""
_llIIIll1Ill11ll11l1111l1I111l1II1IllIII = false
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = 0
_lllIlI1I1lIlIlIII1l1111IIl1llllIlll = Len(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI)
_llIllI1lIl1IlI111Il1lI1II1111111l1l1lll = chr(92)
_lllll11lIl1ll11llI11II1Ill1l1I1 = chr(34)
_llIll111llll1llIllIl1l11llII11llI11II11IIll = Chr(39)
for _llI1II11ll1lll11Il11I1I1II1Ill1Ill1I1lII1II = _lllIIl11I1l11III111l1Il11lII1I1l1II11Il to _lllIlI1I1lIlIlIII1l1111IIl1llllIlll
_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = Mid(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI, _llI1II11ll1lll11Il11I1I1II1Ill1Ill1I1lII1II, 1)
if _lllI11Il11111I11Illl1l111lI11Il1III1Il1l11l then
if _llIIIll1Ill11ll11l1111l1I111l1II1IllIII then
_llIIIll1Ill11ll11l1111l1I111l1II1IllIII = false
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _llIllI1lIl1IlI111Il1lI1II1111111l1l1lll then
_llIIIll1Ill11ll11l1111l1I111l1II1IllIII = true
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _lll1lIIllIllI111IlI1Il1IlI11l1Il11ll1llIllI then
_lllI11Il11111I11Illl1l111lI11Il1III1Il1l11l = false
end if
else
if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _lllll11lIl1ll11llI11II1Ill1l1I1 or _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _llIll111llll1llIllIl1l11llII11llI11II11IIll then
_lllI11Il11111I11Illl1l111lI11Il1III1Il1l11l = true
_lll1lIIllIllI111IlI1Il1IlI11l1Il11ll1llIllI = _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = Chr(91) then
_llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 + 1
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = Chr(93) then
_llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 - 1
if _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = 0 then
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = _llI1II11ll1lll11Il11I1I1II1Ill1Ill1I1lII1II
exit for
end if
end if
end if
end for
if _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = 0 then return []
_lll1II11ll1l1I1IIl1Il1IlIII1lIl = Mid(_lll111llIIIIlI1lI1Ill1l1lIlllIlIllI, _lllIIl11I1l11III111l1Il11lII1I1l1II11Il, _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll - _lllIIl11I1l11III111l1Il11lII1I1l1II11Il + 1)
_llIII1lIlIIlIIl1IIlIll11lIlI1I1lII1 = ParseJSON(_lll1II11ll1l1I1IIl1Il1IlIII1lIl)
if _llIII1lIlIIlIIl1IIlIll11lIlI1I1lII1 = invalid or type(_llIII1lIlIIlIIl1IIlIll11lIlI1I1lII1) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("6fa41733c5d0539e") then return []
return _llIII1lIlIIlIIl1IIlIll11lIlI1I1lII1
end function
function RP_XpassFirstSource(_ll1I1I11I11lll1l111I1lllIIIl1l111I1 as Object) as String
if _ll1I1I11I11lll1l111I1lllIIIl1l111I1 = invalid or type(_ll1I1I11I11lll1l111I1lllIIIl1l111I1) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("74a16e86478f648a758b67ef73e558ef53e54c") then return ""
_llIlI1IlI111I1lIIl1lIlIIl11ll11l11ll11I = _ll1I1I11I11lll1l111I1lllIIIl1l111I1.playlist
if _llIlI1IlI111I1lIIl1lIlIIl11ll11l11ll11I = invalid or type(_llIlI1IlI111I1lIIl1lIlIIl11ll11l11ll11I) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("651987349cb581d9") then return ""
for each _llIllIlI1l11lI111lIII1l11111l1I in _llIlI1IlI111I1lIIl1lIlIIl11ll11l11ll11I
if type(_llIllIlI1l11lI111lIII1l11111l1I) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("2b4679d56f7aa510cb1679ec9f224ee0eb6eb9") then continue for
_ll1IlllIIlI1IlllIllllII1llIII1l1I1lI1lI = _llIllIlI1l11lI111lIII1l11111l1I.sources
if _ll1IlllIIlI1IlllIllllII1llIII1l1I1lI1lI = invalid or type(_ll1IlllIIlI1IlllIllllII1llIII1l1I1lI1lI) <> _llllIllII1II1I1ll1lll1lIlIII11I("5f23f71a32372bb1") then continue for
for each _lll11llllI1IIIl11lI1111IlIl1Ill1l1lI1l1 in _ll1IlllIIlI1IlllIllllII1llIII1l1I1lI1lI
if type(_lll11llllI1IIIl11lI1111IlIl1Ill1l1lI1l1) <> _llllIllII1II1I1ll1lll1lIlIII11I("2c07bde4060bd1167b00548a7e541b4d5228ac") then continue for
_llIlI1l11IIII1IllIIlllI1I1I11IIIlII = _lll11llllI1IIIl11lI1111IlIl1Ill1l1lI1l1.file
if _llIlI1l11IIII1IllIIlllI1I1I11IIIlII <> invalid and _llIlI1l11IIII1IllIIlllI1I1I11IIIlII <> "" then return _llIlI1l11IIII1IllIIlllI1I1I11IIIlII
end for
end for
return ""
end function
function RP_FetchXpassSubs(_lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II as String, _lllIII1IIIllI1III1llI1lIIIlIlIl11llIlIIIll1 as Object) as Object
_ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI = []
if _lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II = invalid or _lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II = "" then return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
_llIll11l1Il1IlIlIlI11IllIIII1IIIIIIII1I = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("2b46795dbfdad538"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6783779942bf25ee38f0288e3da71dc701bf29ef") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("416a4046") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("3d48688d") + chr(34), Chr(105))
m = _llIll11l1Il1IlIlIlI11IllIIII1IIIIIIII1I.match(_lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II)
if m = invalid or m.Count() < 2 then return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
_lllI1IlI1I1llll1l1Il1lI1lIIIIlIlII111l1lIlI = HC_Get(_lllIII1IIIllI1III1llI1lIIIlIlIl11llIlIIIll1, m[1], invalid, 6000)
if _lllI1IlI1I1llll1l1Il1lI1lIIIIlIlII111l1lIlI = invalid or _lllI1IlI1I1llll1l1Il1lI1lIIIIlIlII111l1lIlI.body = "" then return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I = ParseJSON(_lllI1IlI1I1llll1l1Il1lI1lIIIIlIlII111l1lIlI.body)
if _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I = invalid or type(_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("716bfdb461893ceb") then return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
_llllIIlllllI11I1lIIl11I11I1ll1I11Il = _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I.Count()
if _llllIIlllllI11I1lIIl11I11I1ll1I11Il > 30 then _llllIIlllllI11I1lIIl11I11I1ll1I11Il = 30
for _lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1 = 0 to _llllIIlllllI11I1lIIl11I11I1ll1I11Il - 1
_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1 = _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I[_lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1]
if type(_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1) <> _llllIllII1II1I1ll1lll1lIlIII11I("5c580c33575c2065ca4fa5d9cfa36a9ea377fd") then continue for
_ll1I1lIl1Il111IIlIl1Il1111lIl11IIlI1Ill = _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.url
if _ll1I1lIl1Il111IIlIl1Il1111lIl11IIlI1Ill = invalid or _ll1I1lIl1Il111IIlIl1Il1111lIl11IIlI1Ill = "" then continue for
_lll1IIlIlIllIlII1I11l1I1lIl1Il1lIllI111 = (Chr(101) + Chr(110))
if _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.language <> invalid then _lll1IIlIlIllIlII1I11l1I1lIl1Il1lIllI111 = LCase(_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.language)
_llIl1lI1IIlI111lI1IlI1ll11IIlII = ""
if _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.display <> invalid then _llIl1lI1IIlI111lI1IlI1ll11IIlII = _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.display
if _llIl1lI1IIlI111lI1IlI1ll11IIlII = "" then
if _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.language <> invalid then _llIl1lI1IIlI111lI1IlI1ll11IIlII = UCase(_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.language) else _llIl1lI1IIlI111lI1IlI1ll11IIlII = (Chr(69) + Chr(78))
end if
_ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI.Push({ url: _ll1I1lIl1Il111IIlIl1Il1111lIl11IIlI1Ill, language: _lll1IIlIlIllIlII1I11l1I1lIl1Il1lIllI111, name: _llIl1lI1IIlI111lI1IlI1ll11IIlII })
end for
return _ll1I1l1Il1IIlII1IlIlI11llIlll1IIIIll1lI
end function
function RP_ResolveJwplayerPage(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I as String, _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II as String, _llIll1lII1l1I1Ill1lIII1I111Il1l1l1I as String, _llIl11Illl1llIlI1I11lllI1IIIIIlllllllIlIII1 as Object) as Object
if _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I = invalid or _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I = "" then return invalid
_llI1II1II1Ill1I1I1111IlIIII1l1I = []
RP_JwExtractInto(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I, _llI1II1II1Ill1I1I1111IlIIII1l1I)
_llll1I1I11IIll1I11llllll11I1l111IlIllll = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6b2f711b5d106004"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2f8f211d487ce2eea1baddfc099f8c10863695a8e3a631728c60da8628b981af64faac707960c1bdaddec0fa7e64b7"), Chr(105))
_lll1IIllII11l1ll11l1l1lIl11lII1 = _llll1I1I11IIll1I11llllll11I1l111IlIllll.match(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I)
if _lll1IIllII11l1ll11l1l1lIl11lII1 <> invalid and _lll1IIllII11l1ll11l1l1lIl11lII1.Count() >= 1 then
_llllI1llIIIlIll1IIlIlIl1I111l1I = JU_UnpackPacked(_lll1IIllII11l1ll11l1l1lIl11lII1[0])
if _llllI1llIIIlIll1IIlIlIl1I111l1I <> "" then RP_JwExtractInto(_llllI1llIIIlIll1IIlIlIl1I111l1I, _llI1II1II1Ill1I1I1111IlIIII1l1I)
end if
if _llI1II1II1Ill1I1I1111IlIIII1l1I.Count() = 0 then return invalid
_lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I = _llIll1lII1l1I1Ill1lIII1I111Il1l1l1I
if _lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I = "" then _lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I = _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II
_llIl1ll1IIIl1l1I1lIlIIlIIlIIIlI111lIIllI11l = {}
for each _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11 in _llI1II1II1Ill1I1I1111IlIIII1l1I
_llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11 = RP_AbsUrl(_llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11.url, _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II)
if _llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11 = "" then continue for
if _llIl1ll1IIIl1l1I1lIlIIlIIlIIIlI111lIIllI11l.DoesExist(_llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11) then continue for
_llIl1ll1IIIl1l1I1lIlIIlIIlIIIlI111lIIllI11l[_llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11] = true
_lllI1l11Il1II1lIll11I1l1ll1IlIl = HC_Get(_llIl11Illl1llIlI1I11lllI1IIIIIlllllllIlIII1, _llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11, { "Referer": _lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I }, 6000)
if _lllI1l11Il1II1lIll11I1l1ll1IlIl = invalid or _lllI1l11Il1II1lIll11I1l1ll1IlIl.body = "" then continue for
if _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11.fmt = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("40634abe") and Left(_lllI1l11Il1II1lIll11I1l1ll1IlIl.body, 7) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("39a54a505f4bc469") then continue for
return {
url: _llll1ll1lIlII11l1Il11lI1IIIIIlIl1llII11
streamFormat: _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11.fmt
qualities: []
subtitles: RP_ExtractSubs(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I)
chapters: []
referer: _lllII1I1l111l11ll1lI1lI1I111l1Il1II1l1I
userAgent: ""
}
end for
return invalid
end function
sub RP_JwExtractInto(_ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il as String, _ll1I1IIIIlI1llIl1lIlII1I1I1lI111l111Ill as Object)
if _ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il = invalid or _ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il = "" then return
_ll1ll1I1IIIIlllIIl1IIl1llllll11 = chr(34)
_llII1lIlllI1IllIlII11IIlll1lI11l111Il1IIl11 = _llllIllII1II1I1ll1lll1lIlIII11I("4a350adf54ec7f171d00932b1f") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllII1II1I1ll1lll1lIlIII11I("310cac66568b") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6b4d63b4b560f82286") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + (Chr(39) + Chr(93))
_llI1lIlIl11llI1llIIII11I111lII1lI1IlI111lII = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6f6bcae7368349d30bf9a37fb422fa") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llIIlIll1llIlII1lI1lIlI1l1lI111("652985e76b8e") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllII1II1I1ll1lll1lIlIII11I("492fd97c8dd3ebad97") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + (Chr(39) + Chr(93))
_ll1ll1l1I1lIlIl1IIIllI1lII1lIlI1lIIlII1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("55d5d7ebbfe13b2ecbed47db") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("71055d0ec131") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4d02302d683006186f177f6b232c6a5825503f1dd966c3") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("21a1670b0c84") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + (Chr(39) + Chr(93))
_llIl1lIlIl11I1l1IIl1llIIl11IIlllI111l1I = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("7409f7f680b23275998be4b81b29c703") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6aff88009494") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3cfe8785cf2a2091d9") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + (Chr(39) + Chr(93))
for each _lllllIIlI1l1II1lIll1Ill1II11I1IIll11lIlIIIl in [_llII1lIlllI1IllIlII11IIlll1lI11l111Il1IIl11, _llI1lIlIl11llI1llIIII11I111lII1lI1IlI111lII, _ll1ll1l1I1lIlIl1IIIllI1lII1lIlI1lIIlII1, _llIl1lIlIl11I1l1IIl1llIIl11IIlllI111l1I]
_llIIII111111IlI11IIl1l11lII111I = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("53621579dbf6f1d4"), _lllllIIlI1l1II1lIll1Ill1II11I1IIll11lIlIIIl, Chr(105))
m = _llIIII111111IlI11IIl1l11lII111I.match(_ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il)
if m <> invalid and m.Count() >= 2 then
_lllII1lIllIl1lIlll1lIIIllIIIIll = RP_UnescapeSlashes(m[1])
_lll1llI11IlIllI11ll1lIlI1111ll1l1llI1lIl111 = _llllIllII1II1I1ll1lll1lIlIII11I("4983c8fc")
if Instr(1, LCase(_lllII1lIllIl1lIlll1lIIIllIIIIll), _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("23331a9bc3")) > 0 then _lll1llI11IlIllI11ll1lIlI1111ll1l1llI1lIl111 = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3b2afc71")
_ll1I1IIIIlI1llIl1lIlII1I1I1lI111l111Ill.Push({ url: _lllII1lIllIl1lIlll1lIIIllIIIIll, fmt: _lll1llI11IlIllI11ll1lIlI1111ll1l1llI1lIl111 })
end if
end for
_llIIl111Ill1IIllIIl1IIIl1IlllI1lIII = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3535481f8b32ea06"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("51aa6d7c7f7e84d3d1c9cc7b81") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4494389d23bb51d13caf49951cca5e9050") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("73259194977d3ba12d33"), Chr(105))
_lllI11llI1lIl11lIllIII1I1llIllllI1IIIll = _llIIl111Ill1IIllIIl1IIIl1IlllI1lIII.match(_ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il)
if _lllI11llI1lIl11lIllIII1I1llIllllI1IIIll <> invalid and _lllI11llI1lIl11lIllIII1I1llIllllI1IIIll.Count() >= 2 then _ll1I1IIIIlI1llIl1lIlII1I1I1lI111l111Ill.Push({ url: _lllI11llI1lIl11lIllIII1I1llIllllI1IIIll[1], fmt: _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("46ae9db3") })
_llIl1lIIlll1lIll1llIlIll1IIl11llI11lll11Ill = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3e4d247908723566"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3cbb7bae60a35ce642fa45f74b") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("274b7851266e32726d5890da163075c3") + _ll1ll1I1IIIIlllIIl1IIl1llllll11 + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7583d43b4a4cfd36c9da"), Chr(105))
_lll1l1I1l1l11II1l1IllIIIIIIIl11IlI1 = _llIl1lIIlll1lIll1llIlIll1IIl11llI11lll11Ill.match(_ll1l1II1I1lIl1IIIIIll1llIllIl1I11Il)
if _lll1l1I1l1l11II1l1IllIIIIIIIl11IlI1 <> invalid and _lll1l1I1l1l11II1l1IllIIIIIIIl11IlI1.Count() >= 2 then _ll1I1IIIIlI1llIl1lIlII1I1I1lI111l111Ill.Push({ url: _lll1l1I1l1l11II1l1IllIIIIIIIl11IlI1[1], fmt: _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("28598775") })
end sub
function RP_UnescapeSlashes(_llII1lIllll111111l1llII1I1l1I1l as String) as String
if _llII1lIllll111111l1llII1I1l1I1l = invalid or _llII1lIllll111111l1llII1I1l1I1l = "" then return ""
_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("61e71afc807b96f9"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("77e6e99b"), Chr(103))
return _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l.replaceAll(_llII1lIllll111111l1llII1I1l1I1l, Chr(47))
end function
function RP_AbsUrl(_lllI11lII1llII1lIll1Il1I1lllII1 as String, _llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI as String) as String
if _lllI11lII1llII1lIll1Il1I1lllII1 = invalid or _lllI11lII1llII1lIll1Il1I1lllII1 = "" then return ""
_llIlll11I1llIIII1IIlI1111l1l1Il = U_Trim(_lllI11lII1llII1lIll1Il1I1lllII1)
if Left(_llIlll11I1llIIII1IIlI1111l1l1Il, 7) = _llIIlIll1llIlII1lI1lIlI1l1lI111("671c87927dd68994") or Left(_llIlll11I1llIIII1IIlI1111l1l1Il, 8) = _llllIllII1II1I1ll1lll1lIlIII11I("43fd41468bc0390f14") then return _llIlll11I1llIIII1IIlI1111l1l1Il
if Left(_llIlll11I1llIIII1IIlI1111l1l1Il, 2) = (Chr(47) + Chr(47)) then return _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("59774b947e3086") + _llIlll11I1llIIII1IIlI1111l1l1Il
_llIlIlI11llIIlIIIlII11IlIlIIl1I = HC_OriginOf(_llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI)
if _llIlIlI11llIIlIIIlII11IlIlIIl1I = "" then return _llIlll11I1llIIII1IIlI1111l1l1Il
if Left(_llIlll11I1llIIII1IIlI1111l1l1Il, 1) = Chr(47) then return _llIlIlI11llIIlIIIlII11IlIlIIl1I + _llIlll11I1llIIII1IIlI1111l1l1Il
_llIllll1llI111llIllIIIIIl1111I11lII = Len(_llIlIlI11llIIlIIIlII11IlIlIIl1I) + 1
if _llIllll1llI111llIllIIIIIl1111I11lII > Len(_llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI) then return _llIlIlI11llIIlIIIlII11IlIlIIl1I + Chr(47) + _llIlll11I1llIIII1IIlI1111l1l1Il
_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11 = Mid(_llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI, _llIllll1llI111llIllIIIIIl1111I11lII + 1)
_llll1llI1lIlIlIl1I11llIlII1III1lI111lIl = Instr(1, _llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, Chr(63))
if _llll1llI1lIlIlIl1I11llIlII1III1lI111lIl > 0 then _llll11Ill1IIIllI11l111I1lI1IlIlI1llII11 = Left(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, _llll1llI1lIlIlIl1I11llIlII1III1lI111lIl - 1)
_ll1llI1IllllIl1II11llII11l1lI1IIIlI = Instr(1, _llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, Chr(35))
if _ll1llI1IllllIl1II11llII11l1lI1IIIlI > 0 then _llll11Ill1IIIllI11l111I1lI1IlIlI1llII11 = Left(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, _ll1llI1IllllIl1II11llII11l1lI1IIIlI - 1)
_ll1lIl1l1lIll1l11I111IlI1l1Il11IllIIIIllIIl = 0
for _lllI1ll1III1IIl1lI1I1ll1IlIl1lI11l11I1I = 1 to Len(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11)
if Mid(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, _lllI1ll1III1IIl1lI1I1ll1IlIl1lI11l11I1I, 1) = Chr(47) then _ll1lIl1l1lIll1l11I111IlI1l1Il11IllIIIIllIIl = _lllI1ll1III1IIl1lI1I1ll1IlIl1lI11l11I1I
end for
if _ll1lIl1l1lIll1l11I111IlI1l1Il11IllIIIIllIIl = 0 then return _llIlIlI11llIIlIIIlII11IlIlIIl1I + Chr(47) + _llIlll11I1llIIII1IIlI1111l1l1Il
return _llIlIlI11llIIlIIIlII11IlIlIIl1I + Chr(47) + Left(_llll11Ill1IIIllI11l111I1lI1IlIlI1llII11, _ll1lIl1l1lIll1l11I111IlI1l1Il11IllIIIIllIIl) + _llIlll11I1llIIII1IIlI1111l1l1Il
end function
function RP_ResolveLookmovie(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1 as String, _ll1l1IIIl1lII1I11I1I11lI1lIllIl11I11I1I as String, _ll1lll1l11IIIIlIl11l11I1llIll11I1Illl1Il111 as Object) as Object
_ll1ll11lllIlIIlllllI1IlIII11IlI1ll1 = {}
if _ll1l1IIIl1lII1I11I1I11lI1lIllIl11I11I1I <> "" then _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1[_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5f90a2a2a8bcaec2")] = _ll1l1IIIl1lII1I11I1I11lI1lIllIl11I11I1I else _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1[_llllIllII1II1I1ll1lll1lIlIII11I("610c80558a1e9428")] = _llI1ll1Il1llIlIIll1l11Il1llllIlllI1
_ll1l11lIlll11lIIl11111Ill11Il1I = HC_Get(_ll1lll1l11IIIIlIl11l11I1llIll11I1Illl1Il111, _llI1ll1Il1llIlIIll1l11Il1llllIlllI1, _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1, 8000)
if _ll1l11lIlll11lIIl11111Ill11Il1I = invalid or _ll1l11lIlll11lIIl11111Ill11Il1I.body = "" then return invalid
_lllII1lII1III1I1l1lllIIIIlI1lI1 = _ll1l11lIlll11lIIl11111Ill11Il1I.finalUrl
if _lllII1lII1III1I1l1lllIIIIlI1lI1 = invalid or _lllII1lII1III1I1l1lllIIIIlI1lI1 = "" then _lllII1lII1III1I1l1lllIIIIlI1lI1 = _llI1ll1Il1llIlIIll1l11Il1llllIlllI1
_ll1IIlIllIl1Il1ll1IIllIlIlIl1II = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("674527e97328a16f"), _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("508117ac3661130978b90f941f76e1fe0a30fcbd4e2fa39b0028a6e649de366e51dd92031d66b103db79cc145e37ba"), Chr(105))
_ll1Il1lI11l1I1II1lIl1111lI111IIl11lllI111Il = _ll1IIlIllIl1Il1ll1IIllIlIlIl1II.match(_ll1l11lIlll11lIIl11111Ill11Il1I.body)
if _ll1Il1lI11l1I1II1lIl1111lI111IIl11lllI111Il = invalid or _ll1Il1lI11l1I1II1lIl1111lI111IIl11lllI111Il.Count() < 1 then return invalid
_llIllIl111ll1l1111111IIll11l1IlllIlI1II = JU_UnpackPacked(_ll1Il1lI11l1I1II1lIl1111lI111IIl11lllI111Il[0])
if _llIllIl111ll1l1111111IIll11l1IlllIlI1II = "" then return invalid
_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I = {}
_lll1IIl1llIlII1IlII1l11lll111II = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4c0156357a3e472a"), chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("646c2393628f5f168c7041") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7bfe146e610a207a") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("79499726") + chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("2946d925") + chr(34), (Chr(105) + Chr(103)))
_ll1llII1I1l1II11lllIl11llII11I1Il1I = _lll1IIl1llIlII1IlII1l11lll111II.matchAll(_llIllIl111ll1l1111111IIll11l1IlllIlI1II)
if _ll1llII1I1l1II11lllIl11llII11I1Il1I <> invalid then
for each _ll1lIlIIll1l1lI1ll11I1I1Il1IIIl in _ll1llII1I1l1II11lllIl11llII11I1Il1I
if _ll1lIlIIll1l1lI1ll11I1I1Il1IIIl.Count() < 3 then continue for
_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I[_ll1lIlIIll1l1lI1ll11I1I1Il1IIIl[1]] = RP_UnescapeSlashes(_ll1lIlIIll1l1lI1ll11I1I1Il1IIIl[2])
end for
end if
_llI11II1Il1I1llIll1I1llI1IIl1lI = [_llIIlIll1llIlII1lI1lIlI1l1lI111("45ee19bcc5"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7d5a595b17"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("7407f76af2")]
for each _llll11lII1IlIllll11I1lIlIIIII111llI1II1 in _llI11II1Il1I1llIll1I1llI1IIl1lI
_llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l = _lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I[_llll11lII1IlIllll11I1lIlIIIII111llI1II1]
if _llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l = invalid or _llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l = "" then continue for
_llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l = RP_AbsUrl(_llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l, _lllII1lII1III1I1l1lllIIIIlI1lI1)
_llllIlllIll1IIl1l111Ill1llllIl1lllI11I1 = HC_Get(_ll1lll1l11IIIIlIl11l11I1llIll11I1Illl1Il111, _llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l, { "Referer": _lllII1lII1III1I1l1lllIIIIlI1lI1 }, 6000)
if _llllIlllIll1IIl1l111Ill1llllIl1lllI11I1 = invalid or _llllIlllIll1IIl1l111Ill1llllIl1lllI11I1.body = "" then continue for
if Left(_llllIlllIll1IIl1l111Ill1llllIl1lllI11I1.body, 7) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("410d108cd49f0328") then continue for
return {
url: _llIlll1IIllIlII11Ill11I1lI11lIllI11lI1lI11l
streamFormat: _llllIllII1II1I1ll1lll1lIlIII11I("79d2174d")
qualities: []
subtitles: RP_ExtractSubs(_ll1l11lIlll11lIIl11111Ill11Il1I.body)
chapters: []
referer: _lllII1lII1III1I1l1lllIIIIlI1lI1
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidora(_lll1I1I1IIl1I1IlIII1l1I111l11lI as String, _llI1lll1ll1Il1111Ill1I111Il111I as String, _llll1I11Ill11IlI11ll1lllIll1I1ll1l1 as Object) as Object
_ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l = {}
if _llI1lll1ll1Il1111Ill1I111Il111I <> "" then _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l[_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("281ec0fa71562186")] = _llI1lll1ll1Il1111Ill1I111Il111I else _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l[_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("42b572bf6aa142bf")] = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("71356a3c7536032a18611d010914103f0a3f4a6caa25")
_llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI = HC_Get(_llll1I11Ill11IlI11ll1lllIll1I1ll1l1, _lll1I1I1IIl1I1IlIII1l1I111l11lI, _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l, 8000)
if _llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI = invalid or _llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI.body = "" then return invalid
_ll11Illlll11l1I1IIlIl11II11lIlII1III11I = _llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI.finalUrl
if _ll11Illlll11l1I1IIlIl11II11lIlII1III11I = invalid or _ll11Illlll11l1I1IIlIl11II11lIlII1III11I = "" then _ll11Illlll11l1I1IIlIl11II11lIlII1III11I = _lll1I1I1IIl1I1IlIII1l1I111l11lI
return RP_ResolveJwplayerPage(_llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI.body, _ll11Illlll11l1I1IIlIl11II11lIlII1III11I, _ll11Illlll11l1I1IIlIl11II11lIlII1III11I, _llll1I11Ill11IlI11ll1lllIll1I1ll1l1)
end function
function RP_Resolve2embed(_lllIIIl1ll1ll1IllIllll11l11l111Ill11111 as String, _llIIlIIlII1IIII1l1l1l1l1l1l1IlIlI11IIlIllll as String, _ll1111l1I11llII1l1ll1I1I11I111I1I1I as Object) as Object
_llllI1IlIlII1lIlll1Il1IIlII1I11II1lllll1Il1 = {}
if _llIIlIIlII1IIII1l1l1l1l1l1l1IlIlI11IIlIllll <> "" then _llllI1IlIlII1lIlll1Il1IIlII1I11II1lllll1Il1[_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("58d69ce6ed07b2e2")] = _llIIlIIlII1IIII1l1l1l1l1l1l1IlIlI11IIlIllll else _llllI1IlIlII1lIlll1Il1IIlII1I11II1lllll1Il1[_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("7bd82736b72387f2")] = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("40634cfc2ddd7c6119e1cd712e02683198dd8e00")
_ll1IlIIIllIlllII1lllI1llllII11I11l1 = HC_Get(_ll1111l1I11llII1l1ll1I1I11I111I1I1I, _lllIIIl1ll1ll1IllIllll11l11l111Ill11111, _llllI1IlIlII1lIlll1Il1IIlII1I11II1lllll1Il1, 8000)
if _ll1IlIIIllIlllII1lllI1llllII11I11l1 = invalid or _ll1IlIIIllIlllII1lllI1llllII11I11l1.body = "" then return invalid
_ll11I1I11l1I11I1lI1IlI1I1llII1111I1 = _ll1IlIIIllIlllII1lllI1llllII11I11l1.finalUrl
if _ll11I1I11l1I11I1lI1IlI1I1llII1111I1 = invalid or _ll11I1I11l1I11I1lI1IlI1I1llII1111I1 = "" then _ll11I1I11l1I11I1lI1IlI1I1llII1111I1 = _lllIIIl1ll1ll1IllIllll11l11l111Ill11111
_llIIII1111lI11IlII1I11lll1Ill1llIlI111l1III = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5e1a9742e5c6563b"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6b5b944a93b1f204f3f7e448649b88edf962ee") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2fdd7af0b39a9da4a6edf30306b5b5baccd3dac7c9ddd0b82918eaf5f1f3f5d04101044bfaf91a031fee50f7f5") + chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7e2844fb542b") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
_llIlIlI111lIllI1IlI1l11l1IllIIlIlIIIIllI1ll = _llIIII1111lI11IlII1I11lll1Ill1llIlI111l1III.match(_ll1IlIIIllIlllII1lllI1llllII11I11l1.body)
_ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = ""
if _llIlIlI111lIllI1IlI1l11l1IllIIlIlIIIIllI1ll <> invalid and _llIlIlI111lIllI1IlI1l11l1IllIIlIlIIIIllI1ll.Count() >= 2 then
_ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = _llIlIlI111lIllI1IlI1l11l1IllIIlIlIIIIllI1ll[1]
else
_lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("2f371aeef8b01847"), _llIIlIll1llIlII1lI1lIlI1l1lI111("778d96010cf71a876a1d2851645f02ed58939629b406a4cf70bb6e91945efcadb8254e79146f22ccf2dafdf8bc") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("661c831aa378b3"), Chr(105))
_lllII1llI1lI11IIII1Ill11IlII1l111II = _lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I.match(_ll1IlIIIllIlllII1lllI1llllII11I11l1.body)
if _lllII1llI1lI11IIII1Ill11IlII1l111II <> invalid and _lllII1llI1lI11IIII1Ill11IlII1l111II.Count() >= 2 then _ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = _lllII1llI1lI11IIII1Ill11IlII1l111II[1]
end if
if _ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = "" then return invalid
_ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l = U_HtmlDecode(_ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l)
_lllIII1lIIIlllIIllIlI1llIlIllllIlll = HC_Get(_ll1111l1I11llII1l1ll1I1I11I111I1I1I, _ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l, { "Referer": _ll11I1I11l1I11I1lI1IlI1I1llII1111I1 }, 8000)
if _lllIII1lIIIlllIIllIlI1llIlIllllIlll = invalid or _lllIII1lIIIlllIIllIlI1llIlIllllIlll.body = "" then return invalid
_llI1I1Il1lI1I1II1II11IllIlIll11 = _lllIII1lIIIlllIIllIlI1llIlIllllIlll.finalUrl
if _llI1I1Il1lI1I1II1II11IllIlIll11 = invalid or _llI1I1Il1lI1I1II1II11IllIlIll11 = "" then _llI1I1Il1lI1I1II1II11IllIlIll11 = _ll1lI1llIlll1I11III1llIllIll1ll1I1lIl1l
_ll1llll1llIll11IlI11IlIlIl11l111III = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("5a5540616c6a517e"), _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5d35362af9bb6bd443b386349ab0421ffe89") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("2ed39141d7ca") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("38423dad2362") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
_llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = _ll1llll1llIll11IlI11IlIlIl11l111III.match(_lllIII1lIIIlllIIllIlI1llIlIllllIlll.body)
if _llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = invalid or _llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1.Count() < 2 then return invalid
_llIl1lIll1l1l1I1I11IIl1IIII11lI1l1I1Il11lll = _llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1[1]
_llII1lllIlI11lIl1II1l11l1111I1IIlI1II1IIl11 = ""
if Left(_llIl1lIll1l1l1I1I11IIl1IIII11lI1l1I1Il11lll, 4) = _llllIllII1II1I1ll1lll1lIlIII11I("4f09cdd297") then
_llII1lllIlI11lIl1II1l11l1111I1IIlI1II1IIl11 = _llIl1lIll1l1l1I1I11IIl1IIII11lI1l1I1Il11lll
else
_llII1lllIlI11lIl1II1l11l1111I1IIlI1II1IIl11 = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3969bf8f5e0d4f1870ebf088a049312f80a8ad9b9e88312a72a8e1") + _llIl1lIll1l1l1I1I11IIl1IIII11lI1l1I1Il11lll
end if
return RP_ResolveLookmovie(_llII1lllIlI11lIl1II1l11l1111I1IIlI1II1IIl11, _llI1I1Il1lI1I1II1II11IllIlIll11, _ll1111l1I11llII1l1ll1I1I11I111I1I1I)
end function
function RP_ResolveCloudnestra(_lllIlIIII1IIIIllI1IlI1111IlIllIIl1l as String, _lll1lIllll11l1lll1l1lIl1l11l111I1lI1ll1 as String, _lllIIIlII1IIIl1IlIIllll11111lllIIII as Object) as Object
_lllIllIlllI1Il1IllIIIIIIIlI1I1lllII = _lll1lIllll11l1lll1l1lIl1l11l111I1lI1ll1
if _lllIllIlllI1Il1IllIIIIIIIlI1I1lllII = "" then _lllIllIlllI1Il1IllIIIIIIIlI1I1lllII = _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l
_llI111l111lIII1lIIII1lllIIll1l1l1l11IlI = HC_Get(_lllIIIlII1IIIl1IlIIllll11111lllIIII, _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l, { "Referer": _lllIllIlllI1Il1IllIIIIIIIlI1I1lllII }, 8000)
if _llI111l111lIII1lIIII1lllIIll1l1l1l11IlI = invalid or _llI111l111lIII1lIIII1lllIIll1l1l1l11IlI.body = "" then return invalid
_ll1l11Ill1IIIIII1IlIl1lIII11I1l = _llI111l111lIII1lIIII1lllIIll1l1l1l11IlI.finalUrl
if _ll1l11Ill1IIIIII1IlIl1lIII11I1l = invalid or _ll1l11Ill1IIIIII1IlIl1lIII11I1l = "" then _ll1l11Ill1IIIIII1IlIl1lIII11I1l = _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l
_llIl1I1II1Il11lIIll1I1Il11Il11lIl1ll11l = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5a5483acd14a62c5"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("21a746b3648e26201c") + chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("49e47bbafbc0f1852fa55e50149c") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("73a9611f1ab2") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
m = _llIl1I1II1Il11lIIll1I1Il11Il11lIl1ll11l.match(_llI111l111lIII1lIIII1lllIIll1l1l1l11IlI.body)
if m = invalid or m.Count() < 2 then
_lll11lIl11IllIIl1I1l1Il1IIIllIIIlllIlI11I1l = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6d13e2908c977e8a"), Chr(91) + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4abf08bdc3fe0309091b0dd52c2c") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3cb441cb58b0") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
m = _lll11lIl11IllIIl1I1l1Il1IIIllIIIlllIlI11I1l.match(_llI111l111lIII1lIIII1lllIIll1l1l1l11IlI.body)
if m = invalid or m.Count() < 2 then return RP_ResolveGeneric(_lllIlIIII1IIIIllI1IlI1111IlIllIIl1l, _lll1lIllll11l1lll1l1lIl1l11l111I1lI1ll1, _lllIIIlII1IIIl1IlIIllll11111lllIIII)
end if
_llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l = m[1]
if Left(_llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l, 1) <> Chr(47) then _llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l = Chr(47) + _llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l
_llIlIl111lllll1llI11ll1I1ll11I1IIl1lllI1I1l = RP_AbsUrl(_llI1IlIIIlI111lI11lllII1111Il11lIl1l1I1l11l, _ll1l11Ill1IIIIII1IlIl1lIII11I1l)
_ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il = HC_Get(_lllIIIlII1IIIl1IlIIllll11111lllIIII, _llIlIl111lllll1llI11ll1I1ll11I1IIl1lllI1I1l, { "Referer": _ll1l11Ill1IIIIII1IlIl1lIII11I1l }, 8000)
if _ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il = invalid or _ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.body = "" then return invalid
_ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll = _ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.finalUrl
if _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll = invalid or _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll = "" then _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll = _llIlIl111lllll1llI11ll1I1ll11I1IIl1lllI1I1l
_llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("58100ef60e0f142c"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("33e4dee4f0341d032d") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6e8a6f9f") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("5622dad5") + chr(34), Chr(105))
_ll1llII1l1I1IlIIl11I1I11I1l11l1II1I = _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.match(_ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.body)
if _ll1llII1l1I1IlIIl11I1I11I1l11l1II1I = invalid or _ll1llII1l1I1IlIIl11I1I11I1l11l1II1I.Count() < 2 then return invalid
_ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111 = _ll1llII1l1I1IlIIl11I1I11I1l11l1II1I[1]
_ll1l11llIllllIll11II1l1lIll1I1llI1llI1111Il = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("50e0344317bf88c9"), chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("2cd885aca75f1ba9cadb0f15fcb58aa33ea1f01eff2c28f919e8075865aa2275695164d2afb6") + chr(34), (Chr(105) + Chr(103)))
_ll11I11IIl1IIlIll1I111IlI111lIl11Il = _ll1l11llIllllIll11II1l1lIll1I1llI1llI1111Il.matchAll(_ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.body)
_ll11111llIllIl111llIIl1lI111lIIll1I = []
_lll1llII1lIl11l11IIIIIl11I1II1lI1lIIl1I = {}
if _ll11I11IIl1IIlIll1I111IlI111lIl11Il <> invalid then
for each _ll11I1I11ll1l1lI1I111lI1IIlI1IIl1l1 in _ll11I11IIl1IIlIll1I111IlI111lIl11Il
if _ll11I1I11ll1l1lI1I111lI1IIlI1IIl1l1.Count() < 2 then continue for
_llII1I11111I11I1l1IIIl1I1llll11lIII = _ll11I1I11ll1l1lI1I111lI1IIlI1IIl1l1[1]
if _lll1llII1lIl11l11IIIIIl11I1II1lI1lIIl1I.DoesExist(_llII1I11111I11I1l1IIIl1I1llll11lIII) then continue for
_lll1llII1lIl11l11IIIIIl11I1II1lI1lIIl1I[_llII1I11111I11I1l1IIIl1I1llll11lIII] = true
_ll11111llIllIl111llIIl1lI111lIIll1I.Push(_llII1I11111I11I1l1IIIl1I1llll11lIII)
end for
end if
if _ll11111llIllIl111llIIl1lI111lIIll1I.Count() = 0 then _ll11111llIllIl111llIIl1lI111lIIll1I.Push(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("622591ecae79f4f2b9f84b86e7b4dad8598a4608c36e6150260500b62ef9"))
_ll1l1lIl1I1IIII1l1111III11lIIl1IIIIlII1 = []
_llII11I1I1III1l1llIl11lI1l1II1IIl1llllI11ll = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("75d42adcd4b9de92"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("66d679ae0aa5254ffc"), Chr(105))
_llIl1Il1lIlI1I11l11lI1l1lI11llIllll1IIlIlI1 = _llII11I1I1III1l1llIl11lI1l1II1IIl1llllI11ll.split(_ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111)
if _llIl1Il1lIlI1I11l11lI1l1lI11llIllll1IIlIlI1 <> invalid then
for each _llIl111II111ll111Il1lIll1Ill11I11ll in _llIl1Il1lIlI1I11l11lI1l1lI11llIllll1IIlIlI1
_llll1Il1I1I111lI1I1llIIIllll1ll1Il1IIII = U_Trim(_llIl111II111ll111Il1lIll1Ill11I11ll)
if _llll1Il1I1I111lI1I1llIIIllll1ll1Il1IIII <> "" then _ll1l1lIl1I1IIII1l1111III11lIIl1IIIIlII1.Push(_llll1Il1I1I111lI1I1llIIIllll1ll1Il1IIII)
end for
end if
_ll111IlI111II11ll1llIl11I1II11l = []
_llIll1l1111ll11IlIII1IIIIlllI11IIII = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("3b7f66a907706133"), _llIIlIll1llIlII1lI1lIlI1l1lI111("408e60d3af790ed0d2"), Chr(103))
for each _llI1IlI1lII11lll1IlI1llll1llIIl in _ll1l1lIl1I1IIII1l1111III11lIIl1IIIIlII1
if Instr(1, _llI1IlI1lII11lll1IlI1llll1llIIl, (Chr(123) + Chr(118))) > 0 then
for each _llII1I11111I11I1l1IIIl1I1llll11lIII in _ll11111llIllIl111llIIl1lI111lIIll1I
_ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l = Instr(1, _llII1I11111I11I1l1IIIl1I1llll11lIII, Chr(46))
if _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l > 0 and _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l < Len(_llII1I11111I11I1l1IIIl1I1llll11lIII) then
_lllI1lI11IIIlllll1I1I11lIlI1l1I1Ill = Mid(_llII1I11111I11I1l1IIIl1I1llll11lIII, _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l + 1)
else
_lllI1lI11IIIlllll1I1I11lIlI1l1I1Ill = _llII1I11111I11I1l1IIIl1I1llll11lIII
end if
_ll111IlI111II11ll1llIl11I1II11l.Push(_llIll1l1111ll11IlIII1IIIIlllI11IIII.replaceAll(_llI1IlI1lII11lll1IlI1llll1llIIl, _lllI1lI11IIIlllll1I1I11lIlI1l1I1Ill))
end for
else
_ll111IlI111II11ll1llIl11I1II11l.Push(_llI1IlI1lII11lll1IlI1llll1llIIl)
end if
end for
_llI1I11IllI11l1IlIIl1lIl1I1I11II1Il1l1I1lIl = {}
for each _ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I in _ll111IlI111II11ll1llIl11I1II11l
if _ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I = "" or _llI1I11IllI11l1IlIIl1lIl1I1I11II1Il1l1I1lIl.DoesExist(_ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I) then continue for
_llI1I11IllI11l1IlIIl1lIl1I1I11II1Il1l1I1lIl[_ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I] = true
_lll111I111l11111l11I1IIIIIII11lIlI1 = HC_Get(_lllIIIlII1IIIl1IlIIllll11111lllIIII, _ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I, { "Referer": _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll }, 6000)
if _lll111I111l11111l11I1IIIIIII11lIlI1 = invalid or _lll111I111l11111l11I1IIIIIII11lIlI1.body = "" then continue for
if Left(_lll111I111l11111l11I1IIIIIII11lIlI1.body, 7) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6e78966d1a5aa48a") then continue for
return {
url: _ll1IlIll1IlI111Il111IlIIl1ll1ll1IlIIlI11I1I
streamFormat: _llllIllII1II1I1ll1lll1lIlIII11I("30c58a60")
qualities: []
subtitles: RP_ExtractSubs(_ll1IIlII11lI1lllllIIlIl11lIIllIll1l11Il.body)
chapters: []
referer: _ll1I111IllIIllIIll11lIIllIlll111IIlIl1I11ll
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveVidsrcXyz(_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111 as String, _lllIIll1l111Ill1II1l1111I1lll1111I1111l as String, _llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll as Object) as Object
_ll1IlI1lIIIII111II1111lII1I1llIllI1 = _lllIIll1l111Ill1II1l1111I1lll1111I1111l
if _ll1IlI1lIIIII111II1111lII1I1llIllI1 = "" then _ll1IlI1lIIIII111II1111lII1I1llIllI1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2b2a393c3b3d877f824c464452544896585ca0")
_lll1II1IlIllI11ll11lII111I1llI1Il1l = HC_Get(_llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll, _llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111, { "Referer": _ll1IlI1lIIIII111II1111lII1I1llIllI1 }, 8000)
if _lll1II1IlIllI11ll11lII111I1llI1Il1l = invalid or _lll1II1IlIllI11ll11lII111I1llI1Il1l.body = "" then return invalid
_ll1Il111l1111I1III1l1I111I1lI1III111l1I = _lll1II1IlIllI11ll11lII111I1llI1Il1l.finalUrl
if _ll1Il111l1111I1III1l1I111I1lI1III111l1I = invalid or _ll1Il111l1111I1III1l1I111I1lI1III111l1I = "" then _ll1Il111l1111I1III1l1I111I1lI1III111l1I = _llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111
_ll1lllI1llI1I1lIIlll11l1lll1lIIl11I = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("22aa8dbf536e691c"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("5cce877bee822997e1f7dc6c7fca5ed6df") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3dc240e647e260f76cd35da542af419e74") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("72702c275a6458d21f32b58e8a") + chr(34) + _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6d781cadc2b0") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("4b95cd8b861e") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
m = _ll1lllI1llI1I1lIIlll11l1lll1lIIl11I.match(_lll1II1IlIllI11ll11lII111I1llI1Il1l.body)
if m = invalid or m.Count() < 2 then
_llI1l11I1I11llI1IlII1l1I11l11I1l1IlIlll1lI1 = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("589657fd665dd37d"), _llllIllII1II1I1ll1lll1lIlIII11I("5f33283ce6c5") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4a8037fc2bf560f9") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("512563f62434b4e2c6f5f7c16b31b519b3") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("5d8220fd3986") + chr(34) + (Chr(39) + Chr(93)), Chr(105))
m = _llI1l11I1I11llI1IlII1l1I11l11I1l1IlIlll1lI1.match(_lll1II1IlIllI11ll11lII111I1llI1Il1l.body)
end if
if m <> invalid and m.Count() >= 2 then
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l = RP_AbsUrl(m[1], _ll1Il111l1111I1III1l1I111I1lI1III111l1I)
_lllllllII1Il11l1IlI11IlllII1I1l = RP_ResolveCloudnestra(_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l, _ll1Il111l1111I1III1l1I111I1lI1III111l1I, _llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll)
if _lllllllII1Il11l1IlI11IlllII1I1l <> invalid and _lllllllII1Il11l1IlI11IlllII1I1l.url <> "" then return _lllllllII1Il11l1IlI11IlllII1I1l
end if
_ll1llll1lIlllll11III1lI11I1IIII11lll111 = R_FollowKnownIframes(_lll1II1IlIllI11ll11lII111I1llI1Il1l.body, _ll1Il111l1111I1III1l1I111I1lI1III111l1I, _ll1IlI1lIIIII111II1111lII1I1llIllI1, 0, _llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll)
if _ll1llll1lIlllll11III1lI11I1IIII11lll111 <> invalid and _ll1llll1lIlllll11III1lI11I1IIII11lll111.url <> invalid and _ll1llll1lIlllll11III1lI11I1IIII11lll111.url <> "" then return _ll1llll1lIlllll11III1lI11I1IIII11lll111
return RP_ResolveGeneric(_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111, _lllIIll1l111Ill1II1l1111I1lll1111I1111l, _llIIllII1lIIl1llI11II1ll11l1I1lII1lll1lllll)
end function
function RP_ResolveMoviesapi(_ll1l1Ill1lI1lI11II1I1l1lII1Ill1 as String, _llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I as String, _lll11Illl1IlI1lIII11IllII1lllII as Object) as Object
_llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = _llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I
if _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = "" then _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("43046b33cae21b260647a83488e7c5740500a805")
_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I = HC_Get(_lll11Illl1IlI1lIII11IllII1lllII, _ll1l1Ill1lI1lI11II1I1l1lII1Ill1, { "Referer": _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 }, 8000)
if _lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I = invalid or _lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I.body = "" then return invalid
_llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = _lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I.finalUrl
if _llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = invalid or _llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = "" then _llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = _ll1l1Ill1lI1lI11II1I1l1lII1Ill1
_llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl = R_FollowKnownIframes(_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I.body, _llll111111lII1III1I1Il11I1Ill1l1II1I1I1, _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1, 0, _lll11Illl1IlI1lIII11IllII1lllII)
if _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl <> invalid and _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl.url <> invalid and _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl.url <> "" then return _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl
return RP_ResolveJwplayerPage(_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I.body, _llll111111lII1III1I1Il11I1Ill1l1II1I1I1, _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1, _lll11Illl1IlI1lIII11IllII1lllII)
end function
function RP_ResolveAutoembed(_lllI11Il1ll1llllIllIIIIlIllIllll1lll1ll as String, _llIlIl11III1l1II1IlI11111l1IIlIIllI as String, _llll1llII1II1I1lI1Illl1lll11lll as Object) as Object
_llllIl1III1IlIII1IIIIl11l11lIIl = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4c0a11141b1be7d5d81c18382f1f242e2c3636433738404255514a1250575c1d")
_llI111lIl1I11ll1I1IlIll11I1ll11l1ll = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("210f3b3b17302a24"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("6b722673327d0c3f10731513010617371e711f7fb8768f47fb19dc389843964d9861981cbb5a46555a28655e6c4775"), Chr(105))
m = _llI111lIl1I11ll1I1IlIll11I1ll11l1ll.match(_lllI11Il1ll1llllIllIIIIlIllIllll1lll1ll)
if m = invalid or m.Count() < 3 then return invalid
_lll1l1lIlIII1111IlIIII11I1lI1lIIll1 = m[1]
_ll1I1II111lll1IlI1lI1l11llI1III = m[2]
_lllI1II11l1II11llIIIIlIlIlI1ll1II1l = ""
_lll1lIll1l1II11lIlIlIllIll1Il11lIIlll1l11l1 = ""
if m.Count() >= 5 then
_lllI1II11l1II11llIIIIlIlIlI1ll1II1l = m[3]
_lll1lIll1l1II11lIlIlIllIll1Il11lIIlll1l11l1 = m[4]
end if
_llllI1Ill1IIlII11IlII111IIlIIl1 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3a13241339")
if Left(_ll1I1II111lll1IlI1lI1l11llI1III, 2) = (Chr(116) + Chr(116)) then _llllI1Ill1IIlII11IlII111IIlIIl1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("228988848d")
_ll1lIIIl1Ill11Illl1l1lll1I1l11Il1lII1Il = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("395a797c7b81bbb3b68d91928887869090a696d6b19fb1a0a8b3b2c2f1c8cefbc0d2be06dbc6e123") + _llllI1Ill1IIlII11IlII111IIlIIl1 + Chr(61) + U_UrlEncode(_ll1I1II111lll1IlI1lI1l11llI1III) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("4dcec298333e70") + _lll1l1lIlIII1111IlIIII11I1lI1lIIll1
if _lll1l1lIlIII1111IlIIII11I1lI1lIIll1 = (Chr(116) + Chr(118)) and _lllI1II11l1II11llIIIIlIlIlI1ll1II1l <> "" and _lll1lIll1l1II11lIlIlIllIll1Il11lIIlll1l11l1 <> "" then
_ll1lIIIl1Ill11Illl1l1lll1I1l11Il1lII1Il = _ll1lIIIl1Ill11Illl1l1lll1I1l11Il1lII1Il + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3fadf13fecd82e3eb2") + _lllI1II11l1II11llIIIIlIlIlI1ll1II1l + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6b2a915fe13fd05a026c") + _lll1lIll1l1II11lIlIlIllIll1Il11lIIlll1l11l1
end if
_lll1III111I11IIIIIIl1IIIII11lIIIl1II1II = HC_Get(_llll1llII1II1I1lI1Illl1lll11lll, _ll1lIIIl1Ill11Illl1l1lll1I1l11Il1lII1Il, {
"Referer": _llllIl1III1IlIII1IIIIl11l11lIIl
"Origin": _llIIlIll1llIlII1lI1lIlI1l1lI111("4af6e1ecd7eabb5e697eb1e44fe2ddc0e3c6d99427421538c3f6514267524d")
}, 8000)
if _lll1III111I11IIIIIIl1IIIII11lIIIl1II1II = invalid or _lll1III111I11IIIIIIl1IIIII11lIIIl1II1II.body = "" then return invalid
_ll1l11IlI1I1Il111lllIl1lI1l1llI = ParseJSON(_lll1III111I11IIIIIIl1IIIII11lIIIl1II1II.body)
if _ll1l11IlI1I1Il111lllIl1lI1l1llI = invalid or type(_ll1l11IlI1I1Il111lllIl1lI1l1llI) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("44707667787b82918e9989978da1889a9db19c") then return invalid
_lllll11II1lI11IlllIIll1III1lIIlIIlIIlI1 = ""
if _ll1l11IlI1I1Il111lllIl1lI1l1llI.status_code <> invalid then _lllll11II1lI11IlllIIll1III1lIIlIIlIIlI1 = _ll1l11IlI1I1Il111lllIl1lI1l1llI.status_code.ToStr()
if _lllll11II1lI11IlllIIll1III1lIIlIIlIIlI1 <> _llllIllII1II1I1ll1lll1lIlIII11I("69ccf1f6") then return invalid
_llI1ll1I1ll1I1lIlI1l1l1lIII1Il1I1IIl1l11lIl = _ll1l11IlI1I1Il111lllIl1lI1l1llI.data
if _llI1ll1I1ll1I1lIlI1l1l1lIII1Il1I1IIl1l11lIl = invalid or type(_llI1ll1I1ll1I1lIlI1l1l1lIII1Il1I1IIl1l11lIl) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("5b9acd29c3cef9641f6acd40f376a2343fc20d") then return invalid
_ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I = _llI1ll1I1ll1I1lIlI1l1l1lIII1Il1I1IIl1l11lIl.stream_urls
if _ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I = invalid or type(_ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("49c1676df8a00711") or _ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I.Count() = 0 then return invalid
for each _llI1I111IlIII1I1I1l1lII11III1ll in _ll1Il11I11lIl1II1Ill1lIlIl1III11ll1Il1I
if type(_llI1I111IlIII1I1I1l1lII11III1ll) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3d8ee737d960f9") and type(_llI1I111IlIII1I1I1l1lII11III1ll) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4127f99bb17bfe6f81") then continue for
if _llI1I111IlIII1I1I1l1lII11III1ll = "" then continue for
_lllllllIIIIIIIlll1Il11111IIIlIIIlI1I1II = HC_Get(_llll1llII1II1I1lI1Illl1lll11lll, _llI1I111IlIII1I1I1l1lII11III1ll, { "Referer": _llllIl1III1IlIII1IIIIl11l11lIIl }, 6000)
if _lllllllIIIIIIIlll1Il11111IIIlIIIlI1I1II = invalid or _lllllllIIIIIIIlll1Il11111IIIlIIIlI1I1II.body = "" then continue for
if Left(_lllllllIIIIIIIlll1Il11111IIIlIIIlI1I1II.body, 7) <> _llllIllII1II1I1ll1lll1lIlIII11I("78d4774b9006ec8f") then continue for
return {
url: _llI1I111IlIII1I1I1l1lII11III1ll
streamFormat: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6b57cfff")
qualities: []
subtitles: []
chapters: []
referer: _llllIl1III1IlIII1IIIIl11l11lIIl
userAgent: ""
}
end for
return invalid
end function
function RP_ResolveYthd(_lll1l1IllIIlll1IIl1l1ll1llI11l1 as String, _llII1Il1l1IIllI1lllI1ll11llIlII111lIlII as String, _llII1l1111l11Il111IIl1IIIII1I111I1lIlllII11 as Object) as Object
_llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = {}
if _llII1Il1l1IIllI1lllI1ll11llIlII111lIlII <> "" then _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l[_llIIlIll1llIlII1lI1lIlI1l1lI111("28f8aaadc023d639")] = _llII1Il1l1IIllI1lllI1ll11llIlII111lIlII
_llll11lI1IIl1ll1Illll1111lI11IIIIIl = HC_Get(_llII1l1111l11Il111IIl1IIIII1I111I1lIlllII11, _lll1l1IllIIlll1IIl1l1ll1llI11l1, _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l, 8000)
if _llll11lI1IIl1ll1Illll1111lI11IIIIIl = invalid or _llll11lI1IIl1ll1Illll1111lI11IIIIIl.body = "" then return invalid
_lll11lll1l1lII1I1IIlllI1ll1IIll = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("65e51e86b281708e"), _llIIlIll1llIlII1lI1lIlI1l1lI111("75016c9fead5281a96e954f7e22d") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("3a6900820a1f1575") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("2b6d707022287c") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("489d1e95ac4b37f848c56af9") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3ed8fe0e") + chr(34), Chr(105))
_lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I = _lll11lll1l1lII1I1IIlllI1ll1IIll.match(_llll11lI1IIl1ll1Illll1111lI11IIIIIl.body)
if _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I <> invalid and _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I.Count() >= 3 then
_ll1I1lI1ll11IlIIl11I1lIIIlI1llIII111II1 = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("3ecad9dcdbdfaba1a4") + _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I[1] + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("79894df98d6a") + _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I[2]
return RP_ResolveCloudnestra(_ll1I1lI1ll11IlIIl11I1lIIIlI1llIII111II1, _lll1l1IllIIlll1IIl1l1ll1llI11l1, _llII1l1111l11Il111IIl1IIIII1I111I1lIlllII11)
end if
_llII1I1111I1l1Ill11I1IlI11llI11I1lI11Il = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("4ac629db6f8a85b8"), _llIIlIll1llIlII1lI1lIlI1l1lI111("528d702386efe4a74205a6") + chr(34) + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("480adae2") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("2455bae3") + chr(34), Chr(105))
m = _llII1I1111I1l1Ill11I1IlI11llI11I1lI11Il.match(_llll11lI1IIl1ll1Illll1111lI11IIIIIl.body)
if m = invalid or m.Count() < 2 then return invalid
_llI1lIIII1l1l1IlIII1ll1IIlIlll1 = m[1]
_ll1I1lI1ll11IlIIl11I1lIIIlI1llIII111II1 = _llIIlIll1llIlII1lI1lIlI1l1lI111("75412c372225ea9da8d1c4c7a225e88b1ef164bff2cd704356199c71a28da8a546d96cd1") + _llI1lIIII1l1l1IlIII1ll1IIlIlll1
return RP_ResolveCloudnestra(_ll1I1lI1ll11IlIIl11I1lIIIlI1llIII111II1, _lll1l1IllIIlll1IIl1l1ll1llI11l1, _llII1l1111l11Il111IIl1IIIII1I111I1lIlllII11)
end function
function RP_ResolveVidking(_lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1 as String, _llIl11lI11ll1II11Ill11I1IIII1Il as String, _llIll1lIlll1l1IlIll11l11lI1lIll as Object) as Object
_llIll1l1llllllIlIIIl1l1l11l1I1l1lII = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("72dabdef839e994c"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("29a264a370ad4eef52a357c343d655e75ca15dafd29e82c0b1c99ee8da93d49ddab1daccf98a048518f8278e2e9737"), Chr(105))
m = _llIll1l1llllllIlIIIl1l1l11l1I1l1lII.match(_lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1)
if m = invalid or m.Count() < 3 then return invalid
_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1 = m[1]
_lll1IlI1I1IlII1lllIIl111llIlII1 = m[2]
_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = ""
_lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1 = ""
if m.Count() >= 5 then
_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = m[3]
_lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1 = m[4]
end if
_llIlIIlllI1I1IlII1II1IIIIllII11# = B_StrToLong(_lll1IlI1I1IlII1lllIIl111llIlII1)
return RP_VideasyFamilyResolve(_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1, _lll1IlI1I1IlII1lllIIl111llIlII1, _llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il, _lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1, _llIlIIlllI1I1IlII1II1IIIIllII11#, _lll1IlI1I1IlII1lllIIl111llIlII1, _llIll1lIlll1l1IlIll11l11lI1lIll)
end function
function RP_ResolveVideasy(_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I as String, _lll1lIllllIII1lIlII1IlIl1IIl11111l11l11 as String, _lll1Il1I11Il11l1IIl1IIIIlIII11IIllII1Il1lll as Object) as Object
_lll1ll111ll1I11lIll1lI1llIIIl1IIIlI11Illll1 = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("2646695bafcac538"), _llllIllII1II1I1ll1lll1lIlIII11I("2fa73c8db2265c21951a3f79de73b139b2978c00b50ba0de66dfc429befc84fde2e74b"), Chr(105))
m = _lll1ll111ll1I11lIll1lI1llIIIl1IIIlI11Illll1.match(_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I)
if m = invalid or m.Count() < 3 then return invalid
_ll1l111IIIl1l11I1I1I1II11lII111ll11111I1III = m[1]
_ll111I11l111lI1lIIIIII11ll111IllI1l = m[2]
_lll111lIl1l1111l1llIllIllIllIll1lllll1IIIIl = ""
_llIlIl11lIIlIllIll1I1Il1Il1lI1l = ""
if m.Count() >= 5 then
_lll111lIl1l1111l1llIllIllIllIll1lllll1IIIIl = m[3]
_llIlIl11lIIlIllIll1I1Il1Il1lI1l = m[4]
end if
_llII1lIIIllIIIII11lllI1l1Il1I1l# = B_StrToLong(_ll111I11l111lI1lIIIIII11ll111IllI1l)
return RP_VideasyFamilyResolve(_ll1l111IIIl1l11I1I1I1II11lII111ll11111I1III, _ll111I11l111lI1lIIIIII11ll111IllI1l, _lll111lIl1l1111l1llIllIllIllIll1lllll1IIIIl, _llIlIl11lIIlIllIll1I1Il1Il1lI1l, _llII1lIIIllIIIII11lllI1l1Il1I1l#, _ll111I11l111lI1lIIIIII11ll111IllI1l, _lll1Il1I11Il11l1IIl1IIIIlIII11IIllII1Il1lll)
end function
function RP_VideasyFamilyResolve(_ll1I1I1IlIlII11I11I1lII1I1Il11Il111 as String, _llI11I11l111IlllllIlIllllllII1llII1l11l as String, _llII1lIl1ll1lIlI1Ill1l1lIIlI1I1 as String, _llII1IlllIIl11Il1llllII1lIl11I1 as String, _llllIllIll11IllI1l1Il1IlIIllI11 as LongInteger, _lll11l1ll11lIl1IlIIllII1lllIIII1111 as String, _llIIlIl111l1I1I1I1Il1lllll11llllII1llI1 as Object) as Object
_lllI11I1ll1l11IIl111I1IIIIlll111III = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("272104f5358614c239a34ae1b74069f10ae6c760b60058c4b9") + _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 + Chr(47) + _llI11I11l111IlllllIlIllllllII1llII1l11l + _llIIlIll1llIlII1lI1lIlI1l1lI111("3787a42732e538f3d5896cf69a3db8abaeb1e47f48953823b62914b71abc18fb7e")
_lllI11IlIlll11IIII1l1lIIll1111Ill1II11llllI = HC_Get(_llIIlIl111l1I1I1I1Il1lllll11llllII1llI1, _lllI11I1ll1l11IIl111I1IIIIlll111III, {}, 6000)
_lll11l1I1llI11II11III1IIIlIllIl1II1lllI = ""
_lllIl1I1lIll1I111lI1III11IIIII1lIIl1lllIlIl = ""
_ll1lIIlIlIllIl1l1lI1IlIl1Ill11IlllI = ""
if _lllI11IlIlll11IIII1l1lIIll1111Ill1II11llllI <> invalid and _lllI11IlIlll11IIII1l1lIIll1111Ill1II11llllI.body <> "" then
_llII11II1IIIIlIIlIl1I1IIl111I1l = ParseJSON(_lllI11IlIlll11IIII1l1lIIll1111Ill1II11llllI.body)
if type(_llII11II1IIIIlIIlIl1I1IIl111I1l) = _llllIllII1II1I1ll1lll1lIlIII11I("702256f921266a2f9419efa319ed30686d41c7") then
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("629380d3a4ac") and _llII11II1IIIIlIIlIl1I1IIl111I1l.title <> invalid then _lll11l1I1llI11II11III1IIIlIllIl1II1lllI = _llII11II1IIIIlIIlIl1I1IIl111I1l.title
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = (Chr(116) + Chr(118)) and _llII11II1IIIIlIIlIl1I1IIl111I1l.name <> invalid then _lll11l1I1llI11II11III1IIIlIllIl1II1lllI = _llII11II1IIIIlIIlIl1I1IIl111I1l.name
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = _llIIlIll1llIlII1lI1lIlI1l1lI111("636984c7aa55") and _llII11II1IIIIlIIlIl1I1IIl111I1l.release_date <> invalid then _lllIl1I1lIll1I111lI1III11IIIII1lIIl1lllIlIl = Left(_llII11II1IIIIlIIlIl1I1IIl111I1l.release_date, 4)
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = (Chr(116) + Chr(118)) and _llII11II1IIIIlIIlIl1I1IIl111I1l.first_air_date <> invalid then _lllIl1I1lIll1I111lI1III11IIIII1lIIl1lllIlIl = Left(_llII11II1IIIIlIIlIl1I1IIl111I1l.first_air_date, 4)
if _llII11II1IIIIlIIlIl1I1IIl111I1l.external_ids <> invalid and type(_llII11II1IIIIlIIlIl1I1IIl111I1l.external_ids) = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4022e6a47ea581f6fea33f722d8f6f6188e99f") then
if _llII11II1IIIIlIIlIl1I1IIl111I1l.external_ids.imdb_id <> invalid then _ll1lIIlIlIllIl1l1lI1IlIl1Ill11IlllI = _llII11II1IIIIlIIlIl1I1IIl111I1l.external_ids.imdb_id
end if
end if
end if
_ll1lIlII1ll1lI1lI1l11IllIIIIlllllIl = [_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4f0e47b4a5a9b9f8"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("35c635c5"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("343738263a2d062a1822081b")]
_ll1l1111Illllll11ll1I11IlI11I111111 = {
"Referer": _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("411b0e3ecd9c1d48e05ec07accdbadc82d5880f9921eed8a2c9992")
"Origin": _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("2a8f31862e8c589043c658b24bb753d200d40adcf5c7e099818b")
"Accept": _llllIllII1II1I1ll1lll1lIlIII11I("6c487d52")
}
for each _lll1IIl1lI1llll1IllII1I11II1lIllI1l11l1 in _ll1lIlII1ll1lI1lI1l11IllIIIIlllllIl
_llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("35b92c05be68eefdd6a9a5755b0af8394ae27789ecd31348") + _lll1IIl1lI1llll1IllII1I11II1lIllI1l11l1 + _llIIlIll1llIlII1lI1lIlI1l1lI111("4f31da4500f386a11c79526d507bb071a487d22582b3e6c91467b4") + U_UrlEncode(_lll11l1I1llI11II11III1IIIlIllIl1II1lllI) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("54f518f402f035cc03cc11ed") + _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5da96c39121e5d") + U_UrlEncode(_lllIl1I1lIll1I111lI1III11IIIII1lIIl1lllIlIl)
if _ll1I1I1IlIlII11I11I1lII1I1Il11Il111 = (Chr(116) + Chr(118)) then
_llI11I111I111IIlIlIllI111I1lI11 = Chr(49)
_lllIlIllllII11llI11IlII1lIIlI1llII1llIl = Chr(49)
if _llII1IlllIIl11Il1llllII1lIl11I1 <> "" then _llI11I111I111IIlIlIllI111I1lI11 = _llII1IlllIIl11Il1llllII1lIl11I1
if _llII1lIl1ll1lIlI1Ill1l1lIIlI1I1 <> "" then _lllIlIllllII11llI11IlII1lIIlI1llII1llIl = _llII1lIl1ll1lIlI1Ill1l1lIIlI1I1
_llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 = _llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("549cbf229c317e8d5c077c72") + _llI11I111I111IIlIlIllI111I1lI11 + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("36a964b67bad58a564813a") + _lllIlIllllII11llI11IlII1lIIlI1llII1llIl
end if
_llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 = _llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11 + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("2f937a83688c7ca83e") + _llI11I11l111IlllllIlIllllllII1llII1l11l + _llIIlIll1llIlII1lI1lIlI1l1lI111("3af283ae01fcae2267") + U_UrlEncode(_ll1lIIlIlIllIl1l1lI1IlIl1Ill11IlllI)
_llI11llIl11l11I1IIIIIl111II1ll1II1I1II1 = HC_Get(_llIIlIl111l1I1I1I1Il1lllll11llllII1llI1, _llllI1111l1II1I1Illll1I1Il1l1l1I1l11l111I11, _ll1l1111Illllll11ll1I11IlI11I111111, 8000)
if _llI11llIl11l11I1IIIIIl111II1ll1II1I1II1 = invalid or _llI11llIl11l11I1IIIIIl111II1ll1II1I1II1.body = "" then continue for
_llll11lII1lI1I1I1Il1III1I11lI1I1111IlIIlll1 = RP_VideasyDecrypt(U_Trim(_llI11llIl11l11I1IIIIIl111II1ll1II1I1II1.body), _llllIllIll11IllI1l1Il1IlIIllI11)
if _llll11lII1lI1I1I1Il1III1I11lI1I1111IlIIlll1 = "" then continue for
_lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111 = ParseJSON(_llll11lII1lI1I1I1Il1III1I11lI1I1111IlIIlll1)
if _lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111 = invalid or type(_lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("28546fd0e0d7fa6267df21eb2ffbeb13ca95ce") then continue for
_llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI = _lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111.sources
if _llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI = invalid or type(_llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("740ed7868a61146d") or _llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI.Count() = 0 then continue for
_ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l = ""
for each _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I in _llI1l1llII1I1Il11111llIIlI1II1IIIll11I1IllI
if type(_ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I) <> _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3f988e3461d82e7f8d9c303fa11c253a02de71") then continue for
if _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.url <> invalid and _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.url <> "" then
_ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l = _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.url
exit for
end if
if _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.file <> invalid and _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.file <> "" then
_ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l = _ll1l11111ll1Illl1I1lll1I1l1IIl1111ll1IlIl1I.file
exit for
end if
end for
if _ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l = "" then continue for
_llII1111IlIIIlll1llII1I1111l111 = []
if _lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111.subtitles <> invalid and type(_lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111.subtitles) = _llIIlIll1llIlII1lI1lIlI1l1lI111("4dd5c882f601a46f") then
for each _lll11Il1111lI1l1I1I1l11Il1lIIlI in _lllIIIl1IllI1I1II1lIlI1111l1l11I1lII111.subtitles
if type(_lll11Il1111lI1l1I1I1l11Il1lIIlI) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("787639a60b3a146f75dd9063310248479f478a") then continue for
_ll1I111l1lIlII1I11lIlIl1lllIIII = ""
if _lll11Il1111lI1l1I1I1l11Il1lIIlI.url <> invalid then _ll1I111l1lIlII1I11lIlIl1lllIIII = _lll11Il1111lI1l1I1I1l11Il1lIIlI.url
if _ll1I111l1lIlII1I11lIlIl1lllIIII = "" and _lll11Il1111lI1l1I1I1l11Il1lIIlI.file <> invalid then _ll1I111l1lIlII1I11lIlIl1lllIIII = _lll11Il1111lI1l1I1I1l11Il1lIIlI.file
if _ll1I111l1lIlII1I11lIlIl1lllIIII = "" then continue for
_lll1lll1II1III1l11lIll1111I1l1lI11I1llI = (Chr(101) + Chr(110))
if _lll11Il1111lI1l1I1I1l11Il1lIIlI.language <> invalid then _lll1lll1II1III1l11lIll1111I1l1lI11I1llI = LCase(Left(_lll11Il1111lI1l1I1I1l11Il1lIIlI.language, 2))
if _lll1lll1II1III1l11lIll1111I1l1lI11I1llI = "" and _lll11Il1111lI1l1I1I1l11Il1lIIlI.lang <> invalid then _lll1lll1II1III1l11lIll1111I1l1lI11I1llI = LCase(Left(_lll11Il1111lI1l1I1I1l11Il1lIIlI.lang, 2))
_llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl = ""
if _lll11Il1111lI1l1I1I1l11Il1lIIlI.label <> invalid then _llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl = _lll11Il1111lI1l1I1I1l11Il1lIIlI.label
if _llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl = "" then _llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl = UCase(_lll1lll1II1III1l11lIll1111I1l1lI11I1llI)
_llII1111IlIIIlll1llII1I1111l111.Push({ url: _ll1I111l1lIlII1I11lIlIl1lllIIII, language: _lll1lll1II1III1l11lIll1111I1l1lI11I1llI, name: _llIlI1I1I1I1II1llIllIlI1l1IlIl11lIl })
end for
end if
return {
url: _ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l
streamFormat: U_StreamFormat(_ll1IIl1lllllIIl1ll11ll1IIII11IIII1I1I1l)
qualities: []
subtitles: _llII1111IlIIIlll1llII1I1111l111
chapters: []
referer: _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("407b5b724478326429323246214339266a2060289f338a6df16fe72d")
userAgent: ""
}
end for
return invalid
end function
function RP_VideasyDecrypt(_ll1I1Il1III1Ill1I11lIl1lIlIl1lIl1ll as String, _llII1lIl11II11lI11IlIIIlII1IIIlI111 as LongInteger) as String
if _ll1I1Il1III1Ill1I11lIl1lIlIl1lIl1ll = invalid or _ll1I1Il1III1Ill1I11lIl1lIlIl1lIl1ll = "" then return ""
_llll11IllI11II111ll1lI1l1III1lII1ll1l1l = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("676c5f03c5a83b27b9c44712"))
_llll11IllI11II111ll1lI1l1III1lII1ll1l1l.FromHexString(_ll1I1Il1III1Ill1I11lIl1lIlIl1lIl1ll)
if _llll11IllI11II111ll1lI1l1III1lII1ll1l1l.Count() = 0 then return ""
_lllIlIIIll1II111I1I1I11lII1I1I1I1lIlI1l1II1 = RP_VkLcgBytes(_llII1lIl11II11lI11IlIIIlII1IIIlI111, 50)
_llllllI1lIllI111llII1lI11III1IlIlIllIIl1ll1 = RP_VkSerializeBytes(_lllIlIIIll1II111I1I1I11lII1I1I1I1lIlI1l1II1)
_lllIlI1II1I111llIIIIl1IIl1lIlIlI11l1111IlIl = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("69fb6e84323b0f6430786c9a"))
_lllIlI1II1I111llIIIIl1IIl1lIlIlI11l1111IlIl.FromAsciiString(_llllllI1lIllI111llII1lI11III1IlIlIllIIl1ll1)
_llIll1IIl1I1Il1IlI1lI1lI11Ill1lIII1 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3f2134262c2c4670082c5f01561d5e20563b5032a839b2358d398927805a8e40d62ad022c424687e7074744f7a53712b79317c6e116e5138a238ff71f64aaf05a678a674b2728a7d9425c38e9890c4")
_ll1I1Il1l1lI11IIl1lll1lIIIII1I111l11IIll1lI = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("29a15158d62c371fc86b9975"))
_ll1I1Il1l1lI11IIl1lll1lIIIII1I111l11IIll1lI.FromHexString(_llIll1IIl1I1Il1IlI1lI1lI11Ill1lIII1)
_llI11IlI1l1IlIl1lll1lIIIII111IlI1I1llll11Il = R4_KSA(_ll1I1Il1l1lI11IIl1lll1lIIIII1I111l11IIll1lI)
_llllllIIlIlI1lI11111I1lIlllIII1l111llIlI1I1 = R4_PRGA(_llI11IlI1l1IlIl1lll1lIIIII111IlI1I1llll11Il, _lllIlI1II1I111llIIIIl1IIl1lIlIlI11l1111IlIl)
_llII1111lIIIlIlII1l1l11l1lIII1llIIlII11ll11 = R4_KSA(_llllllIIlIlI1lI11111I1lIlllIII1l111llIlI1I1)
_llIlI1Illlll1Ill1lII1llllIl11Il = R4_PRGA(_llII1111lIIIlIlII1l1l11l1lIII1llIIlII11ll11, _llll11IllI11II111ll1lI1l1III1lII1ll1l1l)
if _llIlI1Illlll1Ill1lII1llllIl11Il.Count() < 32 then return ""
if _llIlI1Illlll1Ill1lII1llllIl11Il[0] <> 83 or _llIlI1Illlll1Ill1lII1llllIl11Il[1] <> 97 or _llIlI1Illlll1Ill1lII1llllIl11Il[2] <> 108 or _llIlI1Illlll1Ill1lII1llllIl11Il[3] <> 116 then return ""
if _llIlI1Illlll1Ill1lII1llllIl11Il[4] <> 101 or _llIlI1Illlll1Ill1lII1llllIl11Il[5] <> 100 or _llIlI1Illlll1Ill1lII1llllIl11Il[6] <> 95 or _llIlI1Illlll1Ill1lII1llllIl11Il[7] <> 95 then return ""
_llIIIII1lI1II11IllIIlI1l1IlI11I = B_Slice(_llIlI1Illlll1Ill1lII1llllIl11Il, 8, 16)
_lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = B_Slice(_llIlI1Illlll1Ill1lII1llllIl11Il, 16, _llIlI1Illlll1Ill1lII1llllIl11Il.Count())
_lll11l1IIIlIl1I11IlI1I1lIl1I1II11l11II11III = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("435060865462769565687e69"))
_ll11ll1l11ll1IlI1lllII1I1lIl1l11lIIIlll = EvpBytesToKey(_lll11l1IIIlIl1I11IlI1I1lIl1I1II11l11II11III, _llIIIII1lI1II11IllIIlI1l1IlI11I, 32)
if _ll11ll1l11ll1IlI1lllII1I1lIl1l11lIIIlll.Count() < 32 then return ""
_lll1IlIIIIlI1l1l1I1lIIIlI11lII1IlI1IIII = B_Slice(_ll11ll1l11ll1IlI1lllII1I1lIl1l11lIIIlll, 0, 16)
_llI11l1lll1I1Il1ll1l1l1IlI1I11I1llI1l111IlI = B_Slice(_ll11ll1l11ll1IlI1lllII1I1lIl1l11lIIIlll, 16, 32)
_llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll = _lll1IlIIIIlI1l1l1I1lIIIlI11lII1IlI1IIII.ToHexString()
_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11 = _llI11l1lll1I1Il1ll1l1l1IlI1I11I1llI1l111IlI.ToHexString()
_llI111llI1I1llII1lllI1I11II11IlIll1 = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("6f102805f5fe103d27423a2e"))
_llI11II1III111I1lIIlIll1ll11II11111 = _llI111llI1I1llII1lllI1I11II11IlIll1.Setup(false, _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4d23223be0ff03fcec3d3f43"), _llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll, _ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11, 1)
if _llI11II1III111I1lIIlIll1ll11II11111 <> 0 then return ""
_ll1lIl1IlI1I1lllII11l1I1ll1I11I = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("38ced0df13c3fe986dc519ca"))
_llII1111l11lll1lllIlll1II1lIlll1I1l = _llI111llI1I1llII1lllI1I11II11IlIll1.Process(_lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1)
if _llII1111l11lll1lllIlll1II1lIlll1I1l <> invalid then
for _ll1III11llIl1lIIlIl1lI1l1IlllII = 0 to _llII1111l11lll1lllIlll1II1lIlll1I1l.Count() - 1
_ll1lIl1IlI1I1lllII11l1I1ll1I11I.Push(_llII1111l11lll1lllIlll1II1lIlll1I1l[_ll1III11llIl1lIIlIl1lI1l1IlllII])
end for
end if
_lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II = _llI111llI1I1llII1lllI1I11II11IlIll1.Final()
if _lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II <> invalid then
for _ll1III11llIl1lIIlIl1lI1l1IlllII = 0 to _lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II.Count() - 1
_ll1lIl1IlI1I1lllII11l1I1ll1I11I.Push(_lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II[_ll1III11llIl1lIIlIl1lI1l1IlllII])
end for
end if
if _ll1lIl1IlI1I1lllII11l1I1ll1I11I.Count() = 0 then return ""
return _ll1lIl1IlI1I1lllII11l1I1ll1I11I.ToAsciiString()
end function
function RP_VkLcgBytes(_llIl1Il111I1Il11I1l1IllIl1lIlI1II111l1l as LongInteger, _llI1lIlI11llI11lI11I11I11I111I1lIl1 as Integer) as Object
_ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2ee0a15a7f6c624e002ac99f"))
_ll1lI1I11IIll1I11lIl1llI111Il1l1lIll1Il# = _llIl1Il111I1Il11I1l1IllIl1lIlI1II111l1l AND 2147483647&
for _lll1111I11lIl1ll1llI11IIl1IIIl1l1ll1I11II1I = 1 to _llI1lIlI11llI11lI11I11I11I111I1lIl1
_ll1lI1I11IIll1I11lIl1llI111Il1l1lIll1Il# = (_ll1lI1I11IIll1I11lIl1llI111Il1l1lIll1Il# * 1103515245& + 12345&) AND 2147483647&
_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I# = _ll1lI1I11IIll1I11lIl1llI111Il1l1lIll1Il# mod 255&
_ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl.Push(_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I#)
end for
return _ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl
end function
function RP_VkSerializeBytes(_lllIIlIII1lIl11lI1II1lIIIIl1lIl as Object) as String
if _lllIIlIII1lIl11lI1II1lIIIIl1lIl = invalid or _lllIIlIII1lIl11lI1II1lIIIIl1lIl.Count() = 0 then return ""
_ll11IlIII111IlI11Il1III1III11I1lIIl = ""
_ll11IllI11lI1lIl11llI1lll1IlI1I = _lllIIlIII1lIl11lI1II1lIIIIl1lIl.Count()
for _llI1IIlll111Il1ll1IlI1I1llII111 = 0 to _ll11IllI11lI1lIl11llI1lll1IlI1I - 1
if _llI1IIlll111Il1ll1IlI1I1llII111 > 0 then _ll11IlIII111IlI11Il1III1III11I1lIIl = _ll11IlIII111IlI11Il1III1III11I1lIIl + Chr(44)
_ll11IlIII111IlI11Il1III1III11I1lIIl = _ll11IlIII111IlI11Il1III1III11I1lIIl + _lllIIlIII1lIl11lI1II1lIIIIl1lIl[_llI1IIlll111Il1ll1IlI1I1llII111].ToStr()
end for
return _ll11IlIII111IlI11Il1III1III11I1lIIl
end function
function RP_ResolvePeachify(_ll11I1I11lI11lIll111l1lII1Il1Il as String, _ll1IIIllIll11IIlll1lllIII1ll1l1IllI as String, _ll1I1I1l1l1ll1III111IlIlII111I1I11llllIII1l as Object) as Object
_ll11lI1llIII1lIllI11I11lll1111l = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4b4bb9fdab241de7"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4fda4f9656867683748271a47cba07bb43f54cfc9fcdcfc6f5d8f7d4fbd9cc8fc5b0c5cde68b1b8216"), Chr(105))
m = _ll11lI1llIII1lIllI11I11lll1111l.match(_ll11I1I11lI11lIll111l1lII1Il1Il)
if m = invalid or m.Count() < 3 then return invalid
_ll11lIlIl11l1Il1lIl1lII1Il1ll11 = m[1]
_ll11III1llIlIlI11IIIIll11I1l1Ill1ll1lll1l11 = m[2]
_lll1IlI1I1I1l11llI11I11lIII1l1IllIIlll1 = ""
_lllIIlllI1IIII1l1lII11Il1Il1l1l = ""
if m.Count() >= 5 then
_lll1IlI1I1I1l11llI11I11lIII1l1IllIIlll1 = m[3]
_lllIIlllI1IIII1l1lII11Il1Il1l1l = m[4]
end if
_llIIlll1I1I1ll111l1IlI11I1lllIl = [
{ host: _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("22d9494bc4654e256b0091c1d6cc5fdf692a"),  path: _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("67261fc42dc3") },
{ host: _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("77e8aab9216da5fc7e1122f101775695ae3b"),  path: _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6bfb10dde1ba9398cc") },
{ host: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("6056ddb66304da873694c6edb4f3c7355743"),  path: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("752a9c0c6746") },
{ host: _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7b17181d75333228842a4241424e933b4d41"),  path: _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("71337d2b") },
{ host: _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("49ae3481db6313e60487bc0a0b59408c641d"),  path: _llllIllII1II1I1ll1lll1lIlIII11I("27058a1e") }
]
_lllII1lIlII111ll1l1111l1I1lIIIlIl1I = {
"Referer": _llllIllII1II1I1ll1lll1lIlIII11I("2bd2181d629708dce17b4f94b90e23782efe681cb222")
"Origin": _llIIlIll1llIlII1lI1lIlI1l1lI111("6638e3ee192c01646f50b3def9bcbf0255da93e6c9")
"Accept": _llllIllII1II1I1ll1lll1lIlIII11I("3d07fb00469b0025d9af54495a93276d62")
}
for each _ll1II1I1l11l11111IlIIl11llIlI1lIIlI in _llIIlll1I1I1ll111l1IlI11I1lllIl
_ll11II11lI1llIlIll111lllll1l1l1 = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("271d3c14231e55024e") + _ll1II1I1l11l11111IlIIl11llIlI1lIIlI.host + Chr(47) + _ll1II1I1l11l11111IlIIl11llIlI1lIIlI.path + Chr(47) + _ll11lIlIl11l1Il1lIl1lII1Il1ll11 + Chr(47) + _ll11III1llIlIlI11IIIIll11I1l1Ill1ll1lll1l11
if _ll11lIlIl11l1Il1lIl1lII1Il1ll11 = (Chr(116) + Chr(118)) and _lll1IlI1I1I1l11llI11I11lIII1l1IllIIlll1 <> "" and _lllIIlllI1IIII1l1lII11Il1Il1l1l <> "" then
_ll11II11lI1llIlIll111lllll1l1l1 = _ll11II11lI1llIlIll111lllll1l1l1 + Chr(47) + _lll1IlI1I1I1l11llI11I11lIII1l1IllIIlll1 + Chr(47) + _lllIIlllI1IIII1l1lII11Il1Il1l1l
end if
_ll1111111lllll1IllIlI1IIl111lIl = HC_Get(_ll1I1I1l1l1ll1III111IlIlII111I1I11llllIII1l, _ll11II11lI1llIlIll111lllll1l1l1, _lllII1lIlII111ll1l1111l1I1lIIIlIl1I, 8000)
if _ll1111111lllll1IllIlI1IIl111lIl = invalid or _ll1111111lllll1IllIlI1IIl111lIl.body = "" then continue for
_llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1 = ParseJSON(_ll1111111lllll1IllIlI1IIl111lIl.body)
if _llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1 = invalid or type(_llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("4022e6a47ea581f6fea33f722d8f6f6188e99f") then continue for
if _llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1.isEncrypted <> true then continue for
_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I = _llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1.data
if _llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I = invalid or type(_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I) <> _llllIllII1II1I1ll1lll1lIlIII11I("4a76aa72658a1ed348") then continue for
_ll1l1III11I11I111111IIl1l1l1IlI = RP_PeachifyDecrypt(_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I)
if _ll1l1III11I11I111111IIl1l1l1IlI = "" then continue for
_lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I = ParseJSON(_ll1l1III11I11I111111IIl1l1l1IlI)
if _lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I = invalid or type(_lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("667d7c5a555376566757753361394a3341395e") then continue for
_ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l = _lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I.sources
if _ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l = invalid or type(_ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l) <> _llllIllII1II1I1ll1lll1lIlIII11I("35186e51272c62e6") or _ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l.Count() = 0 then continue for
_ll1Illl1l11Il1lII11I1IIlIIIIlII = ""
for each _llIIIIlI11III111Illlll1lI1l1111I1lI in _ll11lIl11lI1l1ll1IIllIlIIl1lI1l1l1l
if type(_llIIIIlI11III111Illlll1lI1l1111I1lI) <> _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("48b0cee7b8bbdad1ded9d1e7d5e908daddf1ec") then continue for
if _llIIIIlI11III111Illlll1lI1l1111I1lI.url <> invalid and _llIIIIlI11III111Illlll1lI1l1111I1lI.url <> "" then
_ll1Illl1l11Il1lII11I1IIlIIIIlII = _llIIIIlI11III111Illlll1lI1l1111I1lI.url
exit for
end if
if _llIIIIlI11III111Illlll1lI1l1111I1lI.file <> invalid and _llIIIIlI11III111Illlll1lI1l1111I1lI.file <> "" then
_ll1Illl1l11Il1lII11I1IIlIIIIlII = _llIIIIlI11III111Illlll1lI1l1111I1lI.file
exit for
end if
end for
if _ll1Illl1l11Il1lII11I1IIlIIIIlII = "" then continue for
_ll1I11Il1lIllIlllIII1lIII1llllIIl11 = []
if _lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I.subtitles <> invalid and type(_lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I.subtitles) = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("7d1767304f396328") then
for each _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI in _lllIlII1I11llI1lll1IlIll1lIll11llII11lI1I1I.subtitles
if type(_llIlI1IlIIIIlI1ll1lll1IIlIIlIlI) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("6b083b97313c67d28dd83bae61e410a2ad307b") then continue for
_lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = ""
if _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.url <> invalid then _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.url
if _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = "" and _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.file <> invalid then _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.file
if _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI = "" then continue for
_ll1llI111l1I1I11IIIlllI1l1ll11I1llI = (Chr(101) + Chr(110))
if _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.language <> invalid then _ll1llI111l1I1I11IIIlllI1l1ll11I1llI = LCase(Left(_llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.language, 2))
_ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 = ""
if _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.label <> invalid then _ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 = _llIlI1IlIIIIlI1ll1lll1IIlIIlIlI.label
if _ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 = "" then _ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 = UCase(_ll1llI111l1I1I11IIIlllI1l1ll11I1llI)
_ll1I11Il1lIllIlllIII1lIII1llllIIl11.Push({ url: _lllllIlIIIII1Ill1I1I1lIIll1III1l1llIllI, language: _ll1llI111l1I1I11IIIlllI1l1ll11I1llI, name: _ll1I1l1l11lIIIIl1l111lIIIII1Il1I111 })
end for
end if
_lllII1l1I1l1I11lI11IIll11l11l11Il1lIlI1llII = U_StreamFormat(_ll1Illl1l11Il1lII11I1IIlIIIIlII)
_lll11ll1IIllIII1lII1I1l111ll11III1l = LCase(_ll1Illl1l11Il1lII11I1IIlIIIIlII)
if Instr(1, _lll11ll1IIllIII1lII1I1l111ll11III1l, _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("55e718d523")) > 0 then
_lllII1l1I1l1I11lI11IIll11l11l11Il1lIlI1llII = _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("56e755f1")
else if Instr(1, _lll11ll1IIllIII1lII1I1l111ll11III1l, _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("3a7595d4")) > 0 then
_lllII1l1I1l1I11lI11IIll11l11l11Il1lIlI1llII = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3fe9a688")
end if
return {
url: _ll1Illl1l11Il1lII11I1IIlIIIIlII
streamFormat: _lllII1l1I1l1I11lI11IIll11l11l11Il1lIlI1llII
qualities: []
subtitles: _ll1I11Il1lIllIlllIII1lIII1llllIIl11
chapters: []
referer: _llllIllII1II1I1ll1lll1lIlIII11I("4bb8fe03487deec2c761357a9ff4095e14e44e029808")
userAgent: ""
}
end for
return invalid
end function
function RP_PeachifyDecrypt(_ll1III11llI1lIIlI1lllIIlIl1Illl as String) as String
if _ll1III11llI1lIIlI1lllIIlIl1Illl = invalid or _ll1III11llI1lIIlI1lllIIlIl1Illl = "" then return ""
_lllIIl1Il1I1IlIll1I1I1IlIl11111 = _ll1III11llI1lIIlI1lllIIlIl1Illl.Tokenize(Chr(46))
if _lllIIl1Il1I1IlIll1I1I1IlIl11111 = invalid or _lllIIl1Il1I1IlIll1I1I1IlIl11111.Count() < 3 then return ""
_ll1lIIll1111l1I1IIl1l1Il11II1ll = HC_Base64UrlDecode(_lllIIl1Il1I1IlIll1I1I1IlIl11111[0])
_ll1lI11ll11ll1lll11IlI1IlIllIlI = HC_Base64UrlDecode(_lllIIl1Il1I1IlIll1I1I1IlIl11111[1])
_lll1I1Il11l111ll1l11lII1IIlII1I = HC_Base64UrlDecode(_lllIIl1Il1I1IlIll1I1I1IlIl11111[2])
if _ll1lIIll1111l1I1IIl1l1Il11II1ll.Count() <> 12 then return ""
if _lll1I1Il11l111ll1l11lII1IIlII1I.Count() <> 16 then return ""
_ll1Il1IlIlIlI1I11l1Ill1lII1111IlIl1I11I1llI = _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("60c10dca19cd20d22add24dd373739343e46f74af94cfe51065d115816671b631c712476297b2e883b8d408d459748944d9a52575fad64b26bba6cc477c976cf7d")
_ll1lIII1IlI1III11I1I11I1l1Ill1I11ll = AGD_Decrypt(_ll1Il1IlIlIlI1I11l1Ill1lII1111IlIl1I11I1llI, _ll1lIIll1111l1I1IIl1l1Il11II1ll, _ll1lI11ll11ll1lll11IlI1IlIllIlI, _lll1I1Il11l111ll1l11lII1IIlII1I)
if _ll1lIII1IlI1III11I1I11I1l1Ill1I11ll = invalid then return ""
return _ll1lIII1IlI1III11I1I11I1l1Ill1I11ll.ToAsciiString()
end function
function RP_ResolvePrimesrc(_lllI11I1ll1I1I1ll1l1IllI11IIlIl as String, _ll1lIllII1II11I1l11111I1IllI11l as String, _llllI11I1llIllIIIll1lIlIl1111I1lIll1Ill as Object) as Object
return invalid
end function
function RP_ResolveStreamtape(_ll11IIlIIIlI1ll1IIl111IIIll1I1Ill11 as String, _ll11ll11lIlIll1lllI1I1lIlIll1l1 as String, _llIIl11lIIl11II11lIIlI1lll1I1l1 as Object) as Object
_llIIllll1lII1l11lllI1IIII1lII11 = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("5b5070767071766c"), _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("3e8fbecbe1c99e9cd0d9a8fac2b1e3bcbac9f2c3f6c7c8"), Chr(105))
_ll11IIl1l11IIll1II111I1II11I1llIlIl = _llIIllll1lII1l11lllI1IIII1lII11.match(_ll11IIlIIIlI1ll1IIl111IIIll1I1Ill11)
if _ll11IIl1l11IIll1II111I1II11I1llIlIl = invalid or _ll11IIl1l11IIll1II111I1II11I1llIlIl.Count() < 2 then return invalid
_lllI1I1ll1II1Il11llIII1l1II1111lI1l = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("580b7d248e27694a1960372fb75f69eb591aaf7dbc94a33ac069") + _ll11IIl1l11IIll1II111I1II11I1llIlIl[1]
_llIlllII1lI111l1Ill1l111lI1I1llIllll1l11lII = {}
if _ll11ll11lIlIll1lllI1I1lIlIll1l1 <> "" then _llIlllII1lI111l1Ill1l111lI1I1llIllll1l11lII[_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7694c8cecec0d4c6")] = _ll11ll11lIlIll1lllI1I1lIlIll1l1
_llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1 = HC_Get(_llIIl11lIIl11II11lIIlI1lll1I1l1, _lllI1I1ll1II1Il11llIII1l1II1111lI1l, _llIlllII1lI111l1Ill1l111lI1I1llIllll1l11lII, 8000)
if _llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1 = invalid or _llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1.body = "" then return invalid
_lllI1llll11Il1I1I1III1111111lIIIIlI11II = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("2c101900fd5359237fa05ac33f8a5b62bbd1dbcea34d51224be31e413a925d2338921910e8025b22fa109c09248a52904da08b")
_llI1l1lIlII1Il1l1IlI11Ill1I1IIIlIlllIIlI1l1 = Instr(1, _llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1.body, _lllI1llll11Il1I1I1III1111111lIIIIlI11II)
if _llI1l1lIlII1Il1l1IlI11Ill1I1IIIlIlllIIlI1l1 <= 0 then return invalid
_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = Mid(_llIl1II1ll1I1l1llIII1111IIll1Il1l1111I1llI1.body, _llI1l1lIlII1Il1l1IlI11Ill1I1IIIlIlllIIlI1l1 + Len(_lllI1llll11Il1I1I1III1111111lIIIIlI11II))
_lll11II1l1IIIIlII11llI1IIII1I11 = Instr(1, _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1, Chr(39))
if _lll11II1l1IIIIlII11llI1IIII1I11 <= 0 then return invalid
_ll11Illl1II1Illl11I1lI1l1ll11111Ill = Left(_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1, _lll11II1l1IIIIlII11llI1IIII1I11 - 1)
_ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5f75d765458224b6")
_llIlIIl1lI11IllI1lIlIIlIIIII11ll1ll = Instr(1, _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1, _ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII)
if _llIlIIl1lI11IllI1lIlIIlIIIII11ll1ll <= 0 then return invalid
_lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I = Mid(_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1, _llIlIIl1lI11IllI1lIlIIlIIIII11ll1ll + Len(_ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII))
_ll1lII1lll1l1IIllI11II1l11I11llI11IIlI1I1ll = Instr(1, _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I, Chr(39))
if _ll1lII1lll1l1IIllI11II1l11I11llI11IIlI1I1ll <= 0 then return invalid
_lll1IIl1lIlllIIIl1IIIllI11llllIl1l1IlI1I1I1 = Left(_lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I, _ll1lII1lll1l1IIllI11II1l11I11llI11IIlI1I1ll - 1)
_lllI1lllll111l1IllIlllI1IIllIl1I1I11IIlI1lI = _llllIllII1II1I1ll1lll1lIlIII11I("2c682c31f60b9c") + _ll11Illl1II1Illl11I1lI1l1ll11111Ill + _lll1IIl1lIlllIIIl1IIIllI11llllIl1l1IlI1I1I1
return {
url: _lllI1lllll111l1IllIlllI1IIllIl1I1I11IIlI1lI
streamFormat: U_StreamFormat(_lllI1lllll111l1IllIlllI1IIllIl1I1I11IIlI1lI)
qualities: []
subtitles: []
chapters: []
referer: _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("2d3aa28b3cee617ea74af4bd69923aba150b600412bb4cc9")
userAgent: ""
}
end function
function RP_ResolveUqload(_llIIllll1ll1Il111IIl1lIIl1lIl11l1llIIII as String, _ll11IllII11I1lll11II1I11Il1ll1I11l11IlI as String, _llIlI11I1lIlI1l1I1lI1lIll1lllll as Object) as Object
_llII1l11llI11l111IIIl11II1I11llIIII = {}
if _ll11IllII11I1lll11II1I11Il1ll1I11l11IlI <> "" then _llII1l11llI11l111IIIl11II1I11llIIII[_llllIllII1II1I1ll1lll1lIlIII11I("2d5d4f24596f6379")] = _ll11IllII11I1lll11II1I11Il1ll1I11l11IlI
_llI1Il1lI1lIl11lllllIII1lIIllI1II11IlIl = HC_Get(_llIlI11I1lIlI1l1I1lI1lIll1lllll, _llIIllll1ll1Il111IIl1lIIl1lIl11l1llIIII, _llII1l11llI11l111IIIl11II1I11llIIII, 8000)
if _llI1Il1lI1lIl11lllllIII1lIIllI1II11IlIl = invalid or _llI1Il1lI1lIl11lllllIII1lIIllI1II11IlIl.body = "" then return invalid
_ll1111IIllllll1lIlI1I1IIl1ll1I11IIl111I = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4d5757637b68467c"), _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("287c6f6ad8d4eb65ec325832476eb4cc9a") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("3e0ee035") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("56640a2f") + chr(34), Chr(105))
m = _ll1111IIllllll1lIlI1I1IIl1ll1I11IIl111I.match(_llI1Il1lI1lIl11lllllIII1lIIllI1II11IlIl.body)
if m = invalid or m.Count() < 2 then return invalid
_llllIIllI1111I1I1II11lIllI1111Illl1llII11ll = m[1]
if Left(_llllIIllI1111I1I1II11lIllI1111Illl1llII11ll, 4) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("51354a3c55") then return invalid
return {
url: _llllIIllI1111I1I1II11lIllI1111Illl1llII11ll
streamFormat: U_StreamFormat(_llllIIllI1111I1I1II11lIllI1111Illl1llII11ll)
qualities: []
subtitles: []
chapters: []
referer: _llIIlIll1llIlII1lI1lIlI1l1lI111("4653fe0934471c7f8a436ea1b40f02dfa0cbf8")
userAgent: ""
}
end function
function RP_ResolveDoodstream(_llI1I1I1111IlIl1IlII1l11IlIIll1 as String, _ll11IIllI1IIl1lIlI1II1l11l11l11IIII as String, _llIIlIl1IIlI11IIl1l111I11lI1I11Il11I1ll1IlI as Object) as Object
_ll11ll1l11l11llIlI1l11IIIIll1lIll1II1IllI11 = {}
if _ll11IIllI1IIl1lIlI1II1l11l11l11IIII <> "" then _ll11ll1l11l11llIlI1l11IIIIll1lIll1II1IllI11[_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7d34626668606e66")] = _ll11IIllI1IIl1lIlI1II1l11l11l11IIII
_ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill = HC_Get(_llIIlIl1IIlI11IIl1l111I11lI1I11Il11I1ll1IlI, _llI1I1I1111IlIl1IlII1l11IlIIll1, _ll11ll1l11l11llIlI1l11IIIIll1lIll1II1IllI11, 8000)
if _ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill = invalid or _ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.body = "" then return invalid
_llll111IIIIll1IIl11I1I1lllII1II = _ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.finalUrl
if _llll111IIIIll1IIl11I1I1lllII1II = invalid or _llll111IIIIll1IIl11I1I1lllII1II = "" then _llll111IIIIll1IIl11I1I1lllII1II = _llI1I1I1111IlIl1IlII1l11IlIIll1
if Instr(1, _ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.body, _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("43d572d7092606a8389e58")) <= 0 then return invalid
_ll1IllIIl1IIIlll11llllIl1l1l11l1IllIII1 = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("732d4027920ae30f"), _llllIllII1II1I1ll1lll1lIlIII11I("6e6ddfd3b9be85a73c369a5eb329") + chr(34) + (Chr(93) + Chr(43)), Chr(105))
_llIl1IIlI1IIIIl1IIllI1llIII1IIIIl11l1Il = _ll1IllIIl1IIIlll11llllIl1l1l11l1IllIII1.match(_ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.body)
if _llIl1IIlI1IIIIl1IIllI1llIII1IIIIl11l1Il = invalid or _llIl1IIlI1IIIIl1IIllI1llIII1IIIIl11l1Il.Count() < 1 then return invalid
_lll1I1IlllI111IIllIlll1Il1I1lI11III = _llIl1IIlI1IIIIl1IIllI1llIII1IIIIl11l1Il[0]
_llII11IIlI11IlIllI11lIlll1IllIIII11 = HC_OriginOf(_llll111IIIIll1IIl11I1I1lllII1II)
if _llII11IIlI11IlIllI11lIlll1IllIIII11 = "" then return invalid
_lllII1111l1lIlI1lllIlllIl1111l1lllI = _llII11IIlI11IlIllI11lIlll1IllIIII11 + _lll1I1IlllI111IIllIlll1Il1I1lI11III
_llll1l1lIIIIIll1l1l111I1II1l111 = 0
for _lllIIIlIIII1Il1II1llIlIl1IIl1I1I11I = 1 to Len(_lll1I1IlllI111IIllIlll1Il1I1lI11III)
if Mid(_lll1I1IlllI111IIllIlll1Il1I1lI11III, _lllIIIlIIII1Il1II1llIlIl1IIl1I1I11I, 1) = Chr(47) then _llll1l1lIIIIIll1l1l111I1II1l111 = _lllIIIlIIII1Il1II1llIlIl1IIl1I1I11I
end for
if _llll1l1lIIIIIll1l1l111I1II1l111 = 0 or _llll1l1lIIIIIll1l1l111I1II1l111 = Len(_lll1I1IlllI111IIllIlll1Il1I1lI11III) then return invalid
_llllIIl1IIll11I1I11lll1II1I1lll = Mid(_lll1I1IlllI111IIllIlll1Il1I1lI11III, _llll1l1lIIIIIll1l1l111I1II1l111 + 1)
_llIIl1IllI1I11lllI1I1lI11ll111IlIlI = HC_Get(_llIIlIl1IIlI11IIl1l111I11lI1I11Il11I1ll1IlI, _lllII1111l1lIlI1lllIlllIl1111l1lllI, { "Referer": _llll111IIIIll1IIl11I1I1lllII1II }, 8000)
if _llIIl1IllI1I11lllI1I1lI11ll111IlIlI = invalid or _llIIl1IllI1I11lllI1I1lI11ll111IlIlI.body = "" then return invalid
_lllII1IlII11lllI1IIl1l11l1IIIllIlIIllll11l1 = RP_RandomB62String(10)
_ll1lII1lI111ll11I1I1ll1l11I1IllI1Il1IIIlll1 = RP_NowMillis()
_llII1IlIl11l1I1l1IlI1111lII1I1ll1lII1llI1ll = _llIIl1IllI1I11lllI1I1lI11ll111IlIlI.body + _lllII1IlII11lllI1IIl1l11l1IIIllIlIIllll11l1 + _llIIlIll1llIlII1lI1lIlI1l1lI111("74a2873a652063f4") + _llllIIl1IIll11I1I11lll1II1I1lll + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("7496b52943a5324871") + _ll1lII1lI111ll11I1I1ll1l11I1IllI1Il1IIIlll1
_ll1lI1III1II1llI1lIIl1I1IlI11l1ll1I1lI1lll1 = ""
_llI1Ill1llIll1lIlllII1l111l1l1lI1IlIl11 = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("41675dcdaa59f94f"), _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("5a62189b6ee5dd5d4b9c57fad1975f97a2fb8a49fcb664"), Chr(105))
_lllI1I11IlI1lII1lIllIlll1lIII11 = _llI1Ill1llIll1lIlllII1l111l1l1lI1IlIl11.match(_ll1lIIlII1lI1111I1Il1lIII1IIl1llII11ll11Ill.body)
if _lllI1I11IlI1lII1lIllIlll1lIII11 <> invalid and _lllI1I11IlI1lII1lIllIlll1lIII11.Count() >= 2 then
_llIl1l1IIlll1lI111II1l111lllIll = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("30b0bed6cecfd4bc"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("34270a24120856ab51b816"), Chr(105))
_llI1I1lI1llI1IllI11Ill1l1llIIIlIlll = _llIl1l1IIlll1lI111II1l111lllIll.match(_lllI1I11IlI1lII1lIllIlll1lIII11[1])
if _llI1I1lI1llI1IllI11Ill1l1llIIIlIlll <> invalid and _llI1I1lI1llI1IllI11Ill1l1llIIIlIlll.Count() >= 2 then _ll1lI1III1II1llI1lIIl1I1IlI11l1ll1I1lI1lll1 = _llI1I1lI1llI1IllI11Ill1l1llIIIlIlll[1]
end if
return {
url: _llII1IlIl11l1I1l1IlI1111lII1I1ll1lII1llI1ll
streamFormat: U_StreamFormat(_llII1IlIl11l1I1l1IlI1111lII1I1ll1lII1llI1ll)
qualities: []
subtitles: []
chapters: []
referer: _llII11IIlI11IlIllI11lIlll1IllIIII11 + Chr(47)
userAgent: _llIIlIll1llIlII1lI1lIlI1l1lI111("5f8ca80b8eb1bcefe8a3f6911ce7eb073a7558230e7f7b36a03336b14c2fe2a6c2f5beb97c2f7cf5f023667afe0974c761ddd0a29e81e29d98c306b9dc3702261904575a648f7c6f8ae5c60a0601ccf7d01337ebc639347f58f306217c17922da843ce72ee210497da13cec9f437ea0d")
}
end function
function RP_RandomB62String(_ll11l1Il11IlI1II1l11ll111IIllII as Integer) as String
_ll1ll11l1I1lllII11I1lII1IlIl1ll = _llllIllII1II1I1ll1lll1lIlIII11I("485b90853a2f64590e03382de2d70c01b7ace1d68b80b5aa5f5489df1409beb3e8dd9287bcb1665b90853b30655a0f04392ee3d80d6e63988d42376c61160b")
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = ""
for _ll1IlIIII11l1I11Ill1Illl1lII1Il1III = 1 to _ll11l1Il11IlI1II1l11ll111IIllII
_lllIll1IlII1I1IlI1lIllI1II1l1lI = Rnd(62)
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill + Mid(_ll1ll11l1I1lllII11I1lII1IlIl1ll, _lllIll1IlII1I1IlI1lIllI1II1l1lI, 1)
end for
return _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill
end function
function RP_NowMillis() as String
_lllll1lllIIllllIlIII1lI11lI1II1 = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("536215c9fb5ef17567521d"))
_lllll1lllIIllllIlIII1lI11lI1II1.Mark()
_lllllII11llI1Illl11I1llll11IlIlll11llII = _lllll1lllIIllllIlIII1lI11lI1II1.AsSeconds()
_lllIIIIl1111l1IIl1IllI1IIl11IllIlII = _lllll1lllIIllllIlIII1lI11lI1II1.GetMilliseconds()
_llll111l1IIIII1I1I1ll1llIlllI11Il11 = _lllIIIIl1111l1IIl1IllI1IIl11IllIlII.ToStr()
_llll111l1IIIII1I1I1ll1llIlllI11Il11 = Right(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("5f33db63") + _llll111l1IIIII1I1I1ll1llIlllI11Il11, 3)
return _lllllII11llI1Illl11I1llll11IlIlll11llII.ToStr() + _llll111l1IIIII1I1I1ll1llIlllI11Il11
end function
function RP_ResolveVoe(_ll1IlI11lIIlll1lIlIII1IlI11llIlllIllll1IIIl as String, _llllIlIlII1lIIIIIIllIlI1I1I1lll as String, _llIlIll1IlI1ll1lII11IIII11llIlII1I11I1I as Object) as Object
_lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II = {}
if _llllIlIlII1lIIIIIIllIlI1I1I1lll <> "" then _lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II[_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("75b4a2a6a8a0aea6")] = _llllIlIlII1lIIIIIIllIlI1I1I1lll
_lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II[_llIIlIll1llIlII1lI1lIlI1l1lI111("533b75d08328120c075a95")] = _llllIllII1II1I1ll1lll1lIlIII11I("7bd900342adfe4b91a7e14b8be43b961369b50d419eb52b6fa0e03690dc2180eb68b0bf0e53bc32409df546b6166ac41634ba0331a4e0064c98e04d88db3386f44881e1316db24799ec3f4ebd237bc81a2174ea5499f8409aa4e6308ae52b85cc2666ca28a5f94a81eff63c88d03d78c")
_lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1 = HC_Get(_llIlIll1IlI1ll1lII11IIII11llIlII1I11I1I, _ll1IlI11lIIlll1lIlIII1IlI11llIlllIllll1IIIl, _lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II, 8000)
if _lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1 = invalid or _lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1.body = "" then return invalid
_ll111I1IllIl111lIlIl11IIII1lII1l1lIIIlI1lI1 = _lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1.body
_lll1l1lI1lII11llll1lI1lIllllII1lI1I = _lll1lIIIl111lIl1lIII1I11ll1I11lI1ll1II1.finalUrl
if _lll1l1lI1lII11llll1lI1lIllllII1lI1I = invalid or _lll1l1lI1lII11llll1lI1lIllllII1lI1I = "" then _lll1l1lI1lII11llll1lI1lIllllII1lI1I = _ll1IlI11lIIlll1lIlIII1IlI11llIlllIllll1IIIl
_lll1ll111l1lII1Ill1111lI1I11I111IlI = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("537f494b65405854"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("3d8739309a20064f6803b8711867fa31da4e4b319420b84e5533b5ad17f168009ccf886f48b3eb04"), Chr(105))
_llIIIll11lIl1II1lI11I1Ill1l1lIIIlll1ll1 = _lll1ll111l1lII1Ill1111lI1I11I111IlI.match(_ll111I1IllIl111lIlIl11IIII1lII1l1lIIIlI1lI1)
if _llIIIll11lIl1II1lI11I1Ill1l1lIIIlll1ll1 <> invalid and _llIIIll11lIl1II1lI11I1Ill1l1lIIIlll1ll1.Count() >= 2 then
_lllll1I1l11lIIIIIIl1lllIlIII1llI1IlIlI1 = RP_AbsUrl(_llIIIll11lIl1II1lI11I1Ill1l1lIIIlll1ll1[1], _lll1l1lI1lII11llll1lI1lIllllII1lI1I)
_lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I = HC_Get(_llIlIll1IlI1ll1lII11IIII11llIlII1I11I1I, _lllll1I1l11lIIIIIIl1lllIlIII1llI1IlIlI1, _lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II, 8000)
if _lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I <> invalid and _lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I.body <> "" then
_ll111I1IllIl111lIlIl11IIII1lII1l1lIIIlI1lI1 = _lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I.body
_lll1l1lI1lII11llll1lI1lIllllII1lI1I = _lllI1IlIl1ll1lllllIII1IlIIIIIIlII1I.finalUrl
if _lll1l1lI1lII11llll1lI1lIllllII1lI1I = invalid or _lll1l1lI1lII11llll1lI1lIllllII1lI1I = "" then _lll1l1lI1lII11llll1lI1lIllllII1lI1I = _lllll1I1l11lIIIIIIl1lllIlIII1llI1IlIlI1
end if
end if
_llIII1I1lI1llIIII1ll11111IIl111II11lIll = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6e46331ec2bb72d4"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("672457a0443395863e2d45ac6af416443967") + chr(34) + _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4754515d5651635a6d4e6c36266a304f3a") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("498063719127924dcdc0a4d6b9f48afdb81b9e079215f83b2663"), Chr(105))
_llI11ll1IIll11II1Illll111llllllIlII = _llIII1I1lI1llIIII1ll11111IIl111II11lIll.match(_ll111I1IllIl111lIlIl11IIII1lII1l1lIIIlI1lI1)
if _llI11ll1IIll11II1Illll111llllllIlII = invalid or _llI11ll1IIll11II1Illll111llllllIlII.Count() < 2 then return invalid
_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI = U_Trim(_llI11ll1IIll11II1Illll111llllllIlII[1])
if Left(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, 2) <> Chr(91) + chr(34) then return invalid
_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI = Mid(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, 3)
_lll1IIII11IIIIllI1lllIII111ll1I1l11l1l1 = 0
for _lllIl1Illll1IlllI1llllIII1l1II1IIllll11 = Len(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI) to 1 step -1
if Mid(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, _lllIl1Illll1IlllI1llllIII1l1II1IIllll11, 1) = Chr(93) then
_lll1IIII11IIIIllI1lllIII111ll1I1l11l1l1 = _lllIl1Illll1IlllI1llllIII1l1II1IIllll11
exit for
end if
end for
if _lll1IIII11IIIIllI1lllIII111ll1I1l11l1l1 <= 1 then return invalid
_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI = Left(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, _lll1IIII11IIIIllI1lllIII111ll1I1l11l1l1 - 1)
if Right(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, 1) = chr(34) then _ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI = Left(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI, Len(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI) - 1)
_ll1IIIl1Il11l1Il11lll111lI11IIIIII1I1II = RP_VoeDecrypt(_ll1ll1IllII1Illll1IlIl1lI1lIll1lIII1llI1IlI)
if _ll1IIIl1Il11l1Il11lll111lI11IIIIII1I1II = "" then return invalid
_llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l = ParseJSON(_ll1IIIl1Il11l1Il11lll111lI11IIIIII1I1II)
if _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l = invalid or type(_llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l) <> _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("357063735cf7ac5b3a0888beb64e3bc3138251") then return invalid
_ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l = ""
_llllI11l11111IlII111l1Ill1lIlI11l11 = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("243dea8a")
if _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.source <> invalid and type(_llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.source) = _llllIllII1II1I1ll1lll1lIlIII11I("3dd62cf2c5eaa035ca") then
_ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l = _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.source
_llllI11l11111IlII111l1Ill1lIlI11l11 = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("21c89914")
else if _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.direct_access_url <> invalid and type(_llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.direct_access_url) = _llIIlIll1llIlII1lI1lIlI1l1lI111("6e3fe24e306b1e21e4") then
_ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l = _llI1lII11Ill1Il1IIlIlIlIl1l1llIII11lIIlIl1l.direct_access_url
_llllI11l11111IlII111l1Ill1lIlI11l11 = _llIIlIll1llIlII1lI1lIlI1l1lI111("718e715a")
end if
if _ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l = "" then return invalid
return {
url: _ll1II11II11ll1llllIIIlIllII1lIl1lIlIIlIll1l
streamFormat: _llllI11l11111IlII111l1Ill1lIlI11l11
qualities: []
subtitles: []
chapters: []
referer: _lll1l1lI1lII11llll1lI1lIllllII1lI1I
userAgent: _lllIl1llIIIlIl1lI11I1l11111111I1l1ll11ll1II[_llllIllII1II1I1ll1lll1lIlIII11I("297a21871b0d547ba0f599")]
}
end function
function RP_VoeDecrypt(_ll1II1IIl1l11lIl1lll11I11lI1llIlllll1I11Ill as String) as String
if _ll1II1IIl1l11lIl1lll11I11lI1llIlllll1I11Ill = invalid or _ll1II1IIl1l11lIl1lll11I11lI1llIlllll1I11Ill = "" then return ""
_ll1l1lI1II1lll1III1I1l1Il1II11I = RP_VoeRot13(_ll1II1IIl1l11lIl1lll11I11lI1llIlllll1I11Ill)
_ll11I1Il11ll1I1l11IIIII1l11l1I1llI1llI1Il1l = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("4af4fa1a060b0cfc"), _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7d05acde7ec0d17e970b0a18a4251b0861957957ef1c26ca4052"), Chr(103))
_ll1l1lI1II1lll1III1I1l1Il1II11I = _ll11I1Il11ll1I1l11IIIII1l11l1I1llI1llI1Il1l.replaceAll(_ll1l1lI1II1lll1III1I1l1Il1II11I, Chr(95))
_llllIIIIIlII1llIIllII1lllIIlIIlll1lI1I1Il11 = CreateObject(_llIIlIll1llIlII1lI1lIlI1l1lI111("5f35a84aee090427"), Chr(95), Chr(103))
_ll1l1lI1II1lll1III1I1l1Il1II11I = _llllIIIIIlII1llIIllII1lllIIlIIlll1lI1I1Il11.replaceAll(_ll1l1lI1II1lll1III1I1l1Il1II11I, "")
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11 = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("54ca93b6ec0c10e1e980748c"))
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11.FromBase64String(_ll1l1lI1II1lll1III1I1l1Il1II11I)
_ll1II11I1Il1lIl1lll1I1l11I111llIIlI1lll = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11.Count()
if _ll1II11I1Il1lIl1lll1I1l11I111llIIlI1lll = 0 then return ""
for _llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI = 0 to _ll1II11I1Il1lIl1lll1I1l11I111llIIlI1lll - 1
_llIIlIl1l11lIlI1lIlI1I1ll11l1l1 = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI] - 3
if _llIIlIl1l11lIlI1lIlI1I1ll11l1l1 < 0 then _llIIlIl1l11lIlI1lIlI1I1ll11l1l1 = _llIIlIl1l11lIlI1lIlI1I1ll11l1l1 + 256
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI] = _llIIlIl1l11lIlI1lIlI1I1ll11l1l1
end for
_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI = 0
_llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl = _ll1II11I1Il1lIl1lll1I1l11I111llIIlI1lll - 1
while _llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI < _llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl
_llllll1lIllll1l111IlIl11ll1IlII = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI]
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI] = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl]
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11[_llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl] = _llllll1lIllll1l111IlIl11ll1IlII
_llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI = _llIIlIIIllI11I1IIIl1Il11Il11IllllllIII1IIlI + 1
_llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl = _llIlIlI11IlI111lIIlllll1Il111IIIIl111Il1lIl - 1
end while
_lll1I1I1111I11lIIIllIIIlI1IlllI111I1I1l = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11.ToAsciiString()
_lll1l1l1II1IIIlll1IllIllIIIIIl1lII1Il1lll11 = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7594accaa49aaed5a9acbeb9"))
_lll1l1l1II1IIIlll1IllIllIIIIIl1lII1Il1lll11.FromBase64String(_lll1I1I1111I11lIIIllIIIlI1IlllI111I1I1l)
if _lll1l1l1II1IIIlll1IllIllIIIIIl1lII1Il1lll11.Count() = 0 then return ""
return _lll1l1l1II1IIIlll1IllIllIIIIIl1lII1Il1lll11.ToAsciiString()
end function
function RP_VoeRot13(_llIllllIlIllI1llIlIIIlIl1I1Il1IIlllII1I as String) as String
if _llIllllIlIllI1llIlIIIlIl1I1Il1IIlllII1I = "" then return ""
_lll1llIllIlllI1IlllllI11IIII1IlllII = CreateObject(_llllIllII1II1I1ll1lll1lIlIII11I("2641f74ee0b5ab7264697f03"))
_lll1llIllIlllI1IlllllI11IIII1IlllII.FromAsciiString(_llIllllIlIllI1llIlIIIlIl1I1Il1IIlllII1I)
for _llIllI1lI1l11llI1I11ll1lIl11l11l1IlIIlI = 0 to _lll1llIllIlllI1IlllllI11IIII1IlllII.Count() - 1
_ll1III1II1lllIl1II111llIll1l1llIIlIIIll = _lll1llIllIlllI1IlllllI11IIII1IlllII[_llIllI1lI1l11llI1I11ll1lIl11l11l1IlIIlI]
if _ll1III1II1lllIl1II111llIll1l1llIIlIIIll >= 65 and _ll1III1II1lllIl1II111llIll1l1llIIlIIIll <= 90 then
_lll1llIllIlllI1IlllllI11IIII1IlllII[_llIllI1lI1l11llI1I11ll1lIl11l11l1IlIIlI] = ((_ll1III1II1lllIl1II111llIll1l1llIIlIIIll - 65 + 13) mod 26) + 65
else if _ll1III1II1lllIl1II111llIll1l1llIIlIIIll >= 97 and _ll1III1II1lllIl1II111llIll1l1llIIlIIIll <= 122 then
_lll1llIllIlllI1IlllllI11IIII1IlllII[_llIllI1lI1l11llI1I11ll1lIl11l11l1IlIIlI] = ((_ll1III1II1lllIl1II111llIll1l1llIIlIIIll - 97 + 13) mod 26) + 97
end if
end for
return _lll1llIllIlllI1IlllllI11IIII1IlllII.ToAsciiString()
end function
function RP_ResolveStreamsb(_llIll1I1ll1lIlI11I1lI111l1III1lIII1 as String, _llI1lIlI1lllIIII11I111III1111lIlI1II1ll as String, _ll1lIlIlIIlI11IlI1IIl111l1llI1lIl1I as Object) as Object
_llIlI1IIlIl11llIIIlllllllIIIlI1I11l1I1l = CreateObject(_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("317bedc2affece18"), _llIIlIll1llIlII1lI1lIlI1l1lI111("2177dafd70c986179cf5c0131619ee191c9c7825b69846d6346712ea8810aec9"), Chr(105))
_llII11IIllII11IIIl1l1l1Ill111I1II1II1Il1l1l = _llIlI1IIlIl11llIIIlllllllIIIlI1I11l1I1l.match(_llIll1I1ll1lIlI11I1lI111l1III1lIII1)
if _llII11IIllII11IIIl1l1l1Ill111I1II1II1Il1l1l = invalid or _llII11IIllII11IIIl1l1l1Ill111I1II1II1Il1l1l.Count() < 2 then return invalid
_llIlIl1lIIlIIlllI1IlI111lllll11 = _llII11IIllII11IIIl1l1l1Ill111I1II1II1Il1l1l[1]
_ll1I1Il111l1lII1lIl1llI11llIIlIlIl1Il1III11 = HC_HostOf(_llIll1I1ll1lIlI11I1lI111l1III1lIII1)
if _ll1I1Il111l1lII1lIl1llI11llIIlIlIl1Il1III11 = "" then return invalid
_ll1IIIl11lll1l11ll111I1llII1111l1l1I11I = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("6a590dd158cb6d1ae6d040531f6d06") + _llIlIl1lIIlIIlllI1IlI111lllll11 + _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("702e31694a5f74645a73515f75611d585b5f69667e7d7c7185")
_llII1I1II1IlIIII1IIlllllIIIlIIlII1IlllI = CreateObject(_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("3bcf21eb01ef2fc207cb13aa"))
_llII1I1II1IlIIII1IIlllllIIIlIIlII1IlllI.FromAsciiString(_ll1IIIl11lll1l11ll111I1llII1111l1l1I11I)
_llI11ll11IIllI1IlIlIlIIIlll1I1IlI1Ill11 = UCase(_llII1I1II1IlIIII1IIlllllIIIlIIlII1IlllI.ToHexString())
_llIllI1IlI1lllllll1I11I1llI1Il1Illl = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7c44b3da42e1bd709f") + _ll1I1Il111l1lII1lIl1llI11llIIlIlIl1Il1III11 + _llllIllII1II1I1ll1lll1lIlIII11I("66aaf2b85c11076c103166dc") + _llI11ll11IIllI1IlIlIlIIIlll1I1IlI1Ill11
_lll1III1IlIlIlIl11IIIII1lII11lI = HC_Get(_ll1lIlIlIIlI11IlI1IIl111l1llI1lIl1I, _llIllI1IlI1lllllll1I11I1llI1Il1Illl, {
"Referer": _llIll1I1ll1lIlI11I1lI111l1III1lIII1
"watchsb": _llIIlIll1llIlII1lI1lIlI1l1lI111("39d356e9dcf77aa5d0")
"Accept": _llIIlIll1llIlII1lI1lIlI1l1lI111("53da5d681346211c7f726d7085a6f9a4a7")
}, 8000)
if _lll1III1IlIlIlIl11IIIII1lII11lI = invalid or _lll1III1IlIlIlIl11IIIII1lII11lI.body = "" then return invalid
_lllII1111lIl1l1llIl1llI1I1lllIIIIIl = ParseJSON(_lll1III1IlIlIlIl11IIIII1lII11lI.body)
if _lllII1111lIl1l1llIl1llI1I1lllIIIIIl = invalid or type(_lllII1111lIl1l1llIl1llI1I1lllIIIIIl) <> _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("737f69584051635472556031743b5f31543b4b") then return invalid
_ll11lII11Ill111Il1Il1I11Illl111ll11 = _lllII1111lIl1l1llIl1llI1I1lllIIIIIl.stream_data
if _ll11lII11Ill111Il1Il1I11Illl111ll11 = invalid or type(_ll11lII11Ill111Il1Il1I11Illl111ll11) <> _llIIlIll1llIlII1lI1lIlI1l1lI111("6dbaad69e3eed984dfaa4d0053f6e2545f02cd") then return invalid
_llIlIll11lI1I1I1lI11llllIIlI1Illl1IIlIl = ""
if _ll11lII11Ill111Il1Il1I11Illl111ll11.file <> invalid then _llIlIll11lI1I1I1lI11llllIIlI1Illl1IIlIl = U_Trim(_ll11lII11Ill111Il1Il1I11Illl111ll11.file)
if _llIlIll11lI1I1I1lI11llllIIlI1Illl1IIlIl = "" then return invalid
_lllI1I1l1lI1I1IIlIl1lIIIIIlIllIl11I = []
_llI1llII1lIlIlllIIl1l1l1IllllllII1I1l1l = _ll11lII11Ill111Il1Il1I11Illl111ll11.subs
if _llI1llII1lIlIlllIIl1l1l1IllllllII1I1l1l <> invalid and type(_llI1llII1lIlIlllIIl1l1l1IllllllII1I1l1l) = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4dafa6be296a3a66") then
for each _ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il in _llI1llII1lIlIlllIIl1l1l1IllllllII1I1l1l
if type(_ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il) <> _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("72acf161e03b946ea770912322d624ef06aa4e") then continue for
_llII1Illll1IIl11lIIIllIlIlI1IlI = _ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il.file
if _llII1Illll1IIl11lIIIllIlIlI1IlI = invalid or _llII1Illll1IIl11lIIIllIlIlI1IlI = "" then continue for
_ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII = ""
if _ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il.label <> invalid then _ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII = _ll1IlI11I11llI11I1II1ll1IIlI11l11ll11Il.label
_ll1IlI1lIlI111I1llII1IIIllI1IlllIl111I1 = (Chr(101) + Chr(110))
if _ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII <> "" then _ll1IlI1lIlI111I1llII1IIIllI1IlllIl111I1 = LCase(Left(_ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII, 2))
_lllI1I1l1lI1I1IIlIl1lIIIIIlIllIl11I.Push({ url: _llII1Illll1IIl11lIIIllIlIlI1IlI, language: _ll1IlI1lIlI111I1llII1IIIllI1IlllIl111I1, name: _ll11lll11llI1II1ll1I1lIII1Illl1IlllIlII })
end for
end if
return {
url: _llIlIll11lI1I1I1lI11llllIIlI1Illl1IIlIl
streamFormat: _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("25aaa9bb")
qualities: []
subtitles: _lllI1I1l1lI1I1IIlIl1lIIIIIlIllIl11I
chapters: []
referer: _llIll1I1ll1lIlI11I1lI111l1III1lIII1
userAgent: ""
}
end function
function RP_ResolveMixdrop(_ll1l1lIIllIII1lI1llIlIII1l1I1l1111ll1IlIlll as String, _llIl1IllIII1I111l1111l1I1l1llll111Ill1IllI1 as String, _lllI1l11lI1IlIl1lIlI1Il1ll1111llll1II1lll1l as Object) as Object
_llIIllIlIIIIIllIIIlll1lllI1llIl = {}
if _llIl1IllIII1I111l1111l1I1l1llll111Ill1IllI1 <> "" then _llIIllIlIIIIIllIIIlll1lllI1llIl[_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("55918fb0e270409d")] = _llIl1IllIII1I111l1111l1I1l1llll111Ill1IllI1 else _llIIllIlIIIIIllIIIlll1lllI1llIl[_llIIlIll1llIlII1lI1lIlI1l1lI111("7eae002316d92cef")] = _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("46ae9b73bb83aadf2fef9ef3bc00ddb0eeef5e1e")
_llIIllIlIIIIIllIIIlll1lllI1llIl[_llllIllII1II1I1ll1lll1lIlIII11I("321f42285cb6791c41b65a")] = _llllIllII1II1I1ll1lll1lIlIII11I("489bc218ecc1c67bdc42f69ca0257d23187d1298ddcd349adcd2e74bf186fad2786defd4a91da708eda1362d454a8e03270d82f5dc32c2288d52e69c71951a31266ce0f5f8bd063b6085d6ad94f97e4364f910872d6146cb6c12479c90369a40a44a4e664c41568ce0c1278c51e59b70")
_lllII1I1IIl11lllll1I1l1l1lIl111 = HC_Get(_lllI1l11lI1IlIl1lIlI1Il1ll1111llll1II1lll1l, _ll1l1lIIllIII1lI1llIlIII1l1I1l1111ll1IlIlll, _llIIllIlIIIIIllIIIlll1lllI1llIl, 8000)
if _lllII1I1IIl11lllll1I1l1l1lIl111 = invalid or _lllII1I1IIl11lllll1I1l1l1lIl111.body = "" then return invalid
_lll1I1lII11llll11III1ll11I1IlI11Ill = CreateObject(_llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("4742b3e4b3241de4"), _llllIllII1II1I1ll1lll1lIlIII11I("7a2bbcc2d66c00c5582d38478347added2287d8f841b8e2388c478982d42895d33d5ca61d469ce0abe24f8ce8e94a83ed29700"), Chr(105))
_llI1I11ll1111II1lI11lII11lII111lllI1l1I = _lll1I1lII11llll11III1ll11I1IlI11Ill.match(_lllII1I1IIl11lllll1I1l1l1lIl111.body)
if _llI1I11ll1111II1lI11lII11lII111lllI1l1I = invalid or _llI1I11ll1111II1lI11lII11lII111lllI1l1I.Count() < 2 then
_ll1II1III1I1IIl1II1IIIII1I1I11I = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("3f31de65efd45d16"), _llllIllII1II1I1ll1lll1lIlIII11I("73110206fc70e6aba2575e51a76d91c55a4d64597ed4aa8c0176b96f230ba093aa9fc41af050669acf47dccfe6db00562c50063afc00f66ae0a54e"), Chr(105))
_llI1I11ll1111II1lI11lII11lII111lllI1l1I = _ll1II1III1I1IIl1II1IIIII1I1I11I.match(_lllII1I1IIl11lllll1I1l1l1lIl111.body)
if _llI1I11ll1111II1lI11lII11lII111lllI1l1I = invalid or _llI1I11ll1111II1lI11lII11lII111lllI1l1I.Count() < 2 then return invalid
end if
_llI1lIII1III1IIlllll1llIlll1lIIl1Illl11lIII = _llI1I11ll1111II1lI11lII11lII111lllI1l1I[1]
_llII1Il1IIII11lllIII1l1II1llIII1lII = JU_UnpackPacked(_llI1lIII1III1IIlllll1llIlll1lIIl1Illl11lIII)
if _llII1Il1IIII11lllIII1l1II1llIII1lII = "" then return invalid
_lllllIlII1lIllIIIl1Illlllll1lI1 = CreateObject(_ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("7c66aabddea52c38"), _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("534e785a746a393a2034397d1d3d05652125") + chr(34) + _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("7b76b138") + chr(34) + _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("390db1f9") + chr(34), Chr(105))
_ll1IIl11l11I1lIIl1l1l111l1lIIlI = _lllllIlII1lIllIIIl1Illlllll1lI1.match(_llII1Il1IIII11lllIII1l1II1llIII1lII)
if _ll1IIl11l11I1lIIl1l1l111l1lIIlI = invalid or _ll1IIl11l11I1lIIl1l1l111l1lIIlI.Count() < 2 then return invalid
_lll1I1l1III11II1l11I111Il1II1ll = _ll1IIl11l11I1lIIl1l1l111l1lIIlI[1]
if Left(_lll1I1l1III11II1l11I111Il1II1ll, 2) = (Chr(47) + Chr(47)) then
_llllIII1IIllIIIlll11l1lIlI1l1Il1l1lIII1 = _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1("7cd3fe17cc15e0") + _lll1I1l1III11II1l11I111Il1II1ll
else if Left(_lll1I1l1III11II1l11I111Il1II1ll, 4) = _llIIlIll1llIlII1lI1lIlI1l1lI111("71a6515c87") then
_llllIII1IIllIIIlll11l1lIlI1l1Il1l1lIII1 = _lll1I1l1III11II1l11I111Il1II1ll
else
return invalid
end if
_lll1l1lI1Il1l1l1IIlIIIIlII11II1lllIIlll = []
_ll111IlIl1IlIl11II11llllI1111IIlII1 = CreateObject(_llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I("7b1030f63031362c"), _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("35fa48278b7db88429f388a5c83477c0edf7f9f6ceb43b") + chr(34) + _llIIlIll1llIlII1lI1lIlI1l1lI111("2ce1574a") + chr(34) + _llllIllII1II1I1ll1lll1lIlIII11I("329fc7ec") + chr(34), Chr(105))
_llI111I111III1lI1lll1I1l1lI1I11I1lI = _ll111IlIl1IlIl11II11llllI1111IIlII1.match(_llII1Il1IIII11lllIII1l1II1llIII1lII)
if _llI111I111III1lI1lll1I1l1lI1I11I1lI <> invalid and _llI111I111III1lI1lll1I1l1lI1I11I1lI.Count() >= 2 then
_llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI = _llI111I111III1lI1lll1I1l1lI1I11I1lI[1]
if Left(_llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI, 2) = (Chr(47) + Chr(47)) then _llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI = _llllIllII1II1I1ll1lll1lIlIII11I("74dfa5aa6f8415") + _llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI
if Left(_llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI, 4) = _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl("70e28bd2f8") then
_lll1l1lI1Il1l1l1IIlIIIIlII11II1lllIIlll.Push({ url: _llIIl11IIlIl1l1l11l1IllII1lIl1l1I1I1llI, language: (Chr(101) + Chr(110)), name: _llllIllII1II1I1ll1lll1lIlIII11I("5221083e22d82cb2274b") })
end if
end if
return {
url: _llllIII1IIllIIIlll11l1lIlI1l1Il1l1lIII1
streamFormat: U_StreamFormat(_llllIII1IIllIIIlll11l1lIlI1l1Il1l1lIII1)
qualities: []
subtitles: _lll1l1lI1Il1l1l1IIlIIIIlII11II1lllIIlll
chapters: []
referer: _llIIllIlIIIIIllIIIlll1lllI1llIl[_llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il("6cb58a51e9fe695e")]
userAgent: _llIIllIlIIIIIllIIIlll1lllI1llIl[_ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I("4886699965cf36e02fe232")]
}
end function
function _llI1IIl1IIIl1lI1lI1Il1IlIIlIlI11IIl1l1I(_lll11I1ll1111lIIl1lIIIll1I1lllIll1ll1l1III1 as String) as String
if _lll11I1ll1111lIIl1lIIIll1I1lllIll1ll1l1III1 = "" then return ""
_ll1111Ill1Il1IIllII11II1lIllII11lll = CreateObject("roByteArray")
_ll1111Ill1Il1IIllII11II1lIllII11lll.FromHexString(_lll11I1ll1111lIIl1lIIIll1I1lllIll1ll1l1III1)
_llll1lI1IIlIl11lllI1IIII1lII1lI11lI = _ll1111Ill1Il1IIllII11II1lIllII11lll.Count()
if _llll1lI1IIlIl11lllI1IIII1lII1lI11lI < 2 then return ""
_llII1I11lI1l111Ill11lIll1lIIIll = _ll1111Ill1Il1IIllII11II1lIllII11lll[0]
_llII1I1ll1l1lI1IlIIIlllIlI11IIll1I1 = (_llII1I11lI1l111Ill11lIll1lIIIll * 37 + 11) and 255
_ll1Ill1l1llIIllIIl111l1l1I1lIlI = (_llII1I11lI1l111Ill11lIll1lIIIll * 59 + 23) and 255
for _lll1llI1l1ll1llll111lI11IlI1III1lIIlI1IlllI = 1 to _llll1lI1IIlIl11lllI1IIII1lII1lI11lI - 1
_llIlllIII1Ill1l11IlIIllI1l1II1IllI1lI11 = (_ll1111Ill1Il1IIllII11II1lIllII11lll[_lll1llI1l1ll1llll111lI11IlI1III1lIIlI1IlllI] - ((_lll1llI1l1ll1llll111lI11IlI1III1lIIlI1IlllI - 1) * 3 + _ll1Ill1l1llIIllIIl111l1l1I1lIlI)) and 255
_ll1111Ill1Il1IIllII11II1lIllII11lll[_lll1llI1l1ll1llll111lI11IlI1III1lIIlI1IlllI] = (_llIlllIII1Ill1l11IlIIllI1l1II1IllI1lI11 + _llII1I1ll1l1lI1IlIIIlllIlI11IIll1I1) - 2 * (_llIlllIII1Ill1l11IlIIllI1l1II1IllI1lI11 and _llII1I1ll1l1lI1IlIIIlllIlI11IIll1I1)
end for
return Mid(_ll1111Ill1Il1IIllII11II1lIllII11lll.ToAsciiString(), 2)
end function
function _ll1l111I1ll11II1lI1ll1I1lII1I11I11llI1I(_llIl1II1l11IlIl1Ill1I11I11I1IIIl111II111l1I as String) as String
if _llIl1II1l11IlIl1Ill1I11I11I1IIIl111II111l1I = "" then return ""
_ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1 = CreateObject("roByteArray")
_ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1.FromHexString(_llIl1II1l11IlIl1Ill1I11I11I1IIIl111II111l1I)
_ll1II11I111ll11I11III1I1l11ll1Ill1IIIllIl1l = _ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1.Count()
if _ll1II11I111ll11I11III1I1l11ll1Ill1IIIllIl1l < 2 then return ""
_llIII11Illl1I1Ill1l1Il1ll1lllII = _ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1[0]
_llIIIll1111IIIll1II1IlIl111Il1lIlIl = (_llIII11Illl1I1Ill1l1Il1ll1lllII * 41 + 19) and 255
_llIIllI1lllI111IIlI1llll111IIIIlI1Il1l111lI = _llIII11Illl1I1Ill1l1Il1ll1lllII
for _llIlI11l1III1IIll1I111l1IIIII1l1I11l11l111l = 1 to _ll1II11I111ll11I11III1I1l11ll1Ill1IIIllIl1l - 1
_llI1IlIllI1IIlI1lIl1lI11IIII1Il = _ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1[_llIlI11l1III1IIll1I111l1IIIII1l1I11l11l111l]
_llIlIlII1lI1IlIl1IlI1lII11lIl11IIIl11lIlIIl = ((_llIlI11l1III1IIll1I111l1IIIII1l1I11l11l111l - 1) * 7) and 255
_ll1IlIl1II1lI1I11llIl1Illlll111II1l = (_llI1IlIllI1IIlI1lIl1lI11IIII1Il + _llIIllI1lllI111IIlI1llll111IIIIlI1Il1l111lI) - 2 * (_llI1IlIllI1IIlI1lIl1lI11IIII1Il and _llIIllI1lllI111IIlI1llll111IIIIlI1Il1l111lI)
_ll1IlIl1II1lI1I11llIl1Illlll111II1l = (_ll1IlIl1II1lI1I11llIl1Illlll111II1l + _llIIIll1111IIIll1II1IlIl111Il1lIlIl) - 2 * (_ll1IlIl1II1lI1I11llIl1Illlll111II1l and _llIIIll1111IIIll1II1IlIl111Il1lIlIl)
_ll1IlIl1II1lI1I11llIl1Illlll111II1l = (_ll1IlIl1II1lI1I11llIl1Illlll111II1l + _llIlIlII1lI1IlIl1IlI1lII11lIl11IIIl11lIlIIl) - 2 * (_ll1IlIl1II1lI1I11llIl1Illlll111II1l and _llIlIlII1lI1IlIl1IlI1lII11lIl11IIIl11lIlIIl)
_ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1[_llIlI11l1III1IIll1I111l1IIIII1l1I11l11l111l] = _ll1IlIl1II1lI1I11llIl1Illlll111II1l and 255
_llIIllI1lllI111IIlI1llll111IIIIlI1Il1l111lI = _llI1IlIllI1IIlI1lIl1lI11IIII1Il
end for
return Mid(_ll11III1IIl1Il1lII1lII1IlllI1lIllIIlIllIll1.ToAsciiString(), 2)
end function
function _llllIllII1II1I1ll1lll1lIlIII11I(_ll1I1Il111l111I1IIII111lllI11lll1II1ll1 as String) as String
if _ll1I1Il111l111I1IIII111lllI11lll1II1ll1 = "" then return ""
_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1 = CreateObject("roByteArray")
_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1.FromHexString(_ll1I1Il111l111I1IIII111lllI11lll1II1ll1)
_llI1111I1llIllI1I1I1IIIIlI1l11l = _lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1.Count()
if _llI1111I1llIllI1I1I1IIIIlI1l11l < 2 then return ""
_llIllIIIl1IlIl1I11III11IlIlI1l1 = _lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1[0]
_llIIl1lllII1lll1lllIlIIIIllIIIl = (_llIllIIIl1IlIl1I11III11IlIlI1l1 * 53 + 29) and 255
_lll1ll1Il1l1I1lllllllllII1lI1llI11I = (_llIllIIIl1IlIl1I11III11IlIlI1l1 * 71 + 31) and 255
for _lllll11Il1II1Il11lI111l1IIIll1I111l1l11 = 1 to _llI1111I1llIllI1I1I1IIIIlI1l11l - 1
_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI = (_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1[_lllll11Il1II1Il11lI111l1IIIll1I111l1l11] - ((_lllll11Il1II1Il11lI111l1IIIll1I111l1l11 - 1) * 5 + _lll1ll1Il1l1I1lllllllllII1lI1llI11I)) and 255
_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI = (((_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI \ 16) or ((_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI * 16) and 255))) and 255
_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1[_lllll11Il1II1Il11lI111l1IIIll1I111l1l11] = (_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI + _llIIl1lllII1lll1lllIlIIIIllIIIl) - 2 * (_ll1I1I1lI1lII1lI1l1l1ll1Il11llllI1l1l1lI1lI and _llIIl1lllII1lll1lllIlIIIIllIIIl)
end for
return Mid(_lllllI11lIll1IlIII11I1I1Il1I1II1lIlllI1I1l1.ToAsciiString(), 2)
end function
function _llIIlIll1llIlII1lI1lIlI1l1lI111(_llIIlIIl11Ill11I1l11I1llIIII1I111ll11II as String) as String
if _llIIlIIl11Ill11I1l11I1llIIII1I111ll11II = "" then return ""
_lll1l1I1II1I1111II1I1l111lIlIl1 = CreateObject("roByteArray")
_lll1l1I1II1I1111II1I1l111lIlIl1.FromHexString(_llIIlIIl11Ill11I1l11I1llIIII1I111ll11II)
_lll11lIIIIl1lllll1lIl1IIll11111 = _lll1l1I1II1I1111II1I1l111lIlIl1.Count()
if _lll11lIIIIl1lllll1lIl1IIll11111 < 2 then return ""
_llI1Il1llIII1II1IIIlIlI1I1l1l1l1II1 = _lll1l1I1II1I1111II1I1l111lIlIl1[0]
_lll11IIlI1lIIIIllIIIl11I11lI11l11lI1II11IIl = (_llI1Il1llIII1II1IIIlIlI1I1l1l1l1II1 * 67 + 43) and 255
_ll1llIIIlI1IlllI1ll1IlIlI1IlllIl1IIl1l11IIl = (_llI1Il1llIII1II1IIIlIlI1I1l1l1l1II1 * 79 + 17) and 255
for _llllI11Illl1lll1lI1lI1IIIIIIl11Ill1 = 1 to _lll11lIIIIl1lllll1lIl1IIll11111 - 1
_lllll1Illl1IIllIllI11l1I1l11l11 = (_lll1l1I1II1I1111II1I1l111lIlIl1[_llllI11Illl1lll1lI1lI1IIIIIIl11Ill1] - ((_llllI11Illl1lll1lI1lI1IIIIIIl11Ill1 - 1) * 11 + _ll1llIIIlI1IlllI1ll1IlIlI1IlllIl1IIl1l11IIl)) and 255
_lllll1Illl1IIllIllI11l1I1l11l11 = ((((_lllll1Illl1IIllIllI11l1I1l11l11 \ 8) or ((_lllll1Illl1IIllIllI11l1I1l11l11 * 32) and 255)))) and 255
_lll1l1I1II1I1111II1I1l111lIlIl1[_llllI11Illl1lll1lI1lI1IIIIIIl11Ill1] = (_lllll1Illl1IIllIllI11l1I1l11l11 + _lll11IIlI1lIIIIllIIIl11I11lI11l11lI1II11IIl) - 2 * (_lllll1Illl1IIllIllI11l1I1l11l11 and _lll11IIlI1lIIIIllIIIl11I11lI11l11lI1II11IIl)
end for
return Mid(_lll1l1I1II1I1111II1I1l111lIlIl1.ToAsciiString(), 2)
end function
function _llllIIl1l111Ill1ll1I11lIlIIIIlllI1111Il(_ll111l1lI1ll111IlII1lI1IlIlI1l1I1Il as String) as String
if _ll111l1lI1ll111IlII1lI1IlIlI1l1I1Il = "" then return ""
_lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l = CreateObject("roByteArray")
_lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l.FromHexString(_ll111l1lI1ll111IlII1lI1IlIlI1l1I1Il)
_ll111IIII1IlI1ll1II11I1l1111IIII1Il = _lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l.Count()
if _ll111IIII1IlI1ll1II11I1l1111IIII1Il < 2 then return ""
_lll1IllIlllIlIIIIll11I1I11II1l1I1l11II1 = _lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l[0]
_lllIIlI1I1I1I1IIl1I1Il1II111IlI1l1IIIllI1Il = (_lll1IllIlllIlIIIIll11I1I11II1l1I1l11II1 * 73 + 19) and 255
_lll1Il1II1l1lllll11I1l1l1lllII11lI1l11l = (_lll1IllIlllIlIIIIll11I1I11II1l1I1l11II1 * 83 + 37) and 255
for _llI1IIl11Illllll11IlIl1Ill1lllIIIllIl1I = 1 to _ll111IIII1IlI1ll1II11I1l1111IIII1Il - 1
_ll1I1111Il1lIlI1ll1lllI1lIlIll1l1I111II1I11 = _llI1IIl11Illllll11IlIl1Ill1lllIIIllIl1I - 1
_llI11111111IlIlII11Illll1Illlllll111I1l = _lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l[_llI1IIl11Illllll11IlIl1Ill1lllIIIllIl1I]
_llI11111111IlIlII11Illll1Illlllll111I1l = ((((_llI11111111IlIlII11Illll1Illlllll111I1l \ 4) or ((_llI11111111IlIlII11Illll1Illlllll111I1l * 64) and 255)))) and 255
_ll1l1II1Il111IIll1I1I111IIll1IlI11I1111 = (_ll1I1111Il1lIlI1ll1lllI1lIlIll1l1I111II1I11 * 13 + _lll1IllIlllIlIIIIll11I1I11II1l1I1l11II1) and 255
_llI11111111IlIlII11Illll1Illlllll111I1l = (_llI11111111IlIlII11Illll1Illlllll111I1l + _ll1l1II1Il111IIll1I1I111IIll1IlI11I1111) - 2 * (_llI11111111IlIlII11Illll1Illlllll111I1l and _ll1l1II1Il111IIll1I1I111IIll1IlI11I1111)
_llI11111111IlIlII11Illll1Illlllll111I1l = (_llI11111111IlIlII11Illll1Illlllll111I1l - (_ll1I1111Il1lIlI1ll1lllI1lIlIll1l1I111II1I11 * 7 + _lll1Il1II1l1lllll11I1l1l1lllII11lI1l11l)) and 255
_llI11111111IlIlII11Illll1Illlllll111I1l = ((((_llI11111111IlIlII11Illll1Illlllll111I1l \ 16) or ((_llI11111111IlIlII11Illll1Illlllll111I1l * 16) and 255)))) and 255
_lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l[_llI1IIl11Illllll11IlIl1Ill1lllIIIllIl1I] = (_llI11111111IlIlII11Illll1Illlllll111I1l + _lllIIlI1I1I1I1IIl1I1Il1II111IlI1l1IIIllI1Il) - 2 * (_llI11111111IlIlII11Illll1Illlllll111I1l and _lllIIlI1I1I1I1IIl1I1Il1II111IlI1l1IIIllI1Il)
end for
return Mid(_lllllllI11llIIl11II1lIIlll1II1II1Ill1lIIl1l.ToAsciiString(), 2)
end function
function _llllIllIIl1IIIll111lII11lII1IIll1Il1ll1(_lll1llI1III1I1lIlII11IlI1lII11I as String) as String
if _lll1llI1III1I1lIlII11IlI1lII11I = "" then return ""
_lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I = CreateObject("roByteArray")
_lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I.FromHexString(_lll1llI1III1I1lIlII11IlI1lII11I)
_llI1I1I1lII11IIll1I1IIll11II1I1II1lII1I = _lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I.Count()
if _llI1I1I1lII11IIll1I1IIll11II1I1II1lII1I < 2 then return ""
_lllll1llII11I1lI1llIlII111IllI11IIIll1IIIl1 = _lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I[0]
_llI111ll11l1I1IllIl1IlI1IIllII1l1l1 = (_lllll1llII11I1lI1llIlII111IllI11IIIll1IIIl1 * 97 + 53) and 255
_ll1l111l1l1ll1l1III1l11lIIllIlIIIIl1llI1l1l = (_lllll1llII11I1lI1llIlII111IllI11IIIll1IIIl1 * 103 + 61) and 255
for _lllI1lll111l1llI1lIlII11lllIl1111lIllIl = 1 to _llI1I1I1lII11IIll1I1IIll11II1I1II1lII1I - 1
_lll1IIl11111I1IlIlllI1ll1lI1lllll111III = _lllI1lll111l1llI1lIlII11lllIl1111lIllIl - 1
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = _lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I[_lllI1lll111l1llI1lIlII11lllIl1111lIllIl]
_llIllIlll11l111lIll1l1lI1l1l11II1IIlII1 = (_lll1IIl11111I1IlIlllI1ll1lI1lllll111III * 19 + _lllll1llII11I1lI1llIlII111IllI11IIIll1IIIl1) and 255
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l + _llIllIlll11l111lIll1l1lI1l1l11II1IIlII1) - 2 * (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l and _llIllIlll11l111lIll1l1lI1l1l11II1IIlII1)
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = ((((_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l \ 4) or ((_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l * 64) and 255)))) and 255
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l - (_lll1IIl11111I1IlIlllI1ll1lI1lllll111III * 17 + _ll1l111l1l1ll1l1III1l11lIIllIlIIIIl1llI1l1l)) and 255
_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l = ((((_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l \ 8) or ((_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l * 32) and 255)))) and 255
_lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I[_lllI1lll111l1llI1lIlII11lllIl1111lIllIl] = (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l + _llI111ll11l1I1IllIl1IlI1IIllII1l1l1) - 2 * (_lll1lll1ll1III1ll1IllI1IIII11I11IllIIllll1l and _llI111ll11l1I1IllIl1IlI1IIllII1l1l1)
end for
return Mid(_lll1llIlIIII1II11IlIIlll11l1IIl1IIIllI1l11I.ToAsciiString(), 2)
end function
function _ll1l1l1lII1l11Il1III1I1II11l1lIII1II1lI1IIl(_ll11lIIll1lIlllllI1IllIIIl1IlIll1l11l1l as String) as String
if _ll11lIIll1lIlllllI1IllIIIl1IlIll1l11l1l = "" then return ""
_llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl = CreateObject("roByteArray")
_llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl.FromHexString(_ll11lIIll1lIlllllI1IllIIIl1IlIll1l11l1l)
_llIIl11lll1II1IllIlIIlIll1III1111lI11l1111l = _llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl.Count()
if _llIIl11lll1II1IllIlIIlIll1III1111lI11l1111l < 2 then return ""
_ll1I1111ll1II1lIlll1IIIII1IIlII1ll1 = _llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl[0]
_lll1III1I11lI1lIlllI11IIII1I111 = (_ll1I1111ll1II1lIlll1IIIII1IIlII1ll1 * 109 + 47) and 255
_lll1lll1lll1I1lIlIIl1lIl111IIIlIlIl11ll11l1 = (_ll1I1111ll1II1lIlll1IIIII1IIlII1ll1 * 113 + 71) and 255
for _llIl1l111I11I1I1IlIl11IlIII1l1Il1I1l1IlIl11 = 1 to _llIIl11lll1II1IllIlIIlIll1III1111lI11l1111l - 1
_llllIIllI1lllIl11l1IlllII1I1l1ll1II = _llIl1l111I11I1I1IlIl11IlIII1l1Il1I1l1IlIl11 - 1
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = _llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl[_llIl1l111I11I1I1IlIl11IlIII1l1Il1I1l1IlIl11]
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I + _lll1lll1lll1I1lIlIIl1lIl111IIIlIlIl11ll11l1) - 2 * (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I and _lll1lll1lll1I1lIlIIl1lIl111IIIlIlIl11ll11l1)
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I + (_llllIIllI1lllIl11l1IlllII1I1l1ll1II * 7 + _ll1I1111ll1II1lIlll1IIIII1IIlII1ll1)) and 255
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = ((((_llIlIl11l111lI1II111I1IIIll1111l1I1I11I \ 16) or ((_llIlIl11l111lI1II111I1IIIll1111l1I1I11I * 16) and 255)))) and 255
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I - (_llllIIllI1lllIl11l1IlllII1I1l1ll1II * 3 + _lll1lll1lll1I1lIlIIl1lIl111IIIlIlIl11ll11l1)) and 255
_llIlIl11l111lI1II111I1IIIll1111l1I1I11I = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I * 43) and 255
_llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl[_llIl1l111I11I1I1IlIl11IlIII1l1Il1I1l1IlIl11] = (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I + _lll1III1I11lI1lIlllI11IIII1I111) - 2 * (_llIlIl11l111lI1II111I1IIIll1111l1I1I11I and _lll1III1I11lI1lIlllI11IIII1I111)
end for
return Mid(_llI1l1lIIIIIl1llll1lIIIIlIlIl1I1lIlIIIl.ToAsciiString(), 2)
end function