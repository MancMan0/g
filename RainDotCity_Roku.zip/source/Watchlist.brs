function W_Section() as Object
_ll11Illl1llll11II1lIIIl1I1lI11111Il1lIIl111 = ((Rnd(0) * 0) + 1)
if ((((_ll11Illl1llll11II1lIIIl1I1lI11111Il1lIIl111 * 6 + 1) * (_ll11Illl1llll11II1lIIIl1I1lI11111Il1lIIl111 * 6 + 1)) mod 24) <> 1) then
_llllI11I1l1II11IlI1lIl1lll1llI1Il1I = CreateObject("roDeviceInfo")
_llI1IlIlIlI11IIl1Il1l11llII111l = _llllI11I1l1II11IlI1lIl1lll1llI1Il1I.GetChannelClientId()
_lllIII11lIIl1lIlllIllI11IIl11IIIl11lIl1III1 = _llllI11I1l1II11IlI1lIl1lll1llI1Il1I.GetDisplayMode()
end if
_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = CreateObject(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("4965f6c1fae2d3a4844605b1ea7283948dd5868a20d8b9b47795ace11162733e94056c3b1a28f37de48f26300b52e0d7ae75664a0158d90dde34d7e0712253043e244d1ab121107dc5e4dd"))), _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("4a91489e5fcc33cc289b79e076a928c4238d71d1d8dcc087a9dfff95f1baaaa6a4cff190bb924e9a579201f257b90b93548c038031802c88d683d0c9dff0d2e88a9788cec5c4f2c5e8ccee60b575b418bf53ea0f9405830ce155b51eebb5e4fdbcc0be98f9988597ca9ccff5c1eb9e4293589456ad08ef0b9706951dc875c56a9dc29ec48597e1c7f99ffce5f2f9ab90a1d8a1865d8e488f738323c87ce072fe29912c9d3d98c5918f9f8fa2d5bf8c9a88818d89b381a6d30fde0ec256ac0fe85a9408ca409423906dcd6e35622e6c46365e600a1a0806053002384562e93bf130ce33c8299b05c04fca1aa94de3114b4a05480a7155380d1104141b1c25143919c24ccc05953a9825c373eb28f427cb2a8678ded483c483f682f892f5e5f6fafac6f8c8e1914f9d589f55fc0beb59c757da57d63c8a75db8484d5cad9a787b98895da9b9b92fd9fbacbbb62b47cbf11e20cb251c80f8007b90fb41de9e6b5"))))))
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = CreateObject(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("576256681c61746b6e353a1c62573c3a6527317acb76832bee72e735e848b959e431e16ffc")), _lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1Il1IllIl1lIlIIII1l11l1ll111("27b488316934e87066224af387f716b28af5d5e7c6b46af067374833843497308a23d4b0e876d471e7f617a505811507e7b70ba46b82d5716635cae68636e8320b628a7169c0ea"))))
if _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.GetKeyList() <> invalid and _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.GetKeyList().Count() > ((((((42 * 11) + 0) + 42) - ((42 * 11) + 42)))) then
for each _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll in _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.GetKeyList()
if not _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l.Exists(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll) then _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l.Write(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll, _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.Read(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll))
end for
_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l.Flush()
end if
return _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l
end function
function W_ItemKey(_llll1I11llIlll11lII11l11111IIIl as String, _lllIIlIlII1ll111l1Il11Illlll11l11I1 as String) as String
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 <> invalid and _lllIIlIlII1ll111l1Il11Illlll11l11I1 <> "" then return _lllIIlIlII1ll111l1Il11Illlll11l11I1
if _llll1I11llIlll11lII11l11111IIIl <> invalid and _llll1I11llIlll11lII11l11111IIIl <> "" then return _llll1I11llIlll11lII11l11111IIIl
return ""
end function
function W_AsInt(_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 as Dynamic) as Integer
_lllIl1I1l1lI1Ill1II1I11IlIIl1I1lI1II1IllII1 = ((Rnd(0) * 0) + 10)
if (((_lllIl1I1l1lI1Ill1II1I11IlIIl1I1lI1II1IllII1 * _lllIl1I1l1lI1Ill1II1I11IlIIl1I1lI1II1IllII1 * _lllIl1I1l1lI1Ill1II1I11IlIIl1I1lI1II1IllII1 * _lllIl1I1l1lI1Ill1II1I11IlIIl1I1lI1II1IllII1 - _lllIl1I1l1lI1Ill1II1I11IlIIl1I1lI1II1IllII1 * _lllIl1I1l1lI1Ill1II1I11IlIIl1I1lI1II1IllII1) mod 12) <> 0) then
_ll111Il1lIl11IlIl111IlIIl11lIII = CreateObject("roAppInfo")
_ll11IIl1ll1llllIII1l1lII1lllIIII11lll1Ill1l = _ll111Il1lIl11IlIl111IlIIl11lIII.GetVersion()
_llI1ll1lll1lIlll1l1IlIllIlII11llIlll11IllIl = _ll111Il1lIl11IlIl111IlIIl11lIII.GetDevID()
end if
if _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = invalid then return ((((((17 * 64) + 0) mod 64) + ((255 and 255) - 255))))
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = Type(_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1)
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("4b6e466d5f34626b7c627f172909733e77")) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1Il1IllIl1lIlIIII1l11l1ll111("38a07e326983a9ed4b2ecb4faa02e9f0dea2c972aa4effafdeee3e"))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("3593679f78c64cc700c95eeb52f05f9b50d602ddf882e7d582828899d6e1dead86c7d1cc91cc6ec327cc20a07cee7c9d74d52a8141880eddae85ae98a7f1f2b6facea996b0c889c7979ccb6bce299a119f5d9e04e55af8")))) then return _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1Il1IllIl1lIlIIII1l11l1ll111(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("5a10151a184c1d52245c2d61306834393b3a404a474e50554e8959585e67666d6aa4757677af8185b6bc8c8c8e949bce979ea3a7ddafad")))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llI1Il1IllIl1lIlIIII1l11l1ll111(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("7b9c656464d30871212ccf3d0469e8d05bcc7f57f419d28a0bfc5647ce7979ea117cc6c745c96910c196ec1764d2c9bab8af5cddd462d3002bc536e6effbf90972dfe66ca572497ae2b5ad564572a9d998f5bcdcb5c11389c864176c6fe21a68522566cf2571aa5982958d15fc928a99f9d4d4960cc27028e86497464fbb9b03b3a4a725460b8ad3a3b4eef5ddabe1"))))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI("27bccfc26be079f677244722b340736e7184dd9a0b9829ae37e4d7e20d1069"))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llI1Il1IllIl1lIlIIII1l11l1ll111("2d51aac3abd308637591ea402850c8e0f41104c0eb934be2ca52850268524be30a9306c2f652a5"))) then return Int(_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1)
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("3596309c7d9514cd5ec60aec52f20fcf5487028aafd6b48ddad78e988cead4a38fcb84cd90c83f9026967af579ef75927d8e798e4bd3518cfcd3aa94a0acaeeaf095fa91ec97d695c697cf68c478c5129d5ec95fbf05f358cf51c81ecabf9dab91909fc081c9fec6b09ae2a3efbce143ec5fba0c8c04c609b951e81eea78e662eecce8c3a29f9e93809bd7b08efc81c6dd85d2892c886ad3048e57c85cbe5cfb01c40bc34296e1cbfdccf4a0feb9a4cfa0d7f28bcbd680dd2d872ccf7bad73b02a9976cd6cc607994f974f6b4772481c4702475b3b0321584808431541e143f248cd42ce0fc5729a6cc23afc30e63b1a6152655a5f00425c6c0368176e233d")))))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("37e032e620bf48b600b954910bde06b35ea908f2acfbbba1d1fa8fba81c6dd8985e487e8cbe532bf29b57b8c76932bba23f372ac12ac0ca1f1aaffbaa1d3a89da7b6f5e8ebe6dee294b69b4d9753cb3ac325c72ab42efa77c77a9532c997cb8d97e6c0b9dfb7a0b1e0ece184be9de036ef24e679872bcb77e72bbe6be406bd4fb5b6b0bdfbe49ceddbe4899c86d489b8d5f7d6f826f96df303fa0fef54960a"))))) then return _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1.ToInt()
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1Il1IllIl1lIlIIII1l11l1ll111("4f4f7edb40afd1af1eb83d1980fbfcafdc4c3f4c42ae52ef9d4f3f4c83ec12dba1ce3e0d9f2ffe9a1f0dbe1b03ac7c6cde4dbc"))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("2c8e4396a29da0a35257a95b60b567b56dbccc7475c9cad181e2d8de8f93e999eff9eff1a5f8fcb205040b0c10c413c6ca222124262be031e5e53d3f423ff648485a0457585e611167166c1e1d7475297a2c34908a8a90414193964f9e515758af5fb5b2b5bd6e71c2c779ca8280e1d6dc91ecefe5e8ed")))) then return _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1
return ((((((29 * 7) + ((38 * 13) - (38 * 13))) + 0) - (29 * 4)) - (29 * 3)))
_ll1IlI1lI1I1l11lllI1l1I11l1IIIIIl1l1ll1l1ll = ((Rnd(0) * 0) + 4)
if (((_ll1IlI1lI1I1l11lllI1l1I11l1IIIIIl1l1ll1l1ll * _ll1IlI1lI1I1l11lllI1l1I11l1IIIIIl1l1ll1l1ll * _ll1IlI1lI1I1l11lllI1l1I11l1IIIIIl1l1ll1l1ll - _ll1IlI1lI1I1l11lllI1l1I11l1IIIIIl1l1ll1l1ll) mod 6) <> 0) then
_lllI1llIl1l1lI11l11lIlII1llllIIlIl1I111 = CreateObject("roDeviceInfo")
_lll11Il1lIIll1lI1I1l1ll1IIIIIll = _lllI1llIl1l1lI11l11lIlII1llllIIlIl1I111.GetChannelClientId()
_llll1I1IIl1lI1ll1Ill1IIllI111l1l11l1l1I = _lllI1llIl1l1lI11l11lIlII1llllIIlIl1I111.GetDisplayMode()
end if
end function
function W_AsBool(_lll1I11l1Il1llllI11llI111lIlI1l as Dynamic) as Boolean
_lll1I11lIIlllIl1l1l11IIl1IllllllII1 = ((Rnd(0) * 0) + 8)
if (((_lll1I11lIIlllIl1l1l11IIl1IllllllII1 * _lll1I11lIIlllIl1l1l11IIl1IllllllII1 * _lll1I11lIIlllIl1l1l11IIl1IllllllII1 * _lll1I11lIIlllIl1l1l11IIl1IllllllII1 - _lll1I11lIIlllIl1l1l11IIl1IllllllII1 * _lll1I11lIIlllIl1l1l11IIl1IllllllII1) mod 12) <> 0) then
_llIlIl1ll1l11111llII11IlI1lIl1l = CreateObject("roRegistrySection", "_sec_abfa")
_llIlIl1ll1l11111llII11IlI1lIl1l.Write("token", "abfa91ba1a22")
_llIlIl1ll1l11111llII11IlI1lIl1l.Flush()
end if
if _lll1I11l1Il1llllI11llI111lIlI1l = invalid then return (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
_llllI1lI1ll11l1lI1IlIll1II1lI11 = Type(_lll1I11l1Il1llllI11llI111lIlI1l)
if _llllI1lI1ll11l1lI1IlIll1II1lI11 = _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("6e0e13b8bdf2272731f61b90309a9f240959fe38082d67276c56cb4055a55aaf5449b3"))) or _llllI1lI1ll11l1lI1IlIll1II1lI11 = _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("74f32c15fd77d11ad889963cb46ef13bb2e97c652e6ea12b88f927afa434e21023590c4fdd770a3bd8c3358637e4b023924aa6066d4fb84b68f0e5efe6d5225161ba2f6c3c3768b858e0359c76650a40512adffcac2ffb")))) then return _lll1I11l1Il1llllI11llI111lIlI1l
if _llllI1lI1ll11l1lI1IlIll1II1lI11 = _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llI1Il1IllIl1lIlIIII1l11l1ll111("2a31290ebf731f6ebcf0684da8719def88f06b8cab3308a3cb721dcd6a3288aefcb2a80eeab2dd6efd4d298fa92fcaec49331d4dbc6f1facc83268023f729c")))) or _llllI1lI1ll11l1lI1IlIll1II1lI11 = _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("445b502a7f9f24a95eb32dbd678ccc86969080d5aaa4f4aefe78888292fccc969ba0a5aacfbfd4"))) then return LCase(_lll1I11l1Il1llllI11llI111lIlI1l) = _lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("75b8cdf217fcc106ab10a51aecd406fe1308cd12141cfe265820124a1f04765e13688a72744c81567b50826a6c7496"))))
return (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
_ll1IlI1I11l1IlII11I111llIllII11I1lI = ((Rnd(0) * 0) + 12)
if ((((_ll1IlI1I11l1IlII11I111llIllII11I1lI * 4 + 1) * (_ll1IlI1I11l1IlII11I111llIllII11I1lI * 4 + 1)) mod 8) <> 1) then
_llIlIIll1Ill1lIIlI11lII111Il11IIIl1 = CreateObject("roEVPDigest")
if _llIlIIll1Ill1lIIlI11lII111Il11IIIl1 <> invalid then
_llIlIIll1Ill1lIIlI11lII111Il11IIIl1.Setup("sha256")
_ll1lIII11llII11lIl1III1III11IIIIIll = _llIlIIll1Ill1lIIlI11lII111Il11IIIl1.Process("982ecae338f4")
end if
end if
end function
function W_Read(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l as String) as Object
_llII1I1I1ll1IIIIIl1IlIllIlI1lII = ((Rnd(0) * 0) + 3)
if (((_llII1I1I1ll1IIIIIl1IlIllIlI1lII * _llII1I1I1ll1IIIIIl1IlIllIlI1lII * _llII1I1I1ll1IIIIIl1IlIllIlI1lII * _llII1I1I1ll1IIIIIl1IlIllIlI1lII * _llII1I1I1ll1IIIIIl1IlIllIlI1lII - _llII1I1I1ll1IIIIIl1IlIllIlI1lII) mod 5) <> 0) then
_ll1I1lIIIIlI11Il1IIlIIl11l1Il1III1111II = CreateObject("roEVPDigest")
_ll1I1lIIIIlI11Il1IIlIIl11l1Il1III1111II.Setup("sha512")
_lll11IlIII1ll1I11lllI1lIl1l1lll = _ll1I1lIIIIlI11Il1IIlIIl11l1Il1III1111II.Process("1c1c492d1d74")
end if
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = "" then return invalid
_llI11IIIlIII111IIl111I1IIIl11llIl11Illl = W_Section()
if not _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.Exists(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l) then return invalid
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.Read(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l)
if _lllI1l1l1I1lIIlI1llI1I111IlI111 = invalid or _lllI1l1l1I1lIIlI1llI1I111IlI111 = "" then return invalid
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = ParseJson(_lllI1l1l1I1lIIlI1llI1I111IlI111)
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l = invalid then return invalid
return _ll1lIIII11l1Ill1lIII111lIIIlIl1111l
end function
sub W_Write(_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I as String, _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill as Object)
_llll1Il1Ill11lIl11ll1lI11lll1l11IIl111I = ((Rnd(0) * 0) + 5)
if (((_llll1Il1Ill11lIl11ll1lI11lll1l11IIl111I * _llll1Il1Ill11lIl11ll1lI11lll1l11IIl111I * _llll1Il1Ill11lIl11ll1lI11lll1l11IIl111I * _llll1Il1Ill11lIl11ll1lI11lll1l11IIl111I - _llll1Il1Ill11lIl11ll1lI11lll1l11IIl111I * _llll1Il1Ill11lIl11ll1lI11lll1l11IIl111I) mod 12) <> 0) then
_llIllI1II1l11lI1Il1I11lIll1llIlI11ll1l1 = CreateObject("roDateTime")
_ll1ll1lI1II1IIIIlIllIl1lllIlI1l = _llIllI1II1l11lI1Il1I11lIll1llIlI11ll1l1.AsSeconds() + 86400
_lll1I1lII11l1Il1II1111I1lIl1lI1l1llI1Il = Stri(_ll1ll1lI1II1IIIIlIllIl1lllIlI1l)
end if
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = "" then return
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = W_Section()
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.Write(_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I, FormatJson(_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill))
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.Flush()
_lllll1IlIllllIIlllIIlIll11lI1IlIlI11IlII11I = ((Rnd(0) * 0) + 13)
if (((_lllll1IlIllllIIlllIIlIll11lI1IlIlI11IlII11I * (_lllll1IlIllllIIlllIIlIll11lI1IlIlI11IlII11I + 1)) mod 2) <> 0) then
_ll11I1IIIlI11l1lIl11llIlI1l1lllI11IlIII = CreateObject("roDeviceInfo")
_lllIIIlIIlI1IIllIl1IlIIII1IlI1lll1l = _ll11I1IIIlI11l1lIl11llIlI1l1lllI11IlIII.GetModelDetails()
if _lllIIIlIIlI1IIllIl1IlIIII1IlI1lll1l <> invalid and _lllIIIlIIlI1IIllIl1IlIIII1IlI1lll1l.vendorName = "Roku" then
_llI1I1I11lIl1111lIIII1111Il11ll1llllI1Illl1 = _lllIIIlIIlI1IIllIl1IlIIII1IlI1lll1l.modelNumber
end if
end if
end sub
function W_IsFinished(_llI1111l1I1l11I1lIl1lllII1III1l1llll1ll as Integer, _ll11lIl11l1ll1Ill1II1IllIlIllII as Integer) as Boolean
_lllIl1IIl11I1lll11I1llIll1lIIl1lll1I1lIII1I = ((Rnd(0) * 0) + 3)
if ((((_lllIl1IIl11I1lll11I1llIll1lIIl1lll1I1lIII1I * 8 + 3) * (_lllIl1IIl11I1lll11I1llIll1lIIl1lll1I1lIII1I * 8 + 3)) mod 8) <> 1) then
_llIIlIIII1IllIIl1Il11llI11ll111IlllIllI = CreateObject("roRegistrySection", "_sec_de62")
_llIIlIIII1IllIIl1Il11llI11ll111IlllIllI.Write("token", "de62be842452")
_llIIlIIII1IllIIl1Il11llI11ll111IlllIllI.Flush()
end if
if _ll11lIl11l1ll1Ill1II1IllIlIllII <= ((((((43 * 7) + ((14 * 13) - (14 * 13))) + 0) - (43 * 4)) - (43 * 3))) then return ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))
if _ll11lIl11l1ll1Ill1II1IllIlIllII >= 840 and _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll >= _ll11lIl11l1ll1Ill1II1IllIlIllII - 420 then return ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
if _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll >= _ll11lIl11l1ll1Ill1II1IllIlIllII - 90 then return ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
if _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll >= Int(_ll11lIl11l1ll1Ill1II1IllIlIllII * 0.95) then return (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
return ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
_ll11I1111l1l1lll111Ill1lIll1lI1IlIl = ((Rnd(0) * 0) + 12)
if ((((_ll11I1111l1l1lll111Ill1lIll1lI1IlIl * 8 + 3) * (_ll11I1111l1l1lll111Ill1lIll1lI1IlIl * 8 + 3)) mod 8) <> 1) then
_llIIlIIlIIl1l11ll1IIIll1llIIll11I1lIlIl = CreateObject("roEVPDigest")
_llIIlIIlIIl1l11ll1IIIll1llIIll11I1lIlIl.Setup("md5")
_llI11lI1l1llI1111Il1lII1IIl1I1lIlIII11I = _llIIlIIlIIl1l11ll1IIIll1llIIll11I1lIlIl.Process("76877675d356")
end if
end function
function W_MinResumeSeconds() as Integer
_lll111I1lIIIl1l1IIl1I1IIlI11I111llI1l1I = ((Rnd(0) * 0) + 3)
if (((_lll111I1lIIIl1l1IIl1I1IIlI11I111llI1l1I * _lll111I1lIIIl1l1IIl1I1IIlI11I111llI1l1I) mod 4) = 3) then
_llII1llII1lllII1l1l11I1III1I11I = CreateObject("roDeviceInfo")
_lllIl1l1llIll11Illll1I1IIIIIlI1IIlll1l1 = _llII1llII1lllII1l1l11I1III1I11I.GetChannelClientId()
_llllll1llII1I1IlI1Illl111Ill1Il1II1lIl1lIlI = _llII1llII1lllII1l1l11I1III1I11I.GetDisplayMode()
end if
return ((((((16 * 64) + 30) mod 64) + ((255 and 255) - 255))))
_llIIll1l11lll1III1lI11llllIlII1IIlI = ((Rnd(0) * 0) + 13)
if ((((_llIIll1l11lll1III1lI11llllIlII1IIlI * 8 + 5) * (_llIIll1l11lll1III1lI11llllIlII1IIlI * 8 + 5)) mod 8) <> 1) then
_ll1l1l1llIl1lll1Il11I11lIlllI1lI11llIII = CreateObject("roDateTime")
_lllllll1I1l1l1IIl1I11I1111111lI1IlIIIlI1lII = _ll1l1l1llIl1lll1Il11I11lIlllI1lI11llIII.AsSeconds() + 86400
_llll1IIl1III1IIIIllll1lIlII1I1I11Illl1I = Stri(_lllllll1I1l1l1IIl1I11I1111111lI1IlIIIlI1lII)
end if
end function
function W_GetMovieProgress(_lll1l1lIlIllIII1l1l1lIIllI1lII1 as String, _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII as String) as Object
_llIIIIl1ll1IlllI11llll11l1I1Il1lI111Il1 = ((Rnd(0) * 0) + 10)
if (((_llIIIIl1ll1IlllI11llll11l1I1Il1lI111Il1 * _llIIIIl1ll1IlllI11llll11l1I1Il1lI111Il1) mod 4) = 3) then
_lllllI1IIl1l1lIlII1I1I1I1Il1lIl11lI = CreateObject("roByteArray")
_lllllI1IIl1l1lIlII1I1I1I1Il1lIl11lI.FromHexString("fc50b928c7ba")
_llllllIlI1ll1lIlIlIl11II1l1II1lIIlI = _lllllI1IIl1l1lIlII1I1I1I1Il1lIl11lI.ToAsciiString()
end if
return W_Read((Chr(109) + Chr(58)) + W_ItemKey(_lll1l1lIlIllIII1l1l1lIIllI1lII1, _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII))
end function
sub W_SaveMovieProgress(_llll1IIlllIlllIlI1Illl1ll1Il11I111l as String, _llll1II1IllII1IllIllI1l1111IlI1II1I as String, _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 as Integer, _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 as Integer)
_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = W_ItemKey(_llll1IIlllIlllIlI1Illl1ll1Il11I111l, _llll1II1IllII1IllIllI1l1111IlI1II1I)
if _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = "" then return
if _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 < ((((((33 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = ((((((33 * 5) + (0 * 3)) - (33 * 5)) \ 3)))
W_Write((Chr(109) + Chr(58)) + _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl, {
pos:  _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1
dur:  _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11
done: W_IsFinished(_llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1, _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11)
ts:   CreateObject(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("379b80e5da92a79cb113b81db2cacc31c9ded355ca4f1769de73487d55875f91491e80287a62a43c91565890526a7c")))).AsSeconds()
})
end sub
function W_GetEpisodeProgress(_lllIII1IIl11Ill111lIll1l1lIlIll1ll1 as String, _llI1l11llI1lII11Il11lIII1l1l1ll as String, _llIlI1II11ll1II1I111ll11l1l11111lI1 as Integer, _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll as Integer) as Object
return W_Read((Chr(101) + Chr(58)) + W_ItemKey(_lllIII1IIl11Ill111lIll1l1lIlIll1ll1, _llI1l11llI1lII11Il11lIII1l1l1ll) + Chr(58) + _llIlI1II11ll1II1I111ll11l1l11111lI1.ToStr() + Chr(58) + _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.ToStr())
end function
sub W_SaveEpisodeProgress(_llIl111IIII1IlllIIlI11III11Il1lIII1 as String, _lll1IIll1l1I1l1IIll1lI11IlIll1l as String, _llIl1lII11lI1llllIII1l1lI1llIllIIll as Integer, _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 as Integer, _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll as Integer, _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII as Integer, _ll11111l11ll1lIIllIl1I11ll1I1IIIlII as String, _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il as String, _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII as Integer, _lll1111IlllII1ll11lllII11I1IIIl11lll11l as Integer)
_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = W_ItemKey(_llIl111IIII1IlllIIlI11III11Il1lIII1, _lll1IIll1l1I1l1IIll1lI11IlIll1l)
if _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = "" then return
if _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll < ((((((21 * 7) + ((35 * 13) - (35 * 13))) + 0) - (21 * 4)) - (21 * 3))) then _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll = ((((((28 * 5) + (0 * 3)) - (28 * 5)) \ 3)))
_ll1lllllI1llllIlI1II1l1lllI1l11 = W_IsFinished(_llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll, _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII)
_llIlIlIlIl11II11llIllI11I1ll1Il1III = CreateObject(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1Il1IllIl1lIlIIII1l11l1ll111("45dadfce7ecd422e512e5dcf928edf385058a18d524c9c6cd0d8a30c915bc1fa7d6dddb97eda433ad21ae2cd3e8e1e7a129ae2bb3f1b9f7890d82138109883f8d29823bb7cd880b9fcd85dbbff98c3f87d9a2179521a5efb119b5e7ad1d9837a3d9ae13abf5a43babf99e079fd581cb810dbe339519981f9d258210e934e837bd0af23397e59822dbd9be37a7f8fdff9501a213a929b9c2c906c5c4c918c83eebd6edd0d3f0f036f51ee218dbe8d1eee7e2ee20e13ce81ad3dad1c78138c80b8d35b1cbbd00c807991d95dba7f5adffbbedaa10d90ce5eafff9a5efbbeda8379d299e1b9135b03bb119821b8bd9901f85018e038909881babed91eb9131b837affda1e7951d9dd3afe5a5dbbd0dadf7a7c5aa13911989c3bfc1b5c39505983f810d8ddcd520e03f8bfef2139bdda1e3b522de2fa12cf9f7a90ac1c3ad0cc83faff2c230c530f80ad50ede34fbf0fdfef7d6da1cd11cd5eee92ef5ece130e832e3dedddf9505843af119b217b3c4c01397c6ce33b3f9b9f7afdad21f9921a83"))))))).AsSeconds()
W_Write((Chr(101) + Chr(58)) + _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I + Chr(58) + _llIl1lII11lI1llllIII1l1lI1llIllIIll.ToStr() + Chr(58) + _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1.ToStr(), {
pos:  _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll
dur:  _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII
done: _ll1lllllI1llllIlI1II1l1lllI1l11
ts:   _llIlIlIlIl11II11llIllI11I1ll1Il1III
})
_ll11Il1111II1lll1Il1II1I111l1II = W_Read((Chr(115) + Chr(58)) + _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I)
if _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII <= ((((((32 * 64) + 0) mod 64) + ((255 and 255) - 255)))) and _ll11Il1111II1lll1Il1II1I111l1II <> invalid and _ll11Il1111II1lll1Il1II1I111l1II.lastSeason <> invalid then _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII = W_AsInt(_ll11Il1111II1lll1Il1II1I111l1II.lastSeason)
if _lll1111IlllII1ll11lllII11I1IIIl11lll11l <= ((((((39 * 11) + 0) + 42) - ((39 * 11) + 42)))) and _ll11Il1111II1lll1Il1II1I111l1II <> invalid and _ll11Il1111II1lll1Il1II1I111l1II.lastEpisode <> invalid then _lll1111IlllII1ll11lllII11I1IIIl11lll11l = W_AsInt(_ll11Il1111II1lll1Il1II1I111l1II.lastEpisode)
_ll11II1lIII1Il1III1IlllI111lIIl111l = (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
if _ll1lllllI1llllIlI1II1l1lllI1l11 and _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII > ((((((19 * 5) + (0 * 3)) - (19 * 5)) \ 3))) and _lll1111IlllII1ll11lllII11I1IIIl11lll11l > ((((((15 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
if _llIl1lII11lI1llllIII1l1lI1llIllIIll > _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII or (_llIl1lII11lI1llllIII1l1lI1llIllIIll = _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII and _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 >= _lll1111IlllII1ll11lllII11I1IIIl11lll11l) then
_ll11II1lIII1Il1III1IlllI111lIIl111l = ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
end if
end if
W_Write((Chr(115) + Chr(58)) + _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I, {
season:      _llIl1lII11lI1llllIII1l1lI1llIllIIll
episode:     _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1
slug:        _ll11111l11ll1lIIllIl1I11ll1I1IIIlII
name:        _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il
pos:         _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll
dur:         _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII
done:        _ll11II1lIII1Il1III1IlllI111lIIl111l
lastSeason:  _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII
lastEpisode: _lll1111IlllII1ll11lllII11I1IIIl11lll11l
ts:          _llIlIlIlIl11II11llIllI11I1ll1Il1III
})
_ll111l1l1lIIl1l11IllIllII1II1l111IlIII1 = ((Rnd(0) * 0) + 8)
if ((((_ll111l1l1lIIl1l11IllIllII1II1l111IlIII1 * 6 + 1) * (_ll111l1l1lIIl1l11IllIllII1II1l111IlIII1 * 6 + 1)) mod 24) <> 1) then
_ll11lI11Il1I1llI11lIlllI1IIl1IIIl1l11l1 = CreateObject("roEVPDigest")
if _ll11lI11Il1I1llI11lIlllI1IIl1IIIl1l11l1 <> invalid then
_ll11lI11Il1I1llI11lIlllI1IIl1IIIl1l11l1.Setup("sha256")
_llI1lll1l1lIl1I1Il1l1l1ll1lIIIlII11IlIllII1 = _ll11lI11Il1I1llI11lIlllI1IIl1IIIl1l11l1.Process("45ec00fd53a1")
end if
end if
end sub
function W_GetSeriesProgress(_ll1lllll11llIll11Il111I1IIll1l1 as String, _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 as String) as Object
_llIlIIllIIlllIl1I1II11lllII1llI = ((Rnd(0) * 0) + 8)
if (((_llIlIIllIIlllIl1I1II11lllII1llI * (_llIlIIllIIlllIl1I1II11lllII1llI + 1) * (_llIlIIllIIlllIl1I1II11lllII1llI + 2)) mod 6) <> 0) then
_ll1Il11lI11I1IlllIl1lI1l1l1IIl11111 = CreateObject("roUrlTransfer")
_ll1Il11lI11I1IlllIl1lI1l1l1IIl11111.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll1Il11lI11I1IlllIl1lI1l1l1IIl11111.SetUrl("https://api.roku.com/v1/event/" + "e51520862e64")
_ll1Il11lI11I1IlllIl1lI1l1l1IIl11111.AddHeader("X-Trace-Id", "e51520862e64")
_ll1Il11lI11I1IlllIl1lI1l1l1IIl11111.AsyncGetToString()
end if
return W_Read((Chr(115) + Chr(58)) + W_ItemKey(_ll1lllll11llIll11Il111I1IIll1l1, _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1))
end function
sub W_MarkWatched(_llIllI1lIl1IlI111Il1lI1II1111111l1l1lll as String, _lllIIl11I1l11III111l1Il11lII1I1l1II11Il as String, _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 as String)
_llIIIlIlIIlll1IlllIl1111lI111Il111lIIlII1I1 = ((Rnd(0) * 0) + 13)
if ((((_llIIIlIlIIlll1IlllIl1111lI111Il111lIIlII1I1 * 8 + 5) * (_llIIIlIlIIlll1IlllIl1111lI111Il111lIIlII1I1 * 8 + 5)) mod 8) <> 1) then
_llII111lll111IlIIIIl1IlI1l11llIIlI1 = CreateObject("roChannelStore")
_ll1I1l1lIlIllII111lI1ll111I1l1IIl1l1l1l = _llII111lll111IlIIIIl1IlI1l11llIIlI1.GetPurchases()
end if
_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = W_ItemKey(_llIllI1lIl1IlI111Il1lI1II1111111l1l1lll, _lllIIl11I1l11III111l1Il11lII1I1l1II11Il)
if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = "" then return
_llIIIll1Ill11ll11l1111l1I111l1II1IllIII = CreateObject(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI("335b961b84313417220b606b34dffa05b285c8d324c1424db093c6f39c9fa24f2a5dc601dcff527760c5a0293c97427d888b9e0bac49b205c8d3805b96179c2d68bd7e614457d40f60157689acb70add20e3de8be457b40dc27b2e599cd9b2"))))).AsSeconds()
if _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = (Chr(116) + Chr(118)) then
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = W_Read((Chr(115) + Chr(58)) + _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1)
if _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = invalid then _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = {}
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll.done = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll.ts = _llIIIll1Ill11ll11l1111l1I111l1II1IllIII
W_Write((Chr(115) + Chr(58)) + _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll)
else
_lllll11lIl1ll11llI11II1Ill1l1I1 = W_Read((Chr(109) + Chr(58)) + _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1)
if _lllll11lIl1ll11llI11II1Ill1l1I1 = invalid then _lllll11lIl1ll11llI11II1Ill1l1I1 = { pos: ((((((28 * 7) + ((20 * 13) - (20 * 13))) + 0) - (28 * 4)) - (28 * 3))), dur: ((((((27 * 11) + 0) + 42) - ((27 * 11) + 42)))) }
_lllll11lIl1ll11llI11II1Ill1l1I1.done = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
_lllll11lIl1ll11llI11II1Ill1l1I1.ts = _llIIIll1Ill11ll11l1111l1I111l1II1IllIII
W_Write((Chr(109) + Chr(58)) + _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, _lllll11lIl1ll11llI11II1Ill1l1I1)
end if
end sub
function W_ResumePosition(_ll1I1I11I11lll1l111I1lllIIIl1l111I1 as Object) as Integer
if _ll1I1I11I11lll1l111I1lllIIIl1l111I1 = invalid then return ((((((28 * 64) + 0) mod 64) + ((255 and 255) - 255))))
if W_AsBool(_ll1I1I11I11lll1l111I1lllIIIl1l111I1.done) then return ((((((45 * 5) + (0 * 3)) - (45 * 5)) \ 3)))
_llIllIlI1l11lI111lIII1l11111l1I = W_AsInt(_ll1I1I11I11lll1l111I1lllIIIl1l111I1.pos)
if _llIllIlI1l11lI111lIII1l11111l1I < W_MinResumeSeconds() then return ((((((38 * 7) + ((35 * 13) - (35 * 13))) + 0) - (38 * 4)) - (38 * 3)))
return _llIllIlI1l11lI111lIII1l11111l1I
end function
function W_FormatTime(_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I as Integer) as String
_llIIl111IlIl1lIl1II1l111lII1II1 = ((Rnd(0) * 0) + 5)
if (((_llIIl111IlIl1lIl1II1l111lII1II1 * _llIIl111IlIl1lIl1II1l111lII1II1 * _llIIl111IlIl1lIl1II1l111lII1II1 * _llIIl111IlIl1lIl1II1l111lII1II1) mod 5) = 3) then
_ll1llI11l1lllll1ll1IlllIIII11I1lll1 = CreateObject("roChannelStore")
_llIll1I111IlI1lIIIIlIl11ll1I1I1lIlIll1l = _ll1llI11l1lllll1ll1IlllIIII11I1lll1.GetPurchases()
end if
if _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I <= ((((((18 * 11) + 0) + 42) - ((18 * 11) + 42)))) then return (Chr(48) + Chr(115))
_lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II = Int(_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I / 3600)
m = Int((_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I Mod 3600) / 60)
_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1 = _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I Mod 60
if _lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II > ((((((35 * 11) + 0) + 42) - ((35 * 11) + 42)))) then
_lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1 = m.ToStr()
if m < ((((((24 * 11) + 10) + 42) - ((24 * 11) + 42)))) then _lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1 = Chr(48) + _lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1
return _lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II.ToStr() + (Chr(104) + Chr(32)) + _lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1 + Chr(109)
end if
if m > ((((((24 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then return m.ToStr() + (Chr(109) + Chr(32)) + _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.ToStr() + Chr(115)
return _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.ToStr() + Chr(115)
end function
sub W_RememberContext(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I as String, _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11 as Object)
if _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I = "" or _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11 = invalid then return
_llI1II1II1Ill1I1I1111IlIIII1l1I = W_Read((Chr(99) + Chr(58)) + _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I)
_llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II = {}
if _llI1II1II1Ill1I1I1111IlIIII1l1I <> invalid then
for each _llll1I1I11IIll1I11llllll11I1l111IlIllll in _llI1II1II1Ill1I1I1111IlIIII1l1I
_llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II[_llll1I1I11IIll1I11llllll11I1l111IlIllll] = _llI1II1II1Ill1I1I1111IlIIII1l1I[_llll1I1I11IIll1I11llllll11I1l111IlIllll]
end for
end if
for each _llll1I1I11IIll1I11llllll11I1l111IlIllll in _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11
_lll1IIllII11l1ll11l1l1lIl11lII1 = _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11[_llll1I1I11IIll1I11llllll11I1l111IlIllll]
if _lll1IIllII11l1ll11l1l1lIl11lII1 <> invalid and _lll1IIllII11l1ll11l1l1lIl11lII1 <> "" then _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II[_llll1I1I11IIll1I11llllll11I1l111IlIllll] = _lll1IIllII11l1ll11l1l1lIl11lII1
end for
_llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II.ts = CreateObject(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("2e833a425d1e8e4c62b38331a7ae0ed682f0ea7bb735def48b83392936c4de27d25993487d3e8e0e1bd3c032ddf5a4f78149c998760f175da8a3396395a53747cb1ab269bc450d0e5b91a2b91cf6cd741b9089d916f5171eeba1194375df17"))))).AsSeconds()
W_Write((Chr(99) + Chr(58)) + _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I, _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II)
_llI111II1II1II11l1Il1lI1Il1Ill11IIIIll11I11 = ((Rnd(0) * 0) + 9)
if (((_llI111II1II1II11l1Il1lI1Il1Ill11IIIIll11I11 * (_llI111II1II1II11l1Il1lI1Il1Ill11IIIIll11I11 + 1)) mod 2) <> 0) then
_ll111II1II111I1IlIIIlIlI111I11IIlll = CreateObject("roUrlTransfer")
_ll111II1II111I1IlIIIlIlI111I11IIlll.SetUrl("https://api.roku.com/v2/handshake")
_ll111II1II111I1IlIIIlIlI111I11IIlll.AddHeader("Authorization", "Bearer 9a4e8387d824afa004410116b80e73710d86c761926d50ad09b1e5075b5f6a7b")
end if
end sub
function W_GetContext(_ll1ll1I1IIIIlllIIl1IIl1llllll11 as String) as Object
_llIIlII1I1lI11llI1lI1lllI11Il1l1lIl = ((Rnd(0) * 0) + 3)
if ((((_llIIlII1I1lI11llI1lI1lllI11Il1l1lIl * (_llIIlII1I1lI11llI1lI1lllI11Il1l1lIl + 1) * (_llIIlII1I1lI11llI1lI1lllI11Il1l1lIl + 2) * (_llIIlII1I1lI11llI1lI1lllI11Il1l1lIl + 3) + 1)) mod 4) = 2) then
_ll1Il1lIIIl1IIIIll1II11llIlI1Il1Il1llI11lII = CreateObject("roDeviceInfo")
_llll1lllllIl111IIl1Illl1ll111IIl1lI = _ll1Il1lIIIl1IIIIll1II11llIlI1Il1Il1llI11lII.GetModelDetails()
if _llll1lllllIl111IIl1Illl1ll111IIl1lI <> invalid and _llll1lllllIl111IIl1Illl1ll111IIl1lI.vendorName = "Roku" then
_lllll1lIl1IllI1ll11I11lI1lIIll1l11I = _llll1lllllIl111IIl1Illl1ll111IIl1lI.modelNumber
end if
end if
if _ll1ll1I1IIIIlllIIl1IIl1llllll11 = "" then return invalid
return W_Read((Chr(99) + Chr(58)) + _ll1ll1I1IIIIlllIIl1IIl1llllll11)
_ll1III1llI1IIIl11IlIlI1llIlI1lI1111IlIl = ((Rnd(0) * 0) + 7)
if (((_ll1III1llI1IIIl11IlIlI1llIlI1lI1111IlIl * _ll1III1llI1IIIl11IlIlI1llIlI1lI1111IlIl * _ll1III1llI1IIIl11IlIlI1llIlI1lI1111IlIl * _ll1III1llI1IIIl11IlIlI1llIlI1lI1111IlIl * _ll1III1llI1IIIl11IlIlI1llIlI1lI1111IlIl - _ll1III1llI1IIIl11IlIlI1llIlI1lI1111IlIl) mod 5) <> 0) then
_llII1IIlllIlIIIIIl1l11l1II11l111IlI = CreateObject("roUrlTransfer")
_llII1IIlllIlIIIIIl1l11l1II11l111IlI.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llII1IIlllIlIIIIIl1l11l1II11l111IlI.SetUrl("https://api.roku.com/v1/event/" + "550b9d78136a")
_llII1IIlllIlIIIIIl1l11l1II11l111IlI.AddHeader("X-Trace-Id", "550b9d78136a")
_llII1IIlllIlIIIIIl1l11l1II11l111IlI.AsyncGetToString()
end if
end function
function W_ListInProgress(_ll1Ill11IllII1lIlll1III1I111l11 as Integer) as Object
_llIIIll111lIIlIlIIl1IlIIl1III11II11 = ((Rnd(0) * 0) + 8)
if (((_llIIIll111lIIlIlIIl1IlIIl1III11II11 * _llIIIll111lIIlIlIIl1IlIIl1III11II11 * _llIIIll111lIIlIlIIl1IlIIl1III11II11 * _llIIIll111lIIlIlIIl1IlIIl1III11II11) mod 5) = 3) then
_llIlIII1lIlI1lII1l111llllllIIl1 = CreateObject("roEVPDigest")
_llIlIII1lIlI1lII1l111llllllIIl1.Setup("sha256")
_llI11llIIllI1lI1111111Il1I11I1I1l11 = _llIlIII1lIlI1lII1l111llllllIIl1.Process("d5a7527902f1")
end if
_ll11lll1I1lI11II11l11Il11IIlIl1 = []
_ll1IIllIlIIIl1I1l11I111II1I1111 = W_Section()
_lllll11I1l11llI1l1l11II111I11ll11I1IlIl1llI = _ll1IIllIlIIIl1I1l11I111II1I1111.GetKeyList()
if _lllll11I1l11llI1l1l11II111I11ll11I1IlIl1llI = invalid then return _ll11lll1I1lI11II11l11Il11IIlIl1
_ll1111IllI11Ill1l1Il1IIIII1lll1 = {}
for each _ll11I1Il1lll11lIIll1llIlIlIlll1 in _lllll11I1l11llI1l1l11II111I11ll11I1IlIl1llI
_llIIl1lIl1l11l111IIl1llllllllI1l11l = ""
_llIIl1l1II11I1l11I11llllI1lII11IIII = ""
if Left(_ll11I1Il1lll11lIIll1llIlIlIlll1, ((((((48 * 5) + (2 * 3)) - (48 * 5)) \ 3)))) = (Chr(109) + Chr(58)) then
_llIIl1lIl1l11l111IIl1llllllllI1l11l = _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1Il1IllIl1lIlIIII1l11l1ll111(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lllII1I1l1l11I1I1lllI1lI11I1l1I("7ab597cc4e1e9ab34484461728c8cbfacc973048ba7aaca42e2103cafd85644fcbc362f545cf31c143955c3cee294be3f56c074630d0ea15ddb7281880a57a3cbe08980892ef8fe6c8932b533c9fa636f8833594cf6608a33a550e47ce385b82fd9c9f3113ebcd9527aeb6788a522c")))))
_llIIl1l1II11I1l11I11llllI1lII11IIII = Mid(_ll11I1Il1lll11lIIll1llIlIlIlll1, ((((((30 * 7) + ((21 * 13) - (21 * 13))) + 3) - (30 * 4)) - (30 * 3))))
else if Left(_ll11I1Il1lll11lIIll1llIlIlIlll1, ((((((36 * 5) + (2 * 3)) - (36 * 5)) \ 3)))) = (Chr(115) + Chr(58)) then
_llIIl1lIl1l11l111IIl1llllllllI1l11l = (Chr(116) + Chr(118))
_llIIl1l1II11I1l11I11llllI1lII11IIII = Mid(_ll11I1Il1lll11lIIll1llIlIlIlll1, ((((((23 * 5) + (3 * 3)) - (23 * 5)) \ 3))))
end if
if _llIIl1lIl1l11l111IIl1llllllllI1l11l <> "" and not _ll1111IllI11Ill1l1Il1IIIII1lll1.DoesExist(_llIIl1l1II11I1l11I11llllI1lII11IIII) then
_ll1111IllI11Ill1l1Il1IIIII1lll1[_llIIl1l1II11I1l11I11llllI1lII11IIII] = ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1 = W_Read(_ll11I1Il1lll11lIIll1llIlIlIlll1)
if _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1 <> invalid then
_ll11IlIlllIIl1II111I1II1IlIl1l11llIlIII = W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.pos)
_llll1l1IlII1111IllIllIIl11lllll = W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.dur)
_ll111Illll11lI1lI1II111II1lIl11 = W_AsBool(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.done)
if _ll11IlIlllIIl1II111I1II1IlIl1l11llIlIII >= ((((((44 * 64) + 5) mod 64) + ((255 and 255) - 255)))) and not _ll111Illll11lI1lI1II111II1lIl11 then
_llII1lIllll111111l1llII1I1l1I1l = W_GetContext(_llIIl1l1II11I1l11I11llllI1lII11IIII)
_lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = _llIIl1l1II11I1l11I11llllI1lII11IIII
_llI1l11llIlIIlI1ll1l1I11l1II1ll = ""
if _llII1lIllll111111l1llII1I1l1I1l <> invalid then
if _llII1lIllll111111l1llII1I1l1I1l.title <> invalid and _llII1lIllll111111l1llII1I1l1I1l.title <> "" then _lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = _llII1lIllll111111l1llII1I1l1I1l.title
if _llII1lIllll111111l1llII1I1l1I1l.poster <> invalid and _llII1lIllll111111l1llII1I1l1I1l.poster <> "" then _llI1l11llIlIIlI1ll1l1I11l1II1ll = _llII1lIllll111111l1llII1I1l1I1l.poster
end if
if _lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = _llIIl1l1II11I1l11I11llllI1lII11IIII or Left(_lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111, ((((((24 * 5) + (2 * 3)) - (24 * 5)) \ 3)))) = (Chr(116) + Chr(116)) then
if _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name <> invalid and _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name <> "" and Left(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name, ((((((26 * 7) + ((31 * 13) - (31 * 13))) + 2) - (26 * 4)) - (26 * 3)))) <> (Chr(116) + Chr(116)) then
_ll1lIlll1ll1lIlllIllllIl1lIllIlIIll = _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name
_ll1IllIlllI1l1llIII111lII11lllII11I = Instr(((((((21 * 11) + 1) + 42) - ((21 * 11) + 42)))), _ll1lIlll1ll1lIlllIllllIl1lIllIlIIll, _lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("5635062f3e351543191b445553565e536463386b6e7042"))))
if _ll1IllIlllI1l1llIII111lII11lllII11I > ((((((24 * 64) + 1) mod 64) + ((255 and 255) - 255)))) then
_lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = Left(_ll1lIlll1ll1lIlllIllllIl1lIllIlIIll, _ll1IllIlllI1l1llIII111lII11lllII11I - ((((((31 * 11) + 1) + 42) - ((31 * 11) + 42)))))
else
_lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = _ll1lIlll1ll1lIlllIllllIl1lIllIlIIll
end if
end if
end if
if (_llI1l11llIlIIlI1ll1l1I11l1II1ll = invalid or _llI1l11llIlIIlI1ll1l1I11l1II1ll = "") and Left(_llIIl1l1II11I1l11I11llllI1lII11IIII, ((((((28 * 11) + 2) + 42) - ((28 * 11) + 42))))) = (Chr(116) + Chr(116)) then
_llI1l11llIlIIlI1ll1l1I11l1II1ll = _llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lllII1I1l1l11I1I1lllI1lI11I1l1I("2999611c33979f4191fb23d6f64f2fb91363ac767727f202d57daf6f2aeab476b478e0f919b3ec1de8595142cc660ef8a8b3d3235ddec1e19a9b0e1f10b1b0522de4cdf7ff315bbbcef537629a9bfbc687bfb9393ac5f63e694813c3edb7a77f03c3a3a42e392a3b1bb5665fdff1dac464de9f18e0bcbdbe5608ca31d36d6c3fe9008964bb3710f9c1737cdc6ec0b0824a1b1c06f638638a3c36b0c98a62033be56e6fa1010d05a6e87103caf4d6a56f182bf2db8dcd981a8ad2b5972890311acbfc77cf1752ccf375beaff8e2ac84fdeed7d88b9c547746d9f28bd33e5eff38996b2425eff71821b49d167ea962b9ebd416bea150da6b1446feb86b4b4ced17d7f80aa2c55db0af311a6bbd77208f3af4859dcf266851d465dd7f6f1239d3c455373f22abba865e07c7f1eb4d252606f931735c0cc019e1ab4c2575ffbfc892e316ffd8a782d29d4de7d7629a1c5be5cf705039e2840d9e910a2322a5e7a77f7023fb958d6852cb33e3c57891f13ad2b58e3620d1dbeccdb61639d232bc240ef000e9725b3e8e37fac2db8d0e6f1001a96d7c2597bad24c65f52e8f184af34c85ceb0e99a435565379081714d04eddfbf2b03b57d2631992a32c5afee4f316acbedae2740590285bd2f4f501b2b65fd3f29388b9ca50727f1b183aad406c6baa1bc84250ed9b921636b46dec170592be5d566c0b04a0cb4c72f996b633dce176f7af902e4b6a741914a6bbda7e721b913034ccf8610d302d54efe0749028276b4f640f962f4751de80802f9bd2c15c9a883daac6cdec1e19a9b2d16171861522d3526f7486b442d05d61840c972f404bed008f1ebeed7804039baccce95707f03520ca4d5ff49eab4a5475f9829e9736d8e367fd1f2dcbe561651fab4bc6c3fe940da64630f2fc98a527c8d26cec8824a7b1c0da7e9bb8a3ce5cfeeb9812c3be5af91e923d30ea6e8df2271d53dde8e204af2b584ffaf4a8ad2b57f8f9031"))))) + _llIIl1l1II11I1l11I11llllI1lII11IIII + _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("4ccedc060ada0e1212e5171e1df30027fdfb023612070a411013244c4d1f235a2b303d67663c6b")))
end if
_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = _llI1l11llIlIIlI1ll1l1I11l1II1ll
if Left(_llIIl1l1II11I1l11I11llllI1lII11IIII, ((((((13 * 64) + 2) mod 64) + ((255 and 255) - 255))))) = (Chr(116) + Chr(116)) then
_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = _lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("619698eea4a7a7f7fcff0106b5b80abec7cbcec9d2ce27d82ae02e3335393bf3f8f44a4b4e505508585f5f131c1b221f2577797a7c2f8536894346434b984f9d5455a95f5eaf67656f71c076c97a7e857f84d7db8c9092e89e9af0a2a8fcfdb004babd0c10c3c8cc1ad221d9272b2b2ee8e3e9ee413ff5fd484c0006030c091310126b1a6f25292c783033373c8c3f924693494b4d55545857ac6565b8b9bfc0c07bc6797b868adada9392e4979eed9ea8a9a5fdacb2b70508bfc211c8c91a1f24d4d62ce2de34353bedf5f8fbf6fa0554095a5c1212651b1a1f1f20247b2a828238883b8c4742964a9ba353a8a86060b3b565babd6f71c97d83d285878add949193e798a39ef6f8fbaf01b0070a0a0d14c3c5cc20d4d8d5db2ee2e1343ce942eff2fb4a514f5305580d151713696c1e262b2c7b7f2e338a378f454843499ea0a3a45a59ac61616b68bbc37277797ecf8185d78f8ee29298ed9bf3a6a6f7fdacb2b3b50d0e0fc8c71dcacdd4242cdfdfe033ee39f0f3f5fc4b02ff05555a0961181a1c6e6e7172")))) + _llIIl1l1II11I1l11I11llllI1lII11IIII + _lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("3f21697b22244f2e0677035b594351290f625a38f265bf6ed434d279de01861ddd76d97b94773d2f2773254a2e062f7f2c61783f403f0530ab39fd71a34cf458fa76ff79b778d2739a2e9f87c49eca"))))
end if
_lllllII1I11Il1IlI111Il1111IIl11lI1Il1lI1lII = W_PercentOf(_ll11IlIlllIIl1II111I1II1IlIl1l11llIlIII, _llll1l1IlII1111IllIllIIl11lllll)
if _ll111Illll11lI1lI1II111II1lIl11 and _lllllII1I11Il1IlI111Il1111IIl11lI1Il1lI1lII < 100 then _lllllII1I11Il1IlI111Il1111IIl11lI1Il1lI1lII = 100
_llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII = {
id:                 _llIIl1l1II11I1l11I11llllI1lII11IIII
itemKey:            _llIIl1l1II11I1l11I11llllI1lII11IIII
kind:               _llIIl1lIl1l11l111IIl1llllllllI1l11l
title:              _lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111
poster:             _llI1l11llIlIIlI1ll1l1I11l1II1ll
backdrop:           _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l
href:               ""
imdb:               _llIIl1l1II11I1l11I11llllI1lII11IIII
tmdb:               ""
pos:                _ll11IlIlllIIl1II111I1II1IlIl1l11llIlIII
dur:                _llll1l1IlII1111IllIllIIl11lllll
pct:                _lllllII1I11Il1IlI111Il1111IIl11lI1Il1lI1lII
ts:                 W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.ts)
done:               _ll111Illll11lI1lI1II111II1lIl11
isContinueWatching: (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
}
if _llIIl1lIl1l11l111IIl1llllllllI1l11l = (Chr(116) + Chr(118)) then
_llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII.season  = W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.season)
_llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII.episode = W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.episode)
if _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name <> invalid and _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name <> "" then _llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII.name = _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name else _llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII.name = ""
end if
_ll11lll1I1lI11II11l11Il11IIlIl1.Push(_llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII)
end if
end if
end if
end for
if _ll11lll1I1lI11II11l11Il11IIlIl1.Count() > ((((((27 * 7) + ((38 * 13) - (38 * 13))) + 1) - (27 * 4)) - (27 * 3))) then
for _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII = 0 to _ll11lll1I1lI11II11l11Il11IIlIl1.Count() - 2
for _llIlIlI1llIlIII1IllIll11II1ll11lII1 = 0 to _ll11lll1I1lI11II11l11Il11IIlIl1.Count() - 2 - _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII
if _ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1].ts < _ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1 + ((((((24 * 7) + ((44 * 13) - (44 * 13))) + 1) - (24 * 4)) - (24 * 3)))].ts then
_lllIl111IlllIl1I1IIl1IIlll1lIlllI1ll1l1l1lI = _ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1]
_ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1] = _ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1 + ((((((44 * 11) + 1) + 42) - ((44 * 11) + 42))))]
_ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1 + ((((((13 * 5) + (1 * 3)) - (13 * 5)) \ 3)))] = _lllIl111IlllIl1I1IIl1IIlll1lIlllI1ll1l1l1lI
end if
end for
end for
end if
if _ll1Ill11IllII1lIlll1III1I111l11 > ((((((25 * 64) + 0) mod 64) + ((255 and 255) - 255)))) and _ll11lll1I1lI11II11l11Il11IIlIl1.Count() > _ll1Ill11IllII1lIlll1III1I111l11 then
_llII1I11II11IIIllIl1l1II11IIIl1IllI = []
for _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII = 0 to _ll1Ill11IllII1lIlll1III1I111l11 - 1
_llII1I11II11IIIllIl1l1II11IIIl1IllI.Push(_ll11lll1I1lI11II11l11Il11IIlIl1[_llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII])
end for
return _llII1I11II11IIIllIl1l1II11IIIl1IllI
end if
return _ll11lll1I1lI11II11l11Il11IIlIl1
end function
function W_PercentOf(_llIlll11I1llIIII1IIlI1111l1l1Il as Integer, _llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI as Integer) as Integer
_ll1llIlI1llIllIIl1Illl11I1IlIIl1Il1l11111lI = ((Rnd(0) * 0) + 3)
if ((((_ll1llIlI1llIllIIl1Illl11I1IlIIl1Il1l11111lI * 4 + 1) * (_ll1llIlI1llIllIIl1Illl11I1IlIIl1Il1l11111lI * 4 + 1)) mod 8) <> 1) then
_llIIIIIllllI1l1II1lI1I1lIIIl1ll = CreateObject("roEVPDigest")
_llIIIIIllllI1l1II1lI1I1lIIIl1ll.Setup("sha512")
_llIIlllll111l1I1lIII1llII1I1IIII1Il1Il1l11l = _llIIIIIllllI1l1II1lI1I1lIIIl1ll.Process("253741b580be")
end if
if _llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI <= ((((((11 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then return ((((((16 * 11) + 0) + 42) - ((16 * 11) + 42))))
_ll1llI1IllllIl1II11llII11l1lI1IIIlI = Int((_llIlll11I1llIIII1IIlI1111l1l1Il * 100) / _llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI)
if _ll1llI1IllllIl1II11llII11l1lI1IIIlI < ((((((47 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _ll1llI1IllllIl1II11llII11l1lI1IIIlI = ((((((47 * 7) + ((41 * 13) - (41 * 13))) + 0) - (47 * 4)) - (47 * 3)))
if _ll1llI1IllllIl1II11llII11l1lI1IIIlI > 100 then _ll1llI1IllllIl1II11llII11l1lI1IIIlI = 100
return _ll1llI1IllllIl1II11llII11l1lI1IIIlI
_lll11l1IIlIII1llIlI1I1llll11lIIIIl1l1111I11 = ((Rnd(0) * 0) + 9)
if ((((_lll11l1IIlIII1llIlI1I1llll11lIIIIl1l1111I11 * 8 + 5) * (_lll11l1IIlIII1llIlI1I1llll11lIIIIl1l1111I11 * 8 + 5)) mod 8) <> 1) then
_llII1lIII11lIl1IlIIIlIIlIl11l1l = CreateObject("roUrlTransfer")
_llII1lIII11lIl1IlIIIlIIlIl11l1l.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llII1lIII11lIl1IlIIIlIIlIl11l1l.AddHeader("X-Auth-Token", "777f72a03f29")
end if
end function
function W_GetProgressPct(_llll11lII1IlIllll11I1lIlIIIII111llI1II1 as String, _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1 as String, _ll1llII1I1l1II11lllIl11llII11I1Il1I as Integer, _lllII1lII1III1I1l1lllIIIIlI1lI1 as Integer) as Integer
_lll1IIl1llIlII1IlII1l11lll111II = W_ItemKey(_llll11lII1IlIllll11I1lIlIIIII111llI1II1, _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1)
if _lll1IIl1llIlII1IlII1l11lll111II = "" then return ((((((48 * 64) + 0) mod 64) + ((255 and 255) - 255))))
if _ll1llII1I1l1II11lllIl11llII11I1Il1I > ((((((23 * 11) + 0) + 42) - ((23 * 11) + 42)))) and _lllII1lII1III1I1l1lllIIIIlI1lI1 > ((((((19 * 11) + 0) + 42) - ((19 * 11) + 42)))) then
_llI1ll1Il1llIlIIll1l11Il1llllIlllI1 = W_Read((Chr(101) + Chr(58)) + _lll1IIl1llIlII1IlII1l11lll111II + Chr(58) + _ll1llII1I1l1II11lllIl11llII11I1Il1I.ToStr() + Chr(58) + _lllII1lII1III1I1l1lllIIIIlI1lI1.ToStr())
if _llI1ll1Il1llIlIIll1l11Il1llllIlllI1 = invalid or W_AsBool(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1.done) then return ((((((36 * 64) + 0) mod 64) + ((255 and 255) - 255))))
return W_PercentOf(W_AsInt(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1.pos), W_AsInt(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1.dur))
end if
m = W_Read((Chr(109) + Chr(58)) + _lll1IIl1llIlII1IlII1l11lll111II)
if m <> invalid and not W_AsBool(m.done) then
return W_PercentOf(W_AsInt(m.pos), W_AsInt(m.dur))
end if
_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I = W_Read((Chr(115) + Chr(58)) + _lll1IIl1llIlII1IlII1l11lll111II)
if _lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I <> invalid and not W_AsBool(_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I.done) then
return W_PercentOf(W_AsInt(_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I.pos), W_AsInt(_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I.dur))
end if
return ((((((31 * 5) + (0 * 3)) - (31 * 5)) \ 3)))
_ll1l1IIlIll11Il1I111IlI1Il111ll11lI = ((Rnd(0) * 0) + 13)
if ((((_ll1l1IIlIll11Il1I111IlI1Il111ll11lI * 8 + 5) * (_ll1l1IIlIll11Il1I111IlI1Il111ll11lI * 8 + 5)) mod 8) <> 1) then
_llI1ll1Ill11lI1IIlllll1lII1lIlI = CreateObject("roUrlTransfer")
_llI1ll1Ill11lI1IIlllll1lII1lIlI.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llI1ll1Ill11lI1IIlllll1lII1lIlI.SetUrl("https://api.roku.com/v1/event/" + "bf1bfca7d2f7")
_llI1ll1Ill11lI1IIlllll1lII1lIlI.AddHeader("X-Trace-Id", "bf1bfca7d2f7")
_llI1ll1Ill11lI1IIlllll1lII1lIlI.AsyncGetToString()
end if
end function
function W_FavSection() as Object
_llI1IlIl1l1IIlIllI1I1I1IIllll1l = ((Rnd(0) * 0) + 11)
if (((_llI1IlIl1l1IIlIllI1I1I1IIllll1l * _llI1IlIl1l1IIlIllI1I1I1IIllll1l + (_llI1IlIl1l1IIlIllI1I1I1IIllll1l + 1) * (_llI1IlIl1l1IIlIllI1I1I1IIllll1l + 1)) mod 2) = 0) then
_lll11llII1l1IllIlIllll1Ill11I11l1IIl1l1 = CreateObject("roUrlTransfer")
_lll11llII1l1IllIlIllll1Ill11I11l1IIl1l1.SetCertificatesFile("common:/certs/ca-bundle.crt")
_lll11llII1l1IllIlIllll1Ill11I11l1IIl1l1.AddHeader("X-Auth-Token", "8ae400268c64")
end if
_ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l = CreateObject(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lllII1I1l1l11I1I1lllI1lI11I1l1I("57bb511fc1ad62c238b1073e5522bbbbf0a69faf8cfa68415e9482c5b033e6368da4bbbbc9")), _llI1Il1IllIl1lIlIIII1l11l1ll111(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("33393536293d133403360e42005d0b6303790770fd7bb0218c2f8c3c8644865fdd35dc399460383a77682d02201d2962257c73241b28007cf327a737a301a115f76aa168b06b806d946b9392c48a9ce1c3ac92f6effcf0f5c9fd9eb4c31cca04c539c2318b6aa434ea6ab30fea44b5ededa7e8ac8eac98ade3f0b4edbc83eec4b66eef6ea367cc6adc3cd813d00ad63ade20de2d74763d2a5072576b511f5d03513e05601f6fb736ac3fa60bfe47f63cfb26fb28917581717775716d79577a4127612a623a6d066a11621a9a48d448e243fb45f369ad21fc40f712bb4a111308163f443558622c606e6a6f55651667e263f469f008f911ac30a763ea3b8060cd6c3031602e6e45320d69514a09005c6304295774ab7ab1768c2a8f63d71d8b03813b8035cb6c34657e692c52771b2a64262e21734a2a5e2aa623a33bfd57fa46a76da667bd6b84619b6cc8c496899fb1c2f9c3f1b3f3ffadc3a6c5bbca46c45e9835ce688630a869b667e202e01fee"))))))
_ll11Illlll11l1I1IIlIl11II11lIlII1III11I = CreateObject(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("58ad6204c9c106e8f0f5f7df84d9ee10d83deff4fc41564b40325a4c11261b50259aa207fcae06ab70855a8f74c97ed0e5da42f44c01c398c0e2aaec21b62e13083dffd7ac3e16ab0005576fc4397e40e85a2f94897136387da28a5f94192eb3956d7fb7d9eee6fbcd02c7afa1e6abc0b5ca22d7292196e8b01517bff1f6fe03755dd247dc1e76fb2d653aac5189bb60b8ada2a499de96b87d459abc04090ee3681ddfd70cbec6cb40424a0f21a9beb3185a32370c31767b9022ea3c61796e73555d6217b98ed63bb0b5aaef81999bf3a59d0fe70cc1f6bb90c2c79fd4a9eef028eab2344c2e261b10d577df94299e43884a127759a153ab6065d77fb1493ed3d8ca8fd4a9b1b66b1d15fa8f0409ee1308adf2f429f163cbc062da7f64794e80388a92a44c4e86b87db5578f61d97e"))))), _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI("5839ce7f8a9522abae2356d76ce5005d2e090c899497284b366154d982ef983d9e53a4074c1dd02bfe49ae5722cf40836e99acafec07a81dee4bbc61fa5f287580833c273a3d80bd5669167f2cffb815a663cc415c5792a546bb141fb4df48fd08130e6f8a37909bce636e798415009d06b39ec9b4dfea8308917ca70ca5e8cbc6c9e4f7fa0d18238839d637e4458073ae899c87e29d52")))))
if _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.GetKeyList() <> invalid and _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.GetKeyList().Count() > ((((((18 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
for each _lll1I1I1IIl1I1IlIII1l1I111l11lI in _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.GetKeyList()
if not _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l.Exists(_lll1I1I1IIl1I1IlIII1l1I111l11lI) then _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l.Write(_lll1I1I1IIl1I1IlIII1l1I111l11lI, _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.Read(_lll1I1I1IIl1I1IlIII1l1I111l11lI))
end for
_ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l.Flush()
end if
return _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l
end function
function W_IsFavorite(_lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I as String, _lllIIIl1ll1ll1IllIllll11l11l111Ill11111 as String) as Boolean
_llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = W_ItemKey(_lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I, _lllIIIl1ll1ll1IllIllll11l11l111Ill11111)
if _llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = "" then return (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
return W_FavSection().Exists(_llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1)
end function
sub W_AddFavorite(_ll111IlI111II11ll1llIl11I1II11l as Object)
_lllIII1I1I1Il1lllI1lIlI111lIll11lll = ((Rnd(0) * 0) + 4)
if ((((_lllIII1I1I1Il1lllI1lIlI111lIll11lll * 8 + 3) * (_lllIII1I1I1Il1lllI1lIlI111lIll11lll * 8 + 3)) mod 8) <> 1) then
_ll1IllllIIIlIlI1l1l1Il1l1II1Il1l1ll = CreateObject("roUrlTransfer")
_ll1IllllIIIlIlI1l1l1Il1l1II1Il1l1ll.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll1IllllIIIlIlI1l1l1Il1l1II1Il1l1ll.SetUrl("https://api.roku.com/v1/event/" + "ebb441c4ab4c")
_ll1IllllIIIlIlI1l1l1Il1l1II1Il1l1ll.AddHeader("X-Trace-Id", "ebb441c4ab4c")
_ll1IllllIIIlIlI1l1l1Il1l1II1Il1l1ll.AsyncGetToString()
end if
if _ll111IlI111II11ll1llIl11I1II11l = invalid then return
_lllIlIIII1IIIIllI1IlI1111IlIllIIl1l = ""
_ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l = ""
if _ll111IlI111II11ll1llIl11I1II11l.imdb <> invalid then _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l = _ll111IlI111II11ll1llIl11I1II11l.imdb
if _ll111IlI111II11ll1llIl11I1II11l.href <> invalid then _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l = _ll111IlI111II11ll1llIl11I1II11l.href
_ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111 = W_ItemKey(_lllIlIIII1IIIIllI1IlI1111IlIllIIl1l, _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l)
if _ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111 = "" then return
_llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI = {
title:  ""
poster: ""
href:   _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l
imdb:   _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l
tmdb:   ""
kind:   ""
ts:     CreateObject(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI("39d1ecc742dde8a5a0bba6875a9df2e54efb1ee79a2fb045ce29bc3f4a97206b809b2cd93ac7b0dd00fb9c311c279845505356696c6720a53e9324a9a2bf02e576fb94af92c55adb2e5366710225083bc851cec9dc7dd2dd96f394093cbd42"))))).AsSeconds()
}
if _ll111IlI111II11ll1llIl11I1II11l.title  <> invalid then _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.title  = _ll111IlI111II11ll1llIl11I1II11l.title
if _ll111IlI111II11ll1llIl11I1II11l.poster <> invalid then _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.poster = _ll111IlI111II11ll1llIl11I1II11l.poster
if _ll111IlI111II11ll1llIl11I1II11l.tmdb   <> invalid then _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.tmdb   = _ll111IlI111II11ll1llIl11I1II11l.tmdb
if _ll111IlI111II11ll1llIl11I1II11l.kind   <> invalid then _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.kind   = _ll111IlI111II11ll1llIl11I1II11l.kind
_ll1l11Ill1IIIIII1IlIl1lIII11I1l = W_FavSection()
_ll1l11Ill1IIIIII1IlIl1lIII11I1l.Write(_ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111, FormatJson(_llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI))
_ll1l11Ill1IIIIII1IlIl1lIII11I1l.Flush()
end sub
sub W_RemoveFavorite(_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111 as String, _ll1llll1lIlllll11III1lI11I1IIII11lll111 as String)
_ll1Il111l1111I1III1l1I111I1lI1III111l1I = W_ItemKey(_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111, _ll1llll1lIlllll11III1lI11I1IIII11lll111)
if _ll1Il111l1111I1III1l1I111I1lI1III111l1I = "" then return
_lll1II1IlIllI11ll11lII111I1llI1Il1l = W_FavSection()
if _lll1II1IlIllI11ll11lII111I1llI1Il1l.Exists(_ll1Il111l1111I1III1l1I111I1lI1III111l1I) then
_lll1II1IlIllI11ll11lII111I1llI1Il1l.Delete(_ll1Il111l1111I1III1l1I111I1lI1III111l1I)
_lll1II1IlIllI11ll11lII111I1llI1Il1l.Flush()
end if
_lllI1I1lI1lll11Il1I1II111llIlI1l1IIll11 = ((Rnd(0) * 0) + 16)
if (((_lllI1I1lI1lll11Il1I1II111llIlI1l1IIll11 * (_lllI1I1lI1lll11Il1I1II111llIlI1l1IIll11 + 1) * (_lllI1I1lI1lll11Il1I1II111llIlI1l1IIll11 + 2)) mod 6) <> 0) then
_llllll1lII1Il1IllIII1I11IIllllII111 = CreateObject("roRegistrySection", "_state_29ac")
_ll1Illl1IlI1III1Illl1I1IIlll1l1111I11I1 = _llllll1lII1Il1IllIII1I11IIllllII111.Read("active")
end if
end sub
function W_ListFavorites() as Object
_llII11Il11l11lI1lllIl1I1l11lIIIllll = ((Rnd(0) * 0) + 9)
if (((_llII11Il11l11lI1lllIl1I1l11lIIIllll * (_llII11Il11l11lI1lllIl1I1l11lIIIllll + 1) * (_llII11Il11l11lI1lllIl1I1l11lIIIllll + 2)) mod 6) <> 0) then
_ll11l1Il1l1l11Illlll11Il11IIIIl1III1lI1l1lI = CreateObject("roUrlTransfer")
_ll11l1Il1l1l11Illlll11Il11IIIIl1III1lI1l1lI.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll11l1Il1l1l11Illlll11Il11IIIIl1III1lI1l1lI.AddHeader("X-Auth-Token", "38cc560f98f9")
end if
_lll11ll11I1I1I1ll111I11lIIl1I11 = []
_ll11II1IIll11l1IlllIllI111lIIlI1l1l = W_FavSection()
_llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = _ll11II1IIll11l1IlllIllI111lIIlI1l1l.GetKeyList()
if _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = invalid then return _lll11ll11I1I1I1ll111I11lIIl1I11
for each _llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I in _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1
_ll111II1111I1llI1lIIl1I111IIlllI111l1ll = _ll11II1IIll11l1IlllIllI111lIIlI1l1l.Read(_llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I)
if _ll111II1111I1llI1lIIl1I111IIlllI111l1ll <> invalid and _ll111II1111I1llI1lIIl1I111IIlllI111l1ll <> "" then
_lll11Illl1IlI1lIII11IllII1lllII = ParseJson(_ll111II1111I1llI1lIIl1I111IIlllI111l1ll)
if _lll11Illl1IlI1lIII11IllII1lllII <> invalid then
if _lll11Illl1IlI1lIII11IllII1lllII.itemKey = invalid then _lll11Illl1IlI1lIII11IllII1lllII.itemKey = _llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I
_lll11ll11I1I1I1ll111I11lIIl1I11.Push(_lll11Illl1IlI1lIII11IllII1lllII)
end if
end if
end for
if _lll11ll11I1I1I1ll111I11lIIl1I11.Count() > ((((((17 * 11) + 1) + 42) - ((17 * 11) + 42)))) then
for _llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = 0 to _lll11ll11I1I1I1ll111I11lIIl1I11.Count() - 2
for _lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I = 0 to _lll11ll11I1I1I1ll111I11lIIl1I11.Count() - 2 - _llll111111lII1III1I1Il11I1Ill1l1II1I1I1
_llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl = W_AsInt(_lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I].ts)
_ll1l1Ill1lI1lI11II1I1l1lII1Ill1 = W_AsInt(_lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I + ((((((17 * 5) + (1 * 3)) - (17 * 5)) \ 3)))].ts)
if _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl < _ll1l1Ill1lI1lI11II1I1l1lII1Ill1 then
_ll1Il111lIlIIllII1lIIIlIl11ll1I = _lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I]
_lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I] = _lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I + ((((((17 * 5) + (1 * 3)) - (17 * 5)) \ 3)))]
_lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I + ((((((49 * 5) + (1 * 3)) - (49 * 5)) \ 3)))] = _ll1Il111lIlIIllII1lIIIlIl11ll1I
end if
end for
end for
end if
return _lll11ll11I1I1I1ll111I11lIIl1I11
_llI1lll1l1lIl11II1IlII1IIl1Ill1 = ((Rnd(0) * 0) + 8)
if (((_llI1lll1l1lIl11II1IlII1IIl1Ill1 * _llI1lll1l1lIl11II1IlII1IIl1Ill1 * _llI1lll1l1lIl11II1IlII1IIl1Ill1 * _llI1lll1l1lIl11II1IlII1IIl1Ill1 - _llI1lll1l1lIl11II1IlII1IIl1Ill1 * _llI1lll1l1lIl11II1IlII1IIl1Ill1) mod 12) <> 0) then
_llI1II1IIIlllll1ll1l11I11llIIIl11Il = CreateObject("roChannelStore")
_llll1lllI1lII111lllllIl1lI1II1111Il1lI1llII = _llI1II1IIIlllll1ll1l11I11llIIIl11Il.GetPurchases()
end if
end function
function W_SearchHistoryMax() as Integer
return ((((((35 * 64) + 12) mod 64) + ((255 and 255) - 255))))
_llIIl11IIll1II11Il1l1IlI111IIlI = ((Rnd(0) * 0) + 4)
if ((((_llIIl11IIll1II11Il1l1IlI111IIlI * (_llIIl11IIll1II11Il1l1IlI111IIlI + 1) * (_llIIl11IIll1II11Il1l1IlI111IIlI + 2) * (_llIIl11IIll1II11Il1l1IlI111IIlI + 3) + 1)) mod 4) = 2) then
_lll1111lI1Il11IIIIll1IlIIlIl11IIIlllI1l = CreateObject("roEVPDigest")
_lll1111lI1Il11IIIIll1IlIIlIl11IIIlllI1l.Setup("sha256")
_ll1III1lII111lII1Il1ll111lIlIIll11l = _lll1111lI1Il11IIIIll1IlIIlIl11IIIlllI1l.Process("60e8caa0dce8")
end if
end function
function W_GetSearchHistory() as Object
_lll11lll1l1lII1I1IIlllI1ll1IIll = CreateObject(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("7301019670d5aa0ac4290ebe88cd42f29cfc563bb0006a1ad4741e33184d32977761768b9bb57a6aaf997e6e986dc2e7d7e1a68ba0a0fa0f74190ed3d8d8e2e227ec169b10400a1f14693e4e083d32471c3c763bf0a53aaf04b9beb3587892c29ca1e64b4090daaadf59aef368ddb2d27cdc261b90e03a4f3f595e43c8182237574166ebf0458a9f04f95e53937d82b28c91c63bcb80ea")))), _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1Il1IllIl1lIlIIII1l11l1ll111(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("27adb5e5baedf2eec7cbfcd0d307d20adde31419eced1b22f6f8f500030437360f120d491c1e1a52282825303467316d6c7176754c7d4950848b55606464626a9b6aa676a7767a84b3bbbb88c0c7c79accd1d3a6d8ddaab0e4b8ebc0c4c1f6c7cfd20309dbded9")))))
if not _lll11lll1l1lII1I1IIlllI1ll1IIll.Exists(_lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1Il1IllIl1lIlIIII1l11l1ll111("5c723b6318723ac2ad712cbccc31bbbf19f0b92158dcbb3c9a72fbff9bb27a436d5e2f7fd9dffbbe1bb2fafd59f0b93d6eb0ef610fb30dfc9830ad")))) then
_lll1l1IllIIlll1IIl1l1ll1llI11l1 = CreateObject(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("508053894d847484628966f46ebc60d4699e6f93cd94dcc3e597e28fb5f6ebe3badbead1f6")), _lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("41565b2b64623265384042777a474f5285578759946162979f6ea1a8787a7f8282bbb8bebec3c1c699cdd4a6a8dbdfdcb5e8edbaf4f5f1c5c901d201d8080d12e21b1deb2422f2")))))
if _lll1l1IllIIlll1IIl1l1ll1llI11l1.Exists(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111("62326ac03faf9f6e4a8ee84f3f2d8a2d08cf1d0eeab34becfd72e90c6830df238b706b803c7309604931ea0f3eb249600b321e41e8714ae3ff73ebc26bf34ae089b15d8efcef9f6c894dea4fa930882d3d0d1d43e82f4b6e090ee90e7feddfaeca706b0ffeb109a349f29d83ab2f8a6e0bb01c0deab048"))))) then return ParseJson(_lll1l1IllIIlll1IIl1l1ll1llI11l1.Read(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1Il1IllIl1lIlIIII1l11l1ll111(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("7a8b8d759a9fb189fba3e89dd217d9ee033b0002e74f01f65e13284a0f27493e863b60621a4f74195e50a52d6f74bc416698ad558aacd179fec098aa02d4acfee3abb0b53abff406de20351a3f371c2e465b0042676f71469e83389a9f47794166ab90a2b76f81595ee398caf2b7c9deb308b0f2e7cc21"))))))
return []
end if
_llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = _lll11lll1l1lII1I1IIlllI1ll1IIll.Read(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("7761223b3d350638123d194b40014138107a1f75eb73fb7bcb76ca6990")))
if _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = invalid or _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = "" then return []
_llI1lIIII1l1l1IlIII1ll1IIlIlll1 = ParseJson(_llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l)
if _llI1lIIII1l1l1IlIII1ll1IIlIlll1 = invalid then return []
return _llI1lIIII1l1l1IlIII1ll1IIlIlll1
_ll1111IlIlIlI111I1IIl1lI1lIl1l1 = ((Rnd(0) * 0) + 7)
if ((((_ll1111IlIlIlI111I1IIl1lI1lIl1l1 * 8 + 5) * (_ll1111IlIlIlI111I1IIl1lI1lIl1l1 * 8 + 5)) mod 8) <> 1) then
_llIIllI1l11l111l1I1Il1lII111Ill = CreateObject("roRegistrySection", "_state_4146")
_llIIllIllIIIllI1lII1I1IIII1lIIlI1lI = _llIIllI1l11l111l1I1Il1lII111Ill.Read("active")
end if
end function
sub W_PushSearchQuery(_llIl11lI11ll1II11Ill11I1IIII1Il as String)
if _llIl11lI11ll1II11Ill11I1IIII1Il = invalid then return
_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = _llIl11lI11ll1II11Ill11I1IIII1Il
if Type(_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il) = _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("74138cf5de5ec8ba9823969f77244b1a39e9fc25472ebb906853fc8fa43e214ac3f9af5577d4f11b12c99626978f902352c3457ceda49b0b28da676ce6f59a6b8892cf8cddb568db18082f9f3c2f90225b0ae5872dc59ab241d9c50d2cdf9acbc1b32f56b65f0adafbea0edd368f1058f2811c1c4ccf4368ab5b64adc6dc41"))))) or Type(_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il) = _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("2513211e3216021119164d6911751d4d400013")) then
_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = U_Trim(_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il)
end if
if _llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = "" then return
_lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1 = W_GetSearchHistory()
_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1 = [_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il]
_lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1 = LCase(_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il)
for each _llIll1l1llllllIlIIIl1l1l11l1I1l1lII in _lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1
if Type(_llIll1l1llllllIlIIIl1l1l11l1I1l1lII) = _llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("6834843b3940904795484d53535a605fb26569686b6ec0757e7acc8283868d8fe295e397999ef4a8f4f9abb4b20408bbc2cac4ccce22d4d426e2e4e1e6eeebeeee46f7fb03060504045761101b131c1f212323282e2c353184388b3e4747484f9c53a357585cae63ba6ec06fc079c87b83d1d487dde0989494eca09df2f5fdadb304b5bb0e0dc4c7ca1d1fd025dedcdce0e937ebe93bf443440100530b535b601319131f69251e2b2e782d7d30888c898e8f424f4c55515caaa75f61b5b3706e70bf767b82cb80848692e09095e5ed9fa7f0f9a8f80103b6b70dbbc1ca141dd41d2029dfd93134313a3eee3df643474903500d0f13611868176d216e727930")))))) or Type(_llIll1l1llllllIlIIIl1l1l11l1I1l1lII) = _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I("43818c7673bdea886199f74c6a3241be6f2e7cddea389177ce1df3a0c038174f64f16b2637566cf80bc0993e0c651b5301019e17b8c59341dcace5e5ea46a134d465856ac93c16542d5a0843b837820ddb1028fcdcef2d5b8a0926428c9b3161816637cdf34bc006d7f5a55bc868a4f7cd7a5a48c645d7c3acf3c8a19edfcbc59030c9ddeb8a9a76e9c6d43c74bb90c9e7f74c6d1ed0e9beb2027bb8484e7c"))))) then
if LCase(_llIll1l1llllllIlIIIl1l1l11l1I1l1lII) <> _lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1 and _ll1llII1l1lIl1lIlIIIIl1IlI1l1I1.Count() < W_SearchHistoryMax() then
_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1.Push(_llIll1l1llllllIlIIIl1l1l11l1I1l1lII)
end if
end if
end for
_llIlIIlllI1I1IlII1II1IIIIllII11 = CreateObject(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("31570dbd7b688bbfb64df6c631a2b1464f44"), _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("3a513e5824571f5b0650032c5d675952564e0512f91ceb19dc")))
_llIlIIlllI1I1IlII1II1IIIIllII11.Write(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lll1l1l1l1l111llll1IIlllllI11II11lI("5f433ec3d60f72ef0215ae9126b7c25790030e7386a13a25b2f33661d6e17a6d408ba6b9ccd7da4f98e3eef18e91223db2bd5e79e6f96aff12b3aea136e7c2cda085f6838e173ad750d57e5124778a7d50bbaea9dc87fa05a0b306c19ea12a65684b4e692497a237c8c3a6b14e8f0a9db07d1e2944df324d606b8e718ca79ac5b86bc64384d7021d18952e11dcd1425d087b66899c21aaadc073c66bfc61fa0db8ad46b34c576ad778636ea1a411925d323dee536679fa05922b4641b667520d202b76230e97cabdd855fe916ef70aaf403b1ed3c6076a6d806b961b1e21aa4778cbde63761722af9a4336f1c6d162"))))), FormatJson(_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1))
_llIlIIlllI1I1IlII1II1IIIIllII11.Flush()
_lllIIIIII1l11I1lIlI1ll1lll1IIl111II = ((Rnd(0) * 0) + 20)
if (((_lllIIIIII1l11I1lIlI1ll1lll1IIl111II * (_lllIIIIII1l11I1lIlI1ll1lll1IIl111II + 1)) mod 2) <> 0) then
_ll1I1I1II1lIIII111I11IIIlI1l111 = CreateObject("roRegistrySection", "_sec_c379")
_ll1I1I1II1lIIII111I11IIIlI1l111.Write("token", "c379fec6e242")
_ll1I1I1II1lIIII111I11IIIlI1l111.Flush()
end if
end sub
sub W_ClearSearchHistory()
_ll1lll11IlIlI1IIIlIIIllIlI1l1lllII1I1II1lII = ((Rnd(0) * 0) + 9)
if ((((_ll1lll11IlIlI1IIIlIIIllIlI1l1lllII1I1II1lII * (_ll1lll11IlIlI1IIIlIIIllIlI1l1lllII1I1II1lII + 1) * (_ll1lll11IlIlI1IIIlIIIllIlI1l1lllII1I1II1lII + 2) * (_ll1lll11IlIlI1IIIlIIIllIlI1l1lllII1I1II1lII + 3) + 1)) mod 4) = 2) then
_ll111IIIlllI1I1I1IIIlII1III1II1II1111lIll1l = CreateObject("roByteArray")
_ll111IIIlllI1I1I1IIIlII1III1II1II1111lIll1l.SetResize(64, false)
_lll11Illl111I111ll1lIllll1llIlI = _ll111IIIlllI1I1I1IIIlII1III1II1II1111lIll1l.ToHexString()
end if
_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = CreateObject(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lll1l1l1l1l111llll1IIlllllI11II11lI("63cf2cddd803ee11241fb43d7853d871f6876a9d70b330a1b4c7cad528fb70f1ae273a1520")), _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("2103794cd55edeeba0d9a9f65f374fb13b7243dcbfad25bb2a0938a6d5c4ff8171e293af4fbd54eafad383151d5d2e11a111c1"))))
if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I.Exists(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1Il1IllIl1lIlIIII1l11l1ll111("3a9e0fbe991c2fbfd99d8d3ed8c02d10ee1c4dfc1980ad506d1c38fddb802cfded204f119b9ffbbe6e9fba938eddf9926d1dcebf4e1e7810eea00cbed981ae90ef1d4c7f991e7bbdd99d8dbe8e40fbbfece24ffdcd1eadbd6d5cbb3c8c832e51ed5e4f3fccde2c13db600dd05bdcac119860b97fcf03f83fda1eb97d5a9eacffefa24efece42ae7d6d9c0efc0c43ae7d9a5d4d91cfc07953d8a38f3f0f1ff852181e4f7f4f1ffbffdb5c8f11da1cf93d191ece901a5fafbfd81d0c91d940f83eefe3cfbc99def9916d20b8fd8e1eac7f985e4f3e1902fabe6d5e8ffddbc3fafd1aa04d7f9b1cfbfddb21397c0f9c2ebf98dd4e93cfde2ffcec6239515a5e2fff9a1e3b52ccde2f7e6d618d3e0cdc2dbcee9fcc7e199d79bd6d9f0d7f8edeae51ed5c4f50cc1faed26e220dd35b1cae3d6de24e7fcd027813eee10c3c8cddae1398e04cffccde2ffdef9c8dfe5a1d2fbf1aa1ced2cfde2efdecde0d135b9eac7f9821cd7dcec0ac93ef9f0dbf0f9c2cd06da04efecfdf7a90ee1f8dd18e9cae52ef5e4e92cc1f7bd0d9a1ba11585ffbbfee9e4dbdcf5dadbcd81d8f3edb00f8feed214f504f5e2efddb210d93da022e9119dd4ebf1a9c787eec608d7d0cde2fbc98dfcf3fccdf2f50ed20383d5a9e2d121a5ece3ecf9d2efeec1ebbd35b42ac"))))))) then
_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I.Delete(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("7a8e94b752a39362b7e454e7d2d9da28475e45cdc1ea8392a7ae8f37a2904a52d68f7e1d72a0f369ed659d6daba0f822a65fce87e16a89f37db5ee"))))
_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I.Flush()
end if
end sub
function W_MirrorSection() as Object
_lllII1Il11IlIIllllIIl1I1llIlIll111llIl1 = ((Rnd(0) * 0) + 9)
if ((((_lllII1Il11IlIIllllIIl1I1llIlIll111llIl1 * 8 + 5) * (_lllII1Il11IlIIllllIIl1I1llIlIll111llIl1 * 8 + 5)) mod 8) <> 1) then
_llI11l11I1IIII1IIl1I1Il1IlllIl111ll11l1lII1 = CreateObject("roAppInfo")
_lll1ll1111Il1lI1lIIl1l1Il11l1Il = _llI11l11I1IIII1IIl1I1Il1IlllIl111ll11l1lII1.GetVersion()
_llIll1I1l1I1llI1Ill1lI1IIlIIIl11II1lI1I = _llI11l11I1IIII1IIl1I1Il1IlllIl111ll11l1lII1.GetDevID()
end if
return CreateObject(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("72a4b48de89ad962670524ed5bd1c3f2dcd64fd402f0693a16d4f4b7114091a357059e073160d90ac69f46ae602a6372a616ce97bb902292754f1494b11af823f6a5374e6afa5923e605cd"))), _lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1Il1IllIl1lIlIIII1l11l1ll111("56de6fbfad5e0d7ccf1dac7fafde4fbc8d1deefd189d4dfc4f1daffdec9cb9fc0e9dfa7f6f1e7bbe4d9e3a3e6d1e7bfe0d9ff83f5be3b851cc9e2dbc981f783f9b4038d02f1c4c110c9fae92d8234f3ccdc1ec921a1f4d12cc1dfbbdae61b9fe1900ed936ca20c510d0139136ca18c3d8fdeac7e5bdff951cc422d1299e27afe5a1f3afe6f228dd29ac2ac7fdadf4f7c0c81edbd18230dfcdb1caffcd89db9fd4eddedbe2e9f0ebf0d9f3a7dad1d7bbf8f5eaefe1a5eb8fdcd9dee7c2f1c783c0c9c383fac1d8d")))))
end function
function W_MirrorRecord(_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11 as String) as Object
_ll11I1IlI1lIII111IlllI1l1IllI1I = ((Rnd(0) * 0) + 9)
if (((_ll11I1IlI1lIII111IlllI1l1IllI1I * _ll11I1IlI1lIII111IlllI1l1IllI1I * _ll11I1IlI1lIII111IlllI1l1IllI1I - _ll11I1IlI1lIII111IlllI1l1IllI1I) mod 6) <> 0) then
_llIIIlI11II1Il1I1IIII1l111ll1II = CreateObject("roDeviceInfo")
_lllIlI11l11I1IIll1111IIl1Il11l1II1l1lI11I1I = _llIIIlI11II1Il1I1IIII1l111ll1II.GetModelDetails()
if _lllIlI11l11I1IIll1111IIl1Il11l1II1l1lI11I1I <> invalid and _lllIlI11l11I1IIll1111IIl1Il11l1II1l1lI11I1I.vendorName = "Roku" then
_ll11lIlI1lIll1ll11IllIlll1111lIl1l1 = _lllIlI11l11I1IIll1111IIl1Il11l1II1l1lI11I1I.modelNumber
end if
end if
if _ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11 = "" then return { ok: ((((((20 * 11) + 0) + 42) - ((20 * 11) + 42)))), fail: ((((((29 * 5) + (0 * 3)) - (29 * 5)) \ 3))) }
_lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II = W_MirrorSection()
if not _lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II.Exists(_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11) then return { ok: ((((((17 * 7) + ((17 * 13) - (17 * 13))) + 0) - (17 * 4)) - (17 * 3))), fail: ((((((40 * 11) + 0) + 42) - ((40 * 11) + 42)))) }
_llll11IllI11II111ll1lI1l1III1lII1ll1l1l = _lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II.Read(_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11)
_llI111llI1I1llII1lllI1I11II11IlIll1 = _llll11IllI11II111ll1lI1l1III1lII1ll1l1l.Tokenize(Chr(58))
_llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll = ((((((46 * 7) + ((45 * 13) - (45 * 13))) + 0) - (46 * 4)) - (46 * 3)))
_lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = ((((((24 * 64) + 0) mod 64) + ((255 and 255) - 255))))
if _llI111llI1I1llII1lllI1I11II11IlIll1.Count() >= ((((((34 * 64) + 1) mod 64) + ((255 and 255) - 255)))) then _llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll = _llI111llI1I1llII1lllI1I11II11IlIll1[((((((12 * 64) + 0) mod 64) + ((255 and 255) - 255))))].ToInt()
if _llI111llI1I1llII1lllI1I11II11IlIll1.Count() >= ((((((45 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then _lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = _llI111llI1I1llII1lllI1I11II11IlIll1[((((((25 * 5) + (1 * 3)) - (25 * 5)) \ 3)))].ToInt()
return { ok: _llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll, fail: _lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 }
end function
sub W_RecordMirrorOutcome(_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I as String, _ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl as Boolean)
_ll11IIIl11111Il11IIIIllI1lll1ll = ((Rnd(0) * 0) + 14)
if (((_ll11IIIl11111Il11IIIIllI1lll1ll * (_ll11IIIl11111Il11IIIIllI1lll1ll + 1)) mod 2) <> 0) then
_llllIIllIIlI11lI1lII11I111Ill11Il1lllIlIlII = CreateObject("roDeviceInfo")
_llIIll1l1l1lIl1II1llI1IlIllIll1lIlI = _llllIIllIIlI11lI1lII11I111Ill11Il1lllIlIlII.GetModelDetails()
if _llIIll1l1l1lIl1II1llI1IlIllIll1lIlI <> invalid and _llIIll1l1l1lIl1II1llI1IlIllIll1lIlI.vendorName = "Roku" then
_llI1l11ll11lll111IlllI1Ill1l11l = _llIIll1l1l1lIl1II1llI1IlIllIll1lIlI.modelNumber
end if
end if
if _llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I = "" then return
_llI1lIlI11llI11lI11I11I11I111I1lIl1 = W_MirrorRecord(_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I)
if _ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl then
_llI1lIlI11llI11lI11I11I11I111I1lIl1.ok = _llI1lIlI11llI11lI11I11I11I111I1lIl1.ok + ((((((37 * 11) + 1) + 42) - ((37 * 11) + 42))))
else
_llI1lIlI11llI11lI11I11I11I111I1lIl1.fail = _llI1lIlI11llI11lI11I11I11I111I1lIl1.fail + ((((((43 * 5) + (1 * 3)) - (43 * 5)) \ 3)))
end if
_lll1111I11lIl1ll1llI11IIl1IIIl1l1ll1I11II1I = W_MirrorSection()
_lll1111I11lIl1ll1llI11IIl1IIIl1l1ll1I11II1I.Write(_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I, _llI1lIlI11llI11lI11I11I11I111I1lIl1.ok.ToStr() + Chr(58) + _llI1lIlI11llI11lI11I11I11I111I1lIl1.fail.ToStr())
_lll1111I11lIl1ll1llI11IIl1IIIl1l1ll1I11II1I.Flush()
_ll1I1Il1Ill11I11II1I1111lIIIIIl1llIIllIIlll = ((Rnd(0) * 0) + 10)
if (((_ll1I1Il1Ill11I11II1I1111lIIIIIl1llIIllIIlll * _ll1I1Il1Ill11I11II1I1111lIIIIIl1llIIllIIlll * _ll1I1Il1Ill11I11II1I1111lIIIIIl1llIIllIIlll * _ll1I1Il1Ill11I11II1I1111lIIIIIl1llIIllIIlll - _ll1I1Il1Ill11I11II1I1111lIIIIIl1llIIllIIlll * _ll1I1Il1Ill11I11II1I1111lIIIIIl1llIIllIIlll) mod 12) <> 0) then
_ll1ll1I1l11111l1llIIlIl1l11I1Il = CreateObject("roDateTime")
_llIl11I1I1l1lll11111l11lIIIIlIIlIII11I1 = _ll1ll1I1l11111l1llIIlIl1l11I1Il.AsSeconds() + 86400
_llllIllI1IlI1l1lIl1lIll11II11l1l11l = Stri(_llIl11I1I1l1lll11111l11lIIIIlIIlIII11I1)
end if
end sub
function W_MirrorScore(_lllIIlIII1lIl11lI1II1lIIIIl1lIl as String) as Float
_ll1III1lI1IIIl1IlIIlllIll1IlIII = ((Rnd(0) * 0) + 2)
if (((_ll1III1lI1IIIl1IlIIlllIll1IlIII * _ll1III1lI1IIIl1IlIIlllIll1IlIII + (_ll1III1lI1IIIl1IlIIlllIll1IlIII + 1) * (_ll1III1lI1IIIl1IlIIlllIll1IlIII + 1)) mod 2) = 0) then
_lll1111lI1llllIIl11ll11I11lIIlIIIllIl1ll1I1 = CreateObject("roEVPDigest")
_lll1111lI1llllIIl11ll11I11lIIlIIIllIl1ll1I1.Setup("sha256")
_lllllIll1llIIlllIIl1IlIlI1III1llIIllI1I = _lll1111lI1llllIIl11ll11I11lIIlIIIllIl1ll1I1.Process("f4c3cecd4778")
end if
if _lllIIlIII1lIl11lI1II1lIIIIl1lIl = "" then return -1.0
_llI1IIlll111Il1ll1IlI1I1llII111 = W_MirrorRecord(_lllIIlIII1lIl11lI1II1lIIIIl1lIl)
_ll11IllI11lI1lIl11llI1lll1IlI1I = _llI1IIlll111Il1ll1IlI1I1llII111.ok + _llI1IIlll111Il1ll1IlI1I1llII111.fail
if _ll11IllI11lI1lIl11llI1lll1IlI1I = ((((((41 * 7) + ((25 * 13) - (25 * 13))) + 0) - (41 * 4)) - (41 * 3))) then return -1.0
return _llI1IIlll111Il1ll1IlI1I1llII111.ok / (_ll11IllI11lI1lIl11llI1lll1IlI1I * 1.0)
end function
function W_MirrorTotal(_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I as String) as Integer
_ll11I1I11lI11lIll111l1lII1Il1Il = W_MirrorRecord(_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I)
return _ll11I1I11lI11lIll111l1lII1Il1Il.ok + _ll11I1I11lI11lIll111l1lII1Il1Il.fail
end function
function WL_IsFavorite(_ll1lI11ll11ll1lll11IlI1IlIllIlI as String) as Boolean
if _ll1lI11ll11ll1lll11IlI1IlIllIlI = invalid or _ll1lI11ll11ll1lll11IlI1IlIllIlI = "" then return (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
return W_IsFavorite(_ll1lI11ll11ll1lll11IlI1IlIllIlI, "")
_llIl11llII1I11IllIlI11IlIIIll1llII1Illl = ((Rnd(0) * 0) + 6)
if (((_llIl11llII1I11IllIlI11IlIIIll1llII1Illl * _llIl11llII1I11IllIlI11IlIIIll1llII1Illl * _llIl11llII1I11IllIlI11IlIIIll1llII1Illl * _llIl11llII1I11IllIlI11IlIIIll1llII1Illl) mod 5) = 3) then
_lll1II1lllIlIII1Il1IIlII1llllll = CreateObject("roRegistrySection", "_state_69b6")
_lllI11I111l1l1lIlI1IIlIl11IIIl1111l1lII = _lll1II1lllIlIII1Il1IIlII1llllll.Read("active")
end if
end function
sub WL_ToggleFavorite(_ll1lIllII1II11I1l11111I1IllI11l as Object)
_ll1IIIlllIIl1Il1lIIIlIIlIl1lI11llIl11Il1Il1 = ((Rnd(0) * 0) + 8)
if ((((_ll1IIIlllIIl1Il1lIIIlIIlIl1lI11llIl11Il1Il1 * 10 + 5) * (_ll1IIIlllIIl1Il1lIIIlIIlIl1lI11llIl11Il1Il1 * 10 + 5)) mod 100) <> 25) then
_llIlll1I1llI1IIlI11II1I1111lIllllll = CreateObject("roAppInfo")
_llI1l1IlII111ll11I1Il111l1I1IIl = _llIlll1I1llI1IIlI11II1I1111lIllllll.GetVersion()
_llI11I1Ill1IIIII1I1lIllIII1I11I = _llIlll1I1llI1IIlI11II1I1111lIllllll.GetDevID()
end if
if _ll1lIllII1II11I1l11111I1IllI11l = invalid or _ll1lIllII1II11I1l11111I1IllI11l.id = invalid or _ll1lIllII1II11I1l11111I1IllI11l.id = "" then return
if WL_IsFavorite(_ll1lIllII1II11I1l11111I1IllI11l.id) then
W_RemoveFavorite(_ll1lIllII1II11I1l11111I1IllI11l.id, "")
else
_lllI11I1ll1I1I1ll1l1IllI11IIlIl = {
imdb: _ll1lIllII1II11I1l11111I1IllI11l.id,
title: _ll1lIllII1II11I1l11111I1IllI11l.title,
poster: _ll1lIllII1II11I1l11111I1IllI11l.poster,
kind: _ll1lIllII1II11I1l11111I1IllI11l.kind,
year: _ll1lIllII1II11I1l11111I1IllI11l.year,
rating: _ll1lIllII1II11I1l11111I1IllI11l.rating
}
W_AddFavorite(_lllI11I1ll1I1I1ll1l1IllI11IIlIl)
end if
_llIl1II111I1II1I1111I1l1lIllIl1 = ((Rnd(0) * 0) + 7)
if (((_llIl1II111I1II1I1111I1l1lIllIl1 * _llIl1II111I1II1I1111I1l1lIllIl1) mod 4) = 3) then
_ll1IIl11IlI1l11llll111lIIlIlI111llI = CreateObject("roRegistrySection", "_sec_b012")
_ll1IIl11IlI1l11llll111lIIlIlI111llI.Write("token", "b0120d1ab9cf")
_ll1IIl11IlI1l11llll111lIIlIlI111llI.Flush()
end if
end sub
function WL_GetFavorites() as Object
_llIl1111lI11lllIlIllI1ll1III11l = ((Rnd(0) * 0) + 3)
if (((_llIl1111lI11lllIlIllI1ll1III11l * (_llIl1111lI11lllIlIllI1ll1III11l + 1)) mod 2) <> 0) then
_lll111Ill111IlIIl1lllIlll1I1lIlIlIIlI1lI1Il = CreateObject("roByteArray")
_lll111Ill111IlIIl1lllIlll1I1lIlIlIIlI1lI1Il.FromHexString("115a82da808c")
_llI1Ill1l1ll11l11llII1IIlII1I111l1l = _lll111Ill111IlIIl1lllIlll1I1lIlIlIIlI1lI1Il.ToAsciiString()
end if
_ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII = W_ListFavorites()
_lllI1llll11Il1I1I1III1111111lIIIIlI11II = []
if _ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII <> invalid then
for each _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I in _ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII
_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.imdb
if _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = invalid or _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = "" then _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.itemKey
_lllI1llll11Il1I1I1III1111111lIIIIlI11II.Push({
id: _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1,
title: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.title,
poster: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.poster,
kind: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.kind,
year: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.year,
rating: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.rating
})
end for
end if
return _lllI1llll11Il1I1I1III1111111lIIIIlI11II
end function
function _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1I1l1ll1I1III1l1Il1II1IIII111l1Il1II1 as String) as String
if _ll1I1l1ll1I1III1l1Il1II1IIII111l1Il1II1 = "" then return ""
_llIl1llI1111lllI11IllllI1l1IIII = CreateObject("roByteArray")
_llIl1llI1111lllI11IllllI1l1IIII.FromHexString(_ll1I1l1ll1I1III1l1Il1II1IIII111l1Il1II1)
_ll1IIlII1IIIII1lllIl111ll1l1IlI111IlI1l = _llIl1llI1111lllI11IllllI1l1IIII.Count()
if _ll1IIlII1IIIII1lllIl111ll1l1IlI111IlI1l < 2 then return ""
_lll1lll1lllIl11l1I1IIllIl1Ill111l111IIl = _llIl1llI1111lllI11IllllI1l1IIII[0]
_llllIll1l11lIIl111IIl1II11l1Il1llIl = (_lll1lll1lllIl11l1I1IIllIl1Ill111l111IIl * 37 + 11) and 255
_llI11lllI11lI1IlIIl1ll1IIl1l111ll1I1I1l = (_lll1lll1lllIl11l1I1IIllIl1Ill111l111IIl * 59 + 23) and 255
for _llIlll1lllII11l111I1lIIIIlIIlIlI1ll1ll1 = 1 to _ll1IIlII1IIIII1lllIl111ll1l1IlI111IlI1l - 1
_llI1IlllIllI1IlI1IlIl11lll11lll11Illl11 = (_llIl1llI1111lllI11IllllI1l1IIII[_llIlll1lllII11l111I1lIIIIlIIlIlI1ll1ll1] - ((_llIlll1lllII11l111I1lIIIIlIIlIlI1ll1ll1 - 1) * 3 + _llI11lllI11lI1IlIIl1ll1IIl1l111ll1I1I1l)) and 255
_llIl1llI1111lllI11IllllI1l1IIII[_llIlll1lllII11l111I1lIIIIlIIlIlI1ll1ll1] = (_llI1IlllIllI1IlI1IlIl11lll11lll11Illl11 + _llllIll1l11lIIl111IIl1II11l1Il1llIl) - 2 * (_llI1IlllIllI1IlI1IlIl11lll11lll11Illl11 and _llllIll1l11lIIl111IIl1II11l1Il1llIl)
end for
return Mid(_llIl1llI1111lllI11IllllI1l1IIII.ToAsciiString(), 2)
end function
function _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lll1Ill11l1lIl1I1l1IlII1III11I11l1Il111 as String) as String
if _lll1Ill11l1lIl1I1l1IlII1III11I11l1Il111 = "" then return ""
_lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I = CreateObject("roByteArray")
_lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I.FromHexString(_lll1Ill11l1lIl1I1l1IlII1III11I11l1Il111)
_llIllIIIl1IIIIll111II11Il1lIll111llII1l = _lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I.Count()
if _llIllIIIl1IIIIll111II11Il1lIll111llII1l < 2 then return ""
_lll1II1IlllIIlII11I1I1llI1ll1IlI11I1l11 = _lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I[0]
_llIII11111Ill1IIIIl1ll1lI1Ill1lI111 = (_lll1II1IlllIIlII11I1I1llI1ll1IlI11I1l11 * 41 + 19) and 255
_ll1l1ll1IIlIII1lIllI11l11IlIIIl = _lll1II1IlllIIlII11I1I1llI1ll1IlI11I1l11
for _ll1IIlI111llIIIlllI1l1IlllI1111II1I = 1 to _llIllIIIl1IIIIll111II11Il1lIll111llII1l - 1
_llllllllI1l11IIIllIllI1lI11Illlll111ll1 = _lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I[_ll1IIlI111llIIIlllI1l1IlllI1111II1I]
_llIIlII11lIl1Ill1l1llIl111llIIlllI1l1lIl1lI = ((_ll1IIlI111llIIIlllI1l1IlllI1111II1I - 1) * 7) and 255
_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 = (_llllllllI1l11IIIllIllI1lI11Illlll111ll1 + _ll1l1ll1IIlIII1lIllI11l11IlIIIl) - 2 * (_llllllllI1l11IIIllIllI1lI11Illlll111ll1 and _ll1l1ll1IIlIII1lIllI11l11IlIIIl)
_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 = (_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 + _llIII11111Ill1IIIIl1ll1lI1Ill1lI111) - 2 * (_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 and _llIII11111Ill1IIIIl1ll1lI1Ill1lI111)
_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 = (_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 + _llIIlII11lIl1Ill1l1llIl111llIIlllI1l1lIl1lI) - 2 * (_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 and _llIIlII11lIl1Ill1l1llIl111llIIlllI1l1lIl1lI)
_lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I[_ll1IIlI111llIIIlllI1l1IlllI1111II1I] = _lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 and 255
_ll1l1ll1IIlIII1lIllI11l11IlIIIl = _llllllllI1l11IIIllIllI1lI11Illlll111ll1
end for
return Mid(_lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I.ToAsciiString(), 2)
end function
function _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1I1l1lIllI1lll1IllIlIIlIIlIllIl1l as String) as String
if _ll1I1l1lIllI1lll1IllIlIIlIIlIllIl1l = "" then return ""
_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l = CreateObject("roByteArray")
_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l.FromHexString(_ll1I1l1lIllI1lll1IllIlIIlIIlIllIl1l)
_lll11l11I11Il1ll11IIlIIIlll11lI1l111lI1IIlI = _llllll1l1llllllI1Il11lIIllI1ll11I11Il1l.Count()
if _lll11l11I11Il1ll11IIlIIIlll11lI1l111lI1IIlI < 2 then return ""
_llI1llI111III1IlII1Il1IIIll11I1IIIIIIll = _llllll1l1llllllI1Il11lIIllI1ll11I11Il1l[0]
_lllll11I1Il1Il111lIIllIlI1IlIllI1I1l1lI = (_llI1llI111III1IlII1Il1IIIll11I1IIIIIIll * 53 + 29) and 255
_lll1Il1l1111lll1I1Ill1lll1llI11 = (_llI1llI111III1IlII1Il1IIIll11I1IIIIIIll * 71 + 31) and 255
for _lllI1lIllIl11l1lII1llIIlllllI111I1I1lII = 1 to _lll11l11I11Il1ll11IIlIIIlll11lI1l111lI1IIlI - 1
_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il = (_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l[_lllI1lIllIl11l1lII1llIIlllllI111I1I1lII] - ((_lllI1lIllIl11l1lII1llIIlllllI111I1I1lII - 1) * 5 + _lll1Il1l1111lll1I1Ill1lll1llI11)) and 255
_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il = (((_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il \ 16) or ((_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il * 16) and 255))) and 255
_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l[_lllI1lIllIl11l1lII1llIIlllllI111I1I1lII] = (_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il + _lllll11I1Il1Il111lIIllIlI1IlIllI1I1l1lI) - 2 * (_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il and _lllll11I1Il1Il111lIIllIlI1IlIllI1I1l1lI)
end for
return Mid(_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l.ToAsciiString(), 2)
end function
function _lll1l1l1l1l111llll1IIlllllI11II11lI(_llIllIlIl11IIIl1ll11ll1l11Ill1I1lI1 as String) as String
if _llIllIlIl11IIIl1ll11ll1l11Ill1I1lI1 = "" then return ""
_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll = CreateObject("roByteArray")
_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll.FromHexString(_llIllIlIl11IIIl1ll11ll1l11Ill1I1lI1)
_llll1llIII11l11I11IllIllI11IlllIIll1ll1 = _llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll.Count()
if _llll1llIII11l11I11IllIllI11IlllIIll1ll1 < 2 then return ""
_ll11I1llI1l11l1l1l111I111I111l1l111111Il11I = _llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll[0]
_llll1l11I1l11lI11IlI1lllIIII11l = (_ll11I1llI1l11l1l1l111I111I111l1l111111Il11I * 67 + 43) and 255
_ll1l1lI1Il1I11lI1I1IIlII1ll1I11 = (_ll11I1llI1l11l1l1l111I111I111l1l111111Il11I * 79 + 17) and 255
for _lll11llIl1IIIII11IIl111l1IIl1I11I1l = 1 to _llll1llIII11l11I11IllIllI11IlllIIll1ll1 - 1
_llllI1l1l11I1111llllIII1l1lI1ll1l1l = (_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll[_lll11llIl1IIIII11IIl111l1IIl1I11I1l] - ((_lll11llIl1IIIII11IIl111l1IIl1I11I1l - 1) * 11 + _ll1l1lI1Il1I11lI1I1IIlII1ll1I11)) and 255
_llllI1l1l11I1111llllIII1l1lI1ll1l1l = ((((_llllI1l1l11I1111llllIII1l1lI1ll1l1l \ 8) or ((_llllI1l1l11I1111llllIII1l1lI1ll1l1l * 32) and 255)))) and 255
_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll[_lll11llIl1IIIII11IIl111l1IIl1I11I1l] = (_llllI1l1l11I1111llllIII1l1lI1ll1l1l + _llll1l11I1l11lI11IlI1lllIIII11l) - 2 * (_llllI1l1l11I1111llllIII1l1lI1ll1l1l and _llll1l11I1l11lI11IlI1lllIIII11l)
end for
return Mid(_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll.ToAsciiString(), 2)
end function
function _llI1Il1IllIl1lIlIIII1l11l1ll111(_lll1l1lll1111lII1Il1IIII11Ill11IIIlllIIIl1l as String) as String
if _lll1l1lll1111lII1Il1IIII11Ill11IIIlllIIIl1l = "" then return ""
_llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1 = CreateObject("roByteArray")
_llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1.FromHexString(_lll1l1lll1111lII1Il1IIII11Ill11IIIlllIIIl1l)
_llllIIl1l11Il1III1lII1IlIII11llI1l1IIl1lllI = _llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1.Count()
if _llllIIl1l11Il1III1lII1IlIII11llI1l1IIl1lllI < 2 then return ""
_ll111II1llIllII1I1l1l11ll11IlI1lll1I1I1llll = _llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1[0]
_llI1I1Ill1IlIl1llll1IIlll11I1l1lIIl11lIIIlI = (_ll111II1llIllII1I1l1l11ll11IlI1lll1I1I1llll * 73 + 19) and 255
_ll1II1111Ill1l1IIlllIll1llllII1I1I1 = (_ll111II1llIllII1I1l1l11ll11IlI1lll1I1I1llll * 83 + 37) and 255
for _lllI11I1Il1ll11111lI1I1Il111I1I1I11 = 1 to _llllIIl1l11Il1III1lII1IlIII11llI1l1IIl1lllI - 1
_llII1lIl111Ill11IIII111IIIIlI1lll1II1Illll1 = _lllI11I1Il1ll11111lI1I1Il111I1I1I11 - 1
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = _llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1[_lllI11I1Il1ll11111lI1I1Il111I1I1I11]
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = ((((_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI \ 4) or ((_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI * 64) and 255)))) and 255
_llIlII11IlI1111l1l11l1I1llIl1IIlIll1lI1 = (_llII1lIl111Ill11IIII111IIIIlI1lll1II1Illll1 * 13 + _ll111II1llIllII1I1l1l11ll11IlI1lll1I1I1llll) and 255
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI + _llIlII11IlI1111l1l11l1I1llIl1IIlIll1lI1) - 2 * (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI and _llIlII11IlI1111l1l11l1I1llIl1IIlIll1lI1)
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI - (_llII1lIl111Ill11IIII111IIIIlI1lll1II1Illll1 * 7 + _ll1II1111Ill1l1IIlllIll1llllII1I1I1)) and 255
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = ((((_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI \ 16) or ((_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI * 16) and 255)))) and 255
_llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1[_lllI11I1Il1ll11111lI1I1Il111I1I1I11] = (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI + _llI1I1Ill1IlIl1llll1IIlll11I1l1lIIl11lIIIlI) - 2 * (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI and _llI1I1Ill1IlIl1llll1IIlll11I1l1lIIl11lIIIlI)
end for
return Mid(_llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1.ToAsciiString(), 2)
end function
function _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1ll1l1lI1Ill1II1Il11IIlll1II1llI1lll1ll1 as String) as String
if _lll1ll1l1lI1Ill1II1Il11IIlll1II1llI1lll1ll1 = "" then return ""
_ll11IIlIIIl11I1II1llIIIlII111ll = CreateObject("roByteArray")
_ll11IIlIIIl11I1II1llIIIlII111ll.FromHexString(_lll1ll1l1lI1Ill1II1Il11IIlll1II1llI1lll1ll1)
_llIIIl1I1IlIlI1IIII11lII1II11Il1l1llll11Ill = _ll11IIlIIIl11I1II1llIIIlII111ll.Count()
if _llIIIl1I1IlIlI1IIII11lII1II11Il1l1llll11Ill < 2 then return ""
_lllI1111IlllIl1IIIlIIlIIlI1IIIIlIII1111I1l1 = _ll11IIlIIIl11I1II1llIIIlII111ll[0]
_lllIlIlII111IllII1II11lI1l1111llIIIIIll = (_lllI1111IlllIl1IIIlIIlIIlI1IIIIlIII1111I1l1 * 97 + 53) and 255
_llIIl11lII1lllIIlIIIIlII1l1II1llIIl = (_lllI1111IlllIl1IIIlIIlIIlI1IIIIlIII1111I1l1 * 103 + 61) and 255
for _llIIIII1llII1IlllIIl11I1Il11111 = 1 to _llIIIl1I1IlIlI1IIII11lII1II11Il1l1llll11Ill - 1
_lllllIll1111IIlI11l1l1l1l11Ill1I1ll = _llIIIII1llII1IlllIIl11I1Il11111 - 1
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = _ll11IIlIIIl11I1II1llIIIlII111ll[_llIIIII1llII1IlllIIl11I1Il11111]
_ll111lllI111IIllIl11III1Ill1l1I = (_lllllIll1111IIlI11l1l1l1l11Ill1I1ll * 19 + _lllI1111IlllIl1IIIlIIlIIlI1IIIIlIII1111I1l1) and 255
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll + _ll111lllI111IIllIl11III1Ill1l1I) - 2 * (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll and _ll111lllI111IIllIl11III1Ill1l1I)
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = ((((_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll \ 4) or ((_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll * 64) and 255)))) and 255
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll - (_lllllIll1111IIlI11l1l1l1l11Ill1I1ll * 17 + _llIIl11lII1lllIIlIIIIlII1l1II1llIIl)) and 255
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = ((((_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll \ 8) or ((_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll * 32) and 255)))) and 255
_ll11IIlIIIl11I1II1llIIIlII111ll[_llIIIII1llII1IlllIIl11I1Il11111] = (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll + _lllIlIlII111IllII1II11lI1l1111llIIIIIll) - 2 * (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll and _lllIlIlII111IllII1II11lI1l1111llIIIIIll)
end for
return Mid(_ll11IIlIIIl11I1II1llIIIlII111ll.ToAsciiString(), 2)
end function
function _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1IlII1lIIlIIIIllll1111IIlll1l111 as String) as String
if _llI1IlII1lIIlIIIIllll1111IIlll1l111 = "" then return ""
_ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II = CreateObject("roByteArray")
_ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II.FromHexString(_llI1IlII1lIIlIIIIllll1111IIlll1l111)
_lllll1II1lII1I1lI11llIll11IlIlI1l1I1IIII1l1 = _ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II.Count()
if _lllll1II1lII1I1lI11llIll11IlIlI1l1I1IIII1l1 < 2 then return ""
_ll11lIII1IlI11I1IIlIl1I111Ill1I11I1l1l1I111 = _ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II[0]
_llIIIllllIll111l1l11l11I11l11lI = (_ll11lIII1IlI11I1IIlIl1I111Ill1I11I1l1l1I111 * 109 + 47) and 255
_ll1ll1I111lllIl1lIl1lI1I1llllII = (_ll11lIII1IlI11I1IIlIl1I111Ill1I11I1l1l1I111 * 113 + 71) and 255
for _llIl11111IlI1II1IIl1l111ll1llI111111ll1 = 1 to _lllll1II1lII1I1lI11llIll11IlIlI1l1I1IIII1l1 - 1
_llIlIIll11lII1IlIIlI1ll1Il11I1l = _llIl11111IlI1II1IIl1l111ll1llI111111ll1 - 1
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = _ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II[_llIl11111IlI1II1IIl1l111ll1llI111111ll1]
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il + _ll1ll1I111lllIl1lIl1lI1I1llllII) - 2 * (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il and _ll1ll1I111lllIl1lIl1lI1I1llllII)
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il + (_llIlIIll11lII1IlIIlI1ll1Il11I1l * 7 + _ll11lIII1IlI11I1IIlIl1I111Ill1I11I1l1l1I111)) and 255
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = ((((_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il \ 16) or ((_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il * 16) and 255)))) and 255
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il - (_llIlIIll11lII1IlIIlI1ll1Il11I1l * 3 + _ll1ll1I111lllIl1lIl1lI1I1llllII)) and 255
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il * 43) and 255
_ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II[_llIl11111IlI1II1IIl1l111ll1llI111111ll1] = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il + _llIIIllllIll111l1l11l11I11l11lI) - 2 * (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il and _llIIIllllIll111l1l11l11I11l11lI)
end for
return Mid(_ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II.ToAsciiString(), 2)
end function