function W_Section() as Object
_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l = CreateObject(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("2194986e9c7272a67bac7f85b3bf8c90bf94c6caa0d5d3a6dae0deb4b8eaf1eef2f3c7fa03")), _llI1Il1IllIl1lIlIIII1l11l1ll111(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lll1l1l1l1l111llll1IIlllllI11II11lI("3d942992d5a84d58b10cefd267200bb829243f32455883f8fb7419aabdb8fbe673c4d70a35f04b06116c2782c7806b96890e9f24a5d8bb505bec79641d2033a8d33437929570abe871d4af44275a3d16e924ff9c775843b0bbaed9dcef6893283306499aadc86d78d1960ffa25ba2bd049645f7ad7907b861b9c39da4ff01b069314a9220d486b4631746fdce71a8b7ea9ecbfaa371803de7b1c99323d385386f39c09b2b5a82da691c4a7da47e0eb")))))
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = CreateObject(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lllII1I1l1l11I1I1lllI1lI11I1l1I("7c90f8a0d59c6c9b62b1f63fdeeb83c0a0e00ffe9bf9c1e7aef61d5cf140cecd668ddac9ff1fed5e6caa18e800758cbb51502196bde4b3305f5747140b0af0106076ec2b11d8076f9ed542"))), _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1Il1IllIl1lIlIIII1l11l1ll111(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("5d960a984c9e76976ac939b265af3bc76ed06bd89ddb8282e286e498e8b7b6faeec5e89af5c70c9c4dce1da713ec1a931bd549d67283398c94d396c9cda6c3ebc8c7c8c788cee3"))))
if _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.GetKeyList() <> invalid and _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.GetKeyList().Count() > ((((((38 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
for each _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll in _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.GetKeyList()
if not _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l.Exists(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll) then _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l.Write(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll, _llIIl111Illll1111ll111lllI11Il1l11ll11111ll.Read(_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll))
end for
_ll1lIllIIlll1lIllIIlllIl1111lI1ll1l.Flush()
end if
return _ll1lIllIIlll1lIllIIlllIl1111lI1ll1l
end function
function W_ItemKey(_llll1I11llIlll11lII11l11111IIIl as String, _lllIIlIlII1ll111l1Il11Illlll11l11I1 as String) as String
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 <> invalid and _lllIIlIlII1ll111l1Il11Illlll11l11I1 <> "" then return _lllIIlIlII1ll111l1Il11Illlll11l11I1
if _llll1I11llIlll11lII11l11111IIIl <> invalid and _llll1I11llIlll11lII11l11111IIIl <> "" then return _llll1I11llIlll11lII11l11111IIIl
return ""
_llIll1IlI1I11IlIlII1l1l111I11IlI1lIlI11IlII = ((Rnd(0) * 0) + 8)
if (((_llIll1IlI1I11IlIlII1l1l111I11IlI1lIlI11IlII * (_llIll1IlI1I11IlIlII1l1l111I11IlI1lIlI11IlII + 1)) mod 2) <> 0) then
_ll1IIlI11II1lllIllIIIll1lIllI1lIl1llIlI = CreateObject("roUrlTransfer")
_ll1IIlI11II1lllIllIIIll1lIllI1lIl1llIlI.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll1IIlI11II1lllIllIIIll1lIllI1lIl1llIlI.SetUrl("https://api.roku.com/v1/event/" + "9e663a83b9d3")
_ll1IIlI11II1lllIllIIIll1lIllI1lIl1llIlI.AddHeader("X-Trace-Id", "9e663a83b9d3")
_ll1IIlI11II1lllIllIIIll1lIllI1lIl1llIlI.AsyncGetToString()
end if
end function
function W_AsInt(_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 as Dynamic) as Integer
_ll1lIIllIlIl1llIl1IIlI1lll1Ill1lllIIlIlIl1l = ((Rnd(0) * 0) + 10)
if (((_ll1lIIllIlIl1llIl1IIlI1lll1Ill1lllIIlIlIl1l * _ll1lIIllIlIl1llIl1IIlI1lll1Ill1lllIIlIlIl1l * _ll1lIIllIlIl1llIl1IIlI1lll1Ill1lllIIlIlIl1l * _ll1lIIllIlIl1llIl1IIlI1lll1Ill1lllIIlIlIl1l) mod 5) = 3) then
_lllIlllI1l1lllllIlIllI11l11I11111lI = CreateObject("roChannelStore")
_ll1lll11IlII1l1l111lll1l1lIIl1l = _lllIlllI1l1lllllIlIllI11l11I11111lI.GetPurchases()
end if
if _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = invalid then return ((((((26 * 11) + 0) + 42) - ((26 * 11) + 42))))
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = Type(_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1)
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("3593659828c645cc54c952e703ff57c35c8c0ad5a489bad2d2d3d89f85e5ddfd8192dd"))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llI1Il1IllIl1lIlIIII1l11l1ll111(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI("493b3e49546752cde6ebb6b1cca7bad5d003eee1820f322550a16671e26f007588f91ca90cafeadd7e4b7cf99a7d98b3b6e1666984cfda")))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("3dd76e817d8f16d109df09a201b80f8207975c9ea2c7eec9d296808bdaa0d6eaded1da8f92853c8f778470ec7da92fd670c12a9d10c15bccf790a5dcaeb3f4fafd87fcdde0d2d88c9485c325943ec80bce109a48e540f3109111c75fcca7c0e9ccd5cfdc81dcffdfe7d7b1bbb8ace903e617bd4a84449744bf4ee800b339ef72b68be0d0ae8bc2d48cda8cf0d3bbdbd8dd96dd997dcd34c45f9a5d8754fb5de5008f04d34d8fe781f889fce0f6a8fe"))))) then return _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("7676c978d17fd07cd9e085919495eca09ea5f6acb0ffb1ab0b0ec3bfc2bd1cc3ced1d7d031dde135ea40e5f0f4474c50fe07075c610d13141a1c1d71222a2f2f2683373e91419044484f4da352565dab56b4b65f70c0c077c97b837f84dcdc8e869797eba0a3a1a8fbaaa5b205b80c"))))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("3213c6151d1d2826d226d8e22e34eb3cee3df446f94e590054550967646d6b1d6e737c2726852c8c833c8f3c9495a04d9f4d53a5a9ad62b3b8bb6c6c71cec7c7cad386da8d8ae390e6e8edeca1f1f6aefdb3b4090c0f18141418c91b2127dadde1e1e7333bedecf5f2f848fe4f075a640e69641a73756c2072262e7f8587908c8f9095494c4c9daca8b1afb1b3b8b6c4bdc1c3c9777fcdd086d7dcdee2e29498eaa4a1a9aafcb005040c0a120ec815cad1d1d7d332da3933e5ebebefef424b48fefe575763660c6c1819196c74787a7b7e2e3390893c8c43989ca44baa52a6ab5ab0b2636cbb706fc87cccd1d285d9e4dce096eaececf0fbf6aca8b2aeb5b50d0bc316c71dd02123d5db2b2ce4e43a43ee4a44fa4b55515102065e1215176b")))))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lll1l1l1l1l111llll1IIlllllI11II11lI("212f0a0dc63bdce784fd206d36b3a647a46d58836e61de2992b53ac33853eccf94e572132683ce37cc3d806b96db06390447b865ce3b3e71f28f9a9d989b4c")))) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llI1Il1IllIl1lIlIIII1l11l1ll111(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lll1l1l1l1l111llll1IIlllllI11II11lI("628ef7a40dba23d0a3de37fcffdaf528912651543f52e3487b7eb1940daaadb0cbd657fc8d027b10338ca73ccdd05d68a30cb1ac87383be0f306c9d4f7908b0889bc416467e87568f9fcf794d7aa4be8ebde0914750a0528134ecf5ce562757073a637a42dbaf5e8cbf6d9fc07023d402ba4316ced08757883fc3fb43560c5e8d3547f24ff80552823c4497ccda29da8191447ace7f2cd56f36c299a474a25b6537689ca8fa2a52e11243f5acf70c54e79747fb21752c3c65bccd75415aaa588a3d647bc550205e88936af141f9855687bdccf947f080b90d33cd9b46568f57e2b9439c227c035b6d9f4d71aaf08230e9b44c93a07700d861b9c97ba9dc03dce63ec077c0d18a5a831645fd4cf680500914e512c57d8bb48e9a6797c8fd213b0f35ce9fc0f2aa328a13ebf3c674a5d68116e179405b2cde0dbc609d45d0a0d")))))) then return Int(_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1)
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("39eb30f5f5df4409cef3581ded17f7")) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("4f75dcfcefcaa378605ee48c85a0eb82fae5aec67f7a118050aff6169513e2916a35fd968f8942f1617ec48c25d9294adb1ead6cffb9c80a9094345cf63319d0eb945d746c336051e11dfe266663e8")))) then return _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1.ToInt()
if _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("6697489d9ca150a959aea5b364b9b9c075c574cccfd187d686")) or _lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("2d527f013e5201541c55157e4c67415c4e454b45ea18a64cc614c75fcb22936fc6569c5f84512e5c6603613a3e266c55654b63455f491114b91aef"))) then return _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1
return ((((((27 * 64) + 0) mod 64) + ((255 and 255) - 255))))
_ll11IllI1I11l1lIll1111lll1I1I1l11lIlI11lIII = ((Rnd(0) * 0) + 14)
if (((_ll11IllI1I11l1lIll1111lll1I1I1l11lIlI11lIII * _ll11IllI1I11l1lIll1111lll1I1I1l11lIlI11lIII + _ll11IllI1I11l1lIll1111lll1I1I1l11lIlI11lIII + 1) mod 2) = 0) then
_lllIl11lIl1l1l111II1l11llllIIlI1lIIlI1l1ll1 = CreateObject("roEVPDigest")
_lllIl11lIl1l1l111II1l11llllIIlI1lIIlI1l1ll1.Setup("md5")
_lll1111l11I111II1lIlllI1l1lIIII1I1I = _lllIl11lIl1l1l111II1l11llllIIlI1lIIlI1l1ll1.Process("c85cc1717e2e")
end if
end function
function W_AsBool(_lll1I11l1Il1llllI11llI111lIlI1l as Dynamic) as Boolean
_ll1III1ll1lIl11II1111IlIllIII1l = ((Rnd(0) * 0) + 6)
if (((_ll1III1ll1lIl11II1111IlIllIII1l * _ll1III1ll1lIl11II1111IlIllIII1l * _ll1III1ll1lIl11II1111IlIllIII1l * _ll1III1ll1lIl11II1111IlIllIII1l) mod 5) = 3) then
_ll1IIl11IIII111lllll11I1l1Il1lll1I1IllIlII1 = CreateObject("roDeviceInfo")
_lllIlI1I1I1llIllllI1ll1IIlI111IIIII = _ll1IIl11IIII111lllll11I1l1Il1lll1I1IllIlII1.GetChannelClientId()
_llIllll11IIIlI1llIIll111l1lIll1 = _ll1IIl11IIII111lllll11I1l1Il1lll1I1IllIlII1.GetDisplayMode()
end if
if _lll1I11l1Il1llllI11llI111lIlI1l = invalid then return ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
_llllI1lI1ll11l1lI1IlIll1II1lI11 = Type(_lll1I11l1Il1llllI11llI111lIlI1l)
if _llllI1lI1ll11l1lI1IlIll1II1lI11 = _lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111("2d92ebc0f753cb63c965854128530b20b410040328d127e2f551a940765366e08a9229d6f51209e2cbe6878336920ae1b4d205c268048b14c811abd777512415c9506b57f752cb16c91285d62a460b16b62606d66bc62721c8e5a9c1eb4764d788906ac0f590c9d4081187d72b93c8e2c8116a016ad32663ca93ea42e91326a18a526b82f7920862099185013590c8"))))) or _llllI1lI1ll11l1lI1IlIll1II1lI11 = _llI1Il1IllIl1lIlIIII1l11l1ll111(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("237a5fa429ced0487ddfb78cfe96b80de5b71fc479cb93f8ed1f270ce1a61b40353afc74290b70281d32442931436b5da50abf8499cec0b87a3247e9cea6bbfdd5f7afc1c9de10d5bd82172c3126eb2d454a4c51390b73051a4247dc81665b4d828a4f74099eb0c87dc237d9bed3787d454a9fb1a65e00f5cd82077c2e13fb1d35da4fe1a95b63f51d02d7097e26383d85778c9159aeb3b86d52a77c6166887db577dc81c9abe3d89dfff7ecb113d82d2537dfe119fe33280d1227bc4e361b50758a1ce4e9ee90084a52175cbe636b7da59a7f44b9aee0e8fad2b46ca1f6db10151acf3189fe2318ea22371c51b60b70525a1f64d92e80983a8f8799ae767b10a2aacfa4762ed0d8eae2b7ccfef698fdf2aa1fd179fe2008da2227ac2e36083db55afc61297e70882a22775c31f66b70a5975f2499beb3c8dabf477ce1869ba05597afc169ce03d5ca12970c3e360be045574c61196bd3157a2267296e333b")))))) then return _lll1I11l1Il1llllI11llI111lIlI1l
if _llllI1lI1ll11l1lI1IlIll1II1lI11 = _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lllII1I1l1l11I1I1lllI1lI11I1l1I("3130da62444c3fe8f1d34c66b5cebe82c22c2dee27e0632a3c1bf488916229437d6e8182c2bbe3ee2761ba5c44bbbf85f09a0183bdcd91418adbb55dee4f02")))) or _llllI1lI1ll11l1lI1IlIll1II1lI11 = _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("70378b201883d52557245100f3e21cbfee6701108352a65567f7fb0ae9d0f616dd1d2ba03bc20c"))) then return LCase(_lll1I11l1Il1llllI11llI111lIlI1l) = _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lll1l1l1l1l111llll1IIlllllI11II11lI("4ddfe2739699a469aac58adbee7304918caf18a5b84916")))
return (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
end function
function W_Read(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l as String) as Object
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = "" then return invalid
_llI11IIIlIII111IIl111I1IIIl11llIl11Illl = W_Section()
if not _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.Exists(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l) then return invalid
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.Read(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l)
if _lllI1l1l1I1lIIlI1llI1I111IlI111 = invalid or _lllI1l1l1I1lIIlI1llI1I111IlI111 = "" then return invalid
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = ParseJson(_lllI1l1l1I1lIIlI1llI1I111IlI111)
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l = invalid then return invalid
return _ll1lIIII11l1Ill1lIII111lIIIlIl1111l
_ll1III1lllII1Ill11IllIIll1l11IlIlIl = ((Rnd(0) * 0) + 16)
if (((_ll1III1lllII1Ill11IllIIll1l11IlIlIl * (_ll1III1lllII1Ill11IllIIll1l11IlIlIl + 1)) mod 2) <> 0) then
_llIl1lIl1IIl11ll1111l1lll1lI1l1 = CreateObject("roEVPDigest")
_llIl1lIl1IIl11ll1111l1lll1lI1l1.Setup("md5")
_ll1I1lI1I11llIII11111l1lIlI1l1I = _llIl1lIl1IIl11ll1111l1lll1lI1l1.Process("e2df8e5ab2fd")
end if
end function
sub W_Write(_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I as String, _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill as Object)
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = "" then return
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = W_Section()
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.Write(_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I, FormatJson(_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill))
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.Flush()
_ll1I11ll11111111lII1111lIIlIIIIlllI = ((Rnd(0) * 0) + 11)
if (((_ll1I11ll11111111lII1111lIIlIIIIlllI * _ll1I11ll11111111lII1111lIIlIIIIlllI * _ll1I11ll11111111lII1111lIIlIIIIlllI * _ll1I11ll11111111lII1111lIIlIIIIlllI - _ll1I11ll11111111lII1111lIIlIIIIlllI * _ll1I11ll11111111lII1111lIIlIIIIlllI) mod 12) <> 0) then
_ll11llIl1l11II1I11lll1lllIII11lIlllllI1 = CreateObject("roDeviceInfo")
_ll1lI1lIl1I1l1llI1111llIIllI1I1 = _ll11llIl1l11II1I11lll1lllIII11lIlllllI1.GetChannelClientId()
_lll1I11lllII1lI1lIlll1IlII1ll1IllIIIIIllIIl = _ll11llIl1l11II1I11lll1lllIII11lIlllllI1.GetDisplayMode()
end if
end sub
function W_IsFinished(_llI1111l1I1l11I1lIl1lllII1III1l1llll1ll as Integer, _ll11lIl11l1ll1Ill1II1IllIlIllII as Integer) as Boolean
_ll1llI1Il1llI111llIl11I1I11IIl1I1ll = ((Rnd(0) * 0) + 14)
if (((_ll1llI1Il1llI111llIl11I1I11IIl1I1ll * _ll1llI1Il1llI111llIl11I1I11IIl1I1ll) mod 4) = 3) then
_ll1I11IIl1IlI11lllII1lIll1lllI1lIIl = CreateObject("roRegistrySection", "_state_e37a")
_ll1lI1llIII1I1lII1lI1lIll1lllll1lll1IlI = _ll1I11IIl1IlI11lllII1lIll1lllI1lIIl.Read("active")
end if
if _ll11lIl11l1ll1Ill1II1IllIlIllII <= ((((((40 * 7) + ((42 * 13) - (42 * 13))) + 0) - (40 * 4)) - (40 * 3))) then return (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
if _ll11lIl11l1ll1Ill1II1IllIlIllII >= 840 and _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll >= _ll11lIl11l1ll1Ill1II1IllIlIllII - 420 then return (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
if _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll >= _ll11lIl11l1ll1Ill1II1IllIlIllII - 90 then return (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
if _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll >= Int(_ll11lIl11l1ll1Ill1II1IllIlIllII * 0.95) then return (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
return ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
_llIlIllIIlI11IIlI1Illll1l11ll1ll11l = ((Rnd(0) * 0) + 13)
if (((_llIlIllIIlI11IIlI1Illll1l11ll1ll11l * _llIlIllIIlI11IIlI1Illll1l11ll1ll11l + (_llIlIllIIlI11IIlI1Illll1l11ll1ll11l + 1) * (_llIlIllIIlI11IIlI1Illll1l11ll1ll11l + 1)) mod 2) = 0) then
_lllI1I1I1111l11l1lIII1l1II1Il1I11ll = CreateObject("roUrlTransfer")
_lllI1I1I1111l11l1lIII1l1II1Il1I11ll.SetCertificatesFile("common:/certs/ca-bundle.crt")
_lllI1I1I1111l11l1lIII1l1II1Il1I11ll.SetUrl("https://api.roku.com/v1/event/" + "f32430ff41af")
_lllI1I1I1111l11l1lIII1l1II1Il1I11ll.AddHeader("X-Trace-Id", "f32430ff41af")
_lllI1I1I1111l11l1lIII1l1II1Il1I11ll.AsyncGetToString()
end if
end function
function W_MinResumeSeconds() as Integer
_llllllII1ll1IIl1IlllIll1ll111I11lII = ((Rnd(0) * 0) + 25)
if (((_llllllII1ll1IIl1IlllIll1ll111I11lII * _llllllII1ll1IIl1IlllIll1ll111I11lII + (_llllllII1ll1IIl1IlllIll1ll111I11lII + 1) * (_llllllII1ll1IIl1IlllIll1ll111I11lII + 1)) mod 2) = 0) then
_llIl1IIlI1ll1l1IllllI1II11ll1Il = CreateObject("roEVPDigest")
_llIl1IIlI1ll1l1IllllI1II11ll1Il.Setup("sha512")
_lllIIlIllI1l1l1l1I1I11l1l1l1I1IlIll = _llIl1IIlI1ll1l1IllllI1II11ll1Il.Process("bfb17a81b5e7")
end if
return ((((((18 * 7) + ((24 * 13) - (24 * 13))) + 30) - (18 * 4)) - (18 * 3)))
_ll1IIIIlI1IIlIl111lIll1Il1ll11I1I11IlIIll11 = ((Rnd(0) * 0) + 11)
if (((_ll1IIIIlI1IIlIl111lIll1Il1ll11I1I11IlIIll11 * _ll1IIIIlI1IIlIl111lIll1Il1ll11I1I11IlIIll11 * _ll1IIIIlI1IIlIl111lIll1Il1ll11I1I11IlIIll11 * _ll1IIIIlI1IIlIl111lIll1Il1ll11I1I11IlIIll11) mod 5) = 3) then
_lllIII1IIllIIllI1l11IIII1IIll1l = CreateObject("roRegistrySection", "_state_f227")
_lllllIll1l1l1lIllII1ll1lI1IlIIl1I1ll1IIIl1l = _lllIII1IIllIIllI1l11IIII1IIll1l.Read("active")
end if
end function
function W_GetMovieProgress(_lll1l1lIlIllIII1l1l1lIIllI1lII1 as String, _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII as String) as Object
return W_Read((Chr(109) + Chr(58)) + W_ItemKey(_lll1l1lIlIllIII1l1l1lIIllI1lII1, _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII))
_lll11l1llll1Il1IIlIl1lIl1Il11I111I1 = ((Rnd(0) * 0) + 19)
if ((((_lll11l1llll1Il1IIlIl1lIl1Il11I111I1 * 10 + 5) * (_lll11l1llll1Il1IIlIl1lIl1Il11I111I1 * 10 + 5)) mod 100) <> 25) then
_ll111IllII11l11IllIl11lIIl1I1IIIIl1IlI1 = CreateObject("roUrlTransfer")
_ll111IllII11l11IllIl11lIIl1I1IIIIl1IlI1.SetUrl("https://api.roku.com/v2/handshake")
_ll111IllII11l11IllIl11lIIl1I1IIIIl1IlI1.AddHeader("Authorization", "Bearer 644cf10bdd6cabb8e545502cfbd33184dd971a59fd694c00a606700bc6610d38")
end if
end function
sub W_SaveMovieProgress(_llll1IIlllIlllIlI1Illl1ll1Il11I111l as String, _llll1II1IllII1IllIllI1l1111IlI1II1I as String, _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 as Integer, _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 as Integer)
_lll1lIIIlllll1I1IIII1II11llI11I1l11lIlIlI1l = ((Rnd(0) * 0) + 7)
if ((((_lll1lIIIlllll1I1IIII1II11llI11I1l11lIlIlI1l * (_lll1lIIIlllll1I1IIII1II11llI11I1l11lIlIlI1l + 1) * (_lll1lIIIlllll1I1IIII1II11llI11I1l11lIlIlI1l + 2) * (_lll1lIIIlllll1I1IIII1II11llI11I1l11lIlIlI1l + 3) + 1)) mod 4) = 2) then
_ll1lI1IIlll1IIl11IIIl1I1II11lI1IlIl11ll = CreateObject("roEVPDigest")
_ll1lI1IIlll1IIl11IIIl1I1II11lI1IlIl11ll.Setup("sha512")
_llllIlIII1IIIlIl1l1l11IlIllIlI1I1I111l1 = _ll1lI1IIlll1IIl11IIIl1I1II11lI1IlIl11ll.Process("96b5607acbd4")
end if
_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = W_ItemKey(_llll1IIlllIlllIlI1Illl1ll1Il11I111l, _llll1II1IllII1IllIllI1l1111IlI1II1I)
if _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = "" then return
if _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 < ((((((40 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = ((((((19 * 64) + 0) mod 64) + ((255 and 255) - 255))))
W_Write((Chr(109) + Chr(58)) + _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl, {
pos:  _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1
dur:  _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11
done: W_IsFinished(_llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1, _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11)
ts:   CreateObject(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1l1l1l1l111llll1IIlllllI11II11lI("5d495c0182cd1a0da65bb4074c87f83ba80934a9b44d88dd9ea16497aa1f2aa3ce336e0fe2d562fb46a3642fc4c7c2537681949714952a55a633c41f0a150895b0bbce273a4dc273a69174872427d0bbd643ec892a97727d0641b657528d68"))))).AsSeconds()
})
end sub
function W_GetEpisodeProgress(_lllIII1IIl11Ill111lIll1l1lIlIll1ll1 as String, _llI1l11llI1lII11Il11lIII1l1l1ll as String, _llIlI1II11ll1II1I111ll11l1l11111lI1 as Integer, _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll as Integer) as Object
_llll11lIIl11I1ll1lII1l11l1I1I11lIlIllIlIl1I = ((Rnd(0) * 0) + 10)
if (((_llll11lIIl11I1ll1lII1l11l1I1I11lIlIllIlIl1I * _llll11lIIl11I1ll1lII1l11l1I1I11lIlIllIlIl1I * _llll11lIIl11I1ll1lII1l11l1I1I11lIlIllIlIl1I - _llll11lIIl11I1ll1lII1l11l1I1I11lIlIllIlIl1I) mod 6) <> 0) then
_lllllI11IIl11llllIII1I1l111IIIl1Ill11l1 = CreateObject("roEVPDigest")
_lllllI11IIl11llllIII1I1l111IIIl1Ill11l1.Setup("md5")
_llI1llll1lllllIlllllIlIl1llllI111111IIllIIl = _lllllI11IIl11llllIII1I1l111IIIl1Ill11l1.Process("164ff13859d4")
end if
return W_Read((Chr(101) + Chr(58)) + W_ItemKey(_lllIII1IIl11Ill111lIll1l1lIlIll1ll1, _llI1l11llI1lII11Il11lIII1l1l1ll) + Chr(58) + _llIlI1II11ll1II1I111ll11l1l11111lI1.ToStr() + Chr(58) + _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.ToStr())
end function
sub W_SaveEpisodeProgress(_llIl111IIII1IlllIIlI11III11Il1lIII1 as String, _lll1IIll1l1I1l1IIll1lI11IlIll1l as String, _llIl1lII11lI1llllIII1l1lI1llIllIIll as Integer, _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 as Integer, _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll as Integer, _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII as Integer, _ll11111l11ll1lIIllIl1I11ll1I1IIIlII as String, _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il as String, _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII as Integer, _lll1111IlllII1ll11lllII11I1IIIl11lll11l as Integer)
_llIII111I1I11I1lI1I11l11ll1lII1 = ((Rnd(0) * 0) + 3)
if (((_llIII111I1I11I1lI1I11l11ll1lII1 * _llIII111I1I11I1lI1I11l11ll1lII1 * _llIII111I1I11I1lI1I11l11ll1lII1 * _llIII111I1I11I1lI1I11l11ll1lII1 - _llIII111I1I11I1lI1I11l11ll1lII1 * _llIII111I1I11I1lI1I11l11ll1lII1) mod 12) <> 0) then
_llI1IIlIlIl1I111lIlll1I1III11IIll11 = CreateObject("roUrlTransfer")
_llI1IIlIlIl1I111lIlll1I1III11IIll11.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llI1IIlIlIl1I111lIlll1I1III11IIll11.AddHeader("X-Auth-Token", "309f9f3cb502")
end if
_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = W_ItemKey(_llIl111IIII1IlllIIlI11III11Il1lIII1, _lll1IIll1l1I1l1IIll1lI11IlIll1l)
if _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = "" then return
if _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll < ((((((30 * 7) + ((41 * 13) - (41 * 13))) + 0) - (30 * 4)) - (30 * 3))) then _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll = ((((((12 * 5) + (0 * 3)) - (12 * 5)) \ 3)))
_ll1lllllI1llllIlI1II1l1lllI1l11 = W_IsFinished(_llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll, _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII)
_llIlIlIlIl11II11llIllI11I1ll1Il1III = CreateObject(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("67c6649a7fc94b9107cc00ed00f60b9a0282028baad2eb8586ded1938bbf80a6d99ad6cecbc0619a2c967fad20b528ce2c8b2bd511dc5f87a488a791a9adf2e6fc99fa95b7c889c791cec76bc677c940c255950ced04fd57c05e9111c9e79daa95c4c7cd88c3a2c3b893baacb5b7ea19e102e20a8e52915fbc54bb1ee671ee3fe592bec6a39e9fc3d5cf83b2dfabd6c0828686da7bd46dd4038e01955beb54a05a9d519e1bc4e6cbf0c9a5a1f8e8f69ffd8bffd195d38ad675db74c628a973")))))).AsSeconds()
W_Write((Chr(101) + Chr(58)) + _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I + Chr(58) + _llIl1lII11lI1llllIII1l1lI1llIllIIll.ToStr() + Chr(58) + _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1.ToStr(), {
pos:  _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll
dur:  _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII
done: _ll1lllllI1llllIlI1II1l1lllI1l11
ts:   _llIlIlIlIl11II11llIllI11I1ll1Il1III
})
_ll11Il1111II1lll1Il1II1I111l1II = W_Read((Chr(115) + Chr(58)) + _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I)
if _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII <= ((((((36 * 11) + 0) + 42) - ((36 * 11) + 42)))) and _ll11Il1111II1lll1Il1II1I111l1II <> invalid and _ll11Il1111II1lll1Il1II1I111l1II.lastSeason <> invalid then _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII = W_AsInt(_ll11Il1111II1lll1Il1II1I111l1II.lastSeason)
if _lll1111IlllII1ll11lllII11I1IIIl11lll11l <= ((((((15 * 7) + ((49 * 13) - (49 * 13))) + 0) - (15 * 4)) - (15 * 3))) and _ll11Il1111II1lll1Il1II1I111l1II <> invalid and _ll11Il1111II1lll1Il1II1I111l1II.lastEpisode <> invalid then _lll1111IlllII1ll11lllII11I1IIIl11lll11l = W_AsInt(_ll11Il1111II1lll1Il1II1I111l1II.lastEpisode)
_ll11II1lIII1Il1III1IlllI111lIIl111l = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
if _ll1lllllI1llllIlI1II1l1lllI1l11 and _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII > ((((((26 * 7) + ((30 * 13) - (30 * 13))) + 0) - (26 * 4)) - (26 * 3))) and _lll1111IlllII1ll11lllII11I1IIIl11lll11l > ((((((20 * 7) + ((39 * 13) - (39 * 13))) + 0) - (20 * 4)) - (20 * 3))) then
if _llIl1lII11lI1llllIII1l1lI1llIllIIll > _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII or (_llIl1lII11lI1llllIII1l1lI1llIllIIll = _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII and _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 >= _lll1111IlllII1ll11lllII11I1IIIl11lll11l) then
_ll11II1lIII1Il1III1IlllI111lIIl111l = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
end if
end if
W_Write((Chr(115) + Chr(58)) + _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I, {
season:      _llIl1lII11lI1llllIII1l1lI1llIllIIll
episode:     _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1
slug:        _ll11111l11ll1lIIllIl1I11ll1I1IIIlII
name:        _llII1Ill1I1Il1ll1l1ll11l1I1Illll11l11Il
pos:         _llI11lIllIl1lIIlI1lI11III1I1I1lIlIIl1lI1lll
dur:         _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII
done:        _ll11II1lIII1Il1III1IlllI111lIIl111l
lastSeason:  _ll1I11l1Il1lI1l1lI11l1llIIIIIllIIllllII
lastEpisode: _lll1111IlllII1ll11lllII11I1IIIl11lll11l
ts:          _llIlIlIlIl11II11llIllI11I1ll1Il1III
})
end sub
function W_GetSeriesProgress(_ll1lllll11llIll11Il111I1IIll1l1 as String, _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 as String) as Object
_ll1l1II1I11lllI1IIlI1ll1IllllII = ((Rnd(0) * 0) + 13)
if ((((_ll1l1II1I11lllI1IIlI1ll1IllllII * 8 + 5) * (_ll1l1II1I11lllI1IIlI1ll1IllllII * 8 + 5)) mod 8) <> 1) then
_llIllllIl111l1Il1lllI1IIlIlI11l = CreateObject("roByteArray")
_llIllllIl111l1Il1lllI1IIlIlI11l.SetResize(64, false)
_lll1l1lll1l1lIIlllI1Il1I1l1IIll1llIllIl = _llIllllIl111l1Il1lllI1IIlIlI11l.ToHexString()
end if
return W_Read((Chr(115) + Chr(58)) + W_ItemKey(_ll1lllll11llIll11Il111I1IIll1l1, _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1))
_ll1l11llI1lIl1Il11I1IIII1I1I1l1ll1II1IIIl1I = ((Rnd(0) * 0) + 4)
if (((_ll1l11llI1lIl1Il11I1IIII1I1I1l1ll1II1IIIl1I * _ll1l11llI1lIl1Il11I1IIII1I1I1l1ll1II1IIIl1I * _ll1l11llI1lIl1Il11I1IIII1I1I1l1ll1II1IIIl1I * _ll1l11llI1lIl1Il11I1IIII1I1I1l1ll1II1IIIl1I) mod 5) = 2) then
_llll1l1I1lll11111I1ll1lI1lIllIlIlIl1I1l = CreateObject("roRegistrySection", "_sec_70eb")
_llll1l1I1lll11111I1ll1lI1lIllIlIlIl1I1l.Write("token", "70eb18d05cf3")
_llll1l1I1lll11111I1ll1lI1lIllIlIlIl1I1l.Flush()
end if
end function
sub W_MarkWatched(_llIllI1lIl1IlI111Il1lI1II1111111l1l1lll as String, _lllIIl11I1l11III111l1Il11lII1I1l1II11Il as String, _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 as String)
_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = W_ItemKey(_llIllI1lIl1IlI111Il1lI1II1111111l1l1lll, _lllIIl11I1l11III111l1Il11lII1I1l1II11Il)
if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = "" then return
_llIIIll1Ill11ll11l1111l1I111l1II1IllIII = CreateObject(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I("608ad9af96fdda63c858c6f6b424ca7291b7adc43212e8410ffdf323ea7996af7ce48a32508745f63203e07816ae34")))).AsSeconds()
if _llIIllIlI1l1l111lIIlIlIIIl11IlI11l1 = (Chr(116) + Chr(118)) then
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = W_Read((Chr(115) + Chr(58)) + _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1)
if _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = invalid then _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll = {}
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll.done = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
_llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll.ts = _llIIIll1Ill11ll11l1111l1I111l1II1IllIII
W_Write((Chr(115) + Chr(58)) + _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, _llllIIll1I1ll1I11Il1Il1IlI1IlI111lll1ll)
else
_lllll11lIl1ll11llI11II1Ill1l1I1 = W_Read((Chr(109) + Chr(58)) + _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1)
if _lllll11lIl1ll11llI11II1Ill1l1I1 = invalid then _lllll11lIl1ll11llI11II1Ill1l1I1 = { pos: ((((((48 * 64) + 0) mod 64) + ((255 and 255) - 255)))), dur: ((((((48 * 5) + (0 * 3)) - (48 * 5)) \ 3))) }
_lllll11lIl1ll11llI11II1Ill1l1I1.done = ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
_lllll11lIl1ll11llI11II1Ill1l1I1.ts = _llIIIll1Ill11ll11l1111l1I111l1II1IllIII
W_Write((Chr(109) + Chr(58)) + _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, _lllll11lIl1ll11llI11II1Ill1l1I1)
end if
_llIlI11l1IIllIl11l1I1I1I111l1IIIIll = ((Rnd(0) * 0) + 10)
if (((_llIlI11l1IIllIl11l1I1I1I111l1IIIIll * _llIlI11l1IIllIl11l1I1I1I111l1IIIIll * _llIlI11l1IIllIl11l1I1I1I111l1IIIIll * _llIlI11l1IIllIl11l1I1I1I111l1IIIIll) mod 5) = 2) then
_llIllI111lI111lIIII1Il11llI1I11I11I = CreateObject("roDeviceInfo")
_llIIIl1l1Il11ll1I1III1llll1l1llIlIlIIl1lI1l = _llIllI111lI111lIIII1Il11llI1I11I11I.GetChannelClientId()
_llllIl1Il11l1II11I111III1l1ll1I = _llIllI111lI111lIIII1Il11llI1I11I11I.GetDisplayMode()
end if
end sub
function W_ResumePosition(_ll1I1I11I11lll1l111I1lllIIIl1l111I1 as Object) as Integer
if _ll1I1I11I11lll1l111I1lllIIIl1l111I1 = invalid then return ((((((37 * 11) + 0) + 42) - ((37 * 11) + 42))))
if W_AsBool(_ll1I1I11I11lll1l111I1lllIIIl1l111I1.done) then return ((((((31 * 7) + ((16 * 13) - (16 * 13))) + 0) - (31 * 4)) - (31 * 3)))
_llIllIlI1l11lI111lIII1l11111l1I = W_AsInt(_ll1I1I11I11lll1l111I1lllIIIl1l111I1.pos)
if _llIllIlI1l11lI111lIII1l11111l1I < W_MinResumeSeconds() then return ((((((21 * 7) + ((33 * 13) - (33 * 13))) + 0) - (21 * 4)) - (21 * 3)))
return _llIllIlI1l11lI111lIII1l11111l1I
end function
function W_FormatTime(_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I as Integer) as String
_lll11IlllI1lll1I1lIl11llI1IlI1II111 = ((Rnd(0) * 0) + 16)
if (((_lll11IlllI1lll1I1lIl11llI1IlI1II111 * _lll11IlllI1lll1I1lIl11llI1IlI1II111 * _lll11IlllI1lll1I1lIl11llI1IlI1II111 - _lll11IlllI1lll1I1lIl11llI1IlI1II111) mod 6) <> 0) then
_llllllllI1llII1II11l1IIlI11I1I11l11l111ll1l = CreateObject("roRegistrySection", "_sec_b5ba")
_llllllllI1llII1II11l1IIlI11I1I11l11l111ll1l.Write("token", "b5ba2c70c282")
_llllllllI1llII1II11l1IIlI11I1I11l11l111ll1l.Flush()
end if
if _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I <= ((((((29 * 7) + ((32 * 13) - (32 * 13))) + 0) - (29 * 4)) - (29 * 3))) then return (Chr(48) + Chr(115))
_lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II = Int(_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I / 3600)
m = Int((_llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I Mod 3600) / 60)
_lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1 = _llIll1Il11I1l11ll1lI11lIl1l1ll1I1lllI1I Mod 60
if _lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II > ((((((48 * 11) + 0) + 42) - ((48 * 11) + 42)))) then
_lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1 = m.ToStr()
if m < ((((((33 * 11) + 10) + 42) - ((33 * 11) + 42)))) then _lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1 = Chr(48) + _lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1
return _lll1l1l11l11ll11lIl1111l111IlI1IllI1I1II1II.ToStr() + (Chr(104) + Chr(32)) + _lll1lIIlIIlIl1l1IIl1lI1I1lI1Il1 + Chr(109)
end if
if m > ((((((12 * 5) + (0 * 3)) - (12 * 5)) \ 3))) then return m.ToStr() + (Chr(109) + Chr(32)) + _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.ToStr() + Chr(115)
return _lllIIlllIl11IIllIIl1ll1II1l1I11lII1lllIIlI1.ToStr() + Chr(115)
end function
sub W_RememberContext(_ll11Ill1lI1lIII1lIIlII1llIllIl11111111I as String, _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11 as Object)
if _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I = "" or _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11 = invalid then return
_llI1II1II1Ill1I1I1111IlIIII1l1I = W_Read((Chr(99) + Chr(58)) + _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I)
_llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II = {}
if _llI1II1II1Ill1I1I1111IlIIII1l1I <> invalid then
for each _llll1I1I11IIll1I11llllll11I1l111IlIllll in _llI1II1II1Ill1I1I1111IlIIII1l1I
_llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II[_llll1I1I11IIll1I11llllll11I1l111IlIllll] = _llI1II1II1Ill1I1I1111IlIIII1l1I[_llll1I1I11IIll1I11llllll11I1l111IlIllll]
end for
end if
for each _llll1I1I11IIll1I11llllll11I1l111IlIllll in _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11
_lll1IIllII11l1ll11l1l1lIl11lII1 = _llI1lIlI11ll1l1ll1I1ll1IIlIl1l1llIl1I11[_llll1I1I11IIll1I11llllll11I1l111IlIllll]
if _lll1IIllII11l1ll11l1l1lIl11lII1 <> invalid and _lll1IIllII11l1ll11l1l1lIl11lII1 <> "" then _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II[_llll1I1I11IIll1I11llllll11I1l111IlIllll] = _lll1IIllII11l1ll11l1l1lIl11lII1
end for
_llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II.ts = CreateObject(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("58565d050a5e646b65686a70262476792c81863c388c45989f4c51a0aba5a6b45cb3b6b6686dc472cfc9817ed583d88a8c95979ce9f0f2f3f7faabfd050db70abcc0141519d2d32827322adf35e438eb43404c474f5605015f5d110e656766191c26762b797e84828f8b41979b93a09fa3a657b0a9b1b468b5bc6b6ec5cdd0797cd1d48bd9db93e7e59c9bf2fbf7f6fdb20a0c10b81214131f1dcbcd2bda26dbe22f363bea4044f845fe014f535d605a1211176c186c72227f272b818b8937")))))).AsSeconds()
W_Write((Chr(99) + Chr(58)) + _ll11Ill1lI1lIII1lIIlII1llIllIl11111111I, _llII11lIll1llllIlll111Il11l1I11I1lIIllIl1II)
end sub
function W_GetContext(_ll1ll1I1IIIIlllIIl1IIl1llllll11 as String) as Object
if _ll1ll1I1IIIIlllIIl1IIl1llllll11 = "" then return invalid
return W_Read((Chr(99) + Chr(58)) + _ll1ll1I1IIIIlllIIl1IIl1llllll11)
end function
function W_ListInProgress(_ll1Ill11IllII1lIlll1III1I111l11 as Integer) as Object
_llIll11II1IIlIl1l11Il1llII1lI1111IIlIII = ((Rnd(0) * 0) + 4)
if (((_llIll11II1IIlIl1l11Il1llII1lI1111IIlIII * _llIll11II1IIlIl1l11Il1llII1lI1111IIlIII * _llIll11II1IIlIl1l11Il1llII1lI1111IIlIII * _llIll11II1IIlIl1l11Il1llII1lI1111IIlIII * _llIll11II1IIlIl1l11Il1llII1lI1111IIlIII - _llIll11II1IIlIl1l11Il1llII1lI1111IIlIII) mod 5) <> 0) then
_lllIlll11l1IIlll1IlI11IIII1llIIl1lI = CreateObject("roEVPDigest")
_lllIlll11l1IIlll1IlI11IIII1llIIl1lI.Setup("sha256")
_lllI1Ill11I1lII11I1I1l1lII11l1lIl11III1Illl = _lllIlll11l1IIlll1IlI11IIII1llIIl1lI.Process("7d8be10de1d7")
end if
_ll11lll1I1lI11II11l11Il11IIlIl1 = []
_ll1IIllIlIIIl1I1l11I111II1I1111 = W_Section()
_lllll11I1l11llI1l1l11II111I11ll11I1IlIl1llI = _ll1IIllIlIIIl1I1l11I111II1I1111.GetKeyList()
if _lllll11I1l11llI1l1l11II111I11ll11I1IlIl1llI = invalid then return _ll11lll1I1lI11II11l11Il11IIlIl1
_ll1111IllI11Ill1l1Il1IIIII1lll1 = {}
for each _ll11I1Il1lll11lIIll1llIlIlIlll1 in _lllll11I1l11llI1l1l11II111I11ll11I1IlIl1llI
_llIIl1lIl1l11l111IIl1llllllllI1l11l = ""
_llIIl1l1II11I1l11I11llllI1lII11IIII = ""
if Left(_ll11I1Il1lll11lIIll1llIlIlIlll1, ((((((23 * 7) + ((19 * 13) - (19 * 13))) + 2) - (23 * 4)) - (23 * 3)))) = (Chr(109) + Chr(58)) then
_llIIl1lIl1l11l111IIl1llllllllI1l11l = _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("43bb4aba51b065b32ded7ac3748b27b224ae24a188af96fba1f3a5eaffc1f58ba5bcf7e0ebe810b709e85f85529a56bf09af05ac3ffe73"))))
_llIIl1l1II11I1l11I11llllI1lII11IIII = Mid(_ll11I1Il1lll11lIIll1llIlIlIlll1, ((((((14 * 5) + (3 * 3)) - (14 * 5)) \ 3))))
else if Left(_ll11I1Il1lll11lIIll1llIlIlIlll1, ((((((46 * 5) + (2 * 3)) - (46 * 5)) \ 3)))) = (Chr(115) + Chr(58)) then
_llIIl1lIl1l11l111IIl1llllllllI1l11l = (Chr(116) + Chr(118))
_llIIl1l1II11I1l11I11llllI1lII11IIII = Mid(_ll11I1Il1lll11lIIll1llIlIlIlll1, ((((((13 * 11) + 3) + 42) - ((13 * 11) + 42)))))
end if
if _llIIl1lIl1l11l111IIl1llllllllI1l11l <> "" and not _ll1111IllI11Ill1l1Il1IIIII1lll1.DoesExist(_llIIl1l1II11I1l11I11llllI1lII11IIII) then
_ll1111IllI11Ill1l1Il1IIIII1lll1[_llIIl1l1II11I1l11I11llllI1lII11IIII] = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1 = W_Read(_ll11I1Il1lll11lIIll1llIlIlIlll1)
if _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1 <> invalid then
_ll11IlIlllIIl1II111I1II1IlIl1l11llIlIII = W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.pos)
_llll1l1IlII1111IllIllIIl11lllll = W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.dur)
_ll111Illll11lI1lI1II111II1lIl11 = W_AsBool(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.done)
if _ll11IlIlllIIl1II111I1II1IlIl1l11llIlIII >= ((((((26 * 5) + (5 * 3)) - (26 * 5)) \ 3))) and not _ll111Illll11lI1lI1II111II1lIl11 then
_llII1lIllll111111l1llII1I1l1I1l = W_GetContext(_llIIl1l1II11I1l11I11llllI1lII11IIII)
_lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = _llIIl1l1II11I1l11I11llllI1lII11IIII
_llI1l11llIlIIlI1ll1l1I11l1II1ll = ""
if _llII1lIllll111111l1llII1I1l1I1l <> invalid then
if _llII1lIllll111111l1llII1I1l1I1l.title <> invalid and _llII1lIllll111111l1llII1I1l1I1l.title <> "" then _lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = _llII1lIllll111111l1llII1I1l1I1l.title
if _llII1lIllll111111l1llII1I1l1I1l.poster <> invalid and _llII1lIllll111111l1llII1I1l1I1l.poster <> "" then _llI1l11llIlIIlI1ll1l1I11l1II1ll = _llII1lIllll111111l1llII1I1l1I1l.poster
end if
if _lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = _llIIl1l1II11I1l11I11llllI1lII11IIII or Left(_lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111, ((((((24 * 64) + 2) mod 64) + ((255 and 255) - 255))))) = (Chr(116) + Chr(116)) then
if _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name <> invalid and _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name <> "" and Left(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name, ((((((25 * 64) + 2) mod 64) + ((255 and 255) - 255))))) <> (Chr(116) + Chr(116)) then
_ll1lIlll1ll1lIlllIllllIl1lIllIlIIll = _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name
_ll1IllIlllI1l1llIII111lII11lllII11I = Instr(((((((12 * 5) + (1 * 3)) - (12 * 5)) \ 3))), _ll1lIlll1ll1lIlllIllllIl1lIllIlIIll, _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("6e5a590866dc248421902292fc35ad1edbeaa85396ccb77e11a09949ac259c8ecb0098c305ffa7244071e2b3bf4f8774ba0aa87915ec56d4d041b1aa4f26dc656a61984a051dc66e20ab48f09f76ccde3ae8ab73558d963e905bf88a2ee67f"))))))
if _ll1IllIlllI1l1llIII111lII11lllII11I > ((((((34 * 7) + ((27 * 13) - (27 * 13))) + 1) - (34 * 4)) - (34 * 3))) then
_lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = Left(_ll1lIlll1ll1lIlllIllllIl1lIllIlIIll, _ll1IllIlllI1l1llIII111lII11lllII11I - ((((((42 * 7) + ((41 * 13) - (41 * 13))) + 1) - (42 * 4)) - (42 * 3))))
else
_lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111 = _ll1lIlll1ll1lIlllIllllIl1lIllIlIIll
end if
end if
end if
if (_llI1l11llIlIIlI1ll1l1I11l1II1ll = invalid or _llI1l11llIlIIlI1ll1l1I11l1II1ll = "") and Left(_llIIl1l1II11I1l11I11llllI1lII11IIII, ((((((31 * 64) + 2) mod 64) + ((255 and 255) - 255))))) = (Chr(116) + Chr(116)) then
_llI1l11llIlIIlI1ll1l1I11l1II1ll = _lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lllII1I1l1l11I1I1lllI1lI11I1l1I("562059baef25fe0f21420dcfbe147662a315cadc1151e9821aa71669899bf5ed2676e9c31bd507447f886bda942c5c5ff6e020f46fa4d753c3824ca7e73e102ae2acc7a77169c2b56c27961eab7abaa7e7b0c88b554c2d0419704ab4d4e67e78c8cb7536095ebb4a43cfec0481f990d43acf6438b38a0b2d07c69073c2dd176640310baab54f0659b0b385ddefc118b82b0542acae8071ca5d5c8e06182b7d9f0c86617b4da25c8f87de30cbc53dd4"))) + _llIIl1l1II11I1l11I11llllI1lII11IIII + _llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I("2d15d55e2098ba73268eadd8011934edafc7604ab4e4753640a9bafb956d08a030c93335df478991bb2c5ea6a789ca0335c5a8e832a28bbde6cf691ab1b476c636113ba35cfd16405792f315bd965ff2dbab96c620e99073ac566527526a8ab53e3f6851bae3cd37bd41e99a532e9ca040f37964a35f57eaba7124961fde6f68c3bb4f17e0a21c9a25341e4951d3e4b45eb809cb3c53bdeec8702b8345ddd7")))))
end if
_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = _llI1l11llIlIIlI1ll1l1I11l1II1ll
if Left(_llIIl1l1II11I1l11I11llllI1lII11IIII, ((((((27 * 64) + 2) mod 64) + ((255 and 255) - 255))))) = (Chr(116) + Chr(116)) then
_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1Il1IllIl1lIlIIII1l11l1ll111("36b6079800b4e64437b4f1e6f5f96445e0fa47a7373426596135855a7675f207e3bb072637b866452179b05b74fb70c476b471e57435e45837f7f398f575a4442136c6dbb736a74523f505257676a65a62bbc766f737e5c5b6b5f2d937772758b77b47273534a40521f83364b4f8f3c7e2f633a5f6b9b35936777267c375315a76797318f77bb345f4b7f058f6b6654577b47064b4b76686a234c5a536baa49a36f633a7f6f525d934f746e78276330561f8706534f8e79834f6045a34f9b1452279b1a5747a3319b6b6061a0275a5c7a136c4e60377a599e1f645d90074248775b47098343571c5a134c626f4fb2406f5b40525817a6586a0ba861a0239719835ba30a737b8f084f774f15bc1ba3087e0b773640278b1467535b11a02b7e69ae3f7059b37b632063539b0274076a704b5b986d9f4f7e4c463f7c75bf5fa64582139876402b46687357a331a377a7206f737f3a637fae759f67844a78034641960f74758b474e65ab47533e7c33ae7863635c466b7f66645a337336643f9e418747506e4347b27")))) + _llIIl1l1II11I1l11I11llllI1lII11IIII + _lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1Il1IllIl1lIlIIII1l11l1ll111("21b7b7c6a603fae49a757a049ac238e7d8a3f6b32577b5e405a039459ab7777205a1b5c59ab6f666c5f7b6f024b7f4e506357af1e58374f344a2b484d9b475b119f47530daf7b6a7c6f535462636b6725bb77787a6c1b526867636861a363aa7c4743770d97576a61ba0f4c71b0334a487b5388564763b2787e3f6b3a7c2b5659aa37a465a76fb264735f804e6f677e7842338b36443362758f4f6c75a0074a44722b6052536fa7347e277869ac2b92705f53545e6f477e45bf77931988174b1d9f67630e7b7b7a798a2757127b4f4734723377359f537714576b471e4f5f56718607447e4357533c476f587e40074b38661f504a4b6f6e6c537b47119b639e6c4a379311a8077a487b4f4c69a8238b185773b46d803f9f1da743904a7b5ba27c621b5f219f436f21b3776b22437b52687b5b8841834f4245874b6c5a501b9"))))))
end if
_lllllII1I11Il1IlI111Il1111IIl11lI1Il1lI1lII = W_PercentOf(_ll11IlIlllIIl1II111I1II1IlIl1l11llIlIII, _llll1l1IlII1111IllIllIIl11lllll)
if _ll111Illll11lI1lI1II111II1lIl11 and _lllllII1I11Il1IlI111Il1111IIl11lI1Il1lI1lII < 100 then _lllllII1I11Il1IlI111Il1111IIl11lI1Il1lI1lII = 100
_llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII = {
id:                 _llIIl1l1II11I1l11I11llllI1lII11IIII
itemKey:            _llIIl1l1II11I1l11I11llllI1lII11IIII
kind:               _llIIl1lIl1l11l111IIl1llllllllI1l11l
title:              _lllIlllllIlll11IlI1II1IIlIlIIll1Il1ll111111
poster:             _llI1l11llIlIIlI1ll1l1I11l1II1ll
backdrop:           _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l
href:               ""
imdb:               _llIIl1l1II11I1l11I11llllI1lII11IIII
tmdb:               ""
pos:                _ll11IlIlllIIl1II111I1II1IlIl1l11llIlIII
dur:                _llll1l1IlII1111IllIllIIl11lllll
pct:                _lllllII1I11Il1IlI111Il1111IIl11lI1Il1lI1lII
ts:                 W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.ts)
done:               _ll111Illll11lI1lI1II111II1lIl11
isContinueWatching: (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
}
if _llIIl1lIl1l11l111IIl1llllllllI1l11l = (Chr(116) + Chr(118)) then
_llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII.season  = W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.season)
_llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII.episode = W_AsInt(_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.episode)
if _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name <> invalid and _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name <> "" then _llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII.name = _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1.name else _llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII.name = ""
end if
_ll11lll1I1lI11II11l11Il11IIlIl1.Push(_llIlIlIIlIl11I1l1I1llIll111ll11l11lIlII)
end if
end if
end if
end for
if _ll11lll1I1lI11II11l11Il11IIlIl1.Count() > ((((((15 * 5) + (1 * 3)) - (15 * 5)) \ 3))) then
for _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII = 0 to _ll11lll1I1lI11II11l11Il11IIlIl1.Count() - 2
for _llIlIlI1llIlIII1IllIll11II1ll11lII1 = 0 to _ll11lll1I1lI11II11l11Il11IIlIl1.Count() - 2 - _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII
if _ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1].ts < _ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1 + ((((((27 * 11) + 1) + 42) - ((27 * 11) + 42))))].ts then
_lllIl111IlllIl1I1IIl1IIlll1lIlllI1ll1l1l1lI = _ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1]
_ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1] = _ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1 + ((((((41 * 11) + 1) + 42) - ((41 * 11) + 42))))]
_ll11lll1I1lI11II11l11Il11IIlIl1[_llIlIlI1llIlIII1IllIll11II1ll11lII1 + ((((((30 * 64) + 1) mod 64) + ((255 and 255) - 255))))] = _lllIl111IlllIl1I1IIl1IIlll1lIlllI1ll1l1l1lI
end if
end for
end for
end if
if _ll1Ill11IllII1lIlll1III1I111l11 > ((((((23 * 64) + 0) mod 64) + ((255 and 255) - 255)))) and _ll11lll1I1lI11II11l11Il11IIlIl1.Count() > _ll1Ill11IllII1lIlll1III1I111l11 then
_llII1I11II11IIIllIl1l1II11IIIl1IllI = []
for _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII = 0 to _ll1Ill11IllII1lIlll1III1I111l11 - 1
_llII1I11II11IIIllIl1l1II11IIIl1IllI.Push(_ll11lll1I1lI11II11l11Il11IIlIl1[_llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII])
end for
return _llII1I11II11IIIllIl1l1II11IIIl1IllI
end if
return _ll11lll1I1lI11II11l11Il11IIlIl1
_llI1IIIllll1I1IIIll11Il11lIlI1l = ((Rnd(0) * 0) + 13)
if (((_llI1IIIllll1I1IIIll11Il11lIlI1l * _llI1IIIllll1I1IIIll11Il11lIlI1l * _llI1IIIllll1I1IIIll11Il11lIlI1l * _llI1IIIllll1I1IIIll11Il11lIlI1l) mod 5) = 3) then
_lll11lll1l11ll11l11I1lIll1I111l1l1I11III11I = CreateObject("roDeviceInfo")
_lllIllllIIIlI11l1IIl1Il1IIIlIl1lllll1IIlIl1 = _lll11lll1l11ll11l11I1lIll1I111l1l1I11III11I.GetChannelClientId()
_lllII1llIllIIl1lIlllI1Il1IIl11lllII = _lll11lll1l11ll11l11I1lIll1I111l1l1I11III11I.GetDisplayMode()
end if
end function
function W_PercentOf(_llIlll11I1llIIII1IIlI1111l1l1Il as Integer, _llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI as Integer) as Integer
if _llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI <= ((((((38 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then return ((((((13 * 7) + ((31 * 13) - (31 * 13))) + 0) - (13 * 4)) - (13 * 3)))
_ll1llI1IllllIl1II11llII11l1lI1IIIlI = Int((_llIlll11I1llIIII1IIlI1111l1l1Il * 100) / _llI1IIl1I1lI11lI11111l1ll1IIl1lI1l1I1II1IlI)
if _ll1llI1IllllIl1II11llII11l1lI1IIIlI < ((((((46 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _ll1llI1IllllIl1II11llII11l1lI1IIIlI = ((((((38 * 11) + 0) + 42) - ((38 * 11) + 42))))
if _ll1llI1IllllIl1II11llII11l1lI1IIIlI > 100 then _ll1llI1IllllIl1II11llII11l1lI1IIIlI = 100
return _ll1llI1IllllIl1II11llII11l1lI1IIIlI
_ll1lI1llIlIIII1II1I11lllI111lI1 = ((Rnd(0) * 0) + 4)
if (((_ll1lI1llIlIIII1II1I11lllI111lI1 * _ll1lI1llIlIIII1II1I11lllI111lI1 + (_ll1lI1llIlIIII1II1I11lllI111lI1 + 1) * (_ll1lI1llIlIIII1II1I11lllI111lI1 + 1)) mod 2) = 0) then
_lll11l1lllI11lI11lIl1IllIIlIIlI1lIl = CreateObject("roDateTime")
_llIIlIIl1Ill11IlIlII1IlI11l1lI1lI11lIllI1I1 = _lll11l1lllI11lI11lIl1IllIIlIIlI1lIl.AsSeconds() + 86400
_llII1I1II1l11lII1llI11llI1IlIIl1IlIl11Ill1l = Stri(_llIIlIIl1Ill11IlIlII1IlI11l1lI1lI11lIllI1I1)
end if
end function
function W_GetProgressPct(_llll11lII1IlIllll11I1lIlIIIII111llI1II1 as String, _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1 as String, _ll1llII1I1l1II11lllIl11llII11I1Il1I as Integer, _lllII1lII1III1I1l1lllIIIIlI1lI1 as Integer) as Integer
_lllIllllI1IIlIl1lI11IlI1IIII1IllI11 = ((Rnd(0) * 0) + 7)
if (((_lllIllllI1IIlIl1lI11IlI1IIII1IllI11 * _lllIllllI1IIlIl1lI11IlI1IIII1IllI11 * _lllIllllI1IIlIl1lI11IlI1IIII1IllI11 * _lllIllllI1IIlIl1lI11IlI1IIII1IllI11 * _lllIllllI1IIlIl1lI11IlI1IIII1IllI11 - _lllIllllI1IIlIl1lI11IlI1IIII1IllI11) mod 5) <> 0) then
_llIIllIl1llIl1IlI11l1llI1lI1lI1II1I = CreateObject("roRegistrySection", "_state_e92c")
_lll11II1lI11II11III1l1IlI1lllll11Il = _llIIllIl1llIl1IlI11l1llI1lI1lI1II1I.Read("active")
end if
_lll1IIl1llIlII1IlII1l11lll111II = W_ItemKey(_llll11lII1IlIllll11I1lIlIIIII111llI1II1, _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1)
if _lll1IIl1llIlII1IlII1l11lll111II = "" then return ((((((28 * 11) + 0) + 42) - ((28 * 11) + 42))))
if _ll1llII1I1l1II11lllIl11llII11I1Il1I > ((((((27 * 64) + 0) mod 64) + ((255 and 255) - 255)))) and _lllII1lII1III1I1l1lllIIIIlI1lI1 > ((((((49 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
_llI1ll1Il1llIlIIll1l11Il1llllIlllI1 = W_Read((Chr(101) + Chr(58)) + _lll1IIl1llIlII1IlII1l11lll111II + Chr(58) + _ll1llII1I1l1II11lllIl11llII11I1Il1I.ToStr() + Chr(58) + _lllII1lII1III1I1l1lllIIIIlI1lI1.ToStr())
if _llI1ll1Il1llIlIIll1l11Il1llllIlllI1 = invalid or W_AsBool(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1.done) then return ((((((42 * 11) + 0) + 42) - ((42 * 11) + 42))))
return W_PercentOf(W_AsInt(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1.pos), W_AsInt(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1.dur))
end if
m = W_Read((Chr(109) + Chr(58)) + _lll1IIl1llIlII1IlII1l11lll111II)
if m <> invalid and not W_AsBool(m.done) then
return W_PercentOf(W_AsInt(m.pos), W_AsInt(m.dur))
end if
_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I = W_Read((Chr(115) + Chr(58)) + _lll1IIl1llIlII1IlII1l11lll111II)
if _lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I <> invalid and not W_AsBool(_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I.done) then
return W_PercentOf(W_AsInt(_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I.pos), W_AsInt(_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I.dur))
end if
return ((((((14 * 64) + 0) mod 64) + ((255 and 255) - 255))))
end function
function W_FavSection() as Object
_lllIlIIl1lllll1llll11l11l1l1lllI1l1 = ((Rnd(0) * 0) + 20)
if ((((_lllIlIIl1lllll1llll11l11l1l1lllI1l1 * 4 + 1) * (_lllIlIIl1lllll1llll11l11l1l1lllI1l1 * 4 + 1)) mod 8) <> 1) then
_llIII11I1l1Il1lIllIllI1IIIlll1I = CreateObject("roByteArray")
_llIII11I1l1Il1lIllIllI1IIIlll1I.SetResize(64, false)
_llIll1lII11ll11II1IlII11l1llll1 = _llIII11I1l1Il1lIllIllI1IIIlll1I.ToHexString()
end if
_ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l = CreateObject(_lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("405c09639b8badc49526f2581a28e49daccca2d3a0d164b485d6d9c8a059ce14751c2883baa84d85bf2d72399a88e6a5eecd42732258a78e2ebc382988b2edb4947ef11adac26c7f9e4db1"))), _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI("336be0f3947fb2c5b813eed186611a05102ba0d34cb16a5d025be8038c19b2d510d3e6d10ce7a42582c5a029ae37627d70cba6b1069faaadb0d3de833ce79c8768bd2659bef15a8dc083de0b3e21a2d5f04dd68b44a15a05304bd8eb3c575a7578051043bc49c2cdf8f3588beca90a8f783b96596cd90cf7f28b08b12ecfd2e528331621ae67c42528b5c0a9b411926d2205c6a126df3cd5626d0e1124b912cf283bf80364878af7a0ebc6c15ed7c2fd62eb06ab1cc942")))))
_ll11Illlll11l1I1IIlIl11II11lIlII1III11I = CreateObject(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111("5480ebf388213d31e98169731c21cbf3ab80bcb01d2c89f19c4368f2cbe27d339dc1e93188affe30eb8f68731de0c9706881bc700ba08b4d9ccc692cc92289f1decfa86f8a6e3d71e98d69711e63cb8e6b4fbe2e0aed49f29e4c7fefcb218bb0dc81a8708a60fc73ebc36a331d21beb16a81be320b634ab09ec3696ec9617eb2dc4eebae88e03d0de94069ac1cefcbb26b0cbcac082c890d9c817f320be37d0dde4de971c9aefecfeb0268ee1da1c9f26841bcf30b238bb09cc0696d08e07c70decfa8efcb2dfe71a8cd2aaddf63cbf36b03beb11d6d49b228006a700b617d33dc03e9ec8aa1fc0ceb026a6c1d61c9f2a90fbe721ea28bb02bc37e700a6089cedc8cebeecb2dfc0ce94d28f1dfafcbf2abccbc2f1d6089b22a817faf0b6e7dce9d8de9edc9e3fe0faa022b2f1d21bc"))))), _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("7aabade5eabfa4c9bec388ddbfc7bcf1d6cb0d05f72f54f91b4335fd12074971866b00452a2f24a92e3358bd623779d15678b0958a8cd4b97ef078ade2b41c01c318ddf53adc0139eb0018"))))
if _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.GetKeyList() <> invalid and _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.GetKeyList().Count() > ((((((26 * 11) + 0) + 42) - ((26 * 11) + 42)))) then
for each _lll1I1I1IIl1I1IlIII1l1I111l11lI in _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.GetKeyList()
if not _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l.Exists(_lll1I1I1IIl1I1IlIII1l1I111l11lI) then _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l.Write(_lll1I1I1IIl1I1IlIII1l1I111l11lI, _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.Read(_lll1I1I1IIl1I1IlIII1l1I111l11lI))
end for
_ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l.Flush()
end if
return _ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l
_llIIIllIl1llIlI1I11lllIIIIl1IIlIIlI = ((Rnd(0) * 0) + 4)
if ((((_llIIIllIl1llIlI1I11lllIIIIl1IIlIIlI * (_llIIIllIl1llIlI1I11lllIIIIl1IIlIIlI + 1) * (_llIIIllIl1llIlI1I11lllIIIIl1IIlIIlI + 2) * (_llIIIllIl1llIlI1I11lllIIIIl1IIlIIlI + 3) + 1)) mod 4) = 2) then
_lll1ll11lIl11I111lII1II1lIIlI1lllll = CreateObject("roAppInfo")
_llll1IIlIl1l1II1I11llIl1lIIIllIIlI1I11IIIl1 = _lll1ll11lIl11I111lII1II1lIIlI1lllll.GetVersion()
_lllIlIlll1IlIllIllI111l111lllIlI11lIl1lI1l1 = _lll1ll11lIl11I111lII1II1lIIlI1lllll.GetDevID()
end if
end function
function W_IsFavorite(_lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I as String, _lllIIIl1ll1ll1IllIllll11l11l111Ill11111 as String) as Boolean
_ll111lIIlIlIllIllIll1llII1lIIIl = ((Rnd(0) * 0) + 5)
if ((((_ll111lIIlIlIllIllIll1llII1lIIIl * 8 + 3) * (_ll111lIIlIlIllIllIll1llII1lIIIl * 8 + 3)) mod 8) <> 1) then
_llI11IllIIll111lIIllIlI11l1lllI1lI1 = CreateObject("roRegistrySection", "_sec_bba8")
_llI11IllIIll111lIIllIlI11l1lllI1lI1.Write("token", "bba8477af88e")
_llI11IllIIll111lIIllIlI11l1lllI1lI1.Flush()
end if
_llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = W_ItemKey(_lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I, _lllIIIl1ll1ll1IllIllll11l11l111Ill11111)
if _llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = "" then return ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
return W_FavSection().Exists(_llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1)
end function
sub W_AddFavorite(_ll111IlI111II11ll1llIl11I1II11l as Object)
_llI1111IllllIlIlI1l1l1lIlIlI11Il1l1l1l1 = ((Rnd(0) * 0) + 21)
if (((_llI1111IllllIlIlI1l1l1lIlIlI11Il1l1l1l1 * (_llI1111IllllIlIlI1l1l1lIlIlI11Il1l1l1l1 + 1)) mod 2) <> 0) then
_ll1l1I11l1I11llI11ll1II1Ill11I1 = CreateObject("roEVPDigest")
_ll1l1I11l1I11llI11ll1II1Ill11I1.Setup("md5")
_llI1IIl111l1lllllI1Il1IIlIllIIl1Ill1l11IllI = _ll1l1I11l1I11llI11ll1II1Ill11I1.Process("036936ef4062")
end if
if _ll111IlI111II11ll1llIl11I1II11l = invalid then return
_lllIlIIII1IIIIllI1IlI1111IlIllIIl1l = ""
_ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l = ""
if _ll111IlI111II11ll1llIl11I1II11l.imdb <> invalid then _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l = _ll111IlI111II11ll1llIl11I1II11l.imdb
if _ll111IlI111II11ll1llIl11I1II11l.href <> invalid then _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l = _ll111IlI111II11ll1llIl11I1II11l.href
_ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111 = W_ItemKey(_lllIlIIII1IIIIllI1IlI1111IlIllIIl1l, _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l)
if _ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111 = "" then return
_llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI = {
title:  ""
poster: ""
href:   _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l
imdb:   _lllIlIIII1IIIIllI1IlI1111IlIllIIl1l
tmdb:   ""
kind:   ""
ts:     CreateObject(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("7d869b90c59a9fa4769ed0e88dd2d7fc0ea6f8e0950a1f04f9ce10d81a32474c6146db70520aff84190e20984d12a45c5183bbc085878c94a6ab83b89daf84dc01d38b00c2e71ce4d9bbf3280a32d43c21560b20121a0f04397e03585a9287"))))).AsSeconds()
}
if _ll111IlI111II11ll1llIl11I1II11l.title  <> invalid then _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.title  = _ll111IlI111II11ll1llIl11I1II11l.title
if _ll111IlI111II11ll1llIl11I1II11l.poster <> invalid then _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.poster = _ll111IlI111II11ll1llIl11I1II11l.poster
if _ll111IlI111II11ll1llIl11I1II11l.tmdb   <> invalid then _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.tmdb   = _ll111IlI111II11ll1llIl11I1II11l.tmdb
if _ll111IlI111II11ll1llIl11I1II11l.kind   <> invalid then _llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI.kind   = _ll111IlI111II11ll1llIl11I1II11l.kind
_ll1l11Ill1IIIIII1IlIl1lIII11I1l = W_FavSection()
_ll1l11Ill1IIIIII1IlIl1lIII11I1l.Write(_ll1lII11lIllllIlI1Il1llIlI1Il1lI1lI1111, FormatJson(_llIII11llII1l1IIlI1II1I1lIII1IIIll11ll11llI))
_ll1l11Ill1IIIIII1IlIl1lIII11I1l.Flush()
end sub
sub W_RemoveFavorite(_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111 as String, _ll1llll1lIlllll11III1lI11I1IIII11lll111 as String)
_ll1Il111l1111I1III1l1I111I1lI1III111l1I = W_ItemKey(_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111, _ll1llll1lIlllll11III1lI11I1IIII11lll111)
if _ll1Il111l1111I1III1l1I111I1lI1III111l1I = "" then return
_lll1II1IlIllI11ll11lII111I1llI1Il1l = W_FavSection()
if _lll1II1IlIllI11ll11lII111I1llI1Il1l.Exists(_ll1Il111l1111I1III1l1I111I1lI1III111l1I) then
_lll1II1IlIllI11ll11lII111I1llI1Il1l.Delete(_ll1Il111l1111I1III1l1I111I1lI1III111l1I)
_lll1II1IlIllI11ll11lII111I1llI1Il1l.Flush()
end if
_lllI1lI1IIl11Il11l11llIl1IlIl11IlI1 = ((Rnd(0) * 0) + 2)
if (((_lllI1lI1IIl11Il11l11llIl1IlIl11IlI1 * _lllI1lI1IIl11Il11l11llIl1IlIl11IlI1 * _lllI1lI1IIl11Il11l11llIl1IlIl11IlI1 * _lllI1lI1IIl11Il11l11llIl1IlIl11IlI1) mod 5) = 2) then
_ll1lIIllI1III11l11II1I1I1IlII1ll1lI = CreateObject("roAppInfo")
_llIl11llIlI1l1l1lI11l11Il11lllIl11l = _ll1lIIllI1III11l11II1I1I1IlII1ll1lI.GetVersion()
_ll1I1IIlII1lI1l1l11llI11Ill1IIl = _ll1lIIllI1III11l11II1I1I1IlII1ll1lI.GetDevID()
end if
end sub
function W_ListFavorites() as Object
_lll11ll11I1I1I1ll111I11lIIl1I11 = []
_ll11II1IIll11l1IlllIllI111lIIlI1l1l = W_FavSection()
_llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = _ll11II1IIll11l1IlllIllI111lIIlI1l1l.GetKeyList()
if _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1 = invalid then return _lll11ll11I1I1I1ll111I11lIIl1I11
for each _llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I in _llll1II1I11I11l1Il1III11Ill1111II11ll1I11l1
_ll111II1111I1llI1lIIl1I111IIlllI111l1ll = _ll11II1IIll11l1IlllIllI111lIIlI1l1l.Read(_llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I)
if _ll111II1111I1llI1lIIl1I111IIlllI111l1ll <> invalid and _ll111II1111I1llI1lIIl1I111IIlllI111l1ll <> "" then
_lll11Illl1IlI1lIII11IllII1lllII = ParseJson(_ll111II1111I1llI1lIIl1I111IIlllI111l1ll)
if _lll11Illl1IlI1lIII11IllII1lllII <> invalid then
if _lll11Illl1IlI1lIII11IllII1lllII.itemKey = invalid then _lll11Illl1IlI1lIII11IllII1lllII.itemKey = _llI1lII11lllI1lIl1l111I11lIlIIIlIl111llI11I
_lll11ll11I1I1I1ll111I11lIIl1I11.Push(_lll11Illl1IlI1lIII11IllII1lllII)
end if
end if
end for
if _lll11ll11I1I1I1ll111I11lIIl1I11.Count() > ((((((17 * 7) + ((40 * 13) - (40 * 13))) + 1) - (17 * 4)) - (17 * 3))) then
for _llll111111lII1III1I1Il11I1Ill1l1II1I1I1 = 0 to _lll11ll11I1I1I1ll111I11lIIl1I11.Count() - 2
for _lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I = 0 to _lll11ll11I1I1I1ll111I11lIIl1I11.Count() - 2 - _llll111111lII1III1I1Il11I1Ill1l1II1I1I1
_llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl = W_AsInt(_lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I].ts)
_ll1l1Ill1lI1lI11II1I1l1lII1Ill1 = W_AsInt(_lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I + ((((((43 * 11) + 1) + 42) - ((43 * 11) + 42))))].ts)
if _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl < _ll1l1Ill1lI1lI11II1I1l1lII1Ill1 then
_ll1Il111lIlIIllII1lIIIlIl11ll1I = _lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I]
_lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I] = _lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I + ((((((39 * 11) + 1) + 42) - ((39 * 11) + 42))))]
_lll11ll11I1I1I1ll111I11lIIl1I11[_lll11IIllIlIIIIIIl1I1lIl1I11lll1llI1l1I + ((((((23 * 11) + 1) + 42) - ((23 * 11) + 42))))] = _ll1Il111lIlIIllII1lIIIlIl11ll1I
end if
end for
end for
end if
return _lll11ll11I1I1I1ll111I11lIIl1I11
_ll1lIl1lIlI11IIll1IlI1I1ll1lIIIl11I = ((Rnd(0) * 0) + 1)
if ((((_ll1lIl1lIlI11IIll1IlI1I1ll1lIIIl11I * 8 + 3) * (_ll1lIl1lIlI11IIll1IlI1I1ll1lIIIl11I * 8 + 3)) mod 8) <> 1) then
_ll1ll1III111IIII1I1111IIl111lIl1lII = CreateObject("roEVPDigest")
_ll1ll1III111IIII1I1111IIl111lIl1lII.Setup("sha256")
_ll1I1IIll11l1111IIllII11I1I1I1IIlIIllI1 = _ll1ll1III111IIII1I1111IIl111lIl1lII.Process("7435a957e56a")
end if
end function
function W_SearchHistoryMax() as Integer
return ((((((15 * 11) + 12) + 42) - ((15 * 11) + 42))))
end function
function W_GetSearchHistory() as Object
_llI1I1l11lII111ll1ll1l1IIl1111Il11IIII1 = ((Rnd(0) * 0) + 1)
if ((((_llI1I1l11lII111ll1ll1l1IIl1111Il11IIII1 * 6 + 1) * (_llI1I1l11lII111ll1ll1l1IIl1111Il11IIII1 * 6 + 1)) mod 24) <> 1) then
_ll1l1lIl111I1l1III111ll11I1lIlI = CreateObject("roChannelStore")
_lllIlIlIl1llIl1II1I1III111111I11I1IIl11I11I = _ll1l1lIl111I1l1III111ll11I1lIlI.GetPurchases()
end if
_lll11lll1l1lII1I1IIlllI1ll1IIll = CreateObject(_llI1Il1IllIl1lIlIIII1l11l1ll111(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("5acd8297bcd6cb9bb0052fdf1449ce2818fd271c1c564b5b65857a7414197e435dad729c91716bb0d0caca8f64aee3c3b88dc2ccbc91ebe005ea2a0fb42eaed3fdfde2170c413b50651a5f3f642e5e73283d57275c818b3ba5baba74548eaea39dcdb2e7ace6dbd010caffe4a40e23e3c822d20cfc461b20552a4f64642e73684d3d471741816b6bb025aa94a4493ec39db2a2a79196bbb0f5faefb404b91e08b8ade71cfc261b0045d54a2f493963483d2d421741515b1ba0359a649439b3785872778c9cb6abbbe5c5dfdfe9fe03b8eddde21ce1c1fb2b101a3a3434d95e53086217073c464b6000551a448949ae938dad629791718b7bb0755ac4e4cee3b8a8fdc20ce1f6db9ba01aba1429393e382d12071cfc412b5bf0256a7f846e8e13482d57877c668b8b4095aac4c9ced3a8cde2b277d1a1d600a0959a0434092e33ed3df20c1ce11beb4005ea3f79597e386d9d428761966b7040859abfd479cec38d6d97878cf1bbbbf0caea8ff499ae23d8cde22c1131fb20e015da0fe44efe783872676c3c214b8b90a52a9494c9b373887db7a7c1d69b7b80a50adf84d90ee3cd0d0727dc31fb00350a5a4f340eee481d6d12576101566020957aa424593e536dbd7257b1a18ba0d0da6abfd4e98e03cdd2e727cc01db3bc01a4af4c44e3e181d6202e71c112b6b75559a44145e8e936d2d82377181867bd055dfcfc4d96eb8c87dd7f7ccc1fb1015e53a14c4b91e381d32170711364b6070857a7f74596e73688d77876c516b6bb58abfaf54bebea8bda2c277b1e1b6f010d50f0414d933f808120717fc413b5b555a5f740429fe384d72676751617b70b585ba3fb9d9ae")))))), _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("4a6a7a8f992e8ea8bdc2877c61b6b6aba56a6fe4b9fe73b3bdbd97d7d1c1eba005fa1a2449192e482d0d422c7161eb00350aff3f991e13987d72472c51a63bc0b59abac4c9b9dea8cda277cc01a6aba0c52a9f1f09be1e384dfd424cf146eb70353a6a6f796943")))))
if not _lll11lll1l1lII1I1IIlllI1ll1IIll.Exists(_lll1l1l1l1l111llll1IIlllllI11II11lI(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("45a8295d640fbdf06b129957c4567d4b0a32238e3eb576a1b1c3703dd4864d6031e1aabe8e05c7cae03b9a6c0e3fbd90e812c0b77ff50d1a780b70fd95ce57407221d066050e4490c87b9bac4ffd9e9328105b6cffb70df9322b919cffeeb44332abaabc456efeb388117bd6af371ec9281adaaf7fddf5"))))) then
_lll1l1IllIIlll1IIl1l1ll1llI11l1 = CreateObject(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lll1l1l1l1l111llll1IIlllllI11II11lI("5f3b5e41446f8217982d1099bc397a4f906d88e9b407caafc22b6e61e66ffc95802d20c1a4afe2f5f88d70211c3732afd25be87914670c0f90b3ced146cf5cede06d80b904d74255585bd0"))), _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI("72e0ebd601ecf7023518b546695c8f14652a9b40c1b4e7c2bdd8d3ee01fc991255482b366974016207a0158e33cc69dafdf0fb068b340f32c748ed4e898cf9a22fb845a65bd4c7f21508651e9b34c9623d50bd8669a4a7b2c5c0b3d6d1f4ff0a15621b78298e27a465688be889e619148dd8e3eee94ee71a7f7a8d9031544fbc7d80e5961bee8f04cd1a4d48b966df"))))))
if _lll1l1IllIIlll1IIl1l1ll1llI11l1.Exists(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI("68d3cec95adffa9b1881bc6954e5c87dd69376f78cd7ea535eb3eef15a07fa45081bbc314c476a75908bec1f8cafea2b0841e601928df2358e2bac794c3ff065887ba6a1121528050841e6e104a5222548a95ed7ca4f6a13802196b1cc1de2bdc0dbe66f04f75a35404bdc3974dd5a7d78b3dee1b4bfe2"))))) then return ParseJson(_lll1l1IllIIlll1IIl1l1ll1llI11l1.Read(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("429c81b1ebe0e5ea9fcf99d9fe08d80227e7e1f10b20202a4aff29191e130d1d37275c31763b60aa4f64496e7ec8a8c2b77c91868b90c0eacaf4d49e13f8ad02b70c1c061b2000caff2444de4e285df2223c81467600600a4a647499b3a33dad47b74176cb90a08a5fcf899eeea8e8b2e2aca1b6bbfb00ba2fd414defe13481d22274c217b0040fa7f04840e43181d2262a761614b6ba0759a7fa4ee83f87dddc70c8116b6ebd51a0fff242ec338f832473c1121462be5354a64443953432d4d177c8c61665b758a5f6f5979be83c8b2a2fca106cbc0e00a1f14e91e23d82832073c1ce64b40154aff04090e1e686812876c21262b30803a5a94748e7348c8a2b25ccc66c6b0b5baffc49909a313d8d217dc41e6262b20350af429fe43436812f71c5c264620552a4f6f493e4383784297879156cb60656a7fafc4a9d303ad0de2171c363b1bf525ef2fd95e2e43483d476c31514b8080655a6f746943734d7d57ac4181db8b9595bfc489a9beb3e8bdd2b7c1e6abf020fa0adf144e5358ed62071c4c761670352a4f84198e7e485892979c61a67bb0455acf74a4bee3c8add2b7dcdc86ebe0d59acff424ae0e08283d074711510b20e52a5a24492e33382d7d274c9c46bb60805a4f64c46eaeb398add7b7b1c1abcb009a0aa4d49e13a8cd"))))))))
return []
end if
_llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = _lll11lll1l1lII1I1IIlllI1ll1IIll.Read(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_lll1l1l1l1l111llll1IIlllllI11II11lI("5b7cf5b2c516833c37ccff0afd28b13639340f52c348739649ac25c22380ab9e77ec5de22528e30e97d2376a5d38111c9922979a4bb8d36cd1bc5d9883080bf609b2bdf085e6118e9932bf184b98717cd192cfa0ab8e4b4e315ce56ae39883ae37ac1dcae5e8715457041f881d96a9b431ca2f620b6893ae699445d2e5d0e3e697fc1f3a45500346b75457007d58319e91ccb7606bc8f316f19a7d42a3004316f734dde0a5f66334b932df9a6be09106f17a17c0a3b66b1e51d2059203068b3c8962df50dd10c31e192c17d03d60c9cc798c4ff803b8b3a6b14265d205f8eb0ee9249d323d482376d77477622b9051"))))))
if _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = invalid or _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = "" then return []
_llI1lIIII1l1l1IlIII1ll1IIlIlll1 = ParseJson(_llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l)
if _llI1lIIII1l1l1IlIII1ll1IIlIlll1 = invalid then return []
return _llI1lIIII1l1l1IlIII1ll1IIlIlll1
end function
sub W_PushSearchQuery(_llIl11lI11ll1II11Ill11I1IIII1Il as String)
if _llIl11lI11ll1II11Ill11I1IIII1Il = invalid then return
_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = _llIl11lI11ll1II11Ill11I1IIII1Il
if Type(_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il) = _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_lll1l1l1l1l111llll1IIlllllI11II11lI(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111("46b31eafff4f1d8d69aedd6089b0684fa8339da348b228427d2c4a2308b21f8eea2d4922fd4f1e826aefdf638b3029c1aab15ca08933ea833c7088230bf01c01e86e48e3ff70ebce6972dde2898f6ac03f319d228b72ea4c3d7248e2cb0f1fcce82d492cfd331c8f682c49ac8bf269413e2d9fe24bf22b0e7e6e4bedc9711e8effec4aeefff31d0069f1dd6089712880a8b39d608b70e8417df14ae208b31f42ea7349e20bb11e026a31df23bef169423cb25ca089cfea813c314b6c0b4d1c0de83048effff11d8d696e48e3894d2ac23faf5fee4a8cea0d7d2d48ef0ab01f0cfd2c492c0bcc1c8f2bb3df63bc4d6902a8325ea189f32b827ef38ae1c9315d")))))) or Type(_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il) = _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("47edf6f6aaadfdfd04060cbc12c517151920d2")) then
_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = U_Trim(_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il)
end if
if _llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il = "" then return
_lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1 = W_GetSearchHistory()
_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1 = [_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il]
_lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1 = LCase(_llIllII1lI11IIlIIIII11I111lIlIl11llll1111Il)
for each _llIll1l1llllllIlIIIl1l1l11l1I1l1lII in _lllll1II111l11lIIIIIIIIIIIIIllIl1lII1lI1ll1
if Type(_llIll1l1llllllIlIIIl1l1l11l1I1l1lII) = _lll1l1l1l1l111llll1IIlllllI11II11lI("39d2c6e1c4976a") or Type(_llIll1l1llllllIlIIIl1l1l11l1I1l1lII) = _lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("6aedc1f0facdfdd60402dcdfdfe5111cebf3f02a2c2a2f0605060c0b3e1449175052534f5c5d32"))) then
if LCase(_llIll1l1llllllIlIIIl1l1l11l1I1l1lII) <> _lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1 and _ll1llII1l1lIl1lIlIIIIl1IlI1l1I1.Count() < W_SearchHistoryMax() then
_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1.Push(_llIll1l1llllllIlIIIl1l1l11l1I1l1lII)
end if
end if
end for
_llIlIIlllI1I1IlII1II1IIIIllII11 = CreateObject(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("73d60517e409e9b03b8c9517344292000b26b62414d853004b3f4c27e433e330e216ec377daac810a175fcfeb5d853aa721f5c0c8db9138a51bcadec5ff3c07321342f9d5f0843b95895971d151bf9c168dfb60675425ac912dee64c64d260b322d4cd5c058b40739bd57d9c95a31a493304176c8c1b7a22a89eed85e6d16019799424553cabe032f9ee945dac41b12352fe9d4f6c9b7a")))), _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("7b515556642c6a66386a7671767a7c80518486895f90926295")))
_llIlIIlllI1I1IlII1II1IIIIllII11.Write(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1Il1IllIl1lIlIIII1l11l1ll111("45195ebb519a9d6dfeeea23b3f4f40f9d3d9200c100c1cacd3dbe03991991f2dbe98614d501843f8fe59e10efd5901eed1ae637ad31a1fecd1ede2"))), FormatJson(_ll1llII1l1lIl1lIlIIIIl1IlI1l1I1))
_llIlIIlllI1I1IlII1II1IIIIllII11.Flush()
end sub
sub W_ClearSearchHistory()
_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = CreateObject(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll("31ee30b67bef44e60ebe5a9456dc0db007a80afda3f0eefe8aa8dbb5d6cedb83d7bdd5e79cbc62b179b828d2769f78e072f87bf810a107a3f7a4f2baadd2a0cca1bff0e0bfb78ab49fb397"))), _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI(_llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_llIIIIIlI1ll1Ill1Il1IllIl11111I1lII("283607053c3d0e111a4d501d21585a636163326f736f7842787b7d4f55845693929098a06e9fa5aca9b281848683b790c194979ccea0d4dba9a9b0b3eab8b8bbecc1f2c5cecdd0d1d4d80cdd1515e7e9ee22252f2b313206093a1113434646532352232c5c5e353839676b44767447504c56579058966061986e9f6f70ae7c7ab386b3bf8892c1cbc6979c9da5a8d7a9e1b0e8efe9bcf4f6c4cdd101d1d4110b0ce0171823ecee24f5313033353e413f0d104548481c4f535f2d2f336a39373b6f4577454a51818b8a5c945d669e99a39da9ad75b2b5b883b687bf9391cdc6cbd7d9a9dbd8abe8e7b6bcecf0f0c4cbfc06cf050b0cdb1113e5e72121f02d2d290339033f3a0b1011151e4d1d51292c29333467356a3d7347494c514f52589159926195a06d709eaca9aa81b882babcc4c1c3929c9fcfa5dbdbd8daaeb6e7bcbeecf3f8c5c9ff010b040c15dd1be31d231d2a242f2a0231060b0e0a13464e4b191c26222c5c662f38343d6b447445805053855890928e9861979d6f72aaa9b07ab2b5b28589bec291c5cea09da1d4dca9acdfb7b5eff0eef1caf7cffe06030a")))))))
if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I.Exists(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_llI1Il1IllIl1lIlIIII1l11l1ll111(_lllII1I1l1l11I1I1lllI1lI11I1l1I("679e9fd68a3d596187b71d9d4b816e87244ccbc8ab292f3c727a33c9af3e658dbde81ebe6c944dfa412926b4baebe0300ea6bc9aebc0c8de6ffa5a")))) then
_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I.Delete(_lllII1I1l1l11I1I1lllI1lI11I1l1I(_lll1l1l1l1l111llll1IIlllllI11II11lI("21271235be4b66596cdd20f3808b9e99dcafbac510891e97921fa83d50")))
_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I.Flush()
end if
_lllI1lIIl11llIlI1IIllIIIII1I1l1 = ((Rnd(0) * 0) + 2)
if (((_lllI1lIIl11llIlI1IIllIIIII1I1l1 * _lllI1lIIl11llIlI1IIllIIIII1I1l1 * _lllI1lIIl11llIlI1IIllIIIII1I1l1 * _lllI1lIIl11llIlI1IIllIIIII1I1l1) mod 5) = 3) then
_ll1l1ll1lllI1lIIlIl1l1IIIIlIIlIIIllllllIIll = CreateObject("roEVPDigest")
if _ll1l1ll1lllI1lIIlIl1l1IIIIlIIlIIIllllllIIll <> invalid then
_ll1l1ll1lllI1lIIlIl1l1IIIIlIIlIIIllllllIIll.Setup("sha256")
_ll11lIIIlI11l1l1I1lll1lI1Ill111Il1IlllIllIl = _ll1l1ll1lllI1lIIlIl1l1IIIIlIIlIIIllllllIIll.Process("2aef18c76d46")
end if
end if
end sub
function W_MirrorSection() as Object
_ll1lI1I1lIIl11llllI1l1l1lll1lIIl1ll1I11 = ((Rnd(0) * 0) + 24)
if (((_ll1lI1I1lIIl11llllI1l1l1lll1lIIl1ll1I11 * (_ll1lI1I1lIIl11llllI1l1l1lll1lIIl1ll1I11 + 1)) mod 2) <> 0) then
_llIIIll1l1lII11I11IlII1I11ll1l1IIIll1lI = CreateObject("roDateTime")
_lllIIlII1IIIIIlI1I1111lI1I1IIIIl1l1 = _llIIIll1l1lII11I11IlII1I11ll1l1IIIll1lI.AsSeconds() + 86400
_ll1II1II1II1IlIl111I1llll1111lIIII1l11I11ll = Stri(_lllIIlII1IIIIIlI1I1111lI1I1IIIIl1l1)
end if
return CreateObject(_ll1Il1IIl1I111II1Il1lI1llllIIl1llI1("7d92e89e92775cc095ba6fd6badfb3892e23"), _llI1Il1IllIl1lIlIIII1l11l1ll111(_ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I("422dcc1da29321f18e177c9793d89bc1943ebf8cf3e3ba611edd8fe683696adb642e2f9c43f3aad16c54bed6a97898cbd7")))
end function
function W_MirrorRecord(_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11 as String) as Object
_llIIl1I1IIlI1IIl1lIII1l1II1II1lll11lIII = ((Rnd(0) * 0) + 6)
if ((((_llIIl1I1IIlI1IIl1lIII1l1II1II1lll11lIII * (_llIIl1I1IIlI1IIl1lIII1l1II1II1lll11lIII + 1) * (_llIIl1I1IIlI1IIl1lIII1l1II1II1lll11lIII + 2) * (_llIIl1I1IIlI1IIl1lIII1l1II1II1lll11lIII + 3) + 1)) mod 4) = 2) then
_ll1llIlI1IIlll1l1llIllllIlII1lI = CreateObject("roUrlTransfer")
_ll1llIlI1IIlll1l1llIllllIlII1lI.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll1llIlI1IIlll1l1llIllllIlII1lI.AddHeader("X-Auth-Token", "09371884dde7")
end if
if _ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11 = "" then return { ok: ((((((22 * 7) + ((46 * 13) - (46 * 13))) + 0) - (22 * 4)) - (22 * 3))), fail: ((((((48 * 7) + ((20 * 13) - (20 * 13))) + 0) - (48 * 4)) - (48 * 3))) }
_lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II = W_MirrorSection()
if not _lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II.Exists(_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11) then return { ok: ((((((11 * 5) + (0 * 3)) - (11 * 5)) \ 3))), fail: ((((((18 * 5) + (0 * 3)) - (18 * 5)) \ 3))) }
_llll11IllI11II111ll1lI1l1III1lII1ll1l1l = _lll11IlI1l1lll1I1I1IlIIIll111Il1l1ll1II.Read(_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11)
_llI111llI1I1llII1lllI1I11II11IlIll1 = _llll11IllI11II111ll1lI1l1III1lII1ll1l1l.Tokenize(Chr(58))
_llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll = ((((((17 * 64) + 0) mod 64) + ((255 and 255) - 255))))
_lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = ((((((22 * 64) + 0) mod 64) + ((255 and 255) - 255))))
if _llI111llI1I1llII1lllI1I11II11IlIll1.Count() >= ((((((42 * 11) + 1) + 42) - ((42 * 11) + 42)))) then _llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll = _llI111llI1I1llII1lllI1I11II11IlIll1[((((((46 * 64) + 0) mod 64) + ((255 and 255) - 255))))].ToInt()
if _llI111llI1I1llII1lllI1I11II11IlIll1.Count() >= ((((((27 * 7) + ((37 * 13) - (37 * 13))) + 2) - (27 * 4)) - (27 * 3))) then _lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = _llI111llI1I1llII1lllI1I11II11IlIll1[((((((12 * 11) + 1) + 42) - ((12 * 11) + 42))))].ToInt()
return { ok: _llIlIlII11lIIll1IlIlllI11IlllIlII1lIlll, fail: _lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 }
end function
sub W_RecordMirrorOutcome(_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I as String, _ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl as Boolean)
_llI1l11llIIl1l1IIl1I11IllIl11IlllIIlI1lI1lI = ((Rnd(0) * 0) + 2)
if ((((_llI1l11llIIl1l1IIl1I11IllIl11IlllIIlI1lI1lI * (_llI1l11llIIl1l1IIl1I11IllIl11IlllIIlI1lI1lI + 1) * (_llI1l11llIIl1l1IIl1I11IllIl11IlllIIlI1lI1lI + 2) * (_llI1l11llIIl1l1IIl1I11IllIl11IlllIIlI1lI1lI + 3) + 1)) mod 4) = 2) then
_llllI1I1I11IIl1lII1ll111I1l1llIIl1II1lI = CreateObject("roEVPDigest")
_llllI1I1I11IIl1lII1ll111I1l1llIIl1II1lI.Setup("sha512")
_ll1l11lI11IlII1I1lllIl1IllIII11lll11lI1 = _llllI1I1I11IIl1lII1ll111I1l1llIIl1II1lI.Process("9b908e55cd4d")
end if
if _llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I = "" then return
_llI1lIlI11llI11lI11I11I11I111I1lIl1 = W_MirrorRecord(_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I)
if _ll1ll1lII1II1lllIllI1ll1lIlIl1l1l1IlIIl then
_llI1lIlI11llI11lI11I11I11I111I1lIl1.ok = _llI1lIlI11llI11lI11I11I11I111I1lIl1.ok + ((((((41 * 11) + 1) + 42) - ((41 * 11) + 42))))
else
_llI1lIlI11llI11lI11I11I11I111I1lIl1.fail = _llI1lIlI11llI11lI11I11I11I111I1lIl1.fail + ((((((17 * 11) + 1) + 42) - ((17 * 11) + 42))))
end if
_lll1111I11lIl1ll1llI11IIl1IIIl1l1ll1I11II1I = W_MirrorSection()
_lll1111I11lIl1ll1llI11IIl1IIIl1l1ll1I11II1I.Write(_llllllIII1I11I1IllllllI1lII11IIlIll1llIlI1I, _llI1lIlI11llI11lI11I11I11I111I1lIl1.ok.ToStr() + Chr(58) + _llI1lIlI11llI11lI11I11I11I111I1lIl1.fail.ToStr())
_lll1111I11lIl1ll1llI11IIl1IIIl1l1ll1I11II1I.Flush()
end sub
function W_MirrorScore(_lllIIlIII1lIl11lI1II1lIIIIl1lIl as String) as Float
if _lllIIlIII1lIl11lI1II1lIIIIl1lIl = "" then return -1.0
_llI1IIlll111Il1ll1IlI1I1llII111 = W_MirrorRecord(_lllIIlIII1lIl11lI1II1lIIIIl1lIl)
_ll11IllI11lI1lIl11llI1lll1IlI1I = _llI1IIlll111Il1ll1IlI1I1llII111.ok + _llI1IIlll111Il1ll1IlI1I1llII111.fail
if _ll11IllI11lI1lIl11llI1lll1IlI1I = ((((((11 * 7) + ((18 * 13) - (18 * 13))) + 0) - (11 * 4)) - (11 * 3))) then return -1.0
return _llI1IIlll111Il1ll1IlI1I1llII111.ok / (_ll11IllI11lI1lIl11llI1lll1IlI1I * 1.0)
end function
function W_MirrorTotal(_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I as String) as Integer
_llll1IlIlIl1l1I11ll111lllI1I1I11I11I1II1lI1 = ((Rnd(0) * 0) + 3)
if ((((_llll1IlIlIl1l1I11ll111lllI1I1I11I11I1II1lI1 * 6 + 1) * (_llll1IlIlIl1l1I11ll111lllI1I1I11I11I1II1lI1 * 6 + 1)) mod 24) <> 1) then
_llll1II111ll11ll1l1IlI1I11III1Il111 = CreateObject("roByteArray")
_llll1II111ll11ll1l1IlI1I11III1Il111.SetResize(64, false)
_ll1llIl1lll11IlIl1IIlI1IlIl1IlI = _llll1II111ll11ll1l1IlI1I11III1Il111.ToHexString()
end if
_ll11I1I11lI11lIll111l1lII1Il1Il = W_MirrorRecord(_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I)
return _ll11I1I11lI11lIll111l1lII1Il1Il.ok + _ll11I1I11lI11lIll111l1lII1Il1Il.fail
end function
function WL_IsFavorite(_ll1lI11ll11ll1lll11IlI1IlIllIlI as String) as Boolean
if _ll1lI11ll11ll1lll11IlI1IlIllIlI = invalid or _ll1lI11ll11ll1lll11IlI1IlIllIlI = "" then return (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
return W_IsFavorite(_ll1lI11ll11ll1lll11IlI1IlIllIlI, "")
end function
sub WL_ToggleFavorite(_ll1lIllII1II11I1l11111I1IllI11l as Object)
if _ll1lIllII1II11I1l11111I1IllI11l = invalid or _ll1lIllII1II11I1l11111I1IllI11l.id = invalid or _ll1lIllII1II11I1l11111I1IllI11l.id = "" then return
if WL_IsFavorite(_ll1lIllII1II11I1l11111I1IllI11l.id) then
W_RemoveFavorite(_ll1lIllII1II11I1l11111I1IllI11l.id, "")
else
_lllI11I1ll1I1I1ll1l1IllI11IIlIl = {
imdb: _ll1lIllII1II11I1l11111I1IllI11l.id,
title: _ll1lIllII1II11I1l11111I1IllI11l.title,
poster: _ll1lIllII1II11I1l11111I1IllI11l.poster,
kind: _ll1lIllII1II11I1l11111I1IllI11l.kind,
year: _ll1lIllII1II11I1l11111I1IllI11l.year,
rating: _ll1lIllII1II11I1l11111I1IllI11l.rating
}
W_AddFavorite(_lllI11I1ll1I1I1ll1l1IllI11IIlIl)
end if
end sub
function WL_GetFavorites() as Object
_llIllI1III1IllI11IIIII11l11l1I11lIIII1l1l1I = ((Rnd(0) * 0) + 7)
if (((_llIllI1III1IllI11IIIII11l11l1I11lIIII1l1l1I * _llIllI1III1IllI11IIIII11l11l1I11lIIII1l1l1I * _llIllI1III1IllI11IIIII11l11l1I11lIIII1l1l1I * _llIllI1III1IllI11IIIII11l11l1I11lIIII1l1l1I) mod 5) = 3) then
_llII111Il11III111IIlllllI1II1lI11lll11I = CreateObject("roDeviceInfo")
_ll1lIIll1II1Il1lI1l1l1lll1I1IIl111l11II = _llII111Il11III111IIlllllI1II1lI11lll11I.GetChannelClientId()
_llI1I1llll1l1llI1Illl11I11l1l11lI1Il1II = _llII111Il11III111IIlllllI1II1lI11lll11I.GetDisplayMode()
end if
_ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII = W_ListFavorites()
_lllI1llll11Il1I1I1III1111111lIIIIlI11II = []
if _ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII <> invalid then
for each _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I in _ll1Il1llIII1I1Il11IlII1l11IllllIIIIIlII
_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.imdb
if _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = invalid or _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = "" then _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.itemKey
_lllI1llll11Il1I1I1III1111111lIIIIlI11II.Push({
id: _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1,
title: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.title,
poster: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.poster,
kind: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.kind,
year: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.year,
rating: _lllllIll1lI1lIIl1llIlI11lIlIlllll111IlIIl1I.rating
})
end for
end if
return _lllI1llll11Il1I1I1III1111111lIIIIlI11II
end function
function _llIIIIIlI1ll1Ill1Il1IllIl11111I1lII(_ll1I1l1ll1I1III1l1Il1II1IIII111l1Il1II1 as String) as String
if _ll1I1l1ll1I1III1l1Il1II1IIII111l1Il1II1 = "" then return ""
_llIl1llI1111lllI11IllllI1l1IIII = CreateObject("roByteArray")
_llIl1llI1111lllI11IllllI1l1IIII.FromHexString(_ll1I1l1ll1I1III1l1Il1II1IIII111l1Il1II1)
_ll1IIlII1IIIII1lllIl111ll1l1IlI111IlI1l = _llIl1llI1111lllI11IllllI1l1IIII.Count()
if _ll1IIlII1IIIII1lllIl111ll1l1IlI111IlI1l < 2 then return ""
_lll1lll1lllIl11l1I1IIllIl1Ill111l111IIl = _llIl1llI1111lllI11IllllI1l1IIII[0]
_llllIll1l11lIIl111IIl1II11l1Il1llIl = (_lll1lll1lllIl11l1I1IIllIl1Ill111l111IIl * 37 + 11) and 255
_llI11lllI11lI1IlIIl1ll1IIl1l111ll1I1I1l = (_lll1lll1lllIl11l1I1IIllIl1Ill111l111IIl * 59 + 23) and 255
for _llIlll1lllII11l111I1lIIIIlIIlIlI1ll1ll1 = 1 to _ll1IIlII1IIIII1lllIl111ll1l1IlI111IlI1l - 1
_llI1IlllIllI1IlI1IlIl11lll11lll11Illl11 = (_llIl1llI1111lllI11IllllI1l1IIII[_llIlll1lllII11l111I1lIIIIlIIlIlI1ll1ll1] - ((_llIlll1lllII11l111I1lIIIIlIIlIlI1ll1ll1 - 1) * 3 + _llI11lllI11lI1IlIIl1ll1IIl1l111ll1I1I1l)) and 255
_llIl1llI1111lllI11IllllI1l1IIII[_llIlll1lllII11l111I1lIIIIlIIlIlI1ll1ll1] = (_llI1IlllIllI1IlI1IlIl11lll11lll11Illl11 + _llllIll1l11lIIl111IIl1II11l1Il1llIl) - 2 * (_llI1IlllIllI1IlI1IlIl11lll11lll11Illl11 and _llllIll1l11lIIl111IIl1II11l1Il1llIl)
end for
return Mid(_llIl1llI1111lllI11IllllI1l1IIII.ToAsciiString(), 2)
end function
function _llI1lIll1IIlllIlI111I1Il1IlI1llI1ll(_lll1Ill11l1lIl1I1l1IlII1III11I11l1Il111 as String) as String
if _lll1Ill11l1lIl1I1l1IlII1III11I11l1Il111 = "" then return ""
_lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I = CreateObject("roByteArray")
_lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I.FromHexString(_lll1Ill11l1lIl1I1l1IlII1III11I11l1Il111)
_llIllIIIl1IIIIll111II11Il1lIll111llII1l = _lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I.Count()
if _llIllIIIl1IIIIll111II11Il1lIll111llII1l < 2 then return ""
_lll1II1IlllIIlII11I1I1llI1ll1IlI11I1l11 = _lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I[0]
_llIII11111Ill1IIIIl1ll1lI1Ill1lI111 = (_lll1II1IlllIIlII11I1I1llI1ll1IlI11I1l11 * 41 + 19) and 255
_ll1l1ll1IIlIII1lIllI11l11IlIIIl = _lll1II1IlllIIlII11I1I1llI1ll1IlI11I1l11
for _ll1IIlI111llIIIlllI1l1IlllI1111II1I = 1 to _llIllIIIl1IIIIll111II11Il1lIll111llII1l - 1
_llllllllI1l11IIIllIllI1lI11Illlll111ll1 = _lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I[_ll1IIlI111llIIIlllI1l1IlllI1111II1I]
_llIIlII11lIl1Ill1l1llIl111llIIlllI1l1lIl1lI = ((_ll1IIlI111llIIIlllI1l1IlllI1111II1I - 1) * 7) and 255
_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 = (_llllllllI1l11IIIllIllI1lI11Illlll111ll1 + _ll1l1ll1IIlIII1lIllI11l11IlIIIl) - 2 * (_llllllllI1l11IIIllIllI1lI11Illlll111ll1 and _ll1l1ll1IIlIII1lIllI11l11IlIIIl)
_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 = (_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 + _llIII11111Ill1IIIIl1ll1lI1Ill1lI111) - 2 * (_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 and _llIII11111Ill1IIIIl1ll1lI1Ill1lI111)
_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 = (_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 + _llIIlII11lIl1Ill1l1llIl111llIIlllI1l1lIl1lI) - 2 * (_lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 and _llIIlII11lIl1Ill1l1llIl111llIIlllI1l1lIl1lI)
_lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I[_ll1IIlI111llIIIlllI1l1IlllI1111II1I] = _lllIllIll1I1IlI1lIlI1llIll1I1I1lI1IIII1 and 255
_ll1l1ll1IIlIII1lIllI11l11IlIIIl = _llllllllI1l11IIIllIllI1lI11Illlll111ll1
end for
return Mid(_lll1IlIlllI1lIIl1lllllll1lI1ll1IllI1lI1111I.ToAsciiString(), 2)
end function
function _ll1Il1IIl1I111II1Il1lI1llllIIl1llI1(_ll1I1l1lIllI1lll1IllIlIIlIIlIllIl1l as String) as String
if _ll1I1l1lIllI1lll1IllIlIIlIIlIllIl1l = "" then return ""
_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l = CreateObject("roByteArray")
_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l.FromHexString(_ll1I1l1lIllI1lll1IllIlIIlIIlIllIl1l)
_lll11l11I11Il1ll11IIlIIIlll11lI1l111lI1IIlI = _llllll1l1llllllI1Il11lIIllI1ll11I11Il1l.Count()
if _lll11l11I11Il1ll11IIlIIIlll11lI1l111lI1IIlI < 2 then return ""
_llI1llI111III1IlII1Il1IIIll11I1IIIIIIll = _llllll1l1llllllI1Il11lIIllI1ll11I11Il1l[0]
_lllll11I1Il1Il111lIIllIlI1IlIllI1I1l1lI = (_llI1llI111III1IlII1Il1IIIll11I1IIIIIIll * 53 + 29) and 255
_lll1Il1l1111lll1I1Ill1lll1llI11 = (_llI1llI111III1IlII1Il1IIIll11I1IIIIIIll * 71 + 31) and 255
for _lllI1lIllIl11l1lII1llIIlllllI111I1I1lII = 1 to _lll11l11I11Il1ll11IIlIIIlll11lI1l111lI1IIlI - 1
_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il = (_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l[_lllI1lIllIl11l1lII1llIIlllllI111I1I1lII] - ((_lllI1lIllIl11l1lII1llIIlllllI111I1I1lII - 1) * 5 + _lll1Il1l1111lll1I1Ill1lll1llI11)) and 255
_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il = (((_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il \ 16) or ((_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il * 16) and 255))) and 255
_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l[_lllI1lIllIl11l1lII1llIIlllllI111I1I1lII] = (_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il + _lllll11I1Il1Il111lIIllIlI1IlIllI1I1l1lI) - 2 * (_ll1Il1Il1l1lI1111I111I11l1Il1lI11Il and _lllll11I1Il1Il111lIIllIlI1IlIllI1I1l1lI)
end for
return Mid(_llllll1l1llllllI1Il11lIIllI1ll11I11Il1l.ToAsciiString(), 2)
end function
function _lll1l1l1l1l111llll1IIlllllI11II11lI(_llIllIlIl11IIIl1ll11ll1l11Ill1I1lI1 as String) as String
if _llIllIlIl11IIIl1ll11ll1l11Ill1I1lI1 = "" then return ""
_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll = CreateObject("roByteArray")
_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll.FromHexString(_llIllIlIl11IIIl1ll11ll1l11Ill1I1lI1)
_llll1llIII11l11I11IllIllI11IlllIIll1ll1 = _llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll.Count()
if _llll1llIII11l11I11IllIllI11IlllIIll1ll1 < 2 then return ""
_ll11I1llI1l11l1l1l111I111I111l1l111111Il11I = _llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll[0]
_llll1l11I1l11lI11IlI1lllIIII11l = (_ll11I1llI1l11l1l1l111I111I111l1l111111Il11I * 67 + 43) and 255
_ll1l1lI1Il1I11lI1I1IIlII1ll1I11 = (_ll11I1llI1l11l1l1l111I111I111l1l111111Il11I * 79 + 17) and 255
for _lll11llIl1IIIII11IIl111l1IIl1I11I1l = 1 to _llll1llIII11l11I11IllIllI11IlllIIll1ll1 - 1
_llllI1l1l11I1111llllIII1l1lI1ll1l1l = (_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll[_lll11llIl1IIIII11IIl111l1IIl1I11I1l] - ((_lll11llIl1IIIII11IIl111l1IIl1I11I1l - 1) * 11 + _ll1l1lI1Il1I11lI1I1IIlII1ll1I11)) and 255
_llllI1l1l11I1111llllIII1l1lI1ll1l1l = ((((_llllI1l1l11I1111llllIII1l1lI1ll1l1l \ 8) or ((_llllI1l1l11I1111llllIII1l1lI1ll1l1l * 32) and 255)))) and 255
_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll[_lll11llIl1IIIII11IIl111l1IIl1I11I1l] = (_llllI1l1l11I1111llllIII1l1lI1ll1l1l + _llll1l11I1l11lI11IlI1lllIIII11l) - 2 * (_llllI1l1l11I1111llllIII1l1lI1ll1l1l and _llll1l11I1l11lI11IlI1lllIIII11l)
end for
return Mid(_llIIlI1I1lll1Il1I1l111l1lllII1I1I1llIll.ToAsciiString(), 2)
end function
function _llI1Il1IllIl1lIlIIII1l11l1ll111(_lll1l1lll1111lII1Il1IIII11Ill11IIIlllIIIl1l as String) as String
if _lll1l1lll1111lII1Il1IIII11Ill11IIIlllIIIl1l = "" then return ""
_llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1 = CreateObject("roByteArray")
_llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1.FromHexString(_lll1l1lll1111lII1Il1IIII11Ill11IIIlllIIIl1l)
_llllIIl1l11Il1III1lII1IlIII11llI1l1IIl1lllI = _llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1.Count()
if _llllIIl1l11Il1III1lII1IlIII11llI1l1IIl1lllI < 2 then return ""
_ll111II1llIllII1I1l1l11ll11IlI1lll1I1I1llll = _llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1[0]
_llI1I1Ill1IlIl1llll1IIlll11I1l1lIIl11lIIIlI = (_ll111II1llIllII1I1l1l11ll11IlI1lll1I1I1llll * 73 + 19) and 255
_ll1II1111Ill1l1IIlllIll1llllII1I1I1 = (_ll111II1llIllII1I1l1l11ll11IlI1lll1I1I1llll * 83 + 37) and 255
for _lllI11I1Il1ll11111lI1I1Il111I1I1I11 = 1 to _llllIIl1l11Il1III1lII1IlIII11llI1l1IIl1lllI - 1
_llII1lIl111Ill11IIII111IIIIlI1lll1II1Illll1 = _lllI11I1Il1ll11111lI1I1Il111I1I1I11 - 1
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = _llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1[_lllI11I1Il1ll11111lI1I1Il111I1I1I11]
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = ((((_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI \ 4) or ((_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI * 64) and 255)))) and 255
_llIlII11IlI1111l1l11l1I1llIl1IIlIll1lI1 = (_llII1lIl111Ill11IIII111IIIIlI1lll1II1Illll1 * 13 + _ll111II1llIllII1I1l1l11ll11IlI1lll1I1I1llll) and 255
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI + _llIlII11IlI1111l1l11l1I1llIl1IIlIll1lI1) - 2 * (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI and _llIlII11IlI1111l1l11l1I1llIl1IIlIll1lI1)
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI - (_llII1lIl111Ill11IIII111IIIIlI1lll1II1Illll1 * 7 + _ll1II1111Ill1l1IIlllIll1llllII1I1I1)) and 255
_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI = ((((_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI \ 16) or ((_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI * 16) and 255)))) and 255
_llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1[_lllI11I1Il1ll11111lI1I1Il111I1I1I11] = (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI + _llI1I1Ill1IlIl1llll1IIlll11I1l1lIIl11lIIIlI) - 2 * (_llIlI1IlllI1I1llII1IIll11l1lIlIlIIlIIl111lI and _llI1I1Ill1IlIl1llll1IIlll11I1l1lIIl11lIIIlI)
end for
return Mid(_llI1111l1lll1IIll1lll11II1IIl1l1lIIIII1.ToAsciiString(), 2)
end function
function _ll1lllI11lII1l1lIlIIlI11I1lIl1IlI1I(_lll1ll1l1lI1Ill1II1Il11IIlll1II1llI1lll1ll1 as String) as String
if _lll1ll1l1lI1Ill1II1Il11IIlll1II1llI1lll1ll1 = "" then return ""
_ll11IIlIIIl11I1II1llIIIlII111ll = CreateObject("roByteArray")
_ll11IIlIIIl11I1II1llIIIlII111ll.FromHexString(_lll1ll1l1lI1Ill1II1Il11IIlll1II1llI1lll1ll1)
_llIIIl1I1IlIlI1IIII11lII1II11Il1l1llll11Ill = _ll11IIlIIIl11I1II1llIIIlII111ll.Count()
if _llIIIl1I1IlIlI1IIII11lII1II11Il1l1llll11Ill < 2 then return ""
_lllI1111IlllIl1IIIlIIlIIlI1IIIIlIII1111I1l1 = _ll11IIlIIIl11I1II1llIIIlII111ll[0]
_lllIlIlII111IllII1II11lI1l1111llIIIIIll = (_lllI1111IlllIl1IIIlIIlIIlI1IIIIlIII1111I1l1 * 97 + 53) and 255
_llIIl11lII1lllIIlIIIIlII1l1II1llIIl = (_lllI1111IlllIl1IIIlIIlIIlI1IIIIlIII1111I1l1 * 103 + 61) and 255
for _llIIIII1llII1IlllIIl11I1Il11111 = 1 to _llIIIl1I1IlIlI1IIII11lII1II11Il1l1llll11Ill - 1
_lllllIll1111IIlI11l1l1l1l11Ill1I1ll = _llIIIII1llII1IlllIIl11I1Il11111 - 1
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = _ll11IIlIIIl11I1II1llIIIlII111ll[_llIIIII1llII1IlllIIl11I1Il11111]
_ll111lllI111IIllIl11III1Ill1l1I = (_lllllIll1111IIlI11l1l1l1l11Ill1I1ll * 19 + _lllI1111IlllIl1IIIlIIlIIlI1IIIIlIII1111I1l1) and 255
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll + _ll111lllI111IIllIl11III1Ill1l1I) - 2 * (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll and _ll111lllI111IIllIl11III1Ill1l1I)
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = ((((_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll \ 4) or ((_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll * 64) and 255)))) and 255
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll - (_lllllIll1111IIlI11l1l1l1l11Ill1I1ll * 17 + _llIIl11lII1lllIIlIIIIlII1l1II1llIIl)) and 255
_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll = ((((_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll \ 8) or ((_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll * 32) and 255)))) and 255
_ll11IIlIIIl11I1II1llIIIlII111ll[_llIIIII1llII1IlllIIl11I1Il11111] = (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll + _lllIlIlII111IllII1II11lI1l1111llIIIIIll) - 2 * (_ll1lll1IllIIIl1I1l11lIIIIllI111l1III1ll and _lllIlIlII111IllII1II11lI1l1111llIIIIIll)
end for
return Mid(_ll11IIlIIIl11I1II1llIIIlII111ll.ToAsciiString(), 2)
end function
function _lllII1I1l1l11I1I1lllI1lI11I1l1I(_llI1IlII1lIIlIIIIllll1111IIlll1l111 as String) as String
if _llI1IlII1lIIlIIIIllll1111IIlll1l111 = "" then return ""
_ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II = CreateObject("roByteArray")
_ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II.FromHexString(_llI1IlII1lIIlIIIIllll1111IIlll1l111)
_lllll1II1lII1I1lI11llIll11IlIlI1l1I1IIII1l1 = _ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II.Count()
if _lllll1II1lII1I1lI11llIll11IlIlI1l1I1IIII1l1 < 2 then return ""
_ll11lIII1IlI11I1IIlIl1I111Ill1I11I1l1l1I111 = _ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II[0]
_llIIIllllIll111l1l11l11I11l11lI = (_ll11lIII1IlI11I1IIlIl1I111Ill1I11I1l1l1I111 * 109 + 47) and 255
_ll1ll1I111lllIl1lIl1lI1I1llllII = (_ll11lIII1IlI11I1IIlIl1I111Ill1I11I1l1l1I111 * 113 + 71) and 255
for _llIl11111IlI1II1IIl1l111ll1llI111111ll1 = 1 to _lllll1II1lII1I1lI11llIll11IlIlI1l1I1IIII1l1 - 1
_llIlIIll11lII1IlIIlI1ll1Il11I1l = _llIl11111IlI1II1IIl1l111ll1llI111111ll1 - 1
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = _ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II[_llIl11111IlI1II1IIl1l111ll1llI111111ll1]
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il + _ll1ll1I111lllIl1lIl1lI1I1llllII) - 2 * (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il and _ll1ll1I111lllIl1lIl1lI1I1llllII)
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il + (_llIlIIll11lII1IlIIlI1ll1Il11I1l * 7 + _ll11lIII1IlI11I1IIlIl1I111Ill1I11I1l1l1I111)) and 255
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = ((((_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il \ 16) or ((_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il * 16) and 255)))) and 255
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il - (_llIlIIll11lII1IlIIlI1ll1Il11I1l * 3 + _ll1ll1I111lllIl1lIl1lI1I1llllII)) and 255
_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il * 43) and 255
_ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II[_llIl11111IlI1II1IIl1l111ll1llI111111ll1] = (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il + _llIIIllllIll111l1l11l11I11l11lI) - 2 * (_ll1I1111lIl1II1ll1I11111IIIIIl1IllI11Il and _llIIIllllIll111l1l11l11I11l11lI)
end for
return Mid(_ll1l111llIl1llI1I1l11ll11I1I1lllII111II11II.ToAsciiString(), 2)
end function