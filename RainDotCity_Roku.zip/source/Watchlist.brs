function W_Section() as Object
_l1lI1ll = CreateObject(_l1d_acf7d9("a4b28ac2c3bcb5bfbcb8a1dad7d1d7dce0", 219, 251), _l1d_acf7d9("c3999490bd97b3c9a6bcbcd9e9cab2bdd3c5dadd", 174, 199))
_lllI1ll = CreateObject(_l1d_acf7d9("977f7d8f9091aaaaafad96a7acbcaca9ab", 142, 155), _l1d_acf7d9("fbcfeddaf00a19030becfc07f50ffcff", 58, 137))
if _lllI1ll.GetKeyList() <> invalid and _lllI1ll.GetKeyList().Count() > 0 then
for each _lII11ll in _lllI1ll.GetKeyList()
if not _l1lI1ll.Exists(_lII11ll) then _l1lI1ll.Write(_lII11ll, _lllI1ll.Read(_lII11ll))
end for
_l1lI1ll.Flush()
end if
return _l1lI1ll
end function
function W_ItemKey(_l1Ill1l as String, _llIll1l as String) as String
if ((65565 - 7285 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _llIll1l <> invalid and _llIll1l <> "" then return _llIll1l
if _l1Ill1l <> invalid and _l1Ill1l <> "" then return _l1Ill1l
return ""
end function
function W_AsInt(_lI1I11l as Dynamic) as Integer
if _lI1I11l = invalid then return 0
_l11I11l = Type(_lI1I11l)
if _l11I11l = _l1d_acf7d9("d1f5f206070cf8", 26, 126) or _l11I11l = _l1d_acf7d9("e6e4c1ebf4", 129, 243) or _l11I11l = _l1d_acf7d9("a3c3a0c8b1c5cacbbb", 80, 129) then return _lI1I11l
if _l11I11l = _l1d_acf7d9("f724241d35", 195, 114) or _l11I11l = _l1d_acf7d9("f1ef0bf8f8f109", 227, 96) or _l11I11l = _l1d_acf7d9("56344d3d3a46", 168, 106) or _l11I11l = _l1d_acf7d9("f7f70ffd06f603ff", 224, 101) then return Int(_lI1I11l)
if _l11I11l = _l1d_acf7d9("2f1916323832", 115, 15) or _l11I11l = _l1d_acf7d9("8d9d749c99a7abb7", 218, 229) then return _lI1I11l.ToInt()
if _l11I11l = _l1d_acf7d9("f315171304202d2122273b", 198, 105) or _l11I11l = _l1d_acf7d9("b6bca2c2c6d0b1cfccdedfe4da", 95, 137) then return _lI1I11l
return 0
end function
function W_AsBool(_ll11lIl as Dynamic) as Boolean
if _ll11lIl = invalid then return false
_lIl1lIl = Type(_ll11lIl)
if _lIl1lIl = _l1d_acf7d9("a87e818791988e", 127, 107) or _lIl1lIl = _l1d_acf7d9("fdf5d3fbfefefa0109", 68, 199) then return _ll11lIl
if _lIl1lIl = _l1d_acf7d9("668c8da5afa9", 17, 36) or _lIl1lIl = _l1d_acf7d9("fe1e25090a242c28", 112, 252) then return LCase(_ll11lIl) = _l1d_acf7d9("cbd4d2c5", 196, 27)
return false
end function
function W_Read(_llllIIl as String) as Object
if _llllIIl = "" then return invalid
_ll1lIIl = W_Section()
if not _ll1lIIl.Exists(_llllIIl) then return invalid
_lIllIIl = _ll1lIIl.Read(_llllIIl)
if _lIllIIl = invalid or _lIllIIl = "" then return invalid
_l1llIIl = ParseJson(_lIllIIl)
if _l1llIIl = invalid then return invalid
return _l1llIIl
end function
sub W_Write(_lII1ll1 as String, _l1I1ll1 as Object)
if ((30156 - 4308 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _lII1ll1 = "" then return
_lllIll1 = W_Section()
_lllIll1.Write(_lII1ll1, FormatJson(_l1I1ll1))
_lllIll1.Flush()
end sub
function W_IsFinished(_llIlIl1 as Integer, _lI1lIl1 as Integer) as Boolean
if _lI1lIl1 <= 0 then return false
if _lI1lIl1 >= 840 and _llIlIl1 >= _lI1lIl1 - 420 then return true
if _llIlIl1 >= _lI1lIl1 - 90 then return true
if _llIlIl1 >= Int(_lI1lIl1 * 0.95) then return true
return false
end function
function W_MinResumeSeconds() as Integer
return 30
end function
function W_GetMovieProgress(_lIl1I11 as String, _l1l1I11 as String) as Object
if ((36171 - 4019 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
return W_Read(_l1d_acf7d9("9b4f", 190, 200) + W_ItemKey(_lIl1I11, _l1l1I11))
end function
sub W_SaveMovieProgress(_l1ll1I1 as String, _llll1I1 as String, _ll1l1I1 as Integer, _lIIIlI1 as Integer)
_lIll1I1 = W_ItemKey(_l1ll1I1, _llll1I1)
if _lIll1I1 = "" then return
if _ll1l1I1 < 0 then _ll1l1I1 = 0
W_Write(_l1d_acf7d9("76cc", 79, 84) + _lIll1I1, {
pos:  _ll1l1I1
dur:  _lIIIlI1
done: W_IsFinished(_ll1l1I1, _lIIIlI1)
ts:   CreateObject(_l1d_acf7d9("c6dcfae0d0e2f6f4f3ee", 247, 65)).AsSeconds()
})
end sub
function W_GetEpisodeProgress(_lII1II1 as String, _l1I1II1 as String, _lllIII1 as Integer, _llI1II1 as Integer) as Object
return W_Read(_l1d_acf7d9("8254", 13, 26) + W_ItemKey(_lII1II1, _l1I1II1) + _l1d_acf7d9("91", 223, 172) + _lllIII1.ToStr() + _l1d_acf7d9("63", 254, 159) + _llI1II1.ToStr())
end function
sub W_SaveEpisodeProgress(_lIIl1lI as String, _l1Il1lI as String, _llI11lI as Integer, _llIl1lI as Integer, _l1111lI as Integer, _l11l1lI as Integer, _lII11lI as String, _ll111lI as String, _lIl11lI as Integer, _l1l11lI as Integer)
_lll11lI = W_ItemKey(_lIIl1lI, _l1Il1lI)
if _lll11lI = "" then return
if _l1111lI < 0 then _l1111lI = 0
_lI1l1lI = W_IsFinished(_l1111lI, _l11l1lI)
_lllI1lI = CreateObject(_l1d_acf7d9("3a381230483a2e444b46", 193, 135)).AsSeconds()
W_Write(_l1d_acf7d9("993f", 187, 187) + _lll11lI + _l1d_acf7d9("e5", 176, 91) + _llI11lI.ToStr() + _l1d_acf7d9("ef", 14, 187) + _llIl1lI.ToStr(), {
pos:  _l1111lI
dur:  _l11l1lI
done: _lI1l1lI
ts:   _lllI1lI
})
_lI111lI = W_Read(_l1d_acf7d9("d19b", 150, 236) + _lll11lI)
if _lIl11lI <= 0 and _lI111lI <> invalid and _lI111lI.lastSeason <> invalid then _lIl11lI = W_AsInt(_lI111lI.lastSeason)
if _l1l11lI <= 0 and _lI111lI <> invalid and _lI111lI.lastEpisode <> invalid then _l1l11lI = W_AsInt(_lI111lI.lastEpisode)
_l1I11lI = false
if _lI1l1lI and _lIl11lI > 0 and _l1l11lI > 0 then
if _llI11lI > _lIl11lI or (_llI11lI = _lIl11lI and _llIl1lI >= _l1l11lI) then
_l1I11lI = true
end if
end if
W_Write(_l1d_acf7d9("024c", 228, 107) + _lll11lI, {
season:      _llI11lI
episode:     _llIl1lI
slug:        _lII11lI
name:        _ll111lI
pos:         _l1111lI
dur:         _l11l1lI
done:        _l1I11lI
lastSeason:  _lIl11lI
lastEpisode: _l1l11lI
ts:          _lllI1lI
})
end sub
function W_GetSeriesProgress(_ll1IIlI as String, _lIlIIlI as String) as Object
if ((42255 - 8451 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return W_Read(_l1d_acf7d9("99d5", 73, 95) + W_ItemKey(_ll1IIlI, _lIlIIlI))
end function
sub W_MarkWatched(_l1l111I as String, _lll111I as String, _ll1111I as String)
if ((38180 - 9545 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_lIl111I = W_ItemKey(_l1l111I, _lll111I)
if _lIl111I = "" then return
_llI111I = CreateObject(_l1d_acf7d9("240c38202e225424232e", 110, 8)).AsSeconds()
if _ll1111I = _l1d_acf7d9("feff", 34, 168) then
_lI1111I = W_Read(_l1d_acf7d9("4e18", 178, 141) + _lIl111I)
if _lI1111I = invalid then _lI1111I = {}
_lI1111I.done = true
_lI1111I.ts = _llI111I
W_Write(_l1d_acf7d9("6c26", 26, 3) + _lIl111I, _lI1111I)
else
_l11111I = W_Read(_l1d_acf7d9("6f45", 15, 13) + _lIl111I)
if _l11111I = invalid then _l11111I = { pos: 0, dur: 0 }
_l11111I.done = true
_l11111I.ts = _llI111I
W_Write(_l1d_acf7d9("cb01", 95, 153) + _lIl111I, _l11111I)
end if
end sub
function W_ResumePosition(_l1III1I as Object) as Integer
if _l1III1I = invalid then return 0
if W_AsBool(_l1III1I.done) then return 0
_lIIII1I = W_AsInt(_l1III1I.pos)
if _lIIII1I < W_MinResumeSeconds() then return 0
return _lIIII1I
end function
function W_FormatTime(_lII11II as Integer) as String
if ((71658 - 7962 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if _lII11II <= 0 then return _l1d_acf7d9("3bff", 125, 238)
_lI111II = Int(_lII11II / 3600)
m = Int((_lII11II Mod 3600) / 60)
_l1I11II = _lII11II Mod 60
if _lI111II > 0 then
_llI11II = m.ToStr()
if m < 10 then _llI11II = _l1d_acf7d9("4d", 88, 229) + _llI11II
return _lI111II.ToStr() + _l1d_acf7d9("601b", 145, 103) + _llI11II + _l1d_acf7d9("0c", 76, 235)
end if
if m > 0 then return m.ToStr() + _l1d_acf7d9("30f6", 24, 187) + _l1I11II.ToStr() + _l1d_acf7d9("70", 200, 181)
return _l1I11II.ToStr() + _l1d_acf7d9("ac", 174, 207)
end function
sub W_RememberContext(_lI1llll as String, _ll1llll as Object)
if _lI1llll = "" or _ll1llll = invalid then return
_l11llll = W_Read(_l1d_acf7d9("cca8", 39, 136) + _lI1llll)
_l1Illll = {}
if _l11llll <> invalid then
for each _llIllll in _l11llll
_l1Illll[_llIllll] = _l11llll[_llIllll]
end for
end if
for each _llIllll in _ll1llll
_lIIllll = _ll1llll[_llIllll]
if _lIIllll <> invalid and _lIIllll <> "" then _l1Illll[_llIllll] = _lIIllll
end for
_l1Illll.ts = CreateObject(_l1d_acf7d9("b5abc5abbbade1bfbeb9", 101, 158)).AsSeconds()
W_Write(_l1d_acf7d9("559f", 104, 74) + _lI1llll, _l1Illll)
end sub
function W_GetContext(_l1lI1ll as String) as Object
if _l1lI1ll = "" then return invalid
return W_Read(_l1d_acf7d9("05d1", 13, 151) + _l1lI1ll)
end function
function W_ListInProgress(_lIlIl1l as Integer) as Object
_ll1Il1l = []
_lIIIl1l = W_Section()
_lllIl1l = _lIIIl1l.GetKeyList()
if _lllIl1l = invalid then return _ll1Il1l
_llll11l = {}
for each _lII1l1l in _lllIl1l
_l1lIl1l = ""
_llI1l1l = ""
if Left(_lII1l1l, 2) = _l1d_acf7d9("bb8f", 38, 112) then
_l1lIl1l = _l1d_acf7d9("b2b7a1bfb6", 20, 57)
_llI1l1l = Mid(_lII1l1l, 3)
else if Left(_lII1l1l, 2) = _l1d_acf7d9("4a94", 242, 201) then
_l1lIl1l = _l1d_acf7d9("9d9e", 218, 239)
_llI1l1l = Mid(_lII1l1l, 3)
end if
if _l1lIl1l <> "" and not _llll11l.DoesExist(_llI1l1l) then
_llll11l[_llI1l1l] = true
_l1l1l1l = W_Read(_lII1l1l)
if _l1l1l1l <> invalid then
_lI1Il1l = W_AsInt(_l1l1l1l.pos)
_lll1l1l = W_AsInt(_l1l1l1l.dur)
_l111l1l = W_AsBool(_l1l1l1l.done)
if _lI1Il1l >= 5 or _l111l1l then
_lIIll1l = W_GetContext(_llI1l1l)
_l1ll11l = _llI1l1l
_llIIl1l = ""
if _lIIll1l <> invalid then
if _lIIll1l.title <> invalid and _lIIll1l.title <> "" then _l1ll11l = _lIIll1l.title
if _lIIll1l.poster <> invalid and _lIIll1l.poster <> "" then _llIIl1l = _lIIll1l.poster
end if
if _l1ll11l = _llI1l1l or Left(_l1ll11l, 2) = _l1d_acf7d9("b6b9", 48, 114) then
if _l1l1l1l.name <> invalid and _l1l1l1l.name <> "" and Left(_l1l1l1l.name, 2) <> _l1d_acf7d9("3b3e", 191, 112) then
_l1IIl1l = _l1l1l1l.name
_lIl1l1l = Instr(1, _l1IIl1l, _l1d_acf7d9("87978d5f", 114, 53))
if _lIl1l1l > 1 then
_l1ll11l = Left(_l1IIl1l, _lIl1l1l - 1)
else
_l1ll11l = _l1IIl1l
end if
end if
end if
if (_llIIl1l = invalid or _llIIl1l = "") and Left(_llI1l1l, 2) = _l1d_acf7d9("aeb1", 13, 53) then
_llIIl1l = _l1d_acf7d9("eed5d8dfe5afbfc2070605060700d61813051d270f27ee1e1e323734012d473632463e16455a595f6228", 52, 146) + _llI1l1l + _l1d_acf7d9("5c1d241d", 98, 15)
end if
_l11Il1l = W_PercentOf(_lI1Il1l, _lll1l1l)
if _l111l1l and _l11Il1l < 100 then _l11Il1l = 100
_lI11l1l = {
itemKey: _llI1l1l
kind:    _l1lIl1l
title:   _l1ll11l
poster:  _llIIl1l
href:    ""
imdb:    _llI1l1l
tmdb:    ""
pos:     _lI1Il1l
dur:     _lll1l1l
pct:     _l11Il1l
ts:      W_AsInt(_l1l1l1l.ts)
done:    _l111l1l
}
if _l1lIl1l = _l1d_acf7d9("6c71", 153, 127) then
_lI11l1l.season  = W_AsInt(_l1l1l1l.season)
_lI11l1l.episode = W_AsInt(_l1l1l1l.episode)
if _l1l1l1l.name <> invalid and _l1l1l1l.name <> "" then _lI11l1l.name = _l1l1l1l.name else _lI11l1l.name = ""
end if
_ll1Il1l.Push(_lI11l1l)
end if
end if
end if
end for
if _ll1Il1l.Count() > 1 then
for _ll11l1l = 0 to _ll1Il1l.Count() - 2
for _l1I1l1l = 0 to _ll1Il1l.Count() - 2 - _ll11l1l
if _ll1Il1l[_l1I1l1l].ts < _ll1Il1l[_l1I1l1l + 1].ts then
_lIll11l = _ll1Il1l[_l1I1l1l]
_ll1Il1l[_l1I1l1l] = _ll1Il1l[_l1I1l1l + 1]
_ll1Il1l[_l1I1l1l + 1] = _lIll11l
end if
end for
end for
end if
if _lIlIl1l > 0 and _ll1Il1l.Count() > _lIlIl1l then
_ll1l11l = []
for _ll11l1l = 0 to _lIlIl1l - 1
_ll1l11l.Push(_ll1Il1l[_ll11l1l])
end for
return _ll1l11l
end if
return _ll1Il1l
end function
function W_PercentOf(_lIII11l as Integer, _llII11l as Integer) as Integer
if _llII11l <= 0 then return 0
_l1II11l = Int((_lIII11l * 100) / _llII11l)
if _l1II11l < 0 then _l1II11l = 0
if _l1II11l > 100 then _l1II11l = 100
return _l1II11l
end function
function W_GetProgressPct(_l1I1lIl as String, _llI1lIl as String, _l1lIlIl as Integer, _lI11lIl as Integer) as Integer
_lII1lIl = W_ItemKey(_l1I1lIl, _llI1lIl)
if _lII1lIl = "" then return 0
if _l1lIlIl > 0 and _lI11lIl > 0 then
_l111lIl = W_Read(_l1d_acf7d9("f6a6", 28, 125) + _lII1lIl + _l1d_acf7d9("f5", 144, 75) + _l1lIlIl.ToStr() + _l1d_acf7d9("93", 22, 103) + _lI11lIl.ToStr())
if _l111lIl = invalid or W_AsBool(_l111lIl.done) then return 0
return W_PercentOf(W_AsInt(_l111lIl.pos), W_AsInt(_l111lIl.dur))
end if
m = W_Read(_l1d_acf7d9("4678", 241, 170) + _lII1lIl)
if m <> invalid and not W_AsBool(m.done) then
return W_PercentOf(W_AsInt(m.pos), W_AsInt(m.dur))
end if
_lllIlIl = W_Read(_l1d_acf7d9("ee3a", 71, 186) + _lII1lIl)
if _lllIlIl <> invalid and not W_AsBool(_lllIlIl.done) then
return W_PercentOf(W_AsInt(_lllIlIl.pos), W_AsInt(_lllIlIl.dur))
end if
return 0
end function
function W_FavSection() as Object
_l11lIIl = CreateObject(_l1d_acf7d9("846c6a7c7d7e97979c9a839499a9999698", 78, 72), _l1d_acf7d9("bed2dde3c0e8f6c2efff05ead6f60c060e0a1a0c19", 195, 45))
_ll1lIIl = CreateObject(_l1d_acf7d9("746c9a686d7a87838c96b3808995959698", 228, 222), _l1d_acf7d9("877b697a6c9695b39d7b938f958f9d91a2", 96, 95))
if _ll1lIIl.GetKeyList() <> invalid and _ll1lIIl.GetKeyList().Count() > 0 then
for each _lIllIIl in _ll1lIIl.GetKeyList()
if not _l11lIIl.Exists(_lIllIIl) then _l11lIIl.Write(_lIllIIl, _ll1lIIl.Read(_lIllIIl))
end for
_l11lIIl.Flush()
end if
return _l11lIIl
end function
function W_IsFavorite(_l1lIll1 as String, _lllIll1 as String) as Boolean
_lIlIll1 = W_ItemKey(_l1lIll1, _lllIll1)
if _lIlIll1 = "" then return false
return W_FavSection().Exists(_lIlIll1)
end function
sub W_AddFavorite(_l1IlIl1 as Object)
if _l1IlIl1 = invalid then return
_lll1Il1 = ""
_lIIlIl1 = ""
if _l1IlIl1.imdb <> invalid then _lll1Il1 = _l1IlIl1.imdb
if _l1IlIl1.href <> invalid then _lIIlIl1 = _l1IlIl1.href
_l1l1Il1 = W_ItemKey(_lll1Il1, _lIIlIl1)
if _l1l1Il1 = "" then return
_lIl1Il1 = {
title:  ""
poster: ""
href:   _lIIlIl1
imdb:   _lll1Il1
tmdb:   ""
kind:   ""
ts:     CreateObject(_l1d_acf7d9("485844645a6e40686f7a", 154, 96)).AsSeconds()
}
if _l1IlIl1.title  <> invalid then _lIl1Il1.title  = _l1IlIl1.title
if _l1IlIl1.poster <> invalid then _lIl1Il1.poster = _l1IlIl1.poster
if _l1IlIl1.tmdb   <> invalid then _lIl1Il1.tmdb   = _l1IlIl1.tmdb
if _l1IlIl1.kind   <> invalid then _lIl1Il1.kind   = _l1IlIl1.kind
_ll11Il1 = W_FavSection()
_ll11Il1.Write(_l1l1Il1, FormatJson(_lIl1Il1))
_ll11Il1.Flush()
end sub
sub W_RemoveFavorite(_llIIl11 as String, _lI1Il11 as String)
if ((49530 - 9906 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1IIl11 = W_ItemKey(_llIIl11, _lI1Il11)
if _l1IIl11 = "" then return
_lIIIl11 = W_FavSection()
if _lIIIl11.Exists(_l1IIl11) then
_lIIIl11.Delete(_l1IIl11)
_lIIIl11.Flush()
end if
end sub
function W_ListFavorites() as Object
if ((28161 - 4023 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_l1lII11 = []
_ll1II11 = W_FavSection()
_lII1I11 = _ll1II11.GetKeyList()
if _lII1I11 = invalid then return _l1lII11
for each _l1I1I11 in _lII1I11
_lIlII11 = _ll1II11.Read(_l1I1I11)
if _lIlII11 <> invalid and _lIlII11 <> "" then
_lllII11 = ParseJson(_lIlII11)
if _lllII11 <> invalid then
if _lllII11.itemKey = invalid then _lllII11.itemKey = _l1I1I11
_l1lII11.Push(_lllII11)
end if
end if
end for
if _l1lII11.Count() > 1 then
for _lI11I11 = 0 to _l1lII11.Count() - 2
for _llI1I11 = 0 to _l1lII11.Count() - 2 - _lI11I11
_ll11I11 = W_AsInt(_l1lII11[_llI1I11].ts)
_l111I11 = W_AsInt(_l1lII11[_llI1I11 + 1].ts)
if _ll11I11 < _l111I11 then
_l11II11 = _l1lII11[_llI1I11]
_l1lII11[_llI1I11] = _l1lII11[_llI1I11 + 1]
_l1lII11[_llI1I11 + 1] = _l11II11
end if
end for
end for
end if
return _l1lII11
end function
function W_SearchHistoryMax() as Integer
return 12
end function
function W_GetSearchHistory() as Object
_lIlIII1 = CreateObject(_l1d_acf7d9("cfc7f5c7c8d9e2e2e7f50edfe4f4f4f1f3", 38, 123), _l1d_acf7d9("7fb1bcc49dcbb3a5cebcc4", 144, 189))
if not _lIlIII1.Exists(_l1d_acf7d9("322b2a3c2e2c4f314a543c5450", 171, 90)) then
_lII1II1 = CreateObject(_l1d_acf7d9("dae2c0eef3f0ede9f2ecd9060ffb0b0c0e", 156, 236), _l1d_acf7d9("7e92a89db38d94", 222, 232))
if _lII1II1.Exists(_l1d_acf7d9("3d3635453935183c555d475d5b", 74, 4)) then return ParseJson(_lII1II1.Read(_l1d_acf7d9("556e6d5f717f62846d778f7783", 83, 53)))
return []
end if
_l1lIII1 = _lIlIII1.Read(_l1d_acf7d9("bdd6d5c5d9e5c8ecd5ddf7ddeb", 146, 220))
if _l1lIII1 = invalid or _l1lIII1 = "" then return []
_lllIII1 = ParseJson(_l1lIII1)
if _lllIII1 = invalid then return []
return _lllIII1
end function
sub W_PushSearchQuery(_l1l11lI as String)
if _l1l11lI = invalid then return
_lIl11lI = _l1l11lI
if Type(_lIl11lI) = _l1d_acf7d9("a7c3ccd6d6e2", 28, 88) or Type(_lIl11lI) = _l1d_acf7d9("d2e8b7d5def6f8f2", 149, 235) then
_lIl11lI = U_Trim(_lIl11lI)
end if
if _lIl11lI = "" then return
_l1Il1lI = W_GetSearchHistory()
_lIIl1lI = [_lIl11lI]
_llIl1lI = LCase(_lIl11lI)
for each _lll11lI in _l1Il1lI
if Type(_lll11lI) = _l1d_acf7d9("4f7976828892", 155, 135) or Type(_lll11lI) = _l1d_acf7d9("deccc3e9ead2dce6", 9, 99) then
if LCase(_lll11lI) <> _llIl1lI and _lIIl1lI.Count() < W_SearchHistoryMax() then
_lIIl1lI.Push(_lll11lI)
end if
end if
end for
_ll111lI = CreateObject(_l1d_acf7d9("7c6ca27c7d768f979492bb9491a9919698", 234, 228), _l1d_acf7d9("154b46422f49453b584e4e", 30, 201))
_ll111lI.Write(_l1d_acf7d9("f30807fd0f19fc1e0b112d151d", 145, 17), FormatJson(_lIIl1lI))
_ll111lI.Flush()
end sub
sub W_ClearSearchHistory()
if ((14920 - 2984 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l11IIlI = CreateObject(_l1d_acf7d9("664e4c5e5f6079797e7c65767b8b7b787a", 14, 234), _l1d_acf7d9("cf010c0ce513fbf51e0414", 84, 201))
if _l11IIlI.Exists(_l1d_acf7d9("86939a8ea2aa8db19e9ab8a6b0", 20, 31)) then
_l11IIlI.Delete(_l1d_acf7d9("0d22211729234628252b372f27", 249, 131))
_l11IIlI.Flush()
end if
end sub
function W_MirrorSection() as Object
return CreateObject(_l1d_acf7d9("a8c8cec8c9d2bbc3c0cee7e0ddd5edf2f4", 50, 104), _l1d_acf7d9("8278837f9c8672a8957b8ba8bda48c8fa795b999b19fa5", 182, 158))
end function
function W_MirrorRecord(_l1lllII as String) as Object
if _l1lllII = "" then return { ok: 0, fail: 0 }
_lI1llII = W_MirrorSection()
if not _lI1llII.Exists(_l1lllII) then return { ok: 0, fail: 0 }
_l11llII = _lI1llII.Read(_l1lllII)
_ll1llII = _l11llII.Tokenize(_l1d_acf7d9("71", 240, 167))
_lIlllII = 0
_lllllII = 0
if _ll1llII.Count() >= 1 then _lIlllII = _ll1llII[0].ToInt()
if _ll1llII.Count() >= 2 then _lllllII = _ll1llII[1].ToInt()
return { ok: _lIlllII, fail: _lllllII }
end function
sub W_RecordMirrorOutcome(_l1I11II as String, _l1lI1II as Boolean)
if _l1I11II = "" then return
_lII11II = W_MirrorRecord(_l1I11II)
if _l1lI1II then
_lII11II.ok = _lII11II.ok + 1
else
_lII11II.fail = _lII11II.fail + 1
end if
_lllI1II = W_MirrorSection()
_lllI1II.Write(_l1I11II, _lII11II.ok.ToStr() + _l1d_acf7d9("e6", 142, 50) + _lII11II.fail.ToStr())
_lllI1II.Flush()
end sub
function W_MirrorScore(_lI1llll as String) as Float
if _lI1llll = "" then return -1.0
_llIllll = W_MirrorRecord(_lI1llll)
_l1Illll = _llIllll.ok + _llIllll.fail
if _l1Illll = 0 then return -1.0
return _llIllll.ok / (_l1Illll * 1.0)
end function
function W_MirrorTotal(_ll1I1ll as String) as Integer
if ((7665 - 1095 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l11I1ll = W_MirrorRecord(_ll1I1ll)
return _l11I1ll.ok + _l11I1ll.fail
end function
function WL_IsFavorite(_l1l1l1l as String) as Boolean
if _l1l1l1l = invalid or _l1l1l1l = "" then return false
return W_IsFavorite(_l1l1l1l, "")
end function
sub WL_ToggleFavorite(_llllI1l as Object)
if ((15515 - 3103 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if _llllI1l = invalid or _llllI1l.id = invalid or _llllI1l.id = "" then return
if WL_IsFavorite(_llllI1l.id) then
W_RemoveFavorite(_llllI1l.id, "")
else
_lIII11l = {
imdb: _llllI1l.id,
title: _llllI1l.title,
poster: _llllI1l.poster,
kind: _llllI1l.kind,
year: _llllI1l.year,
rating: _llllI1l.rating
}
W_AddFavorite(_lIII11l)
end if
end sub
function WL_GetFavorites() as Object
if ((48472 - 6059 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lllIlIl = W_ListFavorites()
_lII1lIl = []
if _lllIlIl <> invalid then
for each _l1I1lIl in _lllIlIl
_llI1lIl = _l1I1lIl.imdb
if _llI1lIl = invalid or _llI1lIl = "" then _llI1lIl = _l1I1lIl.itemKey
_lII1lIl.Push({
id: _llI1lIl,
title: _l1I1lIl.title,
poster: _l1I1lIl.poster,
kind: _l1I1lIl.kind,
year: _l1I1lIl.year,
rating: _l1I1lIl.rating
})
end for
end if
return _lII1lIl
end function
function _l1d_acf7d9(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function