function TMDB_BuildKey() as String
if ((11109 - 3703 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
return ""
end function
function TMDB_Key() as String
if ((12030 - 2005 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llIll1l = U_PrefDefault(_l1d_9f1519("86727c7955868d", 138, 136), "")
if _llIll1l <> invalid and _llIll1l <> "" then return _llIll1l
return TMDB_BuildKey()
end function
function TMDB_Enabled() as Boolean
return TMDB_Key() <> ""
end function
function TMDB_Image(_lIl1lIl as String, _ll11lIl as String) as String
if _lIl1lIl = invalid or _lIl1lIl = "" then return ""
if _ll11lIl = "" then _ll11lIl = _l1d_9f1519("eaafb5b8", 142, 241)
if Left(_lIl1lIl, 4) = _l1d_9f1519("40373a41", 159, 73) then return _lIl1lIl
return _l1d_9f1519("261518171be7fd003d443b4445133c56525322644c622d57335939", 17, 173) + _ll11lIl + _lIl1lIl
end function
function TMDB_IsNumeric(_l1llIIl as Dynamic) as Boolean
if _l1llIIl = invalid then return false
_lIllIIl = ""
if Type(_l1llIIl) = _l1d_9f1519("795760686a74", 61, 11) or Type(_l1llIIl) = _l1d_9f1519("c4d2a9d3d0dce2ec", 91, 155) then
_lIllIIl = _l1llIIl
else
return false
end if
if _lIllIIl = "" then return false
_llllIIl = CreateObject(_l1d_9f1519("3b5b61575c5d53", 48, 249), _l1d_9f1519("d8d9c40e0a", 240, 42), "")
return _llllIIl.isMatch(_lIllIIl)
end function
function TMDB_FmtRating(_l1lIll1 as Dynamic) as String
if _l1lIll1 = invalid then return ""
_lII1ll1 = 0.0
_lII1ll1 = _l1lIll1
if _lII1ll1 <= 0 then return ""
_lllIll1 = Int(_lII1ll1 * 10 + 0.5)
_lIlIll1 = _lllIll1 \ 10
_l1I1ll1 = _lllIll1 mod 10
return _lIlIll1.ToStr() + _l1d_9f1519("28", 7, 255) + _l1I1ll1.ToStr()
end function
function TMDB_FindId(_lll1Il1 as String, _lIl1Il1 as String, _l1IlIl1 as String) as String
if not TMDB_Enabled() then return ""
if _lll1Il1 = invalid or _lll1Il1 = "" then return ""
_lIIlIl1 = _l1d_9f1519("171834242b", 175, 85)
if _l1IlIl1 = _l1d_9f1519("a4a9", 152, 184) then _lIIlIl1 = _l1d_9f1519("4a4f", 32, 246)
_l1l1Il1 = _l1d_9f1519("1504070608d2eaed261834f8253c3c4748324c4b4d4a195d435b260d2c536c6b5b6f7b41", 18, 155) + _lIIlIl1 + _l1d_9f1519("e30c1e1a0f1e1f36fd", 130, 38) + TMDB_Key() + _l1d_9f1519("dd1312251d27e6", 52, 203) + U_UrlEncode(_lll1Il1)
if _lIl1Il1 <> invalid and _lIl1Il1 <> "" then
if _l1IlIl1 = _l1d_9f1519("c3c8", 28, 91) then
_l1l1Il1 = _l1l1Il1 + _l1d_9f1519("26e9effbff03f1f6010dfd05051b0f0c2918172b79", 192, 64) + _lIl1Il1
else
_l1l1Il1 = _l1l1Il1 + _l1d_9f1519("72b8b7b6ca88", 40, 100) + _lIl1Il1
end if
end if
_lI1lIl1 = HA_GetJson(_l1l1Il1)
if _lI1lIl1 = invalid or _lI1lIl1.results = invalid then return ""
if _lI1lIl1.results.Count() = 0 then return ""
_llIlIl1 = _lI1lIl1.results[0]
if _llIlIl1.id = invalid then return ""
return _llIlIl1.id.ToStr()
end function
function TMDB_Enrich(_llll111 as Object) as Object
if ((6396 - 2132 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if _llll111 = invalid then return _llll111
if not TMDB_Enabled() then return _llll111
_ll1l111 = ""
if _llll111.tmdb <> invalid then _ll1l111 = _llll111.tmdb.ToStr()
if not TMDB_IsNumeric(_ll1l111) then
_ll1l111 = TMDB_FindId(_llll111.title, _llll111.year, _llll111.kind)
end if
if not TMDB_IsNumeric(_ll1l111) then return _llll111
_l1ll111 = _l1d_9f1519("3f404c4443", 67, 17)
if _llll111.kind = _l1d_9f1519("5459", 120, 72) then _l1ll111 = _l1d_9f1519("5c5d", 39, 9)
_l11l111 = _l1d_9f1519("9aa9acabab776d70a9bdb77dcac1bfcacbd7cfced2cf9ee0e8dea9b0af", 131, 175) + _l1ll111 + _l1d_9f1519("ab", 10, 134) + _ll1l111 + _l1d_9f1519("a64b5f5952615e75bc", 65, 40) + TMDB_Key() + _l1d_9f1519("5694a6a9a19da6d4bcaaddc3b9cacabcbed6cb96cfe1d7d9d1eff1a7e0e8e8f405f4fdfec90400c23d3e", 168, 200)
_lI1Il11 = HA_GetJson(_l11l111)
if _lI1Il11 = invalid then return _llll111
_llll111.tmdb = _ll1l111
if _lI1Il11.overview <> invalid and _lI1Il11.overview <> "" then _llll111.description = _lI1Il11.overview
if _lI1Il11.backdrop_path <> invalid and _lI1Il11.backdrop_path <> "" then _llll111.backdrop = TMDB_Image(_lI1Il11.backdrop_path, _l1d_9f1519("864b514a55", 157, 156))
if (_llll111.poster = "" or _llll111.poster = invalid) and _lI1Il11.poster_path <> invalid then _llll111.poster = TMDB_Image(_lI1Il11.poster_path, _l1d_9f1519("d3989699", 34, 126))
_lIll111 = TMDB_FmtRating(_lI1Il11.vote_average)
if _lIll111 <> "" then _llll111.rating = _lIll111
if _llll111.kind = _l1d_9f1519("c4c5", 218, 22) then
if _lI1Il11.episode_run_time <> invalid and Type(_lI1Il11.episode_run_time) = _l1d_9f1519("c2a895cbcebec9", 141, 195) and _lI1Il11.episode_run_time.Count() > 0 then
_llll111.runtime = _lI1Il11.episode_run_time[0].ToStr() + _l1d_9f1519("92d2d1d5", 170, 8)
end if
if _lI1Il11.first_air_date <> invalid and Len(_lI1Il11.first_air_date) >= 4 then _llll111.year = Left(_lI1Il11.first_air_date, 4)
else
if _lI1Il11.runtime <> invalid and _lI1Il11.runtime > 0 then _llll111.runtime = _lI1Il11.runtime.ToStr() + _l1d_9f1519("2eeeedf1", 250, 84)
if _lI1Il11.release_date <> invalid and Len(_lI1Il11.release_date) >= 4 then _llll111.year = Left(_lI1Il11.release_date, 4)
end if
if _lI1Il11.genres <> invalid and _lI1Il11.genres.Count() > 0 then
_l1IIl11 = []
for each _lIIIl11 in _lI1Il11.genres
if _lIIIl11.name <> invalid then _l1IIl11.Push(_lIIIl11.name)
end for
if _l1IIl11.Count() > 0 then _llll111.genres = _l1IIl11
end if
if _lI1Il11.credits <> invalid and _lI1Il11.credits.cast <> invalid and _lI1Il11.credits.cast.Count() > 0 then
_l11Il11 = []
for each _ll1Il11 in _lI1Il11.credits.cast
_llIIl11 = { id: "", name: "", character: "", photo: "" }
if _ll1Il11.id <> invalid then _llIIl11.id = _ll1Il11.id.ToStr()
if _ll1Il11.name <> invalid then _llIIl11.name = _ll1Il11.name
if _ll1Il11.character <> invalid then _llIIl11.character = _ll1Il11.character
if _ll1Il11.profile_path <> invalid and _ll1Il11.profile_path <> "" then _llIIl11.photo = TMDB_Image(_ll1Il11.profile_path, _l1d_9f1519("fabfcbc1", 37, 168))
_l11Il11.Push(_llIIl11)
if _l11Il11.Count() >= 18 then exit for
end for
if _l11Il11.Count() > 0 then _llll111.cast = _l11Il11
end if
return _llll111
end function
function _l1d_9f1519(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function