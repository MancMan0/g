function VSR_Resolve(_ll1I1ll as String, _l11I1ll as String, _llII1ll = 1 as Integer, _lIlI1ll = 1 as Integer) as Object
if _ll1I1ll = invalid or _ll1I1ll = "" then return invalid
if _l11I1ll = invalid or _l11I1ll = "" then _l11I1ll = _l1d_007d69("6166826675", 201, 189)
if _l11I1ll = _l1d_007d69("acb1", 20, 76) then
_l1lI1ll = _l1d_007d69("49686b6a6a261c1f79686e797886357d9498808d888e969a5399985ba8a3a9b1b56dcbcc76", 171, 134) + _ll1I1ll + _l1d_007d69("04", 239, 68) + _llII1ll.ToStr() + _l1d_007d69("26", 78, 197) + _lIlI1ll.ToStr()
else
_l1lI1ll = _l1d_007d69("b0bfc2c1c511070ad0cfc5e0cfe120d4ebefebe4efe9edf13ef40346ff0a04080c58191e2a1e1d6a", 225, 39) + _ll1I1ll
end if
_lllI1ll = {
embedUrl: _l1lI1ll,
refer: _l1d_007d69("a6c5c8c7cd877f82d6c5cdd8d7e796dcf3f5e3ece7eff5f7b4fcfbbe", 136, 198),
kind: _l11I1ll,
imdb: _ll1I1ll,
season: _llII1ll,
episode: _lIlI1ll
}
print _l1d_007d69("72727074827a929f9ea4ada19c649bb8c4b7bdb7799bd2d6ceabd6ccd4d897dce6eea3", 131, 154); _ll1I1ll; _l1d_007d69("423d", 234, 120); _l11I1ll; _l1d_007d69("9b", 187, 9)
_lI1I1ll = R_ResolveEmbed(_lllI1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("6d757b7f7585516a515370608bab8d7c806c9570827e82c99d9a939693acafebe4", 237, 183); Left(_lI1I1ll.url, 60)
return _lI1I1ll
end if
if _l11I1ll = _l1d_007d69("0409", 97, 239) then
_lII11ll = _l1d_007d69("f6edf0f7f7334144fd05141b541616245f2c2735353971", 255, 95) + _ll1I1ll + _l1d_007d69("39", 112, 218) + _llII1ll.ToStr() + _l1d_007d69("ab", 206, 200) + _lIlI1ll.ToStr() + _l1d_007d69("d2", 24, 155)
else
_lII11ll = _l1d_007d69("b59c9fa6a8728285beb4d3ca93d7c5d5a0dde8e4e6e8b2", 182, 215) + _ll1I1ll + _l1d_007d69("f1", 122, 156)
end if
_lllI1ll.embedUrl = _lII11ll
_lllI1ll.refer = _l1d_007d69("2b22252c326c7c7f343a49508d514f5f9a", 92, 247)
print _l1d_007d69("bcc2caccc4d2c0b9c0c0bdcfda18e7d0cadddde92d11ece8f7f0f8ea4506020051", 252, 21); _ll1I1ll
_lI1I1ll = R_ResolveEmbed(_lllI1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("190f1719211f51465d614a603ba94d78606f7c8476c17374898c8d8285cfdc", 86, 12); Left(_lI1I1ll.url, 60)
return _lI1I1ll
end if
_l1II1ll = HC_NewSession()
_lI1I1ll = VSR_ResolveVidSrcIn(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
HC_Close(_l1II1ll)
print _l1d_007d69("99a7a7a9a9afa596a5a5a2b4bf75ceb4c2d4b6cae3cb90c6cbdcdfe4d5d8", 56, 54)
return _lI1I1ll
end if
_lI1I1ll = VSR_ResolveVidSrcCc(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
HC_Close(_l1II1ll)
print _l1d_007d69("554b53555d5b49425959465873a1727066806276997cbc726f888b888184", 116, 38)
return _lI1I1ll
end if
_lI1I1ll = VSR_ResolveVidSrcXyz(_ll1I1ll, _l11I1ll, _llII1ll, _lIlI1ll, _l1II1ll)
HC_Close(_l1II1ll)
if _lI1I1ll <> invalid and _lI1I1ll.url <> "" then
print _l1d_007d69("c4c2c2c4d4ca04f11014fd13ee54e92321ef112501252572242d3a3d463336", 210, 59)
return _lI1I1ll
end if
print _l1d_007d69("0e141c1e1624160b12160f25306e52282b7a3a282f344a4b3b4543479b58625d5b6769b06d6967bc", 254, 105); _ll1I1ll
return invalid
end function
function VSR_ResolveVidSrcCc(_lll1l1l as String, _l1l1l1l as String, _llI1l1l as Integer, _l1Ill1l as Integer, _lllIl1l as Object) as Object
_lIl1l1l = _l1d_007d69("bfbec1c0c2fc1417d1dbe9d7d9ed2bf3f6", 250, 45)
_llIll1l = _lIl1l1l + _l1d_007d69("8632718f4c574d5559a16667536b6ab3", 115, 42) + _lll1l1l
if _l1l1l1l = _l1d_007d69("e9ea", 7, 118) then
_llIll1l = _lIl1l1l + _l1d_007d69("0ec80717e0dbe3e9eb29e1e632", 120, 183) + _lll1l1l + _l1d_007d69("b9", 193, 203) + _llI1l1l.ToStr() + _l1d_007d69("3d", 136, 150) + _l1Ill1l.ToStr()
_lII1l1l = _lIl1l1l + _l1d_007d69("e2231531ee2b213d263d393d06", 182, 73) + _lll1l1l + _l1d_007d69("98", 27, 100) + _llI1l1l.ToStr() + _l1d_007d69("99", 117, 63) + _l1Ill1l.ToStr() + _l1d_007d69("d7a693abaa9cb4b8", 196, 236)
else
_lII1l1l = _lIl1l1l + _l1d_007d69("f52a1c38013a28443150484c19", 48, 214) + _lll1l1l + _l1d_007d69("194059454c624e52", 146, 92)
end if
_lIIll1l = {
"Referer": _llIll1l,
"Origin": _lIl1l1l,
"Accept": _l1d_007d69("687a7d6c6c797a907881834785a19092535ab1a5abba68bcabb3aeb6777e7b8381", 136, 127),
"X-Requested-With": _l1d_007d69("b1a7abaae9ecebd0e4f3faedfe04", 137, 224)
}
_l111l1l = HC_Get(_lllIl1l, _lII1l1l, _lIIll1l, 6000)
if _l111l1l = invalid or _l111l1l.body = "" then return invalid
_ll11l1l = ParseJson(_l111l1l.body)
if _ll11l1l = invalid or type(_ll11l1l) <> _l1d_007d69("969ecfa0a3aab9b6c1afbfb3c9f0c0c3d9c4", 254, 10) then return invalid
_l1I1l1l = invalid
if _ll11l1l.data <> invalid then _l1I1l1l = _ll11l1l.data
if (_l1I1l1l = invalid or type(_l1I1l1l) <> _l1d_007d69("aba380b4b7a9c4", 196, 245)) and _ll11l1l.servers <> invalid then _l1I1l1l = _ll11l1l.servers
if _l1I1l1l = invalid or type(_l1I1l1l) <> _l1d_007d69("bed4b5c7caded9", 23, 89) or _l1I1l1l.Count() = 0 then return invalid
for each _ll1Il1l in _l1I1l1l
if type(_ll1Il1l) <> _l1d_007d69("89977c9194a3aaa3aea6acaebe9db3b6c6b1", 25, 30) then continue for
_l11Il1l = ""
if _ll1Il1l.hash <> invalid then _l11Il1l = _ll1Il1l.hash
if _l11Il1l = "" and _ll1Il1l.data_id <> invalid then _l11Il1l = _ll1Il1l.data_id
if _l11Il1l = "" and _ll1Il1l.id <> invalid then _l11Il1l = _ll1Il1l.id
if _l11Il1l = "" then continue for
_l1lIl1l = _lIl1l1l + _l1d_007d69("e29789a5ee95b49d9db1b603", 80, 99) + _l11Il1l
_lIlIl1l = HC_Get(_lllIl1l, _l1lIl1l, _lIIll1l, 6000)
if _lIlIl1l = invalid or _lIlIl1l.body = "" then continue for
_lI11l1l = ParseJson(_lIlIl1l.body)
if _lI11l1l = invalid or type(_lI11l1l) <> _l1d_007d69("e7dfc0f1f4ebeaf7f2000004fae111140a25", 70, 179) then continue for
_lI1Il1l = ""
if _lI11l1l.data <> invalid and type(_lI11l1l.data) = _l1d_007d69("7b937485889f9eaba694b498ae95a5a8beb9", 22, 23) and _lI11l1l.data.stream <> invalid then
if type(_lI11l1l.data.stream) = _l1d_007d69("91adb6b0b0ac", 68, 122) or type(_lI11l1l.data.stream) = _l1d_007d69("3f5726464b696561", 86, 27) then
_lI1Il1l = _lI11l1l.data.stream
end if
end if
if _lI1Il1l = "" and _lI11l1l.stream <> invalid and (type(_lI11l1l.stream) = _l1d_007d69("4e7875919791", 83, 78) or type(_lI11l1l.stream) = _l1d_007d69("c7b5acd6d3bfc5cf", 139, 206)) then
_lI1Il1l = _lI11l1l.stream
end if
if _lI1Il1l <> "" then
_l1IIl1l = []
if _lI11l1l.data <> invalid and _lI11l1l.data.subtitles <> invalid and type(_lI11l1l.data.subtitles) = _l1d_007d69("98b88da1a4b6b1", 208, 246) then
for each _llIIl1l in _lI11l1l.data.subtitles
if _llIIl1l.file <> invalid and _llIIl1l.file <> "" then
_l1IIl1l.Push({
url: _llIIl1l.file,
label: _llIIl1l.label,
language: _llIIl1l.language
})
end if
end for
end if
return {
url: _lI1Il1l,
streamFormat: U_StreamFormat(_lI1Il1l),
subtitles: _l1IIl1l,
referer: _llIll1l,
userAgent: _lllIl1l.userAgent
}
end if
end for
return invalid
end function
function VSR_ResolveVidSrcIn(_lIII11l as String, _llllI1l as String, _lI1lI1l as Integer, _l1II11l as Integer, _llIlI1l as Object) as Object
_llII11l = _l1d_007d69("a6bdc0c7c703f1f4d0c0c8dce0d20ad2d012dfdae8e8ec24e9ea06f6fd36", 79, 127) + _lIII11l
if _llllI1l = _l1d_007d69("464b", 237, 173) then
_llII11l = _l1d_007d69("b5cccfd6dc160609e3d1d7f1f3e71de3e327f0ebfbf9fb39111642", 236, 49) + _lIII11l + _l1d_007d69("90", 77, 46) + _lI1lI1l.ToStr() + _l1d_007d69("9e", 183, 6) + _l1II11l.ToStr()
end if
_lIllI1l = HC_Get(_llIlI1l, _llII11l, { "Referer": _l1d_007d69("d2f1f4f3f9b3abae08eefc0e1004c20008cc", 136, 242) }, 7000)
if _lIllI1l = invalid or _lIllI1l.body = "" then return invalid
_ll1lI1l = CreateObject(_l1d_007d69("04fa2afafb0020", 231, 111), _l1d_007d69("4a80768d818883c0c063c75ca7ab9d76db", 167, 175) + chr(34) + _l1d_007d69("7582788a88", 158, 188) + chr(34) + _l1d_007d69("18f12a2b00", 244, 69) + chr(34) + _l1d_007d69("97c0", 140, 236), _l1d_007d69("34", 238, 173))
m = _ll1lI1l.match(_lIllI1l.body)
if m <> invalid and m.Count() >= 2 then
_lI1I11l = U_AbsUrl(m[1], _l1d_007d69("cdb4b7bec00a1a1dc7e9dfd5d7eb31fbf73b", 118, 175))
_l11I11l = HC_Get(_llIlI1l, _lI1I11l, { "Referer": _llII11l }, 7000)
if _l11I11l <> invalid and _l11I11l.body <> "" then
_l11lI1l = CreateObject(_l1d_007d69("d3d3f9cfd4d5eb", 224, 65), _l1d_007d69("0e515053525615152b2e3d45466e", 153, 93) + chr(34) + _l1d_007d69("99d6a3ddaef2b700c8e8f0f509", 3, 117) + chr(34) + _l1d_007d69("b18ac2c4", 244, 222), _l1d_007d69("c9", 45, 133))
_l1llI1l = _l11lI1l.match(_l11I11l.body)
if _l1llI1l <> invalid and _l1llI1l.Count() >= 2 then
return {
url: _l1llI1l[1],
streamFormat: _l1d_007d69("575642", 55, 248),
subtitles: [],
referer: _lI1I11l,
userAgent: _llIlI1l.userAgent
}
end if
end if
end if
return invalid
end function
function VSR_ResolveVidSrcXyz(_l111lIl as String, _lI11lIl as String, _lII1lIl as Integer, _ll11lIl as Integer, _lllIlIl as Object) as Object
if ((62531 - 8933 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lIl1lIl = _l1d_007d69("6c73767d81cdbbbe8a867e969a8cd4a9abb1df98a3a5a1a5f1b2b7c3bfb613c8c7c3cc20", 69, 63) + _l111lIl
if _lI11lIl = _l1d_007d69("6566", 110, 75) then
_lIl1lIl = _l1d_007d69("5372757478b4aaad896d7d8d9183c3909298ce97929ca0a4e0babff9a6adb9ba06", 201, 178) + _l111lIl + _l1d_007d69("328277768b7a7c4e", 136, 132) + _lII1lIl.ToStr() + _l1d_007d69("793d2d47304f4d4f8a", 243, 164) + _ll11lIl.ToStr()
end if
_llI1lIl = HC_Get(_lllIlIl, _lIl1lIl, { "Referer": _l1d_007d69("1c03060d0dd9e7ea16362e22263800393b3d0b", 183, 61) }, 7000)
if _llI1lIl = invalid or _llI1lIl.body = "" then return invalid
_l1I1lIl = CreateObject(_l1d_007d69("1f374533383937", 116, 25), _l1d_007d69("67aa91949b9d646a7a7d949297b5", 22, 41) + chr(34) + _l1d_007d69("1f88198d22643d82389ea4a58f", 168, 144) + chr(34) + _l1d_007d69("022f0509", 143, 90), _l1d_007d69("2e", 32, 229))
m = _l1I1lIl.match(_llI1lIl.body)
if m <> invalid and m.Count() >= 2 then
return {
url: m[1],
streamFormat: _l1d_007d69("464d47", 248, 182),
subtitles: [],
referer: _lIl1lIl,
userAgent: _lllIlIl.userAgent
}
end if
return invalid
end function
function _l1d_007d69(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function