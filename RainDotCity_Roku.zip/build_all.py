#!/usr/bin/env python3
"""
================================================================================
   RainDotCity // Unified Master Obfuscation and Protection Suite
================================================================================
   Complete All-In-One Engine:
     1. Roku OS Channel Obfuscator:
        - Position-Dependent Affine Non-Linear String Cipher (dual-key)
        - Homoglyphic Indistinguishable Identifier Mangling (_l{l,1,I})
        - Opaque Predicates and AI Hallucination Decoy Traps
        - SceneGraph XML Polymorphic NCR Entity Obfuscator
        - Pre-flight Dual Compiler and ElementTree Syntax Validation
        - Generates release package: 'RainDotCity_Roku.zip'
     2. Native Windows Downloader and Sideload Engine:
        - Auto-discovery of MSVC x64 C++ toolchain (vswhere / vcvarsall.bat)
        - High-performance C++ compilation (/MT /O2 /EHsc /std:c++17)
        - VMProtect Ultimate polymorphic code virtualization (10 VM Executors)
        - Anti-debugging, import protection, and startup packing
        - Generates hardened binary: 'RDC_Downloader.exe'
================================================================================
"""

import os
import sys
import re
import glob
import shutil
import random
import zipfile
import hashlib
import html
import argparse
import subprocess
import xml.etree.ElementTree as ET
from datetime import datetime

# Configure UTF-8 for console output on Windows
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass

# ANSI Colors for terminal output
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"

def log_header(title):
    print(f"\n{BOLD}{CYAN}{'=' * 75}{RESET}")
    print(f"{BOLD}{CYAN}   {title}{RESET}")
    print(f"{BOLD}{CYAN}{'=' * 75}{RESET}\n")

def log_step(step, msg):
    print(f"{BOLD}{YELLOW}[{step}]{RESET} {msg}")

def log_info(msg):
    print(f"{CYAN}[*]{RESET} {msg}")

def log_success(msg):
    print(f"{GREEN}[+]{RESET} {msg}")

def log_warn(msg):
    print(f"{YELLOW}[!]{RESET} {msg}")

def log_error(msg):
    print(f"{RED}[-]{RESET} {msg}")

# ==============================================================================
# SECTION 1: ROKU BRIGHTSCRIPT AND SCENEGRAPH XML OBFUSCATION ENGINE
# ==============================================================================

KEYWORDS = {
    'sub', 'end', 'function', 'if', 'then', 'else', 'elseif', 'for', 'to', 'step', 'next',
    'in', 'each', 'while', 'exit', 'return', 'print', 'goto', 'stop', 'dim', 'as', 'and',
    'or', 'not', 'invalid', 'true', 'false', 'try', 'catch', 'throw', 'continue',
    'integer', 'longinteger', 'float', 'double', 'string', 'boolean', 'object', 'dynamic', 'interface', 'void',
    'createobject', 'getinterface', 'type', 'box', 'run', 'wait', 'sleep', 'rnd', 'tab', 'pos',
    'tr', 'ucase', 'lcase', 'left', 'right', 'mid', 'len', 'asc', 'chr', 'val', 'str', 'stri', 'formatdrive',
    'm', 'line', 'pos'
}

class BrsTokenizer:
    """High-precision BrightScript lexer that preserves exact character positions."""
    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.len = len(text)

    def tokenize(self):
        tokens = []
        while self.pos < self.len:
            c = self.text[self.pos]
            if c in ' \t':
                start = self.pos
                while self.pos < self.len and self.text[self.pos] in ' \t':
                    self.pos += 1
                tokens.append(('WS', self.text[start:self.pos]))
            elif c in '\r\n':
                start = self.pos
                if c == '\r' and self.pos + 1 < self.len and self.text[self.pos + 1] == '\n':
                    self.pos += 2
                else:
                    self.pos += 1
                tokens.append(('NL', self.text[start:self.pos]))
            elif c == '\'':
                start = self.pos
                while self.pos < self.len and self.text[self.pos] not in '\r\n':
                    self.pos += 1
                tokens.append(('COMMENT', self.text[start:self.pos]))
            elif c == '\"':
                start = self.pos
                self.pos += 1
                while self.pos < self.len:
                    if self.text[self.pos] == '\"':
                        if self.pos + 1 < self.len and self.text[self.pos + 1] == '\"':
                            self.pos += 2
                        else:
                            self.pos += 1
                            break
                    elif self.text[self.pos] in '\r\n':
                        break
                    else:
                        self.pos += 1
                tokens.append(('STRING', self.text[start:self.pos]))
            elif c == '&' and self.pos + 1 < self.len and self.text[self.pos + 1] in 'hH':
                start = self.pos
                self.pos += 2
                while self.pos < self.len and (self.text[self.pos] in '0123456789abcdefABCDEF'):
                    self.pos += 1
                if self.pos < self.len and self.text[self.pos] in '&%':
                    self.pos += 1
                tokens.append(('NUMBER', self.text[start:self.pos]))
            elif c.isdigit() or (c == '.' and self.pos + 1 < self.len and self.text[self.pos + 1].isdigit()):
                start = self.pos
                while self.pos < self.len and (self.text[self.pos].isdigit() or self.text[self.pos] == '.'):
                    self.pos += 1
                if self.pos < self.len and self.text[self.pos] in 'eE':
                    self.pos += 1
                    if self.pos < self.len and self.text[self.pos] in '+-':
                        self.pos += 1
                    while self.pos < self.len and self.text[self.pos].isdigit():
                        self.pos += 1
                if self.pos < self.len and self.text[self.pos] in '%!#&':
                    self.pos += 1
                tokens.append(('NUMBER', self.text[start:self.pos]))
            elif c.isalpha() or c == '_':
                start = self.pos
                while self.pos < self.len and (self.text[self.pos].isalnum() or self.text[self.pos] == '_'):
                    self.pos += 1
                if self.pos < self.len and self.text[self.pos] in '%!#&$':
                    self.pos += 1
                val = self.text[start:self.pos]
                if val.lower() == 'rem':
                    if self.pos >= self.len or self.text[self.pos] in ' \t\r\n:':
                        while self.pos < self.len and self.text[self.pos] not in '\r\n':
                            self.pos += 1
                        tokens.append(('COMMENT', self.text[start:self.pos]))
                        continue
                tokens.append(('IDENT', val))
            elif self.text[self.pos:self.pos+2] in ['<=', '>=', '<>', '+=', '-=', '*=', '/=', '\\=', '<<', '>>']:
                tokens.append(('OP', self.text[self.pos:self.pos+2]))
                self.pos += 2
            else:
                tokens.append(('PUNCT', c))
                self.pos += 1
        return tokens

def collect_global_function_names(src_dir):
    """Scans all source files to catalog top-level function names so they are never mangled."""
    fn_names = set()
    for root, _, files in os.walk(src_dir):
        for f in files:
            path = os.path.join(root, f)
            if f.lower().endswith('.brs'):
                with open(path, 'r', encoding='utf-8', errors='ignore') as fp:
                    text = fp.read()
                toks = BrsTokenizer(text).tokenize()
                clean = [t for t in toks if t[0] not in ('COMMENT', 'WS')]
                for i, t in enumerate(clean):
                    if t[0] == 'IDENT' and t[1].lower() in ('sub', 'function') and (i == 0 or clean[i-1][1].lower() != 'end'):
                        if i + 1 < len(clean) and clean[i+1][0] == 'IDENT':
                            fn_names.add(clean[i+1][1].lower())
            elif f.lower().endswith('.xml'):
                with open(path, 'r', encoding='utf-8', errors='ignore') as fp:
                    xml_text = fp.read()
                for m in re.findall(r'onChange\s*=\s*["\']([a-zA-Z0-9_]+)["\']', xml_text, re.IGNORECASE):
                    fn_names.add(m.lower())
                for sm in re.findall(r'<script\b[^>]*>(.*?)</script>', xml_text, re.DOTALL | re.IGNORECASE):
                    for fn in re.findall(r'\b(?:sub|function)\s+([a-zA-Z0-9_]+)', sm, re.IGNORECASE):
                        fn_names.add(fn.lower())
    fn_names.update({'init', 'onkeyevent'})
    return fn_names

def generate_homoglyphic_id(f_idx, v_idx):
    """Generates an indistinguishable pseudo-random length (32-44 chars) homoglyphic identifier."""
    chars = ['l', '1', 'I']
    h = hashlib.sha256(f"fn_{f_idx}_var_{v_idx}_entropy_rdc_v3".encode()).digest()
    length_opts = [29, 33, 37, 41]
    chosen_len = length_opts[h[0] % len(length_opts)]
    if chosen_len > len(h):
        h2 = hashlib.sha256(h).digest()
        h_all = h + h2
    else:
        h_all = h
    seq = [chars[b % 3] for b in h_all[1:chosen_len+1]]
    return f"_ll{''.join(seq)}"

def analyze_and_mangle_locals(clean, toks, reserved_names):
    """Identifies local variables and parameters within functions and maps them to homoglyphic names."""
    funcs = []
    i = 0
    while i < len(clean):
        tok, orig_idx = clean[i]
        val_lower = tok[1].lower()
        if tok[0] == 'IDENT' and val_lower in ('sub', 'function') and (i == 0 or clean[i-1][0][1].lower() != 'end'):
            start_clean = i
            depth = 1
            j = i + 1
            while j < len(clean):
                t_j = clean[j][0]
                v_j = t_j[1].lower()
                if t_j[0] == 'IDENT' and v_j in ('sub', 'function') and clean[j-1][0][1].lower() != 'end':
                    depth += 1
                elif t_j[0] == 'IDENT' and (v_j in ('endsub', 'endfunction') or (v_j == 'end' and j + 1 < len(clean) and clean[j+1][0][1].lower() in ('sub', 'function'))):
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            funcs.append((start_clean, j))
            i = j
        i += 1

    mangle_map = {}
    for f_idx, (f_start, f_end) in enumerate(funcs):
        local_vars = set()
        p_idx = f_start + 1
        while p_idx < f_end and clean[p_idx][0][1] != '(':
            p_idx += 1
        if p_idx < f_end:
            p_idx += 1
            while p_idx < f_end and clean[p_idx][0][1] != ')':
                p_tok = clean[p_idx][0]
                if p_tok[0] == 'IDENT':
                    p_name = p_tok[1].lower()
                    if p_name not in KEYWORDS and p_name not in reserved_names:
                        local_vars.add(p_name)
                    if p_idx + 2 < f_end and clean[p_idx+1][0][1].lower() == 'as':
                        p_idx += 2
                p_idx += 1

        for ci in range(f_start, min(f_end + 1, len(clean))):
            c_tok, orig_idx = clean[ci]
            if c_tok[0] == 'IDENT':
                v_lower = c_tok[1].lower()
                prev_tok = clean[ci - 1][0] if ci > 0 else None
                next_tok = clean[ci + 1][0] if ci + 1 < len(clean) else None
                if next_tok and next_tok[1] == '=' and (not prev_tok or prev_tok[1] != '.'):
                    if v_lower not in KEYWORDS and v_lower not in reserved_names:
                        local_vars.add(v_lower)
                elif prev_tok and prev_tok[1].lower() in ('each', 'for') and (not next_tok or next_tok[1] != '.'):
                    if v_lower not in KEYWORDS and v_lower not in reserved_names:
                        local_vars.add(v_lower)

        var_names = sorted(list(local_vars))
        f_sub = {v: generate_homoglyphic_id(f_idx + 1, vi + 1) for vi, v in enumerate(var_names)}

        brace_depth = 0
        bracket_depth = 0
        for ci in range(f_start, min(f_end + 1, len(clean))):
            c_tok, orig_idx = clean[ci]
            if c_tok[1] == '{':
                brace_depth += 1
            elif c_tok[1] == '}':
                brace_depth = max(0, brace_depth - 1)
            elif c_tok[1] == '[':
                bracket_depth += 1
            elif c_tok[1] == ']':
                bracket_depth = max(0, bracket_depth - 1)
            elif c_tok[0] == 'IDENT':
                v_lower = c_tok[1].lower()
                prev_tok = clean[ci - 1][0] if ci > 0 else None
                next_tok = clean[ci + 1][0] if ci + 1 < len(clean) else None
                if prev_tok and prev_tok[1] == '.':
                    continue
                if next_tok and next_tok[1] == ':' and brace_depth > bracket_depth:
                    continue
                if v_lower in f_sub:
                    suffix = c_tok[1][-1] if c_tok[1][-1] in '%!#&$' else ''
                    mangle_map[orig_idx] = f_sub[v_lower] + suffix

    return mangle_map

# ==============================================================================
# MULTI-FAMILY POLYMORPHIC ENCRYPTION CIPHERS (ZERO-KEY-ARGUMENT CALL ARCHITECTURE)
# ==============================================================================

def encrypt_cipher_family_1(s, salt):
    """Cipher 1: Positional Affine Shift with Dynamic Salt Key Derivation."""
    k = (salt * 37 + 11) & 255
    seed = (salt * 59 + 23) & 255
    enc = [salt & 255]
    for i, b in enumerate(s.encode('utf-8')):
        v = b ^ k
        v = (v + (i * 3 + seed)) & 255
        enc.append(v)
    return bytes(enc).hex()

def gen_c1_decoder_brs(fn_name, file_int):
    v_arg = generate_homoglyphic_id(file_int, 910)
    v_arr = generate_homoglyphic_id(file_int, 911)
    v_cnt = generate_homoglyphic_id(file_int, 912)
    v_s   = generate_homoglyphic_id(file_int, 913)
    v_k   = generate_homoglyphic_id(file_int, 914)
    v_sd  = generate_homoglyphic_id(file_int, 915)
    v_i   = generate_homoglyphic_id(file_int, 916)
    v_val = generate_homoglyphic_id(file_int, 917)
    return (
        f"function {fn_name}({v_arg} as String) as String\n"
        f"if {v_arg} = \"\" then return \"\"\n"
        f"{v_arr} = CreateObject(\"roByteArray\")\n"
        f"{v_arr}.FromHexString({v_arg})\n"
        f"{v_cnt} = {v_arr}.Count()\n"
        f"if {v_cnt} < 2 then return \"\"\n"
        f"{v_s} = {v_arr}[0]\n"
        f"{v_k} = ({v_s} * 37 + 11) and 255\n"
        f"{v_sd} = ({v_s} * 59 + 23) and 255\n"
        f"for {v_i} = 1 to {v_cnt} - 1\n"
        f"{v_val} = ({v_arr}[{v_i}] - (({v_i} - 1) * 3 + {v_sd})) and 255\n"
        f"{v_arr}[{v_i}] = ({v_val} + {v_k}) - 2 * ({v_val} and {v_k})\n"
        f"end for\n"
        f"return Mid({v_arr}.ToAsciiString(), 2)\n"
        f"end function"
    )

def encrypt_cipher_family_2(s, salt):
    """Cipher 2: Cascading CBC-Style Block Chaining with Salt Feedback."""
    k = (salt * 41 + 19) & 255
    prev = salt & 255
    enc = [prev]
    for i, b in enumerate(s.encode('utf-8')):
        pos_k = (i * 7) & 255
        e = b ^ prev ^ k ^ pos_k
        enc.append(e)
        prev = e
    return bytes(enc).hex()

def gen_c2_decoder_brs(fn_name, file_int):
    v_arg  = generate_homoglyphic_id(file_int, 920)
    v_arr  = generate_homoglyphic_id(file_int, 921)
    v_cnt  = generate_homoglyphic_id(file_int, 922)
    v_s    = generate_homoglyphic_id(file_int, 923)
    v_k    = generate_homoglyphic_id(file_int, 924)
    v_prev = generate_homoglyphic_id(file_int, 925)
    v_i    = generate_homoglyphic_id(file_int, 926)
    v_e    = generate_homoglyphic_id(file_int, 927)
    v_pk   = generate_homoglyphic_id(file_int, 928)
    v_dec  = generate_homoglyphic_id(file_int, 929)
    return (
        f"function {fn_name}({v_arg} as String) as String\n"
        f"if {v_arg} = \"\" then return \"\"\n"
        f"{v_arr} = CreateObject(\"roByteArray\")\n"
        f"{v_arr}.FromHexString({v_arg})\n"
        f"{v_cnt} = {v_arr}.Count()\n"
        f"if {v_cnt} < 2 then return \"\"\n"
        f"{v_s} = {v_arr}[0]\n"
        f"{v_k} = ({v_s} * 41 + 19) and 255\n"
        f"{v_prev} = {v_s}\n"
        f"for {v_i} = 1 to {v_cnt} - 1\n"
        f"{v_e} = {v_arr}[{v_i}]\n"
        f"{v_pk} = (({v_i} - 1) * 7) and 255\n"
        f"{v_dec} = ({v_e} + {v_prev}) - 2 * ({v_e} and {v_prev})\n"
        f"{v_dec} = ({v_dec} + {v_k}) - 2 * ({v_dec} and {v_k})\n"
        f"{v_dec} = ({v_dec} + {v_pk}) - 2 * ({v_dec} and {v_pk})\n"
        f"{v_arr}[{v_i}] = {v_dec} and 255\n"
        f"{v_prev} = {v_e}\n"
        f"end for\n"
        f"return Mid({v_arr}.ToAsciiString(), 2)\n"
        f"end function"
    )

def encrypt_cipher_family_3(s, salt):
    """Cipher 3: 4-bit Nibble-Swap and Positional Diffusion Permutation."""
    k = (salt * 53 + 29) & 255
    salt2 = (salt * 71 + 31) & 255
    enc = [salt & 255]
    for i, b in enumerate(s.encode('utf-8')):
        v = b ^ k
        v = (((v << 4) | (v >> 4))) & 255
        v = (v + (i * 5 + salt2)) & 255
        enc.append(v)
    return bytes(enc).hex()

def gen_c3_decoder_brs(fn_name, file_int):
    v_arg  = generate_homoglyphic_id(file_int, 930)
    v_arr  = generate_homoglyphic_id(file_int, 931)
    v_cnt  = generate_homoglyphic_id(file_int, 932)
    v_s    = generate_homoglyphic_id(file_int, 933)
    v_k    = generate_homoglyphic_id(file_int, 934)
    v_sd2  = generate_homoglyphic_id(file_int, 935)
    v_i    = generate_homoglyphic_id(file_int, 936)
    v_val  = generate_homoglyphic_id(file_int, 937)
    return (
        f"function {fn_name}({v_arg} as String) as String\n"
        f"if {v_arg} = \"\" then return \"\"\n"
        f"{v_arr} = CreateObject(\"roByteArray\")\n"
        f"{v_arr}.FromHexString({v_arg})\n"
        f"{v_cnt} = {v_arr}.Count()\n"
        f"if {v_cnt} < 2 then return \"\"\n"
        f"{v_s} = {v_arr}[0]\n"
        f"{v_k} = ({v_s} * 53 + 29) and 255\n"
        f"{v_sd2} = ({v_s} * 71 + 31) and 255\n"
        f"for {v_i} = 1 to {v_cnt} - 1\n"
        f"{v_val} = ({v_arr}[{v_i}] - (({v_i} - 1) * 5 + {v_sd2})) and 255\n"
        f"{v_val} = ((({v_val} \\ 16) or (({v_val} * 16) and 255))) and 255\n"
        f"{v_arr}[{v_i}] = ({v_val} + {v_k}) - 2 * ({v_val} and {v_k})\n"
        f"end for\n"
        f"return Mid({v_arr}.ToAsciiString(), 2)\n"
        f"end function"
    )

def encrypt_cipher_family_4(s, salt):
    """Cipher 4: Dynamic 8-bit Circular Shift with Positional S-Box Diffusion."""
    k = (salt * 67 + 43) & 255
    salt3 = (salt * 79 + 17) & 255
    enc = [salt & 255]
    for i, b in enumerate(s.encode('utf-8')):
        v = b ^ k
        v = (((v << 3) | (v >> 5))) & 255
        v = (v + (i * 11 + salt3)) & 255
        enc.append(v)
    return bytes(enc).hex()

def gen_c4_decoder_brs(fn_name, file_int):
    v_arg  = generate_homoglyphic_id(file_int, 940)
    v_arr  = generate_homoglyphic_id(file_int, 941)
    v_cnt  = generate_homoglyphic_id(file_int, 942)
    v_s    = generate_homoglyphic_id(file_int, 943)
    v_k    = generate_homoglyphic_id(file_int, 944)
    v_sd3  = generate_homoglyphic_id(file_int, 945)
    v_i    = generate_homoglyphic_id(file_int, 946)
    v_val  = generate_homoglyphic_id(file_int, 947)
    return (
        f"function {fn_name}({v_arg} as String) as String\n"
        f"if {v_arg} = \"\" then return \"\"\n"
        f"{v_arr} = CreateObject(\"roByteArray\")\n"
        f"{v_arr}.FromHexString({v_arg})\n"
        f"{v_cnt} = {v_arr}.Count()\n"
        f"if {v_cnt} < 2 then return \"\"\n"
        f"{v_s} = {v_arr}[0]\n"
        f"{v_k} = ({v_s} * 67 + 43) and 255\n"
        f"{v_sd3} = ({v_s} * 79 + 17) and 255\n"
        f"for {v_i} = 1 to {v_cnt} - 1\n"
        f"{v_val} = ({v_arr}[{v_i}] - (({v_i} - 1) * 11 + {v_sd3})) and 255\n"
        f"{v_val} = (((({v_val} \\ 8) or (({v_val} * 32) and 255)))) and 255\n"
        f"{v_arr}[{v_i}] = ({v_val} + {v_k}) - 2 * ({v_val} and {v_k})\n"
        f"end for\n"
        f"return Mid({v_arr}.ToAsciiString(), 2)\n"
        f"end function"
    )

def encrypt_cipher_family_5(s, salt):
    """Cipher 5: 4-Round Bounded Feistel Permutation with Dual Salt S-Box."""
    k1 = (salt * 73 + 19) & 255
    k2 = (salt * 83 + 37) & 255
    enc = [salt & 255]
    for i, b in enumerate(s.encode('utf-8')):
        v = b ^ k1
        v = (((v << 4) | (v >> 4)) + (i * 7 + k2)) & 255
        v = v ^ ((i * 13 + salt) & 255)
        v = (((v << 2) | (v >> 6))) & 255
        enc.append(v)
    return bytes(enc).hex()

def gen_c5_decoder_brs(fn_name, file_int):
    v_arg  = generate_homoglyphic_id(file_int, 950)
    v_arr  = generate_homoglyphic_id(file_int, 951)
    v_cnt  = generate_homoglyphic_id(file_int, 952)
    v_s    = generate_homoglyphic_id(file_int, 953)
    v_k1   = generate_homoglyphic_id(file_int, 954)
    v_k2   = generate_homoglyphic_id(file_int, 955)
    v_i    = generate_homoglyphic_id(file_int, 956)
    v_idx  = generate_homoglyphic_id(file_int, 957)
    v_val  = generate_homoglyphic_id(file_int, 958)
    v_rk   = generate_homoglyphic_id(file_int, 959)
    return (
        f"function {fn_name}({v_arg} as String) as String\n"
        f"if {v_arg} = \"\" then return \"\"\n"
        f"{v_arr} = CreateObject(\"roByteArray\")\n"
        f"{v_arr}.FromHexString({v_arg})\n"
        f"{v_cnt} = {v_arr}.Count()\n"
        f"if {v_cnt} < 2 then return \"\"\n"
        f"{v_s} = {v_arr}[0]\n"
        f"{v_k1} = ({v_s} * 73 + 19) and 255\n"
        f"{v_k2} = ({v_s} * 83 + 37) and 255\n"
        f"for {v_i} = 1 to {v_cnt} - 1\n"
        f"{v_idx} = {v_i} - 1\n"
        f"{v_val} = {v_arr}[{v_i}]\n"
        f"{v_val} = (((({v_val} \\ 4) or (({v_val} * 64) and 255)))) and 255\n"
        f"{v_rk} = ({v_idx} * 13 + {v_s}) and 255\n"
        f"{v_val} = ({v_val} + {v_rk}) - 2 * ({v_val} and {v_rk})\n"
        f"{v_val} = ({v_val} - ({v_idx} * 7 + {v_k2})) and 255\n"
        f"{v_val} = (((({v_val} \\ 16) or (({v_val} * 16) and 255)))) and 255\n"
        f"{v_arr}[{v_i}] = ({v_val} + {v_k1}) - 2 * ({v_val} and {v_k1})\n"
        f"end for\n"
        f"return Mid({v_arr}.ToAsciiString(), 2)\n"
        f"end function"
    )

def encrypt_cipher_family_6(s, salt):
    """Cipher 6: Dynamic 3-bit / 2-bit Dual Circular Shifts with Positional Salt Diffusion."""
    k1 = (salt * 97 + 53) & 255
    k2 = (salt * 103 + 61) & 255
    enc = [salt & 255]
    for i, b in enumerate(s.encode('utf-8')):
        v = b ^ k1
        v = (((v << 3) | (v >> 5))) & 255
        v = (v + (i * 17 + k2)) & 255
        v = (((v << 2) | (v >> 6))) & 255
        v = v ^ ((i * 19 + salt) & 255)
        enc.append(v)
    return bytes(enc).hex()

def gen_c6_decoder_brs(fn_name, file_int):
    v_arg  = generate_homoglyphic_id(file_int, 960)
    v_arr  = generate_homoglyphic_id(file_int, 961)
    v_cnt  = generate_homoglyphic_id(file_int, 962)
    v_s    = generate_homoglyphic_id(file_int, 963)
    v_k1   = generate_homoglyphic_id(file_int, 964)
    v_k2   = generate_homoglyphic_id(file_int, 965)
    v_i    = generate_homoglyphic_id(file_int, 966)
    v_idx  = generate_homoglyphic_id(file_int, 967)
    v_val  = generate_homoglyphic_id(file_int, 968)
    v_rk   = generate_homoglyphic_id(file_int, 969)
    return (
        f"function {fn_name}({v_arg} as String) as String\n"
        f"if {v_arg} = \"\" then return \"\"\n"
        f"{v_arr} = CreateObject(\"roByteArray\")\n"
        f"{v_arr}.FromHexString({v_arg})\n"
        f"{v_cnt} = {v_arr}.Count()\n"
        f"if {v_cnt} < 2 then return \"\"\n"
        f"{v_s} = {v_arr}[0]\n"
        f"{v_k1} = ({v_s} * 97 + 53) and 255\n"
        f"{v_k2} = ({v_s} * 103 + 61) and 255\n"
        f"for {v_i} = 1 to {v_cnt} - 1\n"
        f"{v_idx} = {v_i} - 1\n"
        f"{v_val} = {v_arr}[{v_i}]\n"
        f"{v_rk} = ({v_idx} * 19 + {v_s}) and 255\n"
        f"{v_val} = ({v_val} + {v_rk}) - 2 * ({v_val} and {v_rk})\n"
        f"{v_val} = (((({v_val} \\ 4) or (({v_val} * 64) and 255)))) and 255\n"
        f"{v_val} = ({v_val} - ({v_idx} * 17 + {v_k2})) and 255\n"
        f"{v_val} = (((({v_val} \\ 8) or (({v_val} * 32) and 255)))) and 255\n"
        f"{v_arr}[{v_i}] = ({v_val} + {v_k1}) - 2 * ({v_val} and {v_k1})\n"
        f"end for\n"
        f"return Mid({v_arr}.ToAsciiString(), 2)\n"
        f"end function"
    )

def encrypt_cipher_family_7(s, salt):
    """Cipher 7: Positional Modular Inverse Multiply (mod 256) with Nibble Swap and Dual Phase Feedback."""
    k1 = (salt * 109 + 47) & 255
    k2 = (salt * 113 + 71) & 255
    enc = [salt & 255]
    for i, b in enumerate(s.encode('utf-8')):
        v = b ^ k1
        v = (v * 131 + (i * 3 + k2)) & 255
        v = (((v << 4) | (v >> 4))) & 255
        v = (v - (i * 7 + salt)) & 255
        v = v ^ k2
        enc.append(v)
    return bytes(enc).hex()

def gen_c7_decoder_brs(fn_name, file_int):
    v_arg  = generate_homoglyphic_id(file_int, 970)
    v_arr  = generate_homoglyphic_id(file_int, 971)
    v_cnt  = generate_homoglyphic_id(file_int, 972)
    v_s    = generate_homoglyphic_id(file_int, 973)
    v_k1   = generate_homoglyphic_id(file_int, 974)
    v_k2   = generate_homoglyphic_id(file_int, 975)
    v_i    = generate_homoglyphic_id(file_int, 976)
    v_idx  = generate_homoglyphic_id(file_int, 977)
    v_val  = generate_homoglyphic_id(file_int, 978)
    return (
        f"function {fn_name}({v_arg} as String) as String\n"
        f"if {v_arg} = \"\" then return \"\"\n"
        f"{v_arr} = CreateObject(\"roByteArray\")\n"
        f"{v_arr}.FromHexString({v_arg})\n"
        f"{v_cnt} = {v_arr}.Count()\n"
        f"if {v_cnt} < 2 then return \"\"\n"
        f"{v_s} = {v_arr}[0]\n"
        f"{v_k1} = ({v_s} * 109 + 47) and 255\n"
        f"{v_k2} = ({v_s} * 113 + 71) and 255\n"
        f"for {v_i} = 1 to {v_cnt} - 1\n"
        f"{v_idx} = {v_i} - 1\n"
        f"{v_val} = {v_arr}[{v_i}]\n"
        f"{v_val} = ({v_val} + {v_k2}) - 2 * ({v_val} and {v_k2})\n"
        f"{v_val} = ({v_val} + ({v_idx} * 7 + {v_s})) and 255\n"
        f"{v_val} = (((({v_val} \\ 16) or (({v_val} * 16) and 255)))) and 255\n"
        f"{v_val} = ({v_val} - ({v_idx} * 3 + {v_k2})) and 255\n"
        f"{v_val} = ({v_val} * 43) and 255\n"
        f"{v_arr}[{v_i}] = ({v_val} + {v_k1}) - 2 * ({v_val} and {v_k1})\n"
        f"end for\n"
        f"return Mid({v_arr}.ToAsciiString(), 2)\n"
        f"end function"
    )

def generate_ai_decoy_predicate():
    """Generates mathematically unreachable branches containing realistic AI honeypot code."""
    trap_seed = random.randint(10000, 99999)
    chk_var = generate_homoglyphic_id(trap_seed, 1)

    inv_type = random.randint(1, 16)
    if inv_type == 1:
        n = random.randint(2, 25)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * {chk_var} * {chk_var} - {chk_var}) mod 6) <> 0) then"
    elif inv_type == 2:
        n = random.randint(2, 25)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * {chk_var}) mod 4) = 3) then"
    elif inv_type == 3:
        n = random.randint(2, 25)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * ({chk_var} + 1)) mod 2) <> 0) then"
    elif inv_type == 4:
        n = random.randint(2, 25)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * ({chk_var} + 1) * ({chk_var} + 2)) mod 6) <> 0) then"
    elif inv_type == 5:
        n = random.randint(2, 7)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * {chk_var} * {chk_var} * {chk_var} * {chk_var} - {chk_var}) mod 5) <> 0) then"
    elif inv_type == 6:
        n = random.randint(2, 25)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * {chk_var} + {chk_var} + 1) mod 2) = 0) then"
    elif inv_type == 7:
        n = random.randint(2, 25)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * {chk_var} + ({chk_var} + 1) * ({chk_var} + 1)) mod 2) = 0) then"
    elif inv_type == 8:
        n = random.randint(2, 13)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * {chk_var} * {chk_var} * {chk_var}) mod 5) = 2) then"
    elif inv_type == 9:
        n = random.randint(2, 13)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * {chk_var} * {chk_var} * {chk_var}) mod 5) = 3) then"
    elif inv_type == 10:
        n = random.randint(2, 10)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif (((({chk_var} * ({chk_var} + 1) * ({chk_var} + 2) * ({chk_var} + 3) + 1)) mod 4) = 2) then"
    elif inv_type == 11:
        n = random.randint(2, 12)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif ((({chk_var} * {chk_var} * {chk_var} * {chk_var} - {chk_var} * {chk_var}) mod 12) <> 0) then"
    elif inv_type == 12:
        n = random.randint(1, 20)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif (((({chk_var} * 4 + 1) * ({chk_var} * 4 + 1)) mod 8) <> 1) then"
    elif inv_type == 13:
        n = random.randint(1, 20)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif (((({chk_var} * 10 + 5) * ({chk_var} * 10 + 5)) mod 100) <> 25) then"
    elif inv_type == 14:
        n = random.randint(1, 8)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif (((({chk_var} * 6 + 1) * ({chk_var} * 6 + 1)) mod 24) <> 1) then"
    elif inv_type == 15:
        n = random.randint(1, 15)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif (((({chk_var} * 8 + 3) * ({chk_var} * 8 + 3)) mod 8) <> 1) then"
    else:
        n = random.randint(1, 15)
        cond = f"{chk_var} = ((Rnd(0) * 0) + {n})\nif (((({chk_var} * 8 + 5) * ({chk_var} * 8 + 5)) mod 8) <> 1) then"

    v1 = generate_homoglyphic_id(trap_seed, 2)
    v2 = generate_homoglyphic_id(trap_seed, 3)
    v3 = generate_homoglyphic_id(trap_seed, 4)
    rand_hex = hashlib.sha256(str(random.random()).encode()).hexdigest()[:12]
    rand_sha = hashlib.sha256(str(random.random()).encode()).hexdigest()

    honeypots = [
        (
            f"{v1} = CreateObject(\"roUrlTransfer\")\n"
            f"{v1}.SetCertificatesFile(\"common:/certs/ca-bundle.crt\")\n"
            f"{v1}.SetUrl(\"https://api.roku.com/v1/event/\" + \"{rand_hex}\")\n"
            f"{v1}.AddHeader(\"X-Trace-Id\", \"{rand_hex}\")\n"
            f"{v1}.AsyncGetToString()"
        ),
        (
            f"{v1} = CreateObject(\"roEVPDigest\")\n"
            f"if {v1} <> invalid then\n"
            f"{v1}.Setup(\"sha256\")\n"
            f"{v2} = {v1}.Process(\"{rand_hex}\")\n"
            f"end if"
        ),
        (
            f"{v1} = CreateObject(\"roRegistrySection\", \"_sec_{rand_hex[:4]}\")\n"
            f"{v1}.Write(\"token\", \"{rand_hex}\")\n"
            f"{v1}.Flush()"
        ),
        (
            f"{v1} = CreateObject(\"roDeviceInfo\")\n"
            f"{v2} = {v1}.GetChannelClientId()\n"
            f"{v3} = {v1}.GetDisplayMode()"
        ),
        (
            f"{v1} = CreateObject(\"roAppInfo\")\n"
            f"{v2} = {v1}.GetVersion()\n"
            f"{v3} = {v1}.GetDevID()"
        ),
        (
            f"{v1} = CreateObject(\"roChannelStore\")\n"
            f"{v2} = {v1}.GetPurchases()"
        ),
        (
            f"{v1} = CreateObject(\"roByteArray\")\n"
            f"{v1}.FromHexString(\"{rand_hex}\")\n"
            f"{v2} = {v1}.ToAsciiString()"
        ),
        (
            f"{v1} = CreateObject(\"roUrlTransfer\")\n"
            f"{v1}.SetCertificatesFile(\"common:/certs/ca-bundle.crt\")\n"
            f"{v1}.AddHeader(\"X-Auth-Token\", \"{rand_hex}\")"
        ),
        (
            f"{v1} = CreateObject(\"roEVPDigest\")\n"
            f"{v1}.Setup(\"md5\")\n"
            f"{v2} = {v1}.Process(\"{rand_hex}\")"
        ),
        (
            f"{v1} = CreateObject(\"roDeviceInfo\")\n"
            f"{v2} = {v1}.GetModelDetails()\n"
            f"if {v2} <> invalid and {v2}.vendorName = \"Roku\" then\n"
            f"{v3} = {v2}.modelNumber\n"
            f"end if"
        ),
        (
            f"{v1} = CreateObject(\"roUrlTransfer\")\n"
            f"{v1}.SetUrl(\"https://api.roku.com/v2/handshake\")\n"
            f"{v1}.AddHeader(\"Authorization\", \"Bearer {rand_sha}\")"
        ),
        (
            f"{v1} = CreateObject(\"roEVPDigest\")\n"
            f"{v1}.Setup(\"sha256\")\n"
            f"{v2} = {v1}.Process(\"{rand_hex}\")"
        ),
        (
            f"{v1} = CreateObject(\"roByteArray\")\n"
            f"{v1}.SetResize(64, false)\n"
            f"{v2} = {v1}.ToHexString()"
        ),
        (
            f"{v1} = CreateObject(\"roDateTime\")\n"
            f"{v2} = {v1}.AsSeconds() + 86400\n"
            f"{v3} = Stri({v2})"
        ),
        (
            f"{v1} = CreateObject(\"roRegistrySection\", \"_state_{rand_hex[:4]}\")\n"
            f"{v2} = {v1}.Read(\"active\")"
        ),
        (
            f"{v1} = CreateObject(\"roEVPDigest\")\n"
            f"{v1}.Setup(\"sha512\")\n"
            f"{v2} = {v1}.Process(\"{rand_hex}\")"
        )
    ]
    body = random.choice(honeypots)
    return f"{cond}\n{body}\nend if"

def obfuscate_brs(source_text, rel_path, reserved_names, level='ultra'):
    """Performs full multi-pass BrightScript obfuscation using 7 Polymorphic Ciphers and 6-Stage Cascading."""
    file_int = int(hashlib.sha256(rel_path.encode('utf-8')).hexdigest()[:8], 16)
    dec1_name = generate_homoglyphic_id(file_int, 901)
    dec2_name = generate_homoglyphic_id(file_int, 902)
    dec3_name = generate_homoglyphic_id(file_int, 903)
    dec4_name = generate_homoglyphic_id(file_int, 904)
    dec5_name = generate_homoglyphic_id(file_int, 905)
    dec6_name = generate_homoglyphic_id(file_int, 906)
    dec7_name = generate_homoglyphic_id(file_int, 907)

    dec_functions = [
        (dec1_name, encrypt_cipher_family_1, gen_c1_decoder_brs(dec1_name, file_int)),
        (dec2_name, encrypt_cipher_family_2, gen_c2_decoder_brs(dec2_name, file_int)),
        (dec3_name, encrypt_cipher_family_3, gen_c3_decoder_brs(dec3_name, file_int)),
        (dec4_name, encrypt_cipher_family_4, gen_c4_decoder_brs(dec4_name, file_int)),
        (dec5_name, encrypt_cipher_family_5, gen_c5_decoder_brs(dec5_name, file_int)),
        (dec6_name, encrypt_cipher_family_6, gen_c6_decoder_brs(dec6_name, file_int)),
        (dec7_name, encrypt_cipher_family_7, gen_c7_decoder_brs(dec7_name, file_int))
    ]

    toks = BrsTokenizer(source_text).tokenize()
    clean = [(t, i) for i, t in enumerate(toks) if t[0] not in ('COMMENT', 'WS')]

    aa_key_indices = set()
    brace_depth = 0
    bracket_depth = 0
    for ci, (tok, orig_idx) in enumerate(clean):
        if tok[1] == '{':
            brace_depth += 1
        elif tok[1] == '}':
            brace_depth = max(0, brace_depth - 1)
        elif tok[1] == '[':
            bracket_depth += 1
        elif tok[1] == ']':
            bracket_depth = max(0, bracket_depth - 1)
        elif tok[0] == 'STRING':
            next_t = clean[ci + 1][0] if ci + 1 < len(clean) else None
            if next_t and next_t[1] == ':' and brace_depth > bracket_depth:
                aa_key_indices.add(orig_idx)

    mangle_map = {}
    if level in ('high', 'ultra'):
        mangle_map = analyze_and_mangle_locals(clean, toks, reserved_names)

    used_decoders = set()
    out_tokens = []
    strings_count = 0
    comments_count = 0
    vars_count = len(mangle_map)
    in_sub_params = False
    in_for_header = False

    for idx, t in enumerate(toks):
        ttype, tval = t
        prev = toks[idx-1] if idx > 0 else (None, None)

        if ttype == 'IDENT' and tval.lower() in ('sub', 'function'):
            in_sub_params = True
        elif in_sub_params and ttype == 'PUNCT' and tval == ')':
            in_sub_params = False

        if ttype == 'IDENT' and tval.lower() == 'for':
            in_for_header = True
        elif in_for_header and (ttype == 'NL' or (ttype == 'PUNCT' and tval == ':')):
            in_for_header = False

        if ttype == 'COMMENT':
            comments_count += 1
            continue
        elif ttype == 'STRING':
            if idx in aa_key_indices:
                out_tokens.append(tval)
            else:
                raw_inner = tval[1:-1].replace('""', '"')
                if not raw_inner:
                    out_tokens.append('""')
                elif len(raw_inner) == 1 and ord(raw_inner) < 128:
                    out_tokens.append(f"Chr({ord(raw_inner)})")
                    strings_count += 1
                elif len(raw_inner) == 2 and ord(raw_inner[0]) < 128 and ord(raw_inner[1]) < 128:
                    out_tokens.append(f"(Chr({ord(raw_inner[0])}) + Chr({ord(raw_inner[1])}))")
                    strings_count += 1
                else:
                    r_mode = random.random()
                    if level == 'ultra' and r_mode < 0.10:
                        # 6-STAGE LAYERED ENCRYPTION
                        c_idxs = random.sample(range(len(dec_functions)), 6)
                        for c in c_idxs: used_decoders.add(c)
                        f_a, enc_a, _ = dec_functions[c_idxs[0]]
                        f_b, enc_b, _ = dec_functions[c_idxs[1]]
                        f_c, enc_c, _ = dec_functions[c_idxs[2]]
                        f_d, enc_d, _ = dec_functions[c_idxs[3]]
                        f_e, enc_e, _ = dec_functions[c_idxs[4]]
                        f_f, enc_f, _ = dec_functions[c_idxs[5]]
                        s_a, s_b, s_c, s_d, s_e, s_f = [random.randint(33, 126) for _ in range(6)]
                        h_a = enc_a(raw_inner, s_a)
                        h_b = enc_b(h_a, s_b)
                        h_c = enc_c(h_b, s_c)
                        h_d = enc_d(h_c, s_d)
                        h_e = enc_e(h_d, s_e)
                        h_f = enc_f(h_e, s_f)
                        q_hex = f'"{h_f}"'
                        out_tokens.append(f'{f_a}({f_b}({f_c}({f_d}({f_e}({f_f}({q_hex}))))))')
                    elif level == 'ultra' and r_mode < 0.30:
                        # 5-STAGE LAYERED ENCRYPTION
                        c_idxs = random.sample(range(len(dec_functions)), 5)
                        for c in c_idxs: used_decoders.add(c)
                        f_a, enc_a, _ = dec_functions[c_idxs[0]]
                        f_b, enc_b, _ = dec_functions[c_idxs[1]]
                        f_c, enc_c, _ = dec_functions[c_idxs[2]]
                        f_d, enc_d, _ = dec_functions[c_idxs[3]]
                        f_e, enc_e, _ = dec_functions[c_idxs[4]]
                        s_a, s_b, s_c, s_d, s_e = [random.randint(33, 126) for _ in range(5)]
                        h_a = enc_a(raw_inner, s_a)
                        h_b = enc_b(h_a, s_b)
                        h_c = enc_c(h_b, s_c)
                        h_d = enc_d(h_c, s_d)
                        h_e = enc_e(h_d, s_e)
                        q_hex = f'"{h_e}"'
                        out_tokens.append(f'{f_a}({f_b}({f_c}({f_d}({f_e}({q_hex})))))')
                    elif level == 'ultra' and r_mode < 0.55:
                        # 4-STAGE LAYERED ENCRYPTION
                        c_idxs = random.sample(range(len(dec_functions)), 4)
                        for c in c_idxs: used_decoders.add(c)
                        f_a, enc_a, _ = dec_functions[c_idxs[0]]
                        f_b, enc_b, _ = dec_functions[c_idxs[1]]
                        f_c, enc_c, _ = dec_functions[c_idxs[2]]
                        f_d, enc_d, _ = dec_functions[c_idxs[3]]
                        s_a, s_b, s_c, s_d = [random.randint(33, 126) for _ in range(4)]
                        h_a = enc_a(raw_inner, s_a)
                        h_b = enc_b(h_a, s_b)
                        h_c = enc_c(h_b, s_c)
                        h_d = enc_d(h_c, s_d)
                        q_hex = f'"{h_d}"'
                        out_tokens.append(f'{f_a}({f_b}({f_c}({f_d}({q_hex}))))')
                    elif level == 'ultra' and r_mode < 0.80:
                        # 3-STAGE LAYERED ENCRYPTION
                        c_idxs = random.sample(range(len(dec_functions)), 3)
                        for c in c_idxs: used_decoders.add(c)
                        f_a, enc_a, _ = dec_functions[c_idxs[0]]
                        f_b, enc_b, _ = dec_functions[c_idxs[1]]
                        f_c, enc_c, _ = dec_functions[c_idxs[2]]
                        s_a, s_b, s_c = [random.randint(33, 126) for _ in range(3)]
                        h_a = enc_a(raw_inner, s_a)
                        h_b = enc_b(h_a, s_b)
                        h_c = enc_c(h_b, s_c)
                        q_hex = f'"{h_c}"'
                        out_tokens.append(f'{f_a}({f_b}({f_c}({q_hex})))')
                    elif level == 'ultra' and r_mode < 0.95:
                        # 2-STAGE LAYERED ENCRYPTION
                        c_idxs = random.sample(range(len(dec_functions)), 2)
                        for c in c_idxs: used_decoders.add(c)
                        f_a, enc_a, _ = dec_functions[c_idxs[0]]
                        f_b, enc_b, _ = dec_functions[c_idxs[1]]
                        s_a, s_b = [random.randint(33, 126) for _ in range(2)]
                        h_a = enc_a(raw_inner, s_a)
                        h_b = enc_b(h_a, s_b)
                        q_hex = f'"{h_b}"'
                        out_tokens.append(f'{f_a}({f_b}({q_hex}))')
                    else:
                        # 1-STAGE ENCRYPTION
                        choice_idx = random.randint(0, len(dec_functions) - 1)
                        fn_name, enc_fn, _ = dec_functions[choice_idx]
                        used_decoders.add(choice_idx)
                        salt = random.randint(33, 126)
                        enc_hex = enc_fn(raw_inner, salt)
                        out_tokens.append(f'{fn_name}("{enc_hex}")')
                    strings_count += 1
        elif ttype == 'IDENT':
            if idx in mangle_map:
                out_tokens.append(mangle_map[idx])
            elif not in_sub_params and level == 'ultra':
                v_lower = tval.lower()
                if v_lower == 'true':
                    out_tokens.append(random.choice([
                        '(((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))',
                        '((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))',
                        '(((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))',
                        '((((100 \\ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))',
                        '((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))',
                        '(not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))',
                        '(((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))',
                        '((((256 \\ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))'
                    ]))
                elif v_lower == 'false':
                    out_tokens.append(random.choice([
                        '(((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))',
                        '((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))',
                        '(((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))',
                        '((not ((100 \\ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))',
                        '(not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))',
                        '((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))',
                        '(not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))',
                        '((((256 \\ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))'
                    ]))
                else:
                    out_tokens.append(tval)
            else:
                out_tokens.append(tval)
        elif ttype == 'NUMBER' and not in_sub_params and not in_for_header and level == 'ultra' and tval.isdigit() and len(tval) <= 3:
            val = int(tval)
            if prev[0] == 'OP' and prev[1] in ('&', '-', '+', '*', '/', '\\'):
                out_tokens.append(tval)
            elif val >= 0 and val <= 50:
                f_type = random.randint(1, 4)
                r1 = random.randint(11, 49)
                r2 = random.randint(11, 49)
                if f_type == 1:
                    out_tokens.append(f"(((((({r1} * 7) + (({r2} * 13) - ({r2} * 13))) + {val}) - ({r1} * 4)) - ({r1} * 3)))")
                elif f_type == 2:
                    out_tokens.append(f"(((((({r1} * 11) + {val}) + 42) - (({r1} * 11) + 42))))")
                elif f_type == 3:
                    out_tokens.append(f"(((((({r1} * 64) + {val}) mod 64) + ((255 and 255) - 255))))")
                else:
                    out_tokens.append(f"(((((({r1} * 5) + ({val} * 3)) - ({r1} * 5)) \\ 3)))")
            else:
                out_tokens.append(tval)
        else:
            out_tokens.append(tval)

    transformed = ''.join(out_tokens)
    raw_lines = [l.strip() for l in transformed.splitlines() if l.strip()]

    final_lines = []

    for line in raw_lines:
        lower = line.lower()
        if level == 'ultra' and (lower.startswith('endsub') or lower == 'end sub' or lower.startswith('endfunction') or lower == 'end function') and 'crypto' not in rel_path.lower() and 'aes' not in rel_path.lower() and random.random() < 0.40:
            final_lines.append(generate_ai_decoy_predicate())
        final_lines.append(line)
        if level == 'ultra' and (lower.startswith('sub ') or lower.startswith('function ')) and 'crypto' not in rel_path.lower() and 'aes' not in rel_path.lower() and random.random() < 0.55:
            final_lines.append(generate_ai_decoy_predicate())

    for idx in sorted(list(used_decoders)):
        final_lines.append(dec_functions[idx][2])

    return '\n'.join(final_lines), strings_count, comments_count, vars_count

def encode_xml_attribute_value(val):
    """Polymorphically encodes an XML attribute value using mixed Hex, Decimal, and Zero-Padded NCRs."""
    if not val:
        return val
    raw = html.unescape(val)
    chars = []
    for c in raw:
        code = ord(c)
        r = random.random()
        if r < 0.20:
            chars.append(f"&#x{code:02x};")
        elif r < 0.38:
            chars.append(f"&#x{code:02X};")
        elif r < 0.55:
            chars.append(f"&#x{code:04x};")
        elif r < 0.70:
            chars.append(f"&#x{code:04X};")
        elif r < 0.85:
            chars.append(f"&#{code};")
        else:
            chars.append(f"&#{code:05d};")
    return ''.join(chars)

def obfuscate_xml(xml_text, rel_path="", reserved_names=None, level='ultra'):
    """Performs polymorphic SceneGraph XML obfuscation with Decoy Node Forest and inline script protection."""
    if reserved_names is None:
        reserved_names = set()

    script_slots = []
    inline_strings_count = 0
    inline_vars_count = 0

    def script_extractor(m):
        nonlocal inline_strings_count, inline_vars_count
        full_tag = m.group(0)
        idx = len(script_slots)

        uri_m = re.search(r'\buri\s*=\s*["\']([^"\']+)["\']', full_tag, re.IGNORECASE)
        type_m = re.search(r'\btype\s*=\s*["\']([^"\']+)["\']', full_tag, re.IGNORECASE)
        script_type = type_m.group(1) if type_m else "text/brightscript"

        if uri_m:
            uri_val = uri_m.group(1)
            slot_content = f'<script type="{script_type}" uri="{uri_val}" />'
        else:
            inner_m = re.search(r'<script\b[^>]*>(.*?)</script>', full_tag, re.DOTALL | re.IGNORECASE)
            if inner_m:
                raw_inner = inner_m.group(1).strip()
                cdata_m = re.search(r'<!\[CDATA\[(.*?)\]\]>', raw_inner, re.DOTALL)
                bs_source = cdata_m.group(1) if cdata_m else raw_inner

                obf_bs, s_cnt, c_cnt, v_cnt = obfuscate_brs(
                    bs_source,
                    f"{rel_path}:inline_{idx}",
                    reserved_names,
                    level=level
                )
                verify_brightscript_syntax(obf_bs, f"{rel_path}:inline_{idx}")
                inline_strings_count += s_cnt
                inline_vars_count += v_cnt
                slot_content = (
                    f'<script type="{script_type}">\n'
                    f'<![CDATA[\n'
                    f'{obf_bs}\n'
                    f']]>\n'
                    f'</script>'
                )
            else:
                slot_content = full_tag

        script_slots.append(slot_content)
        return f"__ROKU_SCRIPT_SLOT_{idx}__"

    text = re.sub(r'<script\b[^>]*/>|<script\b[^>]*>.*?</script>', script_extractor, xml_text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)

    header = '<?xml version="1.0" encoding="utf-8" ?>\n'
    header_match = re.match(r'<\?xml[^>]*\?>\s*', text)
    if header_match:
        header = header_match.group(0).strip() + '\n'
        text = text[header_match.end():]

    if level == 'ultra':
        # Inject decoy security/DRM fields in <component>
        comp_m = re.search(r'<component\b[^>]*>', text, re.IGNORECASE)
        if comp_m:
            pos = comp_m.end()
            rid1 = random.randint(1000, 9999)
            rid2 = random.randint(1000, 9999)
            rid3 = random.randint(1000, 9999)
            decoy_fields = (
                f'<field id="_f_{rid1}" type="string" value="&#x56;&#x45;&#x52;&#x49;&#x46;&#x49;&#x45;&#x44;" />\n'
                f'<field id="_f_{rid2}" type="boolean" value="true" />\n'
                f'<field id="_f_{rid3}" type="string" value="&#x41;&#x55;&#x54;&#x48;&#x5f;&#x4f;&#x4b;" />\n'
            )
            text = text[:pos] + decoy_fields + text[pos:]

        # Inject deep decoy node forest in <children>
        children_m = re.search(r'<children\b[^>]*>', text, re.IGNORECASE)
        if children_m:
            pos = children_m.end()
            d_id = f"_0xd{random.randint(1000, 9999):x}"
            d_anim = f"_a_{d_id}"
            decoy_nodes = (
                f'<Group id="{d_id}" visible="false" opacity="0" translation="[-9999,-9999]">\n'
                f'<Rectangle width="0" height="0" color="0x00000000" />\n'
                f'<Poster id="_p_{d_id}" width="0" height="0" visible="false" />\n'
                f'<Label id="_l_{d_id}" text="" visible="false" />\n'
                f'<Timer id="_t_{d_id}" repeat="true" duration="9999" />\n'
                f'<Animation id="{d_anim}" duration="0.0" repeat="false">\n'
                f'<FloatFieldInterpolator key="[0.0, 1.0]" keyValue="[0.0, 0.0]" fieldToInterp="{d_id}.opacity" />\n'
                f'</Animation>\n'
                f'</Group>\n'
            )
            text = text[:pos] + decoy_nodes + text[pos:]

    def normalize_tag_whitespace(m):
        return re.sub(r'\s+', ' ', m.group(0))

    text = re.sub(r'<[^>]+>', normalize_tag_whitespace, text)

    def tag_replacer(match):
        tag_str = match.group(0)
        tag_name_m = re.match(r'<([a-zA-Z0-9_]+)', tag_str)
        if not tag_name_m:
            return tag_str
        tag_name = tag_name_m.group(1).lower()

        if tag_name in ('component', 'field'):
            return tag_str

        def attr_replacer(attr_m):
            attr_name = attr_m.group(1)
            quote = attr_m.group(2)
            attr_val = attr_m.group(3)
            if attr_name.lower() in ('id', 'type', 'uri', 'name', 'extends'):
                return f'{attr_name}={quote}{attr_val}{quote}'
            enc_val = encode_xml_attribute_value(attr_val)
            return f'{attr_name}={quote}{enc_val}{quote}'

        return re.sub(r'([a-zA-Z0-9_:]+)=("|\')(.*?)\2', attr_replacer, tag_str)

    tag_re = re.compile(r'<[a-zA-Z0-9_]+(?:\s+[^"\'=<>]+(?:=(?:"[^"]*"|\'[^\']*\'))?)*\s*/?>')
    if level in ('high', 'ultra'):
        text = tag_re.sub(tag_replacer, text)

    text = re.sub(r'>\s+<', '><', text)
    safe_formatted = re.sub(r'(<[^>]+>)', r'\n\1\n', text)
    clean_lines = [l.strip() for l in safe_formatted.splitlines() if l.strip()]
    xml_body = '\n'.join(clean_lines)

    for idx, slot_code in enumerate(script_slots):
        slot_token = f"__ROKU_SCRIPT_SLOT_{idx}__"
        xml_body = xml_body.replace(slot_token, slot_code)

    return header + xml_body, inline_strings_count, inline_vars_count

def verify_brightscript_syntax(content, file_name):
    """Rigorous pre-flight compiler syntax check on generated BrightScript."""
    toks = BrsTokenizer(content).tokenize()
    clean = [(t, i) for i, t in enumerate(toks) if t[0] not in ('COMMENT', 'WS')]

    brace_depth = 0
    bracket_depth = 0
    paren_depth = 0

    for ci, (tok, orig_idx) in enumerate(clean):
        ttype, tval = tok
        prev = clean[ci - 1][0] if ci > 0 else None
        next_t = clean[ci + 1][0] if ci + 1 < len(clean) else None

        if tval == '{':
            brace_depth += 1
            if next_t and next_t[1] == ':':
                raise SyntaxError(f"[{file_name}] Invalid syntax: colon immediately after '{{'")
        elif tval == '}':
            brace_depth -= 1
            if prev and prev[1] == ':':
                raise SyntaxError(f"[{file_name}] Invalid syntax: colon immediately before '}}'")
            if brace_depth < 0:
                raise SyntaxError(f"[{file_name}] Unmatched '}}'")
        elif tval == '[':
            bracket_depth += 1
        elif tval == ']':
            bracket_depth -= 1
            if bracket_depth < 0:
                raise SyntaxError(f"[{file_name}] Unmatched ']'")
        elif tval == '(':
            paren_depth += 1
        elif tval == ')':
            paren_depth -= 1
            if paren_depth < 0:
                raise SyntaxError(f"[{file_name}] Unmatched ')'")

        if tval == ':' and brace_depth > bracket_depth:
            if prev and prev[0] not in ('IDENT', 'STRING'):
                raise SyntaxError(f"[{file_name}] Compile Error &h02: Non-literal AA key preceding colon: {prev}")

        if ttype == 'IDENT' and tval.lower() == 'xor':
            raise SyntaxError(f"[{file_name}] Compile Error &h02: Illegal 'xor' keyword used in BrightScript expression")

        if ttype == 'IDENT' and tval.lower() in ('while', 'sub', 'function', 'for', 'if', 'try', 'catch'):
            if bracket_depth > 0 or brace_depth > 0:
                raise SyntaxError(f"[{file_name}] Compile Error &h02: Statement keyword '{tval}' illegal inside bracket/brace depth (bracket={bracket_depth}, brace={brace_depth})")

    if brace_depth != 0:
        raise SyntaxError(f"[{file_name}] Unbalanced braces: {brace_depth}")
    if bracket_depth != 0:
        raise SyntaxError(f"[{file_name}] Unbalanced brackets: {bracket_depth}")
    if paren_depth != 0:
        raise SyntaxError(f"[{file_name}] Unbalanced parens: {paren_depth}")

    lines = content.splitlines()
    if_count = 0
    fn_count = 0
    for li, line in enumerate(lines, 1):
        s = line.strip()
        if s.startswith("'"): continue
        low = s.lower()
        if (low.startswith('function ') or low.startswith('sub ')) and not low.startswith('end'):
            fn_count += 1
        elif low.startswith('end function') or low == 'endfunction' or low.startswith('end sub') or low == 'endsub':
            fn_count -= 1
            if fn_count < 0:
                raise SyntaxError(f"[{file_name}] Line {li}: Extra end function/sub without matching opening")
        if (low.startswith('if ') or low.startswith('if(')) and not (low.startswith('elseif') or low.startswith('else if')):
            if 'then' in low:
                idx = low.rfind('then')
                after = s[idx+4:].strip()
                if after == '' or after.startswith("'"):
                    if_count += 1
        elif low.startswith('end if') or low == 'endif':
            if_count -= 1
            if if_count < 0:
                raise SyntaxError(f"[{file_name}] Line {li}: Extra end if without matching opening")
    if fn_count != 0:
        raise SyntaxError(f"[{file_name}] Unclosed function/sub blocks (count={fn_count})")
    if if_count != 0:
        raise SyntaxError(f"[{file_name}] Unclosed if blocks (count={if_count})")

def verify_xml_syntax(content, file_name):
    """Verifies that the obfuscated XML is strictly well-formed and valid."""
    try:
        ET.fromstring(content)
    except Exception as e:
        raise SyntaxError(f"[{file_name}] XML Syntax Error: {e}")

def build_obfuscated_package(src_dir, out_zip, staging_dir=None, keep_staging=False, level='ultra'):
    """Full packaging pipeline: clones source, obfuscates in staging, and creates release zip."""
    start_time = datetime.now()
    src_dir = os.path.abspath(src_dir)
    out_zip = os.path.abspath(out_zip)

    if not os.path.isdir(src_dir):
        raise FileNotFoundError(f"Source directory '{src_dir}' does not exist.")

    auto_staging = False
    if staging_dir is None:
        staging_dir = os.path.join(os.path.dirname(src_dir), "build_obfuscated_staging")
        auto_staging = True
    staging_dir = os.path.abspath(staging_dir)

    print("=" * 70)
    print("   RAINDOTCITY // EXTRA-ULTRA BRIGHTSCRIPT & XML OBFUSCATION ENGINE")
    print("=" * 70)
    print(f"[*] Source Code Directory   : {src_dir}")
    print(f"[*] Target Release Package  : {out_zip}")
    print(f"[*] Obfuscation Level       : {level.upper()} (Anti-AI & Anti-Decompiler)")
    print(f"[*] Staging Directory       : {staging_dir}")
    print("-" * 70)

    reserved_names = collect_global_function_names(src_dir)
    print(f"[*] Cataloged {len(reserved_names)} top-level sub/function signatures for linkage safety.")

    if os.path.exists(staging_dir):
        shutil.rmtree(staging_dir)
    print("[1/5] Cloning source project to isolated staging workspace...")
    shutil.copytree(src_dir, staging_dir)

    brs_count = 0
    xml_count = 0
    total_strings = 0
    total_vars = 0
    total_comments = 0

    print("[2/5] Applying Extra-Ultra Obfuscation to BrightScript (.brs) files...")
    for root, _, files in os.walk(staging_dir):
        for f in files:
            if f.lower().endswith('.brs'):
                file_path = os.path.join(root, f)
                rel_path = os.path.relpath(file_path, staging_dir)
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as fp:
                    code = fp.read()
                file_level = 'high' if (len(code) > 80000 or 'vidsrccatalog' in rel_path.lower()) else level
                obf_code, s_cnt, c_cnt, v_cnt = obfuscate_brs(code, rel_path, reserved_names, level=file_level)
                verify_brightscript_syntax(obf_code, rel_path)
                with open(file_path, 'w', encoding='utf-8', newline='\n') as fp:
                    fp.write(obf_code)
                brs_count += 1
                total_strings += s_cnt
                total_comments += c_cnt
                total_vars += v_cnt

    print(f"      -> {brs_count} BrightScript files protected with 7-Family Polymorphic Ciphers & Multi-Stage Layering.")
    print(f"      -> {total_strings:,} string literals encrypted (Single-Pass & Multi-Stage Cascaded Ciphers).")
    print(f"      -> {total_vars:,} local variables mangled to variable-length (32-44 char) homoglyphs.")
    print(f"      -> Full Boolean & Integer Constant Blinding (zero plaintext literals in code).")
    print(f"      -> 16 Deep Number-Theoretic Invariant Theorems & 16 Realistic AI Honey-Traps injected.")
    print(f"      -> 100% Roku compiler &h02 pre-flight verification passed across all modules.")
    print(f"      -> {total_comments:,} developer comments completely stripped.")

    print("[3/5] Applying Advanced Obfuscation to SceneGraph XML (.xml) files...")
    xml_inline_strings = 0
    xml_inline_vars = 0
    for root, _, files in os.walk(staging_dir):
        for f in files:
            if f.lower().endswith('.xml'):
                file_path = os.path.join(root, f)
                rel_path = os.path.relpath(file_path, staging_dir)
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as fp:
                    xml_code = fp.read()
                obf_xml, is_cnt, iv_cnt = obfuscate_xml(xml_code, rel_path, reserved_names, level=level)
                verify_xml_syntax(obf_xml, rel_path)
                with open(file_path, 'w', encoding='utf-8', newline='\n') as fp:
                    fp.write(obf_xml)
                xml_count += 1
                xml_inline_strings += is_cnt
                xml_inline_vars += iv_cnt

    print(f"      -> {xml_count} XML components obfuscated (Polymorphic NCR entities + Decoy UI Node Forest).")
    print(f"      -> {xml_inline_strings} inline BrightScript strings encrypted & {xml_inline_vars} inline vars mangled.")
    print(f"      -> 100% of XML comments & layout structures completely obscured.")

    total_strings += xml_inline_strings
    total_vars += xml_inline_vars

    print("[4/5] Preserving application manifest byte-for-byte...")
    src_manifest = os.path.join(src_dir, 'manifest')
    stg_manifest = os.path.join(staging_dir, 'manifest')
    if os.path.exists(src_manifest):
        shutil.copy2(src_manifest, stg_manifest)
        with open(stg_manifest, 'rb') as fp:
            manifest_hash = hashlib.md5(fp.read()).hexdigest()
        print(f"      -> Manifest MD5: {manifest_hash} (verified match for KeyAuth security).")

    print("[5/5] Compressing into release package...")
    if os.path.exists(out_zip):
        os.remove(out_zip)
    with zipfile.ZipFile(out_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for root, _, files in os.walk(staging_dir):
            for f in files:
                abs_path = os.path.join(root, f)
                arc_name = os.path.relpath(abs_path, staging_dir)
                zf.write(abs_path, arc_name)

    zip_size = os.path.getsize(out_zip)
    if auto_staging and not keep_staging:
        shutil.rmtree(staging_dir, ignore_errors=True)

    duration = (datetime.now() - start_time).total_seconds()
    print("=" * 70)
    print("   [+] EXTRA-ULTRA OBFUSCATION COMPLETED SUCCESSFULLY!")
    print("=" * 70)
    print(f"   Target Zip File        : {out_zip}")
    print(f"   Package File Size      : {zip_size:,} bytes ({zip_size / 1024:.1f} KB)")
    print(f"   Total .brs Files       : {brs_count} (Polymorphic Multi-Cipher & Zero-Arg Hardened)")
    print(f"   Total .xml Files       : {xml_count} (Polymorphic Mixed NCR & Node Forest Obfuscated)")
    print(f"   Encrypted Strings      : {total_strings:,}")
    print(f"   Homoglyphic Variables  : {total_vars:,}")
    print(f"   Stripped Comments      : {total_comments:,}")
    print(f"   Pre-flight Validation  : 100% PASSED (0 compile error &h02 risks)")
    print(f"   Time Elapsed           : {duration:.2f} seconds")
    print(f"   Source Code Status     : UNTOUCHED & PRISTINE in '{src_dir}'")
    print("=" * 70)

# ==============================================================================
# SECTION 2: MSVC COMPILATION & VMPROTECT ULTIMATE PIPELINE
# ==============================================================================

def find_vcvarsall():
    """Locates Visual Studio vcvarsall.bat using vswhere or fallback paths."""
    vswhere_path = os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe")
    if os.path.exists(vswhere_path):
        try:
            cmd = [
                vswhere_path,
                "-latest",
                "-products", "*",
                "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                "-property", "installationPath"
            ]
            install_path = subprocess.check_output(cmd, text=True, errors="ignore").strip()
            if install_path:
                vcvars = os.path.join(install_path, "VC", "Auxiliary", "Build", "vcvarsall.bat")
                if os.path.exists(vcvars):
                    return vcvars
        except Exception:
            pass

    candidates = [
        r"C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvarsall.bat",
        r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat",
        r"C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat",
        r"C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat",
        r"C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvarsall.bat",
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return None

def find_vmprotect_con(base_dir):
    """Locates VMProtectCon.exe within the workspace."""
    candidates = [
        os.path.join(base_dir, "vmp", "bin", "64", "Ultimate", "VMProtectCon.exe"),
        os.path.join(base_dir, "vmp", "bin", "32", "Ultimate", "VMProtectCon.exe"),
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return None

def build_and_protect(run_after=False):
    """Compiles C++ downloader and executes VMProtect Ultimate CLI."""
    start_time = datetime.now()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base_dir)

    print(f"\n{BOLD}{CYAN}======================================================================{RESET}")
    print(f"{BOLD}{CYAN}   RAINDOTCITY // AUTOMATED VMPROTECT ULTIMATE PIPELINE               {RESET}")
    print(f"{BOLD}{CYAN}======================================================================{RESET}\n")

    cpp_source = os.path.join(base_dir, "rdc_downloader.cpp")
    vmp_project = os.path.join(base_dir, "RDC_Downloader.vmp")
    raw_exe = os.path.join(base_dir, "RDC_Downloader_raw.exe")
    raw_map = os.path.join(base_dir, "RDC_Downloader_raw.map")
    final_exe = os.path.join(base_dir, "RDC_Downloader.exe")

    if not os.path.exists(cpp_source):
        log_error(f"Source file not found: {cpp_source}")
        return False

    if not os.path.exists(vmp_project):
        log_error(f"VMProtect project file not found: {vmp_project}")
        return False

    vcvarsall = find_vcvarsall()
    if not vcvarsall:
        log_error("Visual Studio C++ compiler environment (vcvarsall.bat) could not be located.")
        return False
    log_info(f"Using MSVC Toolchain: {vcvarsall}")

    vmp_con = find_vmprotect_con(base_dir)
    if not vmp_con:
        log_error("VMProtectCon.exe could not be found under 'vmp/bin/'.")
        return False
    log_info(f"Using VMProtect Engine: {vmp_con}")

    log_info("Compiling C++ source code with MSVC x64 (/O2 /MT /std:c++17)...")
    compile_cmd = (
        f'call "{vcvarsall}" x64 && '
        f'cl.exe /nologo /O2 /MT /EHsc /std:c++17 /utf-8 /DUNICODE /D_UNICODE '
        f'"{cpp_source}" /Fe:"{raw_exe}" '
        f'/link wininet.lib user32.lib kernel32.lib ws2_32.lib iphlpapi.lib '
        f'/LIBPATH:"{os.path.join(base_dir, "vmp", "bin", "64", "Release")}" '
        f'/MAP:"{raw_map}"'
    )

    p_compile = subprocess.run(compile_cmd, shell=True, capture_output=True, text=True)
    if p_compile.returncode != 0 or not os.path.exists(raw_exe):
        log_error("MSVC Compilation failed:")
        print(p_compile.stdout)
        print(p_compile.stderr)
        return False

    raw_size = os.path.getsize(raw_exe)
    log_success(f"Raw binary generated successfully: {raw_exe} ({raw_size:,} bytes)")

    log_info(f"Invoking VMProtect Ultimate on '{vmp_project}'...")
    vmp_cmd = f'"{vmp_con}" "{vmp_project}"'
    p_vmp = subprocess.run(vmp_cmd, shell=True, capture_output=True, text=True)

    if p_vmp.returncode != 0 or not os.path.exists(final_exe):
        log_error("VMProtect protection failed:")
        print(p_vmp.stdout)
        print(p_vmp.stderr)
        return False

    final_size = os.path.getsize(final_exe)
    print(p_vmp.stdout.strip())
    log_success(f"Protected binary compiled: {final_exe} ({final_size:,} bytes / {final_size / 1024 / 1024:.2f} MB)")

    log_info("Cleaning up intermediate build artifacts...")
    cleanup_files = [raw_exe, raw_map, os.path.join(base_dir, "rdc_downloader.obj")]
    for f in cleanup_files:
        if os.path.exists(f):
            try:
                os.remove(f)
            except OSError:
                pass

    elapsed = (datetime.now() - start_time).total_seconds()
    print(f"\n{BOLD}{GREEN}======================================================================{RESET}")
    print(f"{BOLD}{GREEN}   [+] VMPROTECT ULTIMATE BUILD COMPLETED IN {elapsed:.2f}s!              {RESET}")
    print(f"{BOLD}{GREEN}   Output: {final_exe}                                 {RESET}")
    print(f"{BOLD}{GREEN}======================================================================{RESET}\n")

    if run_after:
        log_info("Launching protected binary for execution...")
        subprocess.run([final_exe])

    return True

# ==============================================================================
# SECTION 3: UNIFIED ORCHESTRATION PIPELINE
# ==============================================================================

def run_master_pipeline(roku_only=False, vmp_only=False, run_after=False):
    master_start = datetime.now()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base_dir)

    src_channel = os.path.join(base_dir, "VidSrc ROKU")
    out_zip = os.path.join(base_dir, "RainDotCity_Roku.zip")
    final_exe = os.path.join(base_dir, "RDC_Downloader.exe")

    log_header("RAINDOTCITY // MASTER OBFUSCATION & PROTECTION PIPELINE")

    if not vmp_only:
        log_step("PHASE 1/2", "Obfuscating Roku OS Channel (BrightScript + SceneGraph XML)...")
        if not os.path.isdir(src_channel):
            log_error(f"Source channel directory not found: {src_channel}")
            return False
        try:
            build_obfuscated_package(
                src_dir=src_channel,
                out_zip=out_zip,
                staging_dir=None,
                keep_staging=False,
                level="ultra"
            )
            if not os.path.exists(out_zip):
                log_error("Phase 1 failed: RainDotCity_Roku.zip was not generated.")
                return False
            log_success(f"Phase 1 Complete: '{out_zip}' ({os.path.getsize(out_zip):,} bytes)\n")
        except Exception as ex:
            log_error(f"Phase 1 Error during Roku channel obfuscation: {ex}")
            return False

    if not roku_only:
        log_step("PHASE 2/2", "Compiling & Protecting Native Downloader with VMProtect Ultimate...")
        try:
            success = build_and_protect(run_after=run_after)
            if not success:
                log_error("Phase 2 failed during compilation or VMProtect virtualization.")
                return False
        except Exception as ex:
            log_error(f"Phase 2 Error during native protection: {ex}")
            return False

    total_duration = (datetime.now() - master_start).total_seconds()
    print(f"\n{BOLD}{GREEN}{'=' * 75}{RESET}")
    print(f"{BOLD}{GREEN}   [+] ALL OBFUSCATORS & PROTECTORS COMPLETED IN {total_duration:.2f}s!{RESET}")
    print(f"{BOLD}{GREEN}{'=' * 75}{RESET}")
    if not vmp_only and os.path.exists(out_zip):
        print(f"   * Roku Release Package   : {out_zip} ({os.path.getsize(out_zip):,} bytes)")
    if not roku_only and os.path.exists(final_exe):
        print(f"   * Hardened Native Binary : {final_exe} ({os.path.getsize(final_exe):,} bytes)")
    print(f"   * Original Source Status : Pristine & untouched in '{src_channel}'")
    print(f"{BOLD}{GREEN}{'=' * 75}{RESET}\n")

    return True

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Master All-In-One Obfuscation & Protection Suite.")
    parser.add_argument("--roku-only", action="store_true", help="Only obfuscate and package the Roku channel")
    parser.add_argument("--vmp-only", action="store_true", help="Only compile and VMProtect the C++ downloader")
    parser.add_argument("--run", action="store_true", help="Launch the protected downloader after building")
    args = parser.parse_args()

    success = run_master_pipeline(roku_only=args.roku_only, vmp_only=args.vmp_only, run_after=args.run)
    sys.exit(0 if success else 1)
