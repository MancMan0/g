sub init()
m.btnLiveTv = m.top.findNode(_l1d_b81841("d8cdeacbe9dbebbfe4", 145, 229))
m.btnVod = m.top.findNode(_l1d_b81841("f7ecf9140008", 56, 157))
m.borderLiveTv = m.top.findNode(_l1d_b81841("e5f5fbf4f80425051107391a", 98, 229))
m.borderVod = m.top.findNode(_l1d_b81841("0111f70c1000e7231b", 208, 79))
m.stripLiveTv = m.top.findNode(_l1d_b81841("a5abaca4b08fadbfafa3c8", 65, 115))
m.stripVod = m.top.findNode(_l1d_b81841("28262f3733143e48", 157, 58))
m.btnLiveTv.observeField(_l1d_b81841("c8b6b8bbc9cbabd8d2dee7d3e7e9", 220, 10), _l1d_b81841("03052a12f60c1eff2718221e23132729", 182, 42))
m.btnVod.observeField(_l1d_b81841("f9eff1f402041c110b17180c2022", 56, 159), _l1d_b81841("6466316d65376c767273677b7d", 208, 165))
m.btnLiveTv.observeField(_l1d_b81841("7f8b8a7b809193", 182, 175), _l1d_b81841("797d5c8986678d97877ba0739d9ca9b2", 133, 143))
m.btnVod.observeField(_l1d_b81841("e1ebe2dbd8f1f5", 115, 204), _l1d_b81841("bbbd94a9c691cdc5aad6cdc2c3", 80, 124))
m.top.observeField(_l1d_b81841("8a9493a4a99a9e", 7, 41), _l1d_b81841("acaec9b7beb3e5c1d0bdc6", 60, 89))
end sub
sub onViewFocus()
if m.top.hasFocus() then
if m.btnLiveTv <> invalid then
m.btnLiveTv.setFocus(true)
end if
end if
end sub
sub onBtnLiveTvFocus()
if m.btnLiveTv.hasFocus() then
m.borderLiveTv.color = _l1d_b81841("e530ebee3ff145484b4e", 148, 65)
m.stripLiveTv.color = _l1d_b81841("38f33e41fa4a00030609", 73, 191)
m.borderVod.color = _l1d_b81841("32fd0e113e414c474c4f", 112, 242)
m.stripVod.color = _l1d_b81841("db163336e7eae5f0f5f8", 155, 48)
end if
end sub
sub onBtnVodFocus()
if m.btnVod.hasFocus() then
m.borderVod.color = _l1d_b81841("bb06171ac7cad5d0292c", 17, 154)
m.stripVod.color = _l1d_b81841("96515255a2a5a0ab6467", 200, 158)
m.borderLiveTv.color = _l1d_b81841("17621d20752b7b7e2d30", 18, 245)
m.stripLiveTv.color = _l1d_b81841("82cd888bc094c6c99c9f", 131, 207)
end if
end sub
sub onLiveTvSelected()
if ((23856 - 3408 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.modeSelected = _l1d_b81841("161412261a1b", 187, 63)
end sub
sub onVodSelected()
m.top.modeSelected = _l1d_b81841("c0bab4", 69, 141)
end sub
function onKeyEvent(_lI1lIl1 as String, _llIlIl1 as Boolean) as Boolean
if not _llIlIl1 then return false
if _lI1lIl1 = _l1d_b81841("ece8ecdd", 20, 116) then
if m.btnVod <> invalid and m.btnVod.hasFocus() then
m.btnLiveTv.setFocus(true)
return true
end if
else if _lI1lIl1 = _l1d_b81841("f604090900", 222, 74) then
if m.btnLiveTv <> invalid and m.btnLiveTv.hasFocus() then
m.btnVod.setFocus(true)
return true
end if
else if _lI1lIl1 = _l1d_b81841("1b1d221d", 216, 97) then
m.top.backRequested = true
return true
end if
return false
end function
function _l1d_b81841(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function