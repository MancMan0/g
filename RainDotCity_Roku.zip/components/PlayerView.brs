sub init()
_ll1I1II11IIIl1II111llI1Il1111IIlII1II11l1ll = ((Rnd(0) * 0) + 3)
if (((_ll1I1II11IIIl1II111llI1Il1111IIlII1II11l1ll * _ll1I1II11IIIl1II111llI1Il1111IIlII1II11l1ll * _ll1I1II11IIIl1II111llI1Il1111IIlII1II11l1ll * _ll1I1II11IIIl1II111llI1Il1111IIlII1II11l1ll * _ll1I1II11IIIl1II111llI1Il1111IIlII1II11l1ll - _ll1I1II11IIIl1II111llI1Il1111IIlII1II11l1ll) mod 5) <> 0) then
_llIl1IIIll11l1l111I1I1Il11l11IlIlII = CreateObject("roDateTime")
_llII11IIIIIIlIl1111Illlll1ll1111IlI = _llIl1IIIll11l1l111I1I1Il11l11IlIlII.AsSeconds() + 86400
_llII1lIIIlII111IIllIIII11llll1lIIIll1I1 = Stri(_llII11IIIIIIlIl1111Illlll1ll1111IlI)
end if
m.videoPlayer = m.top.findNode(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1lII1IlIl11111III11l11I1lI1111111(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("52f667c521f5722637bb675aa237f1a4353465c4743844db03b8b358f7357158c175b39b20f847a6817566c577f50726b7b666c4f6b571da35f5b184f7b4f29ac3f46758f576442637383398f4b904d935f5e444a3b6c72636bbb347f5b705e43474e74622b747")))))
m.statusOverlay = m.top.findNode(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("5a1041431c4f1926272a2f2c30626a383b3f3c447d4b514f4f5689589161656aa06aa0767c7d798187bc888d90c8c7cb9b9aa3dadda6b1acafe9ecf1f1f8c5fb00030003dc10d9dbe719ef1ef0ed27fbfb31fc07360511460f48494e2525252d605e606a3c70396f474548508255875e5b6263679699716f6f75acabb183858dc08ac0989c9f99a2a7a5a8afb0b7eab9bbf4c3c9fdccd1cccf0c0cdb11e4e6e3201df4f0fcf9f935073c084110144a191e1923545d5d31622f326c727171467a805280845c8a5960676c689b7072aa777bad8383bd8c92c28f99c99bd1a2a5ace0afe0b7b9bff3c6c7ccc8d202d307"))))))
m.statusTitle = m.top.findNode(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("2fcdd1d5acd8e2b2e4eae7edfcf6fafbfad00309d908110f12e41cec2b2e2a2b2c313541430f421243144c4d5b56582a5b3065"))))
m.statusText = m.top.findNode(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1lII1IlIl11111III11l11I1lI1111111(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("67f4160b5325fa3227dceef63b4df5272f84364ea3452a3f647c5186788da55a6cc4a6ee73d89a82c78c0116dbad95ca2fe1f6fb4328dd42173c5123180065170c14593e13252d3f54792e667b7d9597cfd496abc3659da2d79c71b6aba0d2da9fd1f91e3305ed42142c4156fbf055e7ef14493b03350a3f444911165880253a3fc4866ed3557aa2c76981a69bb0c2ca8fc1e91e2308bd12e4bcbec60b00c507ec11263ef3350d2f475c21665b10622aaf3469be43b86a6297595e7398d0e5"))))))
m.cancelBtn = m.top.findNode(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("2bcec97cefca8d0963be"))
m.menuOverlay = m.top.findNode(_ll1lII1IlIl11111III11l11I1lI1111111(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("36f0d5dafad419ee0ee8d83de7fc8151eb00450a0f5f296923736d32922c51363640b0957f9f59ce6ed81da297ac81f696c0b0ca9ad4b4feb308ed12671c012626f0f53a3a04693e631858c2371c51266be0953a7fb4794eaec89d02b7dc6ce61b20d02adaf499")))))
m.menuTitle = m.top.findNode(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("729cf87c0c5cec3d6edf3a51ce82baffd863ba7e1a")))
m.menuTime = m.top.findNode(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1lII1IlIl11111III11l11I1lI1111111("5415838298793907ddf4b9b1206efeb4cb4258508f05f4431370a8e785a33c62092fa57c8261d3c8c7af5463cae190b0fd666593b1b98e4405f38a9faf3fbd2533527f8ea416cc2199a96effeccdba")))))
m.menuBtnBar = m.top.findNode(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("663864677d3f403b06335543045f5c34072f082bf221b8")))
m.fitModes = [
{ label: _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("51b1b3a91d2277e003762c55f90f04095d12973a6ee2e7c0"),  sx: 1.00, sy: 1.00 },
{ label: _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1lII1IlIl11111III11l11I1lI1111111("5edaacb4bda70ef263837f278fd1f93aa23e24aed843d5fc04e136b0b8c2373c47f11042027dbcce09727b823c3e06915b65359f868eb15b9a2afe66c628baeff4a7e1d118c50c3744860bdbe395b4ffcb73306d4ef40721ea5a4c97111ec192ba456c161f49b2"))), sx: 0.95, sy: 0.95 },
{ label: _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IlIlIllllII1lIlll1IIlllI("433d7764f71a5bc2d0c48da6678a8b1120d72e1e872ae2383a573ff66c3a52210a3d77c40d20182190a7adce878928bb3a0def7424")), sx: 0.90, sy: 0.90 },
{ label: _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("75d5a7aaade7aeb7f0f3e9c2c1c9cacdcb0205d60e0e0f16181bf02122282b2cfb3535350d1149104a48495154535b2a2d346d3b3d406f478047505382575a5a5b5f9597676c6e7579aca9b2b288b5be8bbecdc5cecb9ed2d8e3d9dde2efebecbdc3f5cacd06ce07d9dce0"))), sx: 0.85, sy: 0.85 },
{ label: _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("492b3e59746f8a5d809b86b122afcabdc0d3fef17aff7a15a63b2e51446762d5e8eb1491c41f2235e0d394e9aab532cb28e14649ea0dda231e218e09c41fba6366531661927fa0c328d946c1d2ed920398414c2fb46d78631079068f0ca51abbbeb97ecf74e5e2fb88393cd9ec4d4205e01b6e9734a5d86560d97eefe205f2bd00314cd1d4e70afd9e136e314c474a5d787b5e998c9f009db8dbe6f13407daf568132631343fa255fe73ec91ac9720bd46abdee95ad798f5200b2629343f3a")))),   sx: 0.80, sy: 0.80 }
]
_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = U_PrefDefault(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("77667a34363e5d371d654b184607486b1772462dec21f62a9c2e9a36ca48c357ca6d9b3385627a37603f31546a1a3b3a6774657f5b77167eec24bf"))), ((((((18 * 7) + ((45 * 13) - (45 * 13))) + 0) - (18 * 4)) - (18 * 3))))
if _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll < ((((((47 * 5) + (0 * 3)) - (47 * 5)) \ 3))) or _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll >= m.fitModes.Count() then _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = ((((((43 * 5) + (0 * 3)) - (43 * 5)) \ 3)))
m.fitMode = _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll
applyFitMode(m.fitMode)
m.cancelBtn.observeField(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("414e82adbdec630fd30f9fee926ede4fbd4d42ed51db1ccc3c8f1faf3d2cdfcd3e8c9facbf2f5f4fd14f9ded90d8a33bbf5b43ac526c1f393d9a1c7a3e1a1efa3d0d9df8bd9a637bd3599fbb90acdc7bbdd840ec906fa24c3edb1f7ad2eedff93ccf9faf7eee5fcfd10e5d6f92eddc8fbf4c43f850ac1fcc3d4e01fb3ceddd")))), _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("5334f55afbde9b96b912c7c25336e35439e41f")))
m.menuBtnBar.observeField(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1lII1IlIl11111III11l11I1lI1111111("420a0d1ebc16f8337525bf36093bcda5a776e9b8b095ad62f6c8ee1174cf5e3c0806b5cd823f3e805bf2954fd950d642d2ed6f499608daac873ec476609934"))), _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("3555bac56631fe7f8227b01dae633e61ea5f08fb0609342f2ab7da6b7e1344119a95d0b3cef15e9fe267729d0e414ca96adfe2d5761b4ca7b2bdc845ded94edf126f7a333e195c576ae770"))))
m.videoPlayer.observeField(_ll1lII1IlIl11111III11l11I1lI1111111(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("22600d5298c078925be0f8510d41b89019213950cf43bb939ae33bd2cd01fb52aee379129a5d79105a5dfa910e43ba11181c383c8ddd2c")))), _lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("5b9c8f82b5b0b3d667d4b702e510fb068f1c075a6548336e497405a24bc8cbdea1f4f702fd20b12e51d24f425df65b86593205b2cd9069e6b18af7fa25b6892e2114dd6a2d40e196a164c7c28de0a3c6e9ec171a83182b365144bd82d3989376899c15aa8dc8cbee7fecd7029310d14659ea7f5ae3ee937eb94255da9546e3e6e972ad2a8bc60356b7eadd5a9d58b386371a55b2e546818c6f72df98cb9e4b1e71cafde01b58936e1f4a9738fd56fbc69f7aef904d081bf4f7d267a29dfe11ae812ac7c2fdb8fb167fbac5425db67346df020d9aad2e41ce2f42ef02056e71"))))))
m.videoPlayer.observeField(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1lII1IlIl11111III11l11I1lI1111111("3de0c9ca14c4463e5529905bec3e14d8473b9356d675017252b585de0886ba2cb3763f8872e0acf6438031fa63b4642de0a912b23bfea7a0d13af30d56878040a2f2dc7747018ac293441ff749e26834deecd7f92a6a45fb96f0c00a4ce445d798e1caf3b6c5e021872b657d97b5b642245c562f70ffa36b05162e08aad8c44ee6f869d29be5a510ed81186154d6accedff2bcdc5e18898adaeb74fef09a9994cc667e59e16b242bcbb8b911ebcb8afd783171faa3152faf30da6263ee3e182911ac9d1dd048e95a21b55c9fa8a9d06403965f49921905deb7b051f2838c66fd00fab2dc25cfc7d90febbac6f649ce91ac9ade4fe7ba63149d46bfff22e33ba555bea8a2148c2d475fda9012750d14c74729931dd67f49a9fb84859f08a001b244adf61f7261ac5c43d73169caf37296e0f8122a3c056f9db80af3c42dd680")))))), _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("46394333096962317b3c2e16770b7c36242d7623897cc027fc2faf34f04baa07a638ae38b43917300d3e5107534f596b0873557b64752c7c8477d4388857d14edd648f6cc262aa6ae162b198b980b3e1e7aeb4a5ccf18da6bfa8ebb6e71cba58ec32be6ef4628e3992619509c9109be293a897f5a8fde3f49afe9cba9e869c9ec831996dd237bb3ca063f149a951a03efd77f1730c2a167d2626256f2912755b2e307f616c61cf68d3608f06841d8d37d229d670ef72ad7d0723033a0a520947546a5d6d1236243f376034cc6bd238ea6ca13bf549fc05a76baf6ce0371b3a586b3a31632f39556e4535450c4d1543e918f611f32eff61a34ef91ae7158d4ecc1967486d55636c6c25327d14755a2d33707a25768a2c9072f92eae60a51da7"))))))
_ll1Il1lIIIlI1I1l1lIllI11I1IIl1Il1lI1l1II1ll = ((Rnd(0) * 0) + 23)
if (((_ll1Il1lIIIlI1I1l1lIllI11I1IIl1Il1lI1l1II1ll * _ll1Il1lIIIlI1I1l1lIllI11I1IIl1Il1lI1l1II1ll * _ll1Il1lIIIlI1I1l1lIllI11I1IIl1Il1lI1l1II1ll - _ll1Il1lIIIlI1I1l1lIllI11I1IIl1Il1lI1l1II1ll) mod 6) <> 0) then
_llII1l11I1I111Il1Il11I1II11l11lI1I1IIIl = CreateObject("roEVPDigest")
_llII1l11I1I111Il1Il11I1II11l11lI1I1IIIl.Setup("sha512")
_ll1lllIlIIllllI1lIII11l11l1ll11 = _llII1l11I1I111Il1Il11I1II11l11lI1I1IIIl.Process("4daa39f14784")
end if
end sub
sub applyFitMode(_llll1I11llIlll11lII11l11111IIIl as Integer)
_llI11lIl111IllIl1I1lIlI111l1llI1lI1 = ((Rnd(0) * 0) + 13)
if (((_llI11lIl111IllIl1I1lIlI111l1llI1lI1 * (_llI11lIl111IllIl1I1lIlI111l1llI1lI1 + 1)) mod 2) <> 0) then
_llIlIl1ll1Il11II1IlIII111IlI11I111I = CreateObject("roEVPDigest")
_llIlIl1ll1Il11II1IlIII111IlI11I111I.Setup("sha256")
_ll11IlIlI1llIII1I1Il11I1llI1lllIIII = _llIlIl1ll1Il11II1IlIII111IlI11I111I.Process("5349ec628d86")
end if
if m.fitModes = invalid or m.fitModes.Count() = ((((((15 * 5) + (0 * 3)) - (15 * 5)) \ 3))) then return
if _llll1I11llIlll11lII11l11111IIIl < ((((((18 * 5) + (0 * 3)) - (18 * 5)) \ 3))) or _llll1I11llIlll11lII11l11111IIIl >= m.fitModes.Count() then _llll1I11llIlll11lII11l11111IIIl = ((((((48 * 64) + 0) mod 64) + ((255 and 255) - 255))))
m.fitMode = _llll1I11llIlll11lII11l11111IIIl
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m.fitModes[_llll1I11llIlll11lII11l11111IIIl]
_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l = 1920
_llI1111ll111IlllIlI111lII1IIlIl = 1080
_llI1lIlIIIlllI1I11Il1I11IlI11Il = Int(_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l * _lllIIlIlII1ll111l1Il11Illlll11l11I1.sx)
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = Int(_llI1111ll111IlllIlI111lII1IIlIl * _lllIIlIlII1ll111l1Il11Illlll11l11I1.sy)
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = Int((_ll1l1I1IlII1l1l1I1I11l1IIl1ll111IIllI1l - _llI1lIlIIIlllI1I11Il1I11IlI11Il) / ((((((46 * 11) + 2) + 42) - ((46 * 11) + 42)))))
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = Int((_llI1111ll111IlllIlI111lII1IIlIl - _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I) / ((((((49 * 7) + ((48 * 13) - (48 * 13))) + 2) - (49 * 4)) - (49 * 3))))
if m.videoPlayer <> invalid then
m.videoPlayer.translation = [_llI111lI11I1l11lI11l1lIlll11111lIIlI1II, _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII]
m.videoPlayer.width = _llI1lIlIIIlllI1I11Il1I11IlI11Il
m.videoPlayer.height = _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I
end if
end sub
sub onFitClicked()
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = (m.fitMode + ((((((12 * 64) + 1) mod 64) + ((255 and 255) - 255))))) Mod m.fitModes.Count()
U_PrefSet(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1lII1IlIl11111III11l11I1lI1111111(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("746cc1b69bc0a5caefc4ec0ed318add2072c21e6ee40053aff54fc4e434830e5e74c01561b03856a42741cae535b5dc23a3f84794e7385dacf87e9ee76f8a0a5d7dfc1e9ebf315adf2070cf1f31b4d05472f54291b13153d5f277981368b20954a3c41a93eb3689daf97595e93686db5e7bfb486fed3d8")))), _lllIIllll1llIIlllIllI11lll1ll1lIl11)
applyFitMode(_lllIIllll1llIIlllIllI11lll1ll1lIl11)
if m.menuOverlay <> invalid and m.menuOverlay.visible then
updateMenuButtons()
refocusMenuButton(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("2836043a4340104c474d51535a232c2a60")))
end if
_lll1IllIIll1l1IIl11lllIlll1l1Il = ((Rnd(0) * 0) + 2)
if ((((_lll1IllIIll1l1IIl11lllIlll1l1Il * 8 + 5) * (_lll1IllIIll1l1IIl11lllIlll1l1Il * 8 + 5)) mod 8) <> 1) then
_llI1lllIl1lllIl1lII1II1l1lIl1ll = CreateObject("roEVPDigest")
_llI1lllIl1lllIl1lII1II1l1lIl1ll.Setup("sha512")
_lllIIIlII11IlI1I1IlIllIl1IIlll1lll11lll = _llI1lllIl1lllIl1lII1II1l1lIl1ll.Process("d5c77aec82e6")
end if
end sub
sub refocusMenuButton(_ll1l1I1II1lll1l11lIIll1IIIII11l as String)
_lllIlI111llllIIIl1Il1II1lIlI1I1Ill1 = ((Rnd(0) * 0) + 15)
if ((((_lllIlI111llllIIIl1Il1II1lIlI1I1Ill1 * 8 + 3) * (_lllIlI111llllIIIl1Il1II1lIlI1I1Ill1 * 8 + 3)) mod 8) <> 1) then
_lllIl1I1Illl1Illl1llIIIII1I11l1 = CreateObject("roRegistrySection", "_sec_9bb3")
_lllIl1I1Illl1Illl1llIIIII1I11l1.Write("token", "9bb361add12b")
_lllIl1I1Illl1Illl1llIIIII1I11l1.Flush()
end if
if m.menuBtnBar = invalid then return
_llllI1lI1ll11l1lI1IlIll1II1lI11 = m.menuBtnBar.buttons
if _llllI1lI1ll11l1lI1IlIll1II1lI11 = invalid then return
for _lll1I11l1Il1llllI11llI111lIlI1l = 0 to _llllI1lI1ll11l1lI1IlIll1II1lI11.Count() - 1
if Left(_llllI1lI1ll11l1lI1IlIll1II1lI11[_lll1I11l1Il1llllI11llI111lIlI1l], Len(_ll1l1I1II1lll1l11lIIll1IIIII11l)) = _ll1l1I1II1lll1l11lIIll1IIIII11l then
if _lll1I11l1Il1llllI11llI111lIlI1l < m.menuBtnBar.getChildCount() then
m.menuBtnBar.getChild(_lll1I11l1Il1llllI11llI111lIlI1l).setFocus((not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))))
end if
exit for
end if
end for
end sub
sub onPlayConfigChange()
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = m.top.playConfig
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid then return
m.top.loadingVideo = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
m.currentConfig = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
m.statusTitle.text = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.title
m.menuTitle.text = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.title
m.statusText.text = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_ll1lII1IlIl11111III11l11I1lI1111111("39ba8a654e1ef7ca81a4ed153f61797a5c0ea6d877ea23c40db7e06a521c45ed79612b1afc6d7e7f5840123c4d5e8e28da021ce62e0f200aa2cc3d18e111f3946f7558189862e48df6fea2d1b49d2f36ef29f29b1d8e165850d35cfedecfafa253149dc699782a2b35bebd7028c2bcd486719f4919d60cc6b83a2293c3d4561058e402d4269d0739b29b9c9d07e7c9e27c642e50c7d1d2")))
m.statusOverlay.visible = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
m.cancelBtn.setFocus((((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49))))
applyFitMode(m.fitMode)
m.resolveTask = CreateObject(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("61c572db8819ec2f1a3d4033d859448782a522b3b6b946c76cfde8fb8829040fd455c2436e698c6f2cffc0b38e4b5edfc2c5e0f398930c17a4bf687bf0496c9f9a17809b3843acc70a8718f39809a647423d407300697ca782ad3ab350c1f4cfda059a1b8819242fc44d025b5e99949f1c4f98b3c64366ff746f00330e9bde67f4ff808386f3a4af3437a0b3c6b9dc076cedaa331619ce2ffc4580f57e232e"))))), _ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_ll1lII1IlIl11111III11l11I1lI1111111(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("7625e236e7870275c6a6d6352569d575c6a4970a92eb1534502494b4918657684548a177e54501b5c4c823f7262b14ea06a4e17592aad777928bd7f69344d4f6066417b7e786d6a845a7d434258457754524978853e815b511e5a1b5d28657ea1365e27626e9c235466654f610c797360425a1c9e42b1474532563f7a72994f50425e20b13a8d42905ca173511e995f6058856b6e6c6d5b450c89434a50496f78748e04810c681f551e7168aa7a8973506a4a1771386166946a7960be72a962910e557b75387c2f445a757c9a5055537910b1408a444c12984e662cae56a94f647e722f552c495aa92e694f7d3c716f5934815485028143444a49477e7c515b446a562b653a8836a92a69649e40655754588568aa66b013411c81437e58455b71324547724698176d08896f7a7c483"))))))
m.resolveTask.imdbId = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.imdbId
m.resolveTask.kind = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.kind
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.season <> invalid then m.resolveTask.season = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.season
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.episode <> invalid then m.resolveTask.episode = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.episode
m.resolveTask.observeField(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("32228b40336e39d26710850e091cc1525dc2cd56130e672447b04d3063cce7"))), _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1lII1IlIl11111III11l11I1lI1111111(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllIIl1IlIlIllllII1lIlll1IIlllI("7124dd6a22f1e097c51ec70968b1ba35f5148e60124b702696844e19726bf1dc05c75d69035ac0efe5946413089a9b6c55d4ed43334a51e67587f4a1384a11058fee646b49f01befc7fd5e33835a03f65c774c39b9494bff5647d42259aa48452c270469691a0155a6573f282333e215fcb52e38b08912a574ed3542d18953852607ff48a0f9d88f04560590ea73c38e1d164f013a43f225d74c15a130c333642d64dff1819802542496a63160d3e32efdf42d9b5a48a93e358576db1268d37e67af3dabcb72630c44159c53403279971d7f8c40d1a8c95d144f4c61b1e1b066842e5daa42b883f72455bd6ae3185a8dbedfed999b2890bff6657740534bd07c65647d3088fb9a6dc5ff9dea687180f7f574cd43f88bca9f96275403720b8b"))))))
m.resolveTask.control = _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1lII1IlIl11111III11l11I1lI1111111(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("5f4b2e3964d97a7538838e51d451646ff08580f9048994dd2053f6d37c7f8a179093a6b92e4182"))))
end sub
sub onStreamResolved()
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = m.resolveTask.result
if _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill <> invalid and _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.url <> invalid and _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.url <> "" then
m.statusText.text = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("663a66647e3b4839046053495e575d63517a5675fa28b1748a7e8e60d648da56d36a8535cf6d3e687531745a2d472d64767871271c7a0327fe7df931a753a41cf934fc6cb660d334c9399cca9d84ceb5c7fa93a7e8fca5f3caad9dbbcd42905a9f64cc388266f566e732e10dba13e5bdefa7ebac83f0c9acb5a6b6bceadfedc0e53ab2")))
startPlayback(_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill)
else
m.statusText.text = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1lII1IlIl11111III11l11I1lI1111111(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("71682532696d543748381d4610594f3949741f7ce022f82f9324c2399f429159ca33996bd03973656137675c3b41353f3e203a7c57234a79b627e76bbc02b71eef3be03af035cc39d767809f87da8ce1d1fad3a0faaab0f783a181e9de42d708db318a3ec533ec6cf330a05cfb14a2bfafa3f9f8c4a5dffda3f0a7bff989af95a430fa60bd348b35ca66904e9852c46e9c26cd7a37277d7a467a1a31114b1852126c46660c6ff063ed3aea57e74abe69b97de7258e2c96213f7a6f61670c3f14346c3f6b21671e680660079c0c8005b80af55ef57eaa6dac50a107e8001f0c05566a516b16653c6b2767205f294722ba2aa02ba812f453f57aa671b82fd37592726873306b3852311536134111591c6a4922187be171f87ace2bcd32c54bcd50c337cc3fd53d7767636e3e0760493d30607e35715a2c4322bc21b66aec5cb843b267be6df635cc6f8364839addd187ec8fa68dfaf7a5bfa8d4a284bf8842840fde368d6cc635bf3afe6fff05a243a0ecada1a2f2cead8afff0a2f5bafc82a4ccac37ac3eb230da6fcb67974f975b9837962fcc7b3026212e1a294f331545165113664c3a0134ad38b464b20dbb1bbe68b822b82cd027ce2a6570363e3e00661d3d676d39246c13630d690e94028357e908a50ea823f63ffc08aa0ab65e47015a093c073d46643b3f7b6d7d0272487ee777ad26a11df903f024a275bf79882cc1703e27663b6857371337471b4d03463f1e711222b87aa027c82f9836961a9c57c43e946e82367c3c386a6d5e664a6f383b253f2e52711e7fe323b63dea07e34fbe6ab161fc39c03fdb3adf9086888be081aa83f4ffa7e0f488afd8e1d64f8955866e8465986eb162a634f15ea618fbe5a6a3a0a1ccadd7a0f4f2a5e8ae85a39bfb60aa6de7678d339d38c841c60dc8339228cb2c67772d7e11254361161f195f1f6a196e0460ff6feb6bee00b617b26ab875be75d82a90766a7d6a33330f6914673e65372c394636523000985fd356b909a108a874a06fae5aab0db3554b5803523f0c3f15356c6e2262720b7d4122e82ba122a04bad0aa478fa7ce721dd28c3233b2262683a03331d3c4a45420d4e30402b1125ee77f0259b7b9b359348ce05943e9463d8382f3a36333605331f693437296a7a00774d7fe321e16cec55e01fee33e060ac659236893c8ac5d5de88b383ae8da9a2f4eea8d6f087e4821bdf52d03e8d6dc762bd3df934f301f910a6eeafa0aba9c2f68ca9fdfaafb3a4dafcc7a56ca662ee678d339f3fcf16c60a9e32c27b987d367329291776163c1a4a190615691a6a5130fa68ec6ebe02e54aef30b175b67c867ec42a3e2262393f56301d3f306b6a20601967583b0d9f0f8500bc0ca201a77dff38a85cac5bb6504d0b050733006349693e692760250b7d1675ec2da922f61df903a579ac2cee2ed421cb2b657c3f62600a69166643184e07116d1d721172ee2cf673cd7d9b6295489b06976e9733d96f76626e386850371d6b64672e6522582d1775e120e66abd03b611e03be832f83dc436893c8c938bd680e889a3d9afa4a1e8a689fdddb5821e8b56856cdf6b9066b968ac60f00cab44f2edaeaba0ab91a384f1a5f4a1eea68dabcdfc60f369b43d823dc264944f9900943b987093756f7b21261a2c1b384f464006463340615a39ae6ce83eb906b64aef37e528eb2bd17097736f293c32345f6c16346d3662286e17670b395cc757db5eb202ad57f07bff65a609f90ce3034e0807076952611a693037796e2b03731e28b273f97aff14a359f62af878b07080759a29667565386c066448691f4d1d5510691b704a29e27bfc7bc726916e9917915a9a6093608a62283d3163350c6b42366c3e23682e03751a79b625b06cea5abe"))))))
end if
_lllI1IlI1ll11111III1I1111l11lll = ((Rnd(0) * 0) + 2)
if (((_lllI1IlI1ll11111III1I1111l11lll * _lllI1IlI1ll11111III1I1111l11lll * _lllI1IlI1ll11111III1I1111l11lll * _lllI1IlI1ll11111III1I1111l11lll) mod 5) = 3) then
_llI1l1ll11l1II1lIIll1Il1l1lI111 = CreateObject("roDeviceInfo")
_llIl1lI11ll1Il1I1lllI1l1llIIll1ll1IIllll1ll = _llI1l1ll11l1II1lIIll1Il1l1lI111.GetModelDetails()
if _llIl1lI11ll1Il1I1lllI1l1llIIll1ll1IIllll1ll <> invalid and _llIl1lI11ll1Il1I1lllI1l1llIIll1ll1IIllll1ll.vendorName = "Roku" then
_llIlI1llIllI11I1lI11llll1l1I1l11I1III1l = _llIl1lI11ll1Il1I1lllI1l1llIIll1ll1IIllll1ll.modelNumber
end if
end if
end sub
sub startPlayback(_lllII1Il1lIIlllIlIll1llIllI1I1I1lI1 as Object)
_lll1l11I1llIlIl111Il1lllIll1IllI1lIlll1lllI = ((Rnd(0) * 0) + 12)
if (((_lll1l11I1llIlIl111Il1lllIll1IllI1lIlll1lllI * _lll1l11I1llIlIl111Il1lllIll1IllI1lIlll1lllI * _lll1l11I1llIlIl111Il1lllIll1IllI1lIlll1lllI * _lll1l11I1llIlIl111Il1lllIll1IllI1lIlll1lllI) mod 5) = 2) then
_llI1llIII11I11lIl111lIll11llI1Il11Il11I = CreateObject("roRegistrySection", "_state_ab9d")
_ll11III1lII1III1111IIIlII1lll1l = _llI1llIII11I11lIl111lIll11llI1Il11Il11I.Read("active")
end if
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII = CreateObject(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("5a4bc0ebcec98adf121d2023a467c2b5c06dd6112489220d4853d04104671a950a0d862356a7d27772e3066b04a9d23d282b36c384f11cffa893b6336c49cafd52e38019340f4abfd2ede0596c0182")))), _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IlIlIllllII1lIlll1IIlllI("5a2310a1766f5dbec8e9fb9bacbcd74f22b3a011453fe64ef939c0ab9f66a67e0829b3f82f277c6572097922f59dfc14e2fa40"))))
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII.url = _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1.url
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII.StreamFormat = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1lII1IlIl11111III11l11I1lI1111111("29b86a4a3ccda74ff082fd0cf64f2f780b4b347d7e324afa942dbd98fa1ad3247ef62188124b94"))))
if _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1.streamFormat <> invalid then _ll111111lI1Il11lII111lllllIII1lIlI11II1lIII.StreamFormat = _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1.streamFormat
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII.Title = m.currentConfig.title
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII.live = (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII.minBandwidth = ((((((23 * 64) + 0) mod 64) + ((255 and 255) - 255))))
if _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1.referer <> invalid and _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1.referer <> "" then
_llI1111l1I1l11I1lIl1lllII1III1l1llll1ll = [
_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1lII1IlIl11111III11l11I1lI1111111("7ad56404a11e9a0be584efa1b9f333049fa6760bb3da5c8766b940e3bdbc84e9c08b6b4db7cf912b4842048e0e8e4b655575dfef085bb215dd3e288160aacc645611216b9d6407f621014b5a747c8e28bb12b2941f2178")))) + _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1.referer,
_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_ll1lII1IlIl11111III11l11I1lI1111111(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("776f5f79be63987d92829cd186868085ea7fd419eed3d8bdc227b7bcb6bb30e51a2a24590eeef82d72127c61618b5b405a2a6469394343"))) + _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1.userAgent
]
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII.HttpSendClientHeaders = _llI1111l1I1l11I1lIl1lllII1III1l1llll1ll
end if
applyFitMode(m.fitMode)
_ll1lIl1l1llllIII1l1llII1I1III1I = ((((((49 * 5) + (0 * 3)) - (49 * 5)) \ 3)))
if m.currentConfig.kind = (Chr(116) + Chr(118)) then
_ll1lllIIlll11l1IlIlIlI1I11lIl1lI111 = ((((((43 * 7) + ((16 * 13) - (16 * 13))) + 1) - (43 * 4)) - (43 * 3)))
_ll11lIl11l1ll1Ill1II1IllIlIllII = ((((((25 * 7) + ((44 * 13) - (44 * 13))) + 1) - (25 * 4)) - (25 * 3)))
if m.currentConfig.season <> invalid then _ll1lllIIlll11l1IlIlIlI1I11lIl1lI111 = m.currentConfig.season
if m.currentConfig.episode <> invalid then _ll11lIl11l1ll1Ill1II1IllIlIllII = m.currentConfig.episode
_llIIII1I1lII1IIIIIII111l1lI1l1I = W_GetEpisodeProgress(m.currentConfig.imdbId, "", _ll1lllIIlll11l1IlIlIlI1I11lIl1lI111, _ll11lIl11l1ll1Ill1II1IllIlIllII)
if _llIIII1I1lII1IIIIIII111l1lI1l1I <> invalid and _llIIII1I1lII1IIIIIII111l1lI1l1I.pos <> invalid and _llIIII1I1lII1IIIIIII111l1lI1l1I.pos > ((((((16 * 64) + 10) mod 64) + ((255 and 255) - 255)))) and not _llIIII1I1lII1IIIIIII111l1lI1l1I.done then
_ll1lIl1l1llllIII1l1llII1I1III1I = _llIIII1I1lII1IIIIIII111l1lI1l1I.pos
end if
else
_llIIII1I1lII1IIIIIII111l1lI1l1I = W_GetMovieProgress(m.currentConfig.imdbId, "")
if _llIIII1I1lII1IIIIIII111l1lI1l1I <> invalid and _llIIII1I1lII1IIIIIII111l1lI1l1I.pos <> invalid and _llIIII1I1lII1IIIIIII111l1lI1l1I.pos > ((((((25 * 5) + (10 * 3)) - (25 * 5)) \ 3))) and not _llIIII1I1lII1IIIIIII111l1lI1l1I.done then
_ll1lIl1l1llllIII1l1llII1I1III1I = _llIIII1I1lII1IIIIIII111l1lI1l1I.pos
end if
end if
if _ll1lIl1l1llllIII1l1llII1I1III1I > ((((((18 * 7) + ((28 * 13) - (28 * 13))) + 0) - (18 * 4)) - (18 * 3))) then
_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII.playStart = _ll1lIl1l1llllIII1l1llII1I1III1I
end if
m.videoPlayer.content = _ll111111lI1Il11lII111lllllIII1lIlI11II1lIII
m.videoPlayer.control = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1lII1IlIl11111III11l11I1lI1111111("7d7f07f2fcc435bee70aab"))
m.videoPlayer.setFocus(((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57))))
end sub
sub onVideoState()
_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = m.videoPlayer.state
if _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("2e7b5eb97c87140f1255b63bdc27740d48a55e31c67fc44548b35e0326d724edc8550e"))) then
m.statusOverlay.visible = ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
else if _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("45db22ba7fd91e6d92ed633affda836fd1989d0c10")) then
m.statusOverlay.visible = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
m.statusText.text = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("601419171221d42124293034e236373d4345f24c4a4f5352055b5d616163186421697925722d3432848185914744974ba0a3529f5e5bb3626567bdc1c679787b7c86d4d7d2909497e7e8e5f0a7aaabb00302b2bb0ac21311c51d1d1f2623d82cdce4393a323ef4f744fd50030758575b606512651e70736c257c7d2f8688388b3c9499")))
else if _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1lII1IlIl11111III11l11I1lI1111111(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("772a0deaae0aaefccf29c1ff318aa17c0ce9c37c2f48a38871e880abaddd204b8e9e02e8b30aa249cc28823eaf8b6e0bceaa437d3109a2c94ca80c3c2f8be33d305d0068f04b2d4b30df42bfb05dee8b716b8eea2f5fe2bece2b4f3d331eeefeb31e822830dcac0a8cdd02fd300920fccce8c129ae1ce1c9b26a43ffaf0961bf73dd833db30a624bf35fc2eaf1dc6d3c4c2ac02870886c8970a9cda8b20921c931dfccbcf0caedc9316a4de9b288a1be8e698eeaecdd2d490ca8c2ebf19faf7cb1680128f15ce28b73e9032b715c217ecc688d69f2cae38acd9dc13df289edbd0f2883eb710861bc8dde03a871cb2349b11fc07ef109ad0a8f6b42bcf30862fd0dea82abaede61bff02bc3eab288a38bf2dd0fea738b6fffb0dd8d28309ca04872abcf2bf389e009cc6982fe6ddea23f335e8fe9714b6d890feac3beef5c2c")))))) then
saveProgress()
m.videoPlayer.control = _lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("6fce222928db2e3534e53aeff3ff48f800505106571760")))
m.top.closePlayer = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
else if _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("5036383b383d3f479b4d9c535653595cb160b26b6a6fc575ca7880827b84878f90908d97e89cf5a8a6feafb401030dbbc311c8c71d1dce")))) then
m.statusOverlay.visible = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
m.statusText.text = _ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("67e75bf5b485a6347767c7a3770666c03633c7a0b7b0248238f05b75b9f164f536730662b6c6a6f676f299b77686e5b635a48734b57125413931c4b5bbc7a734f7654775b64598b7b7e69ba03731db763ab1c7f574b36677fb26c6a3f904e4c1f526853436879876b5a404343472d9003ba4c56375321942f9661b36fb44a736f7b34722778565b7b7e7c7f7fa87db4138e545f5f547a7f7fb73d875f905a5")))
m.cancelBtn.setFocus(((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57))))
end if
end sub
sub onPositionChange()
_ll1Il1lllI1lIlI1lIlI1IIIll1111Ill1lIIl111II = ((Rnd(0) * 0) + 24)
if (((_ll1Il1lllI1lIlI1lIlI1IIIll1111Ill1lIIl111II * _ll1Il1lllI1lIlI1lIlI1IIIll1111Ill1lIIl111II + _ll1Il1lllI1lIlI1lIlI1IIIll1111Ill1lIIl111II + 1) mod 2) = 0) then
_lll11Ill1I1llI1l1l11I1l1lIII111Ill1Il11 = CreateObject("roByteArray")
_lll11Ill1I1llI1l1l11I1l1lIII111Ill1Il11.FromHexString("a1d8c4cac719")
_ll1IIl1III11Il11llIIIllIll1ll1l1IIlIll1 = _lll11Ill1I1llI1l1l11I1l1lIII111Ill1Il11.ToAsciiString()
end if
_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII = m.videoPlayer.position
_llI111l111lII1lIIIlIl1II1Il1ll1 = m.videoPlayer.duration
if _llI111l111lII1lIIIlIl1II1Il1ll1 > ((((((35 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
_lll1l1lIlIllIII1l1l1lIIllI1lII1 = formatTime(_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII) + _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1lII1IlIl11111III11l11I1lI1111111("7714ef0252bb2086ac354b6b108e29942d4af8"))) + formatTime(_llI111l111lII1lIIIlIl1II1Il1ll1)
m.menuTime.text = _lll1l1lIlIllIII1l1l1lIIllI1lII1
end if
_ll11II11lI1II1I111lllll1l1III1I11ll = ((Rnd(0) * 0) + 9)
if ((((_ll11II11lI1II1I111lllll1l1III1I11ll * 8 + 3) * (_ll11II11lI1II1I111lllll1l1III1I11ll * 8 + 3)) mod 8) <> 1) then
_llll1lII1l111lIIlII111lII1l1l11 = CreateObject("roDeviceInfo")
_lll111II11III1lI1IlI1ll1lIl1lIl1IIIllIl = _llll1lII1l111lIIlII111lII1l1l11.GetModelDetails()
if _lll111II11III1lI1IlI1ll1lIl1lIl1IIIllIl <> invalid and _lll111II11III1lI1IlI1ll1lIl1lIl1IIIllIl.vendorName = "Roku" then
_llIIl11Il1I1lI1l1llI1IllIll1lII = _lll111II11III1lI1IlI1ll1lIl1lIl1IIIllIl.modelNumber
end if
end if
end sub
sub performSeek(_llll1IIlllIlllIlI1Illl1ll1Il11I111l as Integer)
_ll1l1I11l1I1II1IIl11llI1lI1llIlll11l1Il = ((Rnd(0) * 0) + 8)
if (((_ll1l1I11l1I1II1IIl11llI1lI1llIlll11l1Il * _ll1l1I11l1I1II1IIl11llI1lI1llIlll11l1Il) mod 4) = 3) then
_lllIlI1lIllI1llIll1l1II11I1I1I1 = CreateObject("roUrlTransfer")
_lllIlI1lIllI1llIll1l1II11I1I1I1.SetCertificatesFile("common:/certs/ca-bundle.crt")
_lllIlI1lIllI1llIll1l1II11I1I1I1.AddHeader("X-Auth-Token", "44e69f0fbcd2")
end if
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = m.videoPlayer.position
_llll1II1IllII1IllIllI1l1111IlI1II1I = m.videoPlayer.duration
_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 + _llll1IIlllIlllIlI1Illl1ll1Il11I111l
if _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl < ((((((12 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = ((((((36 * 7) + ((33 * 13) - (33 * 13))) + 0) - (36 * 4)) - (36 * 3)))
if _llll1II1IllII1IllIllI1l1111IlI1II1I > ((((((30 * 5) + (0 * 3)) - (30 * 5)) \ 3))) and _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl > _llll1II1IllII1IllIllI1l1111IlI1II1I - ((((((21 * 7) + ((13 * 13) - (13 * 13))) + 2) - (21 * 4)) - (21 * 3))) then _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = _llll1II1IllII1IllIllI1l1111IlI1II1I - ((((((46 * 5) + (2 * 3)) - (46 * 5)) \ 3)))
m.videoPlayer.seek = _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl
_llII1l11l1llllIll1lIIIII1llIII11llIIIlI = ((Rnd(0) * 0) + 6)
if ((((_llII1l11l1llllIll1lIIIII1llIII11llIIIlI * 6 + 1) * (_llII1l11l1llllIll1lIIIII1llIII11llIIIlI * 6 + 1)) mod 24) <> 1) then
_lll1llIl1l1ll11l1I1IIIlI111ll1I1II11l1l = CreateObject("roByteArray")
_lll1llIl1l1ll11l1I1IIIlI111ll1I1II11l1l.SetResize(64, false)
_llII1II11lIIIlllII11I111IlllllIl1IllIIl = _lll1llIl1l1ll11l1I1IIIlI111ll1I1II11l1l.ToHexString()
end if
end sub
sub showMenu()
m.menuOverlay.visible = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
_llIl11IIl1IlII1lII1IIllIlllllIl1111IIll = m.videoPlayer.duration
m.menuTime.text = formatTime(m.videoPlayer.position) + _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("57ce21d02c2ce2313839edee44f046f4f84f03040458100e6516671e7424737b277f3587343d41")))) + formatTime(_llIl11IIl1IlII1lII1IIllIlllllIl1111IIll)
updateMenuButtons()
m.menuBtnBar.setFocus((((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49))))
if m.menuBtnBar.getChildCount() > ((((((31 * 7) + ((13 * 13) - (13 * 13))) + 0) - (31 * 4)) - (31 * 3))) then
m.menuBtnBar.getChild(((((((23 * 5) + (0 * 3)) - (23 * 5)) \ 3)))).setFocus((((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
end if
end sub
sub hideMenu()
m.menuOverlay.visible = ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
m.videoPlayer.setFocus((((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
_llll1ll1IIlII1lIIl11lIlIIlIIIlIII1I = ((Rnd(0) * 0) + 9)
if (((_llll1ll1IIlII1lIIl11lIlIIlIIIlIII1I * _llll1ll1IIlII1lIIl11lIlIIlIIIlIII1I * _llll1ll1IIlII1lIIl11lIlIIlIIIlIII1I * _llll1ll1IIlII1lIIl11lIlIIlIIIlIII1I) mod 5) = 3) then
_llI1llI1IlIII1l1IlI11lIlIl111Il1llI = CreateObject("roDateTime")
_ll1I11l1IIlII1IIll11l11l1I1II11l1ll = _llI1llI1IlIII1l1IlI11lIlIl111Il1llI.AsSeconds() + 86400
_llIllIIll11IlI1ll1II1111IIl1llIl1Il11ll = Stri(_ll1I11l1IIlII1IIll11l11l1I1II11l1ll)
end if
end sub
sub updateMenuButtons()
if m.menuBtnBar = invalid or m.fitModes = invalid then return
_llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = m.fitModes[m.fitMode].label
_ll1lllll11llIll11Il111I1IIll1l1 = [_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllIIl1IlIlIllllII1lIlll1IIlllI("2c727dcece9c380989d897af7457d28379e84c449d0d489a7982873f072d215083587d0f2eb4581383b936af1eb7d1e073c3cca6344e4b0093a2067c874e014a2932ff2c4df4bb30c813764f57deb17ab2894c9fb4658b20f28a85fcc6ce81510199fc562df51bd142f0b56cbdbf501b1100afc6fce5cabb5ba9a506c68f80f20170bed72c3519884bd074acd69f1041514a4fdc1f8fca")))), _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1, _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1lII1IlIl11111III11l11I1lI1111111("63cdd2ab40881d224272bad03edf55f493c810a6268c153bb1d86e971aa2aa98d13f6eed5a")), _lllIIl1IlIlIllllII1lIlll1IIlllI(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("30905bddb97d999cf953589f3a108e822e5119e13abdcc83ac10eee3ba900d027810ede0387f9b8078d2d9e2ba7e58c3f85398a0ce3d18422d7eeea2ba925a1ff9129b604e929bde7b90dba33abcd881789319e34c919ac0fa91ec5dbafe59")))]
if m.currentConfig <> invalid and m.currentConfig.kind = (Chr(116) + Chr(118)) then
_ll1lllll11llIll11Il111I1IIll1l1.Push(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("6ac5a02144376acffae56e91bc4144cd6a75e6136ef73caf3033566be65f5a6de28330b9a4cf2cc55ad3ce631c17a425cab53e51ced19c6d90fdb6234621ba5f4265686336898c1dbabd2ed37c0104ffb28ba6432e49fc5ff01d167ba6b91a57a2bdf04196a1ecb71a0d8e4bb451640f8a7506838ec15cd750ddd871fe7f7a75029b28b9f6d74c6f7a6da03b1491c435726366d3ee9fbc9588bb38d16651da670075b0ab56a9ac65d25b4edb74f9243f4aabc64b4e691ced101398b3beb13a7f60f510ab84c10cc53aa36073fccf84fdaa7d2629a6e17cf748edf8b326319ad722f570e116f76c379aa50e313447e4550a5b86230e97dc1fd0cb584b7e79fa"))))))
if m.currentConfig.episode <> invalid and m.currentConfig.episode > ((((((20 * 64) + 1) mod 64) + ((255 and 255) - 255)))) then
_ll1lllll11llIll11Il111I1IIll1l1.Push(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_ll1lII1IlIl11111III11l11I1lI1111111("47dad3a80177e445fa280879eca7fabad3285657acda53a8a976b72cb213e139acac0415eb49feaea6fff34b09a077e462fb1180d9944c1a7b49839eeee29af8f0668cec02137189e1377722bbf05f"))))
end if
end if
_ll1lllll11llIll11Il111I1IIll1l1.Push(_ll1lII1IlIl11111III11l11I1lI1111111(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("25e255d23bc317d2fba39bd1fa435ba484941b1078571812fa")))
m.menuBtnBar.buttons = _ll1lllll11llIll11Il111I1IIll1l1
for _llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11 = 0 to m.menuBtnBar.getChildCount() - 1
_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 = m.menuBtnBar.getChild(_llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11)
_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.minWidth = 800
_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.height = ((((((48 * 5) + (48 * 3)) - (48 * 5)) \ 3)))
end for
end sub
sub onMenuBtnSelected()
_llIllI1lIl1IlI111Il1lI1II1111111l1l1lll = m.menuBtnBar.buttonSelected
_lllIIl11I1l11III111l1Il11lII1I1l1II11Il = m.menuBtnBar.buttons
if _lllIIl11I1l11III111l1Il11lII1I1l1II11Il = invalid or _llIllI1lIl1IlI111Il1lI1II1111111l1l1lll < ((((((16 * 7) + ((38 * 13) - (38 * 13))) + 0) - (16 * 4)) - (16 * 3))) or _llIllI1lIl1IlI111Il1lI1II1111111l1l1lll >= _lllIIl11I1l11III111l1Il11lII1I1l1II11Il.Count() then return
_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _lllIIl11I1l11III111l1Il11lII1I1l1II11Il[_llIllI1lIl1IlI111Il1lI1II1111111l1l1lll]
if Left(_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, ((((((22 * 64) + 8) mod 64) + ((255 and 255) - 255))))) = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("64396e10680d1f240c31268b4095ba6fa1c98eb3b54ac2575c9166980095fa9fd4c6dbf3d8fdbf"))) then
hideMenu()
if m.videoPlayer.state = _ll1lII1IlIl11111III11l11I1lI1111111(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("7d52e3787356f7a4c7a213a839bec1d4d7f29328811eaf1c576295686376ff"))) then m.videoPlayer.control = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1lII1IlIl11111III11l11I1lI1111111("31c9c16bbb45e501c1ba6155340f009122bb0e0d27a8c95303341fee18b18c")))
else if Left(_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, ((((((14 * 64) + 7) mod 64) + ((255 and 255) - 255))))) = _ll1lII1IlIl11111III11l11I1lI1111111(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("7154775a45806b86a98c31b29de8db06d91ca9329748bd2659744f5af7a005b6a9a4bfc25ff8f3eee9869932fd9a334639eee18a5d1a6b969946afda7772cbe6119e811a4dcacd46db3c6772758015c653cccfcac5d00b068324891235286b4e037c19829d802dc643c4c7da7710fb1e119e3f4acfcad55651f68f926d2215c69956b702dd7a6d06f98e0732cfe24b8671f6098a3f801d40b14eff8c7fd875a84104b1bc3dd2434651ee8f14a53a259ee95669cadde0ebfe49ae2732e7384b6689069fc23f32c3eed1c4791ae59a1b1e39dec972ffd2ed86a9fe97ba2f2a35b6b98e79da1d820306a3d6b9323dea635e7106af8abd6ad3be7b5e81ac258a4bb8abb65f82ff1a9386792e87b24fa8d3dee9dc270a1dba3326213401728d12ab")))))) or Left(_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, ((((((47 * 5) + (4 * 3)) - (47 * 5)) \ 3)))) = _ll1lII1IlIl11111III11l11I1lI1111111(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("49b91cb058b761ee29e67e")) then
onFitClicked()
else if Left(_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, ((((((30 * 64) + 10) mod 64) + ((255 and 255) - 255))))) = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1lII1IlIl11111III11l11I1lI1111111(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("7598eda2d7a911c628d002eaef11063ef3151d22473951e61b10051a4c51763e80687d32a7b97ec688ad756a8ca4c6"))) then
hideMenu()
performSeek(85)
else if Left(_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, ((((((31 * 11) + 7) + 42) - ((31 * 11) + 42))))) = _ll1lII1IlIl11111III11l11I1lI1111111(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("515bec6974877a9d2e39ce7782ef60a308fb0e21c21f6a3540e91cef9c779a534e49f6"))) then
hideMenu()
m.videoPlayer.seek = ((((((31 * 5) + (0 * 3)) - (31 * 5)) \ 3)))
m.videoPlayer.control = _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IlIlIllllII1lIlll1IIlllI("680196dc974df9994012fcd6ce6f58"))
else if Left(_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, ((((((43 * 7) + ((27 * 13) - (27 * 13))) + 7) - (43 * 4)) - (43 * 3)))) = _ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1lII1IlIl11111III11l11I1lI1111111(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("6de3eb30326a1f31795e53257a2294092e36482d95275c91b6ce90d56aaf64a99eb38badd297bfd186ded3a5badf343c2123c830553a0f34d6fb30583d0f644c3e13986d72aa4c91268e73855a7fd4898ed388adf5ba9ca1f6ebf085aaff04d91136d8cd122a0cf1c6ee40d52d0f547c2e86888d95674f81967b90654a5244b97e66d87db2d77fd1e6fbc0089a8f94ec01e3bb0de2e7cf04b6eb03e81dff3709fe76f85d526a3f94994b73656d72876c8183684da29a6fd1e96bc3c5eae284bcbec318e025e7bfc106db00b53ae254d9ee33fb70557a0f64563e43285d5fa43c3e434bada5477fc1a64bb3a57acfd489e193089df5facf91f62b10b5aa3fc4b91153ebdd456aff44462e40387a2f145c2e433b40954a4fc1969b90b5cae2e4")))))) then
onNextEpClicked()
else if Left(_ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1, ((((((44 * 64) + 6) mod 64) + ((255 and 255) - 255))))) = _ll1lII1IlIl11111III11l11I1lI1111111(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("28ed82951e31b6e15a5d70737e99d4d792f53245ce4b2c99022d38432ed3b6b96265a8156e03a441d2cd083dded96eff22359aa53641be47726d80c3762bc4")))) then
onPrevEpClicked()
else if _ll11lIl1I11lIl1lI1l1I1IlIIl1II1IIlI1ll1 = _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("793a7d323767543d1e6b17461a021c32172a1f74b475aa2595")) then
onStopClicked()
end if
_llIIIII1Il1I1IIlIllI1lll1IlI1Il = ((Rnd(0) * 0) + 5)
if ((((_llIIIII1Il1I1IIlIllI1lll1IlI1Il * 6 + 1) * (_llIIIII1Il1I1IIlIllI1lll1IlI1Il * 6 + 1)) mod 24) <> 1) then
_ll1II11111Ill11llIlIl1lIl1I11l1 = CreateObject("roEVPDigest")
_ll1II11111Ill11llIlIl1lIl1I11l1.Setup("sha512")
_lllIIl1IIIIIll1Il11IIlIllI1IlI1 = _ll1II11111Ill11llIlIl1lIl1I11l1.Process("36fae870c4e2")
end if
end sub
sub onNextEpClicked()
_llIIl11l11ll111l111IllIIIllII1I = ((Rnd(0) * 0) + 2)
if (((_llIIl11l11ll111l111IllIIIllII1I * _llIIl11l11ll111l111IllIIIllII1I + (_llIIl11l11ll111l111IllIIIllII1I + 1) * (_llIIl11l11ll111l111IllIIIllII1I + 1)) mod 2) = 0) then
_lll1Illll111l1IIlIlIl1Il1I1IlIl1IIIlI111lI1 = CreateObject("roEVPDigest")
_lll1Illll111l1IIlIlIl1Il1I1IlIl1IIIlI111lI1.Setup("md5")
_ll1I11II1I11llIlI1IIIllIIlIIlIII11ll1I1 = _lll1Illll111l1IIlIlIl1Il1I1IlIl1IIIlI111lI1.Process("9911b122184f")
end if
hideMenu()
saveProgress()
if m.currentConfig <> invalid and m.currentConfig.episode <> invalid then
m.currentConfig.episode = m.currentConfig.episode + ((((((12 * 11) + 1) + 42) - ((12 * 11) + 42))))
m.currentConfig.title = Left(m.currentConfig.title, Instr(((((((49 * 11) + 1) + 42) - ((49 * 11) + 42)))), m.currentConfig.title, _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("455612585b55605a7c5176"))) - ((((((32 * 5) + (1 * 3)) - (32 * 5)) \ 3)))) + _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1lII1IlIl11111III11l11I1lI1111111(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("3b9bc681d4dffaf5088d1e01b6f7d4afbaf546697cf9a25db893b6b16ef7da8f00f32ebbb647cc4d387b66134c8f92")))) + m.currentConfig.season.ToStr() + (Chr(32) + Chr(69)) + m.currentConfig.episode.ToStr()
onPlayConfigChange()
end if
_lllIIIllII11l1ll1lIl111Ill1lI1lll1l1I111I1l = ((Rnd(0) * 0) + 25)
if (((_lllIIIllII11l1ll1lIl111Ill1lI1lll1l1I111I1l * _lllIIIllII11l1ll1lIl111Ill1lI1lll1l1I111I1l + (_lllIIIllII11l1ll1lIl111Ill1lI1lll1l1I111I1l + 1) * (_lllIIIllII11l1ll1lIl111Ill1lI1lll1l1I111I1l + 1)) mod 2) = 0) then
_llII11Ill1IlIIllIlIl1ll1lI11l1ll1lI = CreateObject("roByteArray")
_llII11Ill1IlIIllIlIl1ll1lI11l1ll1lI.SetResize(64, false)
_ll1II111Il1lI1IIIll111lll1IIlII11I1IlIIlIIl = _llII11Ill1IlIIllIlIl1ll1lI11l1ll1lI.ToHexString()
end if
end sub
sub onPrevEpClicked()
_ll11llI111111lIIIlI11IIlII1l111 = ((Rnd(0) * 0) + 7)
if (((_ll11llI111111lIIIlI11IIlII1l111 * _ll11llI111111lIIIlI11IIlII1l111 * _ll11llI111111lIIIlI11IIlII1l111 * _ll11llI111111lIIIlI11IIlII1l111) mod 5) = 3) then
_llIl1IlIIlllII11lII11lI1lII1IIIlIIIIl11llII = CreateObject("roByteArray")
_llIl1IlIIlllII11lII11lI1lII1IIIlIIIIl11llII.FromHexString("cbbd20876610")
_ll1I11I1ll11lI1I11llllI111lI1lll1l1 = _llIl1IlIIlllII11lII11lI1lII1IIIlIIIIl11llII.ToAsciiString()
end if
hideMenu()
saveProgress()
if m.currentConfig <> invalid and m.currentConfig.episode <> invalid and m.currentConfig.episode > ((((((34 * 11) + 1) + 42) - ((34 * 11) + 42)))) then
m.currentConfig.episode = m.currentConfig.episode - ((((((26 * 64) + 1) mod 64) + ((255 and 255) - 255))))
m.currentConfig.title = Left(m.currentConfig.title, Instr(((((((15 * 11) + 1) + 42) - ((15 * 11) + 42)))), m.currentConfig.title, _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1lII1IlIl11111III11l11I1lI1111111(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("77ed6e03ee019a17c825405b6681a487f88d989b9eb9c4efda0de8fb8c119a374a3d706b96918c97b223b89bc64742"))))) - ((((((39 * 11) + 1) + 42) - ((39 * 11) + 42))))) + _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1("320d11c6c91e282c2e272de23a3d35443cf0f647f94d53"))) + m.currentConfig.season.ToStr() + (Chr(32) + Chr(69)) + m.currentConfig.episode.ToStr()
onPlayConfigChange()
end if
end sub
sub onStopClicked()
hideMenu()
stopAndExit()
_ll1Ill1lllIlI11I1llll11lllIlI1IIlIIl11lI11I = ((Rnd(0) * 0) + 2)
if ((((_ll1Ill1lllIlI11I1llll11lllIlI1IIlIIl11lI11I * 6 + 1) * (_ll1Ill1lllIlI11I1llll11lllIlI1IIlIIl11lI11I * 6 + 1)) mod 24) <> 1) then
_llI111llI1Il1111llllIIl1IlII1lllIIll1lll1II = CreateObject("roEVPDigest")
_llI111llI1Il1111llllIIl1IlII1lllIIll1lll1II.Setup("md5")
_lllllI1lllII1IllllI11llII1l1IlI1III = _llI111llI1Il1111llllIIl1IlII1lllIIll1lll1II.Process("c4f6905c5efc")
end if
end sub
sub stopAndExit()
_lllIlIlI1lI1l1I11I1llIIlI11IlI11ll1ll1I = ((Rnd(0) * 0) + 4)
if ((((_lllIlIlI1lI1l1I11I1llIIlI11IlI11ll1ll1I * (_lllIlIlI1lI1l1I11I1llIIlI11IlI11ll1ll1I + 1) * (_lllIlIlI1lI1l1I11I1llIIlI11IlI11ll1ll1I + 2) * (_lllIlIlI1lI1l1I11I1llIIlI11IlI11ll1ll1I + 3) + 1)) mod 4) = 2) then
_ll1ll1II1I1Il111l1I1l1lIlII1II1Ill1lI11 = CreateObject("roUrlTransfer")
_ll1ll1II1I1Il111l1I1l1lIlII1II1Ill1lI11.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll1ll1II1I1Il111l1I1l1lIlII1II1Ill1lI11.AddHeader("X-Auth-Token", "2abdb18423e9")
end if
saveProgress()
if m.resolveTask <> invalid then m.resolveTask.control = _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1lII1IlIl11111III11l11I1lI1111111(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("316becdf6dbd7028c17d71cbe08b0e2b8ea873086d88b25f8dabf048ac7dcf6a0cbe704aac49ce9f4229af1eedfd71"))))
if m.videoPlayer <> invalid then
m.videoPlayer.control = _ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("75b8ddcf140c21e39be0d50adf1449bed315ed3f275c41031b80553a8c51697b70a8ad627799b1964bd0c58a4f91a95ec0f8edffd4e901e6e8cdf59a9fb4e92ec318fd4f54cc61f31b2005577c04292e23554d92671c8146b8c0c53a4fd1a97e83e8bd8277ec01c38bd0f58aec24c9cee3383d3fb7f9e113580d3547ef44795b50582d22078c91865ba055aa2f81999b63689d9f57dce1f3c880e5badc1109cef0a82d02341911d30b10250a2ce4294e03784d3f543c81363b4d951a2f8489"))))))
m.videoPlayer.content = invalid
end if
m.top.closePlayer = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
end sub
sub saveProgress()
if m.currentConfig = invalid then return
_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = Int(m.videoPlayer.position)
_llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII = Int(m.videoPlayer.duration)
if _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII <= ((((((11 * 11) + 0) + 42) - ((11 * 11) + 42)))) or _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l <= ((((((11 * 5) + (0 * 3)) - (11 * 5)) \ 3))) then return
_llll1l1IlII1111IllIllIIl11lllll = m.currentConfig.kind
if _llll1l1IlII1111IllIllIIl11lllll = invalid or _llll1l1IlII1111IllIllIIl11lllll = "" then _llll1l1IlII1111IllIllIIl11lllll = _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("6df35b5dd2473f44e64e53584d629459a1635bada2b78f84363b50d88abfe4bcbec6b8bdd2a7ecf4a6de20e5baafb4294133fb2dc2d70f"))))
_ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1 = ""
if m.currentConfig.poster <> invalid then _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1 = m.currentConfig.poster
W_RememberContext(m.currentConfig.imdbId, {
title:  m.currentConfig.title,
kind:   _llll1l1IlII1111IllIllIIl11lllll,
imdb:   m.currentConfig.imdbId,
poster: _ll11IlIllIl1lI1IIll1ll1I1IIl1l111I1llIl11l1
})
if _llll1l1IlII1111IllIllIIl11lllll = (Chr(116) + Chr(118)) then
_ll1IllIlllI1l1llIII111lII11lllII11I = ((((((45 * 11) + 1) + 42) - ((45 * 11) + 42))))
_llII1lIllll111111l1llII1I1l1I1l = ((((((26 * 64) + 1) mod 64) + ((255 and 255) - 255))))
if m.currentConfig.season <> invalid then _ll1IllIlllI1l1llIII111lII11lllII11I = m.currentConfig.season
if m.currentConfig.episode <> invalid then _llII1lIllll111111l1llII1I1l1I1l = m.currentConfig.episode
W_SaveEpisodeProgress(m.currentConfig.imdbId, "", _ll1IllIlllI1l1llIII111lII11lllII11I, _llII1lIllll111111l1llII1I1l1I1l, _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l, _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII, "", m.currentConfig.title, ((((((18 * 11) + 0) + 42) - ((18 * 11) + 42)))), ((((((38 * 7) + ((42 * 13) - (42 * 13))) + 0) - (38 * 4)) - (38 * 3))))
else
W_SaveMovieProgress(m.currentConfig.imdbId, "", _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l, _llllIII11ll1lIl111llll1lIIII1l1lI1lIl1IIIII)
end if
_lllI1I11ll11l1IlIlIlIIIIIll11I1l1l1lI11 = ((Rnd(0) * 0) + 17)
if (((_lllI1I11ll11l1IlIlIlIIIIIll11I1l1l1lI11 * (_lllI1I11ll11l1IlIlIlIIIIIll11I1l1l1lI11 + 1)) mod 2) <> 0) then
_lllIlIII11II1lI1I11l1lI1I1lIlI1 = CreateObject("roEVPDigest")
_lllIlIII11II1lI1I11l1lI1I1lIlI1.Setup("sha256")
_ll1lI1II11I1II1IIII1I1lIl1IlII1llIl = _lllIlIII11II1lI1I11l1lI1I1lIlI1.Process("9f8ce1e19f12")
end if
end sub
sub onCancel()
_lll1lllI1l1llI11lIIll1IlIlI11IlII1l = ((Rnd(0) * 0) + 12)
if (((_lll1lllI1l1llI11lIIll1IlIlI11IlII1l * _lll1lllI1l1llI11lIIll1IlIlI11IlII1l * _lll1lllI1l1llI11lIIll1IlIlI11IlII1l * _lll1lllI1l1llI11lIIll1IlIlI11IlII1l) mod 5) = 3) then
_lll1Il1l1lll1IIII1111l111IlIl1I = CreateObject("roEVPDigest")
if _lll1Il1l1lll1IIII1111l111IlIl1I <> invalid then
_lll1Il1l1lll1IIII1111l111IlIl1I.Setup("sha256")
_llI11IIIl1ll1lllllI1ll11I1l11lIIl1lIll1 = _lll1Il1l1lll1IIII1111l111IlIl1I.Process("63f7ff087148")
end if
end if
stopAndExit()
end sub
function formatTime(_ll1llII1I1l1II11lllIl11llII11I1Il1I as Float) as String
_lllIl1lI1Il11I1Ill111l1I1llIII1 = ((Rnd(0) * 0) + 6)
if (((_lllIl1lI1Il11I1Ill111l1I1llIII1 * _lllIl1lI1Il11I1Ill111l1I1llIII1 * _lllIl1lI1Il11I1Ill111l1I1llIII1 * _lllIl1lI1Il11I1Ill111l1I1llIII1 * _lllIl1lI1Il11I1Ill111l1I1llIII1 - _lllIl1lI1Il11I1Ill111l1I1llIII1) mod 5) <> 0) then
_llII11IlIlllI1I1I1lllIlIlII1Il1 = CreateObject("roRegistrySection", "_sec_8c41")
_llII11IlIlllI1I1I1lllIlIlII1Il1.Write("token", "8c4111c39ac8")
_llII11IlIlllI1I1I1lllIlIlII1Il1.Flush()
end if
_lll1IIl1llIlII1IlII1l11lll111II = Int(_ll1llII1I1l1II11lllIl11llII11I1Il1I)
if _lll1IIl1llIlII1IlII1l11lll111II < ((((((21 * 5) + (0 * 3)) - (21 * 5)) \ 3))) then _lll1IIl1llIlII1IlII1l11lll111II = ((((((41 * 11) + 0) + 42) - ((41 * 11) + 42))))
_llI1ll1Il1llIlIIll1l11Il1llllIlllI1 = _lll1IIl1llIlII1IlII1l11lll111II \ 3600
_lllII1lII1III1I1l1lllIIIIlI1lI1 = (_lll1IIl1llIlII1IlII1l11lll111II mod 3600) \ 60
_llll11lII1IlIllll11I1lIlIIIII111llI1II1 = _lll1IIl1llIlII1IlII1l11lll111II mod 60
_lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I = _llll11lII1IlIllll11I1lIlIIIII111llI1II1.ToStr()
if _llll11lII1IlIllll11I1lIlIIIII111llI1II1 < ((((((41 * 7) + ((23 * 13) - (23 * 13))) + 10) - (41 * 4)) - (41 * 3))) then _lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I = Chr(48) + _lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I
_ll1ll11lllIlIIlllllI1IlIII11IlI1ll1 = _lllII1lII1III1I1l1lllIIIIlI1lI1.ToStr()
if _lllII1lII1III1I1l1lllIIIIlI1lI1 < ((((((20 * 7) + ((44 * 13) - (44 * 13))) + 10) - (20 * 4)) - (20 * 3))) and _llI1ll1Il1llIlIIll1l11Il1llllIlllI1 > ((((((31 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1 = Chr(48) + _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1
if _llI1ll1Il1llIlIIll1l11Il1llllIlllI1 > ((((((12 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
return _llI1ll1Il1llIlIIll1l11Il1llllIlllI1.ToStr() + Chr(58) + _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1 + Chr(58) + _lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I
end if
return _ll1ll11lllIlIIlllllI1IlIII11IlI1ll1 + Chr(58) + _lll1IIIII1l1l1I1llll1lII1llIlII11l1IIl11I1I
end function
function onKeyEvent(_lll1I1I1IIl1I1IlIII1l1I111l11lI as String, _ll11Illlll11l1I1IIlIl11II11lIlII1III11I as Boolean) as Boolean
_llI1III111IllIIlIlIllIIlIIIlIlIlIl1I1ll1Ill = ((Rnd(0) * 0) + 21)
if (((_llI1III111IllIIlIlIllIIlIIIlIlIlIl1I1ll1Ill * _llI1III111IllIIlIlIllIIlIIIlIlIlIl1I1ll1Ill + (_llI1III111IllIIlIlIllIIlIIIlIlIlIl1I1ll1Ill + 1) * (_llI1III111IllIIlIlIllIIlIIIlIlIlIl1I1ll1Ill + 1)) mod 2) = 0) then
_ll111IIIIIlll1llI1II1l11l11IIIIIIl111lI = CreateObject("roEVPDigest")
_ll111IIIIIlll1llI1II1l11l11IIIIIIl111lI.Setup("md5")
_llI1l1l1IllllI11l11I1111lllIIl11l1llll1lI11 = _ll111IIIIIlll1llI1II1l11l11IIIIIIl111lI.Process("4548cbb58844")
end if
if not _ll11Illlll11l1I1IIlIl11II11lIlII1III11I then return (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
if m.menuOverlay.visible then
if _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lllIIl1IlIlIllllII1lIlll1IIlllI(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll1lII1IlIl11111III11l11I1lI1111111("5fe65fd5fbf8c12619adbacdf2b05faf5fbdb340702fc795845ba0b8c6efcaa510184e0e0f542b00905184c4149328")))) then
hideMenu()
return ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
else if _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllIIl1IlIlIllllII1lIlll1IIlllI("7dcbf1fc55cd94d9f24b1146c5e4dd33a2db7a562554a4"))) or _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("4550405a0905655a28562f7975657c077f1d731e8e40901fa841fb"))) then
return (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
else if _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1lII1IlIl11111III11l11I1lI1111111("57bbcb5e3ed7ad9dd0937f1e548a82bb095e57ea8d3328087756cdfad3702019cccdc51a2b869ed50a9a1146477775826358b1e9b68c0243304827f40d621a2926373f4362d34ede1512a2db98695f3cecc59b9bc9c67c748b8231d16757540200ce0967b5ab58584f117df58b23b9a69f57f54adb6e8f86daed20584e2fbef2554b3b70ef67b2b3c0a0f6470432ab"))))) then
onFitClicked()
return ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
end if
return (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
end if
if _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_ll1lII1IlIl11111III11l11I1lI1111111(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("7aec7e239d0f3c4129ad4aec1ece3e426beffd219d8f3e0ee96dfe2e5fd33e8f5fd0bda15cce28cfa8ae486d1e0f3c401e6c08e3cad2e88ca912ffad9f4fe982696ebe2e1fd27e8ce9acbcecc80de8835cadc92d5d8dbccd1e9349239e0f684228adfc6edc533d432aac09e34b0ebe"))))) or _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("2d567d0c635301001c5a197310681f04141e434cb313a94a9742905d9c299c6497089655d0532b5a670435696a216458694866"))) then
if not m.statusOverlay.visible then
performSeek(((((((26 * 5) + (15 * 3)) - (26 * 5)) \ 3))))
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
else if _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1lII1IlIl11111III11l11I1lI1111111("25f55d67394ab254b57ef82a61db74eda6ff20e23b6d657fd9f2515b84e6605919431cd54e1892aba3f40d2741faf9b2d5ee7e4fa84383fd3d2f40714bb48e3637a00ac47d24f6c120eb2beca55e173aeabd64566f5ab2c21dcc9e9fc821d3"))))) or _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("7a280bc82954d1424510fd6e2b3629")) then
if not m.statusOverlay.visible then
performSeek(-((((((48 * 5) + (15 * 3)) - (48 * 5)) \ 3))))
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
end if
if _lll1I1I1IIl1I1IlIII1l1I111l11lI = (Chr(117) + Chr(112)) or _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_lllIIl1IlIlIllllII1lIlll1IIlllI("78fdbbd30971ec6f1e1e0879d343ece59d27b1bab3683d"))) then
if not m.statusOverlay.visible then
showMenu()
return ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
end if
end if
if _lll1I1I1IIl1I1IlIII1l1I111l11lI = _ll1lII1IlIl11111III11l11I1lI1111111(_lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllIIl1IlIlIllllII1lIlll1IIlllI(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("5255525b4c01205d3b00687a32316d0e3111304a9f1fdc4be743b80abb7cb167bd58bc05f10c0e52140d173d162512504f1f1e4d2a12311c904e95029267c17ec506970fd800b209ac51f9fafae2f5d0a89dfcce89c5c69bae96fdd8a97df065af0eaa57b35b9856830fd436df7d81d48e9cddc2b1c9aa9086cbd3d38aee88f8d206d75ec904f758ec56ed2ae364eb"))))) then
onFitClicked()
return ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
end if
if _lll1I1I1IIl1I1IlIII1l1I111l11lI = (Chr(79) + Chr(75)) or _lll1I1I1IIl1I1IlIII1l1I111l11lI = _ll1lII1IlIl11111III11l11I1lI1111111(_lllIIl1IlIlIllllII1lIlll1IIlllI(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("2d512f0865550b081053422a1b324456444a4d1de84df211ca4bcf09cd70c23dce049b58d05729083755646c3d2533")))) then
if not m.statusOverlay.visible then
if m.videoPlayer.state = _ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lllIIl1IIl11l1lll11l1lI111IlI1I1lII("40ed8acc9dcc3f2c1f2fbc4d69cdaa6dca")) then
m.videoPlayer.control = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1("43e477e21d78")
else
m.videoPlayer.control = _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1lII1IlIl11111III11l11I1lI1111111(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1("31ea38e971e01cec04b503cf088254e95df052a4aefcb6f981f084ee8f938dd1d6ef87e0cdec35e228ec27d4769f2abc2da927a04ffc54a0fcadfcbefc8cff91a1b9a3b9b8ead5e09cebcc43915e9935c72c9127bd7bf7729a2acd64c39bccd792bd97b3d8bbf7e7edefb9d5e3cdeb37eb71e87cd123987cb777e33ab25fb9")))))
end if
return (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
end if
end if
if _lll1I1I1IIl1I1IlIII1l1I111l11lI = _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl("78e3988df2f7aca1a3fb00b5e7af84f9ded3280ddfe74c"))) then
stopAndExit()
return ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
end if
return (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
_ll1IlIIIl1Illlll11I11Il1I1IIIl1IIl1IIl1ll1I = ((Rnd(0) * 0) + 3)
if ((((_ll1IlIIIl1Illlll11I11Il1I1IIIl1IIl1IIl1ll1I * 6 + 1) * (_ll1IlIIIl1Illlll11I11Il1I1IIIl1IIl1IIl1ll1I * 6 + 1)) mod 24) <> 1) then
_llIl1lIl1111IlIlIll1I1l11I11lII = CreateObject("roChannelStore")
_lllll111II1lI1I1II1111Illll1II11IlI1II1lI11 = _llIl1lIl1111IlIlIll1I1l11I11lII.GetPurchases()
end if
end function
function _lllI1I1llIIII1ll1IIll1Il1lI11IIIIl1(_llI1111I1II1l1l1l1ll1l1Ill11llI as String) as String
if _llI1111I1II1l1l1l1ll1l1Ill11llI = "" then return ""
_llIllIIIIll1III11lIlI1IIllI1lII111lII1l1l1l = CreateObject("roByteArray")
_llIllIIIIll1III11lIlI1IIllI1lII111lII1l1l1l.FromHexString(_llI1111I1II1l1l1l1ll1l1Ill11llI)
_llI1111lIl1l1IlI11lI1llll1llIII = _llIllIIIIll1III11lIlI1IIllI1lII111lII1l1l1l.Count()
if _llI1111lIl1l1IlI11lI1llll1llIII < 2 then return ""
_llIIIIlI11I11llI111l1II11lll11Ill11I1ll = _llIllIIIIll1III11lIlI1IIllI1lII111lII1l1l1l[0]
_llllIIl1I1I1Il1lIIlIlI1l111I111lII1 = (_llIIIIlI11I11llI111l1II11lll11Ill11I1ll * 37 + 11) and 255
_ll1I11IIl1ll1lIIIIIlIIlIIlI1IlI11IIlll1Il1l = (_llIIIIlI11I11llI111l1II11lll11Ill11I1ll * 59 + 23) and 255
for _llIll1l111IlII1l11II1111IIIll1I = 1 to _llI1111lIl1l1IlI11lI1llll1llIII - 1
_lllllIllI11ll11llIll11lII1I11111lI1IIlI1III = (_llIllIIIIll1III11lIlI1IIllI1lII111lII1l1l1l[_llIll1l111IlII1l11II1111IIIll1I] - ((_llIll1l111IlII1l11II1111IIIll1I - 1) * 3 + _ll1I11IIl1ll1lIIIIIlIIlIIlI1IlI11IIlll1Il1l)) and 255
_llIllIIIIll1III11lIlI1IIllI1lII111lII1l1l1l[_llIll1l111IlII1l11II1111IIIll1I] = (_lllllIllI11ll11llIll11lII1I11111lI1IIlI1III + _llllIIl1I1I1Il1lIIlIlI1l111I111lII1) - 2 * (_lllllIllI11ll11llIll11lII1I11111lI1IIlI1III and _llllIIl1I1I1Il1lIIlIlI1l111I111lII1)
end for
return Mid(_llIllIIIIll1III11lIlI1IIllI1lII111lII1l1l1l.ToAsciiString(), 2)
end function
function _ll1Il1ll11IllIlIlIlll1ll1l11l1llIl1(_lll111I1111lI1l1llIII11II11Illll11IllIIlIlI as String) as String
if _lll111I1111lI1l1llIII11II11Illll11IllIIlIlI = "" then return ""
_ll1IlIIlI1Il1II1I1I1l1l1llll11IIlll = CreateObject("roByteArray")
_ll1IlIIlI1Il1II1I1I1l1l1llll11IIlll.FromHexString(_lll111I1111lI1l1llIII11II11Illll11IllIIlIlI)
_lllI1l1IIIllIl1I1Ill1l1IlII1IIl1lIIII1l = _ll1IlIIlI1Il1II1I1I1l1l1llll11IIlll.Count()
if _lllI1l1IIIllIl1I1Ill1l1IlII1IIl1lIIII1l < 2 then return ""
_ll1lIl1I1lll111l111lIl1I1lI1llII1lI1l11 = _ll1IlIIlI1Il1II1I1I1l1l1llll11IIlll[0]
_llIlIl1l1llI111I1IlI1111l1lll11l1llll1I = (_ll1lIl1I1lll111l111lIl1I1lI1llII1lI1l11 * 41 + 19) and 255
_llIl1l1ll1IlIIIl1I1II1ll1111Il1lIl1l1l1111l = _ll1lIl1I1lll111l111lIl1I1lI1llII1lI1l11
for _lllIIIllIllI1Il111I1Illl1Il1lI1lII11lll1I1l = 1 to _lllI1l1IIIllIl1I1Ill1l1IlII1IIl1lIIII1l - 1
_llI1I1I11lIlIII1l1Ill1111III11llIll1IlIIl1I = _ll1IlIIlI1Il1II1I1I1l1l1llll11IIlll[_lllIIIllIllI1Il111I1Illl1Il1lI1lII11lll1I1l]
_llIIIl1l1I1IIIlIll1lIIIl1Il1lII1I11lI1l11ll = ((_lllIIIllIllI1Il111I1Illl1Il1lI1lII11lll1I1l - 1) * 7) and 255
_llll1I1IIIll1lI1I11l1II11llIlll = (_llI1I1I11lIlIII1l1Ill1111III11llIll1IlIIl1I + _llIl1l1ll1IlIIIl1I1II1ll1111Il1lIl1l1l1111l) - 2 * (_llI1I1I11lIlIII1l1Ill1111III11llIll1IlIIl1I and _llIl1l1ll1IlIIIl1I1II1ll1111Il1lIl1l1l1111l)
_llll1I1IIIll1lI1I11l1II11llIlll = (_llll1I1IIIll1lI1I11l1II11llIlll + _llIlIl1l1llI111I1IlI1111l1lll11l1llll1I) - 2 * (_llll1I1IIIll1lI1I11l1II11llIlll and _llIlIl1l1llI111I1IlI1111l1lll11l1llll1I)
_llll1I1IIIll1lI1I11l1II11llIlll = (_llll1I1IIIll1lI1I11l1II11llIlll + _llIIIl1l1I1IIIlIll1lIIIl1Il1lII1I11lI1l11ll) - 2 * (_llll1I1IIIll1lI1I11l1II11llIlll and _llIIIl1l1I1IIIlIll1lIIIl1Il1lII1I11lI1l11ll)
_ll1IlIIlI1Il1II1I1I1l1l1llll11IIlll[_lllIIIllIllI1Il111I1Illl1Il1lI1lII11lll1I1l] = _llll1I1IIIll1lI1I11l1II11llIlll and 255
_llIl1l1ll1IlIIIl1I1II1ll1111Il1lIl1l1l1111l = _llI1I1I11lIlIII1l1Ill1111III11llIll1IlIIl1I
end for
return Mid(_ll1IlIIlI1Il1II1I1I1l1l1llll11IIlll.ToAsciiString(), 2)
end function
function _llll1llI11II1111II11lI1lllIII1l1lI11IIl1lIl(_ll1llIl11llllII1I1ll111IlI1I1lIl1lIIl1l as String) as String
if _ll1llIl11llllII1I1ll111IlI1I1lIl1lIIl1l = "" then return ""
_lll1lI11llI1IllIllI1l1ll1ll1lII1Ill1I11 = CreateObject("roByteArray")
_lll1lI11llI1IllIllI1l1ll1ll1lII1Ill1I11.FromHexString(_ll1llIl11llllII1I1ll111IlI1I1lIl1lIIl1l)
_llllI11lI111llII11IIlIII11I11I11l1Ill11lIl1 = _lll1lI11llI1IllIllI1l1ll1ll1lII1Ill1I11.Count()
if _llllI11lI111llII11IIlIII11I11I11l1Ill11lIl1 < 2 then return ""
_ll1llll11II1I1lllI1I1IIIlllIlI1 = _lll1lI11llI1IllIllI1l1ll1ll1lII1Ill1I11[0]
_llIIIIll1l1l11111ll1llIlIl1ll1I = (_ll1llll11II1I1lllI1I1IIIlllIlI1 * 53 + 29) and 255
_ll1IllIIllIII11IlI1IIllIll1llll1lI1lIIl = (_ll1llll11II1I1lllI1I1IIIlllIlI1 * 71 + 31) and 255
for _ll11IIIIII11llIl111IlII1II1l1IIlIl11llI = 1 to _llllI11lI111llII11IIlIII11I11I11l1Ill11lIl1 - 1
_ll1Il1lllIl111Il1IIl11I111IllIIlllI11lI1II1 = (_lll1lI11llI1IllIllI1l1ll1ll1lII1Ill1I11[_ll11IIIIII11llIl111IlII1II1l1IIlIl11llI] - ((_ll11IIIIII11llIl111IlII1II1l1IIlIl11llI - 1) * 5 + _ll1IllIIllIII11IlI1IIllIll1llll1lI1lIIl)) and 255
_ll1Il1lllIl111Il1IIl11I111IllIIlllI11lI1II1 = (((_ll1Il1lllIl111Il1IIl11I111IllIIlllI11lI1II1 \ 16) or ((_ll1Il1lllIl111Il1IIl11I111IllIIlllI11lI1II1 * 16) and 255))) and 255
_lll1lI11llI1IllIllI1l1ll1ll1lII1Ill1I11[_ll11IIIIII11llIl111IlII1II1l1IIlIl11llI] = (_ll1Il1lllIl111Il1IIl11I111IllIIlllI11lI1II1 + _llIIIIll1l1l11111ll1llIlIl1ll1I) - 2 * (_ll1Il1lllIl111Il1IIl11I111IllIIlllI11lI1II1 and _llIIIIll1l1l11111ll1llIlIl1ll1I)
end for
return Mid(_lll1lI11llI1IllIllI1l1ll1ll1lII1Ill1I11.ToAsciiString(), 2)
end function
function _lll11l1IIllIlll1Il11Il1lllIIIlllIlII11lI1I1(_lll1l1llI1ll11I11II1lll11l11l1I1I1l11lI as String) as String
if _lll1l1llI1ll11I11II1lll11l11l1I1I1l11lI = "" then return ""
_llll1l11lI1l11Il1llI11lI1III1II = CreateObject("roByteArray")
_llll1l11lI1l11Il1llI11lI1III1II.FromHexString(_lll1l1llI1ll11I11II1lll11l11l1I1I1l11lI)
_llIlllIIIl1II1IIlIlI111lII1Il1lll1l = _llll1l11lI1l11Il1llI11lI1III1II.Count()
if _llIlllIIIl1II1IIlIlI111lII1Il1lll1l < 2 then return ""
_ll1I1IIl11lIIIlI11llll1lIIIllllII1l1I11 = _llll1l11lI1l11Il1llI11lI1III1II[0]
_lll1l1l1I1l11I1l1111llll111l1lIlIl1 = (_ll1I1IIl11lIIIlI11llll1lIIIllllII1l1I11 * 67 + 43) and 255
_ll1I1II11II1ll1II1lll1lIIIlIl1IIllll1lI = (_ll1I1IIl11lIIIlI11llll1lIIIllllII1l1I11 * 79 + 17) and 255
for _llI1lIllIlII1lllIllllII111ll1l1lIlI = 1 to _llIlllIIIl1II1IIlIlI111lII1Il1lll1l - 1
_ll1IIlI1III11lIl1l11l111l1I1II111lI11ll = (_llll1l11lI1l11Il1llI11lI1III1II[_llI1lIllIlII1lllIllllII111ll1l1lIlI] - ((_llI1lIllIlII1lllIllllII111ll1l1lIlI - 1) * 11 + _ll1I1II11II1ll1II1lll1lIIIlIl1IIllll1lI)) and 255
_ll1IIlI1III11lIl1l11l111l1I1II111lI11ll = ((((_ll1IIlI1III11lIl1l11l111l1I1II111lI11ll \ 8) or ((_ll1IIlI1III11lIl1l11l111l1I1II111lI11ll * 32) and 255)))) and 255
_llll1l11lI1l11Il1llI11lI1III1II[_llI1lIllIlII1lllIllllII111ll1l1lIlI] = (_ll1IIlI1III11lIl1l11l111l1I1II111lI11ll + _lll1l1l1I1l11I1l1111llll111l1lIlIl1) - 2 * (_ll1IIlI1III11lIl1l11l111l1I1II111lI11ll and _lll1l1l1I1l11I1l1111llll111l1lIlIl1)
end for
return Mid(_llll1l11lI1l11Il1llI11lI1III1II.ToAsciiString(), 2)
end function
function _lllIIl1IIl11l1lll11l1lI111IlI1I1lII(_ll11Il11lI1IIllll1IIllI1111l1l111II as String) as String
if _ll11Il11lI1IIllll1IIllI1111l1l111II = "" then return ""
_lllll1I11l11I1IlI1IlIIII1llI11l1lIlIl1lI11I = CreateObject("roByteArray")
_lllll1I11l11I1IlI1IlIIII1llI11l1lIlIl1lI11I.FromHexString(_ll11Il11lI1IIllll1IIllI1111l1l111II)
_ll11lI1IlI11lIll1lIl1l1l1l1111l11I1 = _lllll1I11l11I1IlI1IlIIII1llI11l1lIlIl1lI11I.Count()
if _ll11lI1IlI11lIll1lIl1l1l1l1111l11I1 < 2 then return ""
_ll1l111IllIIlllIlIlIIIlI11lllll1IIl = _lllll1I11l11I1IlI1IlIIII1llI11l1lIlIl1lI11I[0]
_ll11ll11IlIIlllIIIlIl1lll1111l11l111I1lI1l1 = (_ll1l111IllIIlllIlIlIIIlI11lllll1IIl * 73 + 19) and 255
_ll1Il1l1IIIl1I1Ill1II111111l111llIlIlIl = (_ll1l111IllIIlllIlIlIIIlI11lllll1IIl * 83 + 37) and 255
for _ll111llIII1I1I11IlI1I1l1l1lllI11III = 1 to _ll11lI1IlI11lIll1lIl1l1l1l1111l11I1 - 1
_lllIIlllI1I11lllllI1lllI111l1ll1IIlII11 = _ll111llIII1I1I11IlI1I1l1l1lllI11III - 1
_ll11l11I1ll11l11lIII11l1l1l11l1lI1l = _lllll1I11l11I1IlI1IlIIII1llI11l1lIlIl1lI11I[_ll111llIII1I1I11IlI1I1l1l1lllI11III]
_ll11l11I1ll11l11lIII11l1l1l11l1lI1l = ((((_ll11l11I1ll11l11lIII11l1l1l11l1lI1l \ 4) or ((_ll11l11I1ll11l11lIII11l1l1l11l1lI1l * 64) and 255)))) and 255
_llI1lI1l1ll1I1IIl1lIll1lllI11II = (_lllIIlllI1I11lllllI1lllI111l1ll1IIlII11 * 13 + _ll1l111IllIIlllIlIlIIIlI11lllll1IIl) and 255
_ll11l11I1ll11l11lIII11l1l1l11l1lI1l = (_ll11l11I1ll11l11lIII11l1l1l11l1lI1l + _llI1lI1l1ll1I1IIl1lIll1lllI11II) - 2 * (_ll11l11I1ll11l11lIII11l1l1l11l1lI1l and _llI1lI1l1ll1I1IIl1lIll1lllI11II)
_ll11l11I1ll11l11lIII11l1l1l11l1lI1l = (_ll11l11I1ll11l11lIII11l1l1l11l1lI1l - (_lllIIlllI1I11lllllI1lllI111l1ll1IIlII11 * 7 + _ll1Il1l1IIIl1I1Ill1II111111l111llIlIlIl)) and 255
_ll11l11I1ll11l11lIII11l1l1l11l1lI1l = ((((_ll11l11I1ll11l11lIII11l1l1l11l1lI1l \ 16) or ((_ll11l11I1ll11l11lIII11l1l1l11l1lI1l * 16) and 255)))) and 255
_lllll1I11l11I1IlI1IlIIII1llI11l1lIlIl1lI11I[_ll111llIII1I1I11IlI1I1l1l1lllI11III] = (_ll11l11I1ll11l11lIII11l1l1l11l1lI1l + _ll11ll11IlIIlllIIIlIl1lll1111l11l111I1lI1l1) - 2 * (_ll11l11I1ll11l11lIII11l1l1l11l1lI1l and _ll11ll11IlIIlllIIIlIl1lll1111l11l111I1lI1l1)
end for
return Mid(_lllll1I11l11I1IlI1IlIIII1llI11l1lIlIl1lI11I.ToAsciiString(), 2)
end function
function _lllIIl1IlIlIllllII1lIlll1IIlllI(_ll11llIIIIl11l1llI11I1l1IlI1IllIll1I1Il as String) as String
if _ll11llIIIIl11l1llI11I1l1IlI1IllIll1I1Il = "" then return ""
_llIlIIlI11Ill11III1I1Il1IlIlIII1IIl = CreateObject("roByteArray")
_llIlIIlI11Ill11III1I1Il1IlIlIII1IIl.FromHexString(_ll11llIIIIl11l1llI11I1l1IlI1IllIll1I1Il)
_llIllll1IIl1I1IIllI11l1lI1IllIl1I1lllI1 = _llIlIIlI11Ill11III1I1Il1IlIlIII1IIl.Count()
if _llIllll1IIl1I1IIllI11l1lI1IllIl1I1lllI1 < 2 then return ""
_lll11IIl1IIII1IlI1II1Il1I1llll1lI1I11III11I = _llIlIIlI11Ill11III1I1Il1IlIlIII1IIl[0]
_ll1IIIll1I111lll1lIllIIIIl1IIlI = (_lll11IIl1IIII1IlI1II1Il1I1llll1lI1I11III11I * 97 + 53) and 255
_ll11llI1IIII11ll11lIIIll1lllI11Ill1 = (_lll11IIl1IIII1IlI1II1Il1I1llll1lI1I11III11I * 103 + 61) and 255
for _lllI11Illl1lI11Il1lIIlllIIl11II = 1 to _llIllll1IIl1I1IIllI11l1lI1IllIl1I1lllI1 - 1
_ll1IlIlll1I1IllIlIlIl11llI1I111l1lII1lII1ll = _lllI11Illl1lI11Il1lIIlllIIl11II - 1
_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II = _llIlIIlI11Ill11III1I1Il1IlIlIII1IIl[_lllI11Illl1lI11Il1lIIlllIIl11II]
_llllllIII1IllI11lIll1lIll1lIlIIl1lIIIll = (_ll1IlIlll1I1IllIlIlIl11llI1I111l1lII1lII1ll * 19 + _lll11IIl1IIII1IlI1II1Il1I1llll1lI1I11III11I) and 255
_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II = (_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II + _llllllIII1IllI11lIll1lIll1lIlIIl1lIIIll) - 2 * (_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II and _llllllIII1IllI11lIll1lIll1lIlIIl1lIIIll)
_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II = ((((_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II \ 4) or ((_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II * 64) and 255)))) and 255
_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II = (_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II - (_ll1IlIlll1I1IllIlIlIl11llI1I111l1lII1lII1ll * 17 + _ll11llI1IIII11ll11lIIIll1lllI11Ill1)) and 255
_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II = ((((_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II \ 8) or ((_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II * 32) and 255)))) and 255
_llIlIIlI11Ill11III1I1Il1IlIlIII1IIl[_lllI11Illl1lI11Il1lIIlllIIl11II] = (_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II + _ll1IIIll1I111lll1lIllIIIIl1IIlI) - 2 * (_lllIII1Il1lI1IlIII1I1I111Il1IlIl1II and _ll1IIIll1I111lll1lIllIIIIl1IIlI)
end for
return Mid(_llIlIIlI11Ill11III1I1Il1IlIlIII1IIl.ToAsciiString(), 2)
end function
function _ll1lII1IlIl11111III11l11I1lI1111111(_ll1l11Il11I111I1IlIl11I111I11IIIlIllI11l1I1 as String) as String
if _ll1l11Il11I111I1IlIl11I111I11IIIlIllI11l1I1 = "" then return ""
_ll11l1IllIlIlIIlll1I1ll1I1l111Il1ll = CreateObject("roByteArray")
_ll11l1IllIlIlIIlll1I1ll1I1l111Il1ll.FromHexString(_ll1l11Il11I111I1IlIl11I111I11IIIlIllI11l1I1)
_llIIl11lI1Il1Illll1III1l1lIlIIIIlIII11I = _ll11l1IllIlIlIIlll1I1ll1I1l111Il1ll.Count()
if _llIIl11lI1Il1Illll1III1l1lIlIIIIlIII11I < 2 then return ""
_lllII11I11lllI1IIII11l11ll1ll1I11IIIlIl1lIl = _ll11l1IllIlIlIIlll1I1ll1I1l111Il1ll[0]
_llI1Ill1l11111lIl11ll1IlIlll1Il = (_lllII11I11lllI1IIII11l11ll1ll1I11IIIlIl1lIl * 109 + 47) and 255
_llIl1lI11Il1ll1I11lI11l1I111IlllIlI = (_lllII11I11lllI1IIII11l11ll1ll1I11IIIlIl1lIl * 113 + 71) and 255
for _ll1llI11llIll1I111l1ll1I11l1l1IIllI1ll1lIII = 1 to _llIIl11lI1Il1Illll1III1l1lIlIIIIlIII11I - 1
_lll11Il1I1l1llll1l1IIll11lII1I1 = _ll1llI11llIll1I111l1ll1I11l1l1IIllI1ll1lIII - 1
_llI1IIIIlIllll11ll1IIlII11ll11l = _ll11l1IllIlIlIIlll1I1ll1I1l111Il1ll[_ll1llI11llIll1I111l1ll1I11l1l1IIllI1ll1lIII]
_llI1IIIIlIllll11ll1IIlII11ll11l = (_llI1IIIIlIllll11ll1IIlII11ll11l + _llIl1lI11Il1ll1I11lI11l1I111IlllIlI) - 2 * (_llI1IIIIlIllll11ll1IIlII11ll11l and _llIl1lI11Il1ll1I11lI11l1I111IlllIlI)
_llI1IIIIlIllll11ll1IIlII11ll11l = (_llI1IIIIlIllll11ll1IIlII11ll11l + (_lll11Il1I1l1llll1l1IIll11lII1I1 * 7 + _lllII11I11lllI1IIII11l11ll1ll1I11IIIlIl1lIl)) and 255
_llI1IIIIlIllll11ll1IIlII11ll11l = ((((_llI1IIIIlIllll11ll1IIlII11ll11l \ 16) or ((_llI1IIIIlIllll11ll1IIlII11ll11l * 16) and 255)))) and 255
_llI1IIIIlIllll11ll1IIlII11ll11l = (_llI1IIIIlIllll11ll1IIlII11ll11l - (_lll11Il1I1l1llll1l1IIll11lII1I1 * 3 + _llIl1lI11Il1ll1I11lI11l1I111IlllIlI)) and 255
_llI1IIIIlIllll11ll1IIlII11ll11l = (_llI1IIIIlIllll11ll1IIlII11ll11l * 43) and 255
_ll11l1IllIlIlIIlll1I1ll1I1l111Il1ll[_ll1llI11llIll1I111l1ll1I11l1l1IIllI1ll1lIII] = (_llI1IIIIlIllll11ll1IIlII11ll11l + _llI1Ill1l11111lIl11ll1IlIlll1Il) - 2 * (_llI1IIIIlIllll11ll1IIlII11ll11l and _llI1Ill1l11111lIl11ll1IlIlll1Il)
end for
return Mid(_ll11l1IllIlIlIIlll1I1ll1I1l111Il1ll.ToAsciiString(), 2)
end function