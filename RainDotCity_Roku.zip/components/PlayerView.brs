sub init()
m.videoPlayer = m.top.findNode(_l1d_2b697b("a6bababcc98fcec4bfcec0", 209, 255))
m.statusOverlay = m.top.findNode(_l1d_2b697b("aaa6beacb0b9b0baccc4d9d9d4", 84, 131))
m.statusTitle = m.top.findNode(_l1d_2b697b("7b7f8f85898aaea694afab", 176, 184))
m.statusText = m.top.findNode(_l1d_2b697b("2c36243c3e3b65374f4e", 163, 92))
m.cancelBtn = m.top.findNode(_l1d_2b697b("a0a599a9aaa491c2ab", 206, 243))
m.menuOverlay = m.top.findNode(_l1d_2b697b("919c94b2bbb5abbfa8b8c3", 174, 206))
m.menuTitle = m.top.findNode(_l1d_2b697b("dfdae8f0d4eafaf5ef", 65, 179))
m.menuTime = m.top.findNode(_l1d_2b697b("58535f492b636a65", 16, 219))
m.menuBtnBar = m.top.findNode(_l1d_2b697b("b7c2bab8e4bdc6edd3c3", 186, 224))
m.fitModes = [
{ label: _l1d_2b697b("3c6f63737680c15e8e76c3d0c2c6c9d7dfea7f93afb2f8", 87, 56),  sx: 1.00, sy: 1.00 },
{ label: _l1d_2b697b("4e8175898c9acf789c8cd5ded8d7eaeaf581bfbdbec4b309", 209, 204), sx: 0.95, sy: 0.95 },
{ label: _l1d_2b697b("a9bccec0c3cb8ca9dbe1ae9bb7b1a1a7b2dcf1edf3b9e8e9cb", 134, 212), sx: 0.90, sy: 0.90 },
{ label: _l1d_2b697b("74675b6f7280b59e8272bbc4bfbdd0d0dbb7a6a78fa1a69cf2", 113, 82), sx: 0.85, sy: 0.85 },
{ label: _l1d_2b697b("c6f9edfd000acbe81800cddad5d0dee6f1f5362e30ff", 151, 2),   sx: 0.80, sy: 0.80 }
]
_lII11ll = U_PrefDefault(_l1d_2b697b("c3c2b8d3c2d4ebcfdff9ded8da", 161, 242), 0)
if _lII11ll < 0 or _lII11ll >= m.fitModes.Count() then _lII11ll = 0
m.fitMode = _lII11ll
applyFitMode(m.fitMode)
m.cancelBtn.observeField(_l1d_2b697b("3a34363943455d56505c59516567", 58, 226), _l1d_2b697b("888ab293939ba09a", 168, 193))
m.menuBtnBar.observeField(_l1d_2b697b("3d4d51544c503e4f5b555a6c5e62", 199, 152), _l1d_2b697b("5e62826d6b63956a778d827e88897f9195", 57, 8))
m.videoPlayer.observeField(_l1d_2b697b("101208180a", 47, 180), _l1d_2b697b("8f916c9aa0a4a1809cb4a2b6", 220, 220))
m.videoPlayer.observeField(_l1d_2b697b("615968616967686c", 37, 12), _l1d_2b697b("2a2c11333a33413942441c4440504c4d", 192, 123))
end sub
sub applyFitMode(_l1Ill1l as Integer)
if m.fitModes = invalid or m.fitModes.Count() = 0 then return
if _l1Ill1l < 0 or _l1Ill1l >= m.fitModes.Count() then _l1Ill1l = 0
m.fitMode = _l1Ill1l
_llIll1l = m.fitModes[_l1Ill1l]
_l111l1l = 1920
_ll11l1l = 1080
_lIl1l1l = Int(_l111l1l * _llIll1l.sx)
_l1l1l1l = Int(_ll11l1l * _llIll1l.sy)
_lIIll1l = Int((_l111l1l - _lIl1l1l) / 2)
_lll1l1l = Int((_ll11l1l - _l1l1l1l) / 2)
if m.videoPlayer <> invalid then
m.videoPlayer.translation = [_lIIll1l, _lll1l1l]
m.videoPlayer.width = _lIl1l1l
m.videoPlayer.height = _l1l1l1l
end if
end sub
sub onFitClicked()
_l11I11l = (m.fitMode + 1) Mod m.fitModes.Count()
U_PrefSet(_l1d_2b697b("77968c8796887fa3938db2acae", 145, 150), _l11I11l)
applyFitMode(_l11I11l)
if m.menuOverlay <> invalid and m.menuOverlay.visible then
updateMenuButtons()
refocusMenuButton(_l1d_2b697b("31041810130dd6", 171, 57))
end if
end sub
sub refocusMenuButton(_l111lIl as String)
if m.menuBtnBar = invalid then return
_lIl1lIl = m.menuBtnBar.buttons
if _lIl1lIl = invalid then return
for _ll11lIl = 0 to _lIl1lIl.Count() - 1
if Left(_lIl1lIl[_ll11lIl], Len(_l111lIl)) = _l111lIl then
if _ll11lIl < m.menuBtnBar.getChildCount() then
m.menuBtnBar.getChild(_ll11lIl).setFocus(true)
end if
exit for
end if
end for
end sub
sub onPlayConfigChange()
_llllIIl = m.top.playConfig
if _llllIIl = invalid then return
m.currentConfig = _llllIIl
m.statusTitle.text = _llllIIl.title
m.menuTitle.text = _llllIIl.title
m.statusText.text = _l1d_2b697b("bcaea3aaaea7b9b5c109bbbbc0d2d9d01edbd2dadf2dfef4efeb18f2ee2401f7f7434649", 126, 144)
m.statusOverlay.visible = true
m.cancelBtn.setFocus(true)
applyFitMode(m.fitMode)
m.resolveTask = CreateObject(_l1d_2b697b("6b7b526963879397", 154, 131), _l1d_2b697b("629c89a8ac95ab78a09db7b6c58fbfb0cb", 82, 98))
m.resolveTask.imdbId = _llllIIl.imdbId
m.resolveTask.kind = _llllIIl.kind
if _llllIIl.season <> invalid then m.resolveTask.season = _llllIIl.season
if _llllIIl.episode <> invalid then m.resolveTask.episode = _llllIIl.episode
m.resolveTask.observeField(_l1d_2b697b("6f5d76735d78", 204, 177), _l1d_2b697b("292b634b48424140744e5b4a4e675d5f", 234, 164))
m.resolveTask.control = _l1d_2b697b("303822", 43, 183)
end sub
sub onStreamResolved()
_l1I1ll1 = m.resolveTask.result
if _l1I1ll1 <> invalid and _l1I1ll1.url <> invalid and _l1I1ll1.url <> "" then
m.statusText.text = _l1d_2b697b("885a6a6d736775717d45968c8783b08a86bc998f8f69bb9ba0b2b9b0707376", 62, 12)
startPlayback(_l1I1ll1)
else
m.statusText.text = _l1d_2b697b("77676a6a70bba49a7e7f757483b9918d839b89949a9296a39febe0d3b8aebfc2f2d8b9c9c1c6d015", 224, 210)
end if
end sub
sub startPlayback(_l1l1Il1 as Object)
_lIl1Il1 = CreateObject(_l1d_2b697b("9391b8afbb9d9799", 161, 192), _l1d_2b697b("8baaaec7b9b7d09dbfc9cb", 137, 193))
_lIl1Il1.url = _l1l1Il1.url
_lIl1Il1.StreamFormat = _l1d_2b697b("181f33", 43, 213)
if _l1l1Il1.streamFormat <> invalid then _lIl1Il1.StreamFormat = _l1l1Il1.streamFormat
_lIl1Il1.Title = m.currentConfig.title
if _l1l1Il1.referer <> invalid and _l1l1Il1.referer <> "" then
_llIlIl1 = [
_l1d_2b697b("38323238243e2ae502", 58, 208) + _l1l1Il1.referer,
_l1d_2b697b("fe23142852011e231b387572", 206, 99) + _l1l1Il1.userAgent
]
_lIl1Il1.HttpSendClientHeaders = _llIlIl1
end if
applyFitMode(m.fitMode)
_lIIlIl1 = 0
if m.currentConfig.kind = _l1d_2b697b("6667", 163, 143) then
_lll1Il1 = 1
_lI1lIl1 = 1
if m.currentConfig.season <> invalid then _lll1Il1 = m.currentConfig.season
if m.currentConfig.episode <> invalid then _lI1lIl1 = m.currentConfig.episode
_l1IlIl1 = W_GetEpisodeProgress(m.currentConfig.imdbId, "", _lll1Il1, _lI1lIl1)
if _l1IlIl1 <> invalid and _l1IlIl1.pos <> invalid and _l1IlIl1.pos > 30 and not _l1IlIl1.done then
_lIIlIl1 = _l1IlIl1.pos
end if
else
_l1IlIl1 = W_GetMovieProgress(m.currentConfig.imdbId, "")
if _l1IlIl1 <> invalid and _l1IlIl1.pos <> invalid and _l1IlIl1.pos > 30 and not _l1IlIl1.done then
_lIIlIl1 = _l1IlIl1.pos
end if
end if
m.videoPlayer.content = _lIl1Il1
m.videoPlayer.control = _l1d_2b697b("250c1c27", 174, 71)
if _lIIlIl1 > 0 then
m.videoPlayer.seek = _lIIlIl1
end if
m.videoPlayer.setFocus(true)
end sub
sub onVideoState()
_ll1Il11 = m.videoPlayer.state
if _ll1Il11 = _l1d_2b697b("1b1a102b1e2822", 33, 202) then
m.statusOverlay.visible = false
else if _ll1Il11 = _l1d_2b697b("5765595c5e7660606c", 12, 233) then
m.statusOverlay.visible = true
m.statusText.text = _l1d_2b697b("8591a7aaaaa4bcbeb8fe93c3ced0a9d5bfb7e0c8d622b6d4dde9f0f73d4043", 213, 238)
else if _ll1Il11 = _l1d_2b697b("33313137543c4446", 172, 105) then
saveProgress()
m.videoPlayer.control = _l1d_2b697b("a0a2aaac", 159, 180)
m.top.closePlayer = true
else if _ll1Il11 = _l1d_2b697b("493f425848", 247, 183) then
m.statusOverlay.visible = true
m.statusText.text = _l1d_2b697b("ea111f0a28282d2872302a2d3333843c4b4e3b4548545895a2355a665f62b4587973817e7abf", 221, 93)
m.cancelBtn.setFocus(true)
end if
end sub
sub onPositionChange()
_l1l1I11 = m.videoPlayer.position
_ll11I11 = m.videoPlayer.duration
if _ll11I11 > 0 then
_lIl1I11 = formatTime(_l1l1I11) + _l1d_2b697b("04fa0a", 78, 150) + formatTime(_ll11I11)
m.menuTime.text = _lIl1I11
end if
end sub
sub performSeek(_l1ll1I1 as Integer)
_lIIIlI1 = m.videoPlayer.position
_llll1I1 = m.videoPlayer.duration
_lIll1I1 = _lIIIlI1 + _l1ll1I1
if _lIll1I1 < 0 then _lIll1I1 = 0
if _llll1I1 > 0 and _lIll1I1 > _llll1I1 - 2 then _lIll1I1 = _llll1I1 - 2
m.videoPlayer.seek = _lIll1I1
end sub
sub showMenu()
if ((89307 - 9923 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.menuOverlay.visible = true
_llI1II1 = m.videoPlayer.duration
m.menuTime.text = formatTime(m.videoPlayer.position) + _l1d_2b697b("54525a", 186, 186) + formatTime(_llI1II1)
updateMenuButtons()
m.menuBtnBar.setFocus(true)
if m.menuBtnBar.getChildCount() > 0 then
m.menuBtnBar.getChild(0).setFocus(true)
end if
end sub
sub hideMenu()
m.menuOverlay.visible = false
m.videoPlayer.setFocus(true)
end sub
sub updateMenuButtons()
if ((37024 - 9256 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.menuBtnBar = invalid or m.fitModes = invalid then return
_l11IIlI = m.fitModes[m.fitMode].label
_ll1IIlI = [_l1d_2b697b("b7a09169767f7a75b5a8877d9882868792", 227, 218), _l11IIlI, _l1d_2b697b("703b3c580b654760694f1d181c2e347d26", 45, 242), _l1d_2b697b("f9c9dee0d6e8e9a0ddf4dadfaf10f0f1f2f0f3fbf903", 47, 124)]
if m.currentConfig <> invalid and m.currentConfig.kind = _l1d_2b697b("1112", 127, 6) then
_ll1IIlI.Push(_l1d_2b697b("5d452d3c8b71414b48576163a394", 249, 166))
if m.currentConfig.episode <> invalid and m.currentConfig.episode > 1 then
_ll1IIlI.Push(_l1d_2b697b("0312654a584c6a6b545d2d8d637f6c837b7f", 180, 123))
end if
end if
_ll1IIlI.Push(_l1d_2b697b("e1e9fbfb4add0c12fd1c0a", 91, 195))
m.menuBtnBar.buttons = _ll1IIlI
for _lI1IIlI = 0 to m.menuBtnBar.getChildCount() - 1
_lIlIIlI = m.menuBtnBar.getChild(_lI1IIlI)
_lIlIIlI.minWidth = 800
_lIlIIlI.height = 48
end for
end sub
sub onMenuBtnSelected()
_l1l111I = m.menuBtnBar.buttonSelected
_lll111I = m.menuBtnBar.buttons
if _lll111I = invalid or _l1l111I < 0 or _l1l111I >= _lll111I.Count() then return
_lIl111I = _lll111I[_l1l111I]
if Left(_lIl111I, 8) = _l1d_2b697b("cced7eb0a5a6b1bc", 222, 236) then
hideMenu()
if m.videoPlayer.state = _l1d_2b697b("43374e4f4446", 200, 139) then m.videoPlayer.control = _l1d_2b697b("6278696e8984", 176, 160)
else if Left(_lIl111I, 7) = _l1d_2b697b("6b9e909ea1ad6a", 20, 36) or Left(_lIl111I, 4) = _l1d_2b697b("76646abb", 100, 84) then
onFitClicked()
else if Left(_lIl111I, 10) = _l1d_2b697b("e6f1f20cbfdbfb141d05", 140, 7) then
hideMenu()
performSeek(85)
else if Left(_lIl111I, 7) = _l1d_2b697b("4d3d32344a3c3d", 127, 32) then
hideMenu()
m.videoPlayer.seek = 0
m.videoPlayer.control = _l1d_2b697b("f301faf7120d", 20, 141)
else if Left(_lIl111I, 7) = _l1d_2b697b("a9977d8c5bc391", 186, 181) then
onNextEpClicked()
else if Left(_lIl111I, 6) = _l1d_2b697b("4a41f4150f1f", 202, 84) then
onPrevEpClicked()
else if _lIl111I = _l1d_2b697b("debed0b88fe2d9d7d2d9d3", 181, 238) then
onStopClicked()
end if
end sub
sub onNextEpClicked()
if ((35076 - 8769 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
hideMenu()
saveProgress()
if m.currentConfig <> invalid and m.currentConfig.episode <> invalid then
m.currentConfig.episode = m.currentConfig.episode + 1
m.currentConfig.title = Left(m.currentConfig.title, Instr(1, m.currentConfig.title, _l1d_2b697b("b3bbb9cf", 20, 127)) - 1) + _l1d_2b697b("7e868416", 214, 136) + m.currentConfig.season.ToStr() + _l1d_2b697b("39a1", 176, 169) + m.currentConfig.episode.ToStr()
onPlayConfigChange()
end if
end sub
sub onPrevEpClicked()
hideMenu()
saveProgress()
if m.currentConfig <> invalid and m.currentConfig.episode <> invalid and m.currentConfig.episode > 1 then
m.currentConfig.episode = m.currentConfig.episode - 1
m.currentConfig.title = Left(m.currentConfig.title, Instr(1, m.currentConfig.title, _l1d_2b697b("4c4c5288", 8, 36)) - 1) + _l1d_2b697b("6a707000", 87, 243) + m.currentConfig.season.ToStr() + _l1d_2b697b("53b9", 51, 64) + m.currentConfig.episode.ToStr()
onPlayConfigChange()
end if
end sub
sub onStopClicked()
if ((42260 - 8452 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
hideMenu()
stopAndExit()
end sub
sub stopAndExit()
saveProgress()
if m.resolveTask <> invalid then m.resolveTask.control = _l1d_2b697b("c4ccd6ce", 58, 91)
if m.videoPlayer <> invalid then
m.videoPlayer.control = _l1d_2b697b("bfbfa9c9", 142, 194)
m.videoPlayer.content = invalid
end if
m.top.closePlayer = true
end sub
sub saveProgress()
if ((32520 - 4065 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.currentConfig = invalid then return
_lIIll1l = Int(m.videoPlayer.position)
_l111l1l = Int(m.videoPlayer.duration)
if _l111l1l <= 0 or _lIIll1l <= 0 then return
_l1l1l1l = m.currentConfig.kind
if _l1l1l1l = invalid or _l1l1l1l = "" then _l1l1l1l = _l1d_2b697b("d1d6c0ded5", 212, 24)
_lIl1l1l = ""
if m.currentConfig.poster <> invalid then _lIl1l1l = m.currentConfig.poster
W_RememberContext(m.currentConfig.imdbId, {
title:  m.currentConfig.title,
kind:   _l1l1l1l,
imdb:   m.currentConfig.imdbId,
poster: _lIl1l1l
})
if _l1l1l1l = _l1d_2b697b("6d72", 232, 209) then
_ll11l1l = 1
_lll1l1l = 1
if m.currentConfig.season <> invalid then _ll11l1l = m.currentConfig.season
if m.currentConfig.episode <> invalid then _lll1l1l = m.currentConfig.episode
W_SaveEpisodeProgress(m.currentConfig.imdbId, "", _ll11l1l, _lll1l1l, _lIIll1l, _l111l1l, "", m.currentConfig.title, 0, 0)
else
W_SaveMovieProgress(m.currentConfig.imdbId, "", _lIIll1l, _l111l1l)
end if
end sub
sub onCancel()
stopAndExit()
end sub
function formatTime(_l1lIlIl as Float) as String
if ((38486 - 5498 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lII1lIl = Int(_l1lIlIl)
if _lII1lIl < 0 then _lII1lIl = 0
_l111lIl = _lII1lIl \ 3600
_lI11lIl = (_lII1lIl mod 3600) \ 60
_l1I1lIl = _lII1lIl mod 60
_lllIlIl = _l1I1lIl.ToStr()
if _l1I1lIl < 10 then _lllIlIl = _l1d_2b697b("49", 6, 19) + _lllIlIl
_llI1lIl = _lI11lIl.ToStr()
if _lI11lIl < 10 and _l111lIl > 0 then _llI1lIl = _l1d_2b697b("dd", 88, 117) + _llI1lIl
if _l111lIl > 0 then
return _l111lIl.ToStr() + _l1d_2b697b("f3", 249, 48) + _llI1lIl + _l1d_2b697b("c2", 198, 198) + _lllIlIl
end if
return _llI1lIl + _l1d_2b697b("4d", 183, 192) + _lllIlIl
end function
function onKeyEvent(_lIllIIl as String, _ll1lIIl as Boolean) as Boolean
if not _ll1lIIl then return false
if m.menuOverlay.visible then
if _lIllIIl = _l1d_2b697b("44484944", 159, 71) then
hideMenu()
return true
else if _lIllIIl = _l1d_2b697b("ebe5e7fc", 103, 224) or _lIllIIl = _l1d_2b697b("5d6b78706f", 186, 149) then
return true
else if _lIllIIl = _l1d_2b697b("130910161f2319", 25, 157) then
onFitClicked()
return true
end if
return false
end if
if _lIllIIl = _l1d_2b697b("0a08fd0d14", 38, 182) or _lIllIIl = _l1d_2b697b("c8c4b9bfd4dec6ccd9cfe4", 81, 145) then
if not m.statusOverlay.visible then
performSeek(15)
return true
end if
else if _lIllIIl = _l1d_2b697b("e3efef04", 106, 221) or _lIllIIl = _l1d_2b697b("190b1c1d1916", 230, 133) then
if not m.statusOverlay.visible then
performSeek(-15)
return true
end if
end if
if _lIllIIl = _l1d_2b697b("7179", 183, 175) or _lIllIIl = _l1d_2b697b("848c7793", 179, 173) then
if not m.statusOverlay.visible then
showMenu()
return true
end if
end if
if _lIllIIl = _l1d_2b697b("3e4c4b494a4e5c", 69, 20) then
onFitClicked()
return true
end if
if _lIllIIl = _l1d_2b697b("aeb5", 54, 53) or _lIllIIl = _l1d_2b697b("1c33332e", 150, 54) then
if not m.statusOverlay.visible then
if m.videoPlayer.state = _l1d_2b697b("303f4530434953", 187, 101) then
m.videoPlayer.control = _l1d_2b697b("11051c1912", 42, 183)
else
m.videoPlayer.control = _l1d_2b697b("effff4f5100b", 23, 138)
end if
return true
end if
end if
if _lIllIIl = _l1d_2b697b("d6d6dbd6", 45, 135) then
stopAndExit()
return true
end if
return false
end function
function _l1d_2b697b(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function