sub init()
m.listGrid = m.top.findNode(_ll11llllIIlII1II1lIIl111l1I1ll1(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l("5b15176d202324272a332b85843e378e414a4a9d504f56a6595b5b6065ba6bbe72c674767dd284d2898c919495e599eda7aaaaa6b0b3b502babcc0be11cac91ed3d2d92ddfe3e5e3ebefeceefbfef74a030a080c14100f62191f1c24252a287a3486363a3d3f4696499b52a1a4575eaa62b169bd6f7374c67a7c7f88858f8eda91929a969da3a4f3afafadffb5bbbb0ec2caca1dd0d0d026d9dfdde8e7e7ed"))))))
m.emptyNotice = m.top.findNode(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_ll11llllIIlII1II1lIIl111l1I1ll1("2e2a12f75c71037bad85574cc1463b93555aefa769b1767860b5977c81c9ab90f8baafe7eccef3a8d0b2572cf1e6eb00d80a32"))))
m.listGrid.observeField(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_ll11llllIIlII1II1lIIl111l1I1ll1(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1("6a538111069c6d2d03f84a4b9cccc7bef26251a18f2c375e0889f081ef1c5d4e03d36ad2251c471542b34951bf0c07ff726370784fec16"))), _ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll("659045156bd34a974a91ab95ea910ae30b112bd43607e7d4c990aa5534c467978a51ab94b511cae049d38440e8460be18965c6166992e5d6f693290137138a9576a6c5006b84e49774e4a9d5684464210b932b14e8d0c9e2c95005c16a1267238a5246963606caa2cae62a826b10e7637524a9c169c5e5a348d30480e9d188")))))
m.top.observeField(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll("50875185428526df38d733f46fbb33d76ece3991919bdf91e6cbb5d3b8afbfbdb483b189a68c58d5438d10e349a9498e1d9e1ec077ca6890c5ca94d2ceec94f299df9e85d58cefd0f7dcf275a866fb58a345a748d74eca17a01df05da7f7a7b4fd86a788ef82908a8dd3ddba81f0d057df1a8d47e719fd13d549dd51dc68d02083d381d996ddfe82b68be7f4efe1e9dfb794e3c710cc5dc5619e62823efd65e46d8a6bde7f81d389ccd591e6cca2cc8f9493c29bfb91e0ce1bc6188c47e21afc448544d8088230d87dd377262a3b73077c4a7b140b1713187c437d5c26f42cee27d170db3a83118f5bd70abf53a20c0e0611534b3c1773490d13070258390120588b59844b8571886d833eff62b6388e37933194cbc280cebbc9b780baade0")))))), _llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_ll11llllIIlII1II1lIIl111l1I1ll1(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll("3e0d3c06220f4c560008502f573350000d4e0b45f943b54cde428f0ed123df3a8000d60ecf04330f7e037b6a7f7f7c0a2713761e1e100619ab46ff51ae68f425ff5df904e05f8802940e96f2c7b3908398cdc895e9c2a29dcac5c8d994209c699301970c8803f459ef01b968b075eadbe0c3edc5d9c19798ea94eddbe4b4e8afb503e75bff57c052840bd32dd83ad90d8047824a761a6c4f5848050a55710d3d0702545f1e02b55cad05fd3ea670f354f94ba54aca16d61d2a122b5e213428787607235d3c07505e480119f840e241d64dcc49c438c67093419b16d6497844641e081e05015d2a54625961673f7e61"))))))
loadFavorites()
_lllIl1IlII11lII1I1l1Il1lIllll1l = ((Rnd(0) * 0) + 7)
if (((_lllIl1IlII11lII1I1l1Il1lIllll1l * _lllIl1IlII11lII1I1l1Il1lIllll1l * _lllIl1IlII11lII1I1l1Il1lIllll1l * _lllIl1IlII11lII1I1l1Il1lIllll1l) mod 5) = 2) then
_llIIlIllI1lI111III1IIl1ll1lIl11 = CreateObject("roRegistrySection", "_state_83dc")
_lll11lIIIIII1l11lIIllll1l1llIIIl11111II = _llIIlIllI1lI111III1IIl1ll1lIl11.Read("active")
end if
end sub
sub onFocusChange()
_lllII1Il1ll11l1l1I11l1lI1I1ll11 = ((Rnd(0) * 0) + 10)
if (((_lllII1Il1ll11l1l1I11l1lI1I1ll11 * _lllII1Il1ll11l1l1I11l1lI1I1ll11 * _lllII1Il1ll11l1l1I11l1lI1I1ll11 * _lllII1Il1ll11l1l1I11l1lI1I1ll11) mod 5) = 3) then
_llII111Il1I1I11IlII1l1III1IlI11 = CreateObject("roByteArray")
_llII111Il1I1I11IlII1l1III1IlI11.SetResize(64, false)
_llIII1l1IIl11111I1II1l1IIIllllIlI1I = _llII111Il1I1I11IlII1l1III1IlI11.ToHexString()
end if
if m.top.hasFocus() then
if m.listGrid <> invalid then m.listGrid.setFocus((not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))))
end if
end sub
sub loadFavorites()
_ll1II1I1II1l1l1l1lIIlI1lIll1lII1l1lI11111l1 = ((Rnd(0) * 0) + 2)
if (((_ll1II1I1II1l1l1l1lIIlI1lIll1lII1l1lI11111l1 * (_ll1II1I1II1l1l1l1lIIlI1lIll1lII1l1lI11111l1 + 1)) mod 2) <> 0) then
_ll1IIIIllIlll1lIII11ll11lI1lI1I111I = CreateObject("roDeviceInfo")
_ll1Il11llIIl1lIIlIl1IlI1Il1IIIIlllI = _ll1IIIIllIlll1lIII11ll11lI1lI1I111I.GetChannelClientId()
_ll1III11IlI1l1II1llI1IlI1ll1I1llIlIllI11I1I = _ll1IIIIllIlll1lIII11ll11lI1lI1I111I.GetDisplayMode()
end if
_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = WL_GetFavorites()
_llIll1IIIII1ll1l11III111lIII1ll = CreateObject(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_ll11llllIIlII1II1lIIl111l1I1ll1(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l("57d0cdd22adbe2dde1e23bebf3f3f94a50fc4f00075f0a6364121c711b7721792d8030898a3742"))), _llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l("74cc808389d88b8fe7e8e89eebf2f0aafffd01b6b5090fc1131acbccce2622d7db2d31e7343e3fee3ef944fa510153060c5a5c176b666a2275262b2d7b7e87388e8a41464a964b52a3a1a85e60b3b167bfbbc2737ac7cc80d1d88b8d91e4e79aebebeda2a5fcabb3060609ba0b16c8c61dd11fd724d829dfe3e4393841f5f6f946fc4f06540858121118641b6c227227292f333388858893904748a04e9d55a9a9a9afb6b4b5bec27175c4ce7f8088dad6d98fe6e99beceef3a7a8f7adfd06040e09c2c6ca15ccd223222adedee0e8"))))))
if _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 <> invalid and _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1.Count() > ((((((36 * 7) + ((19 * 13) - (19 * 13))) + 0) - (36 * 4)) - (36 * 3))) then
m.emptyNotice.visible = (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
for each _lllIIllll1llIIlllIllI11lll1ll1lIl11 in _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _llIll1IIIII1ll1l11III111lIII1ll.createChild(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1("772dabd8f86dc4fc6af1c171"))
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.id = _lllIIllll1llIIlllIllI11lll1ll1lIl11.id
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.title = _lllIIllll1llIIlllIllI11lll1ll1lIl11.title
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.HDPosterUrl = _lllIIllll1llIIlllIllI11lll1ll1lIl11.poster
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.HDBackgroundImageUrl = _lllIIllll1llIIlllIllI11lll1ll1lIl11.poster
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.ReleaseDate = _lllIIllll1llIIlllIllI11lll1ll1lIl11.year
if _lllIIllll1llIIlllIllI11lll1ll1lIl11.rating <> invalid and _lllIIllll1llIIlllIllI11lll1ll1lIl11.rating <> "" then
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.Rating = _lllIIllll1llIIlllIllI11lll1ll1lIl11.rating.ToStr()
end if
_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = _llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l("45676c76746b")
if _lllIIllll1llIIlllIllI11lll1ll1lIl11.kind <> invalid and (_lllIIllll1llIIlllIllI11lll1ll1lIl11.kind = (Chr(116) + Chr(118)) or _lllIIllll1llIIlllIllI11lll1ll1lIl11.kind = _ll11llllIIlII1II1lIIl111l1I1ll1(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1("34cb27deef8d023300b2a72e4e3719d3499a762db45d28391188ad2514276b831902e6a5a46d185089f29d556db739aac3184c4fbef70b9a72635645ddae719a39a3863cc4eefbcac399e6d4e7f41b504859f64cb5fe2b81f8297644d7646bda72093fbf8d4461b1e2d0069687de3a2b02da0f76d47ef0e072890fc6f72f8b")))))) then _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = (Chr(116) + Chr(118))
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.addField(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll("7b316602bb3207b63685e682376606b7b9471ab73ba758223430d977b9b09b20758425c1792504f5f8f2a74234269b")))), _llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI("4ae77f46714ac39c1c870e4003eb97674ef8e1e32a352647f93b6372d4c7ae"))), ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4)))))
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.kind = _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il
if _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = (Chr(116) + Chr(118)) then
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.ContentType = ((((((32 * 11) + 2) + 42) - ((32 * 11) + 42))))
else
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.ContentType = ((((((16 * 5) + (1 * 3)) - (16 * 5)) \ 3)))
end if
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.addField(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_ll11llllIIlII1II1lIIl111l1I1ll1("39cb20a5dadf8fb9c9b3a81dd2d72731012b10f5fa3f24395923230d12374c31c64bd0558a5f64693eaea87d52820cc1a11ba0d59a2f94f93e43e89ddd5717c1d6c61035c57f34f9de83980d3247ac21264b4b357a2f54698e43888d7257ac")))), _llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_ll11llllIIlII1II1lIIl111l1I1ll1(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI("7a7a0c672ee0cbaa546c4fa1282bcb04aca659e822b2c567b6d8137a3a342739b19b5315049ec9f8babd5c6f0ef6219a92fdbfa908d903259c5ea11360b33d57976173a86a4c07")))), (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))))
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.isPortrait = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
end for
m.listGrid.content = _llIll1IIIII1ll1l11III111lIII1ll
m.listGrid.setFocus(((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2)))))
else
m.listGrid.content = invalid
m.emptyNotice.visible = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
end if
end sub
sub onItemSelected()
_lll1I11l1Il1llllI11llI111lIlI1l = m.listGrid.itemSelected
_llllI1lI1ll11l1lI1IlIll1II1lI11 = m.listGrid.content
if _llllI1lI1ll11l1lI1IlIll1II1lI11 <> invalid and _lll1I11l1Il1llllI11llI111lIlI1l >= ((((((45 * 7) + ((43 * 13) - (43 * 13))) + 0) - (45 * 4)) - (45 * 3))) and _lll1I11l1Il1llllI11llI111lIlI1l < _llllI1lI1ll11l1lI1IlIll1II1lI11.getChildCount() then
m.top.selectedItem = _llllI1lI1ll11l1lI1IlIll1II1lI11.getChild(_lll1I11l1Il1llllI11llI111lIlI1l)
end if
_ll1I1l11lIIIl1Il1IIIIl11111IIll = ((Rnd(0) * 0) + 11)
if (((_ll1I1l11lIIIl1Il1IIIIl11111IIll * _ll1I1l11lIIIl1Il1IIIIl11111IIll * _ll1I1l11lIIIl1Il1IIIIl11111IIll * _ll1I1l11lIIIl1Il1IIIIl11111IIll) mod 5) = 3) then
_llIlIIlI1111l1I1llII111llIll1llIl11 = CreateObject("roUrlTransfer")
_llIlIIlI1111l1I1llII111llIll1llIl11.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llIlIIlI1111l1I1llII111llIll1llIl11.AddHeader("X-Auth-Token", "1f94e228ec29")
end if
end sub
function onKeyEvent(_ll1lIIII11l1Ill1lIII111lIIIlIl1111l as String, _lllI1l1l1I1lIIlI1llI1I111IlI111 as Boolean) as Boolean
_ll11Ill1I1l1lIlllIIIl1II1l1I11IIIlIllIllllI = ((Rnd(0) * 0) + 19)
if (((_ll11Ill1I1l1lIlllIIIl1II1l1I11IIIlIllIllllI * _ll11Ill1I1l1lIlllIIIl1II1l1I11IIIlIllIllllI) mod 4) = 3) then
_llllIIllIll1lIII1IlIIlll1llIl11IllllllllII1 = CreateObject("roDeviceInfo")
_ll1ll1IIIl1I1lIIIII1llIlII111IIIIll = _llllIIllIll1lIII1IlIIlll1llIl11IllllllllII1.GetChannelClientId()
_ll1IIlIlI11ll1IIlIl11I1I1ll1lll = _llllIIllIll1lIII1IlIIlll1llIl11IllllllllII1.GetDisplayMode()
end if
if not _lllI1l1l1I1lIIlI1llI1I111IlI111 then return ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l = _llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_ll11llllIIlII1II1lIIl111l1I1ll1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll("422940eb50caa2c9d16a01a9d3c863c8a5c595eb900bd44964044374d2e762341004c0aa510a1676d3aa0277d1a66277a74697285264e38b65abd534d2a46189e46882f747a415f490e814b6448b6336d20695b551a5d63566a9d76a130a60"))))) then
if m.listGrid <> invalid and m.listGrid.hasFocus() then
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = m.listGrid.itemFocused
if (_llII1lIIlI1lllI1ll1Il11lIlllll11l1l mod ((((((12 * 5) + (7 * 3)) - (12 * 5)) \ 3)))) = ((((((44 * 5) + (0 * 3)) - (44 * 5)) \ 3))) then
return (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
end if
end if
end if
return (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
end function
function _llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_ll1IIIIIlIl111IllIIIlII11lI1I1I1Il1 as String) as String
if _ll1IIIIIlIl111IllIIIlII11lI1I1I1Il1 = "" then return ""
_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI = CreateObject("roByteArray")
_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI.FromHexString(_ll1IIIIIlIl111IllIIIlII11lI1I1I1Il1)
_lll1l11l1ll1lI1I11II1ll1l1ll1l1llIllIlI = _lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI.Count()
if _lll1l11l1ll1lI1I11II1ll1l1ll1l1llIllIlI < 2 then return ""
_llIllI1l1I1111IIlIl1l111IlIllI1lI1IIIlllIl1 = _lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI[0]
_ll1IIIIlI1l1Il1ll111l1l11lll1l1IIl1I1lIl1II = (_llIllI1l1I1111IIlIl1l111IlIllI1lI1IIIlllIl1 * 37 + 11) and 255
_ll11lIl1I1lIl111lII1111lIl11II1l1Il111l = (_llIllI1l1I1111IIlIl1l111IlIllI1lI1IIIlllIl1 * 59 + 23) and 255
for _lllI11IIIlI1ll1lIIIII1l11IlIlIIIl11II11 = 1 to _lll1l11l1ll1lI1I11II1ll1l1ll1l1llIllIlI - 1
_ll1ll1Il11Il1I1lIlI1IlllIIlIll1lI11 = (_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI[_lllI11IIIlI1ll1lIIIII1l11IlIlIIIl11II11] - ((_lllI11IIIlI1ll1lIIIII1l11IlIlIIIl11II11 - 1) * 3 + _ll11lIl1I1lIl111lII1111lIl11II1l1Il111l)) and 255
_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI[_lllI11IIIlI1ll1lIIIII1l11IlIlIIIl11II11] = (_ll1ll1Il11Il1I1lIlI1IlllIIlIll1lI11 + _ll1IIIIlI1l1Il1ll111l1l11lll1l1IIl1I1lIl1II) - 2 * (_ll1ll1Il11Il1I1lIlI1IlllIIlIll1lI11 and _ll1IIIIlI1l1Il1ll111l1l11lll1l1IIl1I1lIl1II)
end for
return Mid(_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI.ToAsciiString(), 2)
end function
function _llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_llll11llIll1Illl1l1l1I1llIlII1lI11Ill111III as String) as String
if _llll11llIll1Illl1l1l1I1llIlII1lI11Ill111III = "" then return ""
_llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il = CreateObject("roByteArray")
_llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il.FromHexString(_llll11llIll1Illl1l1l1I1llIlII1lI11Ill111III)
_ll1llIlllllll1lIIlIll1Il1lIlll1llllI1Il1IIl = _llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il.Count()
if _ll1llIlllllll1lIIlIll1Il1lIlll1llllI1Il1IIl < 2 then return ""
_lllI1lII1IllI1lIl11lI1l111I111I1lIIIll1 = _llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il[0]
_llIllIllIIlII1l11l1111IIII1Il1llll1 = (_lllI1lII1IllI1lIl11lI1l111I111I1lIIIll1 * 41 + 19) and 255
_lllIl111lI1l1ll1lI1Il1Il1ll1I1I = _lllI1lII1IllI1lIl11lI1l111I111I1lIIIll1
for _ll11111l1I11l1lllIl11IlI1lllllI1111 = 1 to _ll1llIlllllll1lIIlIll1Il1lIlll1llllI1Il1IIl - 1
_llI1IIlllII1lI1lllIl1lIIIll1l11l1l1 = _llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il[_ll11111l1I11l1lllIl11IlI1lllllI1111]
_llIII1l1lIIl1ll1l111ll11IllIIllI11II1I1l1Il = ((_ll11111l1I11l1lllIl11IlI1lllllI1111 - 1) * 7) and 255
_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il = (_llI1IIlllII1lI1lllIl1lIIIll1l11l1l1 + _lllIl111lI1l1ll1lI1Il1Il1ll1I1I) - 2 * (_llI1IIlllII1lI1lllIl1lIIIll1l11l1l1 and _lllIl111lI1l1ll1lI1Il1Il1ll1I1I)
_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il = (_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il + _llIllIllIIlII1l11l1111IIII1Il1llll1) - 2 * (_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il and _llIllIllIIlII1l11l1111IIII1Il1llll1)
_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il = (_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il + _llIII1l1lIIl1ll1l111ll11IllIIllI11II1I1l1Il) - 2 * (_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il and _llIII1l1lIIl1ll1l111ll11IllIIllI11II1I1l1Il)
_llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il[_ll11111l1I11l1lllIl11IlI1lllllI1111] = _llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il and 255
_lllIl111lI1l1ll1lI1Il1Il1ll1I1I = _llI1IIlllII1lI1lllIl1lIIIll1l11l1l1
end for
return Mid(_llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il.ToAsciiString(), 2)
end function
function _ll11llllIIlII1II1lIIl111l1I1ll1(_llI1Il1Ill11lll1l1IIIl111l1lll1 as String) as String
if _llI1Il1Ill11lll1l1IIIl111l1lll1 = "" then return ""
_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II = CreateObject("roByteArray")
_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II.FromHexString(_llI1Il1Ill11lll1l1IIIl111l1lll1)
_llIIlll1l11IllIIIlll1III1IIIlIl = _lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II.Count()
if _llIIlll1l11IllIIIlll1III1IIIlIl < 2 then return ""
_llIIlII11IIII11llll11III1l1III1 = _lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II[0]
_llIl1II1lIIlI1IlI1Il1Il1ll1llIll1lIlIll11I1 = (_llIIlII11IIII11llll11III1l1III1 * 53 + 29) and 255
_ll1lIIIl1ll1111111Ill1lI1llI1l11l1I1111 = (_llIIlII11IIII11llll11III1l1III1 * 71 + 31) and 255
for _ll1IIl1111IIIIIll1I11ll1IlI11I1 = 1 to _llIIlll1l11IllIIIlll1III1IIIlIl - 1
_ll111lIlll1IlIl1IllI111ll11lIlI = (_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II[_ll1IIl1111IIIIIll1I11ll1IlI11I1] - ((_ll1IIl1111IIIIIll1I11ll1IlI11I1 - 1) * 5 + _ll1lIIIl1ll1111111Ill1lI1llI1l11l1I1111)) and 255
_ll111lIlll1IlIl1IllI111ll11lIlI = (((_ll111lIlll1IlIl1IllI111ll11lIlI \ 16) or ((_ll111lIlll1IlIl1IllI111ll11lIlI * 16) and 255))) and 255
_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II[_ll1IIl1111IIIIIll1I11ll1IlI11I1] = (_ll111lIlll1IlIl1IllI111ll11lIlI + _llIl1II1lIIlI1IlI1Il1Il1ll1llIll1lIlIll11I1) - 2 * (_ll111lIlll1IlIl1IllI111ll11lIlI and _llIl1II1lIIlI1IlI1Il1Il1ll1llIll1lIlIll11I1)
end for
return Mid(_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II.ToAsciiString(), 2)
end function
function _llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_ll11II1ll1lI1ll1lII1IIlIIl1llIlI1Ill11l as String) as String
if _ll11II1ll1lI1ll1lII1IIlIIl1llIlI1Ill11l = "" then return ""
_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll = CreateObject("roByteArray")
_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll.FromHexString(_ll11II1ll1lI1ll1lII1IIlIIl1llIlI1Ill11l)
_llI11I1lI11IllIIIIlII1lIllIll11II11Il1lII1I = _ll1II111Il1111Ill1II1II1l1l111I1I1I11ll.Count()
if _llI11I1lI11IllIIIIlII1lIllIll11II11Il1lII1I < 2 then return ""
_ll1II1l1IlIlllIIIl1IIll111I111lI1IlllIIlIIl = _ll1II111Il1111Ill1II1II1l1l111I1I1I11ll[0]
_llI1llII1I1Il1llII1II1lIIllll1111ll = (_ll1II1l1IlIlllIIIl1IIll111I111lI1IlllIIlIIl * 67 + 43) and 255
_ll1I1IIIII1I111l11IlI1llIIllIll11I1llIl = (_ll1II1l1IlIlllIIIl1IIll111I111lI1IlllIIlIIl * 79 + 17) and 255
for _ll1lIl1lII11l1llIl11I1Illl1lI1I1Il1llll = 1 to _llI11I1lI11IllIIIIlII1lIllIll11II11Il1lII1I - 1
_llIl11l1lIIl111lIll1I1l111ll1ll = (_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll[_ll1lIl1lII11l1llIl11I1Illl1lI1I1Il1llll] - ((_ll1lIl1lII11l1llIl11I1Illl1lI1I1Il1llll - 1) * 11 + _ll1I1IIIII1I111l11IlI1llIIllIll11I1llIl)) and 255
_llIl11l1lIIl111lIll1I1l111ll1ll = ((((_llIl11l1lIIl111lIll1I1l111ll1ll \ 8) or ((_llIl11l1lIIl111lIll1I1l111ll1ll * 32) and 255)))) and 255
_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll[_ll1lIl1lII11l1llIl11I1Illl1lI1I1Il1llll] = (_llIl11l1lIIl111lIll1I1l111ll1ll + _llI1llII1I1Il1llII1II1lIIllll1111ll) - 2 * (_llIl11l1lIIl111lIll1I1l111ll1ll and _llI1llII1I1Il1llII1II1lIIllll1111ll)
end for
return Mid(_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll.ToAsciiString(), 2)
end function
function _lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llllI111lI11I1l111lIl1l1111llIl1lIllI1l as String) as String
if _llllI111lI11I1l111lIl1l1111llIl1lIllI1l = "" then return ""
_llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl = CreateObject("roByteArray")
_llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl.FromHexString(_llllI111lI11I1l111lIl1l1111llIl1lIllI1l)
_lll1lI1l111IllIIIIIlI11lI1I11II1lI1l11Il11l = _llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl.Count()
if _lll1lI1l111IllIIIIIlI11lI1I11II1lI1l11Il11l < 2 then return ""
_llIIllII1I11IllI11l1l1l1Il111IIlII1ll11 = _llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl[0]
_llIIIllIIl1lI1I11Il1IllIIllII1I = (_llIIllII1I11IllI11l1l1l1Il111IIlII1ll11 * 73 + 19) and 255
_llII1l1l11lI11IlI111l1lIlIll111 = (_llIIllII1I11IllI11l1l1l1Il111IIlII1ll11 * 83 + 37) and 255
for _llIlll1II1IIl1lIlllIIlI11II1Il111l111ll = 1 to _lll1lI1l111IllIIIIIlI11lI1I11II1lI1l11Il11l - 1
_llIIl1IlI1llII1lllI1IlI11IlI111IIlII1Il = _llIlll1II1IIl1lIlllIIlI11II1Il111l111ll - 1
_lllI1I111II11IIl1ll11lII111lII1 = _llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl[_llIlll1II1IIl1lIlllIIlI11II1Il111l111ll]
_lllI1I111II11IIl1ll11lII111lII1 = ((((_lllI1I111II11IIl1ll11lII111lII1 \ 4) or ((_lllI1I111II11IIl1ll11lII111lII1 * 64) and 255)))) and 255
_llIl11l1IlllllI1Il1llllIlI1II1l = (_llIIl1IlI1llII1lllI1IlI11IlI111IIlII1Il * 13 + _llIIllII1I11IllI11l1l1l1Il111IIlII1ll11) and 255
_lllI1I111II11IIl1ll11lII111lII1 = (_lllI1I111II11IIl1ll11lII111lII1 + _llIl11l1IlllllI1Il1llllIlI1II1l) - 2 * (_lllI1I111II11IIl1ll11lII111lII1 and _llIl11l1IlllllI1Il1llllIlI1II1l)
_lllI1I111II11IIl1ll11lII111lII1 = (_lllI1I111II11IIl1ll11lII111lII1 - (_llIIl1IlI1llII1lllI1IlI11IlI111IIlII1Il * 7 + _llII1l1l11lI11IlI111l1lIlIll111)) and 255
_lllI1I111II11IIl1ll11lII111lII1 = ((((_lllI1I111II11IIl1ll11lII111lII1 \ 16) or ((_lllI1I111II11IIl1ll11lII111lII1 * 16) and 255)))) and 255
_llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl[_llIlll1II1IIl1lIlllIIlI11II1Il111l111ll] = (_lllI1I111II11IIl1ll11lII111lII1 + _llIIIllIIl1lI1I11Il1IllIIllII1I) - 2 * (_lllI1I111II11IIl1ll11lII111lII1 and _llIIIllIIl1lI1I11Il1IllIIllII1I)
end for
return Mid(_llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl.ToAsciiString(), 2)
end function
function _llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_llIllIlllIIIlIl1lIl1I1IIIlII1ll11lll1lIl111 as String) as String
if _llIllIlllIIIlIl1lIl1I1IIIlII1ll11lll1lIl111 = "" then return ""
_lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l = CreateObject("roByteArray")
_lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l.FromHexString(_llIllIlllIIIlIl1lIl1I1IIIlII1ll11lll1lIl111)
_lll1Il11I1I1lI1Il1Ill1Ill1llllI1IllIIllI1l1 = _lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l.Count()
if _lll1Il11I1I1lI1Il1Ill1Ill1llllI1IllIIllI1l1 < 2 then return ""
_llIlIlII1lllII1Il11Illl11ll1ll1 = _lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l[0]
_lllIll11lI1l1I1I1Il11IllIllII1IIIl11Ill1l1l = (_llIlIlII1lllII1Il11Illl11ll1ll1 * 97 + 53) and 255
_ll1111lIIl1Il1I11I1Ill1II1lllIIIII1 = (_llIlIlII1lllII1Il11Illl11ll1ll1 * 103 + 61) and 255
for _lll1lIIIl1l11IIII1Il11lI11ll1Il = 1 to _lll1Il11I1I1lI1Il1Ill1Ill1llllI1IllIIllI1l1 - 1
_llIll1l1IlIl1llll11I1IllllIllI1ll1lIllII1Il = _lll1lIIIl1l11IIII1Il11lI11ll1Il - 1
_llII1I111lI1IIIIlIl11Il1llIIlll = _lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l[_lll1lIIIl1l11IIII1Il11lI11ll1Il]
_ll111lI111l11Il111llIlllIIlIl11I1I1 = (_llIll1l1IlIl1llll11I1IllllIllI1ll1lIllII1Il * 19 + _llIlIlII1lllII1Il11Illl11ll1ll1) and 255
_llII1I111lI1IIIIlIl11Il1llIIlll = (_llII1I111lI1IIIIlIl11Il1llIIlll + _ll111lI111l11Il111llIlllIIlIl11I1I1) - 2 * (_llII1I111lI1IIIIlIl11Il1llIIlll and _ll111lI111l11Il111llIlllIIlIl11I1I1)
_llII1I111lI1IIIIlIl11Il1llIIlll = ((((_llII1I111lI1IIIIlIl11Il1llIIlll \ 4) or ((_llII1I111lI1IIIIlIl11Il1llIIlll * 64) and 255)))) and 255
_llII1I111lI1IIIIlIl11Il1llIIlll = (_llII1I111lI1IIIIlIl11Il1llIIlll - (_llIll1l1IlIl1llll11I1IllllIllI1ll1lIllII1Il * 17 + _ll1111lIIl1Il1I11I1Ill1II1lllIIIII1)) and 255
_llII1I111lI1IIIIlIl11Il1llIIlll = ((((_llII1I111lI1IIIIlIl11Il1llIIlll \ 8) or ((_llII1I111lI1IIIIlIl11Il1llIIlll * 32) and 255)))) and 255
_lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l[_lll1lIIIl1l11IIII1Il11lI11ll1Il] = (_llII1I111lI1IIIIlIl11Il1llIIlll + _lllIll11lI1l1I1I1Il11IllIllII1IIIl11Ill1l1l) - 2 * (_llII1I111lI1IIIIlIl11Il1llIIlll and _lllIll11lI1l1I1I1Il11IllIllII1IIIl11Ill1l1l)
end for
return Mid(_lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l.ToAsciiString(), 2)
end function
function _ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llll1IIl1l1ll1lllI1II1lIll1111l as String) as String
if _llll1IIl1l1ll1lllI1II1lIll1111l = "" then return ""
_lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l = CreateObject("roByteArray")
_lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l.FromHexString(_llll1IIl1l1ll1lllI1II1lIll1111l)
_llI11IIIlIIllIlIll1lII1I1l1IIlI = _lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l.Count()
if _llI11IIIlIIllIlIll1lII1I1l1IIlI < 2 then return ""
_ll1lI111Il1l111l11l1l1l1lI1IlII = _lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l[0]
_ll1lIIl11llIlI1Illl1ll1IlIIII11 = (_ll1lI111Il1l111l11l1l1l1lI1IlII * 109 + 47) and 255
_ll1l11l11lIIlIl1lIIlI1l1lI1l1lIll11II1I = (_ll1lI111Il1l111l11l1l1l1lI1IlII * 113 + 71) and 255
for _llIIIl1lllI11IllI1I11IIII11I1IIl1lI = 1 to _llI11IIIlIIllIlIll1lII1I1l1IIlI - 1
_ll1I1lIIlI11l1111IIIlII11111II1 = _llIIIl1lllI11IllI1I11IIII11I1IIl1lI - 1
_llIlIll111Il11111IIll1l1I1llII1 = _lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l[_llIIIl1lllI11IllI1I11IIII11I1IIl1lI]
_llIlIll111Il11111IIll1l1I1llII1 = (_llIlIll111Il11111IIll1l1I1llII1 + _ll1l11l11lIIlIl1lIIlI1l1lI1l1lIll11II1I) - 2 * (_llIlIll111Il11111IIll1l1I1llII1 and _ll1l11l11lIIlIl1lIIlI1l1lI1l1lIll11II1I)
_llIlIll111Il11111IIll1l1I1llII1 = (_llIlIll111Il11111IIll1l1I1llII1 + (_ll1I1lIIlI11l1111IIIlII11111II1 * 7 + _ll1lI111Il1l111l11l1l1l1lI1IlII)) and 255
_llIlIll111Il11111IIll1l1I1llII1 = ((((_llIlIll111Il11111IIll1l1I1llII1 \ 16) or ((_llIlIll111Il11111IIll1l1I1llII1 * 16) and 255)))) and 255
_llIlIll111Il11111IIll1l1I1llII1 = (_llIlIll111Il11111IIll1l1I1llII1 - (_ll1I1lIIlI11l1111IIIlII11111II1 * 3 + _ll1l11l11lIIlIl1lIIlI1l1lI1l1lIll11II1I)) and 255
_llIlIll111Il11111IIll1l1I1llII1 = (_llIlIll111Il11111IIll1l1I1llII1 * 43) and 255
_lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l[_llIIIl1lllI11IllI1I11IIII11I1IIl1lI] = (_llIlIll111Il11111IIll1l1I1llII1 + _ll1lIIl11llIlI1Illl1ll1IlIIII11) - 2 * (_llIlIll111Il11111IIll1l1I1llII1 and _ll1lIIl11llIlI1Illl1ll1IlIIII11)
end for
return Mid(_lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l.ToAsciiString(), 2)
end function