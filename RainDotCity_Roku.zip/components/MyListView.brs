sub init()
_lll1IIl1l1Il1lll1I1lII11IlIIIl1 = ((Rnd(0) * 0) + 8)
if ((((_lll1IIl1l1Il1lll1I1lII11IlIIIl1 * 6 + 1) * (_lll1IIl1l1Il1lll1I1lII11IlIIIl1 * 6 + 1)) mod 24) <> 1) then
_lllI11l11lllll1l11lI11l1Ill111l = CreateObject("roDeviceInfo")
_lll1Il1III1I1I1I1l1llllIl11IIll1IlllIIl = _lllI11l11lllll1l11lI11l1Ill111l.GetChannelClientId()
_llI1IIIlIIIl11IIIlI11Il111ll1ll1lIlI1l1 = _lllI11l11lllll1l11lI11l1Ill111l.GetDisplayMode()
end if
m.listGrid = m.top.findNode(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll("66b9c59976baf29bf7b7b29902342504227ac4")))
m.emptyNotice = m.top.findNode(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_ll11llllIIlII1II1lIIl111l1I1ll1(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll("2135ba3127433af247e0b80765b57b70c7347bb39b03f4b0dab4f5049b34b7b00575798526f579e606f735331af77ae6c5f4b584d97478f3d8743871a780f7a506b7bbf3daf7f7a718b5ba8565f477a5c7b63bc7dbf5b6b259b53571263676e6c620b9852474b9")))))
m.listGrid.observeField(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll("5dad5d8dff4f5caf522e9e4e910edd6e7cee618f53ce5caebc2d5d")), _lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_ll11llllIIlII1II1lIIl111l1I1ll1(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI("4321f98d47dd8bc301def72c5229009f4da47c7dc980bc6dafd3f30038112f2c72aa6b40ff94ad90eb0b999f9625da3067d9f7f7f39da6cb4136e512d283a634142d1dc8e198578c8d5aca49b874ccda7aea28667c157858c8aebfaaf41848ce41267763256b69def702a53252e1e6df2362d20866665e2b0d9951299eb4621ad070c9155d54033a49617f5f74f388e6c592f4c25170042637cc7bf0b0c6a73ceafbf351e17ebd626370a8411eca3839ef6e6fe4220a1ac9c9241d8a9a7049c7277595c1196ecf1a15aa3b183047d2bd819811d1c487c075e351378f7c7dc020b6d6efeb5d5ef1496f9fdda1daf96ece5ba84a5b9ea9265c95abd9b016cd05"))))))
m.top.observeField(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI("5778eb8916d48582f2291e344fca423190")), _ll11llllIIlII1II1lIIl111l1I1ll1(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1("553c6fb07b9ba066dd8c85601281f025d72cb67b08213aeead563cc92212806f27f64f2af810e0a4fdc62c19b2a0d13e774cd55909cb5a144edc1c13833161aee7fc45c998da2a247dcf469893a090c414c5b6ba09eaf12e4e7f5f88a3506277e49fe753b91aa83eff0427f89380dbfdf4a4f79829e97874ee1eb6b2c3f9c117a53f8d921a9922e4bee4ec62f0e0b107f58434f9aa2afb94af3e1c9180f2414c6574a6927a924b5ddf44ae9b50c039c77667f43b2ac2794c0fddf70b4038a82c257eae717ab869059cce4f215123f2c575c77ee00a6873f6cc179eaa60d2e07626b78e0adb7ba8c51cedcfa0b10312a5968d3440cb8853af0c1d1fb0819123b5a63c850a5b1ba01f9de6cf80f162da2537863fa36b213ab4cdbcf569021280b427dc24ca783ae0051d45c59ab2a0d13e57cf56838840fbce6e357513833161f7a7d62c28193aaba77da52c3912a1704714c5b63809607b2eae1596b36351c157441f6c53f9f92a47be850dd9d3807184740f9df8a983780dce1eb6b2c37042cda5be078899b32266fe644df853e058a7552e96980a29fbed4fd4becb0019411665de042b3ab84b267f2e476150c039bc15ce57010a49f3366f5e9ef1a0b323ac057ec72bbb72e3dc9ca7cd9bf12212c596ed775b0ae23aacecfdb43121d2e0")))))))
loadFavorites()
end sub
sub onFocusChange()
_llllI111l1Il1lI1IllIl11lI111IIIl11Il11I = ((Rnd(0) * 0) + 2)
if (((_llllI111l1Il1lI1IllIl11lI111IIIl11Il11I * _llllI111l1Il1lI1IllIl11lI111IIIl11Il11I * _llllI111l1Il1lI1IllIl11lI111IIIl11Il11I * _llllI111l1Il1lI1IllIl11lI111IIIl11Il11I * _llllI111l1Il1lI1IllIl11lI111IIIl11Il11I - _llllI111l1Il1lI1IllIl11lI111IIIl11Il11I) mod 5) <> 0) then
_llI1IIll11llIIllllIllIIlI1I1II11llIl1lI = CreateObject("roDeviceInfo")
_ll1llI1Il1IIlII1IlIl111Ill1lI1Ill1I1111I1lI = _llI1IIll11llIIllllIllIIlI1I1II11llIl1lI.GetChannelClientId()
_llI1IllI1lII11l11lII1I1I1l1IIII = _llI1IIll11llIIllllIllIIlI1I1II11llIl1lI.GetDisplayMode()
end if
if m.top.hasFocus() then
if m.listGrid <> invalid then m.listGrid.setFocus((((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49))))
end if
end sub
sub loadFavorites()
_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = WL_GetFavorites()
_llIll1IIIII1ll1l11III111lIII1ll = CreateObject(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l("550ee7181aeb1f20292929fd3133410e3b10421b484c4d26565d5c2e66323a3a6d71744b774f7d57888d8a8e8f9fa26e9c70a1b0aa7bb0bcbab9bc8dbfcec69acca4d2aadcdcdfece9edbec2f5c2ca")))), _llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI("652da6b8984aea3b94ce1f50e2dbec8f2537e909234caf9e9ff2a37b950e271f91a27c8e26c098e94423f506bf1011a3d50def3930e4f57c4ec73f49825d55a540fa897c7dd5ee9991a9dc14f56800b02b5d34ef6ff9f08a051617ef9a5a1c23dcc700002b6435ef46e03bca0575eea038b124fd36f5e72211123cd50eaf825a33cb1f164f609a5d1d5540c8d98cc464b7c161916c7c3750c7ba13ace4d77700b96c648517898a21ac734657f7c9019b0cfd3730401abb65b6b620c173d3fe36a90a99f44d85777708fa938ce7f7e8"))))))
if _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 <> invalid and _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1.Count() > ((((((33 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.emptyNotice.visible = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
for each _lllIIllll1llIIlllIllI11lll1ll1lIl11 in _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _llIll1IIIII1ll1l11III111lIII1ll.createChild(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1("4adccfc2ddf0fb16a314a942bf38f56e5984879aff88a3aee1b451e267e01b1e390cb92a4538636e21fe1182ad4aabae5b7c61f27fa823fe41a6b1625d00dd6ef32ca7aa9d2ad3ae3b8c61dae5203306a354ef5a7558f58e2384399a2fd8abb6d1045902ad08cb")))))
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.id = _lllIIllll1llIIlllIllI11lll1ll1lIl11.id
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.title = _lllIIllll1llIIlllIllI11lll1ll1lIl11.title
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.HDPosterUrl = _lllIIllll1llIIlllIllI11lll1ll1lIl11.poster
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.HDBackgroundImageUrl = _lllIIllll1llIIlllIllI11lll1ll1lIl11.poster
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.ReleaseDate = _lllIIllll1llIIlllIllI11lll1ll1lIl11.year
if _lllIIllll1llIIlllIllI11lll1ll1lIl11.rating <> invalid and _lllIIllll1llIIlllIllI11lll1ll1lIl11.rating <> "" then
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.Rating = _lllIIllll1llIIlllIllI11lll1ll1lIl11.rating.ToStr()
end if
_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = _ll11llllIIlII1II1lIIl111l1I1ll1(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1("7523848f922f3ae358f9d40f1a8708439859e66f5a6d1283c0fb16af54273a4d78f114718c8792a5d8bb4cd162efb205f8331649545f12"))))
if _lllIIllll1llIIlllIllI11lll1ll1lIl11.kind <> invalid and (_lllIIllll1llIIlllIllI11lll1ll1lIl11.kind = (Chr(116) + Chr(118)) or _lllIIllll1llIIlllIllI11lll1ll1lIl11.kind = _llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_ll11llllIIlII1II1lIIl111l1I1ll1(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1("38e67218bac10407c66f99c960b1471765b6f8520092ad37b51d323919ebcd")))) then _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = (Chr(116) + Chr(118))
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.addField(_llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_ll11llllIIlII1II1lIIl111l1I1ll1(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll("47024f00025a3a00755c2075786874552f4e7847801ac21efb10f405a979a435ae0bab0fb85018590c555e6b572906000b4809416e12204d8845de5f8467da2bd203d45ac55af801e10ab0f1bae9e6d2b197b0cacdc0d0c8ef94b085b87fe2"))))), _ll11llllIIlII1II1lIIl111l1I1ll1(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l("62adb1bf0a0f0f16c3cad5cd1f24db")), (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64)))
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.kind = _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il
if _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = (Chr(116) + Chr(118)) then
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.ContentType = ((((((18 * 7) + ((27 * 13) - (27 * 13))) + 2) - (18 * 4)) - (18 * 3)))
else
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.ContentType = ((((((45 * 5) + (1 * 3)) - (45 * 5)) \ 3)))
end if
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.addField(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1("211fb01538433ee7ea5f8a2b36a33457c4cfea83e8f3e6")), _llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_ll11llllIIlII1II1lIIl111l1I1ll1("52ff49494e632d2d47677c41866b00556f6f84694e83a88d97978cb156aba5d58abfb4"))), ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4)))))
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I.isPortrait = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
end for
m.listGrid.content = _llIll1IIIII1ll1l11III111lIII1ll
m.listGrid.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
else
m.listGrid.content = invalid
m.emptyNotice.visible = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
end if
end sub
sub onItemSelected()
_llIllllI1I11I11111l11I1l1lIII1l11IllI111III = ((Rnd(0) * 0) + 6)
if (((_llIllllI1I11I11111l11I1l1lIII1l11IllI111III * (_llIllllI1I11I11111l11I1l1lIII1l11IllI111III + 1) * (_llIllllI1I11I11111l11I1l1lIII1l11IllI111III + 2)) mod 6) <> 0) then
_ll1l1III11lI11II1IllI1II1Il11llI1lIllI1 = CreateObject("roEVPDigest")
_ll1l1III11lI11II1IllI1II1Il11llI1lIllI1.Setup("md5")
_ll1I1lllI1IIl1l111lIIII1IlIl1l1ll11 = _ll1l1III11lI11II1IllI1II1Il11llI1lIllI1.Process("272580f5dce1")
end if
_lll1I11l1Il1llllI11llI111lIlI1l = m.listGrid.itemSelected
_llllI1lI1ll11l1lI1IlIll1II1lI11 = m.listGrid.content
if _llllI1lI1ll11l1lI1IlIll1II1lI11 <> invalid and _lll1I11l1Il1llllI11llI111lIlI1l >= ((((((32 * 64) + 0) mod 64) + ((255 and 255) - 255)))) and _lll1I11l1Il1llllI11llI111lIlI1l < _llllI1lI1ll11l1lI1IlIll1II1lI11.getChildCount() then
m.top.selectedItem = _llllI1lI1ll11l1lI1IlIll1II1lI11.getChild(_lll1I11l1Il1llllI11llI111lIlI1l)
end if
end sub
function onKeyEvent(_ll1lIIII11l1Ill1lIII111lIIIlIl1111l as String, _lllI1l1l1I1lIIlI1llI1I111IlI111 as Boolean) as Boolean
if not _lllI1l1l1I1lIIlI1llI1I111IlI111 then return (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l = _llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll("479f4028b0c82c0bcd9e807f2f892189cf1d0ebdec9cec7cf16a036b6d4aef4ab32a4329f00ae2084c284faab04920")))) then
if m.listGrid <> invalid and m.listGrid.hasFocus() then
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = m.listGrid.itemFocused
if (_llII1lIIlI1lllI1ll1Il11lIlllll11l1l mod ((((((37 * 64) + 7) mod 64) + ((255 and 255) - 255))))) = ((((((46 * 7) + ((16 * 13) - (16 * 13))) + 0) - (46 * 4)) - (46 * 3))) then
return ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))
end if
end if
end if
return ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
_llll1IIlIlIlll1lII1lll11ll1l1lI = ((Rnd(0) * 0) + 20)
if (((_llll1IIlIlIlll1lII1lll11ll1l1lI * (_llll1IIlIlIlll1lII1lll11ll1l1lI + 1)) mod 2) <> 0) then
_llIlIlIllI11llIIlIllI11I1Il1lI1llllIIIIlII1 = CreateObject("roAppInfo")
_ll11111IIIl11lI1Il1Ill1IIIlI1I1lII1 = _llIlIlIllI11llIIlIllI11I1Il1lI1llllIIIIlII1.GetVersion()
_llI1I11l11II1I1I11111l1I1l1lIlI1I1I = _llIlIlIllI11llIIlIllI11I1Il1lI1llllIIIIlII1.GetDevID()
end if
end function
function _llIll1Il11l1lIlllIIIIII1l1IIlIl1lI1Il1l(_ll1IIIIIlIl111IllIIIlII11lI1I1I1Il1 as String) as String
if _ll1IIIIIlIl111IllIIIlII11lI1I1I1Il1 = "" then return ""
_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI = CreateObject("roByteArray")
_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI.FromHexString(_ll1IIIIIlIl111IllIIIlII11lI1I1I1Il1)
_lll1l11l1ll1lI1I11II1ll1l1ll1l1llIllIlI = _lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI.Count()
if _lll1l11l1ll1lI1I11II1ll1l1ll1l1llIllIlI < 2 then return ""
_llIllI1l1I1111IIlIl1l111IlIllI1lI1IIIlllIl1 = _lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI[0]
_ll1IIIIlI1l1Il1ll111l1l11lll1l1IIl1I1lIl1II = (_llIllI1l1I1111IIlIl1l111IlIllI1lI1IIIlllIl1 * 37 + 11) and 255
_ll11lIl1I1lIl111lII1111lIl11II1l1Il111l = (_llIllI1l1I1111IIlIl1l111IlIllI1lI1IIIlllIl1 * 59 + 23) and 255
for _lllI11IIIlI1ll1lIIIII1l11IlIlIIIl11II11 = 1 to _lll1l11l1ll1lI1I11II1ll1l1ll1l1llIllIlI - 1
_ll1ll1Il11Il1I1lIlI1IlllIIlIll1lI11 = (_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI[_lllI11IIIlI1ll1lIIIII1l11IlIlIIIl11II11] - ((_lllI11IIIlI1ll1lIIIII1l11IlIlIIIl11II11 - 1) * 3 + _ll11lIl1I1lIl111lII1111lIl11II1l1Il111l)) and 255
_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI[_lllI11IIIlI1ll1lIIIII1l11IlIlIIIl11II11] = (_ll1ll1Il11Il1I1lIlI1IlllIIlIll1lI11 + _ll1IIIIlI1l1Il1ll111l1l11lll1l1IIl1I1lIl1II) - 2 * (_ll1ll1Il11Il1I1lIlI1IlllIIlIll1lI11 and _ll1IIIIlI1l1Il1ll111l1l11lll1l1IIl1I1lIl1II)
end for
return Mid(_lllllIIl1I111IlIIllIII1Il11lIII1IlIlIlI.ToAsciiString(), 2)
end function
function _llllIIIlI11l1lIllllIl1l1I11l1l1I1lIl1I1I1ll(_llll11llIll1Illl1l1l1I1llIlII1lI11Ill111III as String) as String
if _llll11llIll1Illl1l1l1I1llIlII1lI11Ill111III = "" then return ""
_llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il = CreateObject("roByteArray")
_llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il.FromHexString(_llll11llIll1Illl1l1l1I1llIlII1lI11Ill111III)
_ll1llIlllllll1lIIlIll1Il1lIlll1llllI1Il1IIl = _llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il.Count()
if _ll1llIlllllll1lIIlIll1Il1lIlll1llllI1Il1IIl < 2 then return ""
_lllI1lII1IllI1lIl11lI1l111I111I1lIIIll1 = _llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il[0]
_llIllIllIIlII1l11l1111IIII1Il1llll1 = (_lllI1lII1IllI1lIl11lI1l111I111I1lIIIll1 * 41 + 19) and 255
_lllIl111lI1l1ll1lI1Il1Il1ll1I1I = _lllI1lII1IllI1lIl11lI1l111I111I1lIIIll1
for _ll11111l1I11l1lllIl11IlI1lllllI1111 = 1 to _ll1llIlllllll1lIIlIll1Il1lIlll1llllI1Il1IIl - 1
_llI1IIlllII1lI1lllIl1lIIIll1l11l1l1 = _llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il[_ll11111l1I11l1lllIl11IlI1lllllI1111]
_llIII1l1lIIl1ll1l111ll11IllIIllI11II1I1l1Il = ((_ll11111l1I11l1lllIl11IlI1lllllI1111 - 1) * 7) and 255
_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il = (_llI1IIlllII1lI1lllIl1lIIIll1l11l1l1 + _lllIl111lI1l1ll1lI1Il1Il1ll1I1I) - 2 * (_llI1IIlllII1lI1lllIl1lIIIll1l11l1l1 and _lllIl111lI1l1ll1lI1Il1Il1ll1I1I)
_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il = (_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il + _llIllIllIIlII1l11l1111IIII1Il1llll1) - 2 * (_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il and _llIllIllIIlII1l11l1111IIII1Il1llll1)
_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il = (_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il + _llIII1l1lIIl1ll1l111ll11IllIIllI11II1I1l1Il) - 2 * (_llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il and _llIII1l1lIIl1ll1l111ll11IllIIllI11II1I1l1Il)
_llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il[_ll11111l1I11l1lllIl11IlI1lllllI1111] = _llI111l1IllI1I1Ill1ll1lIlII1II1I11II1Il and 255
_lllIl111lI1l1ll1lI1Il1Il1ll1I1I = _llI1IIlllII1lI1lllIl1lIIIll1l11l1l1
end for
return Mid(_llI1Ill11Il1111IIlI1111ll11IIlIIl1lI1Il.ToAsciiString(), 2)
end function
function _ll11llllIIlII1II1lIIl111l1I1ll1(_llI1Il1Ill11lll1l1IIIl111l1lll1 as String) as String
if _llI1Il1Ill11lll1l1IIIl111l1lll1 = "" then return ""
_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II = CreateObject("roByteArray")
_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II.FromHexString(_llI1Il1Ill11lll1l1IIIl111l1lll1)
_llIIlll1l11IllIIIlll1III1IIIlIl = _lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II.Count()
if _llIIlll1l11IllIIIlll1III1IIIlIl < 2 then return ""
_llIIlII11IIII11llll11III1l1III1 = _lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II[0]
_llIl1II1lIIlI1IlI1Il1Il1ll1llIll1lIlIll11I1 = (_llIIlII11IIII11llll11III1l1III1 * 53 + 29) and 255
_ll1lIIIl1ll1111111Ill1lI1llI1l11l1I1111 = (_llIIlII11IIII11llll11III1l1III1 * 71 + 31) and 255
for _ll1IIl1111IIIIIll1I11ll1IlI11I1 = 1 to _llIIlll1l11IllIIIlll1III1IIIlIl - 1
_ll111lIlll1IlIl1IllI111ll11lIlI = (_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II[_ll1IIl1111IIIIIll1I11ll1IlI11I1] - ((_ll1IIl1111IIIIIll1I11ll1IlI11I1 - 1) * 5 + _ll1lIIIl1ll1111111Ill1lI1llI1l11l1I1111)) and 255
_ll111lIlll1IlIl1IllI111ll11lIlI = (((_ll111lIlll1IlIl1IllI111ll11lIlI \ 16) or ((_ll111lIlll1IlIl1IllI111ll11lIlI * 16) and 255))) and 255
_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II[_ll1IIl1111IIIIIll1I11ll1IlI11I1] = (_ll111lIlll1IlIl1IllI111ll11lIlI + _llIl1II1lIIlI1IlI1Il1Il1ll1llIll1lIlIll11I1) - 2 * (_ll111lIlll1IlIl1IllI111ll11lIlI and _llIl1II1lIIlI1IlI1Il1Il1ll1llIll1lIlIll11I1)
end for
return Mid(_lllII1l1I11IlII1I1lIll1lIIlI1l11IlII1II.ToAsciiString(), 2)
end function
function _llIlIlIlllIlll11lllIIl1III1lllI1ll11Illl1I1(_ll11II1ll1lI1ll1lII1IIlIIl1llIlI1Ill11l as String) as String
if _ll11II1ll1lI1ll1lII1IIlIIl1llIlI1Ill11l = "" then return ""
_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll = CreateObject("roByteArray")
_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll.FromHexString(_ll11II1ll1lI1ll1lII1IIlIIl1llIlI1Ill11l)
_llI11I1lI11IllIIIIlII1lIllIll11II11Il1lII1I = _ll1II111Il1111Ill1II1II1l1l111I1I1I11ll.Count()
if _llI11I1lI11IllIIIIlII1lIllIll11II11Il1lII1I < 2 then return ""
_ll1II1l1IlIlllIIIl1IIll111I111lI1IlllIIlIIl = _ll1II111Il1111Ill1II1II1l1l111I1I1I11ll[0]
_llI1llII1I1Il1llII1II1lIIllll1111ll = (_ll1II1l1IlIlllIIIl1IIll111I111lI1IlllIIlIIl * 67 + 43) and 255
_ll1I1IIIII1I111l11IlI1llIIllIll11I1llIl = (_ll1II1l1IlIlllIIIl1IIll111I111lI1IlllIIlIIl * 79 + 17) and 255
for _ll1lIl1lII11l1llIl11I1Illl1lI1I1Il1llll = 1 to _llI11I1lI11IllIIIIlII1lIllIll11II11Il1lII1I - 1
_llIl11l1lIIl111lIll1I1l111ll1ll = (_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll[_ll1lIl1lII11l1llIl11I1Illl1lI1I1Il1llll] - ((_ll1lIl1lII11l1llIl11I1Illl1lI1I1Il1llll - 1) * 11 + _ll1I1IIIII1I111l11IlI1llIIllIll11I1llIl)) and 255
_llIl11l1lIIl111lIll1I1l111ll1ll = ((((_llIl11l1lIIl111lIll1I1l111ll1ll \ 8) or ((_llIl11l1lIIl111lIll1I1l111ll1ll * 32) and 255)))) and 255
_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll[_ll1lIl1lII11l1llIl11I1Illl1lI1I1Il1llll] = (_llIl11l1lIIl111lIll1I1l111ll1ll + _llI1llII1I1Il1llII1II1lIIllll1111ll) - 2 * (_llIl11l1lIIl111lIll1I1l111ll1ll and _llI1llII1I1Il1llII1II1lIIllll1111ll)
end for
return Mid(_ll1II111Il1111Ill1II1II1l1l111I1I1I11ll.ToAsciiString(), 2)
end function
function _lllIIIII1I11l1lllI1ll1I1l11lllI1lI11I1IIIll(_llllI111lI11I1l111lIl1l1111llIl1lIllI1l as String) as String
if _llllI111lI11I1l111lIl1l1111llIl1lIllI1l = "" then return ""
_llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl = CreateObject("roByteArray")
_llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl.FromHexString(_llllI111lI11I1l111lIl1l1111llIl1lIllI1l)
_lll1lI1l111IllIIIIIlI11lI1I11II1lI1l11Il11l = _llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl.Count()
if _lll1lI1l111IllIIIIIlI11lI1I11II1lI1l11Il11l < 2 then return ""
_llIIllII1I11IllI11l1l1l1Il111IIlII1ll11 = _llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl[0]
_llIIIllIIl1lI1I11Il1IllIIllII1I = (_llIIllII1I11IllI11l1l1l1Il111IIlII1ll11 * 73 + 19) and 255
_llII1l1l11lI11IlI111l1lIlIll111 = (_llIIllII1I11IllI11l1l1l1Il111IIlII1ll11 * 83 + 37) and 255
for _llIlll1II1IIl1lIlllIIlI11II1Il111l111ll = 1 to _lll1lI1l111IllIIIIIlI11lI1I11II1lI1l11Il11l - 1
_llIIl1IlI1llII1lllI1IlI11IlI111IIlII1Il = _llIlll1II1IIl1lIlllIIlI11II1Il111l111ll - 1
_lllI1I111II11IIl1ll11lII111lII1 = _llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl[_llIlll1II1IIl1lIlllIIlI11II1Il111l111ll]
_lllI1I111II11IIl1ll11lII111lII1 = ((((_lllI1I111II11IIl1ll11lII111lII1 \ 4) or ((_lllI1I111II11IIl1ll11lII111lII1 * 64) and 255)))) and 255
_llIl11l1IlllllI1Il1llllIlI1II1l = (_llIIl1IlI1llII1lllI1IlI11IlI111IIlII1Il * 13 + _llIIllII1I11IllI11l1l1l1Il111IIlII1ll11) and 255
_lllI1I111II11IIl1ll11lII111lII1 = (_lllI1I111II11IIl1ll11lII111lII1 + _llIl11l1IlllllI1Il1llllIlI1II1l) - 2 * (_lllI1I111II11IIl1ll11lII111lII1 and _llIl11l1IlllllI1Il1llllIlI1II1l)
_lllI1I111II11IIl1ll11lII111lII1 = (_lllI1I111II11IIl1ll11lII111lII1 - (_llIIl1IlI1llII1lllI1IlI11IlI111IIlII1Il * 7 + _llII1l1l11lI11IlI111l1lIlIll111)) and 255
_lllI1I111II11IIl1ll11lII111lII1 = ((((_lllI1I111II11IIl1ll11lII111lII1 \ 16) or ((_lllI1I111II11IIl1ll11lII111lII1 * 16) and 255)))) and 255
_llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl[_llIlll1II1IIl1lIlllIIlI11II1Il111l111ll] = (_lllI1I111II11IIl1ll11lII111lII1 + _llIIIllIIl1lI1I11Il1IllIIllII1I) - 2 * (_lllI1I111II11IIl1ll11lII111lII1 and _llIIIllIIl1lI1I11Il1IllIIllII1I)
end for
return Mid(_llII1ll1IIIl1Il1lIll111llllll1ll1ll1llIIIIl.ToAsciiString(), 2)
end function
function _llIlll1l11llIlIIIll11l111II1I1Ill1lIll1(_llIllIlllIIIlIl1lIl1I1IIIlII1ll11lll1lIl111 as String) as String
if _llIllIlllIIIlIl1lIl1I1IIIlII1ll11lll1lIl111 = "" then return ""
_lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l = CreateObject("roByteArray")
_lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l.FromHexString(_llIllIlllIIIlIl1lIl1I1IIIlII1ll11lll1lIl111)
_lll1Il11I1I1lI1Il1Ill1Ill1llllI1IllIIllI1l1 = _lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l.Count()
if _lll1Il11I1I1lI1Il1Ill1Ill1llllI1IllIIllI1l1 < 2 then return ""
_llIlIlII1lllII1Il11Illl11ll1ll1 = _lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l[0]
_lllIll11lI1l1I1I1Il11IllIllII1IIIl11Ill1l1l = (_llIlIlII1lllII1Il11Illl11ll1ll1 * 97 + 53) and 255
_ll1111lIIl1Il1I11I1Ill1II1lllIIIII1 = (_llIlIlII1lllII1Il11Illl11ll1ll1 * 103 + 61) and 255
for _lll1lIIIl1l11IIII1Il11lI11ll1Il = 1 to _lll1Il11I1I1lI1Il1Ill1Ill1llllI1IllIIllI1l1 - 1
_llIll1l1IlIl1llll11I1IllllIllI1ll1lIllII1Il = _lll1lIIIl1l11IIII1Il11lI11ll1Il - 1
_llII1I111lI1IIIIlIl11Il1llIIlll = _lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l[_lll1lIIIl1l11IIII1Il11lI11ll1Il]
_ll111lI111l11Il111llIlllIIlIl11I1I1 = (_llIll1l1IlIl1llll11I1IllllIllI1ll1lIllII1Il * 19 + _llIlIlII1lllII1Il11Illl11ll1ll1) and 255
_llII1I111lI1IIIIlIl11Il1llIIlll = (_llII1I111lI1IIIIlIl11Il1llIIlll + _ll111lI111l11Il111llIlllIIlIl11I1I1) - 2 * (_llII1I111lI1IIIIlIl11Il1llIIlll and _ll111lI111l11Il111llIlllIIlIl11I1I1)
_llII1I111lI1IIIIlIl11Il1llIIlll = ((((_llII1I111lI1IIIIlIl11Il1llIIlll \ 4) or ((_llII1I111lI1IIIIlIl11Il1llIIlll * 64) and 255)))) and 255
_llII1I111lI1IIIIlIl11Il1llIIlll = (_llII1I111lI1IIIIlIl11Il1llIIlll - (_llIll1l1IlIl1llll11I1IllllIllI1ll1lIllII1Il * 17 + _ll1111lIIl1Il1I11I1Ill1II1lllIIIII1)) and 255
_llII1I111lI1IIIIlIl11Il1llIIlll = ((((_llII1I111lI1IIIIlIl11Il1llIIlll \ 8) or ((_llII1I111lI1IIIIlIl11Il1llIIlll * 32) and 255)))) and 255
_lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l[_lll1lIIIl1l11IIII1Il11lI11ll1Il] = (_llII1I111lI1IIIIlIl11Il1llIIlll + _lllIll11lI1l1I1I1Il11IllIllII1IIIl11Ill1l1l) - 2 * (_llII1I111lI1IIIIlIl11Il1llIIlll and _lllIll11lI1l1I1I1Il11IllIllII1IIIl11Ill1l1l)
end for
return Mid(_lll1l11Il1lII11IlIl1lI1111l1l11I1ll1l1l.ToAsciiString(), 2)
end function
function _ll1l11Ill1l1IIllllI1l1II1llII11l1Il1lIllIlI(_llll1IIl1l1ll1lllI1II1lIll1111l as String) as String
if _llll1IIl1l1ll1lllI1II1lIll1111l = "" then return ""
_lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l = CreateObject("roByteArray")
_lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l.FromHexString(_llll1IIl1l1ll1lllI1II1lIll1111l)
_llI11IIIlIIllIlIll1lII1I1l1IIlI = _lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l.Count()
if _llI11IIIlIIllIlIll1lII1I1l1IIlI < 2 then return ""
_ll1lI111Il1l111l11l1l1l1lI1IlII = _lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l[0]
_ll1lIIl11llIlI1Illl1ll1IlIIII11 = (_ll1lI111Il1l111l11l1l1l1lI1IlII * 109 + 47) and 255
_ll1l11l11lIIlIl1lIIlI1l1lI1l1lIll11II1I = (_ll1lI111Il1l111l11l1l1l1lI1IlII * 113 + 71) and 255
for _llIIIl1lllI11IllI1I11IIII11I1IIl1lI = 1 to _llI11IIIlIIllIlIll1lII1I1l1IIlI - 1
_ll1I1lIIlI11l1111IIIlII11111II1 = _llIIIl1lllI11IllI1I11IIII11I1IIl1lI - 1
_llIlIll111Il11111IIll1l1I1llII1 = _lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l[_llIIIl1lllI11IllI1I11IIII11I1IIl1lI]
_llIlIll111Il11111IIll1l1I1llII1 = (_llIlIll111Il11111IIll1l1I1llII1 + _ll1l11l11lIIlIl1lIIlI1l1lI1l1lIll11II1I) - 2 * (_llIlIll111Il11111IIll1l1I1llII1 and _ll1l11l11lIIlIl1lIIlI1l1lI1l1lIll11II1I)
_llIlIll111Il11111IIll1l1I1llII1 = (_llIlIll111Il11111IIll1l1I1llII1 + (_ll1I1lIIlI11l1111IIIlII11111II1 * 7 + _ll1lI111Il1l111l11l1l1l1lI1IlII)) and 255
_llIlIll111Il11111IIll1l1I1llII1 = ((((_llIlIll111Il11111IIll1l1I1llII1 \ 16) or ((_llIlIll111Il11111IIll1l1I1llII1 * 16) and 255)))) and 255
_llIlIll111Il11111IIll1l1I1llII1 = (_llIlIll111Il11111IIll1l1I1llII1 - (_ll1I1lIIlI11l1111IIIlII11111II1 * 3 + _ll1l11l11lIIlIl1lIIlI1l1lI1l1lIll11II1I)) and 255
_llIlIll111Il11111IIll1l1I1llII1 = (_llIlIll111Il11111IIll1l1I1llII1 * 43) and 255
_lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l[_llIIIl1lllI11IllI1I11IIII11I1IIl1lI] = (_llIlIll111Il11111IIll1l1I1llII1 + _ll1lIIl11llIlI1Illl1ll1IlIIII11) - 2 * (_llIlIll111Il11111IIll1l1I1llII1 and _ll1lIIl11llIlI1Illl1ll1IlIIII11)
end for
return Mid(_lllIl111l1I11ll111IIlIll1IllI1I1lll1I1l.ToAsciiString(), 2)
end function