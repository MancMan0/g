sub init()
m.listGrid = m.top.findNode(_l1d_bc7069("e7ed0608d810fc04", 15, 132))
m.emptyNotice = m.top.findNode(_l1d_bc7069("cbd6dce3ebbfe3efe7e0e9", 2, 100))
m.listGrid.observeField(_l1d_bc7069("64546671366f7b75726c7e82", 83, 42), _l1d_bc7069("565a7a7a6c679c75717b78928488", 235, 210))
m.top.observeField(_l1d_bc7069("2822313e473438", 109, 29), _l1d_bc7069("8d8f6a9695a2ab7ea6a2aaa6a7", 4, 34))
loadFavorites()
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.listGrid <> invalid then m.listGrid.setFocus(true)
end if
end sub
sub loadFavorites()
if ((45856 - 5732 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_lI1I11l = WL_GetFavorites()
_lIII11l = CreateObject(_l1d_bc7069("1614fbf2fe201a1c", 129, 35), _l1d_bc7069("4f7e80897d89926f938b8f", 64, 76))
if _lI1I11l <> invalid and _lI1I11l.Count() > 0 then
m.emptyNotice.visible = false
for each _l11I11l in _lI1I11l
_llII11l = _lIII11l.createChild(_l1d_bc7069("b9d0d2cbdfdbd4c1e5edf1", 28, 90))
_llII11l.id = _l11I11l.id
_llII11l.title = _l11I11l.title
_llII11l.HDPosterUrl = _l11I11l.poster
_llII11l.HDBackgroundImageUrl = _l11I11l.poster
_llII11l.ReleaseDate = _l11I11l.year
if _l11I11l.rating <> invalid and _l11I11l.rating <> "" then
_llII11l.Rating = _l11I11l.rating.ToStr()
end if
_l1II11l = _l1d_bc7069("9fa09cacb3", 159, 173)
if _l11I11l.kind <> invalid and (_l11I11l.kind = _l1d_bc7069("c7cc", 9, 74) or _l11I11l.kind = _l1d_bc7069("b3c8bad2d1c2", 241, 49)) then _l1II11l = _l1d_bc7069("9ba0", 192, 231)
_llII11l.addField(_l1d_bc7069("9e9fa9b2", 153, 172), _l1d_bc7069("909095837f8b", 206, 211), false)
_llII11l.kind = _l1II11l
if _l1II11l = _l1d_bc7069("0102", 131, 10) then
_llII11l.ContentType = 2
else
_llII11l.ContentType = 1
end if
end for
m.listGrid.content = _lIII11l
m.listGrid.setFocus(true)
else
m.listGrid.content = invalid
m.emptyNotice.visible = true
end if
end sub
sub onItemSelected()
_ll11lIl = m.listGrid.itemSelected
_lIl1lIl = m.listGrid.content
if _lIl1lIl <> invalid and _ll11lIl >= 0 and _ll11lIl < _lIl1lIl.getChildCount() then
m.top.selectedItem = _lIl1lIl.getChild(_ll11lIl)
end if
end sub
function _l1d_bc7069(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function