sub init()
m.backdrop = m.top.findNode(_l1d_6bae63("a8aeafbabac7c7cf", 162, 232))
m.poster = m.top.findNode(_l1d_6bae63("43634a506254", 113, 66))
m.title = m.top.findNode(_l1d_6bae63("54745a7571", 52, 20))
m.subMeta = m.top.findNode(_l1d_6bae63("8380987e998ba3", 84, 92))
m.genres = m.top.findNode(_l1d_6bae63("71766e6d7f74", 254, 216))
m.description = m.top.findNode(_l1d_6bae63("5b5f786b7d678180707173", 204, 179))
m.playBtn = m.top.findNode(_l1d_6bae63("e1f0f8e3dbf4fd", 90, 183))
m.favBtn = m.top.findNode(_l1d_6bae63("7c7a72a17683", 184, 158))
m.seriesSection = m.top.findNode(_l1d_6bae63("c0adc5afb6cfb2bfc8d4c4c5c7", 76, 129))
m.seasonDropdownBtn = m.top.findNode(_l1d_6bae63("4f444358474b74655369605c77638a7f6c", 105, 53))
m.seasonInfoLabel = m.top.findNode(_l1d_6bae63("60595869585c7c626d678d73757d79", 235, 200))
m.episodesGrid = m.top.findNode(_l1d_6bae63("8e9c98a5a49ca0b1c8b6b0ae", 32, 73))
m.seasonDropdownGroup = m.top.findNode(_l1d_6bae63("dcf5f4e5040623f010f80f19041e3a08281513", 50, 155))
m.seasonList = m.top.findNode(_l1d_6bae63("b9c6cdc2d9ddbee4d1cf", 213, 19))
m.loadingNotice = m.top.findNode(_l1d_6bae63("b8bab3b9c1c5c1ebcfdbd3ccd5", 98, 170))
m.playBtn.observeField(_l1d_6bae63("f7e5e7ea080ada07110d16021618", 84, 193), _l1d_6bae63("a9ad9ab1afca97bdc3c0cbc0c4", 69, 127))
m.favBtn.observeField(_l1d_6bae63("ee000205eff1f102fc080d1d1113", 78, 194), _l1d_6bae63("3e401b3931214d4d4a555254", 80, 255))
m.seasonDropdownBtn.observeField(_l1d_6bae63("f7ebeff2fe02d80d0913140a1c20", 25, 124), _l1d_6bae63("94965e979687a6a88592b29ab1bba6c097b0c9a1d1d1cad5d6d8", 210, 215))
m.seasonList.observeField(_l1d_6bae63("e8cee2edfeebf5f1fae6fafc", 52, 139), _l1d_6bae63("414523545b4c53573c625b5d41726e787d6f8185", 31, 209))
m.episodesGrid.observeField(_l1d_6bae63("463648535c515d57584e6064", 113, 46), _l1d_6bae63("d1d3fdd3dfdce3ebef08f5effb04f00406", 60, 126))
m.episodesGrid.observeField(_l1d_6bae63("ede8c5e5", 155, 241), _l1d_6bae63("cdcff9c7d3d0dfe7ebdc13e1ebf91ffa13f1", 184, 246))
m.allSeasons = []
m.selectedSeasonIndex = 0
m.top.observeField(_l1d_6bae63("8a848ba4a19a9e", 75, 93), _l1d_6bae63("afb38eb8b7c4cda0cac4cec8c9", 197, 5))
end sub
sub onEpisodesGridGoUp()
if ((21204 - 7068 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.seasonDropdownBtn.setFocus(true)
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.playBtn <> invalid then m.playBtn.setFocus(true)
end if
end sub
sub onContentChange()
if ((58746 - 9791 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_lIl1lIl = m.top.content
if _lIl1lIl = invalid then return
m.backdrop.uri = _lIl1lIl.HDBackgroundImageUrl
m.poster.uri = _lIl1lIl.HDPosterUrl
m.title.text = _lIl1lIl.Title
_l1I1lIl = _l1d_6bae63("b7b8a2c4bb", 118, 156)
if _lIl1lIl.kind <> invalid and (_lIl1lIl.kind = _l1d_6bae63("bbc0", 60, 115) or _lIl1lIl.kind = _l1d_6bae63("ded3e5dddced", 33, 140)) then
_l1I1lIl = _l1d_6bae63("5556", 55, 18)
else if _lIl1lIl.ContentType = 2 then
_l1I1lIl = _l1d_6bae63("babf", 136, 190)
end if
_l1lIlIl = _lIl1lIl.Title
if _l1lIlIl = invalid or _l1lIlIl = "" then _l1lIlIl = _lIl1lIl.title
_lllIlIl = _lIl1lIl.HDPosterUrl
if (_lllIlIl = invalid or _lllIlIl = "") and Left(_lIl1lIl.id, 2) = _l1d_6bae63("898c", 121, 124) then
_lllIlIl = _l1d_6bae63("253437363a06fcff3c433a43445515555064525e6c5e2d7375676c713e84848b918395539a978e9ea165", 33, 220) + _lIl1lIl.id + _l1d_6bae63("f8bdbcc9", 236, 53)
end if
W_RememberContext(_lIl1lIl.id, {
title:  _l1lIlIl,
poster: _lllIlIl,
kind:   _l1I1lIl,
imdb:   _lIl1lIl.id,
year:   _lIl1lIl.ReleaseDate,
rating: _lIl1lIl.Rating
})
_lII1lIl = ""
if _lIl1lIl.Rating <> invalid and _lIl1lIl.Rating <> "" then _lII1lIl = _l1d_6bae63("3542", 155, 132) + _lIl1lIl.Rating + _l1d_6bae63("3134133a3d", 64, 209)
if _lIl1lIl.ReleaseDate <> invalid and _lIl1lIl.ReleaseDate <> "" then _lII1lIl = _lII1lIl + _lIl1lIl.ReleaseDate + _l1d_6bae63("bcbfeec5c8", 24, 132)
_llI1lIl = _l1d_6bae63("5859435d5c", 82, 57)
_lI11lIl = false
if _lIl1lIl.kind <> invalid and (_lIl1lIl.kind = _l1d_6bae63("3237", 204, 122) or _lIl1lIl.kind = _l1d_6bae63("879c8ea6a596", 177, 197)) then
_llI1lIl = _l1d_6bae63("878c61957f7f9a", 13, 46)
_lI11lIl = true
else if _lIl1lIl.ContentType = 2 then
_llI1lIl = _l1d_6bae63("23241525333732", 27, 212)
_lI11lIl = true
end if
_lII1lIl = _lII1lIl + _llI1lIl
m.subMeta.text = _lII1lIl
_ll11lIl = ""
if _lIl1lIl.Categories <> invalid and _lIl1lIl.Categories.Count() > 0 then
for _l111lIl = 0 to _lIl1lIl.Categories.Count() - 1
if _l111lIl > 0 then _ll11lIl = _ll11lIl + _l1d_6bae63("c0bf", 118, 102)
_ll11lIl = _ll11lIl + _lIl1lIl.Categories[_l111lIl].ToStr()
end for
end if
m.genres.text = _ll11lIl
m.description.text = _lIl1lIl.Description
updateFavButton()
if _lI11lIl then
m.seriesSection.visible = true
m.loadingNotice.visible = true
m.seasonDropdownGroup.visible = false
m.allSeasons = []
m.detailsTask = CreateObject(_l1d_6bae63("e0f6c5d4e0020002", 215, 59), _l1d_6bae63("6044364641474165554a55", 184, 100))
m.detailsTask.imdbId = _lIl1lIl.id
m.detailsTask.observeField(_l1d_6bae63("aabaafb0ccb7", 183, 229), _l1d_6bae63("d1d5b2d4e8d6e1e9edcfefe8f0f2f6", 3, 101))
m.detailsTask.control = _l1d_6bae63("696b83", 150, 165)
else
m.seriesSection.visible = false
m.loadingNotice.visible = false
m.seasonDropdownGroup.visible = false
end if
m.playBtn.setFocus(true)
end sub
sub updateFavButton()
_llllIIl = m.top.content
if _llllIIl = invalid then return
if WL_IsFavorite(_llllIIl.id) then
m.favBtn.text = _l1d_6bae63("647595d2649987a1a9a8b09d9985", 84, 85)
else
m.favBtn.text = _l1d_6bae63("423e54857b89959c9c858d", 18, 9)
end if
end sub
sub onFavClicked()
if ((28720 - 7180 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1I1ll1 = m.top.content
if _l1I1ll1 = invalid then return
_lllIll1 = _l1d_6bae63("8a8f998f8e", 224, 253)
if _l1I1ll1.kind <> invalid and (_l1I1ll1.kind = _l1d_6bae63("a5a6", 234, 7) or _l1I1ll1.kind = _l1d_6bae63("76677b797085", 38, 33)) then
_lllIll1 = _l1d_6bae63("4c51", 65, 23)
else if _l1I1ll1.ContentType = 2 then
_lllIll1 = _l1d_6bae63("383d", 28, 208)
end if
_lII1ll1 = {
id: _l1I1ll1.id,
title: _l1I1ll1.Title,
kind: _lllIll1,
year: _l1I1ll1.ReleaseDate,
poster: _l1I1ll1.HDPosterUrl,
rating: _l1I1ll1.Rating
}
WL_ToggleFavorite(_lII1ll1)
updateFavButton()
end sub
sub onDetailsLoaded()
if ((27365 - 5473 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.loadingNotice.visible = false
_lI1lIl1 = m.detailsTask.result
if _lI1lIl1 <> invalid and _lI1lIl1.seasons <> invalid and _lI1lIl1.seasons.Count() > 0 then
m.allSeasons = _lI1lIl1.seasons
populateSeasonDropdown()
selectSeason(0)
end if
end sub
sub populateSeasonDropdown()
_lI1Il11 = CreateObject(_l1d_6bae63("472d6c5b57394749", 111, 42), _l1d_6bae63("76959992a4a29b88aab4b6", 217, 220))
for _ll1Il11 = 0 to m.allSeasons.Count() - 1
_l1IIl11 = m.allSeasons[_ll1Il11]
_llIIl11 = _lI1Il11.createChild(_l1d_6bae63("bea5a7b0a4b0b9d6bab2b6", 100, 151))
_l11Il11 = _l1d_6bae63("1df2f106f5f9be", 169, 35) + _l1IIl11.number.ToStr()
if _l1IIl11.label <> invalid and _l1IIl11.label <> "" then _l11Il11 = _l1IIl11.label
_llIIl11.title = _l11Il11
end for
m.seasonList.content = _lI1Il11
end sub
sub onSeasonDropdownBtnClicked()
if m.seasonDropdownGroup.visible then
closeSeasonDropdown()
else
openSeasonDropdown()
end if
end sub
sub openSeasonDropdown()
if m.allSeasons.Count() = 0 then return
m.seasonDropdownGroup.visible = true
m.seasonList.jumpToItem = m.selectedSeasonIndex
m.seasonList.setFocus(true)
end sub
sub closeSeasonDropdown()
m.seasonDropdownGroup.visible = false
m.seasonDropdownBtn.setFocus(true)
end sub
sub onSeasonListSelected()
_l11l1lI = m.seasonList.itemSelected
if _l11l1lI >= 0 and _l11l1lI < m.allSeasons.Count() then
selectSeason(_l11l1lI)
end if
closeSeasonDropdown()
end sub
sub selectSeason(_lIIIIlI as Integer)
if _lIIIIlI < 0 or _lIIIIlI >= m.allSeasons.Count() then return
m.selectedSeasonIndex = _lIIIIlI
_l1IIIlI = m.allSeasons[_lIIIIlI]
_lllll1I = _l1d_6bae63("d5a2a9beb5b7f4", 228, 30) + _l1IIIlI.number.ToStr()
if _l1IIIlI.label <> invalid and _l1IIIlI.label <> "" then _lllll1I = _l1IIIlI.label
m.seasonDropdownBtn.text = _lllll1I + _l1d_6bae63("7f829abaa6", 147, 204)
_ll1IIlI = 0
if _l1IIIlI.episodes <> invalid then _ll1IIlI = _l1IIIlI.episodes.Count()
m.seasonInfoLabel.text = _l1d_6bae63("d6", 68, 106) + _ll1IIlI.ToStr() + _l1d_6bae63("83a1d9d3e0d7d1d3eca5", 5, 94)
_llIIIlI = CreateObject(_l1d_6bae63("adb3d2e1ddbfc9cb", 189, 222), _l1d_6bae63("68575b4456644d8a6c6668", 177, 118))
if _l1IIIlI.episodes <> invalid then
for each _lIlIIlI in _l1IIIlI.episodes
_l11IIlI = _llIIIlI.createChild(_l1d_6bae63("c6f5f9e6f802efe80a080a", 147, 246))
_lI1IIlI = ""
if _lIlIIlI.episode <> invalid then
_lI1IIlI = _lIlIIlI.episode.ToStr()
end if
_l11IIlI.id = _lI1IIlI
_l11IIlI.Title = _lIlIIlI.title
_l11IIlI.ShortDescriptionLine1 = _l1d_6bae63("120af40df40204cc", 175, 40) + _lI1IIlI
_l11IIlI.HDPosterUrl = _lIlIIlI.thumbnail
if _l11IIlI.HDPosterUrl = "" then _l11IIlI.HDPosterUrl = m.top.content.HDPosterUrl
_l11IIlI.Description = _lIlIIlI.description
end for
end if
m.episodesGrid.content = _llIIIlI
end sub
sub onPlayClicked()
_lll111I = m.top.content
if _lll111I = invalid then return
_lIl111I = _l1d_6bae63("eaebf7efee", 35, 156)
if _lll111I.kind <> invalid and (_lll111I.kind = _l1d_6bae63("8c91", 185, 191) or _lll111I.kind = _l1d_6bae63("c0d9c5e3e2cf", 242, 63)) then
_lIl111I = _l1d_6bae63("b1b2", 135, 190)
else if _lll111I.ContentType = 2 then
_lIl111I = _l1d_6bae63("e7e8", 231, 84)
end if
_l11111I = 1
_l1l111I = 1
if _lIl111I = _l1d_6bae63("cfd0", 247, 76) and m.allSeasons.Count() > 0 then
_ll1111I = m.allSeasons[m.selectedSeasonIndex]
if _ll1111I <> invalid then
_l11111I = _ll1111I.number
if _ll1111I.episodes <> invalid and _ll1111I.episodes.Count() > 0 then
_l1l111I = _ll1111I.episodes[0].episode
end if
end if
end if
m.top.playAction = {
imdbId: _lll111I.id,
title: _lll111I.Title,
kind: _lIl111I,
season: _l11111I,
episode: _l1l111I,
poster: _lll111I.HDPosterUrl
}
end sub
sub onEpisodeSelected()
if ((16908 - 5636 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1III1I = m.top.content
if _l1III1I = invalid or m.allSeasons.Count() = 0 then return
_l1lllII = m.allSeasons[m.selectedSeasonIndex]
_lllllII = m.episodesGrid.itemSelected
if _lllllII >= 0 and _lllllII < _l1lllII.episodes.Count() then
_lIIII1I = _l1lllII.episodes[_lllllII]
m.top.playAction = {
imdbId: _l1III1I.id,
title: _l1III1I.Title + _l1d_6bae63("d3e3d90b", 130, 49) + _l1lllII.number.ToStr() + _l1d_6bae63("daba", 246, 4) + _lIIII1I.episode.ToStr() + _l1d_6bae63("e6e1", 248, 14) + _lIIII1I.title + _l1d_6bae63("4f", 138, 172),
kind: _l1d_6bae63("4e4f", 186, 128),
season: _l1lllII.number,
episode: _lIIII1I.episode,
poster: _l1III1I.HDPosterUrl
}
end if
end sub
function onKeyEvent(_llI11II as String, _l1I11II as Boolean) as Boolean
if not _l1I11II then return false
_lI111II = LCase(_llI11II)
if _lI111II = _l1d_6bae63("6850576f74765e", 82, 43) or _lI111II = _l1d_6bae63("99", 189, 2) then
onFavClicked()
_lII11II = m.top.getScene()
if _lII11II <> invalid and _lII11II.hasField(_l1d_6bae63("c8c6c2cdb3cbccdddf", 7, 84)) then
if m.favBtn.text = _l1d_6bae63("3122427f3146544e56555d6a6652", 68, 18) then
_lII11II.showToast = _l1d_6bae63("bbe3e6e8ecabe2fab4c8f9f1fd0b1210f903d1", 147, 233)
else
_lII11II.showToast = _l1d_6bae63("16eef9fa06fafe3d02110f144c40112915232a28313b", 99, 229)
end if
end if
return true
end if
if m.seasonDropdownGroup.visible then
if _lI111II = _l1d_6bae63("04060b16", 224, 130) or _lI111II = _l1d_6bae63("17212318", 27, 160) or _lI111II = _l1d_6bae63("88727b778e", 44, 42) then
closeSeasonDropdown()
return true
end if
return false
end if
if _lI111II = _l1d_6bae63("202c2c21", 26, 170) then
if m.favBtn.hasFocus() then
m.playBtn.setFocus(true)
return true
else if m.seasonDropdownBtn.hasFocus() then
if m.selectedSeasonIndex > 0 then
selectSeason(m.selectedSeasonIndex - 1)
end if
return true
end if
else if _lI111II = _l1d_6bae63("0701fa060d", 4, 145) then
if m.playBtn.hasFocus() then
m.favBtn.setFocus(true)
return true
else if m.seasonDropdownBtn.hasFocus() then
if m.selectedSeasonIndex < m.allSeasons.Count() - 1 then
selectSeason(m.selectedSeasonIndex + 1)
end if
return true
end if
else if _lI111II = _l1d_6bae63("d2e0cbe5", 84, 162) then
if m.playBtn.hasFocus() or m.favBtn.hasFocus() then
if m.seriesSection.visible then
m.seasonDropdownBtn.setFocus(true)
return true
end if
else if m.seasonDropdownBtn.hasFocus() then
if m.episodesGrid.content <> invalid and m.episodesGrid.content.getChildCount() > 0 then
m.episodesGrid.setFocus(true)
return true
end if
end if
else if _lI111II = _l1d_6bae63("b1b7", 36, 96) then
if m.seasonDropdownBtn.hasFocus() then
m.playBtn.setFocus(true)
return true
end if
end if
return false
end function
function _l1d_6bae63(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function