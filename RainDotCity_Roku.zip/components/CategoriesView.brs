sub init()
m.btnLiveTvHub = m.top.findNode(_l1d_2b2032("9a93acd1af9db1c5a6dfadbb", 115, 137))
m.btnWatchlist = m.top.findNode(_l1d_2b2032("9eb3b09aa7bfafb9c0becbd1", 65, 123))
m.btnKeyAuth = m.top.findNode(_l1d_2b2032("23301d03283712414534", 205, 116))
m.btnAction = m.top.findNode(_l1d_2b2032("3a4b34264757474446", 14, 206))
m.btnScifi = m.top.findNode(_l1d_2b2032("5d4a577568616b67", 125, 62))
m.btnComedy = m.top.findNode(_l1d_2b2032("95aea77faeb3aeb0c8", 66, 117))
m.btnHorror = m.top.findNode(_l1d_2b2032("3a47345939595c4262", 237, 171))
m.btnThriller = m.top.findNode(_l1d_2b2032("b3a4bd8ac9b2d0ced1cdc1", 86, 127))
m.btnCrime = m.top.findNode(_l1d_2b2032("c6dfd8b0e2e0e7e2", 2, 102))
m.btnAnimation = m.top.findNode(_l1d_2b2032("53645d7f636d6c6b79797678", 38, 15))
m.btnDrama = m.top.findNode(_l1d_2b2032("c5b6cfacc1d5dcdb", 87, 144))
m.btnRomance = m.top.findNode(_l1d_2b2032("cdbad7a6dcdddce6e4e1", 149, 214))
m.btnFantasy = m.top.findNode(_l1d_2b2032("c8b5c2edd3cbc4dcd1ca", 124, 170))
m.btnKids = m.top.findNode(_l1d_2b2032("081d1a3a1b192b", 32, 198))
m.btnDoc = m.top.findNode(_l1d_2b2032("3a47345d3b4a", 172, 108))
m.btnHistory = m.top.findNode(_l1d_2b2032("8075926f938084a28892", 80, 78))
m.btnBio = m.top.findNode(_l1d_2b2032("98a9a281adaa", 135, 179))
m.btnSport = m.top.findNode(_l1d_2b2032("87948181a18ba9a6", 76, 89))
m.btnWestern = m.top.findNode(_l1d_2b2032("f7e8f10d02f7f70bff06", 126, 219))
m.btnReality = m.top.findNode(_l1d_2b2032("6d827fa67a798987979d", 97, 106))
m.btnMoviesAll = m.top.findNode(_l1d_2b2032("5e7370927781777687988689", 224, 220))
m.btnSeriesAll = m.top.findNode(_l1d_2b2032("9891aab2ab97b5b4a1d6c4c7", 242, 8))
m.rows = [
[m.btnLiveTvHub, m.btnWatchlist, m.btnKeyAuth],
[m.btnAction, m.btnScifi, m.btnComedy],
[m.btnHorror, m.btnThriller, m.btnCrime],
[m.btnAnimation, m.btnDrama, m.btnRomance],
[m.btnFantasy, m.btnKids, m.btnDoc],
[m.btnHistory, m.btnBio, m.btnSport],
[m.btnWestern, m.btnReality],
[m.btnMoviesAll, m.btnSeriesAll]
]
m.curRow = 0
m.curCol = 0
if m.btnLiveTvHub <> invalid then m.btnLiveTvHub.observeField(_l1d_2b2032("d0c2c4c7d1d3f3e4deeaefdff3f5", 62, 116), _l1d_2b2032("f0f4d9f71509fd1efc15111b18322428", 75, 204))
m.btnWatchlist.observeField(_l1d_2b2032("e3dbdfe2eaee04fdf90300fa0c10", 187, 10), _l1d_2b2032("bdbf8bc4b2c8d4d3dbc4c4aadbe5e1e6d6eaec", 86, 132))
if m.btnKeyAuth <> invalid then m.btnKeyAuth.observeField(_l1d_2b2032("d3e7ebeedaded4e9e5eff006f8fc", 9, 104), _l1d_2b2032("1b1dfd1a11fc13152cfa2f3935362a3e40", 16, 156))
m.btnAction.observeField(_l1d_2b2032("7d97999c9698c099a39f9cb4a8aa", 98, 125), _l1d_2b2032("999d81a69ca2abaf85bab6c0c1b7c9cd", 25, 35))
m.btnScifi.observeField(_l1d_2b2032("04f6f8fb1517e718221e23132729", 150, 16), _l1d_2b2032("abad8dc0b9c1bf9cc9c3cfd8c4d8da", 28, 56))
m.btnComedy.observeField(_l1d_2b2032("c5bbbdc0ced0e8ddd7e3e4d8ecee", 184, 235), _l1d_2b2032("1f21f9282924263e1b303a36374b3f41", 192, 112))
m.btnHorror.observeField(_l1d_2b2032("1f111316303202333d393e2e4244", 214, 107), _l1d_2b2032("494d6a526a6d5b73956a66707187797d", 105, 67))
m.btnThriller.observeField(_l1d_2b2032("ede7e9ec06081009130f0c04181a", 178, 29), _l1d_2b2032("8b8f5897849c9c9f999375a2aea8b19fb1b5", 21, 17))
m.btnCrime.observeField(_l1d_2b2032("a5b1b5b8a4a8a6b3afb9c2d0c2c6", 205, 246), _l1d_2b2032("616553876f6e79727f7b858e9c8e92", 141, 127))
m.btnAnimation.observeField(_l1d_2b2032("4d3d41445c606e5f6b656a5c6e72", 183, 120), _l1d_2b2032("060aee100c131a12182125fb302c36372d3f43", 89, 208))
m.btnDrama.observeField(_l1d_2b2032("bfd3d7dac6ca00d5d1dbdcf2e4e8", 41, 116), _l1d_2b2032("b3b59ed7c9c0cfc4d1cbd7e0ece0e2", 12, 80))
m.btnRomance.observeField(_l1d_2b2032("7c72747795979f949e9a9b8fa3a5", 176, 170), _l1d_2b2032("dee209e7ece3f1e7f01df602fcf9130509", 163, 18))
m.btnFantasy.observeField(_l1d_2b2032("9bb3b7baa2a69cb5b1bbb8d2c4c8", 203, 242), _l1d_2b2032("4c503b57595260554e3b706c76776d7f83", 89, 22))
m.btnKids.observeField(_l1d_2b2032("685a5c5f696b4b7c768287778b8d", 94, 44), _l1d_2b2032("4a4e2c4d5d6d5065616b6c827478", 201, 164))
m.btnDoc.observeField(_l1d_2b2032("647e80836d6f67807a86839b8f91", 74, 60), _l1d_2b2032("9a9cc5a3aabdb2acb8b9adc1c3", 56, 67))
m.btnHistory.observeField(_l1d_2b2032("eae2e6e901050b04100a07011317", 243, 89), _l1d_2b2032("4a4e2b4d5a605c646c495e6a64657b6d71", 1, 220))
m.btnBio.observeField(_l1d_2b2032("4b5b5f624a4e8c5d5963687a6c70", 111, 62), _l1d_2b2032("b2b493c1beadbec8c4c9d9cdcf", 70, 137))
m.btnSport.observeField(_l1d_2b2032("7f8d8f929092828f99959eaa9ea0", 4, 25), _l1d_2b2032("0509371911211e46131f1922302226", 229, 123))
m.btnWestern.observeField(_l1d_2b2032("5a4c4e516b6d7d6e787479697d7f", 246, 198), _l1d_2b2032("9a9c78ada2a2b6aab191c2bcc8cdbdd1d3", 222, 233))
m.btnReality.observeField(_l1d_2b2032("9fb9bbbea8aaa2bbb5c1bed6cacc", 74, 119), _l1d_2b2032("1e2261313830364e4c7546424c51635559", 175, 94))
m.btnMoviesAll.observeField(_l1d_2b2032("cedadee1cdd10fdcd8e2ebf9ebef", 109, 191), _l1d_2b2032("5052785943655c51866c6f7d6e787479697d7f", 246, 183))
m.btnSeriesAll.observeField(_l1d_2b2032("6355575a74764677817d82728688", 86, 47), _l1d_2b2032("eef2e8fd0ff70617e8080b0318141e1f35272b", 9, 136))
m.top.observeField(_l1d_2b2032("7b8786979c8d8f", 166, 187), _l1d_2b2032("b5b994bebdaeb3a6d4ced4ced3", 151, 189))
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.btnWatchlist <> invalid then m.btnWatchlist.setFocus(true)
end if
end sub
sub onLiveTvSelected()
if ((68823 - 7647 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.categorySelected = _l1d_2b2032("b7bda3b7abac", 23, 60)
end sub
sub onWatchlistSelected()
m.top.categorySelected = _l1d_2b2032("e2f3e9f7030a0af3fb", 82, 189)
end sub
sub onKeyAuthSelected()
if ((33760 - 6752 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("01fe1500171910", 160, 54)
end sub
sub onActionSelected()
m.top.categorySelected = _l1d_2b2032("8d927e9e9fa1", 52, 56)
end sub
sub onScifiSelected()
if ((11540 - 2308 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("3b4e5b5961", 243, 187)
end sub
sub onComedySelected()
if ((45654 - 7609 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.categorySelected = _l1d_2b2032("212829242626", 20, 170)
end sub
sub onHorrorSelected()
m.top.categorySelected = _l1d_2b2032("2a2c1a1d3523", 116, 14)
end sub
sub onThrillerSelected()
if ((64610 - 9230 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.categorySelected = _l1d_2b2032("63726f79777a867e", 60, 27)
end sub
sub onCrimeSelected()
m.top.categorySelected = _l1d_2b2032("08fa181f1a", 146, 23)
end sub
sub onAnimationSelected()
m.top.categorySelected = _l1d_2b2032("c0bebec5ccc4cacfd3", 123, 166)
end sub
sub onDramaSelected()
m.top.categorySelected = _l1d_2b2032("445145544b", 35, 253)
end sub
sub onRomanceSelected()
if ((8139 - 2713 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.categorySelected = _l1d_2b2032("6b5354635b6b68", 172, 141)
end sub
sub onFantasySelected()
m.top.categorySelected = _l1d_2b2032("9c9c9a97a59693", 187, 191)
end sub
sub onKidsSelected()
m.top.categorySelected = _l1d_2b2032("28293729", 24, 181)
end sub
sub onDocSelected()
if ((12873 - 4291 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("8d9b9aa7a29da9b2aabec8", 228, 13)
end sub
sub onHistorySelected()
m.top.categorySelected = _l1d_2b2032("a2a49197b39ba3", 241, 9)
end sub
sub onBioSelected()
if ((42490 - 6070 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.categorySelected = _l1d_2b2032("e6e0e1ec02f406f105", 172, 24)
end sub
sub onSportSelected()
if ((41688 - 6948 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.categorySelected = _l1d_2b2032("5c5c766461", 212, 181)
end sub
sub onWesternSelected()
m.top.categorySelected = _l1d_2b2032("7768797d718170", 136, 120)
end sub
sub onRealitySelected()
m.top.categorySelected = _l1d_2b2032("645e5d5b5b7971", 10, 236)
end sub
sub onMoviesAllSelected()
m.top.categorySelected = _l1d_2b2032("000511050415", 33, 180)
end sub
sub onSeriesAllSelected()
m.top.categorySelected = _l1d_2b2032("e2efe701f8f1", 244, 91)
end sub
function getCurrentPosition() as Object
if ((43115 - 8623 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
for _llIIl11 = 0 to m.rows.Count() - 1
_l1IIl11 = m.rows[_llIIl11]
for _lI1Il11 = 0 to _l1IIl11.Count() - 1
if _l1IIl11[_lI1Il11] <> invalid and _l1IIl11[_lI1Il11].hasFocus() then
return { r: _llIIl11, c: _lI1Il11 }
end if
end for
end for
return { r: 0, c: 0 }
end function
function onKeyEvent(_lI11I11 as String, _l1I1I11 as Boolean) as Boolean
if not _l1I1I11 then return false
_l111I11 = getCurrentPosition()
_lllII11 = _l111I11.r
_ll11I11 = _l111I11.c
_l1lII11 = m.rows[_lllII11]
if _lI11I11 = _l1d_2b2032("88a0a1a796", 209, 229) then
if _ll11I11 < _l1lII11.Count() - 1 then
_l1lII11[_ll11I11 + 1].setFocus(true)
return true
end if
else if _lI11I11 = _l1d_2b2032("b9c5c9da", 232, 53) then
if _ll11I11 > 0 then
_l1lII11[_ll11I11 - 1].setFocus(true)
return true
end if
else if _lI11I11 = _l1d_2b2032("37314c36", 10, 201) then
if _lllII11 < m.rows.Count() - 1 then
_llI1I11 = m.rows[_lllII11 + 1]
_lIlII11 = _ll11I11
if _lIlII11 >= _llI1I11.Count() then _lIlII11 = _llI1I11.Count() - 1
_llI1I11[_lIlII11].setFocus(true)
return true
end if
else if _lI11I11 = _l1d_2b2032("b2ba", 111, 152) then
if _lllII11 > 0 then
_lII1I11 = m.rows[_lllII11 - 1]
_lIlII11 = _ll11I11
if _lIlII11 >= _lII1I11.Count() then _lIlII11 = _lII1I11.Count() - 1
_lII1I11[_lIlII11].setFocus(true)
return true
else
return false
end if
end if
return false
end function
function _l1d_2b2032(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function