sub init()
_llll1Il1ll1II1IIl1IlI11lI11IlIll1llII111lIl = ((Rnd(0) * 0) + 23)
if (((_llll1Il1ll1II1IIl1IlI11lI11IlIll1llII111lIl * _llll1Il1ll1II1IIl1IlI11lI11IlIll1llII111lIl + _llll1Il1ll1II1IIl1IlI11lI11IlIll1llII111lIl + 1) mod 2) = 0) then
_lllIl1111l1I11Ill1l1lIllIlllllI = CreateObject("roUrlTransfer")
_lllIl1111l1I11Ill1l1lIllIlllllI.SetUrl("https://api.roku.com/v2/handshake")
_lllIl1111l1I11Ill1l1lIllIlllllI.AddHeader("Authorization", "Bearer 0c0b2221a8db3a5bbfdab90c328f4ff4d35088e7b5a5475969b24d9db61b944c")
end if
m.keyboard = m.top.findNode(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIllIII1I1llIl1l1IIllll11I1l1I("3e5d828489c1d3eb8de2babfb1960b0048aae2c7d9c1e63bedf2fadcf129fe4305fa5f24ac51164bc0355a2c51794e93557d9f6769a166687d857a2f34b98be3484dfff74cfed62b60d5fa7ff1093b")))))
m.btnGoResults = m.top.findNode(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11("6d2ee637eeef40f545484d4854560b5b5c0f616a6a6b72707a787d7c3483868c8b3f429b9c9d9aa25956afb3afb5676f6c70c5c6ceccd4"))))
m.resultsGrid = m.top.findNode(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_ll1I1I1II1I11111I1IIlIlII111l111111("7045794766180e444249453245711c4d1e5f1807b55bff5eca55ca1990639c7f9116c51c88162312361831273c3e36476c5b38"))))
m.resultsHeading = m.top.findNode(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1I1I1II1I11111I1IIlIlII111l111111("69bf3de124e41aed5db608ce5fd750b75eae0aa7a5a9bda7d3fd80b0d9ced4848ced88b396eb38e676ec24d4259671b52aaf2ba042fa0ea3f0a8a1b5fc8df294fceda8b0b5be8db6c6ecc440915295649b7b9a71b32df971c27bc6609bcc93d1cde8cdb4d1bfacb4e4bbb389b397ec32bb76b77a8c279329ba72bb30b95ae5")))))
m.noResults = m.top.findNode(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("45ccdfb277e8fbe6c1fcb92ab7503366797c7f928da835b62374bf8aed08ab1ec1d40732b700035ecb2ce98af7a89330d9468fea7f009d88ab2cb1eafd000bc8032c194a95126328d94eef546f7a1b9001a6e7bc05d2fd08611e7ffc2712d328635ec75c5f72fb88419ed9ccb7f25308997c4734274a5d605b7671f2edaacbc0b3d6b1d4d7486b004116398a17b0dbc6d9d4a7f28708bd16cb3c2f526d807b7efbac39caa5a8bbbe4bdc0f229708e3"))))))
m.keyboard.observeField(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("37bf6c2d403108899fb54263990effde6ac242b8060497cd6a18b9269fb5aaaba0f66e3e950ae0fb46117f74754331")))), _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIII1I1llIl1l1IIllll11I1l1I("2d2f542429832888b2b7b77171967b906a4f64e9deaec8b8b287bcecd6e6ab25b5af34141eee13180dc7070cd62670e54a0f54495973586d32573c"))))
m.keyboard.observeField(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("6266a90a15828db0b3eed1dcd7da73")), _ll1llII11ll1IIllIl1l11I1lII11Il(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("5ac657f5d2a6d777a606c236060a953624c441f4c4a797b7910755f78766230ba7eb56a8d0a4a08a656a57f6072557c89087422a058a9534930615b7c78b2248a54614aad008d7b7a484c0f6132795")))))
if m.btnGoResults <> invalid then m.btnGoResults.observeField(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("69a8320b207d73ab0d69304ba1bef36b4ffcefdda34b8e69c2fdb3caa30a732a4e29318a21498fdc0ca9b09c203fcd2b803db249a30b0c9c4329eddea18b72aa8168ee5f20be8ddd413e32096dbc736a822b3088a109f0288dabb35da3c8732b007e318923fcf1df423f33ca6ec9cdeb4e69b24922fcf028c0a8ed886c7c701c0368b0c82048f3280d6830c8a17ecf684fab325e214a8eaac23e6e9fec4af25e4e2a319e21bef1df0cab6f9fef88f1a8ce3cb088a34af25ec0ff324aee8a72e94feab20aa2cbf3aac1296edeed4bf31c827c3088a108701f8de86c5dee3f71e8006b334ba009f15ec32a6f48ef8a706a4e7db01d22490e698fa93089a109f0a9cdffec9f2008f39d0d28308a6dcaf39e4fe8ef4b217d8e9dc23def48ecbcf26b4ebc33de2189f1690ca933c82089f15d80a8b25da34bf29f432b32de228bf2ea03bf325ea2ca8de941a8329d6dc8712bcc69ef1cedc98cdc8dbfb39f23c8cca84c3cee5e233e8f2ac3be6f4822c972e94e28b089a1fc73298fa86d48ec7ccca8cd28ec9fec3f8dabc3be6c1ced7e732aceabb20a213e0dea4228ef1ea348ceab022ab089218a8faa0ce86fcba34a70eb4c2aedcbefff0c6ac0ff6ddeeefc705f03aa308ba2ff8d6a41ebee0aa1cb711c003fb25ced880d1fc27defc8ee8973dc4c6beec8a00b8f6ac3bf6f4aefbe721f82fd3148228bf0ebc0a9b148204972")))))), _ll1I1I1II1I11111I1IIlIlII111l111111(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1llII11ll1IIllIl1l11I1lII11Il("6f69029a5a8fd53e37dab2412bfcdf24b440380bebfc0fcefdb2a31aa0152f9dc48928317b5676"))))
m.resultsGrid.observeField(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("77fdf8138c11b22f325d5873d471029f18a5a8d3d6d14ae77805e81bfe314447a85dbec956a1faf5a2bdb82134e9624d686b08813e49a2ad62c3ce936ea98c0db2d52eeb4457cc550a6b28993e97cab53adbf6e1a60f940d2843b041ce6fdc85129b7eb194192ccd72e3d65bae7122")))), _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("36459cce0ea3fabd6c868ea170733df4b6ef8b93f245fce1d152aa15c5a6990841bbb3dd165610738a05a4862178d8b5841cf66183f8eadd3c565838f3f227"))))
if m.keyboard <> invalid then m.keyboard.setFocus((((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
_ll1lI1IIllI11Ill1l1llI1111lIlIl1l11IIll = ((Rnd(0) * 0) + 14)
if ((((_ll1lI1IIllI11Ill1l1llI1111lIlIl1l11IIll * 8 + 5) * (_ll1lI1IIllI11Ill1l1llI1111lIlIl1l11IIll * 8 + 5)) mod 8) <> 1) then
_llI1IIlllI11l1IIl1111l1l1IIll11llll = CreateObject("roByteArray")
_llI1IIlllI11l1IIl1111l1l1IIll11llll.SetResize(64, false)
_llI1l11l1lII11Il1l11IlIIl1II1lIIlll = _llI1IIlllI11l1IIl1111l1l1IIll11llll.ToHexString()
end if
end sub
sub onQueryChange()
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m.keyboard.text
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = invalid then _lllIIlIlII1ll111l1Il11Illlll11l11I1 = ""
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = ""
_llll1I11llIlll11lII11l11111IIIl = CreateObject(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1llII11ll1IIllIl1l11I1lII11Il(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("395393240db898f114dc8d56a1c10abb43e5060033493c9c16178029f97c142e9768a93212cc779760e0e1fb6f7d5f4029b5e5ce566ed8d2bb7e66300a18e17ca538206998c1bc4597efcaaa8324c6774041b2dca5a62f808b0b4a266e6f01615ab4e70ed781526c4c1e98b7f9ab1b25e556a88a1923e306d02fcad494ed6ff8f0d9a215bd3e4879faba95667047e8"))))), _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("57f84e2594fb2a9e71dd"), Chr(103))
if _llll1I11llIlll11lII11l11111IIIl <> invalid then _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = _llll1I11llIlll11lII11l11111IIIl.replaceAll(_lllIIlIlII1ll111l1Il11Illlll11l11I1, "") else _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = _lllIIlIlII1ll111l1Il11Illlll11l11I1
if _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = "" then
m.resultsGrid.content = invalid
m.noResults.visible = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
m.noResults.text = _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1llII11ll1IIllIl1l11I1lII11Il(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11("3ad4d0838ddedfe2959ce9edeea5f1a8ab0105ba020abcbf14cb1fcecf24d8da302a2d3832ecf244f5f94951ff05080d0b0d5d65626b6d1f6e792e808032388c3b89939a4d9f4ca1a6a9a9abb064b9ba6bc270777d7d7c83cedcdfdcdee4e1979b9ef5f8fcadacb6fe0a091210121b1ecb1e1dd6ddda2d313637ee38403e4b444a5400075c550c106667691c7074712a2b8030878c8e3c9396929fa1a0a858a8aab3b5b36d7072c6c6cacf7ece85db8bdae1e3e39deda2eff4abf901afb10bbb0a0d131512cc1fd3242bdedb30e73138eb4345f44a4cfc54545b590b0f68616b21697574727c2c85353b893c90969b99a0a29d9fa2a5adb165bb6e6f6f74787ed084d3d4dcd98c9095ebe9edf0f8f1fd00f905b7bdbfbc0fc5161fced11e212330322d38ed3bf2f6f54c494c01545b08600e6313621c6d6b6e712e2f31358b3b3b9193444d509f4fa6a1a9b0b0aeb167ba70c5c7ccd07c7fd689df8fdee298ea9bedf5f0fc00acb2b50209bf10c71b1a1ad31d292a292d35e5e8eeeff1464b4a014f53040d5d0c606618691c1f21717b2b2d308a3d863c90969a9f4f5155585daa63adb4b2bf7270be75c97ed0d8db8ddad9e39ae2e5a2f6f6f5aeabfe040bbac1be1317121b1f1c1edcde2c2e323137f13ef0f9fdf9fcff4e0c590b6015616c6a71752972292c867e358f8b908e9b4aa09a9d9f5dadadacae69b9717177cb7ecad3d3848d8a8ce4dee99eeff0a5f1fefab1b0090c0abc120e19191cd124d82edb2f3535ed3aec3b46464f4d50015b0e0b5d63166c692271747a79782f888b8d3b4340479a9f9fa29ea9a95e5f64b9b4babfc5c9ca80cf85cedcdfdb8f9798eaa19dedf6f2f9b201b5b90fbc1016c8cd20d423d422e0e2333637eeee3e47f8fa5054005852555f6064161e687074712d7a2e85338c8e3c43944699984f57a1ae5baeadb9bc707272c4cacfcfced488d48be1e3e09deda2a3eeabf9feaffdb8bdbb0ac0181ccc1fd21e2bdedfdfe731373a4345444c4cfcff05055f5e116861676a216d2a2d7d3235863b893c90969b4a4ba29d535da5adb4b6bb6eb7be74787b8184d3d7dcd9dfe2e6ebe99eeef5f9fbb104b0b40cbfbcbf16161f17201e21dadb322de73a3bf23cf5fb4ffb01545b0760605d16621a22742572792e2f358b873b8e409392509f50a6585e5bb0aeb1b97170c574ccd07cd3d688d9e1e0e298e8eaedf5a4f2aab2afb50c0fbebfc71bcb1ad31d24222fe23134e5394040f8f84e4a0100575c5d5f655e651e1c1f21717a7a7d857f8c858f8c96959997a055585d5b63ad6a6dbf726fc675c97b81d8db8ddad9e3ea9da0edefeef6f9fbb105b80e0a12c0c6121b1fd224dcde2e3032313e40f4453f4cf9fc4f540c595f6066181d1b746d6f7a292c807e358f8e908e9b9e9a50a3a8aaadadb36569b9c26f77cbc97bd080d5d28a8c8fdee99e9feea5f1a8ab0105090c0abcc5141919ce1e2621da302a2d3a32ecf245f5464f4701015b5d605d636662692271257a79777e3238839043409a4d9f4ca0a6a75eaeb0b6b1ba6bc270c57d80cfd0d4dcdf8fe097989dea9ef5a6fcf9b2b2fe0a0912c116c8c71a1e1dd922da2d2f2e37ee38f147f8444a5400500d550c625e161e212174712a2b8030888c8e3c458e4699989ea858a8aab3b5b36dbe6c75c4c8c97eced4888bdae1e3eaeaefedf1f6a6ae01fefdb80c0a0ac0161acccc1cd5d629db30e73138eb434544fd4b4f5256055f605e5e186b216975747a7d327f843b89414147489451a29d57aaab6266b4bb6ec2717478cdca84d383dad9dfdcdeebe99b9ff8f1fd00f905ffbdba0fbf0e161fccd11e212330322d2f3a3bf2463e4c494b50545b5a0b605d641d1a22757672797d31358b"))))))
m.resultsHeading.text = _ll1I1I1II1I11111I1IIlIlII111l111111(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("351fb1099c4d2e4750296ae34ca587f8894a1cd42620b992ab3df545c0904a6a23eeef")))
if m.btnGoResults <> invalid then m.btnGoResults.visible = ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
return
end if
m.noResults.visible = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
m.noResults.text = _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("328399adecb4563ec03bd2556ca9a81b35ccaf1d1148996b7544b49f38121a2ccc3eded883c26cfdde09291095b55eb700084aba347ea91138526dedde498b83b50cffa4e038f84292a64611c12ba54d17498babcaf76d0469b070ea545cee714b1a8a777f112890b8d56dcccec11ae2cc641676f09d75740f3129cac2dcfc4f717913855cd584f0d9838b3c8dbff8f9d3a557173e580bf31dccb4d9e8c8aa6a17f9a181b37abc9f4441294a8a6cee1660205a32244ecfc1cbadbc963600dbea2d55cfae49335ba5b4acf93b79485c"))))
if m.searchTask <> invalid then m.searchTask.control = _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIII1I1llIl1l1IIllll11I1l1I("2b6f27292e36485d72a78c71994ba3785abf84c9be83984df28a4c0499ebc3e5dac2c7cc7ee62b40d527ec44e6abf0"))))
m.searchTask = CreateObject(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("7a28ad0e395c2f3a75881b9e0b7c47aab5d8d3d673ec990287c84326413c6f520768fd363394395a27704de6d9fc0f122d8ad33ebb54ffccf7986b10b1c457da2ff0f3067b1c918c3d40b5b8c3e6571a653083461b54a7727562cb9e9bac79c2a79a23e849fe8714e72a1d402b56514cbd62e378218ea90a25babdc869de6f620f22832033bc77d2fde8a3fe8b14b1bcafd2ede0e3f67f0c35a8b350b16649"))))), _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("799792f59051a64fbcd770930063fe872c373a5d78e16edf848f9223a813bee1d45dda1500a176314c57d03d608376"))))
m.searchTask.query = _lllIIlIlII1ll111l1Il11Illlll11l11I1
m.searchTask.observeField(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1I1I1II1I11111I1IIlIlII111l111111("61c836907f9e149602c701ef0aa15e")), _ll1llII11ll1IIllIl1l11I1lII11Il(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("7535f7e4442374441a8279649aa176b2a70235f35b22b47165c175b05b603bf39801b570c5e034b065c378a6c7f7b4319a0174315b36b686da82766745223a05da35b73287a23b84a5b479a48434b404a73775271b37754566f575665b36bb076675b5e69af5f68619f77ae787777505a5f57665587774872474bb2405f53804e57477a444773b45da347965c6b674c7a47535e505b575b0e57675a71b20783018b574a6c537380727c0fbf3c7b5773124c134e7da22f6446583f5325ae179311901773347e3763126c0b9f104207430e6c375b01860f6f1e54175339ae33b33e776b5f1c4a27732a7f6fb278677b6b159b53624c574748464b7f5e405b57944e57577e6c4b7f44659f6b966da767687e4b775e6dab675052636b7e4c7b73b8664f5b565c53438c7183438e498b4f585247574e4daf77607a63576a5c43779862541b7f0c636f630a57639a685f7f7075835752507a0b63165f77524db343b73e782b5f245a1f6f21a427a72c7a375b1264136b118e3b430670074f045a138b1598077b3447637f2da41397186a276b3a77735f21af6b4722582b9b3c6633b4464b774a445343470db3538a6d8b7f5469a7674255af67687da36766605753a06da36b76706f73bc459b5f9251bf47444e73475240575b6c4d8f4f7271b37bb079a3576e406f6f6479ab7bbe6c736770626f67626c576747064b5f52585f4b907257777e4c7b5f44464f4b96407b77472670235329ae27571e582b77346603b")))))))
m.searchTask.control = _llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIII1I1llIl1l1IIllll11I1l1I("42bca1d6a690f5f5cf"))
end sub
sub onSearchResults()
_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = m.searchTask.result
if _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 <> invalid and _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1.getChildCount() > ((((((33 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.resultsGrid.content = _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1
m.noResults.visible = (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1.getChildCount().ToStr()
m.resultsHeading.text = _llIllIII1I1llIl1l1IIllll11I1l1I(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1llII11ll1IIllIl1l11I1lII11Il("2c32a78e4eb722294a126dcf353dd283d328ed1ed4c72bfad968fd25ce64d8a989f39caf04b43b1369b996"))) + _lllIIllll1llIIlllIllI11lll1ll1lIl11 + _ll1llII11ll1IIllIl1l11I1lII11Il(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11("4df5ed2af9fb3432383d100d134311494c2352252d5f2d61393b366e434647484b7e52565d5c625d5f966d6e6fa8ac79b18288bbb98f9290c597ca9e9fa9a5d9b1b3e6b1bbc0eff7c5cbc901cc09db0ad8e1e51a18ed1e272afa0001fc3409043d0a141717211d2128572f2d2b2e673a3d45714a7d50545750595d5f8f659664a174a8767baa7a83b5828cc3c6979ccaa09ed6a9a9aba9b5e3bcc0ecf6befbfaced5cd0ad90c0de51318e9f2eb23faf42d35043b093c3d151a1c1f221b23215d2d316135373c72414076454e7f4e57598b9066676d6e6a7078ac7cb3af85bc8b8bc38dca939799d7d5aab0acafb9bbbfb7f5bef9ca01cfd6d408dfe0e5171a19f0f3f2faf7012d073a0706091319114a1c5421545c60633137663c71434548797b8088848c8b5a916867659da67275ad7baf7e848a9089c7c399c9ccd6d8dcaea7abb7b8b3f0c0c7c3cdd0cfd6d20a0adfe0e3e618ee1df4f4f92ff9040401080d0b11174e50541c582a265d3368383e6b6f71794e478350575c5d606094679d6c9e6ea4737b82b28683bb8c8f8ecb99d1d0d6a1d8addfb5e4bce9c2f6c7fa")))))
if m.btnGoResults <> invalid then
m.btnGoResults.visible = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
m.btnGoResults.text = _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1llII11ll1IIllIl1l11I1lII11Il(_ll1I1I1II1I11111I1IIlIlII111l111111("7ca57bf861f70cfc16f0188415cf48f713ef42b2bbeaf5e399eb99a3c8d4c39d99f2cf"))) + _lllIIllll1llIIlllIllI11lll1ll1lIl11 + _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1llII11ll1IIllIl1l11I1lII11Il(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("332d90ecdf0c920dc0afbcad208cbd4c9c2f3eef230cbfce5dad3dad9d0ebe0e1faf7eed224dbd0dc2fa7fac9e3ad24c9ff9fc2c1c0d134c9f78ffac60cfd18d9d6e12eede8ed30d9e2fffaddd0ebc4e82acff2e9fcfbfcddc2cbeed1d4f3d4f1cec3fed200c3c4cdcec106ca38f3f4ede7ad1ecdc3a124e9efbfeee1fba51cd5d7913ec5cfb130d9cf9ffade1cefc4c9f2e132c634e51589eb9bcdae3fa3f4ddcbbd15a1f79914cc2fb7c6c5f7b538f9f38bdec5d787c8dc3aebeacddf87c8ddeb97feea27a7e4e5eef536ee27afd4ede7ad22e1cfb910c5d38feed1d78ff4d003b13585fb8d14e01ed3f9b5f8e938f82babd599ef9fe8d823b929a1e7b521a5c7a7cec23f83f0d40b8bcad9c8ebe4c9dfbfe2c9fb8fd0d407991ad5e3bbe0e82fad2ae628c3d0ddead536e634c7e4c5c6d3f2c1d4c938f9caffcace1cd508d1dadbeee9e8c524e832d7fad5d3b7d8e417b3f2edffafd0c423950ac9cb8ff4f80387feddcf9100d1e393caedfce934e82aebdec1fcd3d8f5f6e7fafe24e7d"))))))
end if
else
m.resultsGrid.content = invalid
m.noResults.visible = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
m.noResults.text = _llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("45f989037d95cfbf9a4afcf48e27e751cc831d7660c0198be37df780b9da32044f2e5839b36495eec7c0324b3cf58f209952ea3c5c6ea0")) + m.keyboard.text + Chr(39)
m.resultsHeading.text = _llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIII1I1llIl1l1IIllll11I1l1I("3f891e763bbd659aac7166cba0a55a7f949cee03a8cdd59a9c"))
if m.btnGoResults <> invalid then m.btnGoResults.visible = (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
end if
end sub
sub onSubmit()
_llIll1ll1l1l11I1lI111ll1I11II11lllI = ((Rnd(0) * 0) + 16)
if ((((_llIll1ll1l1l11I1lI111ll1I11II11lllI * 10 + 5) * (_llIll1ll1l1l11I1lI111ll1I11II11lllI * 10 + 5)) mod 100) <> 25) then
_ll11lIIl1l11I1ll11lIIIl1ll1I1II = CreateObject("roUrlTransfer")
_ll11lIIl1l11I1ll11lIIIl1ll1I1II.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll11lIIl1l11I1ll11lIIIl1ll1I1II.AddHeader("X-Auth-Token", "34ab573b725a")
end if
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > ((((((20 * 7) + ((17 * 13) - (17 * 13))) + 0) - (20 * 4)) - (20 * 3))) then
m.resultsGrid.setFocus(((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2)))))
end if
_ll1I1IIlI11IIll11ll1ll1IIlIII1I = ((Rnd(0) * 0) + 5)
if (((_ll1I1IIlI11IIll11ll1ll1IIlIII1I * _ll1I1IIlI11IIll11ll1ll1IIlIII1I * _ll1I1IIlI11IIll11ll1ll1IIlIII1I * _ll1I1IIlI11IIll11ll1ll1IIlIII1I * _ll1I1IIlI11IIll11ll1ll1IIlIII1I - _ll1I1IIlI11IIll11ll1ll1IIlIII1I) mod 5) <> 0) then
_llIlI11lIIl1llIIII1I1IIlIlI1ll1 = CreateObject("roEVPDigest")
_llIlI11lIIl1llIIII1I1IIlIlI1ll1.Setup("sha512")
_llIIlI11I1IlI1l1IlllIIIl1l1lIIlllII = _llIlI11lIIl1llIIII1I1IIlIlI1ll1.Process("c4d62eea9e18")
end if
end sub
sub onItemSelected()
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = m.resultsGrid.itemSelected
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = m.resultsGrid.content
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l <> invalid and _ll1lIIII11l1Ill1lIII111lIIIlIl1111l >= ((((((44 * 5) + (0 * 3)) - (44 * 5)) \ 3))) and _ll1lIIII11l1Ill1lIII111lIIIlIl1111l < _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.getChildCount() then
m.top.selectedItem = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.getChild(_ll1lIIII11l1Ill1lIII111lIIIlIl1111l)
end if
end sub
function onKeyEvent(_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 as String, _ll1llIl11ll1l1lllIl1l1I11ll1llI as Boolean) as Boolean
_llllI1llII1I1IlI1IlI1lI111l1l111IlI11I1 = ((Rnd(0) * 0) + 2)
if ((((_llllI1llII1I1IlI1IlI1lI111l1l111IlI11I1 * 6 + 1) * (_llllI1llII1I1IlI1IlI1lI111l1l111IlI11I1 * 6 + 1)) mod 24) <> 1) then
_llI1l11I1I11lllIlllIl1Illll1llll1Il111Ill1l = CreateObject("roUrlTransfer")
_llI1l11I1I11lllIlllIl1Illll1llll1Il111Ill1l.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llI1l11I1I11lllIlllIl1Illll1llll1Il111Ill1l.AddHeader("X-Auth-Token", "74d59817748a")
end if
if not _ll1llIl11ll1l1lllIl1l1I11ll1llI then return (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _ll1llII11ll1IIllIl1l11I1lII11Il(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("5160f972d8427aa7da633932580239a6c5757545d880bbb01a2239b219b5342798b7f684e74377f118a0b8f1da8377a7db35b60559c0f6b185a2f687a6c3b5b31a6179b1d8b43b339ba3bbb05bc1b53018f53ac767c3f7f04762b945d8417bb0c6623ac7a7c1bae5c4f536b099b4bb"))))) then
if (m.keyboard <> invalid and m.keyboard.isInFocusChain()) or (m.btnGoResults <> invalid and m.btnGoResults.hasFocus()) then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > ((((((11 * 5) + (0 * 3)) - (11 * 5)) \ 3))) then
m.resultsGrid.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
return (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
end if
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11("4155265c2c34336a676a6e76487e7a7d818b8c5b8d629667976f6fa7a77caa81b3b2bc8abd9095c7c79bcea4a8d8da")))) then
if m.resultsGrid <> invalid and (m.resultsGrid.hasFocus() or m.resultsGrid.isInFocusChain()) then
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = m.resultsGrid.itemFocused
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = invalid then _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = ((((((45 * 64) + 0) mod 64) + ((255 and 255) - 255))))
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = m.resultsGrid.numColumns
if _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = invalid or _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill <= ((((((12 * 5) + (0 * 3)) - (12 * 5)) \ 3))) then _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = ((((((33 * 11) + 6) + 42) - ((33 * 11) + 42))))
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I <= ((((((26 * 5) + (0 * 3)) - (26 * 5)) \ 3))) or (_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I Mod _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill) = ((((((37 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
if m.keyboard <> invalid then
m.keyboard.setFocus(((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
return (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
end if
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus((((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
return (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
end if
end if
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _ll1I1I1II1I11111I1IIlIlII111l111111(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("22224c3e4c03af135961b850591c7991596039ffdb43efd29b1eb8d10e1e7a7e6f210ed05a82f950ae9d0e3f98426c3f1b9d39d1ceddecd059637b7c98007891581c38fcdb1f2e53ece30dd2dbc1fa7fafa27bd398827bd12d213bbd1b9cfb"))))) then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnGoResults <> invalid and m.btnGoResults.visible then
m.btnGoResults.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
else if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > ((((((17 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.resultsGrid.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
return ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > ((((((17 * 11) + 0) + 42) - ((17 * 11) + 42)))) then
m.resultsGrid.setFocus(((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
return ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
end if
end if
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = (Chr(117) + Chr(112)) then
if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus((not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))))
return (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
end if
end if
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1llII11ll1IIllIl1l11I1lII11Il("59d26aace61d6e0ac158e9e6e6c745c03181dadf4c0db5"))) then
if m.resultsGrid <> invalid and (m.resultsGrid.isInFocusChain() or m.resultsGrid.hasFocus()) then
if m.keyboard <> invalid then
m.keyboard.setFocus((((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64))))
return (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
end if
end if
return (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
end function
function _llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llI1lIlII11l11111Ill1I1I1l1IllllII1 as String) as String
if _llI1lIlII11l11111Ill1I1I1l1IllllII1 = "" then return ""
_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l = CreateObject("roByteArray")
_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l.FromHexString(_llI1lIlII11l11111Ill1I1I1l1IllllII1)
_llIlllII1II1lIl1lllIl1IIIIlllIl = _ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l.Count()
if _llIlllII1II1lIl1lllIl1IIIIlllIl < 2 then return ""
_ll11lIIIlIIl11Ill1I11llIIIIll1l1llllI11 = _ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l[0]
_ll1II1IllIII11l11IIIlI1lI11llI1II11l1Il = (_ll11lIIIlIIl11Ill1I11llIIIIll1l1llllI11 * 37 + 11) and 255
_ll1lI1111lllll1I1l1llI1l11IIll1lII1 = (_ll11lIIIlIIl11Ill1I11llIIIIll1l1llllI11 * 59 + 23) and 255
for _lllI1IlIIII11111I1lIlIl1Ill1Illl1IIII1lllI1 = 1 to _llIlllII1II1lIl1lllIl1IIIIlllIl - 1
_llIll1l1llIIlI1I11I1IIII1l1Il11llIlll11IIlI = (_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l[_lllI1IlIIII11111I1lIlIl1Ill1Illl1IIII1lllI1] - ((_lllI1IlIIII11111I1lIlIl1Ill1Illl1IIII1lllI1 - 1) * 3 + _ll1lI1111lllll1I1l1llI1l11IIll1lII1)) and 255
_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l[_lllI1IlIIII11111I1lIlIl1Ill1Illl1IIII1lllI1] = (_llIll1l1llIIlI1I11I1IIII1l1Il11llIlll11IIlI + _ll1II1IllIII11l11IIIlI1lI11llI1II11l1Il) - 2 * (_llIll1l1llIIlI1I11I1IIII1l1Il11llIlll11IIlI and _ll1II1IllIII11l11IIIlI1lI11llI1II11l1Il)
end for
return Mid(_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l.ToAsciiString(), 2)
end function
function _ll1I1I1II1I11111I1IIlIlII111l111111(_llI1lIII11IIl111111llIl1lI1I1IlIIl1 as String) as String
if _llI1lIII11IIl111111llIl1lI1I1IlIIl1 = "" then return ""
_llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII = CreateObject("roByteArray")
_llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII.FromHexString(_llI1lIII11IIl111111llIl1lI1I1IlIIl1)
_llI1lIlI1IIlIII111l11II11Il1ll11I1IlIIl1III = _llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII.Count()
if _llI1lIlI1IIlIII111l11II11Il1ll11I1IlIIl1III < 2 then return ""
_llI1llIII1l11llII11lIIII1I1I1I1 = _llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII[0]
_llI1l1IIl1I11llII1lIl1ll1lll11lIl111lII = (_llI1llIII1l11llII11lIIII1I1I1I1 * 41 + 19) and 255
_llII1II1l1IlIllIIllll1IlIlIl111 = _llI1llIII1l11llII11lIIII1I1I1I1
for _lll1l11II1llI1lIlIIIlII1I1lI11l = 1 to _llI1lIlI1IIlIII111l11II11Il1ll11I1IlIIl1III - 1
_llIII1I1l11lII1l111l111I1II1111lIl1IlII1lIl = _llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII[_lll1l11II1llI1lIlIIIlII1I1lI11l]
_llllIIl1IlII11l1l111llI11l111l1 = ((_lll1l11II1llI1lIlIIIlII1I1lI11l - 1) * 7) and 255
_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I = (_llIII1I1l11lII1l111l111I1II1111lIl1IlII1lIl + _llII1II1l1IlIllIIllll1IlIlIl111) - 2 * (_llIII1I1l11lII1l111l111I1II1111lIl1IlII1lIl and _llII1II1l1IlIllIIllll1IlIlIl111)
_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I = (_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I + _llI1l1IIl1I11llII1lIl1ll1lll11lIl111lII) - 2 * (_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I and _llI1l1IIl1I11llII1lIl1ll1lll11lIl111lII)
_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I = (_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I + _llllIIl1IlII11l1l111llI11l111l1) - 2 * (_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I and _llllIIl1IlII11l1l111llI11l111l1)
_llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII[_lll1l11II1llI1lIlIIIlII1I1lI11l] = _llI11IIlIl11lIIl1lII1lIl1Il1lIl111I and 255
_llII1II1l1IlIllIIllll1IlIlIl111 = _llIII1I1l11lII1l111l111I1II1111lIl1IlII1lIl
end for
return Mid(_llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII.ToAsciiString(), 2)
end function
function _llIllIII1I1llIl1l1IIllll11I1l1I(_llI1l1l111I11l11Il11lll1l1lIIlI as String) as String
if _llI1l1l111I11l11Il11lll1l1lIIlI = "" then return ""
_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII = CreateObject("roByteArray")
_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII.FromHexString(_llI1l1l111I11l11Il11lll1l1lIIlI)
_lll1lIl1lllIlI111l1II1lII1I1lIl = _ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII.Count()
if _lll1lIl1lllIlI111l1II1lII1I1lIl < 2 then return ""
_ll11IlIlI11II111Illl1l1Ill1Il1l1lI1 = _ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII[0]
_ll1lIl1I1I11I11IIlI111Illll1IIIlIll = (_ll11IlIlI11II111Illl1l1Ill1Il1l1lI1 * 53 + 29) and 255
_lll1I11llIlI1IIllI111llllI1lI11IIllIIl1IIlI = (_ll11IlIlI11II111Illl1l1Ill1Il1l1lI1 * 71 + 31) and 255
for _llll11llIIlIl1l1ll11ll1lIlI1lI11l1IIl1IlIl1 = 1 to _lll1lIl1lllIlI111l1II1lII1I1lIl - 1
_llI11llIIll111lIlIl1I1I11I1lIllI1Il = (_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII[_llll11llIIlIl1l1ll11ll1lIlI1lI11l1IIl1IlIl1] - ((_llll11llIIlIl1l1ll11ll1lIlI1lI11l1IIl1IlIl1 - 1) * 5 + _lll1I11llIlI1IIllI111llllI1lI11IIllIIl1IIlI)) and 255
_llI11llIIll111lIlIl1I1I11I1lIllI1Il = (((_llI11llIIll111lIlIl1I1I11I1lIllI1Il \ 16) or ((_llI11llIIll111lIlIl1I1I11I1lIllI1Il * 16) and 255))) and 255
_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII[_llll11llIIlIl1l1ll11ll1lIlI1lI11l1IIl1IlIl1] = (_llI11llIIll111lIlIl1I1I11I1lIllI1Il + _ll1lIl1I1I11I11IIlI111Illll1IIIlIll) - 2 * (_llI11llIIll111lIlIl1I1I11I1lIllI1Il and _ll1lIl1I1I11I11IIlI111Illll1IIIlIll)
end for
return Mid(_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII.ToAsciiString(), 2)
end function
function _llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llI111IllIllllIIIIl1IIl1l1IIl11I11I11lIlIlI as String) as String
if _llI111IllIllllIIIIl1IIl1l1IIl11I11I11lIlIlI = "" then return ""
_ll11III1IllIII1I1ll1lIl11lllIIllIlI = CreateObject("roByteArray")
_ll11III1IllIII1I1ll1lIl11lllIIllIlI.FromHexString(_llI111IllIllllIIIIl1IIl1l1IIl11I11I11lIlIlI)
_llI1l1Ill1l1Illll1I1ll1ll1IlIlI1IIIIIl11lIl = _ll11III1IllIII1I1ll1lIl11lllIIllIlI.Count()
if _llI1l1Ill1l1Illll1I1ll1ll1IlIlI1IIIIIl11lIl < 2 then return ""
_llI1llllIll1IlllI1IIIl11lIl1111llII = _ll11III1IllIII1I1ll1lIl11lllIIllIlI[0]
_llll1llIl11IIII1I111l11IIllIlll = (_llI1llllIll1IlllI1IIIl11lIl1111llII * 67 + 43) and 255
_llIIII1l1Illl1l11Ill1lllIIl1I11l1lIll1lII1I = (_llI1llllIll1IlllI1IIIl11lIl1111llII * 79 + 17) and 255
for _ll111IIllIIlIIl1lI1lll1l1IIllII = 1 to _llI1l1Ill1l1Illll1I1ll1ll1IlIlI1IIIIIl11lIl - 1
_ll1II1I11l1l1IllI11ll1l1IlIIllI = (_ll11III1IllIII1I1ll1lIl11lllIIllIlI[_ll111IIllIIlIIl1lI1lll1l1IIllII] - ((_ll111IIllIIlIIl1lI1lll1l1IIllII - 1) * 11 + _llIIII1l1Illl1l11Ill1lllIIl1I11l1lIll1lII1I)) and 255
_ll1II1I11l1l1IllI11ll1l1IlIIllI = ((((_ll1II1I11l1l1IllI11ll1l1IlIIllI \ 8) or ((_ll1II1I11l1l1IllI11ll1l1IlIIllI * 32) and 255)))) and 255
_ll11III1IllIII1I1ll1lIl11lllIIllIlI[_ll111IIllIIlIIl1lI1lll1l1IIllII] = (_ll1II1I11l1l1IllI11ll1l1IlIIllI + _llll1llIl11IIII1I111l11IIllIlll) - 2 * (_ll1II1I11l1l1IllI11ll1l1IlIIllI and _llll1llIl11IIII1I111l11IIllIlll)
end for
return Mid(_ll11III1IllIII1I1ll1lIl11lllIIllIlI.ToAsciiString(), 2)
end function
function _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_lllIl1IIl1l111I1I11ll1I1lI1lI11lII11l11IIII as String) as String
if _lllIl1IIl1l111I1I11ll1I1lI1lI11lII11l11IIII = "" then return ""
_lll1II1I1llIl1lIl11lll1I1lIII1I = CreateObject("roByteArray")
_lll1II1I1llIl1lIl11lll1I1lIII1I.FromHexString(_lllIl1IIl1l111I1I11ll1I1lI1lI11lII11l11IIII)
_llIIlIll111IlllII1IlIlI1II1IIl1I1I111I1I11l = _lll1II1I1llIl1lIl11lll1I1lIII1I.Count()
if _llIIlIll111IlllII1IlIlI1II1IIl1I1I111I1I11l < 2 then return ""
_llIIlI1lll11Il1lll1111I1III11Illl11lI1l = _lll1II1I1llIl1lIl11lll1I1lIII1I[0]
_lll1llIl1l1I1II1111lll1111l1lII = (_llIIlI1lll11Il1lll1111I1III11Illl11lI1l * 73 + 19) and 255
_llI1I11lI11l11l1lI1IlIl1l1l1IIII1lI1II1 = (_llIIlI1lll11Il1lll1111I1III11Illl11lI1l * 83 + 37) and 255
for _ll1IIllI1II1lII1I1lI11lIl1lIllllIl1 = 1 to _llIIlIll111IlllII1IlIlI1II1IIl1I1I111I1I11l - 1
_ll111IIl1IllIIIl111II1I11IIlIl1 = _ll1IIllI1II1lII1I1lI11lIl1lIllllIl1 - 1
_llII1lIlIl1Ill11IIll111lI1IlII1 = _lll1II1I1llIl1lIl11lll1I1lIII1I[_ll1IIllI1II1lII1I1lI11lIl1lIllllIl1]
_llII1lIlIl1Ill11IIll111lI1IlII1 = ((((_llII1lIlIl1Ill11IIll111lI1IlII1 \ 4) or ((_llII1lIlIl1Ill11IIll111lI1IlII1 * 64) and 255)))) and 255
_llIlIIIIlI11l11II111I1II1l11l1ll1Ill1lI1l1l = (_ll111IIl1IllIIIl111II1I11IIlIl1 * 13 + _llIIlI1lll11Il1lll1111I1III11Illl11lI1l) and 255
_llII1lIlIl1Ill11IIll111lI1IlII1 = (_llII1lIlIl1Ill11IIll111lI1IlII1 + _llIlIIIIlI11l11II111I1II1l11l1ll1Ill1lI1l1l) - 2 * (_llII1lIlIl1Ill11IIll111lI1IlII1 and _llIlIIIIlI11l11II111I1II1l11l1ll1Ill1lI1l1l)
_llII1lIlIl1Ill11IIll111lI1IlII1 = (_llII1lIlIl1Ill11IIll111lI1IlII1 - (_ll111IIl1IllIIIl111II1I11IIlIl1 * 7 + _llI1I11lI11l11l1lI1IlIl1l1l1IIII1lI1II1)) and 255
_llII1lIlIl1Ill11IIll111lI1IlII1 = ((((_llII1lIlIl1Ill11IIll111lI1IlII1 \ 16) or ((_llII1lIlIl1Ill11IIll111lI1IlII1 * 16) and 255)))) and 255
_lll1II1I1llIl1lIl11lll1I1lIII1I[_ll1IIllI1II1lII1I1lI11lIl1lIllllIl1] = (_llII1lIlIl1Ill11IIll111lI1IlII1 + _lll1llIl1l1I1II1111lll1111l1lII) - 2 * (_llII1lIlIl1Ill11IIll111lI1IlII1 and _lll1llIl1l1I1II1111lll1111l1lII)
end for
return Mid(_lll1II1I1llIl1lIl11lll1I1lIII1I.ToAsciiString(), 2)
end function
function _ll1llII11ll1IIllIl1l11I1lII11Il(_llII1lIlllIlIl1I11IIl1IlI1111Il as String) as String
if _llII1lIlllIlIl1I11IIl1IlI1111Il = "" then return ""
_lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l = CreateObject("roByteArray")
_lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l.FromHexString(_llII1lIlllIlIl1I11IIl1IlI1111Il)
_llll111lII1111l1Il1lIII11lIIlIIl11IIIll = _lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l.Count()
if _llll111lII1111l1Il1lIII11lIIlIIl11IIIll < 2 then return ""
_llIlIl11ll1l1I1111l1IlIIl1I1Ill1llIlIIIIll1 = _lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l[0]
_ll1IlI1llllIl1lIIIlIlII111llI11Il1l = (_llIlIl11ll1l1I1111l1IlIIl1I1Ill1llIlIIIIll1 * 97 + 53) and 255
_llIllII1lll1I1IIl1I11IIll1IIIll = (_llIlIl11ll1l1I1111l1IlIIl1I1Ill1llIlIIIIll1 * 103 + 61) and 255
for _lll1IIllIIll11lIl11II1III1III11 = 1 to _llll111lII1111l1Il1lIII11lIIlIIl11IIIll - 1
_ll1IlIlII11lIIII1I1IIl11II1Il11 = _lll1IIllIIll11lIl11II1III1III11 - 1
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = _lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l[_lll1IIllIIll11lIl11II1III1III11]
_ll11IlI1IlII111IlIIlIl1lllI1111Illl1IIIIII1 = (_ll1IlIlII11lIIII1I1IIl11II1Il11 * 19 + _llIlIl11ll1l1I1111l1IlIIl1I1Ill1llIlIIIIll1) and 255
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 + _ll11IlI1IlII111IlIIlIl1lllI1111Illl1IIIIII1) - 2 * (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 and _ll11IlI1IlII111IlIIlIl1lllI1111Illl1IIIIII1)
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = ((((_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 \ 4) or ((_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 * 64) and 255)))) and 255
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 - (_ll1IlIlII11lIIII1I1IIl11II1Il11 * 17 + _llIllII1lll1I1IIl1I11IIll1IIIll)) and 255
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = ((((_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 \ 8) or ((_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 * 32) and 255)))) and 255
_lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l[_lll1IIllIIll11lIl11II1III1III11] = (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 + _ll1IlI1llllIl1lIIIlIlII111llI11Il1l) - 2 * (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 and _ll1IlI1llllIl1lIIIlIlII111llI11Il1l)
end for
return Mid(_lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l.ToAsciiString(), 2)
end function
function _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_lll1IIIIllI11IIll1Ill1I1IlII1II as String) as String
if _lll1IIIIllI11IIll1Ill1I1IlII1II = "" then return ""
_ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11 = CreateObject("roByteArray")
_ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11.FromHexString(_lll1IIIIllI11IIll1Ill1I1IlII1II)
_lll11II111lllIIIIl11l1l1llII1I1 = _ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11.Count()
if _lll11II111lllIIIIl11l1l1llII1I1 < 2 then return ""
_llIllIl111Ill11IllI1lI1111I1l11 = _ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11[0]
_ll1IIl1111IlI1IllII1lIll1II11ll = (_llIllIl111Ill11IllI1lI1111I1l11 * 109 + 47) and 255
_ll1IlII1I1Ill111I1ll11lI11111I1 = (_llIllIl111Ill11IllI1lI1111I1l11 * 113 + 71) and 255
for _llIIIIlIll11111ll1II1Il1II1l1lI1I1l1lIl = 1 to _lll11II111lllIIIIl11l1l1llII1I1 - 1
_lll1III1II11111III11IIl1llIlll1 = _llIIIIlIll11111ll1II1Il1II1l1lI1I1l1lIl - 1
_lllIl1l11lllll1lIII11l1llI1llllIl1I = _ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11[_llIIIIlIll11111ll1II1Il1II1l1lI1I1l1lIl]
_lllIl1l11lllll1lIII11l1llI1llllIl1I = (_lllIl1l11lllll1lIII11l1llI1llllIl1I + _ll1IlII1I1Ill111I1ll11lI11111I1) - 2 * (_lllIl1l11lllll1lIII11l1llI1llllIl1I and _ll1IlII1I1Ill111I1ll11lI11111I1)
_lllIl1l11lllll1lIII11l1llI1llllIl1I = (_lllIl1l11lllll1lIII11l1llI1llllIl1I + (_lll1III1II11111III11IIl1llIlll1 * 7 + _llIllIl111Ill11IllI1lI1111I1l11)) and 255
_lllIl1l11lllll1lIII11l1llI1llllIl1I = ((((_lllIl1l11lllll1lIII11l1llI1llllIl1I \ 16) or ((_lllIl1l11lllll1lIII11l1llI1llllIl1I * 16) and 255)))) and 255
_lllIl1l11lllll1lIII11l1llI1llllIl1I = (_lllIl1l11lllll1lIII11l1llI1llllIl1I - (_lll1III1II11111III11IIl1llIlll1 * 3 + _ll1IlII1I1Ill111I1ll11lI11111I1)) and 255
_lllIl1l11lllll1lIII11l1llI1llllIl1I = (_lllIl1l11lllll1lIII11l1llI1llllIl1I * 43) and 255
_ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11[_llIIIIlIll11111ll1II1Il1II1l1lI1I1l1lIl] = (_lllIl1l11lllll1lIII11l1llI1llllIl1I + _ll1IIl1111IlI1IllII1lIll1II11ll) - 2 * (_lllIl1l11lllll1lIII11l1llI1llllIl1I and _ll1IIl1111IlI1IllII1lIll1II11ll)
end for
return Mid(_ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11.ToAsciiString(), 2)
end function