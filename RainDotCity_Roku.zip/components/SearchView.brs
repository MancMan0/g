sub init()
m.keyboard = m.top.findNode(_l1d_9f71f3("79768d79897e9287", 160, 174))
m.btnGoResults = m.top.findNode(_l1d_9f71f3("3e4b38623d7d49625f4b666e", 109, 47))
m.resultsGrid = m.top.findNode(_l1d_9f71f3("152d1a233f2a261d2d4949", 211, 116))
m.resultsHeading = m.top.findNode(_l1d_9f71f3("3b55424b55504e3a6a696f676b77", 26, 211))
m.noResults = m.top.findNode(_l1d_9f71f3("0e12200e07041e0913", 52, 180))
m.keyboard.observeField(_l1d_9f71f3("4f436158", 132, 95), _l1d_9f71f3("2123392033231d5a323e3e4a4b", 56, 202))
m.keyboard.observeField(_l1d_9f71f3("626379717870", 223, 182), _l1d_9f71f3("a5a96f98a6b6b5a5", 147, 169))
if m.btnGoResults <> invalid then m.btnGoResults.observeField(_l1d_9f71f3("4963656852544c655f6b68807476", 138, 97), _l1d_9f71f3("6b6f456e7c7c7b7b", 155, 119))
m.resultsGrid.observeField(_l1d_9f71f3("fc140601fe0f0b151a2c1e22", 207, 86), _l1d_9f71f3("6d719161737e837c88827f798b8f", 51, 17))
if m.keyboard <> invalid then m.keyboard.setFocus(true)
end sub
sub onQueryChange()
if ((9320 - 2330 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_llIll1l = m.keyboard.text
if _llIll1l = invalid then _llIll1l = ""
_lIIll1l = ""
_l1Ill1l = CreateObject(_l1d_9f71f3("7c6ca27c7d8288", 234, 228), _l1d_9f71f3("8788703b71947c4755", 185, 160), _l1d_9f71f3("4d", 24, 206))
if _l1Ill1l <> invalid then _lIIll1l = _l1Ill1l.replaceAll(_llIll1l, "") else _lIIll1l = _llIll1l
if _lIIll1l = "" then
m.resultsGrid.content = invalid
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("7f576179b77577c0777e8ecc86977e96969f8fa8e79ea8f0a2bbbaaabeba05bcc4c2cdd9c614171a", 122, 81)
m.resultsHeading.text = _l1d_9f71f3("23394a4f395456", 8, 201)
if m.btnGoResults <> invalid then m.btnGoResults.visible = false
return
end if
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("57282f41333133313b05764a45437048667a576f6d1b1e21", 175, 91)
if m.searchTask <> invalid then m.searchTask.control = _l1d_9f71f3("83858d8f", 127, 87)
m.searchTask = CreateObject(_l1d_9f71f3("a69e8d7c86aaa2a6", 4, 48), _l1d_9f71f3("4378776b7f7756867b86", 152, 120))
m.searchTask.query = _llIll1l
m.searchTask.observeField(_l1d_9f71f3("47594e4f6954", 182, 131), _l1d_9f71f3("f4f62e0706160a063f19262f193432", 42, 175))
m.searchTask.control = _l1d_9f71f3("f7ffe9", 75, 222)
end sub
sub onSearchResults()
_lI1I11l = m.searchTask.result
if _lI1I11l <> invalid and _lI1I11l.getChildCount() > 0 then
m.resultsGrid.content = _lI1I11l
m.noResults.visible = false
_l11I11l = _lI1I11l.getChildCount().ToStr()
m.resultsHeading.text = _l1d_9f71f3("8298a9ae98b3b56560", 8, 40) + _l11I11l + _l1d_9f71f3("b1bdbbc359768fcf8098939492a4e49ba3edaea1afaaa9c2", 219, 191)
if m.btnGoResults <> invalid then
m.btnGoResults.visible = true
m.btnGoResults.text = _l1d_9f71f3("f90c240f162369", 212, 99) + _l11I11l + _l1d_9f71f3("b78c7a73707a757fcfb8", 124, 91)
end if
else
m.resultsGrid.content = invalid
m.noResults.visible = true
m.noResults.text = _l1d_9f71f3("eace12c9d1cfdae6d727f0ece5f1fa39f900f60800040c18545e", 120, 180) + m.keyboard.text + _l1d_9f71f3("ca", 19, 150)
m.resultsHeading.text = _l1d_9f71f3("4119262f1b363268637e68", 235, 136)
if m.btnGoResults <> invalid then m.btnGoResults.visible = false
end if
end sub
sub onSubmit()
if ((7588 - 1084 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
end if
end sub
sub onItemSelected()
_l1llIIl = m.resultsGrid.itemSelected
_llllIIl = m.resultsGrid.content
if _llllIIl <> invalid and _l1llIIl >= 0 and _l1llIIl < _llllIIl.getChildCount() then
m.top.selectedItem = _llllIIl.getChild(_l1llIIl)
end if
end sub
function onKeyEvent(_lllIll1 as String, _l1lIll1 as Boolean) as Boolean
if not _l1lIll1 then return false
if _lllIll1 = _l1d_9f71f3("0bf9fefe15", 110, 239) then
if (m.keyboard <> invalid and m.keyboard.isInFocusChain()) or (m.btnGoResults <> invalid and m.btnGoResults.hasFocus()) then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("b9b3b5ca", 167, 238) then
if m.resultsGrid <> invalid and (m.resultsGrid.hasFocus() or m.resultsGrid.isInFocusChain()) then
_lII1ll1 = m.resultsGrid.itemFocused
if _lII1ll1 = invalid then _lII1ll1 = 0
_l1I1ll1 = m.resultsGrid.numColumns
if _l1I1ll1 = invalid or _l1I1ll1 <= 0 then _l1I1ll1 = 6
if _lII1ll1 <= 0 or (_lII1ll1 Mod _l1I1ll1) = 0 then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("0c041f0b", 43, 189) then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnGoResults <> invalid and m.btnGoResults.visible then
m.btnGoResults.setFocus(true)
return true
else if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > 0 then
m.resultsGrid.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("ebe9", 74, 172) then
if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
else if _lllIll1 = _l1d_9f71f3("f7fdfe09", 210, 71) then
if m.resultsGrid <> invalid and (m.resultsGrid.isInFocusChain() or m.resultsGrid.hasFocus()) then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
end if
return false
end function
function _l1d_9f71f3(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function