sub init()
_ll111ll11I1lll1l11Il1ll1II1I11I11l1 = ((Rnd(0) * 0) + 8)
if (((_ll111ll11I1lll1l11Il1ll1II1I11I11l1 * _ll111ll11I1lll1l11Il1ll1II1I11I11l1 * _ll111ll11I1lll1l11Il1ll1II1I11I11l1 * _ll111ll11I1lll1l11Il1ll1II1I11I11l1) mod 5) = 3) then
_llIlllI1lIII111llIll1I1IlIllIlIlI1I = CreateObject("roByteArray")
_llIlllI1lIII111llIll1I1IlIllIlIlI1I.SetResize(64, false)
_ll1l111ll1llIIIlllI11l1lIlIlI11l1lIll11lllI = _llIlllI1lIII111llIll1I1IlIllIlIlI1I.ToHexString()
end if
m.keyboard = m.top.findNode(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("48fadd9aebb083c6677a5590c5006116f9cab5421df60166d722877a2ba8932c1fbcbfeafde079f6970c4722f3383bd407ea97007d16c3243fec6d505b18a12ed73cada03db6e17ed71aedaa85463124d9e44588dd102326393c4fd8d3ee19ecfffa05100b26213c57624d787b76818ca7a2fdb80bce2934f7faaf601376bb34c99a7d986bae99dcc7dacdf04560e934992a05a2735689c6577a95f29ba6a9"))))))
m.btnGoResults = m.top.findNode(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_ll1llII11ll1IIllIl1l11I1lII11Il(_ll1I1I1II1I11111I1IIlIlII111l111111("69bb6eb725e918b252b95acb51d50bef50a701aba9f5b4f9daa0d3b58d9e88898ceed8e694b93ab023eb29db2bce22b42ba97ca017fb0fa5a6aff6e0a0d2ae9cf3b3f6efbdb1d5bd9eb59612c200c634c120962dba77a378c8269c3ec6c09c8cc8bdcbb183e8f9eebde5ecdab291bd")))))
m.resultsGrid = m.top.findNode(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1I1I1II1I11111I1IIlIlII111l111111("7e087a0d3a03505e18544f2d1166445f1645411fec18f34bce439e08cc7997369c5ecf04d65b2802645965643b7e3c5c3547374d5d151e10b548b506e232bc7fb256b10dfa52c15cda518dfd81e183d6df9787c0f0c9b894859a82808479d73dd7038458ca55e3")))))
m.resultsHeading = m.top.findNode(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("5ea243b059d667f47d0a0568732ea73ca7b2bdfea3d691f4a758cd18db7c8f9a1780058eb986cf9c4f086506f11cb912cf483b5e5154f18207a02d96435651da05926598191c27bc3ddac57e515c671467427d50636651e205f88df69ba6b10cd7d2c5e079168f640f1a2528b16ec7548f72fb98c3c6b16265607be0fb8c11")))))
m.noResults = m.top.findNode(_ll1llII11ll1IIllIl1l11I1lII11Il(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIllIII1I1llIl1l1IIllll11I1l1I("491e185d3237f741361b40255a3a3f449993439d5262bc7c71769090c59a74e9aec3a3889d92e7e1f1a6bbf5facadfd409ce48f84d0297fc06063060656aaf74791e53288da287ac76b65bc0ca9a6fa4a97eb3b882c2cccca6d6a00015fae4041e1e2838dd42174c3186fb9035aa0f44494e2358bdd28c6151e67075a57fef8909ae689de212871cd126c095caafaf44eeb328cd5d72cce1e60bdb45454ff4595e33086d52878781662b7ba5aa7f3f"))))))
m.keyboard.observeField(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIII1I1llIl1l1IIllll11I1l1I("73c196a6d0d5cababf298e1ee80d1232e7e1f14650f515"))), _llIllIII1I1llIl1l1IIllll11I1l1I(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_ll1llII11ll1IIllIl1l11I1lII11Il("473b7a89e9fefec575a15002691dae4526cb01d8bab7a41506f1abb27acd5415f7619b8209be97cc17db7b62309d6e2fddf0a152a077257f26aae1db596d74be0ce01b6bc99d942e8ed99241d1bc2ecebd2981b15bcc05b42793e2fa9aadbe7ef780d8e18a477fa44d20d28b71a7cfcebdb3223b20b68fbe64b3e270db369674f419588aeb9c354df4423320d185ac87bee8037aa10f8ffe24f2a3b398f61516b499790a8bbc7c6e0e387380119f0da75f4840baf8ef661dc5b2c3f098cf1776efa139034b7fbd46efa29920921fede74532035af92f679d6572e3d038d51d174fb8b083884477a6555bfa8893a48d"))))))
m.keyboard.observeField(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("47924b485e8c449d3ab3097977865adc31289e97e2c5f3a9fe402ffaf26b807697a4ba339140b76f2425334b61fe74c6fd5bd080f4f46d4418d0a1170c6cda9311a0d40e62a2d1417ef72e233308cb39176cfaf8117f97d787a5fb0b897ef42582f0ee07d5eaebc55351489ed562bb4686de148540306988898d2d9af829be"))))), _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIII1I1llIl1l1IIllll11I1l1I(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11("3674797e7f7678537f8b5c9492979f6f70a3aa7baf7d8083b8b98f91c2ca9fa0a5d1dad0aee3d9b8deeaedc3c5c9fcce0504d90d0fe0090b181aeff6222c2c240032090e0e1243483e4d1c1f552a5c5465616b6a6e6f737a6e7b4c8285555f6295979a6c9e71a3a59e7dae86b3b58f8e90c696cca1d3c9cbd8dcafe6b5e6ecbfc3f4c9f0fef50206070f04df151cec22f3f82b29012d33342e3d0c433b3e1c"))))))
if m.btnGoResults <> invalid then m.btnGoResults.observeField(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("5c32383f4db0cc40da30ec635bb378bcdbb1b92199b0f901dbdfbbe35ab20d")), _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIllIII1I1llIl1l1IIllll11I1l1I("6d030bf002f7dc71361b43855d7f57791e86785d52678c5499bb6045addf94e981c6a8d0a2b77c"))))
m.resultsGrid.observeField(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("7a7a378f1621abca9a847699d0c865f5e4af3980da126f5fee417b9a721cce46a89b53847c3ec930c0ad129736894b9aca6c574130002b9d7ce4a140f3ba9aa5be49b9e3524c2f1641a88245d49f0731200bbda7cf66abb8a224871fd9790aeae4dc39d8b843cd5d57874e3b728d87e7ae30934a250c67c6b803a5542fe626b082edf5d706686bbabd44fe96104b43c494e6b1ab0b72e7ae9e50c36b156f5659e89b75d56c5751a3e36d8a2c7638c358faed97517148b33d4cf7d9b16b9b62b4fea63122da45a75f5e293a0294efbfbea8d3fd24473e332bdaba3f57368092"))))), _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_ll1I1I1II1I11111I1IIlIlII111l111111("5f215a2b422c712933796f5a6f486e706a696c61cc6b8332ef3aec27e55cbc45b321b97ff17f00781a70431715084e7f443d163b71363f6b9432c57896199903c22d9273d427b97bf726a28dfec3a4aaa8b1aebcd0b29beda0e6f0fcfc56f64aaa71ae2fe87bc4218377d3198d56dff1d3efd0b6bdeba2b487b681ad8c92d2")))))
if m.keyboard <> invalid then m.keyboard.setFocus((not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))))
end sub
sub onQueryChange()
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m.keyboard.text
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = invalid then _lllIIlIlII1ll111l1Il11Illlll11l11I1 = ""
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = ""
_llll1I11llIlll11lII11l11111IIIl = CreateObject(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11("235753aa5f61b663bc6a66706cc877cbd386d78adae092e3979a9bf4f79ef8aab2b704bb0dc2c0c518cd1ed024d6dc30d830e537eaede94845fd000407580a0b64611617696c25")))), _llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIllIII1I1llIl1l1IIllll11I1l1I("7d967850a54a6fc1d9be6378ddb2779cf1061820f527afa439def3f54d22072c5143382d254a4c74891b43"))), Chr(103))
if _llll1I11llIlll11lII11l11111IIIl <> invalid then _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = _llll1I11llIlll11lII11l11111IIIl.replaceAll(_lllIIlIlII1ll111l1Il11Illlll11l11I1, "") else _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = _lllIIlIlII1ll111l1Il11Illlll11l11I1
if _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = "" then
m.resultsGrid.content = invalid
m.noResults.visible = ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
m.noResults.text = _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("38a00b719d816872cb22bc72eacfbdb249eecbf1ddcf3f6e0a208b30ea4dbcb2486fc8736b4c6a2cdc607c302901eaf349e33e72a801feb1c9a18ab269c32b321ea248f02901e9f01fa34af128c3e93288e3c873e8c23c31dca1c8f19e8069ed89e3ffb36a8f696f4a2d7d72e98d28ac086c4bf06a8f68ecc92d480deaceabac48affdce9dcc7c6f8a6fbcf1df007eedcaa3cb4e1d0efcaf0bee084d9c4c7c2d0ae08b7068c32b")))
m.resultsHeading.text = _llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIII1I1llIl1l1IIllll11I1l1I("38df192e1e382d1d92e70c2616bbf05a0fcf74397ee3e88d52f72c519b5ba065baafc9")))
if m.btnGoResults <> invalid then m.btnGoResults.visible = (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
return
end if
m.noResults.visible = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
m.noResults.text = _llIllIII1I1llIl1l1IIllll11I1l1I(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1I1I1II1I11111I1IIlIlII111l111111("56ba52bc47b57db935ed3bc562dc6eb130fb61a59fab80a0bcf8efb6b69aed87e5b9e4e0aaee00b719ee10da1dc713bb12a845f52fa33bfec0f096e097df95c89bb199ec86e0bbb0afedfb47f104f63ff62ef472df7a9127aa78fc66f1c9a3dcade2ffbde6b6cd")))
if m.searchTask <> invalid then m.searchTask.control = _ll1I1I1II1I11111I1IIlIlII111l111111(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("25a1d585a494da10c7a11992388094a5bb63d8507b949b257ad69806e6569a12c7611b46a6d65565b922d607a7961b"))))
m.searchTask = CreateObject(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1llII11ll1IIllIl1l11I1lII11Il(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("67a75bf476c418b53427987436046434f9a5c4f5f584a4b6382404b77a4599f4b5669af7744767b6f7f19976b97126f6f7f01bb7fb86d975757007f574312777b8f3d834f607987474b3867677879b36392606b677c61ab777a758b6750564b5f6a4d8f734c7d87475a444b5750427f4ba7084f477b1e67539f099f6f6b3a6373bb3053676f0e7b57bf0c7b6bb466534b5b118b47870e683f7250420b9f16641b43399343673dac3faf24721f6321981fbb387b5b6716536b53144f5f686987737254434787066b5f6e45ab4fb736636b67287b6f6f2a7f43bf305b674b065b7b77058a074f35bc3b9730721750799817a7346b577f22634faf1c7e135729a8377b286f43af1e576f5f318b6f506a734f4f087b47631e6b677e587f4fa4725f47a64db367704e5b6b426c576b9c6e6f67767dab7b584a63474e585b43844a5")))))), _ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("599a231edb4c574a47028318a92eaf542f6a5d78638eefb4b7cac5e0b3f6c90c85022510892e914c4f62f378f98ef7acaf9ab5d8bbee5f0465022d182326df44f5628d78a38e91a40f1243b8fbcef9e417fa1d10a99eaf446fcadb70eb86279cb7b24b30fb74098a0f721588239eefbc8700dd16093cc114352a5b56db6c01aa0fa84db643d451ea57f8031eb334b922af60dd7679646f7aad909b58a3cce784f5a2a50e41ce1142ef58d51061847724273a9d50e1c4df849fa2adb893c65fe465f26318fb2e39448f5a3d48f96e797c779a9db013be2fdc37fa05e80326093cad52cb40e15ed1748f9233b0d3be6fd45d4af50889064134cd4adb4873d68174350223a041bef9d4dfeafd00817e392cd5aa5deee904efecf7301b20d336c94c95628bb61ba449baaff8550ef124f722b7301d4ec3645f5a07982d861b9cdfdab7d88d060904b91acf30bd465964f91cf790bba6b95eaf74ed8adbfef1fc89b417284bf0f3fe0914f732b340c95eef7c4f6a758083a6c1bccfea5be0e3f69f")))))))
m.searchTask.query = _lllIIlIlII1ll111l1Il11Illlll11l11I1
m.searchTask.observeField(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1I1I1II1I11111I1IIlIlII111l111111("30c539c32d93469700cf05b60baf569103d556defb8de8d285d6dbcc8bb889"))), _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("6ff4551b2a1bc144345a2d294029e71cccea33b8b91eed5243b0b8aedf2de4bb49994e35f2b24bd881ecf4ba6afb1136074c9b40f377d6776db5737bf9c90c4573cb5801fee4b23bab91e1a5926d18e0fe19c46a3d23a13e848c2dc221e1b727acea022bb8540f3f137359a9bc07371d98484e77c5654b9b2157c7cacb1bc0c139dc1cb5b20b76de3da2a56b660fdc3c542af801c17f856dfac3e171d4645c02d1d0c6ef5cbdc308d7971d8c7019eb2e5c1c02d36bae5e1762fafb58014f94b4eb02e046861c3a7a70c8691e7db59010064fbcad1590b9d98fd7a580a90610f79525faa810eeb447cd7bd126b6145ded323ec6a93f6dc33b268fbf1cc53248b94117a49a2ad05ea7e7dd2dcb4099e7"))))))
m.searchTask.control = _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11("47eca2a5f9adfffd05"))
end sub
sub onSearchResults()
_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = m.searchTask.result
if _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 <> invalid and _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1.getChildCount() > ((((((30 * 5) + (0 * 3)) - (30 * 5)) \ 3))) then
m.resultsGrid.content = _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1
m.noResults.visible = (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = _llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1.getChildCount().ToStr()
m.resultsHeading.text = _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_ll1I1I1II1I11111I1IIlIlII111l111111("51690165486d71616b6e691b620c6f396b226c29942d8222ba7aed31b746b25aed35ed3cf1625a6a4163410d1917156d11751e2a752d6774cf79c96b9802901894699430dc39e432ae3ef8c5f2dcfee4f4fdf0a4daa2cbaff6abfeb0f811a30dad34ab6fe06892668c61860edb15d6bb89a48babe0f0fbaedaacdfb6d288dbc488358b6fc363fa39b336b31bec02e33ded24ea2b17745d2e362b3e3334186c0a693d65612c69d565ce6cce079f1193"))))) + _lllIIllll1llIIlllIllI11lll1ll1lIl11 + _llIllIII1I1llIl1l1IIllll11I1l1I(_ll1I1I1II1I11111I1IIlIlII111l111111(_ll1llII11ll1IIllIl1l11I1lII11Il("422d645ca2f2a0f1b4d4be566978ba2b0efdd58c4922f08184042fc6f949c93b3e6d2ffc79326a51eeb51f96b3c3d0a8f744758c08b990423d3ee5c7e2d3893ba774cf1db8a94932adee1f3652da9808d71f744d6b4012e27d242527a2e94978066fce5dc0b0e9")))
if m.btnGoResults <> invalid then
m.btnGoResults.visible = ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
m.btnGoResults.text = _llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("418d41eefd989e8d7e4c036cff6e634fbf4d02ee52ac20ccbeda5cacbd2d9f8dbccf40f8d26c5f7bd14f5dedbceea37a538e8279116f5eb9bddadcfbbcad9c3ad3ccdcad7c6cdccc7f9b5f2c13ecdf8d510d5c6cbc6d1fbabc1b812d51ad9d0e919b5eef52ad1e0f7f9902bad1ee60f8bf4fde6c902f2379fd0d01fbbd6cdf8c501a81f990af63cd3e4ddd6f926d62b9fc989cb97dafdd4efe8f5dbb902d1ccd50989caf3c5b5c4f3c4f9ef850ed9e7afd8f5dee3d6e5dcf119a1d6efc985fcefc985dedd0191f0fd3cc80ef7e2fa14c5019406c1018a20f52cfdcafbfaf21b93dce01fa926fe30fbe99426ffe6d203b500f00bb932cdf0f500c002dbe58e07a7f1a5f2fffec5f7bd34ede7b93ee1eb9bd8f9dec3eec9fcc934f00ae10d99d")))))) + _lllIIllll1llIIlllIllI11lll1ll1lIl11 + _llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_ll1I1I1II1I11111I1IIlIlII111l111111("5ca75cac42a77da96eab6bd4309c3ba43ab737b1c3b788e5bfebbdf7b182e7c2b1aab6aea3a30bfa45ab1d95448b46")))
end if
else
m.resultsGrid.content = invalid
m.noResults.visible = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
m.noResults.text = _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIII1I1llIl1l1IIllll11I1l1I("3ba2f7e96106abadc50aacc1d9be93d52a1244e9ee260b5d523afc01194e33758d6247499e768b8db5679ca1a6bbd3857d32c4c99e83a89d95979f74166ec0b50d82f7293e963b3d35ba4f01191ed3657a72372971867b2d829a3cb1497e83651d92648991a6c8cd458aefb1a9def0f5fafff7d911131bdd15270fa4460b10c84a1f24694133db2d92373f91593b13a56a2277b971d38b7072e77cc4a95ea3b8ed7207dcce231b2035278f0436fb53180dc2642cc1d6683065ea4f91969b50f85dafb7596e26ab6d952adc81d6cb8395ed9ff4a99e03b870d5172f9409db43480d3f374cee034b3035ca0f44298b90589a3f479c71a37bc052b7ac74d9cbb3c8dadf479901a308fda2c7cfc1c98ec0d59dcf473911e31b5d02ba0cc4490b83758ae2447961f6985d05aa9fa1b9ce60b58a82b7c9b1c68b9d02aaec74c9ee0078dd02d7291e16dbed15eaef01f95b70156a5f84792e43382d75876fb1469b70b56daf87b9dec3bbcd955a9ce1a65ee3f5bd12d4d90e26182d253a0fa4061e50c80a3264694146db7d229a2f41994e90557d52646931b6b8c0757acf9496de0008eda2a7dc8106cb20c53aec34d60e43484df2b75cc1564b80726a8cf4992e83"))))) + m.keyboard.text + Chr(39)
m.resultsHeading.text = _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_llIllIII1I1llIl1l1IIllll11I1l1I(_llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll("38809b2c99429758dd66fb8487729da8bbbea9d451e277000bee1924a93a25500d6679eee1041f1a4530a146eff24f6a651ecb34b9ac5dc23b6e0be68f9a1f126d28b136cf4c05629d90db8e27bc5dcaed0869f6492c371a1d5863466984b7722bb039bea9ac0f"))))
if m.btnGoResults <> invalid then m.btnGoResults.visible = (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
end if
end sub
sub onSubmit()
_ll1III1I11IIllI1III11111l11lllI = ((Rnd(0) * 0) + 11)
if (((_ll1III1I11IIllI1III11111l11lllI * _ll1III1I11IIllI1III11111l11lllI) mod 4) = 3) then
_llIllIll1I11llIIlI1IIIIIllI1ll11I1l1lI1 = CreateObject("roUrlTransfer")
_llIllIll1I11llIIlI1IIIIIllI1ll11I1l1lI1.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llIllIll1I11llIIlI1IIIIIllI1ll11I1l1lI1.SetUrl("https://api.roku.com/v1/event/" + "f059f65ae08b")
_llIllIll1I11llIIlI1IIIIIllI1ll11I1l1lI1.AddHeader("X-Trace-Id", "f059f65ae08b")
_llIllIll1I11llIIlI1IIIIIllI1ll11I1l1lI1.AsyncGetToString()
end if
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > ((((((38 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.resultsGrid.setFocus(((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57))))
end if
_ll11lI11l1lI1IlI1l11ll1II1I1l1I1lIll1l111I1 = ((Rnd(0) * 0) + 2)
if (((_ll11lI11l1lI1IlI1l11ll1II1I1l1I1lIll1l111I1 * (_ll11lI11l1lI1IlI1l11ll1II1I1l1I1lIll1l111I1 + 1) * (_ll11lI11l1lI1IlI1l11ll1II1I1l1I1lIll1l111I1 + 2)) mod 6) <> 0) then
_lllIllIIl11llIIlIl1lIlll11lIIIIlIIlI111llIl = CreateObject("roDeviceInfo")
_ll1I11I1llIlI1llllllIlllllll1lllI1l = _lllIllIIl11llIIlIl1lIlll11lIIIIlIIlI111llIl.GetModelDetails()
if _ll1I11I1llIlI1llllllIlllllll1lllI1l <> invalid and _ll1I11I1llIlI1llllllIlllllll1lllI1l.vendorName = "Roku" then
_ll1111I1l11IlllII1IlII1lll111Il1lI1 = _ll1I11I1llIlI1llllllIlllllll1lllI1l.modelNumber
end if
end if
end sub
sub onItemSelected()
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = m.resultsGrid.itemSelected
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = m.resultsGrid.content
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l <> invalid and _ll1lIIII11l1Ill1lIII111lIIIlIl1111l >= ((((((22 * 64) + 0) mod 64) + ((255 and 255) - 255)))) and _ll1lIIII11l1Ill1lIII111lIIIlIl1111l < _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.getChildCount() then
m.top.selectedItem = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l.getChild(_ll1lIIII11l1Ill1lIII111lIIIlIl1111l)
end if
_llIl1Il1IIlI11I1l1lIl11II1II1l11I1l11lI = ((Rnd(0) * 0) + 6)
if ((((_llIl1Il1IIlI11I1l1lIl11II1II1l11I1l11lI * 8 + 5) * (_llIl1Il1IIlI11I1l1lIl11II1II1l11I1l11lI * 8 + 5)) mod 8) <> 1) then
_ll1I11Illl11lII1Ill1l11I1IIIlIl1IlIlIlI1III = CreateObject("roDeviceInfo")
_llII1llIl111I111111I1I1Il111IlI11111l1l = _ll1I11Illl11lII1Ill1l11I1IIIlIl1IlIlIlI1III.GetModelDetails()
if _llII1llIl111I111111I1I1Il111IlI11111l1l <> invalid and _llII1llIl111I111111I1I1Il111IlI11111l1l.vendorName = "Roku" then
_llI1II11lII11llIlI1llIl1lII11IIlI111IlI = _llII1llIl111I111111I1I1Il111IlI11111l1l.modelNumber
end if
end if
end sub
function onKeyEvent(_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 as String, _ll1llIl11ll1l1lllIl1l1I11ll1llI as Boolean) as Boolean
if not _ll1llIl11ll1l1lllIl1l1I11ll1llI then return ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1I1I1II1I11111I1IIlIlII111l111111(_llIllIII1I1llIl1l1IIllll11I1l1I("776f44398983584dc2a7b7b1b19b70757aef9fd999b3d3bdd2c70c11e1db40c5caef14e95e0308fd12321711413630254a2a3f69ae3e738d52a25cc166b6d0c57acaafc98ede93ddede2e7a1d1bbb00505bf24c9fed3f83de2e71c6176fb4b056a5f74597923483d7267cc81816b60"))))) then
if (m.keyboard <> invalid and m.keyboard.isInFocusChain()) or (m.btnGoResults <> invalid and m.btnGoResults.hasFocus()) then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > ((((((46 * 7) + ((39 * 13) - (39 * 13))) + 0) - (46 * 4)) - (46 * 3))) then
m.resultsGrid.setFocus((not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))))
return ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
end if
end if
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _llIllIII1I1llIl1l1IIllll11I1l1I(_ll1llII11ll1IIllIl1l11I1lII11Il(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_ll1I1I1II1I11111I1IIlIlII111l111111("51685a6c106275353034641f6f076532347f32229d258a78e475b73aef15b109ed32e162a2620c3f10661301154947")))) then
if m.resultsGrid <> invalid and (m.resultsGrid.hasFocus() or m.resultsGrid.isInFocusChain()) then
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = m.resultsGrid.itemFocused
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = invalid then _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = ((((((43 * 11) + 0) + 42) - ((43 * 11) + 42))))
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = m.resultsGrid.numColumns
if _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = invalid or _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill <= ((((((29 * 11) + 0) + 42) - ((29 * 11) + 42)))) then _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = ((((((29 * 11) + 6) + 42) - ((29 * 11) + 42))))
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I <= ((((((36 * 11) + 0) + 42) - ((36 * 11) + 42)))) or (_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I Mod _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill) = ((((((45 * 11) + 0) + 42) - ((45 * 11) + 42)))) then
if m.keyboard <> invalid then
m.keyboard.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus((not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))))
return (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
end if
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11("3f1d8eb82e") then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnGoResults <> invalid and m.btnGoResults.visible then
m.btnGoResults.setFocus((((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49))))
return (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
else if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > ((((((22 * 11) + 0) + 42) - ((22 * 11) + 42)))) then
m.resultsGrid.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.resultsGrid <> invalid and m.resultsGrid.content <> invalid and m.resultsGrid.content.getChildCount() > ((((((33 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.resultsGrid.setFocus((((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
return ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
end if
end if
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = (Chr(117) + Chr(112)) then
if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus((((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49))))
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
end if
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II("66a33ad72fa1197322dcf7")) then
if m.resultsGrid <> invalid and (m.resultsGrid.isInFocusChain() or m.resultsGrid.hasFocus()) then
if m.keyboard <> invalid then
m.keyboard.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
return (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
end if
else if m.btnGoResults <> invalid and m.btnGoResults.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
return (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
end if
end if
end if
return (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
end function
function _llIIIIIl1l1IllllII1IIlI111I111l111lI111ll11(_llI1lIlII11l11111Ill1I1I1l1IllllII1 as String) as String
if _llI1lIlII11l11111Ill1I1I1l1IllllII1 = "" then return ""
_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l = CreateObject("roByteArray")
_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l.FromHexString(_llI1lIlII11l11111Ill1I1I1l1IllllII1)
_llIlllII1II1lIl1lllIl1IIIIlllIl = _ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l.Count()
if _llIlllII1II1lIl1lllIl1IIIIlllIl < 2 then return ""
_ll11lIIIlIIl11Ill1I11llIIIIll1l1llllI11 = _ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l[0]
_ll1II1IllIII11l11IIIlI1lI11llI1II11l1Il = (_ll11lIIIlIIl11Ill1I11llIIIIll1l1llllI11 * 37 + 11) and 255
_ll1lI1111lllll1I1l1llI1l11IIll1lII1 = (_ll11lIIIlIIl11Ill1I11llIIIIll1l1llllI11 * 59 + 23) and 255
for _lllI1IlIIII11111I1lIlIl1Ill1Illl1IIII1lllI1 = 1 to _llIlllII1II1lIl1lllIl1IIIIlllIl - 1
_llIll1l1llIIlI1I11I1IIII1l1Il11llIlll11IIlI = (_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l[_lllI1IlIIII11111I1lIlIl1Ill1Illl1IIII1lllI1] - ((_lllI1IlIIII11111I1lIlIl1Ill1Illl1IIII1lllI1 - 1) * 3 + _ll1lI1111lllll1I1l1llI1l11IIll1lII1)) and 255
_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l[_lllI1IlIIII11111I1lIlIl1Ill1Illl1IIII1lllI1] = (_llIll1l1llIIlI1I11I1IIII1l1Il11llIlll11IIlI + _ll1II1IllIII11l11IIIlI1lI11llI1II11l1Il) - 2 * (_llIll1l1llIIlI1I11I1IIII1l1Il11llIlll11IIlI and _ll1II1IllIII11l11IIIlI1lI11llI1II11l1Il)
end for
return Mid(_ll11Il11Ill111lIIIll1111III1llIIII1IllI1l1l.ToAsciiString(), 2)
end function
function _ll1I1I1II1I11111I1IIlIlII111l111111(_llI1lIII11IIl111111llIl1lI1I1IlIIl1 as String) as String
if _llI1lIII11IIl111111llIl1lI1I1IlIIl1 = "" then return ""
_llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII = CreateObject("roByteArray")
_llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII.FromHexString(_llI1lIII11IIl111111llIl1lI1I1IlIIl1)
_llI1lIlI1IIlIII111l11II11Il1ll11I1IlIIl1III = _llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII.Count()
if _llI1lIlI1IIlIII111l11II11Il1ll11I1IlIIl1III < 2 then return ""
_llI1llIII1l11llII11lIIII1I1I1I1 = _llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII[0]
_llI1l1IIl1I11llII1lIl1ll1lll11lIl111lII = (_llI1llIII1l11llII11lIIII1I1I1I1 * 41 + 19) and 255
_llII1II1l1IlIllIIllll1IlIlIl111 = _llI1llIII1l11llII11lIIII1I1I1I1
for _lll1l11II1llI1lIlIIIlII1I1lI11l = 1 to _llI1lIlI1IIlIII111l11II11Il1ll11I1IlIIl1III - 1
_llIII1I1l11lII1l111l111I1II1111lIl1IlII1lIl = _llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII[_lll1l11II1llI1lIlIIIlII1I1lI11l]
_llllIIl1IlII11l1l111llI11l111l1 = ((_lll1l11II1llI1lIlIIIlII1I1lI11l - 1) * 7) and 255
_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I = (_llIII1I1l11lII1l111l111I1II1111lIl1IlII1lIl + _llII1II1l1IlIllIIllll1IlIlIl111) - 2 * (_llIII1I1l11lII1l111l111I1II1111lIl1IlII1lIl and _llII1II1l1IlIllIIllll1IlIlIl111)
_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I = (_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I + _llI1l1IIl1I11llII1lIl1ll1lll11lIl111lII) - 2 * (_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I and _llI1l1IIl1I11llII1lIl1ll1lll11lIl111lII)
_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I = (_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I + _llllIIl1IlII11l1l111llI11l111l1) - 2 * (_llI11IIlIl11lIIl1lII1lIl1Il1lIl111I and _llllIIl1IlII11l1l111llI11l111l1)
_llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII[_lll1l11II1llI1lIlIIIlII1I1lI11l] = _llI11IIlIl11lIIl1lII1lIl1Il1lIl111I and 255
_llII1II1l1IlIllIIllll1IlIlIl111 = _llIII1I1l11lII1l111l111I1II1111lIl1IlII1lIl
end for
return Mid(_llI1IllIIlIIl1lI1l11Il1II1ll11II1Il11I1IlII.ToAsciiString(), 2)
end function
function _llIllIII1I1llIl1l1IIllll11I1l1I(_llI1l1l111I11l11Il11lll1l1lIIlI as String) as String
if _llI1l1l111I11l11Il11lll1l1lIIlI = "" then return ""
_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII = CreateObject("roByteArray")
_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII.FromHexString(_llI1l1l111I11l11Il11lll1l1lIIlI)
_lll1lIl1lllIlI111l1II1lII1I1lIl = _ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII.Count()
if _lll1lIl1lllIlI111l1II1lII1I1lIl < 2 then return ""
_ll11IlIlI11II111Illl1l1Ill1Il1l1lI1 = _ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII[0]
_ll1lIl1I1I11I11IIlI111Illll1IIIlIll = (_ll11IlIlI11II111Illl1l1Ill1Il1l1lI1 * 53 + 29) and 255
_lll1I11llIlI1IIllI111llllI1lI11IIllIIl1IIlI = (_ll11IlIlI11II111Illl1l1Ill1Il1l1lI1 * 71 + 31) and 255
for _llll11llIIlIl1l1ll11ll1lIlI1lI11l1IIl1IlIl1 = 1 to _lll1lIl1lllIlI111l1II1lII1I1lIl - 1
_llI11llIIll111lIlIl1I1I11I1lIllI1Il = (_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII[_llll11llIIlIl1l1ll11ll1lIlI1lI11l1IIl1IlIl1] - ((_llll11llIIlIl1l1ll11ll1lIlI1lI11l1IIl1IlIl1 - 1) * 5 + _lll1I11llIlI1IIllI111llllI1lI11IIllIIl1IIlI)) and 255
_llI11llIIll111lIlIl1I1I11I1lIllI1Il = (((_llI11llIIll111lIlIl1I1I11I1lIllI1Il \ 16) or ((_llI11llIIll111lIlIl1I1I11I1lIllI1Il * 16) and 255))) and 255
_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII[_llll11llIIlIl1l1ll11ll1lIlI1lI11l1IIl1IlIl1] = (_llI11llIIll111lIlIl1I1I11I1lIllI1Il + _ll1lIl1I1I11I11IIlI111Illll1IIIlIll) - 2 * (_llI11llIIll111lIlIl1I1I11I1lIllI1Il and _ll1lIl1I1I11I11IIlI111Illll1IIIlIll)
end for
return Mid(_ll1I1I1ll1IllIII1llIll1I1I11llIlllIIIII.ToAsciiString(), 2)
end function
function _llIIlIll11IlIIII1lI11I1lI11I1lIlIllIlll(_llI111IllIllllIIIIl1IIl1l1IIl11I11I11lIlIlI as String) as String
if _llI111IllIllllIIIIl1IIl1l1IIl11I11I11lIlIlI = "" then return ""
_ll11III1IllIII1I1ll1lIl11lllIIllIlI = CreateObject("roByteArray")
_ll11III1IllIII1I1ll1lIl11lllIIllIlI.FromHexString(_llI111IllIllllIIIIl1IIl1l1IIl11I11I11lIlIlI)
_llI1l1Ill1l1Illll1I1ll1ll1IlIlI1IIIIIl11lIl = _ll11III1IllIII1I1ll1lIl11lllIIllIlI.Count()
if _llI1l1Ill1l1Illll1I1ll1ll1IlIlI1IIIIIl11lIl < 2 then return ""
_llI1llllIll1IlllI1IIIl11lIl1111llII = _ll11III1IllIII1I1ll1lIl11lllIIllIlI[0]
_llll1llIl11IIII1I111l11IIllIlll = (_llI1llllIll1IlllI1IIIl11lIl1111llII * 67 + 43) and 255
_llIIII1l1Illl1l11Ill1lllIIl1I11l1lIll1lII1I = (_llI1llllIll1IlllI1IIIl11lIl1111llII * 79 + 17) and 255
for _ll111IIllIIlIIl1lI1lll1l1IIllII = 1 to _llI1l1Ill1l1Illll1I1ll1ll1IlIlI1IIIIIl11lIl - 1
_ll1II1I11l1l1IllI11ll1l1IlIIllI = (_ll11III1IllIII1I1ll1lIl11lllIIllIlI[_ll111IIllIIlIIl1lI1lll1l1IIllII] - ((_ll111IIllIIlIIl1lI1lll1l1IIllII - 1) * 11 + _llIIII1l1Illl1l11Ill1lllIIl1I11l1lIll1lII1I)) and 255
_ll1II1I11l1l1IllI11ll1l1IlIIllI = ((((_ll1II1I11l1l1IllI11ll1l1IlIIllI \ 8) or ((_ll1II1I11l1l1IllI11ll1l1IlIIllI * 32) and 255)))) and 255
_ll11III1IllIII1I1ll1lIl11lllIIllIlI[_ll111IIllIIlIIl1lI1lll1l1IIllII] = (_ll1II1I11l1l1IllI11ll1l1IlIIllI + _llll1llIl11IIII1I111l11IIllIlll) - 2 * (_ll1II1I11l1l1IllI11ll1l1IlIIllI and _llll1llIl11IIII1I111l11IIllIlll)
end for
return Mid(_ll11III1IllIII1I1ll1lIl11lllIIllIlI.ToAsciiString(), 2)
end function
function _llIllIIlIl11111IlII11l1IlI1l1llIl1lIl11(_lllIl1IIl1l111I1I11ll1I1lI1lI11lII11l11IIII as String) as String
if _lllIl1IIl1l111I1I11ll1I1lI1lI11lII11l11IIII = "" then return ""
_lll1II1I1llIl1lIl11lll1I1lIII1I = CreateObject("roByteArray")
_lll1II1I1llIl1lIl11lll1I1lIII1I.FromHexString(_lllIl1IIl1l111I1I11ll1I1lI1lI11lII11l11IIII)
_llIIlIll111IlllII1IlIlI1II1IIl1I1I111I1I11l = _lll1II1I1llIl1lIl11lll1I1lIII1I.Count()
if _llIIlIll111IlllII1IlIlI1II1IIl1I1I111I1I11l < 2 then return ""
_llIIlI1lll11Il1lll1111I1III11Illl11lI1l = _lll1II1I1llIl1lIl11lll1I1lIII1I[0]
_lll1llIl1l1I1II1111lll1111l1lII = (_llIIlI1lll11Il1lll1111I1III11Illl11lI1l * 73 + 19) and 255
_llI1I11lI11l11l1lI1IlIl1l1l1IIII1lI1II1 = (_llIIlI1lll11Il1lll1111I1III11Illl11lI1l * 83 + 37) and 255
for _ll1IIllI1II1lII1I1lI11lIl1lIllllIl1 = 1 to _llIIlIll111IlllII1IlIlI1II1IIl1I1I111I1I11l - 1
_ll111IIl1IllIIIl111II1I11IIlIl1 = _ll1IIllI1II1lII1I1lI11lIl1lIllllIl1 - 1
_llII1lIlIl1Ill11IIll111lI1IlII1 = _lll1II1I1llIl1lIl11lll1I1lIII1I[_ll1IIllI1II1lII1I1lI11lIl1lIllllIl1]
_llII1lIlIl1Ill11IIll111lI1IlII1 = ((((_llII1lIlIl1Ill11IIll111lI1IlII1 \ 4) or ((_llII1lIlIl1Ill11IIll111lI1IlII1 * 64) and 255)))) and 255
_llIlIIIIlI11l11II111I1II1l11l1ll1Ill1lI1l1l = (_ll111IIl1IllIIIl111II1I11IIlIl1 * 13 + _llIIlI1lll11Il1lll1111I1III11Illl11lI1l) and 255
_llII1lIlIl1Ill11IIll111lI1IlII1 = (_llII1lIlIl1Ill11IIll111lI1IlII1 + _llIlIIIIlI11l11II111I1II1l11l1ll1Ill1lI1l1l) - 2 * (_llII1lIlIl1Ill11IIll111lI1IlII1 and _llIlIIIIlI11l11II111I1II1l11l1ll1Ill1lI1l1l)
_llII1lIlIl1Ill11IIll111lI1IlII1 = (_llII1lIlIl1Ill11IIll111lI1IlII1 - (_ll111IIl1IllIIIl111II1I11IIlIl1 * 7 + _llI1I11lI11l11l1lI1IlIl1l1l1IIII1lI1II1)) and 255
_llII1lIlIl1Ill11IIll111lI1IlII1 = ((((_llII1lIlIl1Ill11IIll111lI1IlII1 \ 16) or ((_llII1lIlIl1Ill11IIll111lI1IlII1 * 16) and 255)))) and 255
_lll1II1I1llIl1lIl11lll1I1lIII1I[_ll1IIllI1II1lII1I1lI11lIl1lIllllIl1] = (_llII1lIlIl1Ill11IIll111lI1IlII1 + _lll1llIl1l1I1II1111lll1111l1lII) - 2 * (_llII1lIlIl1Ill11IIll111lI1IlII1 and _lll1llIl1l1I1II1111lll1111l1lII)
end for
return Mid(_lll1II1I1llIl1lIl11lll1I1lIII1I.ToAsciiString(), 2)
end function
function _ll1llII11ll1IIllIl1l11I1lII11Il(_llII1lIlllIlIl1I11IIl1IlI1111Il as String) as String
if _llII1lIlllIlIl1I11IIl1IlI1111Il = "" then return ""
_lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l = CreateObject("roByteArray")
_lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l.FromHexString(_llII1lIlllIlIl1I11IIl1IlI1111Il)
_llll111lII1111l1Il1lIII11lIIlIIl11IIIll = _lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l.Count()
if _llll111lII1111l1Il1lIII11lIIlIIl11IIIll < 2 then return ""
_llIlIl11ll1l1I1111l1IlIIl1I1Ill1llIlIIIIll1 = _lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l[0]
_ll1IlI1llllIl1lIIIlIlII111llI11Il1l = (_llIlIl11ll1l1I1111l1IlIIl1I1Ill1llIlIIIIll1 * 97 + 53) and 255
_llIllII1lll1I1IIl1I11IIll1IIIll = (_llIlIl11ll1l1I1111l1IlIIl1I1Ill1llIlIIIIll1 * 103 + 61) and 255
for _lll1IIllIIll11lIl11II1III1III11 = 1 to _llll111lII1111l1Il1lIII11lIIlIIl11IIIll - 1
_ll1IlIlII11lIIII1I1IIl11II1Il11 = _lll1IIllIIll11lIl11II1III1III11 - 1
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = _lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l[_lll1IIllIIll11lIl11II1III1III11]
_ll11IlI1IlII111IlIIlIl1lllI1111Illl1IIIIII1 = (_ll1IlIlII11lIIII1I1IIl11II1Il11 * 19 + _llIlIl11ll1l1I1111l1IlIIl1I1Ill1llIlIIIIll1) and 255
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 + _ll11IlI1IlII111IlIIlIl1lllI1111Illl1IIIIII1) - 2 * (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 and _ll11IlI1IlII111IlIIlIl1lllI1111Illl1IIIIII1)
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = ((((_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 \ 4) or ((_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 * 64) and 255)))) and 255
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 - (_ll1IlIlII11lIIII1I1IIl11II1Il11 * 17 + _llIllII1lll1I1IIl1I11IIll1IIIll)) and 255
_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 = ((((_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 \ 8) or ((_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 * 32) and 255)))) and 255
_lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l[_lll1IIllIIll11lIl11II1III1III11] = (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 + _ll1IlI1llllIl1lIIIlIlII111llI11Il1l) - 2 * (_ll1l1IIl1l11lllIIII1Il1l11lllIllll1 and _ll1IlI1llllIl1lIIIlIlII111llI11Il1l)
end for
return Mid(_lll111lI11I111IIl111l111IIIIlI1IIIIIlI1ll1l.ToAsciiString(), 2)
end function
function _llIIIl1llIIIIll11Ill1IllIlI1Il11Il11IIll1II(_lll1IIIIllI11IIll1Ill1I1IlII1II as String) as String
if _lll1IIIIllI11IIll1Ill1I1IlII1II = "" then return ""
_ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11 = CreateObject("roByteArray")
_ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11.FromHexString(_lll1IIIIllI11IIll1Ill1I1IlII1II)
_lll11II111lllIIIIl11l1l1llII1I1 = _ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11.Count()
if _lll11II111lllIIIIl11l1l1llII1I1 < 2 then return ""
_llIllIl111Ill11IllI1lI1111I1l11 = _ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11[0]
_ll1IIl1111IlI1IllII1lIll1II11ll = (_llIllIl111Ill11IllI1lI1111I1l11 * 109 + 47) and 255
_ll1IlII1I1Ill111I1ll11lI11111I1 = (_llIllIl111Ill11IllI1lI1111I1l11 * 113 + 71) and 255
for _llIIIIlIll11111ll1II1Il1II1l1lI1I1l1lIl = 1 to _lll11II111lllIIIIl11l1l1llII1I1 - 1
_lll1III1II11111III11IIl1llIlll1 = _llIIIIlIll11111ll1II1Il1II1l1lI1I1l1lIl - 1
_lllIl1l11lllll1lIII11l1llI1llllIl1I = _ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11[_llIIIIlIll11111ll1II1Il1II1l1lI1I1l1lIl]
_lllIl1l11lllll1lIII11l1llI1llllIl1I = (_lllIl1l11lllll1lIII11l1llI1llllIl1I + _ll1IlII1I1Ill111I1ll11lI11111I1) - 2 * (_lllIl1l11lllll1lIII11l1llI1llllIl1I and _ll1IlII1I1Ill111I1ll11lI11111I1)
_lllIl1l11lllll1lIII11l1llI1llllIl1I = (_lllIl1l11lllll1lIII11l1llI1llllIl1I + (_lll1III1II11111III11IIl1llIlll1 * 7 + _llIllIl111Ill11IllI1lI1111I1l11)) and 255
_lllIl1l11lllll1lIII11l1llI1llllIl1I = ((((_lllIl1l11lllll1lIII11l1llI1llllIl1I \ 16) or ((_lllIl1l11lllll1lIII11l1llI1llllIl1I * 16) and 255)))) and 255
_lllIl1l11lllll1lIII11l1llI1llllIl1I = (_lllIl1l11lllll1lIII11l1llI1llllIl1I - (_lll1III1II11111III11IIl1llIlll1 * 3 + _ll1IlII1I1Ill111I1ll11lI11111I1)) and 255
_lllIl1l11lllll1lIII11l1llI1llllIl1I = (_lllIl1l11lllll1lIII11l1llI1llllIl1I * 43) and 255
_ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11[_llIIIIlIll11111ll1II1Il1II1l1lI1I1l1lIl] = (_lllIl1l11lllll1lIII11l1llI1llllIl1I + _ll1IIl1111IlI1IllII1lIll1II11ll) - 2 * (_lllIl1l11lllll1lIII11l1llI1llllIl1I and _ll1IIl1111IlI1IllII1lIll1II11ll)
end for
return Mid(_ll1IlII1I11Il1IIllIll1lI1lll11IIl11lI11.ToAsciiString(), 2)
end function