sub init()
if ((19450 - 3890 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.top.functionName = _l1d_492033("eff9e101f2f9140b0df4", 42, 151)
end sub
sub runKeyAuth()
if ((8872 - 1109 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_llIll1l = m.top.action
if _llIll1l = _l1d_492033("909693909eac99", 165, 199) then
m.top.result = KA_License(m.top.licenseKey)
else if _llIll1l = _l1d_492033("dfd3e1dddbf3", 35, 138) then
m.top.result = KA_VerifySavedLicense()
else if _llIll1l = _l1d_492033("dfe1dce5e9", 82, 161) then
m.top.result = KA_Login(m.top.username, m.top.password)
else
m.top.result = KA_Init()
end if
end sub
function _l1d_492033(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function