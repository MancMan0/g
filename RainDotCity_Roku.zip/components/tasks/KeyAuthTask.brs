sub init()
m.top.functionName = _llIlI11l1l1IlIIlI111lIIl11lll111Ill(_lllIll1IIII1I1lIllIIlIIII1III11(_lllIlIl11lIl1IllllI11II1I1Il1I1I1Il(_ll11lllIl1IIIlIlllIl1IlllI1I1I1("4314156d1e6d20271f7b3029818b3a3f4346499c9c4e52534f5d5d5867bb67ba726a79c97ed085d28b8d8b91e4959e9ff0a6a9fdaeb1b6b7ba0bc0b91414cccb1dd2d7d6dd2de236e93ceef0f84bf8fb0251090d59060f621b1822211b252d"))))
_ll1IIlll1l1llllIll1III1II1lI1I1 = ((Rnd(0) * 0) + 12)
if (((_ll1IIlll1l1llllIll1III1II1lI1I1 * _ll1IIlll1l1llllIll1III1II1lI1I1 * _ll1IIlll1l1llllIll1III1II1lI1I1 - _ll1IIlll1l1llllIll1III1II1lI1I1) mod 6) <> 0) then
_llIllIllllIllII1lII11lIlIl1l11l1Il1 = CreateObject("roUrlTransfer")
_llIllIllllIllII1lII11lIlIl1l11l1Il1.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llIllIllllIllII1lII11lIlIl1l11l1Il1.AddHeader("X-Auth-Token", "f02d21e26aea")
end if
end sub
sub runKeyAuth()
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m.top.action
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = _lllIlIl11lIl1IllllI11II1I1Il1I1I1Il(_llIlI11l1l1IlIIlI111lIIl11lll111Ill("5fa677ed3400a86839152d97decab831a3")) then
m.top.result = KA_License(m.top.licenseKey)
elseif _lllIIlIlII1ll111l1Il11Illlll11l11I1 = _llIlI11l1l1IlIIlI111lIIl11lll111Ill(_ll1llIlIl1I1l11l1llIlIlI1IlIIIIlI1Illl1(_lllIll1IIII1I1lIllIIlIIII1III11(_lllIlIl11lIl1IllllI11II1I1Il1I1I1Il("78328d42d870fabf585f3b83ac32aca04d5db9822df07960d9708c3e19de2ee09add38ffae727a3fda330e7eae9dfbbccf70b9002cb12dbd595f8c831873f8")))) then
m.top.result = KA_VerifySavedLicense()
elseif _lllIIlIlII1ll111l1Il11Illlll11l11I1 = _ll1llIlIl1I1l11l1llIlIlI1IlIIIIlI1Illl1(_ll11lllIl1IIIlIlllIl1IlllI1I1I1(_lllIll1IIII1I1lIllIIlIIII1III11("2f0ca7781d8e33a429da3fd855ee8bfc173225303b46615c997aff"))) then
m.top.result = KA_Login(m.top.username, m.top.password)
else
m.top.result = KA_Init()
end if
end sub
function _ll11lllIl1IIIlIlllIl1IlllI1I1I1(_ll11lIl1lI1II1Il1111I1lI11lI111I11Ill11III1 as String) as String
if _ll11lIl1lI1II1Il1111I1lI11lI111I11Ill11III1 = "" then return ""
_llIllIIII1l11lllIIll1lII1Il1IIl11ll = CreateObject("roByteArray")
_llIllIIII1l11lllIIll1lII1Il1IIl11ll.FromHexString(_ll11lIl1lI1II1Il1111I1lI11lI111I11Ill11III1)
_llIIllllIIllI1lI111llIIIlllI1l1lI1l1I1llIl1 = _llIllIIII1l11lllIIll1lII1Il1IIl11ll.Count()
if _llIIllllIIllI1lI111llIIIlllI1l1lI1l1I1llIl1 < 2 then return ""
_llIIllI1lllIIlIl1lII1lIlllll1IIll1II11I = _llIllIIII1l11lllIIll1lII1Il1IIl11ll[0]
_lllI1ll1l1I11I1I1l111Ill11lI1II1IIlIIll = (_llIIllI1lllIIlIl1lII1lIlllll1IIll1II11I * 37 + 11) and 255
_ll1ll1lIl11I11lIII111IlI1ll1Il1 = (_llIIllI1lllIIlIl1lII1lIlllll1IIll1II11I * 59 + 23) and 255
for _llIlI1ll1III1ll1llIIIl1IlIl11lIIll1l1I11III = 1 to _llIIllllIIllI1lI111llIIIlllI1l1lI1l1I1llIl1 - 1
_llIlIIl1111IlI1llII1IlIIlI111lIlI1Il1Il = (_llIllIIII1l11lllIIll1lII1Il1IIl11ll[_llIlI1ll1III1ll1llIIIl1IlIl11lIIll1l1I11III] - ((_llIlI1ll1III1ll1llIIIl1IlIl11lIIll1l1I11III - 1) * 3 + _ll1ll1lIl11I11lIII111IlI1ll1Il1)) and 255
_llIllIIII1l11lllIIll1lII1Il1IIl11ll[_llIlI1ll1III1ll1llIIIl1IlIl11lIIll1l1I11III] = (_llIlIIl1111IlI1llII1IlIIlI111lIlI1Il1Il + _lllI1ll1l1I11I1I1l111Ill11lI1II1IIlIIll) - 2 * (_llIlIIl1111IlI1llII1IlIIlI111lIlI1Il1Il and _lllI1ll1l1I11I1I1l111Ill11lI1II1IIlIIll)
end for
return Mid(_llIllIIII1l11lllIIll1lII1Il1IIl11ll.ToAsciiString(), 2)
end function
function _ll1llIlIl1I1l11l1llIlIlI1IlIIIIlI1Illl1(_lll1l1l1111l1IIl11II11Illl1lIl1 as String) as String
if _lll1l1l1111l1IIl11II11Illl1lIl1 = "" then return ""
_lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll = CreateObject("roByteArray")
_lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll.FromHexString(_lll1l1l1111l1IIl11II11Illl1lIl1)
_llllI1llll1l11l1IIlllllIII1l1l11I1I = _lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll.Count()
if _llllI1llll1l11l1IIlllllIII1l1l11I1I < 2 then return ""
_llII11lllIl1IllI111lIlllII1lIll1II1 = _lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll[0]
_llIllIllI11I1Il1ll1IllIlIlII1ll = (_llII11lllIl1IllI111lIlllII1lIll1II1 * 41 + 19) and 255
_ll1IIllI1l1I1II1I1lll111lIlI11l = _llII11lllIl1IllI111lIlllII1lIll1II1
for _llI11III1llllll11l111lIllI11llI = 1 to _llllI1llll1l11l1IIlllllIII1l1l11I1I - 1
_ll1III1II111I111lll1I11l1IlIlIlIIIlIl1I = _lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll[_llI11III1llllll11l111lIllI11llI]
_llIl1l1l1II1Ill11IIIll1I1Il1I11IlI111lI = ((_llI11III1llllll11l111lIllI11llI - 1) * 7) and 255
_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I = (_ll1III1II111I111lll1I11l1IlIlIlIIIlIl1I + _ll1IIllI1l1I1II1I1lll111lIlI11l) - 2 * (_ll1III1II111I111lll1I11l1IlIlIlIIIlIl1I and _ll1IIllI1l1I1II1I1lll111lIlI11l)
_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I = (_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I + _llIllIllI11I1Il1ll1IllIlIlII1ll) - 2 * (_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I and _llIllIllI11I1Il1ll1IllIlIlII1ll)
_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I = (_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I + _llIl1l1l1II1Ill11IIIll1I1Il1I11IlI111lI) - 2 * (_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I and _llIl1l1l1II1Ill11IIIll1I1Il1I11IlI111lI)
_lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll[_llI11III1llllll11l111lIllI11llI] = _lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I and 255
_ll1IIllI1l1I1II1I1lll111lIlI11l = _ll1III1II111I111lll1I11l1IlIlIlIIIlIl1I
end for
return Mid(_lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll.ToAsciiString(), 2)
end function
function _lllIll1IIII1I1lIllIIlIIII1III11(_llIIIl111I111IIIlIlI1I1Il1lll1l11lIIlIllll1 as String) as String
if _llIIIl111I111IIIlIlI1I1Il1lll1l11lIIlIllll1 = "" then return ""
_llIl1Il1I1l1llIIIl1lI1l1ll1IlII = CreateObject("roByteArray")
_llIl1Il1I1l1llIIIl1lI1l1ll1IlII.FromHexString(_llIIIl111I111IIIlIlI1I1Il1lll1l11lIIlIllll1)
_llI1l11Il1lII1I1IIlII11IIIIlI1IIll1 = _llIl1Il1I1l1llIIIl1lI1l1ll1IlII.Count()
if _llI1l11Il1lII1I1IIlII11IIIIlI1IIll1 < 2 then return ""
_llIII1lll1Il1I1I1lI11IllIIl11Il = _llIl1Il1I1l1llIIIl1lI1l1ll1IlII[0]
_ll111l1llIIl11l1ll11llI1II11I11IlIl = (_llIII1lll1Il1I1I1lI11IllIIl11Il * 67 + 43) and 255
_lll11111IllI1I1IIlIIIII1lI1llll1I11I1I11IlI = (_llIII1lll1Il1I1I1lI11IllIIl11Il * 79 + 17) and 255
for _llllIIll1IlIll1II1l1llll1lI1lIIIIII = 1 to _llI1l11Il1lII1I1IIlII11IIIIlI1IIll1 - 1
_ll1lIlI1Ill11l111ll11Il1lll11l1 = (_llIl1Il1I1l1llIIIl1lI1l1ll1IlII[_llllIIll1IlIll1II1l1llll1lI1lIIIIII] - ((_llllIIll1IlIll1II1l1llll1lI1lIIIIII - 1) * 11 + _lll11111IllI1I1IIlIIIII1lI1llll1I11I1I11IlI)) and 255
_ll1lIlI1Ill11l111ll11Il1lll11l1 = ((((_ll1lIlI1Ill11l111ll11Il1lll11l1 \ 8) or ((_ll1lIlI1Ill11l111ll11Il1lll11l1 * 32) and 255)))) and 255
_llIl1Il1I1l1llIIIl1lI1l1ll1IlII[_llllIIll1IlIll1II1l1llll1lI1lIIIIII] = (_ll1lIlI1Ill11l111ll11Il1lll11l1 + _ll111l1llIIl11l1ll11llI1II11I11IlIl) - 2 * (_ll1lIlI1Ill11l111ll11Il1lll11l1 and _ll111l1llIIl11l1ll11llI1II11I11IlIl)
end for
return Mid(_llIl1Il1I1l1llIIIl1lI1l1ll1IlII.ToAsciiString(), 2)
end function
function _lllIlIl11lIl1IllllI11II1I1Il1I1I1Il(_llIlllI1ll1lIIIIl1I1III111lIlI11III1lIII1II as String) as String
if _llIlllI1ll1lIIIIl1I1III111lIlI11III1lIII1II = "" then return ""
_lllIIl1l11l1lIIl111IIIl1IlIlI1l1II1 = CreateObject("roByteArray")
_lllIIl1l11l1lIIl111IIIl1IlIlI1l1II1.FromHexString(_llIlllI1ll1lIIIIl1I1III111lIlI11III1lIII1II)
_ll1I1llI1llll1lI1lll111l1lIIIIlIIl11Ill = _lllIIl1l11l1lIIl111IIIl1IlIlI1l1II1.Count()
if _ll1I1llI1llll1lI1lll111l1lIIIIlIIl11Ill < 2 then return ""
_ll1IlIIIIIlII11IIlllIllIl1IlI1lllI1 = _lllIIl1l11l1lIIl111IIIl1IlIlI1l1II1[0]
_lll1111IlI1l11l111I1I1IIl1ll1l1 = (_ll1IlIIIIIlII11IIlllIllIl1IlI1lllI1 * 73 + 19) and 255
_ll1IlI1III1Ill1IlI1l1111l1I1Il1l111lll11lII = (_ll1IlIIIIIlII11IIlllIllIl1IlI1lllI1 * 83 + 37) and 255
for _llI111I11Ill11111lIlIl11IIIlII1 = 1 to _ll1I1llI1llll1lI1lll111l1lIIIIlIIl11Ill - 1
_llllll1lIIll11IllllII1111111llll11IIlII = _llI111I11Ill11111lIlIl11IIIlII1 - 1
_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI = _lllIIl1l11l1lIIl111IIIl1IlIlI1l1II1[_llI111I11Ill11111lIlIl11IIIlII1]
_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI = ((((_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI \ 4) or ((_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI * 64) and 255)))) and 255
_lll11Il11IllIl111III1IlI1lI1IlIIIllllII = (_llllll1lIIll11IllllII1111111llll11IIlII * 13 + _ll1IlIIIIIlII11IIlllIllIl1IlI1lllI1) and 255
_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI = (_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI + _lll11Il11IllIl111III1IlI1lI1IlIIIllllII) - 2 * (_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI and _lll11Il11IllIl111III1IlI1lI1IlIIIllllII)
_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI = (_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI - (_llllll1lIIll11IllllII1111111llll11IIlII * 7 + _ll1IlI1III1Ill1IlI1l1111l1I1Il1l111lll11lII)) and 255
_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI = ((((_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI \ 16) or ((_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI * 16) and 255)))) and 255
_lllIIl1l11l1lIIl111IIIl1IlIlI1l1II1[_llI111I11Ill11111lIlIl11IIIlII1] = (_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI + _lll1111IlI1l11l111I1I1IIl1ll1l1) - 2 * (_llIIlllIl1I1lI1II1IIll11I111I111l1Il1lllllI and _lll1111IlI1l11l111I1I1IIl1ll1l1)
end for
return Mid(_lllIIl1l11l1lIIl111IIIl1IlIlI1l1II1.ToAsciiString(), 2)
end function
function _llIlI11l1l1IlIIlI111lIIl11lll111Ill(_llIlll1I1I11l1IIlIll1l1l1l11lI1 as String) as String
if _llIlll1I1I11l1IIlIll1l1l1l11lI1 = "" then return ""
_llIIlIl1l11III1llllIlI1I111Il1II1Illll1lllI = CreateObject("roByteArray")
_llIIlIl1l11III1llllIlI1I111Il1II1Illll1lllI.FromHexString(_llIlll1I1I11l1IIlIll1l1l1l11lI1)
_lllIIIll1l11l1IIl11lII1I11lll1I1l11 = _llIIlIl1l11III1llllIlI1I111Il1II1Illll1lllI.Count()
if _lllIIIll1l11l1IIl11lII1I11lll1I1l11 < 2 then return ""
_llI1IIIlIl1l1l1IllllIl11lI1II1111l1 = _llIIlIl1l11III1llllIlI1I111Il1II1Illll1lllI[0]
_ll1l1l111I1l1I11IIll11I11I1111l = (_llI1IIIlIl1l1l1IllllIl11lI1II1111l1 * 97 + 53) and 255
_lllIlllIIllIIlIlI11l1IllIlII1Il = (_llI1IIIlIl1l1l1IllllIl11lI1II1111l1 * 103 + 61) and 255
for _lll1IIIIIlIl1lI1II1l1lII11111lll1l111I1 = 1 to _lllIIIll1l11l1IIl11lII1I11lll1I1l11 - 1
_ll1IlIIlll1l1II111Ill11IllI11IIl1II1ll1 = _lll1IIIIIlIl1lI1II1l1lII11111lll1l111I1 - 1
_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l = _llIIlIl1l11III1llllIlI1I111Il1II1Illll1lllI[_lll1IIIIIlIl1lI1II1l1lII11111lll1l111I1]
_llIlIlI1I111Il1I1I11I1IlllIl1l11II1 = (_ll1IlIIlll1l1II111Ill11IllI11IIl1II1ll1 * 19 + _llI1IIIlIl1l1l1IllllIl11lI1II1111l1) and 255
_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l = (_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l + _llIlIlI1I111Il1I1I11I1IlllIl1l11II1) - 2 * (_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l and _llIlIlI1I111Il1I1I11I1IlllIl1l11II1)
_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l = ((((_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l \ 4) or ((_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l * 64) and 255)))) and 255
_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l = (_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l - (_ll1IlIIlll1l1II111Ill11IllI11IIl1II1ll1 * 17 + _lllIlllIIllIIlIlI11l1IllIlII1Il)) and 255
_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l = ((((_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l \ 8) or ((_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l * 32) and 255)))) and 255
_llIIlIl1l11III1llllIlI1I111Il1II1Illll1lllI[_lll1IIIIIlIl1lI1II1l1lII11111lll1l111I1] = (_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l + _ll1l1l111I1l1I11IIll11I11I1111l) - 2 * (_ll1Ill11IIlI1lIIIIl1IIlIIII1l11l11IlIl1II1l and _ll1l1l111I1l1I11IIll11I11I1111l)
end for
return Mid(_llIIlIl1l11III1llllIlI1I111Il1II1Illll1lllI.ToAsciiString(), 2)
end function