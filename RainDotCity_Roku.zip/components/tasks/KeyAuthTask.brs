sub init()
m.top.functionName = _llIlIl1lll11IlllIIIl1I1lI11I1ll111I("2b797e0c24e862867166cd")
end sub
sub runKeyAuth()
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m.top.action
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = _ll1llIlIl1I1l11l1llIlIlI1IlIIIIlI1Illl1("4b3149325430762f") then
_llll1I11llIlll11lII11l11111IIIl = _ll1111111l1lII1111II11IllIlI1l1lIl(m.top.licenseKey)
if _llll1I11llIlll11lII11l11111IIIl <> invalid and _llll1I11llIlll11lII11l11111IIIl.success = true then
_ll1III1l1ll1IIIlI1IlII1ll11lIll1l1()
end if
m.top.result = _llll1I11llIlll11lII11l11111IIIl
else if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = _ll1llIlIl1I1l11l1llIlIlI1IlIIIIlI1Illl1("6783739d739b53") then
_llll1I11llIlll11lII11l11111IIIl = _llIIl1lll1II1lI1lIIlIIlI1l11l11lll()
if _llll1I11llIlll11lII11l11111IIIl <> invalid and _llll1I11llIlll11lII11l11111IIIl.success = true then
_ll1III1l1ll1IIIlI1IlII1ll11lIll1l1()
end if
m.top.result = _llll1I11llIlll11lII11l11111IIIl
else if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = _lllIll1IIII1I1lIllIIlIIII1III11("5a8598e37ec1") then
_llll1I11llIlll11lII11l11111IIIl = _ll1111111l1lII1111II11IllIlI1l1lIl(m.top.username)
if _llll1I11llIlll11lII11l11111IIIl <> invalid and _llll1I11llIlll11lII11l11111IIIl.success = true then
_ll1III1l1ll1IIIlI1IlII1ll11lIll1l1()
end if
m.top.result = _llll1I11llIlll11lII11l11111IIIl
else
m.top.result = { success: true }
end if
end sub
function _ll1llIlIl1I1l11l1llIlIlI1IlIIIIlI1Illl1(_lll1l1l1111l1IIl11II11Illl1lIl1 as String) as String
if _lll1l1l1111l1IIl11II11Illl1lIl1 = "" then return ""
_lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll = CreateObject("roByteArray")
_lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll.FromHexString(_lll1l1l1111l1IIl11II11Illl1lIl1)
_llllI1llll1l11l1IIlllllIII1l1l11I1I = _lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll.Count()
if _llllI1llll1l11l1IIlllllIII1l1l11I1I < 2 then return ""
_llII11lllIl1IllI111lIlllII1lIll1II1 = _lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll[0]
_llIllIllI11I1Il1ll1IllIlIlII1ll = (_llII11lllIl1IllI111lIlllII1lIll1II1 * 41 + 19) and 255
_ll1IIllI1l1I1II1I1lll111lIlI11l = _llII11lllIl1IllI111lIlllII1lIll1II1
for _llI11III1llllll11l111lIllI11llI = 1 to _llllI1llll1l11l1IIlllllIII1l1l11I1I - 1
_ll1III1II111I111lll1I11l1IlIlIlIIIlIl1I = _lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll[_llI11III1llllll11l111lIllI11llI]
_llIl1l1l1II1Ill11IIIll1I1Il1I11IlI111lI = ((_llI11III1llllll11l111lIllI11llI - 1) * 7) and 255
_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I = (_ll1III1II111I111lll1I11l1IlIlIlIIIlIl1I + _ll1IIllI1l1I1II1I1lll111lIlI11l) - 2 * (_ll1III1II111I111lll1I11l1IlIlIlIIIlIl1I and _ll1IIllI1l1I1II1I1lll111lIlI11l)
_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I = (_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I + _llIllIllI11I1Il1ll1IllIlIlII1ll) - 2 * (_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I and _llIllIllI11I1Il1ll1IllIlIlII1ll)
_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I = (_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I + _llIl1l1l1II1Ill11IIIll1I1Il1I11IlI111lI) - 2 * (_lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I and _llIl1l1l1II1Ill11IIIll1I1Il1I11IlI111lI)
_lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll[_llI11III1llllll11l111lIllI11llI] = _lll1llI1I1lIl1IIl1llllll1Il11Il1I1l1l1I and 255
_ll1IIllI1l1I1II1I1lll111lIlI11l = _ll1III1II111I111lll1I11l1IlIlIlIIIlIl1I
end for
return Mid(_lll1lIIIIll1l1l1IlIllllIIl11Ill11lIlIlIllll.ToAsciiString(), 2)
end function
function _lllIll1IIII1I1lIllIIlIIII1III11(_llIIIl111I111IIIlIlI1I1Il1lll1l11lIIlIllll1 as String) as String
if _llIIIl111I111IIIlIlI1I1Il1lll1l11lIIlIllll1 = "" then return ""
_llIl1Il1I1l1llIIIl1lI1l1ll1IlII = CreateObject("roByteArray")
_llIl1Il1I1l1llIIIl1lI1l1ll1IlII.FromHexString(_llIIIl111I111IIIlIlI1I1Il1lll1l11lIIlIllll1)
_llI1l11Il1lII1I1IIlII11IIIIlI1IIll1 = _llIl1Il1I1l1llIIIl1lI1l1ll1IlII.Count()
if _llI1l11Il1lII1I1IIlII11IIIIlI1IIll1 < 2 then return ""
_llIII1lll1Il1I1I1lI11IllIIl11Il = _llIl1Il1I1l1llIIIl1lI1l1ll1IlII[0]
_ll111l1llIIl11l1ll11llI1II11I11IlIl = (_llIII1lll1Il1I1I1lI11IllIIl11Il * 67 + 43) and 255
_lll11111IllI1I1IIlIIIII1lI1llll1I11I1I11IlI = (_llIII1lll1Il1I1I1lI11IllIIl11Il * 79 + 17) and 255
for _llllIIll1IlIll1II1l1llll1lI1lIIIIII = 1 to _llI1l11Il1lII1I1IIlII11IIIIlI1IIll1 - 1
_ll1lIlI1Ill11l111ll11Il1lll11l1 = (_llIl1Il1I1l1llIIIl1lI1l1ll1IlII[_llllIIll1IlIll1II1l1llll1lI1lIIIIII] - ((_llllIIll1IlIll1II1l1llll1lI1lIIIIII - 1) * 11 + _lll11111IllI1I1IIlIIIII1lI1llll1I11I1I11IlI)) and 255
_ll1lIlI1Ill11l111ll11Il1lll11l1 = ((((_ll1lIlI1Ill11l111ll11Il1lll11l1 \ 8) or ((_ll1lIlI1Ill11l111ll11Il1lll11l1 * 32) and 255)))) and 255
_llIl1Il1I1l1llIIIl1lI1l1ll1IlII[_llllIIll1IlIll1II1l1llll1lI1lIIIIII] = (_ll1lIlI1Ill11l111ll11Il1lll11l1 + _ll111l1llIIl11l1ll11llI1II11I11IlIl) - 2 * (_ll1lIlI1Ill11l111ll11Il1lll11l1 and _ll111l1llIIl11l1ll11llI1II11I11IlIl)
end for
return Mid(_llIl1Il1I1l1llIIIl1lI1l1ll1IlII.ToAsciiString(), 2)
end function
function _llIlIl1lll11IlllIIIl1I1lI11I1ll111I(_llIlIIIl1llllll111lI1IIl1II111I as String) as String
if _llIlIIIl1llllll111lI1IIl1II111I = "" then return ""
_lllI1Il11II11IlII1lI1I1l1IIIl1Illll = CreateObject("roByteArray")
_lllI1Il11II11IlII1lI1I1l1IIIl1Illll.FromHexString(_llIlIIIl1llllll111lI1IIl1II111I)
_llIIllIlIl1I1II1lI11l1lII1I1II1llI1II11IlI1 = _lllI1Il11II11IlII1lI1I1l1IIIl1Illll.Count()
if _llIIllIlIl1I1II1lI11l1lII1I1II1llI1II11IlI1 < 2 then return ""
_llllI1l1l111lll1I11I1lIIIlII1IIlllll1Il11lI = _lllI1Il11II11IlII1lI1I1l1IIIl1Illll[0]
_lll1lIIlIll11l1lIl11IIlll1l1I11IIIl1l1lI1lI = (_llllI1l1l111lll1I11I1lIIIlII1IIlllll1Il11lI * 109 + 47) and 255
_ll11IIIll1lll1II1IIl1IIl1l1l1Ill11Illl1IlIl = (_llllI1l1l111lll1I11I1lIIIlII1IIlllll1Il11lI * 113 + 71) and 255
for _llIlIlI11Il1IlIl11I1I11111llIlI = 1 to _llIIllIlIl1I1II1lI11l1lII1I1II1llI1II11IlI1 - 1
_llIIllll11I1IlI111II1lI1I1111II1I1l11IIl1II = _llIlIlI11Il1IlIl11I1I11111llIlI - 1
_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 = _lllI1Il11II11IlII1lI1I1l1IIIl1Illll[_llIlIlI11Il1IlIl11I1I11111llIlI]
_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 = (_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 + _ll11IIIll1lll1II1IIl1IIl1l1l1Ill11Illl1IlIl) - 2 * (_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 and _ll11IIIll1lll1II1IIl1IIl1l1l1Ill11Illl1IlIl)
_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 = (_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 + (_llIIllll11I1IlI111II1lI1I1111II1I1l11IIl1II * 7 + _llllI1l1l111lll1I11I1lIIIlII1IIlllll1Il11lI)) and 255
_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 = ((((_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 \ 16) or ((_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 * 16) and 255)))) and 255
_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 = (_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 - (_llIIllll11I1IlI111II1lI1I1111II1I1l11IIl1II * 3 + _ll11IIIll1lll1II1IIl1IIl1l1l1Ill11Illl1IlIl)) and 255
_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 = (_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 * 43) and 255
_lllI1Il11II11IlII1lI1I1l1IIIl1Illll[_llIlIlI11Il1IlIl11I1I11111llIlI] = (_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 + _lll1lIIlIll11l1lIl11IIlll1l1I11IIIl1l1lI1lI) - 2 * (_lll1Ill1I11l1l1llIIllIlI1IllIlI1lIlIII1 and _lll1lIIlIll11l1lIl11IIlll1l1I11IIIl1l1lI1lI)
end for
return Mid(_lllI1Il11II11IlII1lI1I1l1IIIl1Illll.ToAsciiString(), 2)
end function