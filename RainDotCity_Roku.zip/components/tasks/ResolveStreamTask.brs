sub init()
m.top.functionName = _l1d_3b1f7b("84728b82828f817a969f8d949b", 132, 142)
end sub
sub resolveStream()
_l1Ill1l = m.top.imdbId
_lIIll1l = m.top.kind
_lll1l1l = m.top.season
_llIll1l = m.top.episode
if _l1Ill1l = invalid or _l1Ill1l = "" then
m.top.result = { url: "", error: _l1d_3b1f7b("a7c6b3b6cfd9d391a8decee9e3a3cdcd", 145, 203) }
return
end if
_l1l1l1l = VSR_Resolve(_l1Ill1l, _lIIll1l, _lll1l1l, _llIll1l)
if _l1l1l1l <> invalid and _l1l1l1l.url <> invalid and _l1l1l1l.url <> "" then
m.top.result = _l1l1l1l
else
m.top.result = { url: "", error: _l1d_3b1f7b("c6dddae4efb6ebefebc2f305fa0105fe14da0d14240f2a2a232ff527272c3e453c", 30, 105) }
end if
end sub
function _l1d_3b1f7b(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function