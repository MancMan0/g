sub init()
m.top.functionName = _l1d_4555a4("07fd0d0a030519eb1b0c27", 82, 208)
end sub
sub executeTask()
_ll11l1l = m.top.playlistUrl
if _ll11l1l = invalid or _ll11l1l = "" then
_ll11l1l = M3U_GetSavedUrl()
end if
_lIl1l1l = ""
if Left(_ll11l1l, 4) = _l1d_4555a4("758d8c44", 147, 146) or Left(_ll11l1l, 4) = _l1d_4555a4("34203673", 200, 120) then
_lIl1l1l = ReadAsciiFile(_ll11l1l)
else
_l111l1l = CreateObject(_l1d_4555a4("eeeedbf7f8e300f6020a000612", 2, 126))
_l111l1l.SetUrl(_ll11l1l)
_l111l1l.SetCertificatesFile(_l1d_4555a4("ada4a9acadaf8676c5c6dadbe188d7dc93dff1d9e6e1eda5f50708", 14, 64))
_l111l1l.AddHeader(_l1d_4555a4("9ac3d0c89ebddedfebd4", 20, 89), _l1d_4555a4("a7c8d6ccd2d5dd1a371f382b26e4edf1fef8131246e3004f6365526b65611720247f847a76418e937b85364c474b38526e3c59776fa4baa9c2", 202, 32))
_l1l1l1l = CreateObject(_l1d_4555a4("5f7596716a6d7e7f809890807d", 53, 24))
_l111l1l.SetMessagePort(_l1l1l1l)
if _l111l1l.AsyncGetToString() then
_lIIll1l = wait(15000, _l1l1l1l)
if type(_lIIll1l) = _l1d_4555a4("a78d86b0957fb5a5a3bc", 205, 232) then
_llIll1l = _lIIll1l.GetResponseCode()
if _llIll1l = 200 then
_lIl1l1l = _lIIll1l.GetString()
end if
else
_l111l1l.AsyncCancel()
end if
end if
end if
if _lIl1l1l <> "" and Instr(1, _lIl1l1l, _l1d_4555a4("f1162e2d", 1, 207)) > 0 then
_lll1l1l = M3U_ParseContent(_lIl1l1l)
m.top.result = _lll1l1l
else
_l1Ill1l = _l1d_4555a4("cd364c4b47ec55", 34, 204) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("5b040a190105107771887a5152468342509c90444f6438667776a48267b1b68d8e82bf7f898893ded28691a6e07dabbcbbefa78cf6fbd2d3c704c6c8d3ce2317d4f3f6f5f731292ced31f3fa031814430b0a0f50fb6f1a7125007a67402d39777c4250405d5b8b654d6b5662ada1406e7f7eb0b1677287c15e8c9d9cd06b7a", 74, 242) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("ded5d8dfe39fadb0f2f8f202c0fe09fa0c140910d8261d1ee3292828ef2e392a3c44394057494f49591757185515", 189, 9) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("a34c4241595d58afc9b0c2797a8edb9a98d4d87bacaeb1b6aab4a0b802b0adff04bbbcd01dddd7e6e11c20c3f4f6f9fef2fce80040d7d8474c030418652729242f64683524272628728a8d4e92545b544945a45c6b70b19d5d56a648ab4fc8718e8ac8cd9381a18e8cec96ae9cb7b3eef2a1bfb0af0112a7d8dadde2d6e0cce424caf6f8eef402", 210, 178) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("e1c8cbd2d8223235f3f8fe01020200f8085212191a5f201b1d2d286f3231393f3739322e8c3b37404e555c4da44d56ac6e9f5caa", 84, 165) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("91325249474540bfafbeb2818274c18880dac86f8fa0958586e1adb2e6ebbabbadfabcbcc3be1907aeaebfb418c7c821d4f2e8f1f7f034390809fb480c0c0712675522292c33337f6d7039773f3e374c5289474e5394aea66cae5a63b7ad7e736db5ba768e849199cf9b99a19c96f1df91a4b1a8b2b0b1f9f6ffaec0c5d30c15b6b6c7bc20cfd029d4cb", 199, 173) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("aca3a6adb3edfd00c2bbc0060edcd9e2d9e8e3d7edef2ceff9eb39fdfcfe45050d051754525357555c5e5f6c0e1c1122791d161b81882e2d2f9657665b576b63aa6cad6aa8", 220, 248) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("00616f7666626d1c0e2d1f6e6f6320676d3935a87a7ca1937d80419fa4565baaab9f5c9caea5b07b77eabcbe85e6d8c2c59403049ba0eff0e4a1e3e5f0ebc0bcf910131a1cd6c6c912ce1817203539e030272ced630c560e155e2004654a561c215f755d7a8028827288737f4a46ba9e84a2a3a95b54d1a3a56ccdbfa9ac7beaeb", 46, 243) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("fb0a0d0c0c584e51190c1c1e62262432267028312e3d343f5141458e514d61995b6266a56b69776bb4c1c8c4ceccd1c9a18fb7aadab1c9e1a69daeb8aab8f7bb00c911", 99, 240) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("8a73696880847f96b097a9606175c2817fbbbfa97c78989a988988e6a497e3e89fa0b401c1bbcac50004eec1bddddfddcecd2109f1edf9f9e2fe373cf3f408551719141f54582514171618627a7d3e82444b443935944c5b60a185946b978d9b95b8617e7ab8bd8371917e7cdc869e8ca7a3dee2d1afa09ff102deb1adcdcfcdbebd11f9e1dde9e9d2ee291413", 114, 57) + chr(10)
_l1Ill1l = _l1Ill1l + _l1d_4555a4("6970737a804a3a3d768991898b859aa15691a4aca4a6a0b5bc71beb9c7bcb7839289c6cc93e3d4dbece9e5e1abf7f800f5ba0308c41007072210182521de20f12efc", 164, 157) + chr(10)
_lll1l1l = M3U_ParseContent(_l1Ill1l)
m.top.result = _lll1l1l
end if
end sub
function _l1d_4555a4(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function