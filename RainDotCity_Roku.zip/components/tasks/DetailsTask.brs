sub init()
m.top.functionName = _l1d_c3a6e1("b5b7b0b699bdafbfcad0b6", 18, 55)
end sub
sub loadDetails()
_llIll1l = m.top.imdbId
if _llIll1l = invalid or _llIll1l = "" then return
_l1Ill1l = VSC_FetchSeriesDetails(_llIll1l)
m.top.result = {
seasons: _l1Ill1l
}
end sub
function _l1d_c3a6e1(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function