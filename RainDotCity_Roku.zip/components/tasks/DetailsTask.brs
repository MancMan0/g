sub init()
m.top.functionName = _ll1lIIlllIII1IIIl1llllIlIIlII1l(_llIlII1IIl1ll11l111IIII11Il1lIlIIlIl1Il("5ca65da51aa874f037a1378737ce6ca23ce161b2cbea8fb9b1"))
end sub
sub loadDetails()
_ll1l1llIIIIll111ll1Ill11Illl1I1IIl1 = ((Rnd(0) * 0) + 7)
if ((((_ll1l1llIIIIll111ll1Ill11Illl1I1IIl1 * 8 + 5) * (_ll1l1llIIIIll111ll1Ill11Illl1I1IIl1 * 8 + 5)) mod 8) <> 1) then
_ll1I1I1llll11lI11llI1111IIllIll11l11IlI = CreateObject("roByteArray")
_ll1I1I1llll11lI11llI1111IIllIll11l11IlI.SetResize(64, false)
_llI1llII11IlII11ll1111IlI1Il1I11IIl1IIl1II1 = _ll1I1I1llll11lI11llI1111IIllIll11l11IlI.ToHexString()
end if
if not _ll1IlIIIl1IllI1lIIIIlIl1I1lllI111I() then
m.top.result = {}
return
end if
_llll1I11llIlll11lII11l11111IIIl = m.top.imdbId
if _llll1I11llIlll11lII11l11111IIIl = invalid or _llll1I11llIlll11lII11l11111IIIl = "" then return
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = _lllII1I1IllII1I1l1l1Il1lI1IlIlI(_llI11IllIlIIIlll11I1lllIlIlllII("59b2834f067daf70fbbb0aa646"))
if m.top.kind <> invalid and m.top.kind <> "" then _llI111lI11I1l11lI11l1lIlll11111lIIlI1II = m.top.kind
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = VSC_FetchTitleMeta(_llll1I11llIlll11lII11l11111IIIl, _llI111lI11I1l11lI11l1lIlll11111lIIlI1II)
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 <> invalid then
m.top.result = _lllIIlIlII1ll111l1Il11Illlll11l11I1
else
m.top.result = {}
end if
end sub
function _ll1lIIlllIII1IIIl1llllIlIIlII1l(_ll1ll11l1I11Il11lll1Il1IIIlllIIIl1l1lllIIII as String) as String
if _ll1ll11l1I11Il11lll1Il1IIIlllIIIl1l1lllIIII = "" then return ""
_lllIl1II1I1lIIllIlll11lIII11l1lIll1 = CreateObject("roByteArray")
_lllIl1II1I1lIIllIlll11lIII11l1lIll1.FromHexString(_ll1ll11l1I11Il11lll1Il1IIIlllIIIl1l1lllIIII)
_ll1I11lllIlIIl1l1lllIl1Ill1I1lIllIlIl11 = _lllIl1II1I1lIIllIlll11lIII11l1lIll1.Count()
if _ll1I11lllIlIIl1l1lllIl1Ill1I1lIllIlIl11 < 2 then return ""
_llI1I11I11I11IIl1IIl1ll1I1lIIlll1lIl1l1I1II = _lllIl1II1I1lIIllIlll11lIII11l1lIll1[0]
_ll1lIII11l11IIllII1lllll1llIlIIlIll = (_llI1I11I11I11IIl1IIl1ll1I1lIIlll1lIl1l1I1II * 37 + 11) and 255
_llI1II111lIlllll1lI1lIlIlll1lll = (_llI1I11I11I11IIl1IIl1ll1I1lIIlll1lIl1l1I1II * 59 + 23) and 255
for _llI11Il11IlI1I1lIl11IlI11ll1IIlI11l = 1 to _ll1I11lllIlIIl1l1lllIl1Ill1I1lIllIlIl11 - 1
_ll11lI1l1Ill11l1II1l1I1lIII1II1IlIll11IllIl = (_lllIl1II1I1lIIllIlll11lIII11l1lIll1[_llI11Il11IlI1I1lIl11IlI11ll1IIlI11l] - ((_llI11Il11IlI1I1lIl11IlI11ll1IIlI11l - 1) * 3 + _llI1II111lIlllll1lI1lIlIlll1lll)) and 255
_lllIl1II1I1lIIllIlll11lIII11l1lIll1[_llI11Il11IlI1I1lIl11IlI11ll1IIlI11l] = (_ll11lI1l1Ill11l1II1l1I1lIII1II1IlIll11IllIl + _ll1lIII11l11IIllII1lllll1llIlIIlIll) - 2 * (_ll11lI1l1Ill11l1II1l1I1lIII1II1IlIll11IllIl and _ll1lIII11l11IIllII1lllll1llIlIIlIll)
end for
return Mid(_lllIl1II1I1lIIllIlll11lIII11l1lIll1.ToAsciiString(), 2)
end function
function _llIlII1IIl1ll11l111IIII11Il1lIlIIlIl1Il(_ll11IlI1lIlIllII1IIlI1ll1ll11I1IlIl as String) as String
if _ll11IlI1lIlIllII1IIlI1ll1ll11I1IlIl = "" then return ""
_lllIl1I1IlI111lI1l1II1Il1llIII1II1I = CreateObject("roByteArray")
_lllIl1I1IlI111lI1l1II1Il1llIII1II1I.FromHexString(_ll11IlI1lIlIllII1IIlI1ll1ll11I1IlIl)
_lllllIIIIIl111l1I11111I1llllIlIlllI = _lllIl1I1IlI111lI1l1II1Il1llIII1II1I.Count()
if _lllllIIIIIl111l1I11111I1llllIlIlllI < 2 then return ""
_ll11lIIll1I1I11I1l1lll1l1lll1lI1llI = _lllIl1I1IlI111lI1l1II1Il1llIII1II1I[0]
_llI1IIl1lll111ll1lIl1lll1Il1lIllIIlII1Ill1I = (_ll11lIIll1I1I11I1l1lll1l1lll1lI1llI * 41 + 19) and 255
_llI1I1l1IlIll1I11llI1lIIlIl1llI = _ll11lIIll1I1I11I1l1lll1l1lll1lI1llI
for _llIllIl111II111lII1l11lI1l1lll1ll11 = 1 to _lllllIIIIIl111l1I11111I1llllIlIlllI - 1
_ll1lII1I1l1lIll1l1l11IIlI11I1I11II1l11IIlll = _lllIl1I1IlI111lI1l1II1Il1llIII1II1I[_llIllIl111II111lII1l11lI1l1lll1ll11]
_lllII11I1lII1lIIlI1II1II11I1111I11IIlII1l1I = ((_llIllIl111II111lII1l11lI1l1lll1ll11 - 1) * 7) and 255
_llllI1I11II1III1lI1I1l1IlllIllII11l11lI = (_ll1lII1I1l1lIll1l1l11IIlI11I1I11II1l11IIlll + _llI1I1l1IlIll1I11llI1lIIlIl1llI) - 2 * (_ll1lII1I1l1lIll1l1l11IIlI11I1I11II1l11IIlll and _llI1I1l1IlIll1I11llI1lIIlIl1llI)
_llllI1I11II1III1lI1I1l1IlllIllII11l11lI = (_llllI1I11II1III1lI1I1l1IlllIllII11l11lI + _llI1IIl1lll111ll1lIl1lll1Il1lIllIIlII1Ill1I) - 2 * (_llllI1I11II1III1lI1I1l1IlllIllII11l11lI and _llI1IIl1lll111ll1lIl1lll1Il1lIllIIlII1Ill1I)
_llllI1I11II1III1lI1I1l1IlllIllII11l11lI = (_llllI1I11II1III1lI1I1l1IlllIllII11l11lI + _lllII11I1lII1lIIlI1II1II11I1111I11IIlII1l1I) - 2 * (_llllI1I11II1III1lI1I1l1IlllIllII11l11lI and _lllII11I1lII1lIIlI1II1II11I1111I11IIlII1l1I)
_lllIl1I1IlI111lI1l1II1Il1llIII1II1I[_llIllIl111II111lII1l11lI1l1lll1ll11] = _llllI1I11II1III1lI1I1l1IlllIllII11l11lI and 255
_llI1I1l1IlIll1I11llI1lIIlIl1llI = _ll1lII1I1l1lIll1l1l11IIlI11I1I11II1l11IIlll
end for
return Mid(_lllIl1I1IlI111lI1l1II1Il1llIII1II1I.ToAsciiString(), 2)
end function
function _llI11IllIlIIIlll11I1lllIlIlllII(_llIl1IlIllllIl11lIIllI1I1IIlI1llI11 as String) as String
if _llIl1IlIllllIl11lIIllI1I1IIlI1llI11 = "" then return ""
_llIIl1lIlIlllII1I1lllII111lIlII1Il1l1Il = CreateObject("roByteArray")
_llIIl1lIlIlllII1I1lllII111lIlII1Il1l1Il.FromHexString(_llIl1IlIllllIl11lIIllI1I1IIlI1llI11)
_ll11l111l1I1lIlIl1lIl11I1111IIII11llIllIII1 = _llIIl1lIlIlllII1I1lllII111lIlII1Il1l1Il.Count()
if _ll11l111l1I1lIlIl1lIl11I1111IIII11llIllIII1 < 2 then return ""
_lllllll111IIlll1ll1lI1111lIl1l1 = _llIIl1lIlIlllII1I1lllII111lIlII1Il1l1Il[0]
_ll1llllllII111lIl11lIIIll1III11 = (_lllllll111IIlll1ll1lI1111lIl1l1 * 97 + 53) and 255
_ll1IlII1ll1l1lI1I1IlIII11IIlllll1lIIllI11ll = (_lllllll111IIlll1ll1lI1111lIl1l1 * 103 + 61) and 255
for _lllIlIl1Il1lI1lII1II1lIIl11llIIIII1lIIIIII1 = 1 to _ll11l111l1I1lIlIl1lIl11I1111IIII11llIllIII1 - 1
_lll11Ill1llIlllIII1I1II111II1ll = _lllIlIl1Il1lI1lII1II1lIIl11llIIIII1lIIIIII1 - 1
_llIlI1IlIlllI1l1IllIll1lIlIIlIl = _llIIl1lIlIlllII1I1lllII111lIlII1Il1l1Il[_lllIlIl1Il1lI1lII1II1lIIl11llIIIII1lIIIIII1]
_llIl1I1l1I1lIIIll1l1ll1llllI1ll1lII1IlI = (_lll11Ill1llIlllIII1I1II111II1ll * 19 + _lllllll111IIlll1ll1lI1111lIl1l1) and 255
_llIlI1IlIlllI1l1IllIll1lIlIIlIl = (_llIlI1IlIlllI1l1IllIll1lIlIIlIl + _llIl1I1l1I1lIIIll1l1ll1llllI1ll1lII1IlI) - 2 * (_llIlI1IlIlllI1l1IllIll1lIlIIlIl and _llIl1I1l1I1lIIIll1l1ll1llllI1ll1lII1IlI)
_llIlI1IlIlllI1l1IllIll1lIlIIlIl = ((((_llIlI1IlIlllI1l1IllIll1lIlIIlIl \ 4) or ((_llIlI1IlIlllI1l1IllIll1lIlIIlIl * 64) and 255)))) and 255
_llIlI1IlIlllI1l1IllIll1lIlIIlIl = (_llIlI1IlIlllI1l1IllIll1lIlIIlIl - (_lll11Ill1llIlllIII1I1II111II1ll * 17 + _ll1IlII1ll1l1lI1I1IlIII11IIlllll1lIIllI11ll)) and 255
_llIlI1IlIlllI1l1IllIll1lIlIIlIl = ((((_llIlI1IlIlllI1l1IllIll1lIlIIlIl \ 8) or ((_llIlI1IlIlllI1l1IllIll1lIlIIlIl * 32) and 255)))) and 255
_llIIl1lIlIlllII1I1lllII111lIlII1Il1l1Il[_lllIlIl1Il1lI1lII1II1lIIl11llIIIII1lIIIIII1] = (_llIlI1IlIlllI1l1IllIll1lIlIIlIl + _ll1llllllII111lIl11lIIIll1III11) - 2 * (_llIlI1IlIlllI1l1IllIll1lIlIIlIl and _ll1llllllII111lIl11lIIIll1III11)
end for
return Mid(_llIIl1lIlIlllII1I1lllII111lIlII1Il1l1Il.ToAsciiString(), 2)
end function
function _lllII1I1IllII1I1l1l1Il1lI1IlIlI(_lllIl1l1I1l1llI1I11lIllI1I1Il1IIllI1lll as String) as String
if _lllIl1l1I1l1llI1I11lIllI1I1Il1IIllI1lll = "" then return ""
_ll1l11llI1ll111IIl1ll1lIIIIII1l11I111l11111 = CreateObject("roByteArray")
_ll1l11llI1ll111IIl1ll1lIIIIII1l11I111l11111.FromHexString(_lllIl1l1I1l1llI1I11lIllI1I1Il1IIllI1lll)
_ll1II1lIl1lllIllll11llIII1III1l = _ll1l11llI1ll111IIl1ll1lIIIIII1l11I111l11111.Count()
if _ll1II1lIl1lllIllll11llIII1III1l < 2 then return ""
_lllI11ll1l1IlIlIlI1lllll1111l1IIllllII1 = _ll1l11llI1ll111IIl1ll1lIIIIII1l11I111l11111[0]
_lll1lIIIIll1I1Il1llI111II11II1I1ll1 = (_lllI11ll1l1IlIlIlI1lllll1111l1IIllllII1 * 109 + 47) and 255
_ll111IlIl1lIl1IIlllIlI1Ill1llIIl1ll = (_lllI11ll1l1IlIlIlI1lllll1111l1IIllllII1 * 113 + 71) and 255
for _llI1II1l111IlIlI1Il11IllIII11II1l1I = 1 to _ll1II1lIl1lllIllll11llIII1III1l - 1
_llIlIII1lI1Ill11lIl111llIllIII11II1llIl = _llI1II1l111IlIlI1Il11IllIII11II1l1I - 1
_ll11IlIl1lI1IIIII1l1llIIl111lllIIII = _ll1l11llI1ll111IIl1ll1lIIIIII1l11I111l11111[_llI1II1l111IlIlI1Il11IllIII11II1l1I]
_ll11IlIl1lI1IIIII1l1llIIl111lllIIII = (_ll11IlIl1lI1IIIII1l1llIIl111lllIIII + _ll111IlIl1lIl1IIlllIlI1Ill1llIIl1ll) - 2 * (_ll11IlIl1lI1IIIII1l1llIIl111lllIIII and _ll111IlIl1lIl1IIlllIlI1Ill1llIIl1ll)
_ll11IlIl1lI1IIIII1l1llIIl111lllIIII = (_ll11IlIl1lI1IIIII1l1llIIl111lllIIII + (_llIlIII1lI1Ill11lIl111llIllIII11II1llIl * 7 + _lllI11ll1l1IlIlIlI1lllll1111l1IIllllII1)) and 255
_ll11IlIl1lI1IIIII1l1llIIl111lllIIII = ((((_ll11IlIl1lI1IIIII1l1llIIl111lllIIII \ 16) or ((_ll11IlIl1lI1IIIII1l1llIIl111lllIIII * 16) and 255)))) and 255
_ll11IlIl1lI1IIIII1l1llIIl111lllIIII = (_ll11IlIl1lI1IIIII1l1llIIl111lllIIII - (_llIlIII1lI1Ill11lIl111llIllIII11II1llIl * 3 + _ll111IlIl1lIl1IIlllIlI1Ill1llIIl1ll)) and 255
_ll11IlIl1lI1IIIII1l1llIIl111lllIIII = (_ll11IlIl1lI1IIIII1l1llIIl111lllIIII * 43) and 255
_ll1l11llI1ll111IIl1ll1lIIIIII1l11I111l11111[_llI1II1l111IlIlI1Il11IllIII11II1l1I] = (_ll11IlIl1lI1IIIII1l1llIIl111lllIIII + _lll1lIIIIll1I1Il1llI111II11II1I1ll1) - 2 * (_ll11IlIl1lI1IIIII1l1llIIl111lllIIII and _lll1lIIIIll1I1Il1llI111II11II1I1ll1)
end for
return Mid(_ll1l11llI1ll111IIl1ll1lIIIIII1l11I111l11111.ToAsciiString(), 2)
end function