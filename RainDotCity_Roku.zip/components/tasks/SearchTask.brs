sub init()
if ((19158 - 6386 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.top.functionName = _l1d_54710c("d6e413e0e7fbeff7", 228, 86)
end sub
sub doSearch()
_l1l1l1l = m.top.query
_lIl1l1l = CreateObject(_l1d_54710c("869c6b7a86a8a2a4", 85, 95), _l1d_54710c("335a5c695d65724b6f6b6f", 6, 238))
if _l1l1l1l = invalid or _l1l1l1l = "" then
m.top.result = _lIl1l1l
return
end if
_lIIll1l = VSC_Search(_l1l1l1l)
for each _llIll1l in _lIIll1l
_l1Ill1l = _lIl1l1l.createChild(_l1d_54710c("e91012fb0f1b0401251d21", 84, 210))
_l1Ill1l.id = _llIll1l.id
_l1Ill1l.title = _llIll1l.title
_l1Ill1l.HDPosterUrl = _llIll1l.poster
_l1Ill1l.HDBackgroundImageUrl = _llIll1l.backdrop
_l1Ill1l.description = _llIll1l.description
_l1Ill1l.ReleaseDate = _llIll1l.year
if _llIll1l.rating <> invalid and _llIll1l.rating <> "" then
_l1Ill1l.Rating = _llIll1l.rating.ToStr()
end if
_lll1l1l = _l1d_54710c("191a36262d", 207, 119)
if _llIll1l.kind <> invalid and (_llIll1l.kind = _l1d_54710c("f2f3", 250, 100) or _llIll1l.kind = _l1d_54710c("707d778f867f", 85, 74)) then _lll1l1l = _l1d_54710c("fb00", 4, 139)
_l1Ill1l.addField(_l1d_54710c("abb0aca9", 150, 174), _l1d_54710c("8c8c91afaba7", 214, 231), false)
_l1Ill1l.kind = _lll1l1l
if _lll1l1l = _l1d_54710c("a8ad", 137, 171) then
_l1Ill1l.ContentType = 2
else
_l1Ill1l.ContentType = 1
end if
if _llIll1l.genres <> invalid then
_l1Ill1l.Categories = _llIll1l.genres
end if
end for
m.top.result = _lIl1l1l
end sub
function _l1d_54710c(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function