sub init()
m.top.functionName = _l1d_04d6a4("c3c7bcc4e4c5bdcbdbdfda", 49, 102)
end sub
sub loadCatalog()
if ((7662 - 1277 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_ll11l1l = m.top.category
_llI111l = CreateObject(_l1d_04d6a4("141c3b4a44283034", 60, 198), _l1d_04d6a4("a3caccd5c9d5debbdfd7db", 132, 220))
_lII111l = []
if _ll11l1l = _l1d_04d6a4("212b2c27", 224, 153) then
_lII1l1l = W_ListInProgress(20)
if _lII1l1l <> invalid and _lII1l1l.Count() > 0 then
_ll1111l = []
for each _l1Il11l in _lII1l1l
if _l1Il11l.title = invalid or _l1Il11l.title = "" or Left(_l1Il11l.title, 2) = _l1d_04d6a4("c6c9", 110, 172) or _l1Il11l.poster = invalid or _l1Il11l.poster = "" then
_lIIl11l = VSC_FetchTitleMeta(_l1Il11l.itemKey, _l1Il11l.kind)
if _lIIl11l <> invalid then
if _lIIl11l.title <> invalid and _lIIl11l.title <> "" then _l1Il11l.title = _lIIl11l.title
if _lIIl11l.poster <> invalid and _lIIl11l.poster <> "" then _l1Il11l.poster = _lIIl11l.poster
if _lIIl11l.backdrop <> invalid and _lIIl11l.backdrop <> "" then _l1Il11l.backdrop = _lIIl11l.backdrop
W_RememberContext(_l1Il11l.itemKey, {
title:    _l1Il11l.title,
poster:   _l1Il11l.poster,
backdrop: _l1Il11l.backdrop,
kind:     _l1Il11l.kind,
imdb:     _l1Il11l.itemKey,
year:     _lIIl11l.year,
rating:   _lIIl11l.rating
})
end if
end if
if (_l1Il11l.poster = invalid or _l1Il11l.poster = "") and Left(_l1Il11l.itemKey, 2) = _l1d_04d6a4("9598", 24, 41) then
_l1Il11l.poster = _l1d_04d6a4("e3dadde4e4a0aeb1faf908050affc70b160a201c1228df1d23353637f032363537493f05444d5c545717", 191, 12) + _l1Il11l.itemKey + _l1d_04d6a4("ffc0c7c0", 227, 51)
end if
if _l1Il11l.backdrop = invalid or _l1Il11l.backdrop = "" then _l1Il11l.backdrop = _l1Il11l.poster
_ll1111l.Push(_l1Il11l)
end for
if _ll1111l.Count() > 0 then
_lII111l.Push({ title: _l1d_04d6a4("91b0b2abb3bbb5c886a0cdc3d5cdd1d9e5", 24, 54), items: _ll1111l })
end if
end if
end if
if _ll11l1l = _l1d_04d6a4("b2b2b3ae", 37, 101) then
_l1ll11l = VSC_FetchHomeRows()
if _l1ll11l <> invalid then
for each _l11l11l in _l1ll11l
_lII111l.Push(_l11l11l)
end for
end if
else if _ll11l1l = _l1d_04d6a4("f2f3fdf7f603", 162, 35) then
_llII11l = VSC_FetchTrendingMovies()
if _llII11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("8a6b616d666e76722e9e838d838293", 160, 150), items: _llII11l })
_lllI11l = VSC_FetchByGenre(_l1d_04d6a4("4a4f59574e", 164, 129), _l1d_04d6a4("455865a43e6e", 71, 49))
if _lllI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("e4d7d413fbdd27ffe0daecf3e8", 254, 55), items: _lllI11l })
_llIll1l = VSC_FetchByGenre(_l1d_04d6a4("2829432d3c", 42, 225), _l1d_04d6a4("5d42384e575b", 241, 173))
if _llIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("4f344830393b8060455f455465", 104, 38), items: _llIll1l })
_l111l1l = VSC_FetchByGenre(_l1d_04d6a4("bbc0aac0bf", 208, 254), _l1d_04d6a4("d3b2b3bec0a8", 56, 88))
if _l111l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("fc2b2c272b21ed1b402c403f30", 17, 170), items: _l111l1l })
_lIll11l = VSC_FetchByGenre(_l1d_04d6a4("e9eaf4f6ed", 70, 190), _l1d_04d6a4("b092b0b39bb9", 44, 76))
if _lIll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("082424272d2d82183935454c41", 95, 241), items: _lIll11l })
else if _ll11l1l = _l1d_04d6a4("a8b5afc7beb7", 21, 66) or _ll11l1l = _l1d_04d6a4("a4a5", 219, 245) then
_l1II11l = VSC_FetchTrendingSeries()
if _l1II11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("cbf3f1effb09ffd0dfe4d9ed17171219", 157, 254), items: _l1II11l })
_l1Ill1l = VSC_FetchByGenre(_l1d_04d6a4("e8e1eddbeaf7", 10, 111), _l1d_04d6a4("6a4f5d5b5c60", 37, 6))
if _l1Ill1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("d9fe0c0a0b0fcc000d271f162f", 133, 21), items: _l1Ill1l })
_l1lI11l = VSC_FetchByGenre(_l1d_04d6a4("624f67515871", 76, 35), _l1d_04d6a4("1326337a123c", 194, 130))
if _l1lI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("2e616e354d773136375c7e8a778778854f619a86a4a390", 18, 237), items: _l1lI11l })
_lI11l1l = VSC_FetchByGenre(_l1d_04d6a4("768f7d999885", 179, 182), _l1d_04d6a4("86a5a6b1b3bb", 8, 59))
if _lI11l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("8fa6abb6bac804b4c5dbc7cee3", 207, 3), items: _lI11l1l })
else if _ll11l1l = _l1d_04d6a4("1f243820292b", 8, 182) then
_llIll1l = VSC_FetchByGenre(_l1d_04d6a4("3536203a39", 146, 54), _l1d_04d6a4("012634222327", 13, 181))
if _llIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("dec3b1cfd0d411f7dcc8e4dbd4", 117, 170), items: _llIll1l })
_l1Ill1l = VSC_FetchByGenre(_l1d_04d6a4("1a2b212d3429", 63, 206), _l1d_04d6a4("51728c72777b", 139, 135))
if _l1Ill1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("1e3f4f4f4c4e0f3e3f184a66646f76", 6, 215), items: _l1Ill1l })
else if _ll11l1l = _l1d_04d6a4("b3c6cfc7d5", 116, 172) then
_lllI11l = VSC_FetchByGenre(_l1d_04d6a4("c5c6c0cad9", 122, 174), _l1d_04d6a4("695c551c8a5e", 185, 127))
if _lllI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("2f020b523014503e232f232233", 97, 253), items: _lllI11l })
_l1lI11l = VSC_FetchByGenre(_l1d_04d6a4("cabbcfbdc4d9", 174, 237), _l1d_04d6a4("03160f560218", 72, 232))
if _l1lI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("5c2f3c835b457f7677887a565c6766", 98, 43), items: _l1lI11l })
else if _ll11l1l = _l1d_04d6a4("13222722241c", 242, 130) then
_l111l1l = VSC_FetchByGenre(_l1d_04d6a4("3a3f593f4e", 200, 149), _l1d_04d6a4("bee5e6e1e503", 133, 248))
if _l111l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("5130313c404602604561455465", 41, 231), items: _l111l1l })
_lI11l1l = VSC_FetchByGenre(_l1d_04d6a4("e6ffeb0908f5", 18, 133), _l1d_04d6a4("ab8a8f9a9ea4", 43, 67))
if _lI11l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("1d3c3d484a320c2328152b535d5857", 152, 66), items: _lI11l1l })
else if _ll11l1l = _l1d_04d6a4("747060637969", 247, 213) then
_lIll11l = VSC_FetchByGenre(_l1d_04d6a4("aeb3afbbc2", 157, 190), _l1d_04d6a4("b1d7dde0e0e6", 194, 39))
if _lIll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("a3876f729078cdbb9c88a09f8c", 115, 104), items: _lIll11l })
_ll1l11l = VSC_FetchByGenre(_l1d_04d6a4("4a5f51596859", 153, 96), _l1d_04d6a4("d6b2b2b5bbbb", 127, 159))
if _ll1l11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("ffe7dfe2f0e8b91015c21600080302", 57, 142), items: _ll1l11l })
else if _ll11l1l = _l1d_04d6a4("453b434251614f4c50", 79, 23) then
_lIIll1l = VSC_FetchByGenre(_l1d_04d6a4("0203ed0f06", 246, 103), _l1d_04d6a4("61777f7e8d9d8b888c", 79, 83))
if _lIIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("280c1615142216185f472832342b40", 102, 1), items: _lIIll1l })
_lll1l1l = VSC_FetchByGenre(_l1d_04d6a4("261b2b152435", 72, 235), _l1d_04d6a4("3258605f5e4e6c696d", 23, 220))
if _lll1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("6f959d9c97dfdce587adb5b4b3c3b5b900b0c1d7d3cadf", 199, 233), items: _lll1l1l })
else if _ll11l1l = _l1d_04d6a4("afa4b8afbe", 95, 116) then
_lIlIl1l = VSC_FetchByGenre(_l1d_04d6a4("979ca8a49b", 229, 15), _l1d_04d6a4("edbaceddd4", 243, 54))
if _lIlIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("0bf8ecfbf236240511090815", 227, 100), items: _lIlIl1l })
_ll1Il1l = VSC_FetchByGenre(_l1d_04d6a4("321f37212841", 76, 243), _l1d_04d6a4("764359585f", 186, 120))
if _ll1Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("394a5a5960243b402d416b736e6d", 25, 220), items: _ll1Il1l })
else if _ll11l1l = _l1d_04d6a4("877b878691", 159, 139) then
_llI1l1l = VSC_FetchByGenre(_l1d_04d6a4("5b604c605f", 209, 159), _l1d_04d6a4("f327131a25", 203, 107))
if _llI1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("415371706b312e375f766f6f8377854f779882a49b90", 150, 108), items: _llI1l1l })
_l1I1l1l = VSC_FetchByGenre(_l1d_04d6a4("9ba8a0aab1aa", 28, 44), _l1d_04d6a4("5426303742", 184, 89))
if _l1I1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("798da5a49f67686d93aaa7a5b7b1b98594998ea2dcdcc7ce", 149, 163), items: _l1I1l1l })
else if _ll11l1l = _l1d_04d6a4("8581839c8a9f98", 9, 22) then
_llIIl1l = VSC_FetchByGenre(_l1d_04d6a4("6768826c7b", 170, 160), _l1d_04d6a4("88b0b6c3b9cad7", 7, 71))
if _llIIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("01e1dfdceadbd8b412f3eff706f3", 59, 132), items: _llIIl1l })
_l1IIl1l = VSC_FetchByGenre(_l1d_04d6a4("cfc0d6c2c9de", 111, 179), _l1d_04d6a4("7856666f5f747d", 160, 146))
if _l1IIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("ac969a879f909de7b6b7f0c2bebca7ae", 246, 252), items: _l1IIl1l })
else if _ll11l1l = _l1d_04d6a4("f1f20212", 9, 143) or _ll11l1l = _l1d_04d6a4("e5efe6edeb03", 78, 189) then
_l11Il1l = VSC_FetchByGenre(_l1d_04d6a4("7f806c8c83", 55, 37), _l1d_04d6a4("5a3e353c3c52", 173, 111))
if _l11Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("9ebfcfdf919a97c0dcdbdae2f0accaef0beffe0f", 9, 92), items: _l11Il1l })
_lIIll1l = VSC_FetchByGenre(_l1d_04d6a4("9499b3a1a8", 76, 115), _l1d_04d6a4("8db5bbbab9a7c7c8ca", 84, 120))
if _lIIll1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("7951575665736769b094728779758e929a88a1", 108, 76), items: _lIIll1l })
_lI1Il1l = VSC_FetchByGenre(_l1d_04d6a4("20392543422f", 146, 63), _l1d_04d6a4("6a8695949caa", 193, 227))
if _lI1Il1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("927379734392974ca28f87919891", 188, 155), items: _lI1Il1l })
_lll1l1l = VSC_FetchByGenre(_l1d_04d6a4("89828e7c8b98", 138, 144), _l1d_04d6a4("98c0c6c5c4d2d2d3d5", 68, 147))
if _lll1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("8a6f818a7275798f454a4bad8b8b9299b1a3a766d6a4a8c3c2", 171, 162), items: _lll1l1l })
else if _ll11l1l = _l1d_04d6a4("13321f37373a342e", 85, 242) then
_l11I11l = VSC_FetchByGenre(_l1d_04d6a4("e4e5cff1e8", 214, 41), _l1d_04d6a4("31001d070508142c", 236, 121))
if _l11I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("683f48464c4f4b570c1112846d6a6e666e766f2d9d7e8882818e", 34, 242), items: _l11I11l })
_lI1I11l = VSC_FetchByGenre(_l1d_04d6a4("0d22142c2b1c", 81, 235), _l1d_04d6a4("c8d7f4dedcdfeb03", 204, 48))
if _lI1I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("a6cfccd2c8d2d8d191c1dae8e4e3f0", 3, 86), items: _lI1I11l })
else if _ll11l1l = _l1d_04d6a4("9b9b9c93a39ba0", 192, 233) then
_l11111l = VSC_FetchByGenre(_l1d_04d6a4("e9eae4eefd", 58, 146), _l1d_04d6a4("859ba09fa5a3a4", 71, 112))
if _l11111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("352b2c2b35333078797e654935458d735844605750", 117, 14), items: _l11111l })
_lI1111l = VSC_FetchByGenre(_l1d_04d6a4("726379656c81", 15, 246), _l1d_04d6a4("9583848b8d9398", 185, 170))
if _lI1111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("f008090810191916560c19312b223b", 196, 90), items: _lI1111l })
else if _ll11l1l = _l1d_04d6a4("8c9a99a6a19ca8b1a9bdc7", 68, 108) then
_lllIl1l = VSC_FetchByGenre(_l1d_04d6a4("e3e4fee8f7", 106, 220), _l1d_04d6a4("1c08ff140f0a18210f252d", 97, 247))
if _lllIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("f20a110a15201a17251713ef1438372f312f4734", 155, 19), items: _lllIl1l })
_l1lIl1l = VSC_FetchByGenre(_l1d_04d6a4("f708fc1a1106", 182, 50), _l1d_04d6a4("bce4dbf4efeaf401ef010d", 195, 53))
if _l1lIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("e6c2c9bebfd4c6ceddce", 57, 105), items: _l1lIl1l })
else if _ll11l1l = _l1d_04d6a4("484c35354f3d4b", 182, 106) then
_lIIIl1l = VSC_FetchByGenre(_l1d_04d6a4("676c766c6b", 160, 154), _l1d_04d6a4("fddfd8e2eae2de", 187, 10))
if _lIIIl1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("9175928e7c9a8491928857585dcfa4b869c9bfabb8cb", 172, 173), items: _lIIIl1l })
_llll11l = VSC_FetchByGenre(_l1d_04d6a4("9b94a09e9daa", 98, 138), _l1d_04d6a4("a4c6d3d9d5dde5", 129, 219))
if _llll11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("0d2f484a32524e0a3a4b614d5469", 143, 70), items: _llll11l })
else if _ll11l1l = _l1d_04d6a4("0711120d2315272236", 36, 193) then
_l1l1l1l = VSC_FetchByGenre(_l1d_04d6a4("0c112b1920", 140, 43), _l1d_04d6a4("edc7d0dbe9dbedd8ec", 104, 195))
if _l1l1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("7088919c8c9c909b9daaabab7290b5b1b5c4b5", 25, 21), items: _l1l1l1l })
_lIl1l1l = VSC_FetchByGenre(_l1d_04d6a4("c7c0cebac9d6", 75, 143), _l1d_04d6a4("253f48536153655064", 200, 155))
if _lIl1l1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("629095907e9486a1a59ea3b1687ab39fbdbca9", 146, 146), items: _lIl1l1l })
else if _ll11l1l = _l1d_04d6a4("9ca0bea4ad", 146, 187) then
_lIlI11l = VSC_FetchByGenre(_l1d_04d6a4("10112b1524", 202, 105), _l1d_04d6a4("0f2f493734", 212, 136))
if _lIlI11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("52787c7c7d81576d8e8a9aa196", 31, 6), items: _lIlI11l })
_ll1I11l = VSC_FetchByGenre(_l1d_04d6a4("3c2d412f364b", 174, 95), _l1d_04d6a4("e60a000e0f", 134, 17))
if _ll1I11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("0c2e4636333b8d2c5857445f5a6851675d756c65b7b8bd518b8b767d", 85, 6), items: _ll1I11l })
else if _ll11l1l = _l1d_04d6a4("798a837f938b92", 60, 46) then
_lIII11l = VSC_FetchByGenre(_l1d_04d6a4("6166626675", 121, 77), _l1d_04d6a4("657a878f838f7e", 74, 72))
if _lIII11l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("cfa0b9b7a9c3ba77ddc2cecac1da", 165, 221), items: _lIII11l })
_llllI1l = VSC_FetchByGenre(_l1d_04d6a4("cbd8d0eae1da", 212, 36), _l1d_04d6a4("5586777d8f81a0", 145, 143))
if _llllI1l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("1348353f513f5e9727604e6a6956", 83, 15), items: _llllI1l })
else if _ll11l1l = _l1d_04d6a4("1711101e1e2c34", 226, 135) then
_lIl111l = VSC_FetchByGenre(_l1d_04d6a4("7a93818d9c89", 187, 178), _l1d_04d6a4("705c635b615957268287", 189, 129))
if _lIl111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("b9b3b2b0b0aea680d7d889dbc7cdc8c7", 186, 209), items: _lIl111l })
_l1l111l = VSC_FetchByGenre(_l1d_04d6a4("8889a5959c", 111, 134), _l1d_04d6a4("5e7c8b98838e8aa39bafa9", 12, 22))
if _l1l111l.Count() > 0 then _lII111l.Push({ title: _l1d_04d6a4("835756669d8c6a6c6caca086828a828192", 97, 80), items: _l1l111l })
end if
for each _lll111l in _lII111l
_l1I111l = _llI111l.createChild(_l1d_04d6a4("86b5b7a0b4c0a9a6cac2c6", 80, 115))
_l1I111l.title = _lll111l.title
for each _lI1l11l in _lll111l.items
_llIl11l = _l1I111l.createChild(_l1d_04d6a4("06dde1def0eae710f20002", 191, 10))
populateItemNode(_llIl11l, _lI1l11l)
end for
end for
m.top.result = _llI111l
end sub
sub populateItemNode(_l1II11l as Object, _lI1I11l as Object)
_l1II11l.id = _lI1I11l.id
if _l1II11l.id = invalid or _l1II11l.id = "" then
if _lI1I11l.itemKey <> invalid then _l1II11l.id = _lI1I11l.itemKey
end if
_l1II11l.title = _lI1I11l.title
_l1II11l.HDPosterUrl = _lI1I11l.poster
_l1II11l.HDBackgroundImageUrl = _lI1I11l.backdrop
if _l1II11l.HDBackgroundImageUrl = invalid or _l1II11l.HDBackgroundImageUrl = "" then
_l1II11l.HDBackgroundImageUrl = _lI1I11l.poster
end if
_l1II11l.description = _lI1I11l.description
_l1II11l.ReleaseDate = _lI1I11l.year
if _lI1I11l.rating <> invalid and _lI1I11l.rating <> "" then
_l1II11l.Rating = _lI1I11l.rating.ToStr()
end if
_llII11l = _l1d_04d6a4("d5d6e0dad9", 34, 134)
if _lI1I11l.kind <> invalid and (_lI1I11l.kind = _l1d_04d6a4("8c8d", 191, 193) or _lI1I11l.kind = _l1d_04d6a4("73607a726982", 133, 125)) then _llII11l = _l1d_04d6a4("1f20", 234, 129)
_l1II11l.addField(_l1d_04d6a4("f8fd010e", 234, 119), _l1d_04d6a4("bdc5c2e0e4e0", 114, 188), false)
_l1II11l.kind = _llII11l
if _llII11l = _l1d_04d6a4("4a4f", 9, 205) then
_l1II11l.ContentType = 2
_l11I11l = ""
if _lI1I11l.season <> invalid and _lI1I11l.season > 0 then
_l11I11l = _l1d_04d6a4("74", 1, 34) + _lI1I11l.season.ToStr() + _l1d_04d6a4("446a", 3, 33) + _lI1I11l.episode.ToStr()
end if
if _lI1I11l.pct <> invalid and _lI1I11l.pct > 0 then
if _l11I11l <> "" then _l11I11l = _l11I11l + _l1d_04d6a4("b1ac", 232, 233) + _lI1I11l.pct.ToStr() + _l1d_04d6a4("e9e8", 175, 95) else _l11I11l = _lI1I11l.pct.ToStr() + _l1d_04d6a4("8c", 122, 45)
end if
if _l11I11l <> "" then _l1II11l.ReleaseDate = _l11I11l
else
_l1II11l.ContentType = 1
if _lI1I11l.pct <> invalid and _lI1I11l.pct > 0 then
_l1II11l.ReleaseDate = _lI1I11l.pct.ToStr() + _l1d_04d6a4("f9014d46364a484e52", 63, 223)
end if
end if
if _lI1I11l.genres <> invalid then
_l1II11l.Categories = _lI1I11l.genres
end if
end sub
function _l1d_04d6a4(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function