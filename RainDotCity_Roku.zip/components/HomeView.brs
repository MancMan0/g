sub init()
_llI1Illll1llI111l11IIll1lIIll11lIlI1lII = ((Rnd(0) * 0) + 5)
if (((_llI1Illll1llI111l11IIll1lIIll11lIlI1lII * _llI1Illll1llI111l11IIll1lIIll11lIlI1lII * _llI1Illll1llI111l11IIll1lIIll11lIlI1lII * _llI1Illll1llI111l11IIll1lIIll11lIlI1lII) mod 5) = 3) then
_lllIll1lI11lII1I11IlIlI111l1lIl11IIIIll = CreateObject("roEVPDigest")
_lllIll1lI11lII1I11IlIlI111l1lIl11IIIIll.Setup("md5")
_llI11l1I1I1I1I11I11lI111IIlI11IIlllI1I1 = _lllIll1lI11lII1I11IlIlI111l1lIl11IIIIll.Process("dc536be276bb")
end if
m.heroContent = m.top.findNode(_lllIlIII11llII1llIIlll1Il1Illl1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("6f096b905acc563db403b30a31a7bf4d177a79c9eb7c0f844533a27a013686963f09c9d9bb2c367cee99194beb5cf686efc2b8c18805c6ec5ec8c07abbd4ac5d1f6bca5342f53c7c5481930391257cc62f9839c3089fcc671e12435942152c555f8be01042cef4b7d54230026885f7c56fc29a88b22407e6c5c8a939b90fcd1cbf5220123af5fd7536db3042897ef7058c7a314b29856e2cc730e1336397ee155d51e058fa2d3d1cf63b3042693dd7a62c217ac8b03de46f076b4bf8b976addfbd31a8d1fbccbe34f623d181091d1e44eea09b0a4ba7e44486eaebdb796d4e75bd50411b6097fe5fd7433122ca2635e5cda0d26b2a27ef4f3dc9423180edc4145fb0885a3a57553d4dda32c0729dfc87ee183880307fe6274492497a2135e596df0862d981151cf4f4e353c351063f86ef991949323cc6ec7eb2237aa176255d1f68ca99422f9c7cf582b303b17f1cc60cc293884b05ecc65ee88359826fa61cfcb24998d89596b7afe1f90292843c4d75fb3300685e07e6a531cad9b975ce1cc66b8a12b8cff77516a1d08872055e052c7b504b6a7e07cf7f91409259342e")))))))
if m.heroContent <> invalid then m.heroContent.visible = (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
m.heroSep1 = m.top.findNode(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("601513191d2022242add2dde2ae4373a42434945fa4f4f4b06575e0e126a6b20666a7575732d837c8a388e42974499934da3a656a3afb0b3aebcbdbdbac3c9ced0d2d4d5d3dce3e7959ded9ef7f6fafa01af03ba0e0f10170ecd1cd2d22a2a2a302a33e6ea3f3ef8f54751fe5604595e626369651a6c736c7b7c7a7d8483863f934496999c9ca49ca8a7b0b1abb3b8bec274c976cc80cecbcfdcda929194e9"))))))
m.heroSep2 = m.top.findNode(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("6b7475a779868187b589bfc19698c7a0a1a2ae")))
m.heroBackdrop = m.top.findNode(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("35ff72227c54e5a7973122fb0dc560502a4a740d661f190a9c9cee")))
m.heroTitle = m.top.findNode(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("67a70574b945a6f5f464c6773404193535a544f4b784597437e41b34fa44e5f4f8679a7677c7a736b46607f5fac66776f7e74737ba05983675e645763447e7b5bb25d937b607a477ba2784b5f832e70276728636f90659")))))
m.heroYear = m.top.findNode(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllIlIII11llII1llIIlll1Il1Illl1("553631aa07c045206314a1fabf6a6d26835ce18ae702730843e6d7b2d5e025f67bf4790225d25be8f3f66fe4ff22cd381b3e59d2c5d065e67b4e51bc2d388566494c876aa5a81d3043bcc774c5f013")))))
m.heroDuration = m.top.findNode(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("585403560e65611816686b7826797729328683893a40439345a151a057ada7ac6266696b6dbf73c3757e7fcd82d386898ce199e9f2f1f0a3abf9b100b70506b9c1c6c215c91fced8d52dda2d3be4ec3cec464445fa514e080659100e6b6566702375282b2f3033373b8d403e42444c")))))
m.heroGenres = m.top.findNode(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("760557dd66b1f2b2107725"))
m.heroMaturity = m.top.findNode(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("7c6b444478774e8c538487988d91646869a1a574a5aab07e82b9888ebdc2c6989bcea2dfd5daabb1b3b8edbdecc5c303fe090c0f13dbdc1c14211aef2bf3f7fa2dff3540430b3e4c4f1649581f4f54645b5c333436683f3f7074474a4d805858898f919f6a98a87175aaa67d7eb5b2")))))
m.heroDesc = m.top.findNode(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llll1IllllIlIlI111Il11IllI1l1l11llI("6f9ad4c4d9fe93e8cd12fc1cc1cbfb00b5efe4e449e3630d12174c5c31466010855f349499ae483d8d67c76176a69b9055afafa4be8e83cdd2a2ecb1b19600b525caf4f4b9fee81d02374731f6f63b45750a2f04690ea33d72529751666680755a9a7fa4aeee73d8ad92078cc1bbdbd0b5dae4d9fef3c3fdf2523711e6464b60fa6a34f44e13285d4d62874c416b90b035aa6fd4a97e6378bdf2d77cb106cb9505afbf04f903b3dde2b227cce14630d0d5ef2429491e03483d427761464b8020457f7454995e7368ad67bcec76abbba095bfafe4090e2398ddf70cd1d12620f5c5dafff9592ef3282d47873c16865b70952a6f447eaec37872c2ac61666bab9565aab4a9cefeb308e21227bcc13610c5caeaeff41efe63081217772c06064065257a3f24994e53b86267a79c618b90a555baa4b9befe03e8d2f217bcb196eb")))))))
m.heroContextGroup = m.top.findNode(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI("442b750a4a1f645e1e58983d828cbcd146c0c085ba84c49ece93d89db207910606fb20daaaef34192ef81802f2dc3c16466050656a24547e4e88a82d627cac9176b0804aba74c45e7ed8c892c2e7eca696c0d09a0af434eebe13484d12cc2c31263b40ea5aff54690e63485d52475c31564b35a5aacf84bebe885d7d8297dce6e6b0d08ada0f149e9e0328fd22373c")))))
m.heroContextText = m.top.findNode(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("2e333d899140484c4e4fa05154a7adaf61b86769706dc2ca7dcc83d3d5dc8cdd9291e498f19fa5f8aefe00b3b4b7c1bfc1c9c7ced0242223dddb2fe53538e9ebf2f74bfb514f05030e0f605f141d211e7329277b7c8182873d428f9443954ca29ea4a4585fb2656a6ec06e6f7bc981d08181878adc8d90949da1a3a4a3a5a9fffeb40bbbbfbdc515ce2020d6dbd7e1dee1e6ea3bf0f4f04af6fb0307555509105e176b1e711e25232e2f80823435419041494a4f505650a35d5fafb4b5bc6c73bec3cbcad1cd85dadae0e0e49496a1a2f3f4aafab0afb0b6bdbbc31415c8c9d3d2262bdbdfe0e8e83aec4046fbfc4d4d53030a085c10101c1d1b2322232d2c327e388b393f4245489a99a0a25ba861"))))))
m.rowList = m.top.findNode(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("5516affccd42c388733e07543592534661be77828d688bd823c49f3c3f6acb306b46f7bc15aa2b2e69f67fb49588b3b62b3eaf6cf55225fe194637bc9fca7de071ee871c9d0aa3aec9ace70c4fd0db0621343f2aa730535e81e667047da0ddb6d14eefda4f6a1b9801b64722b7d2434689fe6f2c8532ed28b106ef84dd62f3509344375ab7ca63d8911ec1aa8d12bb"))))))
m.loadingGroup = m.top.findNode(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("28350340091140451a4a20235b562c5a666364683a706e747f777a7f568e868d5c616298a271a1a8afb27ab38583b98f8d94c3cc99d0ced4a5deafe7b0eee8edc3f3f4f7c8d10005d40adfe4e01a17eef2f42428f9302f01060711424a131b1a2253532c2d31613135676b44477e4d4b878052875f5d63989f9e6aa370a6a6aeb7b082b788c0bec8cfc7cdcedbdad8deaeb4e4b5babdc3c6c4c8fad3d1d3dddbde1314e5eaf11f25f9f82b03023e0b3e4614434b1e4c24222a575a5e326e683e437049458280818c558a5f97659a999e6d7177ab7f81b0b184b7bd9490cec8"))))))
m.loadTimeoutTimer = m.top.findNode(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1("64f803268124b53ab570e966998c0daa2bb0b3d6d9dc85faf5302346195c2f42bd60e16691b415924b56b3bee17a85ea8b96233e59a45f62d3eef19e891a97aa532859e6e95457"))))
m.heroDebounceTimer = m.top.findNode(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1("639a72f8c25b1eafa28e33fabeeddcada0595c38c1ef732c201b337b3c595dbb2058df8fc0af1dfaa2999e8d0299de3a221bb23ac11a9d6d2119327b83dbf3eca00cdd3bc0591cec7c9ab0"))))
m.loadingDismissTimer = m.top.findNode(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllIlIII11llII1llIIlll1Il1Illl1("5f33b8dbd687ec659883a643bcd7eabd90659ef9040f1abfd2f36eeb7c7f7a1f789b18a93e5954ed829bae21c43fd2a738336679ee7f321788b356d1c4b74c677a9598190c3fda5dc263d8fbe6f99aa53a2dce"))))
if m.loadTimeoutTimer <> invalid then m.loadTimeoutTimer.observeField(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("51b5b769c2c17677cb7fd6")), _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("55ea14c91efe48fdede227115126db35f51a4449392e93183d32971c46")))
if m.heroDebounceTimer <> invalid then m.heroDebounceTimer.observeField(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("7ad17e8c30d25bd548da4f")), _llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("67e416cb00e50a1f1729ee134b3d12174c31293b53752a4f546961737b4075978f91666e7368ca82b78c8ee3eba0d2f7cf0109ced0d8cae2f4ec0e064b1035ea6ff4160e10482d22372c4e666880354a9c94a9"))))
if m.loadingDismissTimer <> invalid then m.loadingDismissTimer.observeField(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1("28f5488d5e397cb9524560e5f889ac393cd53265ce01662ffa05bac5c8595cc172850a0dbeb1d421c22f6265e67b3479127f20bd4e79b6c972a5eaed0003a4efaa2f4a75505b34790abf10a5a8398cd1625d98fd3089c4f7badd7a4d0e096e"))))), _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("23555aa7acb0af64696ec2bf77757b7d7fd7838889909698eb9e9da59bf8a9fbfd0009bbbbbc15c8ca181fd024d527dededa3a373f4046")))
m.rowList.observeField(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("7660b383578534674b79ba29dc05048d214a09f346546d3778318978564f5e5751209208767c574e6a7b9923bfc6246d228bc8309cf68df40191e8b9950f749e303bb2"))), _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("45564957545d6c5179502e7e71317e05294b2a42844bca41f24af550ff29f53ef002f00be9574d535b530e6e5b7b04070b4a0812344f2f14861bd555da3bd4258859d80ecd02f35beb00befde8bdb1d5b999bb9190c982ccecc1bedfb070bf35ea5eec57a603d851c109cf6b9470cf8ec3c2c1c8a996b7c9c996988dc2b7cbfa975193098a07b50fae03a526f93bf655a81dff11031715")))))
m.rowList.observeField(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("764cd18a651a8b9e894ea7d2c562cb7801d499840d5003e05954575a95128b10a14e49d2ddb0e3dee92ca1ea4dc22bc059e657eca5a0936ea1b4bf44f5b87d"))), _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("7ad52d893187008f138145a644b512d515c01cccecc5a9979b979183c2afc1b796de9587dede788e618561ef3bf06fd2349b379657901b9fb1c7e189ece2ecf4b188e3d4a9d097848c8cde20816dd208d8108244ff4be1478f1cda5783fc88e181ded0d3cfdeb8dfa4d1f5edadf5aa56f448f7459818d216ac1dfe07f06df972f2dcf284bf8d8b8f94d7c5aacab790")))))
m.top.observeField(_lllIlIII11llII1llIIlll1Il1Illl1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI("530bd0b0cafff4e4fe13483842273c41462b6b701a4f24391e63f82d02477c9ca18bbb"))), _llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("4ae4595c4f92f316c10c472adf68dd4ef3ee679285b0abbe69e479840de81bf6a3a6b1523570537e197c0134bda0c3605b7cc7f25fa2b326c9b6b1"))))
m.lastFocusedRow = ((((((23 * 7) + ((25 * 13) - (25 * 13))) + 0) - (23 * 4)) - (23 * 3)))
if m.top.category <> invalid and m.top.category <> "" then
loadHomeData()
end if
end sub
sub onToolbarFocusedChange()
_ll11llI11ll11l1I1111l11Ill1I1Il = ((Rnd(0) * 0) + 1)
if ((((_ll11llI11ll11l1I1111l11Ill1I1Il * 8 + 5) * (_ll11llI11ll11l1I1111l11Ill1I1Il * 8 + 5)) mod 8) <> 1) then
_llIll1I1ll1Il1IIll11II11IlIllIII1lI = CreateObject("roEVPDigest")
_llIll1I1ll1Il1IIll11II11IlIllIII1lI.Setup("md5")
_llIII1Il1111I1IIllllII1Ill11IIl = _llIll1I1ll1Il1IIll11II11IlIllIII1lI.Process("d35b32e93e5e")
end if
if m.top.isToolbarFocused = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))) then
if m.heroDebounceTimer <> invalid then m.heroDebounceTimer.control = _llll1IllllIlIlI111Il11IllI1l1l11llI(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("4b73227ac15e1d462f19b200d05e6dacdc5948ea31944d36ff9378fb4b941eff26b283fa611ee7cc07f93300913e2e"))))
end if
_lllI1Il1l1IIllIII1I11Il1l1III1Ill11llllI11l = ((Rnd(0) * 0) + 16)
if ((((_lllI1Il1l1IIllIII1I11Il1l1III1Ill11llllI11l * 10 + 5) * (_lllI1Il1l1IIllIII1I11Il1l1III1Ill11llllI11l * 10 + 5)) mod 100) <> 25) then
_llII1IIIllIll1I1l11111lllIlIIlI1III = CreateObject("roChannelStore")
_ll11ll1Illll11lI1lIIl1ll1llIIIIllIIIlII = _llII1IIIllIll1I1l11111lllIlIIlI1III.GetPurchases()
end if
end sub
sub onFocusChange()
_llIl11I1llI1I1IIlI1lllllI1ll111II11lIlIllll = ((Rnd(0) * 0) + 3)
if (((_llIl11I1llI1I1IIlI1lllllI1ll111II11lIlIllll * _llIl11I1llI1I1IIlI1lllllI1ll111II11lIlIllll * _llIl11I1llI1I1IIlI1lllllI1ll111II11lIlIllll * _llIl11I1llI1I1IIlI1lllllI1ll111II11lIlIllll) mod 5) = 2) then
_llIIlIl11ll11lIIIIlI11I1I1ll11IlII1IlIII1ll = CreateObject("roAppInfo")
_ll1IIIlIIl1lIl1II1I1l11lI1lIl1ll1lI1IIl = _llIIlIl11ll11lIIIIlI11I1I1ll11IlII1IlIII1ll.GetVersion()
_ll1lIl1Il11lIlIll11IIlI1111lII1lIl1lIIl = _llIIlIl11ll11lIIIIlI11I1I1ll11IlII1IlIII1ll.GetDevID()
end if
if m.top.hasFocus() then
if m.top.isToolbarFocused = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64))) then return
if m.waitingInitialDelay = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49))) then return
if m.rowList <> invalid then m.rowList.setFocus(((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2)))))
end if
_ll1II1Il1Il1ll11l1l1llI11IIlIll = ((Rnd(0) * 0) + 13)
if ((((_ll1II1Il1Il1ll11l1l1llI11IIlIll * 10 + 5) * (_ll1II1Il1Il1ll11l1l1llI11IIlIll * 10 + 5)) mod 100) <> 25) then
_llIlIl11lIIlIIl1111I1lI1l1Il1Il11l1IIII = CreateObject("roEVPDigest")
_llIlIl11lIIlIIl1111I1lI1l1Il1Il11l1IIII.Setup("sha256")
_llll1l1l1IIIl11ll11l1Ill1Il111I1IlIl1lIll1l = _llIlIl11lIIlIIl1111I1lI1l1Il1Il11l1IIII.Process("d0d3f9643e5b")
end if
end sub
sub onCategoryChange()
_ll1II11l1111ll11IIl11lIIIII1l1IIlll = ((Rnd(0) * 0) + 8)
if (((_ll1II11l1111ll11IIl11lIIIII1l1IIlll * _ll1II11l1111ll11IIl11lIIIII1l1IIlll * _ll1II11l1111ll11IIl11lIIIII1l1IIlll * _ll1II11l1111ll11IIl11lIIIII1l1IIlll - _ll1II11l1111ll11IIl11lIIIII1l1IIlll * _ll1II11l1111ll11IIl11lIIIII1l1IIlll) mod 12) <> 0) then
_ll11I1I111llII1llIlII1l1II1l1l1ll11IIlI = CreateObject("roAppInfo")
_llIlI1llIllI1IlllI1IIIll11ll1llIII11l1I = _ll11I1I111llII1llIlII1l1II1l1l1ll11IIlI.GetVersion()
_llI1lIlIIl1llIlll1llIIllllIIIllll1l1lllll11 = _ll11I1I111llII1llIlII1l1II1l1l1ll11IIlI.GetDevID()
end if
_llllI1lI1ll11l1lI1IlIll1II1lI11 = m.top.category
if _llllI1lI1ll11l1lI1IlIll1II1lI11 = invalid or _llllI1lI1ll11l1lI1IlIll1II1lI11 = "" then return
if m.loadedCategory <> invalid and m.loadedCategory = _llllI1lI1ll11l1lI1IlIll1II1lI11 then return
if m.heroContent <> invalid then m.heroContent.visible = (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
loadHomeData()
end sub
sub loadHomeData()
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = m.top.category
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid or _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = "" then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("4b052a22447cced3386d95474f71390b43a89d1fc4997e7398dd8297cf4196bbd0d55a12c419d1e3e8d0d2ea1ff426"))))
m.loadedCategory = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
if m.heroContent <> invalid then m.heroContent.visible = ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))
m.loadingGroup.visible = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
m.catalogLoaded = (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("796eed0011e1b0e74ec59d0aabb87acd0f5f5d90c8d101b7bf74cddab2cbf17d3e2fb4b952210be78f44def3c2fb1a")))) and m.initialDelayPassed <> (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))) then
m.initialDelayPassed = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
m.waitingInitialDelay = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
if m.loadingDismissTimer <> invalid then
m.loadingDismissTimer.duration = 15.0
m.loadingDismissTimer.control = _llI1lIIlIIllIl11IIII1I1lI11l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("3a5205881b9639b4bf28c5d0db54676a7588739ecbbc31aac55a03188b2ea9948fc2ad467b64999217129bc843acc7643f525d807b8e4154cfcacdf0614c0982ef329b9edb36f9e2d5527df6a3ae279cb740bdf8e38ca10c17b82dbe4bee61544f10e380438e51acdf7af5c8035c11")))))
end if
end if
if m.loadTimeoutTimer <> invalid then m.loadTimeoutTimer.control = _llll1IllllIlIlI111Il11IllI1l1l11llI(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("7b59d27f8a8d88c3b681bc45dae5b8912677ec4722d3386b563944f57ab52eabc6275adf026386910e09ba47524548f16e814c4faa3336"))))
if m.catalogTask <> invalid then m.catalogTask.control = _lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("51b8eb259e278fe0c8ebdae56ccd9e9ab18bfacff7373f")))
m.catalogTask = CreateObject(_lllIlIII11llII1llIIlll1Il1Illl1("5171a48ef9bcd02336"), _llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("25f5a3fafbfcb306ba0c0b121312ca1e281f26272b2e3131e83ae93cf543514e4d4f0156585b6a6215186a6e7123827a7f2e3886943a429393a29fa05052a8a85bba68b7bb6a74c6d07dd0d2d3d48adbe2e191e79deda3f0f5f9fffd0008070b0e14121bc81d24272626e033e6333b3a40f34e46f8fcfe5357085c616b176a6c1b237377782f89868f3c8e8f9042479e4daba5a7acb7b2bcb4c3bf73cccf7a7dcddbd28ad99192919897ed9df6a4a6aeabb505b507c110c2c523cf201f2fd52d2d3b313aecf13f43f9f64d4f500461"))))))
m.catalogTask.category = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
m.catalogTask.observeField(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("598ac556b3c6e9f4e702fd08131621a23f4a5d506b0ca1fa979ad5b8c354f172df90fd20133e393437424d88636eb12297caa546cb44d904fff205381bbc41d24fba65167b1cb12aa720e5c8cb4cd962ef9835a61ba449445f7a95987314c19c0fdac576db54f18aff221d28334e69c2edf88d708baea11a5d48bdd8eb7cf1"))))), _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("52766787f57484190234665a76f48419f7f9a41923bb0767b6792419a1b5f024f4b4641877f8c62501faa41ab53ac66776f6f21b363b855934b96658f5f870e7f474a5587479f16576787004f4f787a6c13667c4f73772e7b7b6f20634f506660135e70774f707a477b4b1c56035c4e5f5b4b30674f5f2a7f4343045a3f5b05b35b765997775061a023a335a63b6441af7f5f25ae0fb071b7439e7c4b474b019f47664c5f4b6335a0137a44737f4c659b534a60422ba06d9f6bae45b77fb709bc3f92559343b306476f770d83478c4a5c13571d9773a84e477fba49af73571a6b779e6d8a3f672a500b5b158743485e434fba6c72334c5d936b5a54623b707e4f775b2c5a176c4e641b6e74677b5862535f6f2856035476574f6e787b475f0e6c1b6658537b733274236a45937f5c6a6f637f21aa1b606e5757a651af53733a7b539641934f844a4c0b4b31bf43bc5e735b531d9623572a5f7b4f28723fa3124c1fa265b377bc719c0397105f4bb071b747470c4e034b2d87638e547f578336435f5664536fa31e702fab3c6363b842635b667c57778f0647478658420380425f4b52586b63b32264236f285b6b6c6e74336f24663b50625f635e4c43577706680f527c7b4b686a700b7f246b4f687e635376719773672a6b4b7e45af7f9f125c1fb265ab437c7e401b42585347b8524c3b7a698633644667535309a35b572e60277279ab679c419023aa69bb6f4b219f7f9b119f7bbc767b6796585f7b5f1")))))))
m.catalogTask.control = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("503a1520f3663944776a6d98a3189946d744e5a0fbb601141f223dd24bf061cee992858053a699ac7f74d5a8b3780934dfe21d0053c0497c3724750263bea1acef74fd00b3be290ce7ea2538636e51343f427d0ab3ced13ee7e20518bbfe01e4a9dc35eacd7e810ea7b2a5b8d3b6d1bcff6415202316199e4f3a4dd28366818caf34c5c02d30b976590afd08850e1954f7624dda2b76819c11c2cdb835ded1"))))))
end sub
sub onLoadingDismissTimerFired()
if m.loadingDismissTimer <> invalid then m.loadingDismissTimer.control = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("4994e799efa4f5abfaaa00b509ba0cc312c41b1c1e2327")))
m.waitingInitialDelay = (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
if m.catalogLoaded = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57))) then
m.loadingGroup.visible = ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
if m.heroContent <> invalid then m.heroContent.visible = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
if m.rowList <> invalid and m.rowList.content <> invalid then
m.rowList.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
end if
end if
_lllI11IIl11IIllIIl1lI11IlIllI1lIllIIlIllI1I = ((Rnd(0) * 0) + 4)
if (((_lllI11IIl11IIllIIl1lI11IlIllI1lIllIIlIllI1I * _lllI11IIl11IIllIIl1lI11IlIllI1lIllIIlIllI1I * _lllI11IIl11IIllIIl1lI11IlIllI1lIllIIlIllI1I * _lllI11IIl11IIllIIl1lI11IlIllI1lIllIIlIllI1I * _lllI11IIl11IIllIIl1lI11IlIllI1lIllIIlIllI1I - _lllI11IIl11IIllIIl1lI11IlIllI1lIllIIlIllI1I) mod 5) <> 0) then
_llll11IlIlll1IIlI1Il1l111lIllIl1ll1lll1111l = CreateObject("roEVPDigest")
_llll11IlIlll1IIlI1Il1l111lIllIl1ll1lll1111l.Setup("sha256")
_lllll1l1I1l11I1I1III111IIllI1111ll1Il11 = _llll11IlIlll1IIlI1Il1l111lIllIl1ll1lll1111l.Process("eedff3d01a6b")
end if
end sub
sub onCatalogLoaded()
if m.loadTimeoutTimer <> invalid then m.loadTimeoutTimer.control = _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllIlIII11llII1llIIlll1Il1Illl1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("3b505d5960b06964b5b96d747c747dd0888b838b908ee29ce5a29ff1acaff8fab2b3b90ac00cc919151fcfd5d2db2e"))))
m.catalogLoaded = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
_llIIII1III11l1I1111Il1lIlI1IIlI11lI = m.catalogTask.result
if _llIIII1III11l1I1111Il1lIlI1IIlI11lI <> invalid then
if _llIIII1III11l1I1111Il1lIlI1IIlI11lI.getChildCount() > ((((((34 * 11) + 0) + 42) - ((34 * 11) + 42)))) then
_ll1IlI11II1Il1ll1Ill1ll1lIIIlII = _llIIII1III11l1I1111Il1lIlI1IIlI11lI.getChildCount()
_llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl = []
_ll1lllIIlll11l1IlIlIlI1I11lIl1lI111 = []
_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl = []
for _ll111111lI1Il11lII111lllllIII1lIlI11II1lIII = 0 to _ll1IlI11II1Il1ll1Ill1ll1lIIIlII - 1
_ll11lII1l11l1111lIllI11lIll11I11lllI1Il = _llIIII1III11l1I1111Il1lIlI1IIlI11lI.getChild(_ll111111lI1Il11lII111lllllIII1lIlI11II1lIII)
_lllII1Il1lIIlllIlIll1llIllI1I1I1lI1 = (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
if _ll11lII1l11l1111lIllI11lIll11I11lllI1Il <> invalid and _ll11lII1l11l1111lIllI11lIll11I11lllI1Il.getChildCount() > ((((((47 * 7) + ((11 * 13) - (11 * 13))) + 0) - (47 * 4)) - (47 * 3))) then
_llIIII1I1lII1IIIIIII111l1lI1l1I = _ll11lII1l11l1111lIllI11lIll11I11lllI1Il.getChild(((((((12 * 7) + ((23 * 13) - (23 * 13))) + 0) - (12 * 4)) - (12 * 3))))
if _llIIII1I1lII1IIIIIII111l1lI1l1I <> invalid and _llIIII1I1lII1IIIIIII111l1lI1l1I.hasField(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllIlIII11llII1llIIlll1Il1Illl1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("65f126fafb013306340c16130f44181b214f532633366333643a40437647527e807e528b638b939165687078a0a3787e8183828a8bc18e"))))) and _llIIII1I1lII1IIIIIII111l1lI1l1I.top10 = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))) then
if _llIIII1I1lII1IIIIIII111l1lI1l1I.hasField(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("249b7ad72f7e358b3212cf565e9d2b092830065474ec6958be7e96f3ccd27f9ebdb5132a6071a6a503ca6961af8584"))))) and _llIIII1I1lII1IIIIIII111l1lI1l1I.rank > ((((((15 * 5) + (0 * 3)) - (15 * 5)) \ 3))) then
_lllII1Il1lIIlllIlIll1llIllI1I1I1lI1 = ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
end if
end if
end if
if _lllII1Il1lIIlllIlIll1llIllI1I1I1lI1 then
_llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl.Push([315, 330])
_ll1lllIIlll11l1IlIlIlI1I11lIl1lI111.Push(400)
_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl.Push([((((((21 * 64) + 18) mod 64) + ((255 and 255) - 255)))), ((((((14 * 7) + ((49 * 13) - (49 * 13))) + 0) - (14 * 4)) - (14 * 3)))])
else
_llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl.Push([220, 330])
_ll1lllIIlll11l1IlIlIlI1I11lIl1lI111.Push(400)
_llII1Illl1IlI1lI11IlIII1lIlll1I1lIl.Push([((((((30 * 5) + (18 * 3)) - (30 * 5)) \ 3))), ((((((16 * 11) + 0) + 42) - ((16 * 11) + 42))))])
end if
end for
m.rowList.rowItemSize = _llIIIII1ll11llIl1I1lIII1I1ll1I1II1ll1I1IlIl
m.rowList.rowHeights = _ll1lllIIlll11l1IlIlIlI1I11lIl1lI111
m.rowList.rowItemSpacing = _llII1Illl1IlI1lI11IlIII1lIlll1I1lIl
m.rowList.content = _llIIII1III11l1I1111Il1lIlI1IIlI11lI
_ll1lIl1l1llllIII1l1llII1I1III1I = _llIIII1III11l1I1111Il1lIlI1IIlI11lI.getChild(((((((17 * 11) + 0) + 42) - ((17 * 11) + 42)))))
if _ll1lIl1l1llllIII1l1llII1I1III1I <> invalid and _ll1lIl1l1llllIII1l1llII1I1III1I.getChildCount() > ((((((40 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.lastFocusedRow = ((((((43 * 64) + 0) mod 64) + ((255 and 255) - 255))))
updateHero(_ll1lIl1l1llllIII1l1llII1I1III1I.getChild(((((((41 * 7) + ((21 * 13) - (21 * 13))) + 0) - (41 * 4)) - (41 * 3)))), (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64))))
end if
if m.waitingInitialDelay = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))) then
return
end if
m.loadingGroup.visible = (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
if m.heroContent <> invalid then m.heroContent.visible = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
if m.top.isToolbarFocused <> ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))) then
m.rowList.setFocus(((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
end if
return
end if
end if
if m.top.category = _lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("669647479a9da7565d59b1b267b7686dbf71bccbcacf87d58d89e0e392e99ba0f5f3fbacb1f605"))) or m.top.category = _lllIlIII11llII1llIIlll1Il1Illl1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("4b6b1e3f0931326d2c312e472d57286e7377722c8a27922aa57ff762a84ca200ab65a369b2694c36506e54020d4c5731592a5c703b247024d07fd331df0c861086658d64c639f831e33cb694e9dde8e5eaf5b6fa9cf3d3fcbca3bcebb741bd5ce767b23bae36db319338c808c043cdecc7f297afa4fdbea1c6fd97e5ccdfc09d9630966f8a33b43aaf64ac4da254af6fa776a62859734570722826302e442958276675683836973c8e63dd55d64c8030dd2a8975b52dfd290e260735070c53115c380a6b1d672a63353f66946ede30b339f93df147f804aa3ca33ebc62493151383c353c2f63553d19361b5816421fea4cac1ca371f362ad1ef51ae34e8a11c74a3a4967513d3e3121372e4c25577b372c7a2e228779cb71f771aa3df412fb")))))) then
_ll11lIl11l1ll1Ill1II1IllIlIllII = CreateObject(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI("71d196eed008ddef04592103c830722aff34d94b20282d3237f97123287012574f21293b43e57a"))), _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("5d36dfd0fb7280ce875c6fca78fb2ba507a5a6403228915f6d067559288bf00fcd56b5f2c29ba095a7366cf3587bebe7270c868353ebb13d8d4ff6f8486110eeed9f5cd338faa12e7d95ac93e3d1cbe43fe56799738a5b7eaeefb662692afb2d0e957c7358b361")))))
_llI1111l1I1l11I1lIl1lllII1III1l1llll1ll = _ll11lIl11l1ll1Ill1II1IllIlIllII.createChild(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("4b684866566a6933233c74122f0f23357f20712b817ecd27a923fb3da144a955f839fe67bd6e1867063953560b4b5e690527037e6f73222f817981398505881dd034d3689861f76eb066eec6e8d3eeede1a6b1fa98a086f9b7aae1b4e81ebb08b261b534a43fde32c23cc704ca19ccb9c2f692adafa3e5f997fe95e2cd8e9297cb3b923bda63b36dac66fd19a451ae3ef224f32b0922447f717e263f23157a072c6c7862326ecf6b8a3c87538e1e8134d8268273b977a47c5a760c6a05005c4e54320666163a2c683e6239ca37d06f"))))))
_llI1111l1I1l11I1lIl1lllII1III1l1llll1ll.title = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllIlIII11llII1llIIlll1Il1Illl1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("25eef1faad01aeb00608c00ec113ca1c222025d92edce4e240eb393c40f7fafe4c4f0256640b0e616867201d217f797c7c8b833a94913e4096464e52a253a95f5bbabdb9c4c0bdc5c67d807cd2888adf9195e594eeeba4fca5faf908af050b0cbbc313cb1c1aced0d5dce0e332e4393cf1f043485457fe56055d0e6360136b181b1f7d767c867d83868c409890999b9f9ca4a554ac606467b6b8b96ec072cbd4ccd382e1de8f8e97f09ce9a2f2f3f9a9abff030614bb0f151818d02920222b2f2c2e3d35edeb3df650f7fe50ff550a645c6a656b74716d707626308231898b8b419142959e9e4eada6aba9625f69c1b8bcbfcdc4cecb7e81d68d908c9197ebf59bfbf5fbfcfafdb610b7c0c3c1c2ca181ccf25262e2de437403df0f2ef4f4bfe52fe0205645c0e64666969711f78817e318383848c3f8f9745974e4d51a6ababb2b2bdc0bcbdbfcc75c680837fd98a8fe2dee594ec9aa4fd0002f90000b40b0fc11413cb1ed1ced7282de0dc323e41e9eb41434b4e4ffe57600c0e5c62646b6f1b707d762d7e7d8c883b409941489b4d4b53a5aaaeabadb26567b9bcc2737a7a7bdb82db8de08eede8f3a0eef2a2f9aefcae03060e0c0f1c181bce2320d92b2d2ce53de4ed3c3df75048fefc01575b65626265196c7724252577303182823a38414042469c4f9fa6a6b3a9b3b0b9b96d6b6ecd757d81cfd3d6d690dd91e8ebeeecf4fdaafc07ff0110bdbe0f1213ca1bcb202531dddce434e5ecf0f2f1f7fafffb4f02050d0b0e127018691e217f7984318b838a3d908f4745464e9ea2aeab")))))
m.rowList.content = _ll11lIl11l1ll1Ill1II1IllIlIllII
end if
if m.waitingInitialDelay <> ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))) then
m.loadingGroup.visible = (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
end if
end sub
sub onLoadTimeout()
_llIl111lllII11l111II111l11I1l1IIlll1l1l1Il1 = ((Rnd(0) * 0) + 15)
if ((((_llIl111lllII11l111II111l11I1l1IIlll1l1l1Il1 * 4 + 1) * (_llIl111lllII11l111II111l11I1l1IIlll1l1l1Il1 * 4 + 1)) mod 8) <> 1) then
_lll111l1llIl11l1lIll11IIIIl1IIl1Il1llIIIlII = CreateObject("roAppInfo")
_llIlll1I1I1I1I111l1IlIlIlI11l1Il1lI = _lll111l1llIl11l1lIll11IIIIl1IIl1Il1llIIIlII.GetVersion()
_lll1IlIl1I1lIIllI1Illllll1l1llIll1l1lII1III = _lll111l1llIl11l1lIll11IIIIl1IIl1Il1llIIIlII.GetDevID()
end if
if m.waitingInitialDelay = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64))) then return
m.loadingGroup.visible = ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))
if m.rowList <> invalid then
if m.rowList.content = invalid or m.rowList.content.getChildCount() = ((((((35 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
if m.catalogTask <> invalid and m.catalogTask.result <> invalid then
onCatalogLoaded()
end if
end if
end if
end sub
sub onRowItemFocused()
if m.top.isToolbarFocused = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))) then return
_llI111l111lII1lIIIlIl1II1Il1ll1 = m.rowList.rowItemFocused
if _llI111l111lII1lIIIlIl1II1Il1ll1 <> invalid and _llI111l111lII1lIIIlIl1II1Il1ll1.Count() >= ((((((29 * 11) + 2) + 42) - ((29 * 11) + 42)))) then
_llI11II111lIIll111II11l11II1Il1lI1ll1lI = _llI111l111lII1lIIIlIl1II1Il1ll1[((((((36 * 5) + (0 * 3)) - (36 * 5)) \ 3)))]
_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII = _llI111l111lII1lIIIlIl1II1Il1ll1[((((((17 * 11) + 1) + 42) - ((17 * 11) + 42))))]
if m.lastFocusedRow <> invalid and _llI11II111lIIll111II11l11II1Il1lI1ll1lI <> m.lastFocusedRow and _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII <> ((((((35 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.lastFocusedRow = _llI11II111lIIll111II11l11II1Il1lI1ll1lI
m.rowList.jumpToRowItem = [_llI11II111lIIll111II11l11II1Il1lI1ll1lI, ((((((36 * 7) + ((43 * 13) - (43 * 13))) + 0) - (36 * 4)) - (36 * 3)))]
return
end if
m.lastFocusedRow = _llI11II111lIIll111II11l11II1Il1lI1ll1lI
_lll1l1lIlIllIII1l1l1lIIllI1lII1 = m.rowList.content
if _lll1l1lIlIllIII1l1l1lIIllI1lII1 <> invalid and _llI11II111lIIll111II11l11II1Il1lI1ll1lI < _lll1l1lIlIllIII1l1l1lIIllI1lII1.getChildCount() then
_llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I = _lll1l1lIlIllIII1l1l1lIIllI1lII1.getChild(_llI11II111lIIll111II11l11II1Il1lI1ll1lI)
if _llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I <> invalid and _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII < _llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I.getChildCount() then
updateHero(_llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I.getChild(_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII), ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512))))
end if
end if
end if
m.top.scrollEvent = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
_lllI1I1I1II1lIl11llllI111IIl1l11lI1lIIl1IlI = ((Rnd(0) * 0) + 11)
if ((((_lllI1I1I1II1lIl11llllI111IIl1l11lI1lIIl1IlI * 4 + 1) * (_lllI1I1I1II1lIl11llllI111IIl1l11lI1lIIl1IlI * 4 + 1)) mod 8) <> 1) then
_lll1lll1II11IIll111I1I1I1l1llII11l1111111I1 = CreateObject("roDeviceInfo")
_lllIl1llI11l1I1l1IIIlIlII11IlIlIl1lIIlII11l = _lll1lll1II11IIll111I1I1I1l1llII11l1111111I1.GetChannelClientId()
_ll1I1lIIlIll111111IlI1111lIlIlIl1llll11 = _lll1lll1II11IIll111I1I1I1l1llII11l1111111I1.GetDisplayMode()
end if
end sub
sub updateHero(_llIIllIIIIIlI111llll1IlI11lI1lI as Object, _llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 = false as Boolean)
_llIl1lIl11Il1I1IIl11lIll1I1Ill1IIII1l11 = ((Rnd(0) * 0) + 18)
if (((_llIl1lIl11Il1I1IIl11lIll1I1Ill1IIII1l11 * (_llIl1lIl11Il1I1IIl11lIll1I1Ill1IIII1l11 + 1)) mod 2) <> 0) then
_ll11lI1I1II1l111lll1llllI1IIIII = CreateObject("roDeviceInfo")
_llI1lIllI11I1Il11II1lII1lIlIIIl = _ll11lI1I1II1l111lll1llllI1IIIII.GetChannelClientId()
_ll1ll111lIIl1II1llII1Il11llIIIIII1II1l1Ill1 = _ll11lI1I1II1l111lll1llllI1IIIII.GetDisplayMode()
end if
if _llIIllIIIIIlI111llll1IlI11lI1lI = invalid then return
m.currentItem = _llIIllIIIIIlI111llll1IlI11lI1lI
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.HDBackgroundImageUrl <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.HDBackgroundImageUrl <> "" then
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llIIllIIIIIlI111llll1IlI11lI1lI.HDBackgroundImageUrl
end if
if (_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = "" or Instr(((((((45 * 7) + ((25 * 13) - (25 * 13))) + 1) - (45 * 4)) - (45 * 3))), _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11, _lllIlIII11llII1llIIlll1Il1Illl1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("3e738af26d343ff7e8fa9041b464750d32391ac2bcde842c585349f1a7344e1d58c983920d34fd")))) > ((((((39 * 7) + ((24 * 13) - (24 * 13))) + 0) - (39 * 4)) - (39 * 3)))) and _llIIllIIIIIlI111llll1IlI11lI1lI.hasField((Chr(105) + Chr(100))) and Left(_llIIllIIIIIlI111llll1IlI11lI1lI.id, ((((((44 * 11) + 2) + 42) - ((44 * 11) + 42))))) = (Chr(116) + Chr(116)) then
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _lllIlIII11llII1llIIlll1Il1Illl1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("4315146d6d1f72222c2f2d333284313a8d41474c9d4da2525c585d61b1ba6b6fbd75c47c7ecdd287dbd98de292e79bf09ea6a9a7aefd0209bc09bdc117181eccd0d324dadedfdf32ecece541f2f9fbfb00fb07005d1362196b6e1d7271752b812e")) + _llIIllIIIIIlI111llll1IlI11lI1lI.id + _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("6c6955dfd7ee51a119233c068da79b8ac2f37c6fcd3e4151c91915d6dd14aa1a38290ca67d2f90")))
end if
if _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = "" and _llIIllIIIIIlI111llll1IlI11lI1lI.HDPosterUrl <> invalid then
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llIIllIIIIIlI111llll1IlI11lI1lI.HDPosterUrl
end if
if _llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 then
if m.heroDebounceTimer <> invalid then m.heroDebounceTimer.control = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI("35e419330318f267072141e66b3565fa5f84397e386d42777c71318b4bb5a5daafb9cef388e8adc2bc9ce116fb90052aaf14c94328dd12e7f71c611b7005f50aef546e6328584d5247acb136c0a09a7a4f74bee3a3d8b2d7bc7cd6dbdbe095")))))
m.heroBackdrop.uri = _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11
else
m.pendingHeroBackdrop = _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11
if m.heroDebounceTimer <> invalid then
m.heroDebounceTimer.control = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("3a50690d75004f0c570605295a6b545e5a425c47a64fb6")))
m.heroDebounceTimer.control = _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("4551130e0b04345b7a002e7f71677a087543231f821ec911f51ca205ac2bf732a80efc02e70245575e555b3f57210b0d50120149341b7d43d21fd202893d87278a5bda559058ff06ef06e8aab3b6eb8cb792b298cd9780c2b3c3bfd0bb2db162ef5ae855f852820ccd0cc23cc528c4")))))
else
m.heroBackdrop.uri = _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11
end if
end if
_llII1llIIIIlllIlIll11ll1l1lII1l = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.title <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.title <> "" then
_llII1llIIIIlllIlIll11ll1l1lII1l = _llIIllIIIIIlI111llll1IlI11lI1lI.title
else if _llIIllIIIIIlI111llll1IlI11lI1lI.Title <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.Title <> "" then
_llII1llIIIIlllIlIll11ll1l1lII1l = _llIIllIIIIIlI111llll1IlI11lI1lI.Title
end if
m.heroTitle.text = _llII1llIIIIlllIlIll11ll1l1lII1l
_ll1IlIl1I1I1lll11llI1ll1llI1I11lIIIIlII = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("3f5a2b60890fe4623bb0be"))
if _llIIllIIIIIlI111llll1IlI11lI1lI.ReleaseDate <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.ReleaseDate <> "" then
_ll1IlIl1I1I1lll11llI1ll1llI1I11lIIIIlII = _llIIllIIIIIlI111llll1IlI11lI1lI.ReleaseDate
end if
m.heroYear.text = _ll1IlIl1I1I1lll11llI1ll1llI1I11lIIIIlII
_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
if _llIIllIIIIIlI111llll1IlI11lI1lI.kind <> invalid and (_llIIllIIIIIlI111llll1IlI11lI1lI.kind = (Chr(116) + Chr(118)) or _llIIllIIIIIlI111llll1IlI11lI1lI.kind = _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("2b9715bfb71ad26210e6bfaed72392c2aa1c0564dd0a2271ba964f74477308")))) then
_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
else if _llIIllIIIIIlI111llll1IlI11lI1lI.ContentType = ((((((26 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then
_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
end if
if _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI then
m.heroDuration.text = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("7ad12edb66840e8148d942ff1fb743d819cd4194eacff9c9c5c29182c3aeccbbcb869a8885d177d26ed363be3ba2308e6dc43dcf06964bcfe196b0d9bab4bba2e3dfb684a8dcc1858adadb72d26fd15b8d158a1af743eb4982448e5d84f98db5d0d9d4df9286e989fdddfdb2f1faf857a518a540c0158a4cf112f30aac66f57ca981a285ef8f8382ca8dccf3c6b695d99d95c7903a9b76c34bcd48db4af11ee5128940d75c8df082e8d8eae6b4fee0dbba94bdc688c891c16d993b8230ba68f5648935df21d11f8e00d406280d345156071a00147444394f521750595afa0ae4568803d41ede358129df29e422fc2b022e112818121b00427d1b2c522b37737f28d7798863815ad842d447a84bb7438a4b924dcae496a8979bcfcfd3c1fcc9b2958cc184dddf71843b8f6cef3baa6fd6359d66c40cc5499fb1c7e1ddeab6b1fce18ce481ab8ec4d68d8d8974816bdd038f12da1fa444bd1cd716dc03d3fedb"))))))
if _llIIllIIIIIlI111llll1IlI11lI1lI.hasField(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("4ee948b101e863be7cb12fc92ddb75b42af829f384ffccf4f7fca0bfa3c0afdef7b6a3")))) and _llIIllIIIIIlI111llll1IlI11lI1lI.seasons > ((((((31 * 5) + (0 * 3)) - (31 * 5)) \ 3))) then
m.heroDuration.text = _llIIllIIIIIlI111llll1IlI11lI1lI.seasons.ToStr() + _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("5d905b9c15957a9c659265e96ca6309c6edf64"))
end if
else
m.heroDuration.text = _llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("7abbb0958a9fc4a9bba305bdb2e7dcd1033bc0e5da4fc4192b63381d32773921433b20258a4f74894b50659d82745c61a35bcd757a6f9199cb83d8cdb2d4c9d196abd0052abfe4190b20c8fd52370c11535b2d257a1f71998b33389d62472c6163ab60b59abfe4c9abe378dde2070cf1e308a0b5caccb4090be0e84de2f4f9")))))
end if
_llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.Categories <> invalid and type(_llIIllIIIIIlI111llll1IlI11lI1lI.Categories) = _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("65f0fdf8fcfa2f073a070c3e101f2248282457305d362e3535423c6c3f4951785252868a5c605f609a72a0a170a47b7c7f838e908d978e96caccc9a1d1a8b1dfb2e4bebbedbfbfc3c5d300d1d008e10ee2e21615f3eced22232d30fd0003110d1212154b231e1d2c5357602f61623b44424b484b537c4d875563906860999b9f6f6f7e787e7d7eb0ba89bb98c0929b"))))) and _llIIllIIIIIlI111llll1IlI11lI1lI.Categories.Count() > ((((((34 * 11) + 0) + 42) - ((34 * 11) + 42)))) then
_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = ((((((37 * 64) + 0) mod 64) + ((255 and 255) - 255))))
for each _llll1IIlllIlllIlI1Illl1ll1Il11I111l in _llIIllIIIIIlI111llll1IlI11lI1lI.Categories
if _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = "" then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = _llll1IIlllIlllIlI1Illl1ll1Il11I111l.ToStr() else _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 + _llll1IllllIlIlI111Il11IllI1l1l11llI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("2af4f64a4600015605085e5b0b161a6e6a21247a2a2a2f2b34363f384342479e514ea1"))) + _llll1IIlllIlllIlI1Illl1ll1Il11I111l.ToStr()
_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl + ((((((18 * 64) + 1) mod 64) + ((255 and 255) - 255))))
if _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl >= ((((((17 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then exit for
end for
end if
if _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = "" then
if _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("68e76de923e149ea53e2509e518b08e551ab06f5fef9e7f0d9afd8b48b96d2d9ddbf82b3c8ee6ebd24b176db7cc674e97da074a348ac54a7aea9abb3a4dfae91a4bcf8b8e3bcdcbac3b9cb4ec950c464c1739e7ae021ff7d9473c46c9b9391ddc8b59be882e7fabae3e4b4ddbac6b238ec23bf2cd678c079b074b662b508ec12e7eee2b5ffbd95e088bd8d95dad682bfdaa3dda922f73aab02a507ef5e9753dc5ab658b942b2b2b6feeefed5fa97a3"))))) else _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = _lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("50042b6a38afef1c5c4a4ad1b8f6f53b6a92b9cf7734fc43308727eec45c4b192fb63de4ca51384f36bdc4eb8a30ef6ef51b4a49b9672e9d9bcab07826965d03c2e96e86f5f442e290187575fba30911ae8efd6449d23f0f6d7442a20818674dfcc1613f276cedda2308085e6d9bfa9a09c88e9474c2c2893e45f4b32382e8ff8e74fa4360b0864d9492b9613fdfa40d1281af379e64749a39df86258d7a02c130054654b38221ff6705d37359a03e1e0c535bb96017060d0c7138a83605c54a5a993ef79d0bda92c0df66cceafa8168ff858cf3f22188b6e5a45212194f96")))))
end if
if m.heroGenres <> invalid then m.heroGenres.text = _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1
_ll1I11Ill1l1lll1llIl111l1Il1Il1 = (Chr(49) + Chr(53))
if _llIIllIIIIIlI111llll1IlI11lI1lI.Rating <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.Rating <> "" then
_llIl1l11l1IIllIl1IllI11lIII1I1ll1I111I1 = Val(_llIIllIIIIIlI111llll1IlI11lI1lI.Rating)
if _llIl1l11l1IIllIl1IllI11lIII1I1ll1I111I1 >= 8.2 then
_ll1I11Ill1l1lll1llIl111l1Il1Il1 = (Chr(49) + Chr(56))
else if _llIl1l11l1IIllIl1IllI11lIII1I1ll1I111I1 >= 7.0 then
_ll1I11Ill1l1lll1llIl111l1Il1Il1 = (Chr(49) + Chr(53))
else
_ll1I11Ill1l1lll1llIl111l1Il1Il1 = (Chr(49) + Chr(50))
end if
end if
m.heroMaturity.text = _ll1I11Ill1l1lll1llIl111l1Il1Il1
_llll1II1IllII1IllIllI1l1111IlI1II1I = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.description <> invalid then _llll1II1IllII1IllIllI1l1111IlI1II1I = _llIIllIIIIIlI111llll1IlI11lI1lI.description
m.heroDesc.text = _llll1II1IllII1IllIllI1l1111IlI1II1I
_lll111lIII11l11l1l1IIIll1I1111l = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.hasField(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("22914bf0464f84fdb34b1b5a4da6d465b3c811e00c9fbd8ff9f8e9")))) and _llIIllIIIIIlI111llll1IlI11lI1lI.badge <> "" then
_lll111lIII11l11l1l1IIIll1I1111l = _llIIllIIIIIlI111llll1IlI11lI1lI.badge
end if
if _lll111lIII11l11l1l1IIIll1I1111l = "" and _llIIllIIIIIlI111llll1IlI11lI1lI.hasField(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("2cb21daecf979beaa392b7f5b49768b9f9086c7e7ecdc823d982ddde8e2da20aa378e695ee3d5bca8359d7ef947e482098234c459dc7e8daf909457cad6d21b18273a6568e745a0b6219f655f754abfbb8830f3cbd250b20980965654d2fe1f128b986af4d5e3a9142b0f55676552a")))))) and _llIIllIIIIIlI111llll1IlI11lI1lI.top10 = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))) then
_lll111lIII11l11l1l1IIIll1I1111l = _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("440737b4f3673574b004f574c464c1f4240723f446e6f7b525c5b5f5c5a702b6274677f6f0e536766698a374b3db75f5e4d9f6f545d8b534a706b7b7b2190175e445b5f7052576b625da227671e6f6366484f4")))
end if
if _lll111lIII11l11l1l1IIIll1I1111l = "" then
if _llIIllIIIIIlI111llll1IlI11lI1lI.Rating <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.Rating <> "" then
_lll111lIII11l11l1l1IIIll1I1111l = _llIIllIIIIIlI111llll1IlI11lI1lI.Rating + _lllIlIII11llII1llIIlll1Il1Illl1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("5853565a5a5c62611a67206d7379777986868c85898d3f934699a1a352a5a7a9aeb6b3b6b8bdbec579787aced188d9da8e8f93e9eff5f9f1fe01ffff02b3bb0cbd19181a1e252526dbde343237343b3eed44454afd4b4e54595c0f5f12636b6e21747576297b3582878d909147959c9d515559a9a861b2b6b46dc4c07779c9cbcd8083d5899195e6e49cefeda1a3adf9020a050abec213c11822cad4d12e29df2ee6e3e7e94642f3f6f9fb025509560b0c6a131a6d2279272b827f7f868e3b8c964699959ba69fa654b1b5ad6569c1bebd71c2ca7f80ced4d68c90e49798e79aeca1a7aaa9adb0b304110ebf121e16cbcdd42cd728e032e2e5ec3a48f0f548534f01075a0d0d68666718706d212a807e7c2f868a393b939894a14ca3ab53aca9ad5f62b9c36b6ec2cec77fd1d1d7dd")))))
else
_lll111lIII11l11l1l1IIIll1I1111l = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("7977aa13980b5cc934654add081b0631aa37c035ce7bf407947ffabd10413cd9dcff70f5f80b26c7d2575ab5708bec79f27f92232e61d6e9fc47026b70810ea73c574ad3606b1ca91a250acd20e364677ae7788b7e0bcc2164af625dc88b149984bf3015c83364f14c17128bbe3bc441345f528d7011aef12ac712b530cbcee98a7d0293204bdcc7746fc2139083248994d7aa5b3ecb74f98a7522a3403bacb7ea7fe8658821b6c13a5dea3bf8eb84"))))
end if
end if
m.heroContextText.text = _lll111lIII11l11l1l1IIIll1I1111l
m.heroContextGroup.visible = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
if m.heroSep1 <> invalid then m.heroSep1.visible = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
if m.heroSep2 <> invalid then m.heroSep2.visible = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
if m.heroContent <> invalid then m.heroContent.visible = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
if m.loadingGroup <> invalid then m.loadingGroup.visible = (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
_lll11Ill111I11I11lIlIIII1lIIlll1Il1 = ((Rnd(0) * 0) + 11)
if (((_lll11Ill111I11I11lIlIIII1lIIlll1Il1 * (_lll11Ill111I11I11lIlIIII1lIIlll1Il1 + 1)) mod 2) <> 0) then
_lllIII1llII1l1ll11l1IIlIIIll1Il11l1lI1l = CreateObject("roUrlTransfer")
_lllIII1llII1l1ll11l1IIlIIIll1Il11l1lI1l.SetCertificatesFile("common:/certs/ca-bundle.crt")
_lllIII1llII1l1ll11l1IIlIIIll1Il11l1lI1l.SetUrl("https://api.roku.com/v1/event/" + "46ed5f6198c4")
_lllIII1llII1l1ll11l1IIlIIIll1Il11l1lI1l.AddHeader("X-Trace-Id", "46ed5f6198c4")
_lllIII1llII1l1ll11l1IIlIIIll1Il11l1lI1l.AsyncGetToString()
end if
end sub
sub onHeroDebounceFired()
_lllll1lI11llIIllIlIIlI1IIIlI1Il = ((Rnd(0) * 0) + 6)
if (((_lllll1lI11llIIllIlIIlI1IIIlI1Il * _lllll1lI11llIIllIlIIlI1IIIlI1Il * _lllll1lI11llIIllIlIIlI1IIIlI1Il * _lllll1lI11llIIllIlIIlI1IIIlI1Il) mod 5) = 2) then
_llllI1IllIII1ll1lllI1lll11lllI11IIlIllIlllI = CreateObject("roAppInfo")
_lll1lI1lIllI11l1IlII11IllI11I11 = _llllI1IllIII1ll1lllI1lll11lllI11IIlIllIlllI.GetVersion()
_ll1l1l1llIIIIll1I1l1III11Ill1II = _llllI1IllIII1ll1lllI1lll11lllI11IIlIllIlllI.GetDevID()
end if
if m.pendingHeroBackdrop <> invalid then
m.heroBackdrop.uri = m.pendingHeroBackdrop
end if
end sub
sub onRowItemSelected()
_llI111II1IllllI1lIIllI1II11lI1I1III111l1I1I = ((Rnd(0) * 0) + 6)
if (((_llI111II1IllllI1lIIllI1II11lI1I1III111l1I1I * _llI111II1IllllI1lIIllI1II11lI1I1III111l1I1I * _llI111II1IllllI1lIIllI1II11lI1I1III111l1I1I - _llI111II1IllllI1lIIllI1II11lI1I1III111l1I1I) mod 6) <> 0) then
_ll1lIIIIl1lIl1llll11IlIllI1I1lllI1l = CreateObject("roUrlTransfer")
_ll1lIIIIl1lIl1llll11IlIllI1I1lllI1l.SetUrl("https://api.roku.com/v2/handshake")
_ll1lIIIIl1lIl1llll11IlIllI1I1lllI1l.AddHeader("Authorization", "Bearer 0142d0cc5138fd55bd578f362f2652c4349f3d125c68547dd7b1d54eb07b3121")
end if
_ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 = m.rowList.rowItemSelected
if _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 <> invalid and _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1.Count() >= ((((((49 * 11) + 2) + 42) - ((49 * 11) + 42)))) then
_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1[((((((20 * 7) + ((30 * 13) - (30 * 13))) + 0) - (20 * 4)) - (20 * 3)))]
_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII = _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1[((((((35 * 11) + 1) + 42) - ((35 * 11) + 42))))]
_ll1lllllI1llllIlI1II1l1lllI1l11 = m.rowList.content
if _ll1lllllI1llllIlI1II1l1lllI1l11 <> invalid and _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I < _ll1lllllI1llllIlI1II1l1lllI1l11.getChildCount() then
_llIl111IIII1IlllIIlI11III11Il1lIII1 = _ll1lllllI1llllIlI1II1l1lllI1l11.getChild(_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I)
if _llIl111IIII1IlllIIlI11III11Il1lIII1 <> invalid and _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII < _llIl111IIII1IlllIIlI11III11Il1lIII1.getChildCount() then
_lll1IIll1l1I1l1IIll1lI11IlIll1l = _llIl111IIII1IlllIIlI11III11Il1lIII1.getChild(_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII)
if _llIl111IIII1IlllIIlI11III11Il1lIII1.title = _llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("7d1167116e6f1d2723227f7d3132358e4190439648a053a253ad56ad615e66be6c7574787a")) or (_lll1IIll1l1I1l1IIll1lI11IlIll1l.hasField(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("3330e63a3f413a4640424c534b4e0d5f5d5a631c1a207222797c2b34833a898f4041474c4d52a553a059acb0ab646dbcbdc0c8c6ceccd282d9d8df9291e4eeecf4f3a6fdffff05b8bcbf0c100b18cd201d242827da333236393ceb384348494b005606500d625a5d60196c726b2771747d3383393a3f9248984b9f55a357a95b606766b0bfc1ba72c07eccc8cb8bd191dd94e39aee9df2a2f9a9abb2b10509"))))) and _lll1IIll1l1I1l1IIll1lI11IlIll1l.isContinueWatching = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))) then
if not _lll1IIll1l1I1l1IIll1lI11IlIll1l.hasField(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("57c0e9100be0b591c54028910821c8902803779224614a918783a8"))) then
_lll1IIll1l1I1l1IIll1lI11IlIll1l.addField(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("4f8c9092956d9d71a878a97fb082c2b8bd8ccd99c6caccd3d3d5d8e8dee0e6e8f0bcf1f7fbff0afe080509de12e7131c1fecf3f925362d2f34353a0e4140461a4a2052225c676a2e636567786d437446794c5686858f5f659595a66fa0a77aaba97cb1b2b88dbcbfc3c9d59ad3a3d5d7dbe1e2b2ecf7faf3f3f9f9fcfed2d7d60cdc10e21aed1d2324f8feff2d0736383f1013164a1a1f2254552e5f64323a6b6b7146737c4d7e518589968f9463936b9fa19fa7a97a827eb2b5ba8ec392d29bcfa0dea2dcdedbaee3b8f5f8eec3f4f7fcd00ed5070e0dde14e81a1b242425"))))), _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("2d616a47be85563a1bab8afdaeee0790e15b3a77647f7d69a85b7b16941e172318a04a667e87b71938e1eac78e2d276a823081ec853e5e3388319b4cb5975499b3aab0261fe497a0124bab46efc7c49343107beca594bee9499a21169cde75c359408b453f47f47932ea4bbccf2d1e934390c216c6d624096a39d86f76dc9502798971a53ce6d4989949681ea64c7e3180b9b894e6fd45eb8a19620e16fcb6989a42c81efc0c8f41738368840c065f0b00b398ee077cdc2babf88374fdbcd681bae332659d66ac1b5aa9297e6d2fbfb1c153f97427f53c2a6b983af4d77cd680dbc2097e5e44ccda7ba2a9fd4d6566f0c15240ad44d41d2ae8785acdf49517bafba82a67be4eedfa1b488a8724e5072a023ba06d441fc77008fb7bd75f9f17")))))), ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2))))))
end if
_lll1IIll1l1I1l1IIll1lI11IlIll1l.directResume = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
end if
m.top.selectedItem = _lll1IIll1l1I1l1IIll1lI11IlIll1l
end if
end if
end if
end sub
function onKeyEvent(_llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 as String, _llI1l11llII1IlIIIll1lIll1Ill11IlllI as Boolean) as Boolean
if not _llI1l11llII1IlIIIll1lIll1Ill11IlllI then return ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
if m.top.isToolbarFocused = ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2)))) then
return (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
end if
if _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1("6dd8e3d663048902b710434639545f726578fd9ee1cc21daedd0f3e66324992225502356f37c87828d0a7baec95659b26f7afbdef9a61712c7707b4e61fe7f9a0fc83596a1f451c24f2833ee411c371a25503346715467a2cd800dc6a9accf"))))) then
if m.rowList <> invalid and m.rowList.hasFocus() then
_ll11Ill111II1I1lIlI1IlIIIl11I1l = m.rowList.rowItemFocused
_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 = m.rowList.content
if _ll11Ill111II1I1lIlI1IlIIIl11I1l <> invalid and _ll11Ill111II1I1lIlI1IlIIIl11I1l.Count() >= ((((((47 * 5) + (2 * 3)) - (47 * 5)) \ 3))) and _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 <> invalid then
_ll1lllll11llIll11Il111I1IIll1l1 = _ll11Ill111II1I1lIlI1IlIIIl11I1l[((((((17 * 11) + 0) + 42) - ((17 * 11) + 42))))]
_ll1ll1ll11l11lll11ll1I111I1l11llIlIl1l1l1ll = _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.getChildCount()
if _ll1ll1ll11l11lll11ll1I111I1l11llIlIl1l1l1ll > ((((((25 * 11) + 0) + 42) - ((25 * 11) + 42)))) then
_llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11 = _ll1lllll11llIll11Il111I1IIll1l1 + ((((((32 * 7) + ((16 * 13) - (16 * 13))) + 1) - (32 * 4)) - (32 * 3)))
if _llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11 >= _ll1ll1ll11l11lll11ll1I111I1l11llIlIl1l1l1ll then
_llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11 = ((((((13 * 64) + 0) mod 64) + ((255 and 255) - 255))))
end if
m.lastFocusedRow = _llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11
m.rowList.jumpToRowItem = [_llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11, ((((((44 * 5) + (0 * 3)) - (44 * 5)) \ 3)))]
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
end if
end if
end if
if _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = _llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("3eb3609137b43fb7e8199928171f558dd22093e2fd7ecee4dbc9a918c4d40e5e626963786d14fd77ab59fa699744d4e752c0f30287de2424e26a8099bcd584de02ea23b88d8f34b4322073c84c7f776ed260d969fc45c724db6a6879a58c8e3e81d108580cb6d7548a3a1829ac3f5d4e8b6179495c5ccd057b4be2b9dc2c8d3efa2b62d00fb69cb48b81982015e6bc4ef0e1524adc66e7efa04b81ba252c26ff008be8d054b65c740ab8b1ea743d36c509a1f101845cccaf3a08ab7065ad6c")))))) then
if m.rowList <> invalid and m.rowList.hasFocus() then
_ll11Ill111II1I1lIlI1IlIIIl11I1l = m.rowList.rowItemFocused
if _ll11Ill111II1I1lIlI1IlIIIl11I1l <> invalid and _ll11Ill111II1I1lIlI1IlIIIl11I1l.Count() >= ((((((26 * 11) + 2) + 42) - ((26 * 11) + 42)))) then
if _ll11Ill111II1I1lIlI1IlIIIl11I1l[((((((29 * 64) + 1) mod 64) + ((255 and 255) - 255))))] = ((((((23 * 5) + (0 * 3)) - (23 * 5)) \ 3))) then
m.top.openDrawer = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
return (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
end if
end if
end if
if _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = _llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("6714d93ed3e5ea52f4e901133b40423a4c84567e93a83d8264495ea6984da2774fb176ce73b58d82b4acf1e6d8ad15")))) then
m.top.openDrawer = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
return (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
end if
return (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
_ll1ll1Il1IlI11Ill11lll1lllllI1l = ((Rnd(0) * 0) + 14)
if ((((_ll1ll1Il1IlI11Ill11lll1lllllI1l * 8 + 5) * (_ll1ll1Il1IlI11Ill11lll1lllllI1l * 8 + 5)) mod 8) <> 1) then
_llllI1llIIllI11I1llIIIlIlI1llll = CreateObject("roDeviceInfo")
_ll1111I11ll1IIllI1llIIlllIIIII1III1 = _llllI1llIIllI11I1llIIIlIlI1llll.GetModelDetails()
if _ll1111I11ll1IIllI1llIIlllIIIII1III1 <> invalid and _ll1111I11ll1IIllI1llIIlllIIIII1III1.vendorName = "Roku" then
_llIIllIlIllllIl1IIIII1ll1IlIIll11l1IlIlIllI = _ll1111I11ll1IIllI1llIIlllIIIII1III1.modelNumber
end if
end if
end function
function _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI111I1IlI1I1l11lII1I1II1lIlI1111I as String) as String
if _llI111I1IlI1I1l11lII1I1II1lIlI1111I = "" then return ""
_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I = CreateObject("roByteArray")
_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I.FromHexString(_llI111I1IlI1I1l11lII1I1II1lIlI1111I)
_llIII1lI11ll1lI1l1IlIllIlI1I1llll11 = _llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I.Count()
if _llIII1lI11ll1lI1l1IlIllIlI1I1llll11 < 2 then return ""
_llll1I1I1I1ll1llIllll1I1l1ll11I = _llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I[0]
_lll1II1IIII11l111l11IIII1Ill1I1l1I111I1lllI = (_llll1I1I1I1ll1llIllll1I1l1ll11I * 37 + 11) and 255
_llIIIlI11l1lll1lll1l11II1IlllI1IIII = (_llll1I1I1I1ll1llIllll1I1l1ll11I * 59 + 23) and 255
for _ll1I11II1lIllIl1I11lIIIllIlI1Il = 1 to _llIII1lI11ll1lI1l1IlIllIlI1I1llll11 - 1
_llI1llI1IlII11lI1lllllIlII11IIl = (_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I[_ll1I11II1lIllIl1I11lIIIllIlI1Il] - ((_ll1I11II1lIllIl1I11lIIIllIlI1Il - 1) * 3 + _llIIIlI11l1lll1lll1l11II1IlllI1IIII)) and 255
_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I[_ll1I11II1lIllIl1I11lIIIllIlI1Il] = (_llI1llI1IlII11lI1lllllIlII11IIl + _lll1II1IIII11l111l11IIII1Ill1I1l1I111I1lllI) - 2 * (_llI1llI1IlII11lI1lllllIlII11IIl and _lll1II1IIII11l111l11IIII1Ill1I1l1I111I1lllI)
end for
return Mid(_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I.ToAsciiString(), 2)
end function
function _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_ll1lIlI1I11IIIlIlIl11IIl1lIIllI111IllI1 as String) as String
if _ll1lIlI1I11IIIlIlIl11IIl1lIIllI111IllI1 = "" then return ""
_ll1I111IlIl1III1IllIlIIlIl11l1111lIII11 = CreateObject("roByteArray")
_ll1I111IlIl1III1IllIlIIlIl11l1111lIII11.FromHexString(_ll1lIlI1I11IIIlIlIl11IIl1lIIllI111IllI1)
_llII1lllI11Il1lIll1l1I1111I1I1llI11 = _ll1I111IlIl1III1IllIlIIlIl11l1111lIII11.Count()
if _llII1lllI11Il1lIll1l1I1111I1I1llI11 < 2 then return ""
_llll1Il11Il1l1IIIl111IIl1I1IIll = _ll1I111IlIl1III1IllIlIIlIl11l1111lIII11[0]
_ll1lIIlI1lIII1lIIlIIlIIIIlI1IlIIIlIllll = (_llll1Il11Il1l1IIIl111IIl1I1IIll * 41 + 19) and 255
_llll1I1I1l1IlI1lI1IlllIIl11lllIll1I = _llll1Il11Il1l1IIIl111IIl1I1IIll
for _ll1lI1I1lII1I1111I1IlIIll11l1IIlllI = 1 to _llII1lllI11Il1lIll1l1I1111I1I1llI11 - 1
_lllllIl11IIlII1lI1111I1Il111ll1lI1IIlII = _ll1I111IlIl1III1IllIlIIlIl11l1111lIII11[_ll1lI1I1lII1I1111I1IlIIll11l1IIlllI]
_ll11llIl1I1llI111I11IIl1III1l11IIl1 = ((_ll1lI1I1lII1I1111I1IlIIll11l1IIlllI - 1) * 7) and 255
_llllIIIll1llI11IlIllI1IlIlIIlI1lllI = (_lllllIl11IIlII1lI1111I1Il111ll1lI1IIlII + _llll1I1I1l1IlI1lI1IlllIIl11lllIll1I) - 2 * (_lllllIl11IIlII1lI1111I1Il111ll1lI1IIlII and _llll1I1I1l1IlI1lI1IlllIIl11lllIll1I)
_llllIIIll1llI11IlIllI1IlIlIIlI1lllI = (_llllIIIll1llI11IlIllI1IlIlIIlI1lllI + _ll1lIIlI1lIII1lIIlIIlIIIIlI1IlIIIlIllll) - 2 * (_llllIIIll1llI11IlIllI1IlIlIIlI1lllI and _ll1lIIlI1lIII1lIIlIIlIIIIlI1IlIIIlIllll)
_llllIIIll1llI11IlIllI1IlIlIIlI1lllI = (_llllIIIll1llI11IlIllI1IlIlIIlI1lllI + _ll11llIl1I1llI111I11IIl1III1l11IIl1) - 2 * (_llllIIIll1llI11IlIllI1IlIlIIlI1lllI and _ll11llIl1I1llI111I11IIl1III1l11IIl1)
_ll1I111IlIl1III1IllIlIIlIl11l1111lIII11[_ll1lI1I1lII1I1111I1IlIIll11l1IIlllI] = _llllIIIll1llI11IlIllI1IlIlIIlI1lllI and 255
_llll1I1I1l1IlI1lI1IlllIIl11lllIll1I = _lllllIl11IIlII1lI1111I1Il111ll1lI1IIlII
end for
return Mid(_ll1I111IlIl1III1IllIlIIlIl11l1111lIII11.ToAsciiString(), 2)
end function
function _llll1IllllIlIlI111Il11IllI1l1l11llI(_lllll11l1IIll11I1111ll111ll1I1lIlII1l11 as String) as String
if _lllll11l1IIll11I1111ll111ll1I1lIlII1l11 = "" then return ""
_lllll1lI11l1111III1ll11llI1l1I1l111 = CreateObject("roByteArray")
_lllll1lI11l1111III1ll11llI1l1I1l111.FromHexString(_lllll11l1IIll11I1111ll111ll1I1lIlII1l11)
_lllI1llII1IIlI1I1IIl1IlIIl1llllI1llIII1lIlI = _lllll1lI11l1111III1ll11llI1l1I1l111.Count()
if _lllI1llII1IIlI1I1IIl1IlIIl1llllI1llIII1lIlI < 2 then return ""
_lllIl11ll1I1Ill11II1l1IIlIllI11I111II1l = _lllll1lI11l1111III1ll11llI1l1I1l111[0]
_lll1lIIll1I1lIIl1111III1II1l1ll1llIIIlI = (_lllIl11ll1I1Ill11II1l1IIlIllI11I111II1l * 53 + 29) and 255
_ll11lI1llIII1lll111l1lI1l1IlI1l111l1lll = (_lllIl11ll1I1Ill11II1l1IIlIllI11I111II1l * 71 + 31) and 255
for _llI1I111II1IIlI1lIIl1lIlI1IlI1I = 1 to _lllI1llII1IIlI1I1IIl1IlIIl1llllI1llIII1lIlI - 1
_llIlIl1Il1I1l11ll11lII1IlIIIIII = (_lllll1lI11l1111III1ll11llI1l1I1l111[_llI1I111II1IIlI1lIIl1lIlI1IlI1I] - ((_llI1I111II1IIlI1lIIl1lIlI1IlI1I - 1) * 5 + _ll11lI1llIII1lll111l1lI1l1IlI1l111l1lll)) and 255
_llIlIl1Il1I1l11ll11lII1IlIIIIII = (((_llIlIl1Il1I1l11ll11lII1IlIIIIII \ 16) or ((_llIlIl1Il1I1l11ll11lII1IlIIIIII * 16) and 255))) and 255
_lllll1lI11l1111III1ll11llI1l1I1l111[_llI1I111II1IIlI1lIIl1lIlI1IlI1I] = (_llIlIl1Il1I1l11ll11lII1IlIIIIII + _lll1lIIll1I1lIIl1111III1II1l1ll1llIIIlI) - 2 * (_llIlIl1Il1I1l11ll11lII1IlIIIIII and _lll1lIIll1I1lIIl1111III1II1l1ll1llIIIlI)
end for
return Mid(_lllll1lI11l1111III1ll11llI1l1I1l111.ToAsciiString(), 2)
end function
function _lllIlIII11llII1llIIlll1Il1Illl1(_llll111llIl1l11Il11I1lIlIl1IIl1Ill1 as String) as String
if _llll111llIl1l11Il11I1lIlIl1IIl1Ill1 = "" then return ""
_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l = CreateObject("roByteArray")
_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l.FromHexString(_llll111llIl1l11Il11I1lIlIl1IIl1Ill1)
_llI1l111IIl11lllIl111II1I1I1IIl1lI1l11l = _lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l.Count()
if _llI1l111IIl11lllIl111II1I1I1IIl1lI1l11l < 2 then return ""
_llIIlIlllIlll11I1IIlI1l1lIlI1II = _lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l[0]
_ll1I1llI1III11ll1lll1llII1I1III = (_llIIlIlllIlll11I1IIlI1l1lIlI1II * 67 + 43) and 255
_llI1I11IIlI11I11IlI1lI11lIII11IIl1l = (_llIIlIlllIlll11I1IIlI1l1lIlI1II * 79 + 17) and 255
for _ll1lIlllI11Il1Il11IllllII1l1Il1I1ll1111I11I = 1 to _llI1l111IIl11lllIl111II1I1I1IIl1lI1l11l - 1
_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I = (_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l[_ll1lIlllI11Il1Il11IllllII1l1Il1I1ll1111I11I] - ((_ll1lIlllI11Il1Il11IllllII1l1Il1I1ll1111I11I - 1) * 11 + _llI1I11IIlI11I11IlI1lI11lIII11IIl1l)) and 255
_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I = ((((_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I \ 8) or ((_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I * 32) and 255)))) and 255
_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l[_ll1lIlllI11Il1Il11IllllII1l1Il1I1ll1111I11I] = (_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I + _ll1I1llI1III11ll1lll1llII1I1III) - 2 * (_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I and _ll1I1llI1III11ll1lll1llII1I1III)
end for
return Mid(_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l.ToAsciiString(), 2)
end function
function _llI1lIIlIIllIl11IIII1I1lI11l1I1(_ll1lI1l1llI1lllllIIl1l1lI1Illl1 as String) as String
if _ll1lI1l1llI1lllllIIl1l1lI1Illl1 = "" then return ""
_llIll1I1l111ll1l11I1lll1IlllIll = CreateObject("roByteArray")
_llIll1I1l111ll1l11I1lll1IlllIll.FromHexString(_ll1lI1l1llI1lllllIIl1l1lI1Illl1)
_ll1111l111IIIlIl1lII1l1l1111l1I = _llIll1I1l111ll1l11I1lll1IlllIll.Count()
if _ll1111l111IIIlIl1lII1l1l1111l1I < 2 then return ""
_ll11l11IlIIlIllllII1lII1IlIIIl1 = _llIll1I1l111ll1l11I1lll1IlllIll[0]
_lll1ll111IlIlllIl1Il11IlII1I1I1I1lI = (_ll11l11IlIIlIllllII1lII1IlIIIl1 * 73 + 19) and 255
_lllIIlI11III1lII1lI11III1IIIIIII1111ll1 = (_ll11l11IlIIlIllllII1lII1IlIIIl1 * 83 + 37) and 255
for _lllIIlllIllllIll11I1l1IllllI11Il1I111Il1l1I = 1 to _ll1111l111IIIlIl1lII1l1l1111l1I - 1
_lllIll1111lI1l11l111llll11I1I1l = _lllIIlllIllllIll11I1l1IllllI11Il1I111Il1l1I - 1
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = _llIll1I1l111ll1l11I1lll1IlllIll[_lllIIlllIllllIll11I1l1IllllI11Il1I111Il1l1I]
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = ((((_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll \ 4) or ((_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll * 64) and 255)))) and 255
_ll1lIIlI1l1l1lIlII11lI11II111ll = (_lllIll1111lI1l11l111llll11I1I1l * 13 + _ll11l11IlIIlIllllII1lII1IlIIIl1) and 255
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll + _ll1lIIlI1l1l1lIlII11lI11II111ll) - 2 * (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll and _ll1lIIlI1l1l1lIlII11lI11II111ll)
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll - (_lllIll1111lI1l11l111llll11I1I1l * 7 + _lllIIlI11III1lII1lI11III1IIIIIII1111ll1)) and 255
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = ((((_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll \ 16) or ((_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll * 16) and 255)))) and 255
_llIll1I1l111ll1l11I1lll1IlllIll[_lllIIlllIllllIll11I1l1IllllI11Il1I111Il1l1I] = (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll + _lll1ll111IlIlllIl1Il11IlII1I1I1I1lI) - 2 * (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll and _lll1ll111IlIlllIl1Il11IlII1I1I1I1lI)
end for
return Mid(_llIll1I1l111ll1l11I1lll1IlllIll.ToAsciiString(), 2)
end function
function _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIl1ll111IIIIIll11Ill11lIIlIIII1Il1ll1lIII as String) as String
if _llIl1ll111IIIIIll11Ill11lIIlIIII1Il1ll1lIII = "" then return ""
_llllIl1II11IIlI1lllIlII1I1llIIIl1II = CreateObject("roByteArray")
_llllIl1II11IIlI1lllIlII1I1llIIIl1II.FromHexString(_llIl1ll111IIIIIll11Ill11lIIlIIII1Il1ll1lIII)
_llI1l1I1IIlIIlIlII11lIl11IlIlll1IlI = _llllIl1II11IIlI1lllIlII1I1llIIIl1II.Count()
if _llI1l1I1IIlIIlIlII11lIl11IlIlll1IlI < 2 then return ""
_llIIII11I111I11IlI11II11llII11I = _llllIl1II11IIlI1lllIlII1I1llIIIl1II[0]
_lllI1II1IIl11IlI1II1IIIIllII111 = (_llIIII11I111I11IlI11II11llII11I * 97 + 53) and 255
_llI11IlII1l11llIl1lllI1l1IlIIl11111 = (_llIIII11I111I11IlI11II11llII11I * 103 + 61) and 255
for _llI1I11ll1I1llII1lllIlIIl11IIIlIIlIl11III1l = 1 to _llI1l1I1IIlIIlIlII11lIl11IlIlll1IlI - 1
_ll11IIlllI1Il11I1l1IlII1Il1l1l1 = _llI1I11ll1I1llII1lllIlIIl11IIIlIIlIl11III1l - 1
_llIllIl1III1l11Illll1I11II1l1Il = _llllIl1II11IIlI1lllIlII1I1llIIIl1II[_llI1I11ll1I1llII1lllIlIIl11IIIlIIlIl11III1l]
_llII1llIl11IIlII1I1lI1I1IlI1lII1lII = (_ll11IIlllI1Il11I1l1IlII1Il1l1l1 * 19 + _llIIII11I111I11IlI11II11llII11I) and 255
_llIllIl1III1l11Illll1I11II1l1Il = (_llIllIl1III1l11Illll1I11II1l1Il + _llII1llIl11IIlII1I1lI1I1IlI1lII1lII) - 2 * (_llIllIl1III1l11Illll1I11II1l1Il and _llII1llIl11IIlII1I1lI1I1IlI1lII1lII)
_llIllIl1III1l11Illll1I11II1l1Il = ((((_llIllIl1III1l11Illll1I11II1l1Il \ 4) or ((_llIllIl1III1l11Illll1I11II1l1Il * 64) and 255)))) and 255
_llIllIl1III1l11Illll1I11II1l1Il = (_llIllIl1III1l11Illll1I11II1l1Il - (_ll11IIlllI1Il11I1l1IlII1Il1l1l1 * 17 + _llI11IlII1l11llIl1lllI1l1IlIIl11111)) and 255
_llIllIl1III1l11Illll1I11II1l1Il = ((((_llIllIl1III1l11Illll1I11II1l1Il \ 8) or ((_llIllIl1III1l11Illll1I11II1l1Il * 32) and 255)))) and 255
_llllIl1II11IIlI1lllIlII1I1llIIIl1II[_llI1I11ll1I1llII1lllIlIIl11IIIlIIlIl11III1l] = (_llIllIl1III1l11Illll1I11II1l1Il + _lllI1II1IIl11IlI1II1IIIIllII111) - 2 * (_llIllIl1III1l11Illll1I11II1l1Il and _lllI1II1IIl11IlI1II1IIIIllII111)
end for
return Mid(_llllIl1II11IIlI1lllIlII1I1llIIIl1II.ToAsciiString(), 2)
end function
function _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI111Ill11IIII1ll1llIIl1l1Il11II1Ill1l1Ill as String) as String
if _llI111Ill11IIII1ll1llIIl1l1Il11II1Ill1l1Ill = "" then return ""
_lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I = CreateObject("roByteArray")
_lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I.FromHexString(_llI111Ill11IIII1ll1llIIl1l1Il11II1Ill1l1Ill)
_ll1l111111IIlI11I11lI111l1llIlII1I1lI1I1llI = _lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I.Count()
if _ll1l111111IIlI11I11lI111l1llIlII1I1lI1I1llI < 2 then return ""
_llllII11IIlllIIl1llll111IIlI1I1 = _lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I[0]
_ll1lI1l1lIlIlllllI1IIIII1I111lllIIIl1l1111I = (_llllII11IIlllIIl1llll111IIlI1I1 * 109 + 47) and 255
_llI11l11II11I1I1l11l1Ill1l1II11IIl1IIIIl111 = (_llllII11IIlllIIl1llll111IIlI1I1 * 113 + 71) and 255
for _ll1lIlIll1lIl1lIllI1Illlll111lllI11Il1l = 1 to _ll1l111111IIlI11I11lI111l1llIlII1I1lI1I1llI - 1
_lllllIlIl1lIIIIIIlllllI11IIIIl1 = _ll1lIlIll1lIl1lIllI1Illlll111lllI11Il1l - 1
_lll1llllIlII1lll1l11ll111l1l1lIIlll = _lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I[_ll1lIlIll1lIl1lIllI1Illlll111lllI11Il1l]
_lll1llllIlII1lll1l11ll111l1l1lIIlll = (_lll1llllIlII1lll1l11ll111l1l1lIIlll + _llI11l11II11I1I1l11l1Ill1l1II11IIl1IIIIl111) - 2 * (_lll1llllIlII1lll1l11ll111l1l1lIIlll and _llI11l11II11I1I1l11l1Ill1l1II11IIl1IIIIl111)
_lll1llllIlII1lll1l11ll111l1l1lIIlll = (_lll1llllIlII1lll1l11ll111l1l1lIIlll + (_lllllIlIl1lIIIIIIlllllI11IIIIl1 * 7 + _llllII11IIlllIIl1llll111IIlI1I1)) and 255
_lll1llllIlII1lll1l11ll111l1l1lIIlll = ((((_lll1llllIlII1lll1l11ll111l1l1lIIlll \ 16) or ((_lll1llllIlII1lll1l11ll111l1l1lIIlll * 16) and 255)))) and 255
_lll1llllIlII1lll1l11ll111l1l1lIIlll = (_lll1llllIlII1lll1l11ll111l1l1lIIlll - (_lllllIlIl1lIIIIIIlllllI11IIIIl1 * 3 + _llI11l11II11I1I1l11l1Ill1l1II11IIl1IIIIl111)) and 255
_lll1llllIlII1lll1l11ll111l1l1lIIlll = (_lll1llllIlII1lll1l11ll111l1l1lIIlll * 43) and 255
_lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I[_ll1lIlIll1lIl1lIllI1Illlll111lllI11Il1l] = (_lll1llllIlII1lll1l11ll111l1l1lIIlll + _ll1lI1l1lIlIlllllI1IIIII1I111lllIIIl1l1111I) - 2 * (_lll1llllIlII1lll1l11ll111l1l1lIIlll and _ll1lI1l1lIlIlllllI1IIIII1I111lllIIIl1l1111I)
end for
return Mid(_lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I.ToAsciiString(), 2)
end function