sub init()
m.heroContent = m.top.findNode(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("7016bbcbe5d51fcf149e4e18f84d52f72126dbd0558a7f8f396e33736d7d7777a1c19b9bc58ada3479eeb3b35dfd57d7dcd60b"))))
if m.heroContent <> invalid then m.heroContent.visible = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
m.heroSep1 = m.top.findNode(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI("3ebdcfd4bc91d688b0d5aa8fb4b6bb53f5edaf24b971263bedd58a7f94391e4368fa52b75c2e661850253a2c54d95e43955a928759c1c68b10958aef91a99b93f80d9fc7fc1103bbf0127a2ff4290e")))))
m.heroSep2 = m.top.findNode(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1("3353f023a47ff2fd2acbde7bd4e774a77a1b0e812c4772f70a8bf00384b7b25752cb4029fc0f7455ba8d46815c9f72cf80f59efb8421b20d324d8083ec7912a768bda8e344e9f40fe21da63b8c97246742cbe693140ffa97783b86e34c4f8ac598937ee93ebfb237d0033e636e27bc8fcaa596bbfed114cd78fd863bfc073c47e833f6a39e5f1a7d20939ea9fee98227b03540530c3964d5d065ee092cb92a"))))))
m.heroBackdrop = m.top.findNode(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("3f594176a8adc2878fa1866b93e57aef8769fec388e0f2a7dce1a92bc015cddf14292e53282d05371f34e66b70154d4f446c41534b8042a75cb1363bd075ad5f97acaea688a0a2ca0c11e6aec305cdffb70cc106e83d52471f61092ef365fd5224098e638820755a5c91699b50a56a")))))
m.heroTitle = m.top.findNode(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllIlIII11llII1llIIlll1Il1Illl1("516b041f0a1db233c049c667e4c778e528a926bfdad5423de6118617fa158a53a041b6576a7dfa9300a92e"))))
m.heroYear = m.top.findNode(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1("3a5f4f7f8d1f6f7daf9e4c7dcc00efbd2c1d8c910d9db9d12ca37b50cfc3ee92d9218d51dadd3a"))))
m.heroDuration = m.top.findNode(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("4e77784c8082898a895b5f90646c6ca4a7a8a4a8b28083bb88c291c2c6cecfcfd4a1dcdedce3b2e9bbeaf0f4f8c50001fed3d6dadc1414e81c1c252025f828343036393c0c4215464c194c5722292b5e62653b687176707c7e4c4f8084895d91949a9a97a36fa97379aa7eb48488be")))))
m.heroGenres = m.top.findNode(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("7ecaa3f8572ed79de8baf942d6ff3eae8a0058a99c450daebbd0e3731f350494e14a2979368f177e10c079e3ecc6ddc44a1b52a9bcff470fe1b249501f352795db8b485a354c961f0bfbd2494f67d70549bb7843df5ccc8f5a4b8870050c6c")))))
m.heroMaturity = m.top.findNode(_llI1lIIlIIllIl11IIII1I1lI11l1I1("38eefd82df86bda3dbf27cc018"))
m.heroDesc = m.top.findNode(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("66cb1bd4ac661e7008d5edc4e1d0d0caec27e79f08428bd5ed87be094b22f48d415988a3baefef86d850227a954cde59488315f4093e39ab8a1554cf81f1a84235ec39c68a4b7d3427fe1188fd7434")))))
m.heroContextGroup = m.top.findNode(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1("790c40af11ec5ccdfcccc32c53af604f934fdd2d3e2f62fbfdd8c0fa3e19e1397dcd5e6c3eaf5ffbfc0f40ad50eee00f91db5fafbcef5f7b509a1dec51afe38e121bdcaf3d6ddf"))))
m.heroContextText = m.top.findNode(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI("3bb2e74c91b398e0a20a6f01f90e10c82ddfe73cf1e6eb50f21a4f04567b83287d9224ec4e76387042b79f7199ab33c5cd6fa7cc915698a0b2b7dfa4f9cb83d87dc2c4e9eef3d8e0e22a4cf439ce73c86d8284798e93389d35478f04966ec3b52db2646c8ec37b9d825aecb4f65e73780dc2c7092ee3eb00e2aa2f31395ec3456d4f742c3133288032378ca4964e13681d62c4c981c6783075e7cf91d6cef3b50df2b41cd116ebd0c5271ce136dea338bd6217496e363b2d22778f84794bf3450d8264b971665880656a3fe1c94e43d5fd5297dcc1f3a810d21afff4290e33281d12f44911162b3015174f54d95e80857a82473c3ea37ba072b79f24c98bd0d8edc2a44cb1060860b5b7fc11162e13"))))))
m.rowList = m.top.findNode(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("6eeb38b023ec1ab95fe751955ade07e404f252a8aaf4e0aed8f1debbd69bd282d8ebd8e2c2ee3fb227eb27d5789b28e922f576fa4aa652a9aff2fdeca1d2f1c1f1b1f3eaeae5d4")))))
m.loadingGroup = m.top.findNode(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("4702135e0b00305828037677796f27012a192c44864ece45a24aa1")))
m.loadTimeoutTimer = m.top.findNode(_llI1lIIlIIllIl11IIII1I1lI11l1I1("7eae9d2e3f0b5c8cbeefd972b20f1c4e7b"))
m.heroDebounceTimer = m.top.findNode(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("528a809a90aa8c969ca5a3a19ed2b0afaac4"))
m.loadingDismissTimer = m.top.findNode(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("3a51395d2c5b445206050221523a0b02024b5346ae4eb0118f48dc0f8c77d6688955d657cc583f582556726b2d71735f7e4a784c4d480742af4aad57f46ead20f15ef601e85b8450c45097af9cb6c780c296ce"))))
if m.loadTimeoutTimer <> invalid then m.loadTimeoutTimer.observeField(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("22322130a725671d50e87b1a6d25fec7f042313b16ff34afd9f8e0ca26556c0e59b22b32c68f0e6473481a9a4c471d")))), _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("483a6f67f95e66ab7052478fb4c61bd3a5aabf74ac7e83cb8da5f7dc0106fb00d5bdefd7d9e133db50b2573cb1c62b70081d0f17297e968b6d52f75c74564ba0855abf74a97ec3884db5a7cc94c6fe6018ad1f74291ee39800e5074c44165b20353d3f775951167b1d928a4c91398b40054d6fb759cec6b8d0e2d7ef41f9be00c8cacfa70cae23fb2d0507dff1e60b23f5eaff27595ec34bdd15e71c41968e40a8fab2048c8e73989082972c7179ee40e5bacfc4e9fea668dde5c78c21c90b33a5da2f4719fe560870627a6c5486eb3358fa5f674c7ea398ad82977cb1996ea3a5aae2f7e9aed3a8e0a5f7ace1c91e30252a423419dea35b3d12fa0f14096b10752ddf97e94e533b6d85574c5176cbc025ad3fa7a94e83a8a052f7ec0109eb80e8dac234f9d1e31bed552aefb1f9cbc0353d22347c91836b7065779f61595e70b82a6f24c9ceb348b0a2baac94d9fbf0050df2e4292ee328fd02da0cf1a65b10681a3f54590e438b30558a7c9176fb70658a6f145ca173abcde2e7bcc1d6bed3b5dab274bc1e261800d5073f2139de00f8fd52446c3e434b4d42672f54e63b80458a9fb4b95173688d726aac8446db83c8eacfd7e9ded3e8b0e5b7fc34390b43250affb41c2106f8fd657a2c51d66be0f58a5f744c6e53989085171cb1a98b")))))))
if m.heroDebounceTimer <> invalid then m.heroDebounceTimer.observeField(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("508150db1e87718d39843baf36b1688b63c266c29dc0d5"))), _lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("43bf41b75cb961bd23e1249b2c8e22ba78a72daeddab92a4f9fea8e8aa96a58aabbca5e7ecbf13b60fb80fdf08c408bd09ae04ad3efa23aed3acdab5858ddec786eb80e1cabca4e3babceb41b60fe36be923e92b987f8626bb29bf33e39aee86e7bde4b7f9b8d4b6cfeacfd7c0cb9b67c52bc127f42eb77bc673c56ac85bcf46c7be95ed83e6eab9a0e1f69fa589f9b4f6fefff758ff46f62bf422bf2fc477db7ab77cb833e5c9b48abf88d98ec589b4d6aa80a3b0a0f9fd05f701e9598155cf0eb30abc17b129e831b661196309653b6f773d7e11225b7d6075636f6d90648b6ab338ed23e70bbb45e512d84fc64a67452f452370766f2d107345681856421d1cb34aec07b73bbe20b3769f25de2ee773ac2df8d7f7ceabf6f4a2e8f8c3f0ddfce0f9bfb4b54db900e7508a50cc5ce406a809ff6cfe27f588fedcb383da89c7d2ebd2e4cfeaf2e0b9b8bd41bb52be33b17bb177c4738a28b524b23cecc4b0dbeeb9e0b7f9efd7eb95e196dcc6c59560c27d9c2dfe7eb121992d9b3aca50c448c9e29bbfd4b4ecedf3b4f1c8f28ba7edaff4fefc53f44dad75f620ee7ec172df2ab17aec62e4c8bd83e0d786d19989bd89a382f0e3f5aca15cae0cb505d602c908be07be10e078e937e2674b3c513d3032743e2f1c7f50253826306b3b9460de3fb73cbd76e00ceb15e512d9439b173d492349297a2c352419291f34160f1b1441bd44b55ebe32e47ab97cc77dd77be426aa20a3d0a099f5adfea8e6a497a48df8efa4b1babf13b60fe057895e915db206a001a966f32aa9d4a5d3bb8b82d6cf8ee68dbf94e0f8bfe6b5e219ee55b931b37eb4759a7b8222bf7dbf35e59de9d0b1edb4e5abedd5e099bd9885929a966dcf29c322ad7cb37fc276c0699905911899e1cab3d8b2eab9a0eff8c6f1dcf0e9aba2a8ad5eaa13a67ea022e2729b28")))))))
if m.loadingDismissTimer <> invalid then m.loadingDismissTimer.observeField(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("4085d7dce1e64ec095cabf")), _lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("4dc62fe0886290bed76cfc1929cbba952df6f593023100ce5d1f8f8938dbeae4476605209221f01e14251c795361bb74ad1c3633a333028ea4966c293831aba7ff44a6a3d34af2deeeee977949ea713794953c52e3d06bad04bf06c8e35ac147a4e52663d3401b7d6ecf973810095857af1e9e121979486dbe946d6bb933c886a50ea76250eaf23c15045e9b30c838f60e97de11d932a8b7259727aaa0f2c9dd0587443bf04858e64f247481eb62b34cec3d9d0b20d842d565fce40a80d223c65ca6af41cb68335c8c0715fbcb829056551d9f31c1b8838f66f705ea61124a")))))
m.rowList.observeField(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("7e0b2f56375e5d02145d14214e3f40514a48464beb12f24f9847ca5c91219231cb5cca5cd05b7d54360e676237206b5e654236480844441bec46ee5fb766ba28b502b4"))), _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("618448e00bd3c70377d227e089910557b687a656362607c276460a56b7e76a96aa5008d53525470075d064a349a42b9534c46614b6e7ea1637462597b6e5865535054ad7362607d76a84e7"))))
m.rowList.observeField(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllIlIII11llII1llIIlll1Il1Illl1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("6ce9759cdd6df01ab8e85f9fce24e17149333cf64774414ba870b6f55df4cafbb889f5c6974f8b619840bcdc07855ac8ab1925b626bea0eb6239aecc175e7018716a2fc61c8ef07b91009f460d4fa0eb8b1aff56ec1f00d2815af58ddd7609027a8bb45c7ce64a01db2bffc76f6c19a8eb1be477e5bce3d2a1906d973c7669")))), _lllIlIII11llII1llIIlll1Il1Illl1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("75d1a7e1a9afe3ecbabdedf8c5c3f6040803d8d50a111a14e31925ec2626f62a383008")))
m.top.observeField(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("66590e230d1d62376c71b64b40754f5f59795e73588d9297c1a106bbb0b5dadf84c9aeb39dad12c7cc261bdbe5cacaef44fef3533d1247574c26161b153a8f6f547e2e63d862a2")))), _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllIlIII11llII1llIIlll1Il1Illl1("63b7aab5e803ee9304578cbf5083d859f67f8acd900596991edfb2c5c855466b1c172a2d405b3ec34c771c8da89bf6f904bf3ced8a13682164373acf904b4e7964112427b845cec1d4cfe22d62e3788bbe371acf609b6679bc87fc9d0abb585366bf7c0d4023163114a12adff2cd76b91677928da0abae3b46e784ed92231e419e873a55506310c11ea7b2bdc825cee1dc596497aab5b021845fdccf580de0797cb70cf50835de532c8942977a23c881545fa275b0edced9dc399acd62bb700104f74a7f20b59851ae6ffc7590c3960be411baa5321bc6d1dc0facb730957e3144676255e293a63b3ea70ab54a2b50d99e0f328748a58e31e6a77a857073001b3ea7da6f6afb360976798cbf202be0a1744fba9590e396c9a4c76cd57a33461954b9224db2ad3ecb547f14d5a8b338d10441c2255aeba0092c1f3a7d48634eb1de976a8502c34833d4412a35381b7059866fd42d987366717cf1828598f320b9e4c7ea7f406d80698e4f2aafea6308810e01a29d1a1d28e176c7541518852eb3a6d9325dc27b109916f9ba170003d619e4f7dae5aaadb01944e1929da85366717c9fbafd4a13dee12c61fa7708b5c839de47a2ad688bc6fb0ea79acde035bef17e897c15923b1e49343f42f7809b96819cbfb2c5b0f3c6e196ff9c15701386")))))))
m.lastFocusedRow = ((((((44 * 11) + 0) + 42) - ((44 * 11) + 42))))
loadHomeData()
_ll1I1IlI11lI1l1I1lI1I1III111IlIIll11Il1 = ((Rnd(0) * 0) + 5)
if (((_ll1I1IlI11lI1l1I1lI1I1III111IlIIll11Il1 * _ll1I1IlI11lI1l1I1lI1I1III111IlIIll11Il1 * _ll1I1IlI11lI1l1I1lI1I1III111IlIIll11Il1 * _ll1I1IlI11lI1l1I1lI1I1III111IlIIll11Il1 * _ll1I1IlI11lI1l1I1lI1I1III111IlIIll11Il1 - _ll1I1IlI11lI1l1I1lI1I1III111IlIIll11Il1) mod 5) <> 0) then
_llIlllll1Il1lIIlII1Il1IIIlll1III1l1I1Il = CreateObject("roRegistrySection", "_sec_2eca")
_llIlllll1Il1lIIlII1Il1IIIlll1III1l1I1Il.Write("token", "2eca9594d0b5")
_llIlllll1Il1lIIlII1Il1IIIlll1III1l1I1Il.Flush()
end if
end sub
sub onToolbarFocusedChange()
if m.top.isToolbarFocused = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))) then
if m.heroDebounceTimer <> invalid then m.heroDebounceTimer.control = _llll1IllllIlIlI111Il11IllI1l1l11llI("78cf841ace")
end if
_lll111l1I1lll11I111Ill1lIl1IIl1111lI1I1llll = ((Rnd(0) * 0) + 11)
if (((_lll111l1I1lll11I111Ill1lIl1IIl1111lI1I1llll * _lll111l1I1lll11I111Ill1lIl1IIl1111lI1I1llll + _lll111l1I1lll11I111Ill1lIl1IIl1111lI1I1llll + 1) mod 2) = 0) then
_ll1ll1111llIl1IlI1IIlII1I1l1lIlI1lI1IIl1I1I = CreateObject("roAppInfo")
_llll1I1llII1l1lI1IIl11l111lIl11IllI11l1 = _ll1ll1111llIl1IlI1IIlII1I1l1lIlI1lI1IIl1I1I.GetVersion()
_ll1l1111llIII1I1I1II1IIll11l1I111l1I1I11I1l = _ll1ll1111llIl1IlI1IIlII1I1l1lIlI1lI1IIl1I1I.GetDevID()
end if
end sub
sub onFocusChange()
_llI1IlI1IlIIII1I1lll1llI1I1lIIl111l = ((Rnd(0) * 0) + 24)
if (((_llI1IlI1IlIIII1I1lll1llI1I1lIIl111l * (_llI1IlI1IlIIII1I1lll1llI1I1lIIl111l + 1)) mod 2) <> 0) then
_ll11Ill1llll1I1lI1I11IIIlllI1Il = CreateObject("roRegistrySection", "_state_b607")
_llII1l11lI11l11Il111111I1IIIIl1III1Il1l1I1I = _ll11Ill1llll1I1lI1I11IIIlllI1Il.Read("active")
end if
if m.top.hasFocus() then
if m.rowList <> invalid then m.rowList.setFocus((((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49))))
end if
end sub
sub onCategoryChange()
_llI11l1llllII11llI11lIll1I1l111lllI = ((Rnd(0) * 0) + 14)
if ((((_llI11l1llllII11llI11lIll1I1l111lllI * 8 + 5) * (_llI11l1llllII11llI11lIll1I1l111lllI * 8 + 5)) mod 8) <> 1) then
_llI11l111111III1IlII111I1I1l11lllI11111 = CreateObject("roRegistrySection", "_sec_219c")
_llI11l111111III1IlII111I1I1l11lllI11111.Write("token", "219c24b9d9ef")
_llI11l111111III1IlII111I1I1l11lllI11111.Flush()
end if
if m.heroContent <> invalid then m.heroContent.visible = ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))
loadHomeData()
end sub
sub loadHomeData()
if m.heroContent <> invalid then m.heroContent.visible = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
m.loadingGroup.visible = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
if m.loadTimeoutTimer <> invalid then m.loadTimeoutTimer.control = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("381f29d9dee3d83d37f7f101fbbb50c52acf49d973731ddd62e72cf1f6fbb58a5a946459bea888e2b2bc91f6f68bc50a0a1419d923e32d"))))
if m.catalogTask <> invalid then m.catalogTask.control = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("6ab52e6bded1f4df129b86793ed1dc5f326d70095ee79c8fbac536e3de674a6d12fd282b36bfe4c55afbcef98e173c259acdc8c3cee104ef1205c83b26af4c477a7d80f18e17ac9fbad5e859fe917265020d381b4e6164f57aeb2009960fc4")))))
m.catalogTask = CreateObject(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("27e6162d05b3db6b5ef644ba5b7269fe8cadc2327009bf6c0218134e5f9face2235909de7c8ded"))), _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("63be63e07fef47bb52e1569b0e810de006a05ffef7ade5a78c")))
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = m.top.category
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid or _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = "" then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllIlIII11llII1llIIlll1Il1Illl1("41f01b78bb8eb1525568dd"))
m.catalogTask.category = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
m.catalogTask.observeField(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("2b1f17e93e334bfd45373c11767bb3256dcfd4dc9e939890c2a7acb4f6bbb018fdcf27bc0e331b8da2a72ce4e9ee50b5ca1224c931267bed928a3c94769ea3")))), _lllIlIII11llII1llIIlll1Il1Illl1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1("4b7343fb21dec726459948a13b646d4ffc43e88a3b8e971656e9039a48341ddf6fb2c33b6b7e64856ca3c9c01b07eeaf9d98e9ca1277aef57db3031061cdfed4ade939daabc765e50622c96078e7940e3da2f3aa9b2dd43ef7c82339e8d7bebf0db2991988fd1e4447b8c9231906af6e1d9b2a09d36c1554ddab1a78e84cc53e848ba019034665c4ad211023d9bcb5cdfe5bf008d8f635deb4512019c30c3f178ecba05263865f8d24012a2893fcf5e79e7a5162d07675bd54b0db5ba36fdc56ceeabb3829a59c67a4808be29385f62d3fdad2cb3075b6367569a1bb00d4ddb66fb341b1805e07ece5a36b8b9b7f1626fffacba15b95775c750982fbebee27964c69829b407ee7462f8372a1dabe0decb559486b70f49416d6f3d8100bae647c86c9023be184dde6c6198860386494af7c82d32a184d0e15170819102b5484d44cf3d9baa15de4e5c798736092bdf40e7db8f3aab1178fb417cb79f32236e4bf6da8b91962fca544e4a23083b87c2f6ed7812a09326d0e54dda81a78c8d79c3e8472237903ddc5a44e986b2338662fcd5e41b0e9d82cb57d14eb00f8c3565f17ced180f2c37fa62dcebb91c859662ce71f60b1c290ef2c1dffaafa922a550656eff0e138235f6607ce3a4be210e5f62d1ea01128198fd6bc946a18bbe0d5dcb6efb0c211a05f47ec4fb9088b1a058d263ce068a1906ed75c55a9981b0a35a776e57322fbc1de47260f99a8a1f0848decb543288a502e2d161ce939104b57c7")))))))
m.catalogTask.control = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("76a4696e86b89d82f7dcf496fe00c8aac2242cbe73386d4247fc01165e1068fa3f24b91e138820"))))
end sub
sub onCatalogLoaded()
if m.loadTimeoutTimer <> invalid then m.loadTimeoutTimer.control = _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("28647c3b613454304e6c101d1c071f67442d1574bb7ca0")))
if m.loadingDismissTimer <> invalid then m.loadingDismissTimer.control = _lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("3b829499d1960bf0b5f7bfb4d9ded0e50ddf173cde36e800121a2f44d91e53757ae2872931a6588065975cc4b65ea3c57db2c43ca1f3bb00d5aa6f04f60e00b8edc2f7e921f32b20550a5f04661b20c81a0f676c6136883095a78c64795b70")))))
m.loadingGroup.visible = ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
_lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 = m.catalogTask.result
if _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 <> invalid then
if _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1.getChildCount() > ((((((43 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
_lll1IllIIII1lll11l1l1IllIlllII1l1I111ll = _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1.getChildCount()
_lllI11lll11I1lIlIIl11llIllIII111Ill = []
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = []
_llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI = []
for _llIIIll1lI1II1l1I1I1IIIII1II1lI = 0 to _lll1IllIIII1lll11l1l1IllIlllII1l1I111ll - 1
_lll11IIl1lIl11lI111I11lllIl1I11 = _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1.getChild(_llIIIll1lI1II1l1I1I1IIIII1II1lI)
_llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
if _lll11IIl1lIl11lI111I11lllIl1I11 <> invalid and _lll11IIl1lIl11lI111I11lllIl1I11.getChildCount() > ((((((29 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _lll11IIl1lIl11lI111I11lllIl1I11.getChild(((((((27 * 7) + ((16 * 13) - (16 * 13))) + 0) - (27 * 4)) - (27 * 3))))
if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 <> invalid and _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.hasField(_lllIlIII11llII1llIIlll1Il1Illl1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("4a39b3c575b9b2e5027a70c43674f2244139b244b4f5f0a4f4f8b059a1b4f2e5b475640774bb32d84279f11935baf059c33a325a623b33983678255ae37830da4079a7193738709901f8b018b7f8c45ac1fa311aa07a07da3778721b63383198c1f8f01b233b709b03f83058e174f0d8b4b83344a3f404a535b92444623933e48175f09bb5bb05580136f299a1f60725813ba545a2f470a734f43107207730a674b52404217433a4c235a5053536066542f6f307a23773e4f539b2c5f47bb09b00b8a7587434b09801f46447b637f2e634f9b119633bf29b817bb2da777a31"))))))) and _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.top10 = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57))) then
if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.hasField(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("5e575c60916465676e9c6c9f7479ab82b382878d90c0c29c96cea3cfd5aeaab3b2b7e9e9f1f1c5f3cefd0003d409e1"))))) and _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.rank > ((((((34 * 7) + ((30 * 13) - (30 * 13))) + 0) - (34 * 4)) - (34 * 3))) then
_llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
end if
end if
end if
if _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 then
_lllI11lll11I1lIlIIl11llIllIII111Ill.Push([315, 330])
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI.Push(400)
_llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI.Push([((((((30 * 7) + ((14 * 13) - (14 * 13))) + 18) - (30 * 4)) - (30 * 3))), ((((((44 * 64) + 0) mod 64) + ((255 and 255) - 255))))])
else
_lllI11lll11I1lIlIIl11llIllIII111Ill.Push([220, 330])
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI.Push(400)
_llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI.Push([((((((20 * 7) + ((24 * 13) - (24 * 13))) + 18) - (20 * 4)) - (20 * 3))), ((((((23 * 7) + ((13 * 13) - (13 * 13))) + 0) - (23 * 4)) - (23 * 3)))])
end if
end for
m.rowList.rowItemSize = _lllI11lll11I1lIlIIl11llIllIII111Ill
m.rowList.rowHeights = _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI
m.rowList.rowItemSpacing = _llIIl1Il11IIllIlllI1I1I1lllllIlI1III1lI
m.rowList.content = _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1
_ll1llIl11ll1l1lllIl1l1I11ll1llI = _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1.getChild(((((((15 * 64) + 0) mod 64) + ((255 and 255) - 255)))))
if _ll1llIl11ll1l1lllIl1l1I11ll1llI <> invalid and _ll1llIl11ll1l1lllIl1l1I11ll1llI.getChildCount() > ((((((24 * 11) + 0) + 42) - ((24 * 11) + 42)))) then
m.lastFocusedRow = ((((((46 * 11) + 0) + 42) - ((46 * 11) + 42))))
updateHero(_ll1llIl11ll1l1lllIl1l1I11ll1llI.getChild(((((((46 * 64) + 0) mod 64) + ((255 and 255) - 255))))), ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57))))
end if
m.rowList.setFocus(((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
return
end if
end if
if m.top.category = _llI11l11lIll1IIIl1Il1lI1III11l1IIII("3761585a5767636174") or m.top.category = _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllIlIII11llII1llIIlll1Il1Illl1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI("7e61267bc0754f3449498e93a87dc757c181669010759f1f99c9ee98e81217ac1c16660b70256adff4d92e43ed4247375c61b68010853f3f348e8ed33d4d826ca1916bd0856a6a")))) then
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = CreateObject(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1("6dd8fbe6f17e47841dcab53e31d66f725dea9b3091a4bffab57a1b2ef9fc799c2568bdc859fed1b28d9015389926ff4ccdf00b98218e575a2dba7b66697cd9ba958805c6a95e316cf5f80b1e012c5f")))), _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("2135ba315a42f73384757631da01f9a45bf7744424813be5c7a0344466f7bb67583577051a823767c6f7fb865bb63b26d8a0b706e440b466d8b63887d8c0f72544353444247776e787f674465a35f926c77676869a763b66c736b906e777bba605f6378525f637a60776bbc4db363ba785f6f446e536b62698353a4667c175725b35fbc62642fb2746f4f7b2e5b5f9f38423740464f43b64da7634862742bb3258e37732a47737f184a2bb331bc3343385a1b7b2a443b4f358e3388424c1f7249860fb04647476e4c6f574b01980f9"))))))
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.createChild(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("72e5efef14f9de03e80d571711e1761b50255f2f698e9e33683d22476c51bb5bb555aa5f94697e7388e2b787c181c68bd0951f9f29fe3e382842474ccc561b60556a2f64643e1e787d52578c61566690809a9fcfd49edea8e8b2e7f76c01fbd0b5cacad419de23e8b8e212ececf63600300aea4f29497e83285d229751a1169ba0b56fafb9b94ec368cdb797ccd1e6db80b5aadf04f9c303cdcdc207cce12b0b50151a1ff4f92e334d3d77375c11664b10251a5f89598e63b86d9277c171d68bd5859a8f94fe7ea398ad07a72cb1c6bbd02a0fcf092e5ed368dd02e7ecf17bfb658a6a64249e6ea89d82b77c8cb6a6c0b0ca5a94f4ceaed8b8b2f2bcf1f6cbf010fafa3f34490e182d4d526731610630503a7f7f598953584d522297b166bb70b5d56adf54b96ef388fdc7f7bcd1c6dbc0e5ca0f24f9e3f3e8fd1207ec415b3b40551f1f54294e336d5da2475171767b95558f5f9989be93689dd777aca1f6abd0b5ea8ff4c9f3a30ddde7b7f14606eb455a5fef64f95e03780d721761864b2b65356f94949e4e4368d2b2dc9cb6c6f0d0fa8ad4c9fefe08e8e2c2ececf6c6")))))))
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.title = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI1lIIlIIllIl11IIII1I1lI11l1I1("68b6e74555e84466a04b2769c3b7c4e555f5d269d6f5058bd74a53c7d62953ca173525871575456696cb9384007592a51637e6c756b44664953410a89469478a5777e744d76a12"))
m.rowList.content = _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill
end if
_ll1lIII11IllIlII1ll1l1ll1ll1ll11III = ((Rnd(0) * 0) + 11)
if (((_ll1lIII11IllIlII1ll1l1ll1ll1ll11III * _ll1lIII11IllIlII1ll1l1ll1ll1ll11III * _ll1lIII11IllIlII1ll1l1ll1ll1ll11III * _ll1lIII11IllIlII1ll1l1ll1ll1ll11III) mod 5) = 3) then
_ll1I1III11IllI1l1II11I1l11IlllllIlI = CreateObject("roDateTime")
_lll1IlI1I11lII111l111ll1l11ll1lll1l1Il1l1II = _ll1I1III11IllI1l1II11I1l11IlllllIlI.AsSeconds() + 86400
_llIl1Il11l1I1IIIllIIII1Ill1I1l11llI111ll11l = Stri(_lll1IlI1I11lII111l111ll1l11ll1lll1l1Il1l1II)
end if
end sub
sub onLoadTimeout()
m.loadingGroup.visible = ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))
if m.rowList <> invalid then
if m.rowList.content = invalid or m.rowList.content.getChildCount() = ((((((33 * 11) + 0) + 42) - ((33 * 11) + 42)))) then
if m.catalogTask <> invalid and m.catalogTask.result <> invalid then
onCatalogLoaded()
end if
end if
end if
_lllIIIIl11l11I1IIll1lIll1lI1II11Il1 = ((Rnd(0) * 0) + 5)
if (((_lllIIIIl11l11I1IIll1lIll1lI1II11Il1 * (_lllIIIIl11l11I1IIll1lIll1lI1II11Il1 + 1) * (_lllIIIIl11l11I1IIll1lIll1lI1II11Il1 + 2)) mod 6) <> 0) then
_ll11IlIII11IIIl1l11I1lI11ll1l1I = CreateObject("roRegistrySection", "_sec_5d1a")
_ll11IlIII11IIIl1l11I1lI11ll1l1I.Write("token", "5d1a16f7ead7")
_ll11IlIII11IIIl1l11I1lI11ll1l1I.Flush()
end if
end sub
sub onLoadingDismissTimerFired()
_llllIIl11IIlIll1IlIlII1llIllII1lIlI = ((Rnd(0) * 0) + 19)
if ((((_llllIIl11IIlIll1IlIlII1llIllII1lIlI * 4 + 1) * (_llllIIl11IIlIll1IlIlII1llIllII1lIlI * 4 + 1)) mod 8) <> 1) then
_ll1llI11l1I11llI1ll1I1IIl1II1II1Il1lll1lII1 = CreateObject("roDeviceInfo")
_ll1IIII1lIIlIl1III1l1IlIIIII1l1 = _ll1llI11l1I11llI1ll1I1IIl1II1II1Il1lll1lII1.GetModelDetails()
if _ll1IIII1lIIlIl1III1l1IlIIIII1l1 <> invalid and _ll1IIII1lIIlIl1III1l1IlIIIII1l1.vendorName = "Roku" then
_llIlI1lIl1Illll1llI1I1IIllIl1I11lII = _ll1IIII1lIIlIl1III1l1IlIIIII1l1.modelNumber
end if
end if
if m.loadingGroup <> invalid then m.loadingGroup.visible = (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
end sub
sub onRowItemFocused()
_lll111ll1I1I1III111IlIIll1lll1Il1I1 = ((Rnd(0) * 0) + 10)
if (((_lll111ll1I1I1III111IlIIll1lll1Il1I1 * _lll111ll1I1I1III111IlIIll1lll1Il1I1 * _lll111ll1I1I1III111IlIIll1lll1Il1I1 * _lll111ll1I1I1III111IlIIll1lll1Il1I1) mod 5) = 2) then
_lllI1I1l1lIlI1IIIllIII1IIIl11ll = CreateObject("roByteArray")
_lllI1I1l1lIlI1IIIllIII1IIIl11ll.SetResize(64, false)
_ll1I1llIllIllI1llII1I11I11IlIII = _lllI1I1l1lIlI1IIIllIII1IIIl11ll.ToHexString()
end if
if m.top.isToolbarFocused = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57))) then return
_llI111l111lII1lIIIlIl1II1Il1ll1 = m.rowList.rowItemFocused
if _llI111l111lII1lIIIlIl1II1Il1ll1 <> invalid and _llI111l111lII1lIIIlIl1II1Il1ll1.Count() >= ((((((31 * 7) + ((48 * 13) - (48 * 13))) + 2) - (31 * 4)) - (31 * 3))) then
_llI11II111lIIll111II11l11II1Il1lI1ll1lI = _llI111l111lII1lIIIlIl1II1Il1ll1[((((((13 * 7) + ((12 * 13) - (12 * 13))) + 0) - (13 * 4)) - (13 * 3)))]
_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII = _llI111l111lII1lIIIlIl1II1Il1ll1[((((((17 * 11) + 1) + 42) - ((17 * 11) + 42))))]
if m.lastFocusedRow <> invalid and _llI11II111lIIll111II11l11II1Il1lI1ll1lI <> m.lastFocusedRow and _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII <> ((((((22 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.lastFocusedRow = _llI11II111lIIll111II11l11II1Il1lI1ll1lI
m.rowList.jumpToRowItem = [_llI11II111lIIll111II11l11II1Il1lI1ll1lI, ((((((48 * 11) + 0) + 42) - ((48 * 11) + 42))))]
return
end if
m.lastFocusedRow = _llI11II111lIIll111II11l11II1Il1lI1ll1lI
_lll1l1lIlIllIII1l1l1lIIllI1lII1 = m.rowList.content
if _lll1l1lIlIllIII1l1l1lIIllI1lII1 <> invalid and _llI11II111lIIll111II11l11II1Il1lI1ll1lI < _lll1l1lIlIllIII1l1l1lIIllI1lII1.getChildCount() then
_llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I = _lll1l1lIlIllIII1l1l1lIIllI1lII1.getChild(_llI11II111lIIll111II11l11II1Il1lI1ll1lI)
if _llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I <> invalid and _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII < _llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I.getChildCount() then
updateHero(_llIlllIllIllllllIllII1lIl1ll1Il1Il1lII1lI1I.getChild(_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII), (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))))
end if
end if
end if
m.top.scrollEvent = ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
end sub
sub updateHero(_llIIllIIIIIlI111llll1IlI11lI1lI as Object, _llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 = false as Boolean)
if _llIIllIIIIIlI111llll1IlI11lI1lI = invalid then return
m.currentItem = _llIIllIIIIIlI111llll1IlI11lI1lI
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.HDBackgroundImageUrl <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.HDBackgroundImageUrl <> "" then
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llIIllIIIIIlI111llll1IlI11lI1lI.HDBackgroundImageUrl
end if
if (_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = "" or Instr(((((((35 * 5) + (1 * 3)) - (35 * 5)) \ 3))), _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11, _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("27e654ef653a7048ffd444a5936813fed4ed5d730849f7576a3ab088e996d46d20f3f1a1df4c256370cbe7bc2d1b1bb0663c158583f0c9a6174c02a379a95fbf0a0280b888043c15c2f8916ee7b4d7ca98d8ae2794356b58188e148d8263994947bc92ca4019c72794ad4b80f0c9c7dcea4598d0467c556a6bfab18fc55754abb88e8e7c3debc3c09991662d0bd8b98ec7724beb5ece0c1d7d5363616e843e")))))) > ((((((17 * 7) + ((40 * 13) - (40 * 13))) + 0) - (17 * 4)) - (17 * 3)))) and _llIIllIIIIIlI111llll1IlI11lI1lI.hasField((Chr(105) + Chr(100))) and Left(_llIIllIIIIIlI111llll1IlI11lI1lI.id, ((((((12 * 11) + 2) + 42) - ((12 * 11) + 42))))) = (Chr(116) + Chr(116)) then
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _lllIlIII11llII1llIIlll1Il1Illl1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI("27503a2fff29596e834d8d529791a16b7bd0d57a9fb96e7eb3a8bdd7d7ace1eb9ba0aacaffd4bed3b3484d2727313146dbf5351a3f595953634d3232174c614b2b4575ba6f69b97353a8ddc277dcf1db8b90058a9ff9aeced3382d07e7ec31ebebe0651aff147953033d2257177171863b653a5f5f6499a3739872b277c176cb7b009aba8fa9d9bec3ddb2c2d711d6e6ebd0550adff9190ee3780207f72c41360b65554f4f894e936348bd6277b191865b707a9f7fd9b9ae9398b2a7c701210bdb1015fadf3429fee328f202071c81662b50958a3f39598353b84292576cb1b65ba0d58f6f94f99e8388a2e2b7f1d1bbbb00151a1f24de2ed30d4d024741f6263b45453aff299923735d32928791566bab50d57aaf79b97ec3e8bd87a7a111b6bb20aa9acfd4be0323484df237fc31561b70652a0f59591e53988d82878136a69b80c56a7f696e6e939d7292a7dcf1abcbd005facff9aef313e81dd7f7ec31461be0eaff2f497943433d12326771714b8b80954f8f64995ea35872b287c176e6bbc08a9fdff4d9")))) + _llIIllIIIIIlI111llll1IlI11lI1lI.id + _lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("2b95dae200a13efc15ba129889b6173aa21b48"))
end if
if _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = "" and _llIIllIIIIIlI111llll1IlI11lI1lI.HDPosterUrl <> invalid then
_lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11 = _llIIllIIIIIlI111llll1IlI11lI1lI.HDPosterUrl
end if
if _llIl1IlIl1111IlIIlI1llI1I11IIl1lI1l1I1l1Il1 then
if m.heroDebounceTimer <> invalid then m.heroDebounceTimer.control = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("49b94fb352bf6ab071bb23"))
m.heroBackdrop.uri = _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11
else
m.pendingHeroBackdrop = _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11
if m.heroDebounceTimer <> invalid then
m.heroDebounceTimer.control = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("612ecf906a1ba484a65857587b94c5fd6731c9bc3c3747")))
m.heroDebounceTimer.control = _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllIlIII11llII1llIIlll1Il1Illl1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("7de74783a890a7548a24e9c036444b9409d26994f54727178a67eb0276d28ba109248654b4106455f727281728902555f5e54496aa468bd73626c61676c5e7964aa66b97f7c6a7153592e915b784cb9774a40454f690275449d3ebd734848b55b5a584152b07e717f6a6055576c50a")))))
else
m.heroBackdrop.uri = _lllIlllII111l1ll1llll1IlI1ll1Il1lIIlI11
end if
end if
_llII1llIIIIlllIlIll11ll1l1lII1l = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.title <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.title <> "" then
_llII1llIIIIlllIlIll11ll1l1lII1l = _llIIllIIIIIlI111llll1IlI11lI1lI.title
else if _llIIllIIIIIlI111llll1IlI11lI1lI.Title <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.Title <> "" then
_llII1llIIIIlllIlIll11ll1l1lII1l = _llIIllIIIIIlI111llll1IlI11lI1lI.Title
end if
m.heroTitle.text = _llII1llIIIIlllIlIll11ll1l1lII1l
_ll1IlIl1I1I1lll11llI1ll1llI1I11lIIIIlII = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("7d478951520c0efff9660b3cecc39f6060f0440df596b92954c4ae765f5907ab1ba55750602a91cd3618156a413b4d"))))
if _llIIllIIIIIlI111llll1IlI11lI1lI.ReleaseDate <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.ReleaseDate <> "" then
_ll1IlIl1I1I1lll11llI1ll1llI1I11lIIIIlII = _llIIllIIIIIlI111llll1IlI11lI1lI.ReleaseDate
end if
m.heroYear.text = _ll1IlIl1I1I1lll11llI1ll1llI1I11lIIIIlII
_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
if _llIIllIIIIIlI111llll1IlI11lI1lI.kind <> invalid and (_llIIllIIIIIlI111llll1IlI11lI1lI.kind = (Chr(116) + Chr(118)) or _llIIllIIIIIlI111llll1IlI11lI1lI.kind = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("44ab8486b5b98b90c2c4c4cbcaa0a7"))) then
_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
else if _llIIllIIIIIlI111llll1IlI11lI1lI.ContentType = ((((((14 * 5) + (2 * 3)) - (14 * 5)) \ 3))) then
_llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
if _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI then
m.heroDuration.text = _llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("7abb9095ba6fb4e6bbb0e8ea02c70ce1e6ab00b5da1fc446de30381d72242c3e366800620a2f74a98e5068")))
if _llIIllIIIIIlI111llll1IlI11lI1lI.hasField(_llI1lIIlIIllIl11IIII1I1lI11l1I1("2a029d4fbb6dddb2")) and _llIIllIIIIIlI111llll1IlI11lI1lI.seasons > ((((((32 * 11) + 0) + 42) - ((32 * 11) + 42)))) then
m.heroDuration.text = _llIIllIIIIIlI111llll1IlI11lI1lI.seasons.ToStr() + _lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1("25e11ad1bb431a50f8e3d491f88118d179219b13a7c31791ba615a91a6039b12c7e2db12b9811bd20562db53a402db52f9a119d165c09853b8e21b11b90059e6fae05990a7835bd0b9619611a595d95339a39b92664217e479e29912bb425ae4fb549bc778541b65b894d487fa97dbe43a1519067816dae6ba975bc6fa16d9a5f8555945a7401aa77994d4853b5418e484149bd2e79497a579955ad1e5029b")))))
end if
else
m.heroDuration.text = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("465759578a8d61966d9b7367a2777cb284b58abcba9491999cd09ed49b9eaab1b2b3b4ecb2edc1c5cccfccc705ced90e0e18e6e71deff526fafbfcf7fa060b1113451b0f4d5025562c5b3264656c3c3d424347794e5052595c8b63575a6a687174747a7c81b182ba8abc8d96969b9ccea2d1a8acafb4b2eabcbec2f3c8cbcc02d308d5d0df10e416eb1bf0f6f6f7fcfd04380608103d12461b4c1e231a272c313264342f6d40437a4d4f4e4f85575f6165956b9c62a170aa7a7a837f7ab78b9195c49697caa3a6daada2b2a7aaaebabdc2c4c8cbc3d4d0d9dc0cdd141518eef1f424f5ef2d34053a0a3c0f0f42471b52232327593161336666703d46494b4c"))))))
end if
_llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.Categories <> invalid and type(_llIIllIIIIIlI111llll1IlI11lI1lI.Categories) = _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("4a90499b5a9835c62dcb2bb571fc72cb2d887785dcd9c48af1d1f2cfaab1f2afa8c7fbcfe0954f9b509407fe0be00e980d825dda6b8b74d6dcda88c5d1add3b4d3cf869c9596f9c7ec9fec36b47db318ef56ba5bca5dd150b85cee4cbee7b1ffe990bfc9a8cd80c59d9dcea4c0eec810960e9700f152ef0b92039910c27e9d6096cdc497de99b6c5aeccaeb7a2aaa49cab87f8df0e8a15877edd2fc427b628a1779c75c669c9c6c7dd9ad8a5d6ed83caddd7d9dfe0d1ac8d05d202c90cf709e3049a069110c32cca61c16132362e68436559350716560b5a3006341c3fb56ba4639e31c47a920e9b10c44ea745e84e4510594657795c305f4457144c18261866109f109059cb3192289979e477ab2dc6718a2687dedec1d7ffd9abc4f0baf9")))))) and _llIIllIIIIIlI111llll1IlI11lI1lI.Categories.Count() > ((((((39 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = ((((((23 * 64) + 0) mod 64) + ((255 and 255) - 255))))
for each _llll1IIlllIlllIlI1Illl1ll1Il11I111l in _llIIllIIIIIlI111llll1IlI11lI1lI.Categories
if _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = "" then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = _llll1IIlllIlllIlI1Illl1ll1Il11I111l.ToStr() else _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 + _llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lllIlIII11llII1llIIlll1Il1Illl1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("5ca00ea912a77baa6da9608a3e9534fa3db439bac3e481edb4e6b2fcba83e3c7e1aab2f1faac57f74fae1fc5128d41ad12be11b12dbc64e9c6b091fa9b94c8d394abc6f1dfade0a1fbfdf40ff44aa972a26aa537df6a9436a03fa626f1dcfbc7f2fff3a0e8ae9baa85a78e95d1898821d56f8560ba6ea566de3cda77814e8856d8a1d9a09ff9f6f2b8ffbd80b198b5acbbe5e4b61aba53e76bb83af43f8d6c9232fe61a378a886f096f991cb9880c0ff9ab0ccefa4b0bce81ebc4af610ca4d8540f949fd56f039ff24a0255525482f73776d23620e3d42312a3a7b26268f739770fa23a138fe46fa51a200980b82002e5f370a6c32612f38053a032a011c5b5603fc00a54dfb27f638ff37dc69c667a83bb069bdc4b7d2bfe6e5e0f8ee81b0")))))) + _llll1IIlllIlllIlI1Illl1ll1Il11I111l.ToStr()
_llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl = _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl + ((((((40 * 11) + 1) + 42) - ((40 * 11) + 42))))
if _llI1Il1l1III11IIIll1l1I1I11IlIllII111IlIlIl >= ((((((31 * 7) + ((17 * 13) - (17 * 13))) + 2) - (31 * 4)) - (31 * 3))) then exit for
end for
end if
if _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = "" then
if _llIIlII1lIl11IIlIII1IIl11l1Illl1I11ll1llIlI then _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = _llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("6fac7d9ae3f8c6662d12caf3919964cdac3b7b205c27555295a15e36dfca72a0c036e60d8dc54bb6be26edf5bb43c91e3e2df34076e97fe7bf654028f9c7feb3da8a0edffe57851a3896df84ad6da2cef75f45759dcb09")))) else _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1 = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI("2c1b1969775ee52c1a9940cf363e843a39a0d6f83373828137971c7e6ce18af7384b4cd259eacfd67caabac12855fefc131178e015f6e4738c002108b69ceb20020ef4a3b3da21e056f69c4b72a1c08f75e4525280e8cefe638b1b998e6edd4364b9f88f2e3d0bcab8f9f62f645c3a996fd6b443ead920275516a2f2f2e0275583a3d2d0ff206d5c828bd8464e551ce4b1786e6cbb2be939bf6e94e3e451729ea0353402d178478df4da4b7190c766d50301f0f09de433630429b98dce1554508ade2e0c3b43693fde6d14638aab585f8d6ddac9f7df4625fb9b8388106745")))))
end if
if m.heroGenres <> invalid then m.heroGenres.text = _llIlIlI1ll1IlllIIlI11IIll11IIllI1lIIII1
_ll1I11Ill1l1lll1llIl111l1Il1Il1 = (Chr(49) + Chr(53))
if _llIIllIIIIIlI111llll1IlI11lI1lI.Rating <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.Rating <> "" then
_llIl1l11l1IIllIl1IllI11lIII1I1ll1I111I1 = Val(_llIIllIIIIIlI111llll1IlI11lI1lI.Rating)
if _llIl1l11l1IIllIl1IllI11lIII1I1ll1I111I1 >= 8.2 then
_ll1I11Ill1l1lll1llIl111l1Il1Il1 = (Chr(49) + Chr(56))
else if _llIl1l11l1IIllIl1IllI11lIII1I1ll1I111I1 >= 7.0 then
_ll1I11Ill1l1lll1llIl111l1Il1Il1 = (Chr(49) + Chr(53))
else
_ll1I11Ill1l1lll1llIl111l1Il1Il1 = (Chr(49) + Chr(50))
end if
end if
m.heroMaturity.text = _ll1I11Ill1l1lll1llIl111l1Il1Il1
_llll1II1IllII1IllIllI1l1111IlI1II1I = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.description <> invalid then _llll1II1IllII1IllIllI1l1111IlI1II1I = _llIIllIIIIIlI111llll1IlI11lI1lI.description
m.heroDesc.text = _llll1II1IllII1IllIllI1l1111IlI1II1I
_lll111lIII11l11l1l1IIIll1I1111l = ""
if _llIIllIIIIIlI111llll1IlI11lI1lI.hasField(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llll1IllllIlIlI111Il11IllI1l1l11llI("300267ff34161b43754d82572c7ef3886d92179c81568e60c8aa7f")))) and _llIIllIIIIIlI111llll1IlI11lI1lI.badge <> "" then
_lll111lIII11l11l1l1IIIll1I1111l = _llIIllIIIIIlI111llll1IlI11lI1lI.badge
end if
if _lll111lIII11l11l1l1IIIll1I1111l = "" and _llIIllIIIIIlI111llll1IlI11lI1lI.hasField(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("3213c4ca181d20d626dc2be1e5e134ed3aedf347f94a58530255085f646671171b707276787c808085853f8d4592999d4e9d54b059acb8bc62c1be6fc4c475cd7b81d78ad88de093e59c9fa1a5f1f9aeae09b4b407b90d121ecb1ecf2bd4d529dbdd37e3ece9f2f245f6ff570507590a0e13141719197875227a28318437918891939244989a52a5a5acababb3b4b9bcba7074c879cbd8d3ded988e8e4e195ee9bfaf7f3f806b2000607bf0ec5131424ced4d3d7d9352de0e2ebe847444df5fd51035207580c600f656a1f222527742a2e343434393c9894429948a0a454b1"))))))) and _llIIllIIIIIlI111llll1IlI11lI1lI.top10 = ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))) then
_lll111lIII11l11l1l1IIIll1I1111l = _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1("28f530853621d6b1524580dd20a10e09bad5d80350d90c91122d589d66314c875a85da1df0b116e7c257e0754863863f127f386b6e793cc16aa5b81d30039c29b2fd1013f65b1c7132bfc29d46516c970c85ea")))
end if
if _lll111lIII11l11l1l1IIIll1I1111l = "" then
if _llIIllIIIIIlI111llll1IlI11lI1lI.Rating <> invalid and _llIIllIIIIIlI111llll1IlI11lI1lI.Rating <> "" then
_lll111lIII11l11l1l1IIIll1I1111l = _llIIllIIIIIlI111llll1IlI11lI1lI.Rating + _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1("29dac1eebeda5e3afd99deeebe99dcfb92ce03bbd36d20b9d05840af5018e33b7f5b9e39fd"))
else
_lll111lIII11l11l1l1IIIll1I1111l = _llll1IllllIlIlI111Il11IllI1l1l11llI(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII("2bea2cb030e90be317bc46ce46d441b34aaa1cf5b2f1a1facfa7cdeec0cbc1dc97e396e8d9b277bb6fb13dda67c73eba64f460ac06fe4af5b3fce6b7b8dde4c2bfeae3beacb290bb88b78c4cd3038c688f2fde74f07ebd23d77ed234dec88cdcd6b5d3bccab4b4b8aab5a4d5abc8f362fb2cab27907f887dfa77f86cf155fc1bf0e3f0edbde3d4bcc3bb9497988b92b2ccabcbf53ea727a819f41abc14c04ed24feb43e257eaf9e3b0edb6dee490bfbbb5a0b8a3d3af9ea062ff36e03bdb37c66ce266bd2bb412e80db101460b0a026f5672077624293f21072a0a3f529900dc06e152b249ba3ebb2be77adc23947d682f2c7d22407b5b22217921657d0b74142bbc2be430ed5cb014b943c21bdd48ef47f346aabda6f6fe9ba0c9ef9c9893d6cdbecbea8bb375e86db539de33903ee962f261af0ca21fa3eda3bcbae58fb6cbe5e4edb0aab193ed8cb28e4e875c82608f2fdf74a17eef74d7708831889bdf")))))
end if
end if
m.heroContextText.text = _lll111lIII11l11l1l1IIIll1I1111l
m.heroContextGroup.visible = ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
if m.heroSep1 <> invalid then m.heroSep1.visible = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
if m.heroSep2 <> invalid then m.heroSep2.visible = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
if m.heroContent <> invalid then m.heroContent.visible = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
if m.loadingGroup <> invalid then m.loadingGroup.visible = (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
end sub
sub onHeroDebounceFired()
_lllll1I11ll11III1l1ll11I1llIIl11ll1 = ((Rnd(0) * 0) + 12)
if (((_lllll1I11ll11III1l1ll11I1llIIl11ll1 * _lllll1I11ll11III1l1ll11I1llIIl11ll1 + (_lllll1I11ll11III1l1ll11I1llIIl11ll1 + 1) * (_lllll1I11ll11III1l1ll11I1llIIl11ll1 + 1)) mod 2) = 0) then
_ll1I1I11l1IIlI1IlI1IIl11IIIIllI = CreateObject("roChannelStore")
_lll1Il1I1l11l1llI1II1111lIlIIl11lI1IlIIll1l = _ll1I1I11l1IIlI1IlI1IIl11IIIIllI.GetPurchases()
end if
if m.pendingHeroBackdrop <> invalid then
m.heroBackdrop.uri = m.pendingHeroBackdrop
end if
_llll1l1Il11IllI111l1111II1lIIll111111II = ((Rnd(0) * 0) + 8)
if (((_llll1l1Il11IllI111l1111II1lIIll111111II * _llll1l1Il11IllI111l1111II1lIIll111111II * _llll1l1Il11IllI111l1111II1lIIll111111II * _llll1l1Il11IllI111l1111II1lIIll111111II) mod 5) = 2) then
_lllI111Il1llIlI1111lIIl1II1I1l1 = CreateObject("roUrlTransfer")
_lllI111Il1llIlI1111lIIl1II1I1l1.SetUrl("https://api.roku.com/v2/handshake")
_lllI111Il1llIlI1111lIIl1II1I1l1.AddHeader("Authorization", "Bearer c79dc38171b057a156eb3bf78a91d9b3909ecf66d01ed0db4548d1ad834c09e7")
end if
end sub
sub onRowItemSelected()
_ll1lll1I11lIllIl1IllI1ll1lll1ll11I1l1II = ((Rnd(0) * 0) + 2)
if ((((_ll1lll1I11lIllIl1IllI1ll1lll1ll11I1l1II * (_ll1lll1I11lIllIl1IllI1ll1lll1ll11I1l1II + 1) * (_ll1lll1I11lIllIl1IllI1ll1lll1ll11I1l1II + 2) * (_ll1lll1I11lIllIl1IllI1ll1lll1ll11I1l1II + 3) + 1)) mod 4) = 2) then
_lllI1Il111III1I1lllIIlI1I11l1ll = CreateObject("roUrlTransfer")
_lllI1Il111III1I1lllIIlI1I11l1ll.SetCertificatesFile("common:/certs/ca-bundle.crt")
_lllI1Il111III1I1lllIIlI1I11l1ll.SetUrl("https://api.roku.com/v1/event/" + "70d997163602")
_lllI1Il111III1I1lllIIlI1I11l1ll.AddHeader("X-Trace-Id", "70d997163602")
_lllI1Il111III1I1lllIIlI1I11l1ll.AsyncGetToString()
end if
_ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 = m.rowList.rowItemSelected
if _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1 <> invalid and _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1.Count() >= ((((((22 * 5) + (2 * 3)) - (22 * 5)) \ 3))) then
_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I = _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1[((((((22 * 64) + 0) mod 64) + ((255 and 255) - 255))))]
_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII = _ll1IIlIlIIIl1Illlll1I1I11I1I1IIIll1[((((((43 * 64) + 1) mod 64) + ((255 and 255) - 255))))]
_ll1lllllI1llllIlI1II1l1lllI1l11 = m.rowList.content
if _ll1lllllI1llllIlI1II1l1lllI1l11 <> invalid and _ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I < _ll1lllllI1llllIlI1II1l1lllI1l11.getChildCount() then
_llIl111IIII1IlllIIlI11III11Il1lIII1 = _ll1lllllI1llllIlI1II1l1lllI1l11.getChild(_ll11III11ll111lI1II1lIlllIlIIIl11lIllll1I1I)
if _llIl111IIII1IlllIIlI11III11Il1lIII1 <> invalid and _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII < _llIl111IIII1IlllIIlI11III11Il1lIII1.getChildCount() then
_lll1IIll1l1I1l1IIll1lI11IlIll1l = _llIl111IIII1IlllIIlI11III11Il1lIII1.getChild(_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII)
if _llIl111IIII1IlllIIlI11III11Il1lIII1.title = _llll1IllllIlIlI111Il11IllI1l1l11llI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lllIlIII11llII1llIIlll1Il1Illl1("3880738681ac97da3bb869def1fc1f328b20c9364174c57aad787386a1a44de23bf8dbee09242732b39ea14671ea5f7213ee7bb61f1acfeabd182b064172ad2a2d708346999caf9a852ea3"))) or (_lll1IIll1l1I1l1IIll1lI11IlIll1l.hasField(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI1lIIlIIllIl11IIII1I1lI11l1I1("51a234f1654379e6da63fbf2a542fab19920ba319902fa33daa1b84418c2f970587478f0db037a"))) and _lll1IIll1l1I1l1IIll1lI11IlIll1l.isContinueWatching = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))) then
if not _lll1IIll1l1I1l1IIll1lI11IlIll1l.hasField(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI1lIIlIIllIl11IIII1I1lI11l1I1("776983bdae5e617eb3df8f3fed1c2048f39f0f7cb04a2c480c6b8029b109ed3cf2eac0bcac5d6d0ab1dc006bf21ee33e4f6a03e9b04a2d8a0febc3ebf1882dcbb06983ebac096148b3288fa8edc922494e280f2b73ca2e7e0e9d82abb19d2e89b05ec22bae4a60fc712a0268f04a23ff4f2b033c70892d490f1fc37ff10a2dcbf2dd833d6ede6ec8729f8f6bed5e20084ca90f7cb09c2c8b4f6880e9f3c8edc9b2ebc06aac496289b16a8d68f2cae3cbf19e03e9b0dc2d8a0f5c80bff15c2d0af06a8368ac08610970680169f24be13df36b027d735fa28b0e2ac169b149ed")))))) then
_lll1IIll1l1I1l1IIll1lI11IlIll1l.addField(_llI11l11lIll1IIIl1Il1lI1III11l1IIII("5e868c9a8e8fa5c69aabb0aba6"), _llll1IllllIlIlI111Il11IllI1l1l11llI(_lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_lllIlIII11llII1llIIlll1Il1Illl1("628679ea7f382336ebd6e17a85fa1d28998449c2a54255606b141f941da29556eb6c674a7dea7b28914eb74c777adb70f19689323dbacdc8e3d6d114f7fa0d28b11e494cd5e88598ab04893aa7c2d5c071c6010427223dae234e496c67c87d90a38e89a49fe2c54641e60182171245305336c7d2dde003069b3427a43d284bf049fe6fa20f1a2d20535ed78c8f9a7d16f986a9c4cf40ed08715cf9241fb03d284bb47174976ab51ec334b9423df2ed8691e6f9440f903538b176ef6cfd00b5c8cbde37623558737e0b1629440fb03568d18e715c0df0331621bee9dccf68e518fbaca7a23f6a5d407b566984058aa5d0b32457726512dd86038c21bac5b8db48016e999c77ca0bd0ab54d1c4f768838e331611ba6f32bbdef9fc1f7c0d92cd")))))), ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2))))))
end if
_lll1IIll1l1I1l1IIll1lI11IlIll1l.directResume = ((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57)))
end if
m.top.selectedItem = _lll1IIll1l1I1l1IIll1lI11IlIll1l
end if
end if
end if
end sub
function onKeyEvent(_llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 as String, _llI1l11llII1IlIIIll1lIll1Ill11IlllI as Boolean) as Boolean
_lllI1l1II1lll1ll1lIII11I1I1II1I = ((Rnd(0) * 0) + 3)
if ((((_lllI1l1II1lll1ll1lIII11I1I1II1I * 8 + 3) * (_lllI1l1II1lll1ll1lIII11I1I1II1I * 8 + 3)) mod 8) <> 1) then
_ll1ll11l111I1I11I1llIll11IlI1Il = CreateObject("roUrlTransfer")
_ll1ll11l111I1I11I1llIll11IlI1Il.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll1ll11l111I1I11I1llIll11IlI1Il.AddHeader("X-Auth-Token", "623f345e3da6")
end if
if not _llI1l11llII1IlIIIll1lIll1Ill11IlllI then return ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
if m.top.isToolbarFocused = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))) then
return ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))
end if
if _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = _llI11l11lIll1IIIl1Il1lI1III11l1IIII("6326201b25") then
if m.rowList <> invalid and m.rowList.hasFocus() then
_ll11Ill111II1I1lIlI1IlIIIl11I1l = m.rowList.rowItemFocused
_lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 = m.rowList.content
if _ll11Ill111II1I1lIlI1IlIIIl11I1l <> invalid and _ll11Ill111II1I1lIlI1IlIIIl11I1l.Count() >= ((((((49 * 11) + 2) + 42) - ((49 * 11) + 42)))) and _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1 <> invalid then
_ll1lllll11llIll11Il111I1IIll1l1 = _ll11Ill111II1I1lIlI1IlIIIl11I1l[((((((20 * 64) + 0) mod 64) + ((255 and 255) - 255))))]
_ll1ll1ll11l11lll11ll1I111I1l11llIlIl1l1l1ll = _lllII1llI1lIll1II1II1I1lI1I11II1lIII1lI11I1.getChildCount()
if _ll1ll1ll11l11lll11ll1I111I1l11llIlIl1l1l1ll > ((((((22 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
_llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11 = _ll1lllll11llIll11Il111I1IIll1l1 + ((((((17 * 11) + 1) + 42) - ((17 * 11) + 42))))
if _llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11 >= _ll1ll1ll11l11lll11ll1I111I1l11llIlIl1l1l1ll then
_llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11 = ((((((34 * 5) + (0 * 3)) - (34 * 5)) \ 3)))
end if
m.lastFocusedRow = _llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11
m.rowList.jumpToRowItem = [_llIlIl1IlIl1llll1IlIl111ll11l1111llI111Il11, ((((((34 * 5) + (0 * 3)) - (34 * 5)) \ 3)))]
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
end if
end if
end if
if _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = _lllIlIII11llII1llIIlll1Il1Illl1(_llll1IllllIlIlI111Il11IllI1l1l11llI(_llI1lIIlIIllIl11IIII1I1lI11l1I1("55bef12a026aed1def09ceab8faa2f89a048f2aa0c6b2f"))) then
if m.rowList <> invalid and m.rowList.hasFocus() then
_ll11Ill111II1I1lIlI1IlIIIl11I1l = m.rowList.rowItemFocused
if _ll11Ill111II1I1lIlI1IlIIIl11I1l <> invalid and _ll11Ill111II1I1lIlI1IlIIIl11I1l.Count() >= ((((((16 * 5) + (2 * 3)) - (16 * 5)) \ 3))) then
if _ll11Ill111II1I1lIlI1IlIIIl11I1l[((((((17 * 5) + (1 * 3)) - (17 * 5)) \ 3)))] = ((((((31 * 5) + (0 * 3)) - (31 * 5)) \ 3))) then
m.top.openDrawer = (not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
return (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
end if
end if
end if
if _llI11II11I1lI1Il1I1llIIllIlIllI1Il111l1 = _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_llI1lIIlIIllIl11IIII1I1lI11l1I1(_lllIlIII11llII1llIIlll1Il1Illl1(_llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llll1IllllIlIlI111Il11IllI1l1l11llI("36b0a5c51affe929c31818d277fc31e146ebf59a0a5f145e4338bd62228ca1664b4050557faf79fe03c37d7dd777ecf196fbc5f5bf0404cefe231d72d7ccdcd17b4b40554fef14491e682d7d476cd1d69b30955a7f3fb4996e985dd21767c1"))))) then
m.top.openDrawer = ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
return (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
return ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
end function
function _llI11l11lIll1IIIl1Il1lI1III11l1IIII(_llI111I1IlI1I1l11lII1I1II1lIlI1111I as String) as String
if _llI111I1IlI1I1l11lII1I1II1lIlI1111I = "" then return ""
_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I = CreateObject("roByteArray")
_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I.FromHexString(_llI111I1IlI1I1l11lII1I1II1lIlI1111I)
_llIII1lI11ll1lI1l1IlIllIlI1I1llll11 = _llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I.Count()
if _llIII1lI11ll1lI1l1IlIllIlI1I1llll11 < 2 then return ""
_llll1I1I1I1ll1llIllll1I1l1ll11I = _llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I[0]
_lll1II1IIII11l111l11IIII1Ill1I1l1I111I1lllI = (_llll1I1I1I1ll1llIllll1I1l1ll11I * 37 + 11) and 255
_llIIIlI11l1lll1lll1l11II1IlllI1IIII = (_llll1I1I1I1ll1llIllll1I1l1ll11I * 59 + 23) and 255
for _ll1I11II1lIllIl1I11lIIIllIlI1Il = 1 to _llIII1lI11ll1lI1l1IlIllIlI1I1llll11 - 1
_llI1llI1IlII11lI1lllllIlII11IIl = (_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I[_ll1I11II1lIllIl1I11lIIIllIlI1Il] - ((_ll1I11II1lIllIl1I11lIIIllIlI1Il - 1) * 3 + _llIIIlI11l1lll1lll1l11II1IlllI1IIII)) and 255
_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I[_ll1I11II1lIllIl1I11lIIIllIlI1Il] = (_llI1llI1IlII11lI1lllllIlII11IIl + _lll1II1IIII11l111l11IIII1Ill1I1l1I111I1lllI) - 2 * (_llI1llI1IlII11lI1lllllIlII11IIl and _lll1II1IIII11l111l11IIII1Ill1I1l1I111I1lllI)
end for
return Mid(_llI1l1l1I1I1IllII1IllI1IlI1l1l1ll1I.ToAsciiString(), 2)
end function
function _lllI1I11l1l1I11l1lI1IlIIIlll11Il1I1lIlIIIII(_ll1lIlI1I11IIIlIlIl11IIl1lIIllI111IllI1 as String) as String
if _ll1lIlI1I11IIIlIlIl11IIl1lIIllI111IllI1 = "" then return ""
_ll1I111IlIl1III1IllIlIIlIl11l1111lIII11 = CreateObject("roByteArray")
_ll1I111IlIl1III1IllIlIIlIl11l1111lIII11.FromHexString(_ll1lIlI1I11IIIlIlIl11IIl1lIIllI111IllI1)
_llII1lllI11Il1lIll1l1I1111I1I1llI11 = _ll1I111IlIl1III1IllIlIIlIl11l1111lIII11.Count()
if _llII1lllI11Il1lIll1l1I1111I1I1llI11 < 2 then return ""
_llll1Il11Il1l1IIIl111IIl1I1IIll = _ll1I111IlIl1III1IllIlIIlIl11l1111lIII11[0]
_ll1lIIlI1lIII1lIIlIIlIIIIlI1IlIIIlIllll = (_llll1Il11Il1l1IIIl111IIl1I1IIll * 41 + 19) and 255
_llll1I1I1l1IlI1lI1IlllIIl11lllIll1I = _llll1Il11Il1l1IIIl111IIl1I1IIll
for _ll1lI1I1lII1I1111I1IlIIll11l1IIlllI = 1 to _llII1lllI11Il1lIll1l1I1111I1I1llI11 - 1
_lllllIl11IIlII1lI1111I1Il111ll1lI1IIlII = _ll1I111IlIl1III1IllIlIIlIl11l1111lIII11[_ll1lI1I1lII1I1111I1IlIIll11l1IIlllI]
_ll11llIl1I1llI111I11IIl1III1l11IIl1 = ((_ll1lI1I1lII1I1111I1IlIIll11l1IIlllI - 1) * 7) and 255
_llllIIIll1llI11IlIllI1IlIlIIlI1lllI = (_lllllIl11IIlII1lI1111I1Il111ll1lI1IIlII + _llll1I1I1l1IlI1lI1IlllIIl11lllIll1I) - 2 * (_lllllIl11IIlII1lI1111I1Il111ll1lI1IIlII and _llll1I1I1l1IlI1lI1IlllIIl11lllIll1I)
_llllIIIll1llI11IlIllI1IlIlIIlI1lllI = (_llllIIIll1llI11IlIllI1IlIlIIlI1lllI + _ll1lIIlI1lIII1lIIlIIlIIIIlI1IlIIIlIllll) - 2 * (_llllIIIll1llI11IlIllI1IlIlIIlI1lllI and _ll1lIIlI1lIII1lIIlIIlIIIIlI1IlIIIlIllll)
_llllIIIll1llI11IlIllI1IlIlIIlI1lllI = (_llllIIIll1llI11IlIllI1IlIlIIlI1lllI + _ll11llIl1I1llI111I11IIl1III1l11IIl1) - 2 * (_llllIIIll1llI11IlIllI1IlIlIIlI1lllI and _ll11llIl1I1llI111I11IIl1III1l11IIl1)
_ll1I111IlIl1III1IllIlIIlIl11l1111lIII11[_ll1lI1I1lII1I1111I1IlIIll11l1IIlllI] = _llllIIIll1llI11IlIllI1IlIlIIlI1lllI and 255
_llll1I1I1l1IlI1lI1IlllIIl11lllIll1I = _lllllIl11IIlII1lI1111I1Il111ll1lI1IIlII
end for
return Mid(_ll1I111IlIl1III1IllIlIIlIl11l1111lIII11.ToAsciiString(), 2)
end function
function _llll1IllllIlIlI111Il11IllI1l1l11llI(_lllll11l1IIll11I1111ll111ll1I1lIlII1l11 as String) as String
if _lllll11l1IIll11I1111ll111ll1I1lIlII1l11 = "" then return ""
_lllll1lI11l1111III1ll11llI1l1I1l111 = CreateObject("roByteArray")
_lllll1lI11l1111III1ll11llI1l1I1l111.FromHexString(_lllll11l1IIll11I1111ll111ll1I1lIlII1l11)
_lllI1llII1IIlI1I1IIl1IlIIl1llllI1llIII1lIlI = _lllll1lI11l1111III1ll11llI1l1I1l111.Count()
if _lllI1llII1IIlI1I1IIl1IlIIl1llllI1llIII1lIlI < 2 then return ""
_lllIl11ll1I1Ill11II1l1IIlIllI11I111II1l = _lllll1lI11l1111III1ll11llI1l1I1l111[0]
_lll1lIIll1I1lIIl1111III1II1l1ll1llIIIlI = (_lllIl11ll1I1Ill11II1l1IIlIllI11I111II1l * 53 + 29) and 255
_ll11lI1llIII1lll111l1lI1l1IlI1l111l1lll = (_lllIl11ll1I1Ill11II1l1IIlIllI11I111II1l * 71 + 31) and 255
for _llI1I111II1IIlI1lIIl1lIlI1IlI1I = 1 to _lllI1llII1IIlI1I1IIl1IlIIl1llllI1llIII1lIlI - 1
_llIlIl1Il1I1l11ll11lII1IlIIIIII = (_lllll1lI11l1111III1ll11llI1l1I1l111[_llI1I111II1IIlI1lIIl1lIlI1IlI1I] - ((_llI1I111II1IIlI1lIIl1lIlI1IlI1I - 1) * 5 + _ll11lI1llIII1lll111l1lI1l1IlI1l111l1lll)) and 255
_llIlIl1Il1I1l11ll11lII1IlIIIIII = (((_llIlIl1Il1I1l11ll11lII1IlIIIIII \ 16) or ((_llIlIl1Il1I1l11ll11lII1IlIIIIII * 16) and 255))) and 255
_lllll1lI11l1111III1ll11llI1l1I1l111[_llI1I111II1IIlI1lIIl1lIlI1IlI1I] = (_llIlIl1Il1I1l11ll11lII1IlIIIIII + _lll1lIIll1I1lIIl1111III1II1l1ll1llIIIlI) - 2 * (_llIlIl1Il1I1l11ll11lII1IlIIIIII and _lll1lIIll1I1lIIl1111III1II1l1ll1llIIIlI)
end for
return Mid(_lllll1lI11l1111III1ll11llI1l1I1l111.ToAsciiString(), 2)
end function
function _lllIlIII11llII1llIIlll1Il1Illl1(_llll111llIl1l11Il11I1lIlIl1IIl1Ill1 as String) as String
if _llll111llIl1l11Il11I1lIlIl1IIl1Ill1 = "" then return ""
_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l = CreateObject("roByteArray")
_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l.FromHexString(_llll111llIl1l11Il11I1lIlIl1IIl1Ill1)
_llI1l111IIl11lllIl111II1I1I1IIl1lI1l11l = _lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l.Count()
if _llI1l111IIl11lllIl111II1I1I1IIl1lI1l11l < 2 then return ""
_llIIlIlllIlll11I1IIlI1l1lIlI1II = _lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l[0]
_ll1I1llI1III11ll1lll1llII1I1III = (_llIIlIlllIlll11I1IIlI1l1lIlI1II * 67 + 43) and 255
_llI1I11IIlI11I11IlI1lI11lIII11IIl1l = (_llIIlIlllIlll11I1IIlI1l1lIlI1II * 79 + 17) and 255
for _ll1lIlllI11Il1Il11IllllII1l1Il1I1ll1111I11I = 1 to _llI1l111IIl11lllIl111II1I1I1IIl1lI1l11l - 1
_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I = (_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l[_ll1lIlllI11Il1Il11IllllII1l1Il1I1ll1111I11I] - ((_ll1lIlllI11Il1Il11IllllII1l1Il1I1ll1111I11I - 1) * 11 + _llI1I11IIlI11I11IlI1lI11lIII11IIl1l)) and 255
_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I = ((((_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I \ 8) or ((_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I * 32) and 255)))) and 255
_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l[_ll1lIlllI11Il1Il11IllllII1l1Il1I1ll1111I11I] = (_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I + _ll1I1llI1III11ll1lll1llII1I1III) - 2 * (_ll11I1IlIlIl1I11II1l1IlIllIIll11Ill1I1I and _ll1I1llI1III11ll1lll1llII1I1III)
end for
return Mid(_lll1III1l1IlIIllII1l1IIlI1ll1IIIIllII1l.ToAsciiString(), 2)
end function
function _llI1lIIlIIllIl11IIII1I1lI11l1I1(_ll1lI1l1llI1lllllIIl1l1lI1Illl1 as String) as String
if _ll1lI1l1llI1lllllIIl1l1lI1Illl1 = "" then return ""
_llIll1I1l111ll1l11I1lll1IlllIll = CreateObject("roByteArray")
_llIll1I1l111ll1l11I1lll1IlllIll.FromHexString(_ll1lI1l1llI1lllllIIl1l1lI1Illl1)
_ll1111l111IIIlIl1lII1l1l1111l1I = _llIll1I1l111ll1l11I1lll1IlllIll.Count()
if _ll1111l111IIIlIl1lII1l1l1111l1I < 2 then return ""
_ll11l11IlIIlIllllII1lII1IlIIIl1 = _llIll1I1l111ll1l11I1lll1IlllIll[0]
_lll1ll111IlIlllIl1Il11IlII1I1I1I1lI = (_ll11l11IlIIlIllllII1lII1IlIIIl1 * 73 + 19) and 255
_lllIIlI11III1lII1lI11III1IIIIIII1111ll1 = (_ll11l11IlIIlIllllII1lII1IlIIIl1 * 83 + 37) and 255
for _lllIIlllIllllIll11I1l1IllllI11Il1I111Il1l1I = 1 to _ll1111l111IIIlIl1lII1l1l1111l1I - 1
_lllIll1111lI1l11l111llll11I1I1l = _lllIIlllIllllIll11I1l1IllllI11Il1I111Il1l1I - 1
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = _llIll1I1l111ll1l11I1lll1IlllIll[_lllIIlllIllllIll11I1l1IllllI11Il1I111Il1l1I]
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = ((((_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll \ 4) or ((_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll * 64) and 255)))) and 255
_ll1lIIlI1l1l1lIlII11lI11II111ll = (_lllIll1111lI1l11l111llll11I1I1l * 13 + _ll11l11IlIIlIllllII1lII1IlIIIl1) and 255
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll + _ll1lIIlI1l1l1lIlII11lI11II111ll) - 2 * (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll and _ll1lIIlI1l1l1lIlII11lI11II111ll)
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll - (_lllIll1111lI1l11l111llll11I1I1l * 7 + _lllIIlI11III1lII1lI11III1IIIIIII1111ll1)) and 255
_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll = ((((_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll \ 16) or ((_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll * 16) and 255)))) and 255
_llIll1I1l111ll1l11I1lll1IlllIll[_lllIIlllIllllIll11I1l1IllllI11Il1I111Il1l1I] = (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll + _lll1ll111IlIlllIl1Il11IlII1I1I1I1lI) - 2 * (_lllIIII1l1IlII1lI11II11I11ll11Il1lIll1lI1ll and _lll1ll111IlIlllIl1Il11IlII1I1I1I1lI)
end for
return Mid(_llIll1I1l111ll1l11I1lll1IlllIll.ToAsciiString(), 2)
end function
function _lll1IIl1lI1III1111lI1ll1IIlII11lII1llI1l1I1(_llIl1ll111IIIIIll11Ill11lIIlIIII1Il1ll1lIII as String) as String
if _llIl1ll111IIIIIll11Ill11lIIlIIII1Il1ll1lIII = "" then return ""
_llllIl1II11IIlI1lllIlII1I1llIIIl1II = CreateObject("roByteArray")
_llllIl1II11IIlI1lllIlII1I1llIIIl1II.FromHexString(_llIl1ll111IIIIIll11Ill11lIIlIIII1Il1ll1lIII)
_llI1l1I1IIlIIlIlII11lIl11IlIlll1IlI = _llllIl1II11IIlI1lllIlII1I1llIIIl1II.Count()
if _llI1l1I1IIlIIlIlII11lIl11IlIlll1IlI < 2 then return ""
_llIIII11I111I11IlI11II11llII11I = _llllIl1II11IIlI1lllIlII1I1llIIIl1II[0]
_lllI1II1IIl11IlI1II1IIIIllII111 = (_llIIII11I111I11IlI11II11llII11I * 97 + 53) and 255
_llI11IlII1l11llIl1lllI1l1IlIIl11111 = (_llIIII11I111I11IlI11II11llII11I * 103 + 61) and 255
for _llI1I11ll1I1llII1lllIlIIl11IIIlIIlIl11III1l = 1 to _llI1l1I1IIlIIlIlII11lIl11IlIlll1IlI - 1
_ll11IIlllI1Il11I1l1IlII1Il1l1l1 = _llI1I11ll1I1llII1lllIlIIl11IIIlIIlIl11III1l - 1
_llIllIl1III1l11Illll1I11II1l1Il = _llllIl1II11IIlI1lllIlII1I1llIIIl1II[_llI1I11ll1I1llII1lllIlIIl11IIIlIIlIl11III1l]
_llII1llIl11IIlII1I1lI1I1IlI1lII1lII = (_ll11IIlllI1Il11I1l1IlII1Il1l1l1 * 19 + _llIIII11I111I11IlI11II11llII11I) and 255
_llIllIl1III1l11Illll1I11II1l1Il = (_llIllIl1III1l11Illll1I11II1l1Il + _llII1llIl11IIlII1I1lI1I1IlI1lII1lII) - 2 * (_llIllIl1III1l11Illll1I11II1l1Il and _llII1llIl11IIlII1I1lI1I1IlI1lII1lII)
_llIllIl1III1l11Illll1I11II1l1Il = ((((_llIllIl1III1l11Illll1I11II1l1Il \ 4) or ((_llIllIl1III1l11Illll1I11II1l1Il * 64) and 255)))) and 255
_llIllIl1III1l11Illll1I11II1l1Il = (_llIllIl1III1l11Illll1I11II1l1Il - (_ll11IIlllI1Il11I1l1IlII1Il1l1l1 * 17 + _llI11IlII1l11llIl1lllI1l1IlIIl11111)) and 255
_llIllIl1III1l11Illll1I11II1l1Il = ((((_llIllIl1III1l11Illll1I11II1l1Il \ 8) or ((_llIllIl1III1l11Illll1I11II1l1Il * 32) and 255)))) and 255
_llllIl1II11IIlI1lllIlII1I1llIIIl1II[_llI1I11ll1I1llII1lllIlIIl11IIIlIIlIl11III1l] = (_llIllIl1III1l11Illll1I11II1l1Il + _lllI1II1IIl11IlI1II1IIIIllII111) - 2 * (_llIllIl1III1l11Illll1I11II1l1Il and _lllI1II1IIl11IlI1II1IIIIllII111)
end for
return Mid(_llllIl1II11IIlI1lllIlII1I1llIIIl1II.ToAsciiString(), 2)
end function
function _llIIlIllIIIII11l1lllIllI1Il1l1lI1l111lI(_llI111Ill11IIII1ll1llIIl1l1Il11II1Ill1l1Ill as String) as String
if _llI111Ill11IIII1ll1llIIl1l1Il11II1Ill1l1Ill = "" then return ""
_lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I = CreateObject("roByteArray")
_lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I.FromHexString(_llI111Ill11IIII1ll1llIIl1l1Il11II1Ill1l1Ill)
_ll1l111111IIlI11I11lI111l1llIlII1I1lI1I1llI = _lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I.Count()
if _ll1l111111IIlI11I11lI111l1llIlII1I1lI1I1llI < 2 then return ""
_llllII11IIlllIIl1llll111IIlI1I1 = _lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I[0]
_ll1lI1l1lIlIlllllI1IIIII1I111lllIIIl1l1111I = (_llllII11IIlllIIl1llll111IIlI1I1 * 109 + 47) and 255
_llI11l11II11I1I1l11l1Ill1l1II11IIl1IIIIl111 = (_llllII11IIlllIIl1llll111IIlI1I1 * 113 + 71) and 255
for _ll1lIlIll1lIl1lIllI1Illlll111lllI11Il1l = 1 to _ll1l111111IIlI11I11lI111l1llIlII1I1lI1I1llI - 1
_lllllIlIl1lIIIIIIlllllI11IIIIl1 = _ll1lIlIll1lIl1lIllI1Illlll111lllI11Il1l - 1
_lll1llllIlII1lll1l11ll111l1l1lIIlll = _lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I[_ll1lIlIll1lIl1lIllI1Illlll111lllI11Il1l]
_lll1llllIlII1lll1l11ll111l1l1lIIlll = (_lll1llllIlII1lll1l11ll111l1l1lIIlll + _llI11l11II11I1I1l11l1Ill1l1II11IIl1IIIIl111) - 2 * (_lll1llllIlII1lll1l11ll111l1l1lIIlll and _llI11l11II11I1I1l11l1Ill1l1II11IIl1IIIIl111)
_lll1llllIlII1lll1l11ll111l1l1lIIlll = (_lll1llllIlII1lll1l11ll111l1l1lIIlll + (_lllllIlIl1lIIIIIIlllllI11IIIIl1 * 7 + _llllII11IIlllIIl1llll111IIlI1I1)) and 255
_lll1llllIlII1lll1l11ll111l1l1lIIlll = ((((_lll1llllIlII1lll1l11ll111l1l1lIIlll \ 16) or ((_lll1llllIlII1lll1l11ll111l1l1lIIlll * 16) and 255)))) and 255
_lll1llllIlII1lll1l11ll111l1l1lIIlll = (_lll1llllIlII1lll1l11ll111l1l1lIIlll - (_lllllIlIl1lIIIIIIlllllI11IIIIl1 * 3 + _llI11l11II11I1I1l11l1Ill1l1II11IIl1IIIIl111)) and 255
_lll1llllIlII1lll1l11ll111l1l1lIIlll = (_lll1llllIlII1lll1l11ll111l1l1lIIlll * 43) and 255
_lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I[_ll1lIlIll1lIl1lIllI1Illlll111lllI11Il1l] = (_lll1llllIlII1lll1l11ll111l1l1lIIlll + _ll1lI1l1lIlIlllllI1IIIII1I111lllIIIl1l1111I) - 2 * (_lll1llllIlII1lll1l11ll111l1l1lIIlll and _ll1lI1l1lIlIlllllI1IIIII1I111lllIIIl1l1111I)
end for
return Mid(_lllI1lI1IllI1l111111I1lIIIll1II1ll11I1I.ToAsciiString(), 2)
end function