sub init()
m.heroBackdrop = m.top.findNode(_l1d_462afc("cad8e6d4bce0e1dceefbe903", 203, 39))
m.heroBadge = m.top.findNode(_l1d_462afc("bfcfdbcbf1d7dddfe4", 42, 125))
m.heroTitle = m.top.findNode(_l1d_462afc("fff7ef07cf0ff5100c", 212, 67))
m.heroMeta = m.top.findNode(_l1d_462afc("f4fc10f8dd081a12", 206, 78))
m.heroDesc = m.top.findNode(_l1d_462afc("aeb6cab2dec2d7ca", 110, 168))
m.heroPlayBtn = m.top.findNode(_l1d_462afc("99a1b9a19da4b4bf9bc8b5", 204, 245))
m.heroWatchlistBtn = m.top.findNode(_l1d_462afc("474f474f6a5f4d675f5e66635f986572", 124, 51))
m.rowList = m.top.findNode(_l1d_462afc("bcd2bdb7ddcac8", 149, 213))
m.loadingGroup = m.top.findNode(_l1d_462afc("e0e0e1e1efede70a02f8050d", 167, 21))
m.heroPlayBtn.observeField(_l1d_462afc("b8ccd0d3cfd3f9cedad4d5ebdde1", 161, 245), _l1d_462afc("62644d65797161787893", 70, 57))
m.heroWatchlistBtn.observeField(_l1d_462afc("a793979aa6aac8b5b1bbc4b2c4c8", 61, 72), _l1d_462afc("4c4e6b4b5b5b8653695b636a6a777b9e7c777a827e", 32, 253))
m.rowList.observeField(_l1d_462afc("5c425d2a62544f505d59636c7a6c70", 77, 29), _l1d_462afc("7476957d78a97f938eab9c96a2a797abad", 62, 35))
m.rowList.observeField(_l1d_462afc("4e3c576060524d775158716e676b", 107, 53), _l1d_462afc("dce0d7e500c505f7f2e0fa0116170c10", 201, 54))
m.top.observeField(_l1d_462afc("ebe5ece1e2f7fb", 153, 236), _l1d_462afc("b4b8a3bdc4b9baadc7d1d3ddde", 217, 254))
loadHomeData()
end sub
sub onFocusChange()
if ((29536 - 3692 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.top.hasFocus() then
if m.rowList <> invalid then m.rowList.setFocus(true)
end if
end sub
sub onCategoryChange()
loadHomeData()
end sub
sub loadHomeData()
if ((43856 - 5482 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.loadingGroup.visible = true
if m.catalogTask <> invalid then m.catalogTask.control = _l1d_462afc("898f8b91", 1, 55)
m.catalogTask = CreateObject(_l1d_462afc("4040675e684c4448", 224, 174), _l1d_462afc("90756b7b797b869a8a7b86", 186, 151))
_lIl1lIl = m.top.category
if _lIl1lIl = invalid or _lIl1lIl = "" then _lIl1lIl = _l1d_462afc("4343443f", 53, 230)
m.catalogTask.category = _lIl1lIl
m.catalogTask.observeField(_l1d_462afc("ccc0d1d6c2dd", 233, 49), _l1d_462afc("f9fbe308fe0e0c0e19f51720262a2c", 218, 68))
m.catalogTask.control = _l1d_462afc("3d433f", 64, 43)
end sub
sub onCatalogLoaded()
m.loadingGroup.visible = false
_ll1lIIl = m.catalogTask.result
if _ll1lIIl <> invalid and _ll1lIIl.getChildCount() > 0 then
m.rowList.content = _ll1lIIl
_lIllIIl = _ll1lIIl.getChild(0)
if _lIllIIl <> invalid and _lIllIIl.getChildCount() > 0 then
updateHero(_lIllIIl.getChild(0))
end if
m.rowList.setFocus(true)
else if m.top.category = _l1d_462afc("60676b7876748073", 135, 124) or m.top.category = _l1d_462afc("4257455f675f61", 52, 255) then
_llllIIl = CreateObject(_l1d_462afc("2d4514232d51494d", 84, 7), _l1d_462afc("d9080cf90b1502fb1d1b1d", 147, 9))
_l1llIIl = _llllIIl.createChild(_l1d_462afc("5c43452e424e3774585054", 180, 101))
_l1llIIl.title = _l1d_462afc("653c3e5b4b4765581e8c65736965696571393491754580849d9d87a5a35da9a0b262", 46, 248)
m.rowList.content = _llllIIl
end if
end sub
sub onRowItemFocused()
_lllIll1 = m.rowList.rowItemFocused
if _lllIll1 <> invalid and _lllIll1.Count() >= 2 then
_lIlIll1 = _lllIll1[0]
_l1I1ll1 = _lllIll1[1]
_lII1ll1 = m.rowList.content
if _lII1ll1 <> invalid and _lIlIll1 < _lII1ll1.getChildCount() then
_l1lIll1 = _lII1ll1.getChild(_lIlIll1)
if _l1lIll1 <> invalid and _l1I1ll1 < _l1lIll1.getChildCount() then
updateHero(_l1lIll1.getChild(_l1I1ll1))
end if
end if
end if
m.top.scrollEvent = true
end sub
sub updateHero(_l1IlIl1 as Object)
if _l1IlIl1 = invalid then return
m.currentItem = _l1IlIl1
m.heroBackdrop.uri = _l1IlIl1.HDBackgroundImageUrl
m.heroTitle.text = _l1IlIl1.title
_lIIlIl1 = _l1d_462afc("b7b8b4c4cb", 159, 229)
if _l1IlIl1.kind <> invalid and _l1IlIl1.kind = _l1d_462afc("a5a6", 182, 227) then
_lIIlIl1 = _l1d_462afc("afb009bba7a5c0", 78, 149)
else if _l1IlIl1.ContentType = 2 then
_lIIlIl1 = _l1d_462afc("b9ba0bbda9afca", 202, 27)
end if
if m.heroBadge <> invalid then
m.heroBadge.text = _l1d_462afc("93939a8a8c96a2a6cd", 253, 216) + _lIIlIl1
end if
_l1l1Il1 = ""
if _l1IlIl1.Rating <> invalid and _l1IlIl1.Rating <> "" then
_l1l1Il1 = _l1d_462afc("7e8b", 123, 45) + _l1IlIl1.Rating + _l1d_462afc("dfe2e5", 126, 129)
end if
if _l1IlIl1.ReleaseDate <> invalid and _l1IlIl1.ReleaseDate <> "" then
_l1l1Il1 = _l1l1Il1 + _l1IlIl1.ReleaseDate + _l1d_462afc("2427562d30", 24, 236)
end if
_l1l1Il1 = _l1l1Il1 + _lIIlIl1
if _l1IlIl1.Categories <> invalid and _l1IlIl1.Categories.Count() > 0 then
_lI1lIl1 = ""
_lll1Il1 = 2
if _l1IlIl1.Categories.Count() <= 2 then _lll1Il1 = _l1IlIl1.Categories.Count() - 1
for _llIlIl1 = 0 to _lll1Il1
if _llIlIl1 > 0 then _lI1lIl1 = _lI1lIl1 + _l1d_462afc("150c", 163, 134)
_lI1lIl1 = _lI1lIl1 + _l1IlIl1.Categories[_llIlIl1].ToStr()
end for
if _lI1lIl1 <> "" then _l1l1Il1 = _l1l1Il1 + _l1d_462afc("a8abd2b1b4", 31, 105) + _lI1lIl1
end if
m.heroMeta.text = _l1l1Il1
m.heroDesc.text = _l1IlIl1.description
updateHeroWatchlistBtn()
end sub
sub updateHeroWatchlistBtn()
if ((27960 - 5592 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.currentItem = invalid or m.heroWatchlistBtn = invalid then return
if WL_IsFavorite(m.currentItem.id) then
m.heroWatchlistBtn.text = _l1d_462afc("7b6c8e5b8ba0b0a8a2a1a7c4c29c", 13, 37)
else
m.heroWatchlistBtn.text = _l1d_462afc("0a04544939515b5a604d4b", 53, 236)
end if
end sub
sub onHeroWatchlistToggle()
if m.currentItem = invalid then return
_lIl1I11 = _l1d_462afc("c0c5d1c5c4", 65, 148)
if m.currentItem.kind <> invalid and (m.currentItem.kind = _l1d_462afc("898e", 80, 101) or m.currentItem.kind = _l1d_462afc("6f687462717e", 202, 182)) then
_lIl1I11 = _l1d_462afc("a3a8", 68, 115)
else if m.currentItem.ContentType = 2 then
_lIl1I11 = _l1d_462afc("5d5e", 55, 26)
end if
_l1l1I11 = {
id: m.currentItem.id,
title: m.currentItem.Title,
kind: _lIl1I11,
year: m.currentItem.ReleaseDate,
poster: m.currentItem.HDPosterUrl,
rating: m.currentItem.Rating
}
WL_ToggleFavorite(_l1l1I11)
updateHeroWatchlistBtn()
_ll11I11 = m.top.getScene()
if _ll11I11 <> invalid and _ll11I11.hasField(_l1d_462afc("d1cbcbd6b8d4d1e6e4", 5, 91)) then
if WL_IsFavorite(m.currentItem.id) then
_ll11I11.showToast = _l1d_462afc("43182e2226653c246e62334b37353c3a535d928f", 235, 139) + m.currentItem.Title
else
_ll11I11.showToast = _l1d_462afc("bdcdc8c9e5d9dd24e1f8dee333dff808fcfaf9ff181a", 207, 32)
end if
end if
end sub
sub onRowItemSelected()
if ((18456 - 3076 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l1ll1I1 = m.rowList.rowItemSelected
if _l1ll1I1 <> invalid and _l1ll1I1.Count() >= 2 then
_ll1l1I1 = _l1ll1I1[0]
_lIIIlI1 = _l1ll1I1[1]
_llll1I1 = m.rowList.content
if _llll1I1 <> invalid and _ll1l1I1 < _llll1I1.getChildCount() then
_lIll1I1 = _llll1I1.getChild(_ll1l1I1)
if _lIll1I1 <> invalid and _lIIIlI1 < _lIll1I1.getChildCount() then
m.top.selectedItem = _lIll1I1.getChild(_lIIIlI1)
end if
end if
end if
end sub
sub onHeroPlay()
if m.currentItem <> invalid then
m.top.selectedItem = m.currentItem
end if
end sub
function onKeyEvent(_l11l1lI as String, _lI1l1lI as Boolean) as Boolean
if ((56187 - 6243 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if not _lI1l1lI then return false
if _l11l1lI = _l1d_462afc("463039354c", 172, 104) then
if m.heroPlayBtn.hasFocus() then
m.heroWatchlistBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("2d29293e", 162, 95) then
if m.heroWatchlistBtn.hasFocus() then
m.heroPlayBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("3339", 20, 210) then
if m.rowList.hasFocus() and m.rowList.rowItemFocused[0] = 0 then
m.heroPlayBtn.setFocus(true)
return true
end if
else if _l11l1lI = _l1d_462afc("f4ee09f3", 238, 106) then
if m.heroPlayBtn.hasFocus() or m.heroWatchlistBtn.hasFocus() then
m.rowList.setFocus(true)
return true
end if
end if
return false
end function
function _l1d_462afc(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function