sub init()
m.viewHost = m.top.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("57d3f546daae37e019"))
m.leftToolbar = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("5d3b0e019ca66a75882346b9"))
m.tabSearch = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3db60ce1f7db20f40a9f"))
m.tabSearchFocus = m.top.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("592257b81011fb5a8ea012ca535882"))
m.tabSearchIndicator = m.top.findNode(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("2c473e4d14722f68256a03340220071b191903"))
m.iconSearch = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("32de43889d53377c70661b"))
m.tabHome = m.top.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("5d7f9d4e3fb0f903"))
m.tabHomeFocus = m.top.findNode(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("2fc13dcb0ce531e409c402ab0f"))
m.tabHomeIndicator = m.top.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("4e8d421c4c26e9b1d0d51d5e4609fa9a76"))
m.iconHome = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("40e5200b1e1a2c4792"))
m.tabPremiumTv = m.top.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("507b6445483bc4e61538e71091"))
m.tabPremiumTvFocus = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("27ba2d40bcd679c4af1ae52943cf21cc6762"))
m.tabPremiumTvIndicator = m.top.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("53532282055446bcaac038a4f7f2041c603bb174e7ab"))
m.iconPremiumTv = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("6741e6aba0c6e91fa4692db3294c"))
m.tabAccount = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("5d8ea6aaccb1b4aba4b0a9"))
m.tabAccountFocus = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("787fb5eac1e4e92e9248acd4470cb015"))
m.tabAccountIndicator = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("6f0e26260c2d3037243c29294542524b503e5846"))
m.iconAccount = m.top.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("46757e67b659d50c3572bef7"))
m.tabLiveTv = m.top.findNode(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("537162117f4c051cd86b"))
m.tabLiveTvFocus = m.top.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("47d648e8ab4e38fac0bfd3b98fc0f9"))
m.tabLiveTvIndicator = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("58160406f71523170b2c042a272d262b433b43"))
m.iconLiveTv = m.top.findNode(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("75cc78c962e278f470cc55"))
m.tabShows = m.top.findNode(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("5e0b4c0166335e2241"))
m.tabShowsFocus = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("6fae8499ab0378fcc1f58cd1f5da"))
m.tabShowsIndicator = m.top.findNode(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("52019062b37df64c9a2689ebbe966c578251"))
m.iconShows = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("5621864b60984a5fe5aa"))
m.tabMovies = m.top.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("666f9ad4bc3d1d6e4019"))
m.tabMoviesFocus = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("3a60c3e6b8d4a7ba25a0521641dcd7"))
m.tabMoviesIndicator = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("79f6e6eac8ed07edfc0dd6fe07ff0c0d231127"))
m.iconMovies = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("21ff64291e5538ac22e78b"))
m.tabNew = m.top.findNode(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("4d515f5b687945"))
m.tabNewFocus = m.top.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("6bbd90daabbaeed281face5e"))
m.tabNewIndicator = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("7d72c89de4977b63f69b70d5faae24d8"))
m.iconNew = m.top.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("218c879e9fbe3bb1"))
m.tabCategories = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("76b6c4caaccdc5d7dcd7cfd7e6d7"))
m.tabCategoriesFocus = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("4e32d5f8faf669ec0752c57823de50947fda15"))
m.tabCategoriesIndicator = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("2c8326292d47ba3d3803f649740f6b4da88bc6e154877a"))
m.iconCategories = m.top.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("5548326b4322f10e228bb02fc1aafe"))
m.tabMyList = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("7c2e44466e45755b4446"))
m.tabMyListFocus = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("665d1308dfa1f9ac10856de025892e"))
m.tabMyListIndicator = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("305fc2c5b923d7b974b7dbfd58fb36510437ea"))
m.iconMyList = m.top.findNode(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("3e2a4ab83623f6e23220f1"))
m.toolbarLabelPill = m.top.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("396e70c861c9b1ae1b2ab309e287b0a9c1"))
m.toolbarLabelBg = m.top.findNode(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("43f95ff047f77bed5ec95ab7588072"))
m.toolbarLabelText = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("56f602050710100633191f231f3a2c1423"))
m.toolbarFocusTrap = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("48b6ced1d7ccd0c2f9e3dad3d0fad7ebdf"))
if m.toolbarFocusTrap <> invalid then m.toolbarFocusTrap.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("4bab0e111c7f8274d093e62174070a"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("4e70c89648b3ab4128bdf4dc89fc7440eaf0881cc970"))
m.isToolbarFocused = false
m.toolbarIndex = 1
m.toolbarTabs = [
{ id: _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("4431acd75add40"), name: _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("7480458d4d9579"), focus: m.tabSearchFocus, indicator: m.tabSearchIndicator, icon: m.iconSearch },
{ id: _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("5a92274cd1"), name: _llI11IIIIlI1lIll1I111IIIl1l11lI("742fd74ea6"), focus: m.tabHomeFocus, indicator: m.tabHomeIndicator, icon: m.iconHome },
{ id: _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("712e2e3e304247"), name: _llI11IIIIlI1lIll1I111IIIl1l11lI("66d318982532a739"), focus: m.tabLiveTvFocus, indicator: m.tabLiveTvIndicator, icon: m.iconLiveTv },
{ id: _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("57264638463d6f"), name: _llI11IIIIlI1lIll1I111IIIl1l11lI("3eed77fd088d6cc8f2"), focus: m.tabShowsFocus, indicator: m.tabShowsIndicator, icon: m.iconShows },
{ id: _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("50746f4275e03b"), name: _llI11IIIIlI1lIll1I111IIIl1l11lI("241e2ffcdd7572"), focus: m.tabMoviesFocus, indicator: m.tabMoviesIndicator, icon: m.iconMovies },
{ id: _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("3f9a9a2a"), name: _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("30ab39aac2d3bfd0e43e4113a050"), focus: m.tabNewFocus, indicator: m.tabNewIndicator, icon: m.iconNew },
{ id: _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("44d041cc4bc77cd37cd66d"), name: _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("5f9bb6ef54fa28e9bbd52f"), focus: m.tabCategoriesFocus, indicator: m.tabCategoriesIndicator, icon: m.iconCategories },
{ id: _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("24eaae04b95d92"), name: _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("72a10d5ecaae092c"), focus: m.tabMyListFocus, indicator: m.tabMyListIndicator, icon: m.iconMyList },
{ id: _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("4b881a9ba8641f45ce41"), name: _llI11IIIIlI1lIll1I111IIIl1l11lI("3176f6b3eb0532965eff49"), focus: m.tabPremiumTvFocus, indicator: m.tabPremiumTvIndicator, icon: m.iconPremiumTv },
{ id: _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("456f5e4eff0a5ca9"), name: _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("6e3cd302ff67cc66"), focus: m.tabAccountFocus, indicator: m.tabAccountIndicator, icon: m.iconAccount }
]
_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = _lll1l1I1l1ll1I1IlI1lIIIIl11l1l111I()
if _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll <> invalid and _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll <> "" then
end if
m.toastGroup = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("5d7b3ef974a7298d80dbbe"))
m.toastText = m.top.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("433cf297bb50576b1f64"))
m.verifyOverlay = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("7136d96ccfe265c18326b9f467b2"))
m.verifyTitle = m.top.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("30b4c8b6c2d0b8e8ceced9e3"))
m.verifyDetail = m.top.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6e1f925508cb9ed2d4670a5548"))
m.viewStack = []
m.lastVerifyTime = CreateObject(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("3b7f666a861261b7c116ef")).AsSeconds()
m.consecutiveVerifyFailures = 0
m.top.observeField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("5f7351765c797571"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("54596ea2a8cd82d70a81c6ecd1"))
if not m.global.hasField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("411e8dfa505ae078d29000bfd0dbed8112da83f9")) then m.global.addField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("305f3aedb00baed114f0eabdf05bb6425c573a9d"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("65986e73a72d"), false)
if not m.global.hasField(_llI11IIIIlI1lIll1I111IIIl1l11lI("59226cbf92c97deecddedfff745b82a897013352")) then m.global.addField(_llI11IIIIlI1lIll1I111IIIl1l11lI("5353a8dab8b00424746fba5f0f26b363e23b5e29"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("67c1d5dad054"), false)
if not m.global.hasField(_llI11IIIIlI1lIll1I111IIIl1l11lI("7421d74ea66f2b8e25ff68a7742b")) then m.global.addField(_llI11IIIIlI1lIll1I111IIIl1l11lI("7eae3940b92364d0faa0e16bf55a"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("660e02071da1"), false)
m.watchdogTickCount = 0
m.sessionWatchdogTimer = CreateObject(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("3ed4d2b9b0bcded8da"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("3cf155408b2e"))
m.sessionWatchdogTimer.duration = 10
m.sessionWatchdogTimer.repeat = true
m.sessionWatchdogTimer.observeField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("69eb61f96d"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("582a3ff199fd02684d62d4fcd0269be075faeca449ce"))
if _ll11llllII111I1II1I1I1IIllII11I11I() then
verifyAndShowHome()
else
showKeyAuthView()
end if
m.initFocusTimer = CreateObject(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("7d545c3b4a44687074"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("4bfbcd92176d"))
m.initFocusTimer.duration = 0.15
m.initFocusTimer.repeat = false
m.initFocusTimer.observeField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("7a8172937e"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("39dd4575e333c1f07c556ef8e4c9a89e16"))
m.initFocusTimer.control = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("5f3d50c35671")
end sub
sub verifyAndShowHome()
_llll1I11llIlll11lII11l11111IIIl = _lll1l1I1l1ll1I1IlI1lIIIIl11l1l111I()
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_lllIIlIlII1ll111l1Il11Illlll11l11I1) then
_ll11I1III1II11lIlI11IlI11ll1lIIlll()
showToast(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("6ff7039020561db4f6de9be968de552e"))
showKeyAuthView()
if m.keyAuthView <> invalid then
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = m.keyAuthView.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("323e2d836f7c4e5808fce943eb"))
if _llI111lI11I1l11lI11l1lIlll11111lIIlI1II <> invalid then
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II.text = _llI11IIIIlI1lIll1I111IIIl1l11lI("6f43cae736bf2ebf06cdeb8f4005b787d1a1bbfa227c108d8a551cccb5846db7783cd6e5fe4aaf3781dcab044d6c795a974b2b4b13d9f78b5d118bd03b8b")
end if
end if
return
end if
setHeaderVisible(false)
if m.verifyOverlay <> invalid then
m.verifyOverlay.visible = true
if m.verifyTitle <> invalid then m.verifyTitle.text = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("39fa2693005360941cd5145c9a88a93f360fafd8") + _llll1I11llIlll11lII11l11111IIIl
if m.verifyDetail <> invalid then m.verifyDetail.text = _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3de92c2126db00d4aa3fd425ed63341e52d76c13861a52f529fe7038ae7f78bdb2372c80f6a7f045aa8fe4b89ecf68ccdef7dcb0869ad021262b")
end if
if m.verifyTask <> invalid then m.verifyTask.control = _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("680c5ee2fc")
m.verifyTask = CreateObject(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("4fa87ec40a7f92e7fc"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("59467053536e6d7b4a475f26"))
m.verifyTask.action = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("384e132111017d")
m.verifyTask.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("77db7ef914d722"), _llI11IIIIlI1lIll1I111IIIl1l11lI("2fac9dbbdc6b0d53a1e16023043e0e8e9b1a276ae780"))
m.verifyTask.control = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("6a476ca6")
end sub
sub onStartupVerifyResult()
if m.verifyOverlay <> invalid then m.verifyOverlay.visible = false
_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = m.verifyTask.result
if _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il <> invalid and _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il.success = true then
m.consecutiveVerifyFailures = 0
m.lastVerifyTime = CreateObject(_llI11IIIIlI1lIll1I111IIIl1l11lI("7ddb48109bc076886688d3")).AsSeconds()
showToast(_llI11IIIIlI1lIll1I111IIIl1l11lI("4ceda76cdaabee57cac30c87c3957688b0") + _lll1l1I1l1ll1I1IlI1lIIIIl11l1l111I())
showHomeView(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("26766964af"))
startSessionWatchdog()
else
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("341f161c0b1e2901774177377e396c1f74")
if _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il <> invalid and _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il.message <> invalid and _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il.message <> "" then
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _llIlIlll1I11IllIIllI1lIllII11l1llI(_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il.message)
end if
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = _ll11II111ll1l1I1Ill1lIIl1lIII1llll(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I)
_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = (not _lllIIllll1llIIlllIllI11lll1ll1lIl11) or (_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il <> invalid and _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il.isNetworkError = true) or _lllI1I1I1lll111IIll1Il111Il11lll11(_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I)
if not _lllIIllll1llIIlllIllI11lll1ll1lIl11 and not _lll1lllIllIllII11II1IllI1IIIllIll1(_lll1IllI11ll1IllllIllI1l11II1III11()) then
m.consecutiveVerifyFailures = 0
m.lastVerifyTime = CreateObject(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("429558b766ab48936e9e61")).AsSeconds()
showToast(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("72ebba91d983788e5b23b9be0bd5ff91d9e38a6d1a4ef8112a23b812d801fe10"))
showHomeView(_llI11IIIIlI1lIll1I111IIIl1l11lI("6312e258b3"))
startSessionWatchdog()
else
_ll11I1III1II11lIlI11IlI11ll1lIIlll()
showToast(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("6dd4e6e1e1cae800daf309094d46") + _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I)
showKeyAuthView()
if m.keyAuthView <> invalid then
_llIll1IIIII1ll1l11III111lIII1ll = m.keyAuthView.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("3cafb1c7b7b9bef0d2c6dce7e7"))
if _llIll1IIIII1ll1l11III111lIII1ll <> invalid then
_llIll1IIIII1ll1l11III111lIII1ll.text = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("6a98bab4c2cfccfe17") + _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I + chr(10) + _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("4e8335adfa9268a9bf976f37211802109d0e059eb3eaf9bbee85dcdd70c1db2c94fe35a0baf96dc9fc36464e27b2e2b3c6ce0e9caa69585bf6c7defed14070a0165e1dcddafac84afcd4e7f7e0f0a9")
end if
end if
end if
end if
end sub
sub onSceneFocus()
if m.top.hasFocus() then
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then return
if m.isToolbarFocused then
if m.toolbarFocusTrap <> invalid then m.toolbarFocusTrap.setFocus(true)
return
end if
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
end sub
sub onInitFocusTimer()
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then return
if m.isToolbarFocused then return
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
if m.initFocusTimer <> invalid then m.initFocusTimer.control = _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("7bce7bdc7f")
end sub
sub showHomeView(_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3390856aef") as String)
if not _ll11llllII111I1II1I1I1IIllII11I11I() or _lll1lllIllIllII11II1IllI1IIIllIll1(_lll1IllI11ll1IllllIllI1l11II1III11()) then
kickoutUser(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("67001fe5edf8d02390ff756ef422ea6b18edccb59d51e0b2c3b7853e0dabda9329461e860ee1b12ad8b9d58c55fb6ba3ba36ce363e4b2232a8ce679ec528f8b36945dd26aec1b249d0be1404575ab06a5a152f569f91c21a"))
return
end if
clearViews()
m.isToolbarFocused = false
m.viewHost.translation = [140, 0]
if m.cachedHomeViews = invalid then m.cachedHomeViews = {}
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill
if m.cachedHomeViews[_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11] = invalid then
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = CreateObject(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("245cff69d4272b0e11"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("7cdb5cd04fea4fef46"))
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.category = _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.observeField(_llI11IIIIlI1lIll1I111IIIl1l11lI("50f0a49412986a96c51e3531da"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("75a9abd197abb6c7b4bebac3afc3c5"))
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.observeField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("6cb3b9cd83787df426fcb115"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("396163406a6b76677a8c7c7c7f6b9f918da6"))
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.observeField(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("33ddf5ede512fff50aff0b"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("7588aab9648e4474805060f20db41c89ca"))
m.cachedHomeViews[_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11] = _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I
end if
m.homeView = m.cachedHomeViews[_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11]
m.homeView.isToolbarFocused = false
m.viewHost.appendChild(m.homeView)
m.viewStack.Push(m.homeView)
setHeaderVisible(true)
updateNavSelection(_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill)
focusActiveView(m.homeView)
if m.tabsPreloaded <> true then
m.tabsPreloaded = true
preloadAllTabs()
end if
end sub
sub onHomeOpenDrawer()
m.isToolbarFocused = false
focusToolbar(m.activeTab)
end sub
sub onHomeScrollEvent()
checkLicenseOnInteraction()
end sub
sub showDetailsView(_llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII as Object)
checkLicenseOnInteraction()
m.isToolbarFocused = false
m.viewHost.translation = [0, 0]
m.detailsView = CreateObject(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("2eb5032c7b01e1cb30"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("656143794d78776e49584233"))
m.detailsView.content = _llII1I1Il1II1I11l1l1Il1111lIlIllIll1lII
m.detailsView.observeField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("64f5bbf074f81f5389ee03"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("450609c52f62ad797326597477"))
m.detailsView.observeField(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("21e99996cdf441b1e292a0cf47"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("5680bbca18603d9292c2bf101a21bf"))
m.viewHost.appendChild(m.detailsView)
m.viewStack.Push(m.detailsView)
setHeaderVisible(false)
m.detailsView.setFocus(true)
end sub
sub onCloseDetails()
popDetailsView()
end sub
sub popDetailsView()
m.isToolbarFocused = false
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_llI1l11llI1lII11Il11lIII1l1l1ll = m.viewStack.Peek()
if _llI1l11llI1lII11Il11lIII1l1l1ll <> invalid and _llI1l11llI1lII11Il11lIII1l1l1ll.isSubtype(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("4f83525f837a135c543a13dc")) then
m.viewHost.removeChild(_llI1l11llI1lII11Il11lIII1l1l1ll)
m.viewStack.Pop()
m.detailsView = invalid
end if
end if
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_llIl11IIl1IlII1lII1IIllIlllllIl1111IIll = m.viewStack.Peek()
if _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll <> invalid then
if _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.isSubtype(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("583b78306b0a6b0f62")) or _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.isSubtype(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("3db5e2e9ddf1e9c2f0f7ec")) or _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.isSubtype(_llI11IIIIlI1lIll1I111IIIl1l11lI("3d35522f82f021916ef266")) or _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.isSubtype(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("7685f9cbd6bf154ff2c0710d5d858c")) or _llIl11IIl1IlII1lII1IIllIlllllIl1111IIll.isSubtype(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("3412111b0608221b1b2d1046")) then
m.viewHost.translation = [140, 0]
setHeaderVisible(true)
end if
focusActiveView(_llIl11IIl1IlII1lII1IIllIlllllIl1111IIll)
return
end if
end if
showHomeView(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("643a363b46"))
end sub
sub showPlayerView(_llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII as Object)
m.viewHost.translation = [0, 0]
m.playerView = CreateObject(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("5a5483ec5a80e0ca92"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("6db9f666c837abd8247549"))
m.playerView.observeField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("704156fbd0857aef0399eee388"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("5537eeb66031403cba6d853956cad9442d66ddc332"))
m.playerView.observeField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("2897cce1a74ba3e59a2064da"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("279295499bbee984e8d28550bb2e"))
m.playerView.playConfig = _llI1lI11IIlIllIIl1lI1IlIll1IllII1IIllII
m.viewHost.appendChild(m.playerView)
m.viewStack.Push(m.playerView)
setHeaderVisible(false)
m.playerView.setFocus(true)
end sub
sub showSearchView()
clearViews()
m.viewHost.translation = [140, 0]
if m.cachedSearchView = invalid then
m.cachedSearchView = CreateObject(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("4c70937de8bbbf2225"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("22a13d28cb4e910b9f8a25"))
m.cachedSearchView.observeField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("6d967c966e9946815ca566cd65"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("60e8fd14665ce1c76b0075da8e8499"))
end if
m.searchView = m.cachedSearchView
m.viewHost.appendChild(m.searchView)
m.viewStack.Push(m.searchView)
setHeaderVisible(true)
updateNavSelection(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("2d6b4f946a7e13"))
m.searchView.setFocus(true)
end sub
sub showMyListView()
clearViews()
m.viewHost.translation = [140, 0]
if m.cachedMyListView = invalid then
m.cachedMyListView = CreateObject(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("34b94750ed7f678757"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("5cd039b749cabc490c4533"))
m.cachedMyListView.observeField(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("384f48544e4b65575b8171636e"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("7b2d2f111f333e033c46423f374b4d"))
end if
m.myListView = m.cachedMyListView
if m.myListView.hasField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("4f875f8d5093798146ad5bd3")) then
m.myListView.refreshList = true
end if
m.viewHost.appendChild(m.myListView)
m.viewStack.Push(m.myListView)
setHeaderVisible(true)
updateNavSelection(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("48bc27dabdf83b"))
m.myListView.setFocus(true)
end sub
sub showCategoriesView()
clearViews()
m.isToolbarFocused = false
m.viewHost.translation = [140, 0]
if m.cachedCategoriesView = invalid then
m.cachedCategoriesView = CreateObject(_llI11IIIIlI1lIll1I111IIIl1l11lI("355b2bd7ce7980e731"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("58df041c0e0f1a221e1d2a122a293a"))
m.cachedCategoriesView.observeField(_llI11IIIIlI1lIll1I111IIIl1l11lI("52558c7d71e840311e1596b63873b0c467"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3380754c2fe5f91ea359ce75178c21861c3025"))
m.cachedCategoriesView.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6244670a6d27a316d14ccf"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3e1a2f16294ed33aace257fea0b6da00b4"))
end if
m.categoriesView = m.cachedCategoriesView
m.categoriesView.isToolbarFocused = false
m.viewHost.appendChild(m.categoriesView)
m.viewStack.Push(m.categoriesView)
setHeaderVisible(true)
updateNavSelection(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("75a5a694a8adb8a6c0b7b0"))
m.categoriesView.setFocus(true)
end sub
sub showKeyAuthView()
stopSessionWatchdog()
clearViews()
m.viewHost.translation = [0, 0]
m.keyAuthView = CreateObject(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("67877db272b26cb076"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("772e6b3a566f067f693022b3"))
m.keyAuthView.observeField(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("7de13024dc062d7b79ea083a44eea753c033"), _llI11IIIIlI1lIll1I111IIIl1l11lI("783c6b2f628354e312a98dbe380fc649a0"))
m.keyAuthView.observeField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("712fbe0e214ff8ef1da9"), _llI11IIIIlI1lIll1I111IIIl1l11lI("4a9f31f7f91e5171134e5423c2e655"))
m.viewHost.appendChild(m.keyAuthView)
m.viewStack.Push(m.keyAuthView)
setHeaderVisible(false)
focusActiveView(m.keyAuthView)
end sub
sub onKeyAuthSuccess()
m.lastVerifyTime = CreateObject(_llI11IIIIlI1lIll1I111IIIl1l11lI("399f74694502b7bb2bb41b")).AsSeconds()
showToast(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("5fbbb7cc5499aa48d2512d955c12a1f083af7e3ac7c9b8d8c806fca56c23b1e9"))
showHomeView(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("363a319a80"))
startSessionWatchdog()
end sub
sub onKeyAuthClose()
if _ll11llllII111I1II1I1I1IIllII11I11I() then
showHomeView(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("26bec5cd99"))
end if
end sub
sub onCategorySelected(_llII1lIllll111111l1llII1I1l1I1l as Object)
_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = _llII1lIllll111111l1llII1I1l1I1l.getData()
if _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = invalid or _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = "" then return
if _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = _llI11IIIIlI1lIll1I111IIIl1l11lI("49919680d43345") then
showSearchView()
else if _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("48ec671a6dd0fbde195c") then
showMyListView()
else if _ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("2a19749f6a152853") then
showKeyAuthView()
else
showHomeView(_ll1I1ll111ll1I111IIl11ll1Il1III1ll11l1l)
end if
end sub
sub clearViews()
m.viewHost.removeChildrenIndex(m.viewHost.getChildCount(), 0)
m.viewStack.Clear()
end sub
sub setHeaderVisible(_llI1ll1Il1llIlIIll1l11Il1llllIlllI1 as Boolean)
if m.leftToolbar <> invalid then m.leftToolbar.visible = _llI1ll1Il1llIlIIll1l11Il1llllIlllI1
end sub
sub onItemSelected(_ll11Illlll11l1I1IIlIl11II11lIlII1III11I as Object)
if not _ll11llllII111I1II1I1I1IIllII11I11I() then
kickoutUser(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("4e8f758f6a9443d81dda00b21cf952cf17971289f49ff8d38fdf82c082a49bf8dbcfc09f8f8d3fc728cf35eb39e926db"))
return
end if
_ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_ll1l1I1lllIll1lIl11lII1IlI1l1l1IlIIIlIIlI1l) then
kickoutUser(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("620e80f38704a6dce8e939f9ec8e5f45504bd0e1571d15ce381201265e16acb782d86032a78c0487882a11180f64dfc7b2a812a395fcb6edf8f2c8e8df5faed65910c31387eea51d6842"))
return
end if
_llI1lll1ll1Il1111Ill1I111Il111I = _ll11Illlll11l1I1IIlIl11II11lIlII1III11I.getData()
if _llI1lll1ll1Il1111Ill1I111Il111I <> invalid then
if _llI1lll1ll1Il1111Ill1I111Il111I.hasField(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("3a7e7c9a868f9dc692aba8939e")) and _llI1lll1ll1Il1111Ill1I111Il111I.directResume = true then
_llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI = ""
if _llI1lll1ll1Il1111Ill1I111Il111I.hasField((Chr(105) + Chr(100))) and _llI1lll1ll1Il1111Ill1I111Il111I.id <> invalid and _llI1lll1ll1Il1111Ill1I111Il111I.id <> "" then
_llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI = _llI1lll1ll1Il1111Ill1I111Il111I.id.ToStr()
else if _llI1lll1ll1Il1111Ill1I111Il111I.hasField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("62143f120d")) and _llI1lll1ll1Il1111Ill1I111Il111I.imdb <> invalid and _llI1lll1ll1Il1111Ill1I111Il111I.imdb <> "" then
_llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI = _llI1lll1ll1Il1111Ill1I111Il111I.imdb.ToStr()
end if
_llll1I11Ill11IlI11ll1lllIll1I1ll1l1 = _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("6abf6f032dfe")
if _llI1lll1ll1Il1111Ill1I111Il111I.hasField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("59ec1126cb")) and _llI1lll1ll1Il1111Ill1I111Il111I.kind <> invalid and _llI1lll1ll1Il1111Ill1I111Il111I.kind <> "" then _llll1I11Ill11IlI11ll1lllIll1I1ll1l1 = _llI1lll1ll1Il1111Ill1I111Il111I.kind.ToStr()
_lllIllII11lIlIIlllI11l1II11lllI1lI1IIl11Ill = 1
_lll1I1I1IIl1I1IlIII1l1I111l11lI = 1
if _llI1lll1ll1Il1111Ill1I111Il111I.hasField(_llI11IIIIlI1lIll1I111IIIl1l11lI("6ca068f04cc775")) and _llI1lll1ll1Il1111Ill1I111Il111I.season <> invalid and _llI1lll1ll1Il1111Ill1I111Il111I.season > 0 then _lllIllII11lIlIIlllI11l1II11lllI1lI1IIl11Ill = _llI1lll1ll1Il1111Ill1I111Il111I.season
if _llI1lll1ll1Il1111Ill1I111Il111I.hasField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("41585348525d6655")) and _llI1lll1ll1Il1111Ill1I111Il111I.episode <> invalid and _llI1lll1ll1Il1111Ill1I111Il111I.episode > 0 then _lll1I1I1IIl1I1IlIII1l1I111l11lI = _llI1lll1ll1Il1111Ill1I111Il111I.episode
_ll11l1lI1II1l1lllIlI1llIl11l11111II111l = ""
if _llI1lll1ll1Il1111Ill1I111Il111I.Title <> invalid and _llI1lll1ll1Il1111Ill1I111Il111I.Title <> "" then
_ll11l1lI1II1l1lllIlI1llIl11l11111II111l = _llI1lll1ll1Il1111Ill1I111Il111I.Title
else if _llI1lll1ll1Il1111Ill1I111Il111I.title <> invalid and _llI1lll1ll1Il1111Ill1I111Il111I.title <> "" then
_ll11l1lI1II1l1lllIlI1llIl11l11111II111l = _llI1lll1ll1Il1111Ill1I111Il111I.title
end if
_lllI1lIIlll1IIlI11IIlI1Il111l1I = ""
if _llI1lll1ll1Il1111Ill1I111Il111I.HDPosterUrl <> invalid and _llI1lll1ll1Il1111Ill1I111Il111I.HDPosterUrl <> "" then _lllI1lIIlll1IIlI11IIlI1Il111l1I = _llI1lll1ll1Il1111Ill1I111Il111I.HDPosterUrl
_ll1IlIl1llIIlIlI1I1I1II11lll1IlII11lI1III11 = {
imdbId:  _llIIlIlIlI1I1l1I1lllIllll1IIIlIll1l1IlI,
title:   _ll11l1lI1II1l1lllIlI1llIl11l11111II111l,
kind:    _llll1I11Ill11IlI11ll1lllIll1I1ll1l1,
season:  _lllIllII11lIlIIlllI11l1II11lllI1lI1IIl11Ill,
episode: _lll1I1I1IIl1I1IlIII1l1I111l11lI,
poster:  _lllI1lIIlll1IIlI11IIlI1Il111l1I
}
showPlayerView(_ll1IlIl1llIIlIlI1I1I1II11lll1IlII11lI1III11)
else
showDetailsView(_llI1lll1ll1Il1111Ill1I111Il111I)
end if
end if
end sub
sub onPlayAction(_lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I as Object)
_lllIIIl1ll1ll1IllIllll11l11l111Ill11111 = _lllIl11Il1IllI1I1lll1IIIIIl11III11ll11ll11I.getData()
if _lllIIIl1ll1ll1IllIllll11l11l111Ill11111 <> invalid then
if not _ll11llllII111I1II1I1I1IIllII11I11I() then
kickoutUser(_llI11IIIIlI1lIll1I111IIIl1l11lI("6268d94aa231b752baf1caaa209516adb748d1c57b6e61e7ea6528d4dd7b0772a2bf49793cb251253e28f5d4b371d98b42a01b7331"))
return
end if
_llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1 = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_llIlIl11I1IIlI11l11l1llI11Il1I11l11llI1) then
kickoutUser(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("6efc3356068ab11ba37a701782c8b258a5a9331604bab798612b805d4238f1d4a32b375840fba218e22a379b47f8a25b63ab33da06bab69a71b9329b03787459f07ab157b164f1c8a704779883bb22"))
return
end if
showPlayerView(_lllIIIl1ll1ll1IllIllll11l11l111Ill11111)
end if
end sub
sub onClosePlayer()
if m.viewStack.Count() > 0 then
_ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l = m.viewStack.Peek()
if _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l <> invalid and _ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l.isSubtype(_llI11IIIIlI1lIll1I111IIIl1l11lI("6268d98b249c9070c733cf")) then
m.viewHost.removeChild(_ll11llIIIII1I1llIII1I1Il1IIlI1lIl1lIl1l)
m.viewStack.Pop()
if m.viewStack.Count() > 0 then
_ll111IlI111II11ll1llIl11I1II11l = m.viewStack.Peek()
if _ll111IlI111II11ll1llIl11I1II11l.isSubtype(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("55caecede8bcfaf1e6")) or _ll111IlI111II11ll1llIl11I1II11l.isSubtype(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("7480458d4d9579a25da748")) or _ll111IlI111II11ll1llIl11I1II11l.isSubtype(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("27c789c194384d74a86d91")) or _ll111IlI111II11ll1llIl11I1II11l.isSubtype(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("65452634282d38464037506e4c4358")) or _ll111IlI111II11ll1llIl11I1II11l.isSubtype(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("793c708326a8a4aeb25dd8")) or _ll111IlI111II11ll1llIl11I1II11l.isSubtype(_llI11IIIIlI1lIll1I111IIIl1l11lI("5c0f58339403ab102e6f5c34a1eb")) then
m.viewHost.translation = [140, 0]
setHeaderVisible(true)
else if _ll111IlI111II11ll1llIl11I1II11l.isSubtype(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("5ac6c85bbe89bc6fa3b520bb")) then
setHeaderVisible(false)
end if
focusActiveView(_ll111IlI111II11ll1llIl11I1II11l)
if _ll111IlI111II11ll1llIl11I1II11l <> invalid and _ll111IlI111II11ll1llIl11I1II11l.isSubtype(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("56995dc472beb00217")) then
end if
else
showHomeView(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("7e577e5c6d"))
end if
end if
end if
end sub
sub focusActiveView(_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l as Object)
if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l = invalid then return
if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_llI11IIIIlI1lIll1I111IIIl1l11lI("25fa5d33cf6233b0783e970d")) then
setHeaderVisible(false)
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
_ll1llll1lIlllll11III1lI11I1IIII11lll111 = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("2b53976cf2842cd0"))
if _ll1llll1lIlllll11III1lI11I1IIII11lll111 <> invalid then _ll1llll1lIlllll11III1lI11I1IIII11lll111.setFocus(true)
else if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_llI11IIIIlI1lIll1I111IIIl1l11lI("5523a7f810fa239b28")) then
setHeaderVisible(true)
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
_lll1II1IlIllI11ll11lII111I1llI1Il1l = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("5a55404460684566"))
if _lll1II1IlIllI11ll11lII111I1llI1Il1l <> invalid then _lll1II1IlIllI11ll11lII111I1llI1Il1l.setFocus(true)
else if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("2558a9c665160b6590112186e5d0")) then
setHeaderVisible(true)
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isToolbarFocused = false
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.hasField(_llI11IIIIlI1lIll1I111IIIl1l11lI("5a4aab74fea64f0b8268f7be")) then
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.resumeFocus = true
else
_lll1II1IlIllI11ll11lII111I1llI1Il1l = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("4d323725206028434b33504c"))
if _lll1II1IlIllI11ll11lII111I1llI1Il1l <> invalid then _lll1II1IlIllI11ll11lII111I1llI1Il1l.setFocus(true)
end if
else if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("78eeccdace02e306deddee")) then
setHeaderVisible(true)
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
_lll1II1IlIllI11ll11lII111I1llI1Il1l = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("7d1269c4e81fcb64d3935505"))
if _lll1II1IlIllI11ll11lII111I1llI1Il1l <> invalid then _lll1II1IlIllI11ll11lII111I1llI1Il1l.setFocus(true)
else if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("55b18fd00352e319252cc7")) then
setHeaderVisible(true)
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111 = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("36fbb097c039f014e0"))
if _llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111 <> invalid then _llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111.setFocus(true)
else if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("6c7a89dde9c1eb5e08634fa768806c")) then
setHeaderVisible(true)
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
_ll1llll1lIlllll11III1lI11I1IIII11lll111 = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("7a534fa182d3ec"))
if _ll1llll1lIlllll11III1lI11I1IIII11lll111 <> invalid then _ll1llll1lIlllll11III1lI11I1IIII11lll111.setFocus(true)
else if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("6564406d577e736d4a5b4130")) then
setHeaderVisible(true)
m.viewHost.translation = [140, 0]
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
_ll1llll1lIlllll11III1lI11I1IIII11lll111 = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("411a0f0a7425df6f0ac7c8"))
if _ll1llll1lIlllll11III1lI11I1IIII11lll111 <> invalid then _ll1llll1lIlllll11III1lI11I1IIII11lll111.setFocus(true)
else if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_llI11IIIIlI1lIll1I111IIIl1l11lI("427ceff6bfbdfc7013bf0b")) then
setHeaderVisible(true)
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
_ll1Il111l1111I1III1l1I111I1lI1III111l1I = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("452cdd4a2285516f7d"))
if _ll1Il111l1111I1III1l1I111I1lI1III111l1I <> invalid then _ll1Il111l1111I1III1l1I111I1lI1III111l1I.setFocus(true)
else if _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.isSubtype(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("33f9eaf10c0305ec29f30213")) then
setHeaderVisible(false)
_llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111 = _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("47ebc32eb089200f70"))
if _llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111 <> invalid then _llIIIIlIIll1II11IIl1I1IIlI1lIII11IlI11lI111.setFocus(true) else _ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
else
_ll11lII11lll1lI1I1IIlll1l1Il1l1Ill1lI1l.setFocus(true)
end if
end sub
sub focusToolbar(_ll1l1Ill1lI1lI11II1I1l1lII1Ill1 = "" as String)
m.isToolbarFocused = true
if m.homeView <> invalid then m.homeView.isToolbarFocused = true
if m.categoriesView <> invalid then m.categoriesView.isToolbarFocused = true
if m.accountView <> invalid then m.accountView.isToolbarFocused = true
if m.premiumTvView <> invalid then m.premiumTvView.isToolbarFocused = true
if m.liveTvView <> invalid then m.liveTvView.isToolbarFocused = true
if _ll1l1Ill1lI1lI11II1I1l1lII1Ill1 <> "" then
for _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl = 0 to m.toolbarTabs.Count() - 1
if m.toolbarTabs[_llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl].id = _ll1l1Ill1lI1lI11II1I1l1lII1Ill1 or (_ll1l1Ill1lI1lI11II1I1l1lII1Ill1 = (Chr(116) + Chr(118)) and m.toolbarTabs[_llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl].id = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("5179f487ea15b0")) or (_ll1l1Ill1lI1lI11II1I1l1lII1Ill1 = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("7484673a85b0") and m.toolbarTabs[_llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl].id = _llI11IIIIlI1lIll1I111IIIl1l11lI("6f6b2c0138a0bd")) then
m.toolbarIndex = _llI1l111l1lllllI1lIIll1IlIlI1lII1lIIIIl
exit for
end if
end for
end if
updateToolbarVisuals()
if m.toolbarFocusTrap <> invalid then
m.toolbarFocusTrap.setFocus(true)
else
m.top.setFocus(true)
end if
end sub
sub unfocusToolbar()
m.isToolbarFocused = false
if m.homeView <> invalid then m.homeView.isToolbarFocused = false
if m.categoriesView <> invalid then m.categoriesView.isToolbarFocused = false
if m.accountView <> invalid then m.accountView.isToolbarFocused = false
if m.premiumTvView <> invalid then m.premiumTvView.isToolbarFocused = false
if m.liveTvView <> invalid then m.liveTvView.isToolbarFocused = false
if m.toolbarLabelPill <> invalid then m.toolbarLabelPill.visible = false
for each _llllIl1III1IlIII1IIIIl11l11lIIl in m.toolbarTabs
if _llllIl1III1IlIII1IIIIl11l11lIIl.focus <> invalid then _llllIl1III1IlIII1IIIIl11l11lIIl.focus.visible = false
end for
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end sub
sub updateToolbarVisuals()
_llI1lIIII1l1l1IlIII1ll1IIlIlll1 = _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("4380010a0f14191e23858a")
_lll1l1IllIIlll1IIl1l1ll1llI11l1 = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("332d2f34dd8aa8db7acc95")
for _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = 0 to m.toolbarTabs.Count() - 1
_llll11lI1IIl1ll1Illll1111lI11IIIIIl = m.toolbarTabs[_llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l]
_lll11lll1l1lII1I1IIlllI1ll1IIll = (_llll11lI1IIl1ll1Illll1111lI11IIIIIl.id = m.activeTab or (m.activeTab = (Chr(116) + Chr(118)) and _llll11lI1IIl1ll1Illll1111lI11IIIIIl.id = _llI11IIIIlI1lIll1I111IIIl1l11lI("7da329751aadd1")) or (m.activeTab = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("2454370a5580") and _llll11lI1IIl1ll1Illll1111lI11IIIIIl.id = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("5706a114d7c23d")))
if _llll11lI1IIl1ll1Illll1111lI11IIIIIl.indicator <> invalid then _llll11lI1IIl1ll1Illll1111lI11IIIIIl.indicator.visible = _lll11lll1l1lII1I1IIlllI1ll1IIll
if _llll11lI1IIl1ll1Illll1111lI11IIIIIl.icon <> invalid then
if _lll11lll1l1lII1I1IIlllI1ll1IIll or (m.isToolbarFocused and _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = m.toolbarIndex) then
_llll11lI1IIl1ll1Illll1111lI11IIIIIl.icon.blendColor = _lll1l1IllIIlll1IIl1l1ll1llI11l1
else
_llll11lI1IIl1ll1Illll1111lI11IIIIIl.icon.blendColor = _llI1lIIII1l1l1IlIII1ll1IIlIlll1
end if
end if
if m.isToolbarFocused and _llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l = m.toolbarIndex then
if _llll11lI1IIl1ll1Illll1111lI11IIIIIl.focus <> invalid then _llll11lI1IIl1ll1Illll1111lI11IIIIIl.focus.visible = true
if m.toolbarLabelPill <> invalid and m.toolbarLabelText <> invalid then
m.toolbarLabelPill.visible = true
m.toolbarLabelPill.translation = [86, 250 + (_llII1IlII11l111I11lll1IIll1IlIIl11lI1II1I1l * 48)]
m.toolbarLabelText.text = _llll11lI1IIl1ll1Illll1111lI11IIIIIl.name
_lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I = 44 + (Len(_llll11lI1IIl1ll1Illll1111lI11IIIIIl.name) * 18)
if _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I < 240 then _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I = 240
if m.toolbarLabelBg <> invalid then m.toolbarLabelBg.width = _lll11l11lll1II1III1IlIlIIlII1Illl1l1l1IlI1I
end if
else
if _llll11lI1IIl1ll1Illll1111lI11IIIIIl.focus <> invalid then _llll11lI1IIl1ll1Illll1111lI11IIIIIl.focus.visible = false
end if
end for
end sub
sub onToolbarTrapSelected()
if m.isToolbarFocused then
_lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1 = m.toolbarTabs[m.toolbarIndex]
executeToolbarSelection(_lll111lI1l1I1lIlI1I111I1lIl1lI11lIl1II1.id)
end if
end sub
sub executeToolbarSelection(_llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I as String)
if m.isExecutingToolbarSelection = true then return
m.isExecutingToolbarSelection = true
unfocusToolbar()
checkLicenseOnInteraction()
if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("52f5907b1ea1e4") then
showSearchView()
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("7afafafb06") then
showHomeView(_llI11IIIIlI1lIll1I111IIIl1l11lI("3d26b079cc"))
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _llI11IIIIlI1lIll1I111IIIl1l11lI("724cc72ac35ab24f2fa6") then
showPremiumTvView()
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("5002b56d567c2b4b") then
showAccountView()
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("636194c74acde8") then
showLiveTvView()
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _llI11IIIIlI1lIll1I111IIIl1l11lI("3397f94d7264e1") then
showHomeView(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3f4d7147bb8066"))
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("60bdbedac2d1de") then
showHomeView(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("7af5fa16020922"))
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("45686277") then
showHomeView(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("3e8b3ed9"))
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3814f9cdc3e86d4197dc40") then
showCategoriesView()
else if _llIllIll1ll11III1ll1II1l1IlIIII1111I11l1l1I = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("4b43ee51845f32") then
showMyListView()
end if
m.isExecutingToolbarSelection = false
end sub
sub showAccountView()
clearViews()
m.viewHost.translation = [140, 0]
if m.cachedAccountView = invalid then
m.cachedAccountView = CreateObject(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("7946ac7c170de97d04"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("4d6e555a9f45993f22185d43"))
m.cachedAccountView.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("5109040fba95c8a35551c4371215"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6da2a569636ed934e742b6b063163134"))
m.cachedAccountView.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6379cc3f924c088b068134"), _llI11IIIIlI1lIll1I111IIIl1l11lI("74f99fdc85f3540f8dd0665441f46ed9a4"))
end if
m.accountView = m.cachedAccountView
m.viewHost.appendChild(m.accountView)
m.viewStack.Push(m.accountView)
setHeaderVisible(true)
updateNavSelection(_llI11IIIIlI1lIll1I111IIIl1l11lI("7e77fea1cb665c18"))
m.accountView.setFocus(true)
end sub
sub onAccountAction(_ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11 as Object)
_lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = _ll1l11lI1lIllIIl1llIlIlll1IIl1IlI11.getData()
if _lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("6e06b0da01b976d7") then
showKeyAuthView()
else if _lllI11l1Il1llIlIIlll1ll1Il11lIlIIl1 = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("6053649dc7") then
showHomeView(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("6fef6449ce"))
end if
end sub
sub showPremiumTvView()
if not _ll11llllII111I1II1I1I1IIllII11I11I() or _lll1lllIllIllII11II1IllI1IIIllIll1(_lll1IllI11ll1IllllIllI1l11II1III11()) then
kickoutUser(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("62190af3fdce151b181523111ee6312b20f230302b45333f430a5242135d4a1c666853676f756d3a378a817b8277844c8a9881938d5ea0aa67a9ae9cbaa4b47cc3c9c6c3d1bfcc94e0d5d4a0cfeba9edf4f8e1ff01e9fcca"))
return
end if
clearViews()
m.isToolbarFocused = false
m.viewHost.translation = [140, 0]
if m.cachedPremiumTvView = invalid then
m.cachedPremiumTvView = CreateObject(_llI11IIIIlI1lIll1I111IIIl1l11lI("384a9b35c0edf6b6c5"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("42789225705bc691e5ff0b9d8823"))
m.cachedPremiumTvView.observeField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("35f28ae048f0ea03acf1cb6148f46b40"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("38aebf765fb0bcf59c2e3d4d1d0f33ed5fae7d835ecf"))
m.cachedPremiumTvView.observeField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("42c592f7c4de92b5e185d3"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("2ebab955069fa492e033c24edf942cb77a"))
end if
m.premiumTvView = m.cachedPremiumTvView
m.premiumTvView.isToolbarFocused = false
m.viewHost.appendChild(m.premiumTvView)
m.viewStack.Push(m.premiumTvView)
setHeaderVisible(true)
updateNavSelection(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("7d155700ea5154e3c5d4"))
m.premiumTvView.setFocus(true)
if m.premiumTvView.hasField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("6fc77fd862c955e367e67699")) then
m.premiumTvView.resumeFocus = true
end if
end sub
sub showLiveTvView()
if not _ll11llllII111I1II1I1I1IIllII11I11I() or _lll1lllIllIllII11II1IllI1IIIllIll1(_lll1IllI11ll1IllllIllI1l11II1III11()) then
kickoutUser(_llI11IIIIlI1lIll1I111IIIl1l11lI("6a396ad1a098f93921abfcb824d360e166763c2df27887eb5da159753db3a6b60fb15409adfd9d850b2fa2339a308f2be122697d7b23363abcb33dfb8e8c20dc3c7c64ee23ff6b06ffe7ccadb66d269ce9588f43d4f01c2c"))
return
end if
clearViews()
m.isToolbarFocused = false
m.viewHost.translation = [140, 0]
if m.cachedLiveTvView = invalid then
m.cachedLiveTvView = CreateObject(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("2df8eb17c20517eafd"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("489f6a8962b17f985b9d4e"))
m.cachedLiveTvView.observeField(_llI11IIIIlI1lIll1I111IIIl1l11lI("3d280f3aaafc7e8e01f2012cd501a0b1"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("580b0ff4122014f11f19272a2632162f3b35324c3e42"))
m.cachedLiveTvView.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("4b5326996ca662e560db8e"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("3f7a3955055e327d16611a3227383e1322"))
end if
m.liveTvView = m.cachedLiveTvView
m.liveTvView.isToolbarFocused = false
m.viewHost.appendChild(m.liveTvView)
m.viewStack.Push(m.liveTvView)
setHeaderVisible(true)
updateNavSelection(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("6b316927613f5c"))
m.liveTvView.setFocus(true)
end sub
sub onLiveChannelSelected(_ll11I1I11lI11lIll111l1lII1Il1Il as Object)
_llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I = _ll11I1I11lI11lIll111l1lII1Il1Il.getData()
if _llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I = invalid then return
if not _ll11llllII111I1II1I1I1IIllII11I11I() then
kickoutUser(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("2d7dbf54997f639c8e3257ccb546dbc4765a9054ddee03ecfde2b88ca2d60f50a50aef441afe37a80dd34b0d815a4c21463a7fc49d"))
return
end if
_llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1 = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_llIIl1IIl1lllIlI1IlIIlI1II1III1IlI1) then
kickoutUser(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("624bdff1fb3f1cadfc8fdcf13fbd5c2e7a7e5d307a6d1a2cbc7f2d09ffed9c33fc7cd80ebcae0cafbffc194dfaad4f2fbc7d5d0d7a6c1a2d4ecc1ccebfac1aac8dcc5cf06f205e5ffac3d94f3ceecf"))
return
end if
clearViews()
m.viewHost.translation = [0, 0]
m.livePlayerView = CreateObject(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("7480347cc05548bdb2"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("77f6ded2e8fee5f5e0f7eb0afc03f4"))
m.livePlayerView.observeField(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("395f053243b24d353e146c19"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("74c4776e442772379d04f3771a677688e50b"))
m.livePlayerView.observeField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("5f248437b547e77541660737f5"), _llI11IIIIlI1lIll1I111IIIl1l11lI("6b6e6f090bb81e61b8b783b3dc63a62c55e32d3126"))
m.livePlayerView.allChannels = _llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I.allChannels
m.livePlayerView.currentIndex = _llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I.currentIndex
m.livePlayerView.channelData = _llIl1lI1lIlI11l1I1IIIIIIl1IlI1lIl1I
m.viewHost.appendChild(m.livePlayerView)
m.viewStack.Push(m.livePlayerView)
setHeaderVisible(false)
m.livePlayerView.setFocus(true)
end sub
sub onCloseLivePlayer()
m.isToolbarFocused = false
if m.livePlayerView <> invalid then
m.viewHost.removeChild(m.livePlayerView)
m.livePlayerView = invalid
end if
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_ll1lI11ll11ll1lll11IlI1IlIllIlI = m.viewStack.Peek()
if _ll1lI11ll11ll1lll11IlI1IlIllIlI <> invalid and _ll1lI11ll11ll1lll11IlI1IlIllIlI.isSubtype(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("35b8ca268b7c294026f174decbb0f7")) then
m.viewStack.Pop()
end if
end if
if m.activeTab = _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("289706397318257bf6d6") then
showPremiumTvView()
else
showLiveTvView()
end if
end sub
sub updateNavSelection(_lllI11I1ll1I1I1ll1l1IllI11IIlIl as String)
m.activeTab = _lllI11I1ll1I1I1ll1l1IllI11IIlIl
updateToolbarVisuals()
end sub
sub onShowToastChange()
_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 = m.top.showToast
if _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 <> invalid and _lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1 <> "" then
showToast(_lllIlI11l1l111IIl11I111lIlIll1IIlIlll11I1l1)
end if
end sub
sub showToast(_llIIllll1ll1Il111IIl1lIIl1lIl11l1llIIII as String)
m.toastText.text = _llIIllll1ll1Il111IIl1lIIl1lIl11l1llIIII
m.toastGroup.visible = true
m.toastTimer = CreateObject(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("377260b4df51adb53c"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("63f21f0c3e2a"))
m.toastTimer.duration = 2.5
m.toastTimer.observeField(_llI11IIIIlI1lIll1I111IIIl1l11lI("277ffeeb7b"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("6f7203b120119c34acb8"))
m.toastTimer.control = _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("74c9f1f6c2ea")
end sub
sub hideToast()
m.toastGroup.visible = false
if m.toastTimer <> invalid then m.toastTimer.control = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("658bbe01b4")
end sub
function onKeyEvent(_ll1ll11l1I1lllII11I1lII1IlIl1ll as String, _lllIll1IlII1I1IlI1lIllI1II1l1lI as Boolean) as Boolean
if not _lllIll1IlII1I1IlI1lIllI1II1l1lI then return false
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then
if _ll1ll11l1I1lllII11I1lII1IlIl1ll = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("54c0c4c5c0") then
return true
end if
return true
end if
if _ll11llllII111I1II1I1I1IIllII11I11I() then
checkLicenseOnInteraction()
end if
if m.top.hasFocus() and not m.isToolbarFocused then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
if _ll1ll11l1I1lllII11I1lII1IlIl1ll = _llI11IIIIlI1lIll1I111IIIl1l11lI("7b72e44def17e49e") then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = m.viewStack.Peek()
if _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill <> invalid and _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("6e8f558b569e7eb35ab64f")) then
return false
end if
end if
showSearchView()
return true
end if
if m.isToolbarFocused then
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = invalid
if m.viewStack <> invalid and m.viewStack.Count() > 0 then _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = m.viewStack.Peek()
if _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill <> invalid and (_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("334915511b5021461f70141b")) or _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3f1fe136bc80569dcf94ba")) or _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3577cee2184a9267eb314508004529"))) then
m.isToolbarFocused = false
else
if _ll1ll11l1I1lllII11I1lII1IlIl1ll = (Chr(117) + Chr(112)) then
m.toolbarIndex = m.toolbarIndex - 1
if m.toolbarIndex < 0 then m.toolbarIndex = 0
updateToolbarVisuals()
return true
else if _ll1ll11l1I1lllII11I1lII1IlIl1ll = _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("294d1cebfd") then
m.toolbarIndex = m.toolbarIndex + 1
if m.toolbarIndex >= m.toolbarTabs.Count() then m.toolbarIndex = m.toolbarTabs.Count() - 1
updateToolbarVisuals()
return true
else if _ll1ll11l1I1lllII11I1lII1IlIl1ll = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("43651d24cff8") then
unfocusToolbar()
return true
else if _ll1ll11l1I1lllII11I1lII1IlIl1ll = _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("4eb3882349") then
return true
else if _ll1ll11l1I1lllII11I1lII1IlIl1ll = _llI11IIIIlI1lIll1I111IIIl1l11lI("392252f339") then
return true
else if _ll1ll11l1I1lllII11I1lII1IlIl1ll = (Chr(79) + Chr(75)) or _ll1ll11l1I1lllII11I1lII1IlIl1ll = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("469388848e8fa5") then
_ll11l1Il11IlI1II1l11ll111IIllII = m.toolbarTabs[m.toolbarIndex]
executeToolbarSelection(_ll11l1Il11IlI1II1l11ll111IIllII.id)
return true
end if
return true
end if
end if
if _ll1ll11l1I1lllII11I1lII1IlIl1ll = _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("488d62870c") then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = m.viewStack.Peek()
if _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill <> invalid and _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("7b496054aa2fe4d88b4388ac")) then
popDetailsView()
return true
end if
end if
if m.viewStack.Count() > 1 then
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = m.viewStack.Pop()
m.viewHost.removeChild(_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill)
if _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill <> invalid and _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_llI11IIIIlI1lIll1I111IIIl1l11lI("3133dacead05f5cca67993e0")) then
m.detailsView = invalid
end if
_ll1IlIIII11l1I11Ill1Illl1lII1Il1III = m.viewStack.Peek()
if _ll1IlIIII11l1I11Ill1Illl1lII1Il1III <> invalid then
if _ll1IlIIII11l1I11Ill1Illl1lII1Il1III.isSubtype(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("65d2f6115cce127df8")) or _ll1IlIIII11l1I11Ill1Illl1lII1Il1III.isSubtype(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("772f6b3bb9ac84b806b060")) or _ll1IlIIII11l1I11Ill1Illl1lII1Il1III.isSubtype(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("53fba5093b9669856712ad")) or _ll1IlIIII11l1I11Ill1Illl1lII1Il1III.isSubtype(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("3f561a4a104127552750360c02191f")) or _ll1IlIIII11l1I11Ill1Illl1lII1Il1III.isSubtype(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("65967d82c76dc1674a40856b")) then
m.viewHost.translation = [140, 0]
setHeaderVisible(true)
end if
focusActiveView(_ll1IlIIII11l1I11Ill1Illl1lII1Il1III)
return true
end if
else if m.viewStack.Count() = 1 then
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = m.viewStack[0]
if _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill <> invalid and _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("64342b3ff57acf23768e5377")) then
popDetailsView()
return true
end if
if _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill <> invalid and _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("602a4d11995b70369c307599")) and not _ll11llllII111I1II1I1I1IIllII11I11I() then
return true
end if
focusToolbar(m.activeTab)
return true
end if
else if _ll1ll11l1I1lllII11I1lII1IlIl1ll = _llI11IIIIlI1lIll1I111IIIl1l11lI("728e13d288") then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill = m.viewStack.Peek()
if _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill <> invalid and (_lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("6b194d014300791647204c4b")) or _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6425d1b47faa4d372bd651")) or _lllIll11l1IlIIll11IlI1I11I11Il11Ill1Ill.isSubtype(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("24b10a2b1a556d057d24719d12a137"))) then
return false
end if
end if
if m.leftToolbar <> invalid and m.leftToolbar.visible then
focusToolbar(m.activeTab)
return true
end if
end if
return false
end function
sub startSessionWatchdog()
m.watchdogTickCount = 0
if m.sessionWatchdogTimer <> invalid then
m.sessionWatchdogTimer.control = _llI11IIIIlI1lIll1I111IIIl1l11lI("461a4a6757")
m.sessionWatchdogTimer.control = _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("3a143a083207")
end if
end sub
sub stopSessionWatchdog()
if m.sessionWatchdogTimer <> invalid then
m.sessionWatchdogTimer.control = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("4eded4ec3a")
end if
end sub
sub checkLicenseOnInteraction()
if not _ll11llllII111I1II1I1I1IIllII11I11I() then return
_lll1I1I1111I11lIIIllIIIlI1IlllI111I1I1l = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_lll1I1I1111I11lIIIllIIIlI1IlllI111I1I1l) then
kickoutUser(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("2a093a333d0e454b585553515e26616b603270606b75737f83404d608791988d9a62a09e97a9a374b6b07dbfc4b2c0baca92c9cfdcd9d7d5e2aae6ebdab6e5f1bf03fafef70507ff12da0e0c1521281f262832ee"))
return
end if
_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11 = CreateObject(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("2c413663087f2647004a0f")).AsSeconds()
if (_llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11 - m.lastVerifyTime) >= 60 then
m.lastVerifyTime = _llll11lIll11l1IIl1l1l1Ill1l11l11I1llI11
triggerOnlineVerify()
end if
end sub
sub triggerOnlineVerify()
if not _ll11llllII111I1II1I1I1IIllII11I11I() then return
if m.watchdogTask <> invalid and m.watchdogTask.state = _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("7e4d7e5f65515d51") then return
if m.watchdogTask <> invalid then
m.watchdogTask.unobserveField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("2481349e298e0e"))
m.watchdogTask = invalid
end if
m.watchdogTask = CreateObject(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("447076556460829092"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("74cfb5e89eaab2749b06b2f4"))
m.watchdogTask.action = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("24fc89aa989bcf")
m.watchdogTask.observeField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("504ce046eb7f05"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("31bcbf934db0532651145fe385187b8e1145c7625da06b"))
m.watchdogTask.control = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("63c63c26")
end sub
sub onSessionWatchdogTick()
if not _ll1IlIIIl1IllI1lIIIIlIl1I1lllI111I() then
stopSessionWatchdog()
kickoutUser(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("54a01ab5c09b768982c7aa05888336093c9ff035186316496c1f5853e18b4e79f46fa01d90d9c631442fd21570530e299c1f60"))
return
end if
if not _ll11llllII111I1II1I1I1IIllII11I11I() then
stopSessionWatchdog()
return
end if
_llIllI1IlI1lllllll1I11I1llI1Il1Illl = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_llIllI1IlI1lllllll1I11I1llI1Il1Illl) then
kickoutUser(_llI11IIIIlI1lIll1I111IIIl1l11lI("394e74281a4250424a3255c3ce0c5a8af150c585ed0320f3f4fbe3c3ea0a149a86c3386b1fb393da7062560b759208f5f93654363e2659b7a2f0b73ec655fea4d0163031f56ccc491563a6d580537d8791f121a0"))
return
end if
if m.watchdogTickCount = invalid then m.watchdogTickCount = 0
m.watchdogTickCount = m.watchdogTickCount + 1
_llII1I1II1IlIIII1IIlllllIIIlIIlII1IlllI = (m.playerView <> invalid or m.livePlayerView <> invalid)
if _llII1I1II1IlIIII1IIlllllIIIlIIlII1IlllI then
if (m.watchdogTickCount mod 6) = 0 then
triggerOnlineVerify()
end if
else
if (m.watchdogTickCount mod 3) = 0 then
triggerOnlineVerify()
end if
end if
end sub
sub onVideoLoadTriggered()
verifyLicenseForVideoLoad()
end sub
sub verifyLicenseForVideoLoad()
if not _ll1IlIIIl1IllI1lIIIIlIl1I1lllI111I() then
kickoutUser(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("30c8392ba8b8478f0d1d221020b1af551d9510fa3949f7ff344c49db3582bec44c2600a84a10674ca75e22f0a2136d747d3673"))
return
end if
if not _ll11llllII111I1II1I1I1IIllII11I11I() then
kickoutUser(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("5bad60ad7fb656fa08f8159009db47ed02b507abe1bdedf19afd97e297868edaceedd5bd9aaf2af536fa26c7219d"))
return
end if
_lll1lIIlllll1II1IIlIl1III1IIl1Il1IIll1I = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_lll1lIIlllll1II1IIlIl1III1IIl1Il1IIll1I) then
kickoutUser(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("455b6c757d2e757d7a7783938046918da25292b0aba7b3a1a3706da0b7b3bacfbc82c2ced7cbe394d8e09de1e6f2f2faecb2f901fefb071704ca180d2cd62523df252c2e3737374134fa504c55434a515858541e"))
return
end if
if m.videoVerifyTask <> invalid then
m.videoVerifyTask.unobserveField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("3ce12cfe31ee16"))
m.videoVerifyTask = invalid
end if
m.videoVerifyTask = CreateObject(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("6fc775f27af264f07e"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("299b82c64a9085cb8d6549cf"))
m.videoVerifyTask.action = _llI11IIIIlI1lIll1I111IIIl1l11lI("33bef94d72dcc7")
m.videoVerifyTask.observeField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("67b7d9a4067096"), _llI11IIIIlI1lIll1I111IIIl1l11lI("4a9f319b3898ab94ad49cfa12c8a887f8e2ce283c93066cd"))
m.videoVerifyTask.control = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("27abcea1")
end sub
sub onVideoLoadVerifyResult()
if m.videoVerifyTask = invalid then return
_lll11IlIlI1l111l1IIllIl11ll1ll1 = m.videoVerifyTask.result
if _lll11IlIlI1l111l1IIllIl11ll1ll1 = invalid then return
if _lll11IlIlI1l111l1IIllIl11ll1ll1.success = true then
m.consecutiveVerifyFailures = 0
m.lastVerifyTime = CreateObject(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("3866492b0fc245d77ba671")).AsSeconds()
if _lll11IlIlI1l111l1IIllIl11ll1ll1.expiry <> invalid and _lll11IlIlI1l111l1IIllIl11ll1ll1.expiry <> "" then
U_PrefSet(_llI11IIIIlI1lIll1I111IIIl1l11lI("6a80c88dfdeab2394469"), _lll11IlIlI1l111l1IIllIl11ll1ll1.expiry)
if _lll1lllIllIllII11II1IllI1IIIllIll1(_lll11IlIlI1l111l1IIllIl11ll1ll1.expiry) then
kickoutUser(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("22fe13ed0fb67cba6db561d17c8d3bbd22f760e393f397edadaea4c793b798bc85c0c7c2c6da2e8174873dff34f126973ecb75c744c850dcbd90f187e6e7bde5f9dff2d7f3c3cbd1c09d9463996d92589d469306"))
return
end if
end if
else
_ll11l111ll11IlIIl1llIlIllIlll1l1lll1l1II1Il = ""
if _lll11IlIlI1l111l1IIllIl11ll1ll1.message <> invalid then _ll11l111ll11IlIIl1llIlIllIlll1l1lll1l1II1Il = _lll11IlIlI1l111l1IIllIl11ll1ll1.message
_llll11Il1lllI1II1lI11IIIII1I1ll1lllllIlIIIl = false
if _lll11IlIlI1l111l1IIllIl11ll1ll1.isDefinitive <> invalid and _lll11IlIlI1l111l1IIllIl11ll1ll1.isDefinitive = true then
_llll11Il1lllI1II1lI11IIIII1I1ll1lllllIlIIIl = true
else if _ll11II111ll1l1I1Ill1lIIl1lIII1llll(_ll11l111ll11IlIIl1llIlIllIlll1l1lll1l1II1Il) then
_llll11Il1lllI1II1lI11IIIII1I1ll1lllllIlIIIl = true
end if
_ll1lII1l1IIl1II1II1llII1lIll1I1 = false
if _lll11IlIlI1l111l1IIllIl11ll1ll1.isNetworkError <> invalid and _lll11IlIlI1l111l1IIllIl11ll1ll1.isNetworkError = true then
_ll1lII1l1IIl1II1II1llII1lIll1I1 = true
else if _lllI1I1I1lll111IIll1Il111Il11lll11(_ll11l111ll11IlIIl1llIlIllIlll1l1lll1l1II1Il) and not _llll11Il1lllI1II1lI11IIIII1I1ll1lllllIlIIIl then
_ll1lII1l1IIl1II1II1llII1lIll1I1 = true
end if
if not _ll1lII1l1IIl1II1II1llII1lIll1I1 and _llll11Il1lllI1II1lI11IIIII1I1ll1lllllIlIIIl then
_llIlllIlllI1lII1l1l1I11IlI1IIl111IIllII = _llIlIlll1I11IllIIllI1lIllII11l1llI(_ll11l111ll11IlIIl1llIlIllIlll1l1lll1l1II1Il)
if _llIlllIlllI1lII1l1l1I11IlI1IIl111IIllII = "" then _llIlllIlllI1lII1l1l1I11IlI1IIl111IIllII = _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("31f46d1dafbc41dedd3c2f5e2eb88ddbcfed3ddd2d3e0eddcd6f3cddf04cc01cf2386d5e")
kickoutUser(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("2bbfd9e4bf7a85fa94f689dc072225a25d") + _llIlllIlllI1lII1l1l1I11IlI1IIl111IIllII + _llI11IIIIlI1lIll1I111IIIl1l11lI("2a679cb80f9c67ed18bcca8f724644858084011c86c41b198d21894971fb8cc874ebc8f0d950"))
return
else
_llIlIlIl1llI11111l1IIIlIlIIl1l1l1l1 = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_llIlIlIl1llI11111l1IIIlIlIIl1l1l1l1) then
kickoutUser(_llI11IIIIlI1lIll1I111IIIl1l11lI("6444d7ac9ce182421ad046845db8199ad61345288101b79026c8817e1898304c0560aa58555704999c41061950da1bc86ae59656eea4299850bc86ddc817061793e793320f78becca50169efe7f76f04b3f16283"))
return
end if
end if
end if
end sub
sub onWatchdogVerifyResult()
if m.watchdogTask = invalid then return
_llllIIIll1lllI11l1IllI1l111llIll11lIlIl = m.watchdogTask.result
if _llllIIIll1lllI11l1IllI1l111llIll11lIlIl = invalid then return
if _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.success = true then
m.consecutiveVerifyFailures = 0
if _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.expiry <> invalid and _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.expiry <> "" then
U_PrefSet(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("30b7c4d1ceb6c1cbc5c1"), _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.expiry)
if _lll1lllIllIllII11II1IllI1IIIllIll1(_llllIIIll1lllI11l1IllI1l111llIll11lIlIl.expiry) then
kickoutUser(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("3a3e0b2d1776647a75757911644d237d3a3778238b338f2db56ebc078b77807c9d00df02de1a36416c47253f2c313e57260b6d075c08481ca550e947fe27a525e11fea17eb03d311d85d8ca381ad8a9885868bc6"))
return
end if
end if
else
_llll1l1l1lIIl1lIIlIlIlIll1IlI111Il1IIll = ""
if _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.message <> invalid then _llll1l1l1lIIl1lIIlIlIlIll1IlI111Il1IIll = _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.message
_ll1ll1IIllI11II11I11lll1l1l11I1 = false
if _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.isDefinitive <> invalid and _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.isDefinitive = true then
_ll1ll1IIllI11II11I11lll1l1l11I1 = true
else if _ll11II111ll1l1I1Ill1lIIl1lIII1llll(_llll1l1l1lIIl1lIIlIlIlIll1IlI111Il1IIll) then
_ll1ll1IIllI11II11I11lll1l1l11I1 = true
end if
_llIIlIll11Il1lI1lIlI1I11llIlllIIIl1 = false
if _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.isNetworkError <> invalid and _llllIIIll1lllI11l1IllI1l111llIll11lIlIl.isNetworkError = true then
_llIIlIll11Il1lI1lIlI1I11llIlllIIIl1 = true
else if _lllI1I1I1lll111IIll1Il111Il11lll11(_llll1l1l1lIIl1lIIlIlIlIll1IlI111Il1IIll) and not _ll1ll1IIllI11II11I11lll1l1l11I1 then
_llIIlIll11Il1lI1lIlI1I11llIlllIIIl1 = true
end if
if not _llIIlIll11Il1lI1lIlI1I11llIlllIIIl1 and _ll1ll1IIllI11II11I11lll1l1l11I1 then
_ll1lIIIIllllIl1III1II1Il1IIIIIll1lI = _llIlIlll1I11IllIIllI1lIllII11l1llI(_llll1l1l1lIIl1lIIlIlIlIll1IlI111Il1IIll)
if _ll1lIIIIllllIl1III1II1Il1IIIIIll1lI = "" then _ll1lIIIIllllIl1III1II1Il1IIIIIll1lI = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("661e3c494e4c625797515b5f647a608272aeb57a7a7c7f878bc6cd8da5d6a99bb2b3a8ac")
kickoutUser(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("7bfc5ef543ea7cb0158e01ee0ef9009e11") + _ll1lIIIIllllIl1III1II1Il1IIIIIll1lI + _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("52db7604eeb19c37d2c3e84b86098c050a8d262b46e98c0f8273e0c39eb91c3fdacb20fba667"))
return
else
_llII1l1lll1lll11lI1lI111I1ll111lIl11IllIl1l = _lll1IllI11ll1IllllIllI1l11II1III11()
if _lll1lllIllIllII11II1IllI1IIIllIll1(_llII1l1lll1lll11lI1lI111I1ll111lIl11IllIl1l) then
kickoutUser(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("770c461f5a44294838473423297f6e4f77053511c601c21ff85cf135c645cd4ed032923093287b732175680d610373656b392035113a052ee862a475b315e817ac2da725a6319e23956fc191cc9fc7aac8b4c6f4"))
return
end if
end if
end if
end sub
sub kickoutUser(_llIlI11lIl11llI1I1IlllIlI1I11l11IIIll1llI1I as String)
if m.videoVerifyTask <> invalid then
m.videoVerifyTask.unobserveField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("45abde4a624cd1"))
m.videoVerifyTask = invalid
end if
if m.playerView <> invalid then
_ll1I1IIII1lIll1l11111ll11lI11l11III = m.playerView.findNode(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("25e124879a550773a6f1dc2f"))
if _ll1I1IIII1lIll1l11111ll11lI11l11III <> invalid then _ll1I1IIII1lIll1l11111ll11lI11l11III.control = _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("7eb161734f")
m.viewHost.removeChild(m.playerView)
m.playerView = invalid
end if
if m.livePlayerView <> invalid then
_ll11l1l1lI1111111ll1ll11l11I1Ill1IllIIlllI1 = m.livePlayerView.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("21b3a544483dfa3cede5"))
if _ll11l1l1lI1111111ll1ll11l11I1Ill1IllIIlllI1 <> invalid then _ll11l1l1lI1111111ll1ll11l11I1Ill1IllIIlllI1.control = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("4e3339553b")
m.viewHost.removeChild(m.livePlayerView)
m.livePlayerView = invalid
end if
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
for _ll111II1llII1IlII1Il1IllI1I1IIl = m.viewStack.Count() - 1 to 0 step -1
_llI1llIIIlI1lIl1l1II11I1IlIl1ll1IIIlllI = m.viewStack[_ll111II1llII1IlII1Il1IllI1I1IIl]
if _llI1llIIIlI1lIl1l1II11I1IlIl1ll1IIIlllI <> invalid and (_llI1llIIIlI1lIl1l1II11I1IlIl1ll1IIIlllI.isSubtype(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("32b2c9c7e2c9e3c2ded5ea")) or _llI1llIIIlI1lIl1l1II11I1IlIl1ll1IIIlllI.isSubtype(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("6dbeb7a3c7fa350628750a1984b66b"))) then
_ll1lll1lIIllll1l1I1IlIIl1Il1ll1Il11 = _llI1llIIIlI1lIl1l1II11I1IlIl1ll1IIIlllI.findNode(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("52f3c91e13786ab267eb3165"))
if _ll1lll1lIIllll1l1I1IlIIl1Il1ll1Il11 = invalid then _ll1lll1lIIllll1l1I1IlIIl1Il1ll1Il11 = _llI1llIIIlI1lIl1l1II11I1IlIl1ll1IIIlllI.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("38effc815c49bfafdfad"))
if _ll1lll1lIIllll1l1I1IlIIl1Il1ll1Il11 <> invalid then _ll1lll1lIIllll1l1I1IlIIl1Il1ll1Il11.control = _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("7bba4f0599")
m.viewHost.removeChild(_llI1llIIIlI1lIl1l1II11I1IlIl1ll1IIIlllI)
end if
end for
end if
stopSessionWatchdog()
_ll11I1III1II11lIlI11IlI11ll1lIIlll()
m.cachedHomeViews = invalid
m.cachedLiveTvView = invalid
m.cachedPremiumTvView = invalid
m.cachedCategoriesView = invalid
m.cachedMyListView = invalid
m.cachedSearchView = invalid
m.cachedAccountView = invalid
m.tabsPreloaded = false
if m.preloadTimer <> invalid then m.preloadTimer.control = _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("797e796c7d")
clearViews()
showKeyAuthView()
if m.keyAuthView <> invalid then
_llllI11I1I1l1l11II11llI1lI1l11I = m.keyAuthView.findNode(_llI11IIIIlI1lIll1I111IIIl1l11lI("287c6ba638378eb4b94ab6eb4a"))
if _llllI11I1I1l1l11II11llI1lI1l11I <> invalid then
_llllI11I1I1l1l11II11llI1lI1l11I.text = _llIlI11lIl11llI1I1IlllIlI1I11l11IIIll1llI1I
end if
_ll111llIII1l1ll1IIlllIlI1IIIllll1Ill11I = m.keyAuthView.findNode(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("7479774f97feb5e1"))
if _ll111llIII1l1ll1IIlllIlI1IIIllll1Ill11I <> invalid then
_ll111llIII1l1ll1IIlllIlI1IIIllll1Ill11I.color = _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("2e1aa3474c2e33787d1217")
_ll111llIII1l1ll1IIlllIlI1IIIllll1Ill11I.width = 120
end if
_llIIII1Il111IlIlI1llI111IllI1l1lIll = m.keyAuthView.findNode(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("34b5c42415b4a84792bb"))
if _llIIII1Il111IlIlI1llI111IllI1l1lIll <> invalid then
_llIIII1Il111IlIlI1llI111IllI1l1lIll.text = _llI11IIIIlI1lIll1I111IIIl1l11lI("3b7d7f93cfd59091")
_llIIII1Il111IlIlI1llI111IllI1l1lIll.color = _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("54b5021d28d1dccfda5f6a")
end if
_ll1I1lI1llI11Il1Il1IIll1lIIlIlIl11l1llI = m.keyAuthView.findNode(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("4305fce54f18394e285f272e"))
if _ll1I1lI1llI11Il1Il1IIll1lIIlIlIl11l1llI <> invalid then _ll1I1lI1llI11Il1Il1IIll1lIIlIlIl11l1llI.text = _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("4e2146494e3f4294295d536d6c696d")
end if
showToast(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("79bedeebf0ec04f9b7ec021602010e10d9d2f61b1e233437e70e322e2c3b3d"))
end sub
sub preloadAllTabs()
if m.cachedHomeViews = invalid then m.cachedHomeViews = {}
if m.cachedHomeViews[_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("36e233f237f71e")] = invalid then
_llll1lIIl11l1IlIlIl1l1l1lIlIlIlI1l1IlI11IlI = CreateObject(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("504c80480ca19409fe"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("3dad1da60e9c0e9907"))
_llll1lIIl11l1IlIlIl1l1l1lIlIlIlI1l1IlI11IlI.category = _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("3fec1187bb8066")
_llll1lIIl11l1IlIlIl1l1l1lIlIlIlI1l1IlI11IlI.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("231772b588c316a9ac1e42d520"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("4bedef11fff3fe23fc0602ff170b0d"))
_llll1lIIl11l1IlIlIl1l1l1lIlIlIlI1l1IlI11IlI.observeField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("30565a70a4999e11491dd238"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6afb0eea1c1762de68fb5e616cb052c5a863"))
_llll1lIIl11l1IlIlIl1l1l1lIlIlIlI1l1IlI11IlI.observeField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("3a607e13980bbd911d607e"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("52a3332f35dd37437ab989e75dd62fb4e0"))
m.cachedHomeViews[_llI11IIIIlI1lIll1I111IIIl1l11lI("564638d6859fd2")] = _llll1lIIl11l1IlIlIl1l1l1lIlIlIlI1l1IlI11IlI
end if
if m.cachedHomeViews[_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("2820393e393b10")] = invalid then
_llI1IIlIII11IllIll1ll1IlIII1IIll1l111IlIllI = CreateObject(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("67d0a6ec32a7ba0f24"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6b393b36811577a23d"))
_llI1IIlIII11IllIll1ll1IlIII1IIll1l111IlIllI.category = _llI11IIIIlI1lIll1I111IIIl1l11lI("6f6b2c0138a0bd")
_llI1IIlIII11IllIll1ll1IlIII1IIll1l111IlIllI.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("3d6e296c3f1acd606397f98cd7"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("641c6232442a731d5e1d50624c6a42"))
_llI1IIlIII11IllIll1ll1IlIII1IIll1l111IlIllI.observeField(_llI11IIIIlI1lIll1I111IIIl1l11lI("36207ed59e69800bc87fbeed"), _llI11IIIIlI1lIll1I111IIIl1l11lI("3f8899740cb55d466a6607749a73e9a8c6cd"))
_llI1IIlIII11IllIll1ll1IlIII1IIll1l111IlIllI.observeField(_llI11IIIIlI1lIll1I111IIIl1l11lI("47152e5e417e6b3aae2914"), _llI11IIIIlI1lIll1I111IIIl1l11lI("58009fde843bd3031558a5d751b2a721ec"))
m.cachedHomeViews[_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("62c05e303d6e5b")] = _llI1IIlIII11IllIll1ll1IlIII1IIll1l111IlIllI
end if
if m.cachedHomeViews[_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("6a9b3016")] = invalid then
_lll1lI1111lIlI1lIIIlI1l1IllI11l = CreateObject(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("35142c3b4a54383034"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("75732a4fd4a69ee3c7"))
_lll1lI1111lIlI1lIIIlI1l1IllI11l.category = _llI11IIIIlI1lIll1I111IIIl1l11lI("4ea28376")
_lll1lI1111lIlI1lIIIlI1l1IllI11l.observeField(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("5bb8080a7a55ef763f3760d122"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("43c6e6fccb67c6397546a5f408e4c4"))
_lll1lI1111lIlI1lIIIlI1l1IllI11l.observeField(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("65c59e8270e2532b347c74c8"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6f0c0feb2d2873ef79fc6f626dc153d6a964"))
_lll1lI1111lIlI1lIIIlI1l1IllI11l.observeField(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("6afbc8cbdd494f3481f282"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("76195a47977ed7e1d3c0d04fbf058ce499"))
m.cachedHomeViews[_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("6141b34e")] = _lll1lI1111lIlI1lIIIlI1l1IllI11l
end if
if m.cachedLiveTvView = invalid then
_lllIlIIIl1I1Il1IllI11ll111IlI1ll111 = CreateObject(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("6d277b43077c8f2439"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("6c66190de3f91c2337fc20"))
_lllIlIIIl1I1Il1IllI11ll111IlI1ll111.observeField(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("729e172df120d3833bc42d6798ab49f8"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("3ffabb8caa3c476b07f0e2b163b780753dab4bba390e"))
_lllIlIIIl1I1Il1IllI11ll111IlI1ll111.observeField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("4eb056ac468f4f95428e52"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("239d9f80a6abb68fa7bfb7a4b1c7bcd1bd"))
m.cachedLiveTvView = _lllIlIIIl1I1Il1IllI11ll111IlI1ll111
end if
if m.cachedPremiumTvView = invalid then
_lll1IlIIIIll1IlIIIl1I1I1Il1lI1I = CreateObject(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("27073d3232322c3036"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("3cd2b3c3ced5bcd7e3c4e7e7decf"))
_lll1IlIIIIll1IlIIIl1I1I1Il1lI1I.observeField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("211e2d1e39170d17292827582a56346e"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("607c66575841746e446e4c174c077c087e187f06950e"))
_lll1IlIIIIll1IlIIIl1I1I1Il1lI1I.observeField(_lll1II1l1lI11l1I1lIll1I1111l1lIl11l("5c8375838d6a7f9380958b"), _llI11IIIIlI1lIll1I111IIIl1l11lI("58009fde843bd3031558a5d751b2a721ec"))
m.cachedPremiumTvView = _lll1IlIIIIll1IlIIIl1I1I1Il1lI1I
end if
if m.cachedCategoriesView = invalid then
_ll1I1I1I1llIllllIIIlI1IllllI111l11I = CreateObject(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("4cfd0a645da6cd377c"), _llI11IIIIlI1lIll1I111IIIl1l11lI("6cb5291c1e45ae80bc48453d07a3e8"))
_ll1I1I1I1llIllllIIIlI1IllllI111l11I.observeField(_llllll11l1I11l1ll1lI11Il1llI1l1ll1I("64554292a372c53e26b1d81969285c470c"), _llllll11l1I11l1ll1lI11Il1llI1l1ll1I("632011c5d05d970cf538e84dda552d165dd3c2"))
_ll1I1I1I1llIllllIIIlI1IllllI111l11I.observeField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("2daa8054a95074a84e7288"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("5f7a5955655e527d76617a3247385e1342"))
m.cachedCategoriesView = _ll1I1I1I1llIllllIIIlI1IllllI111l11I
end if
if m.cachedMyListView = invalid then
_ll1ll1lll1IIllI1I11ll1l1lIl11I1 = CreateObject(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("65577f6270626e6074"), _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("3bf008cc36df0ef42af13f"))
_ll1ll1lll1IIllI1I11ll1l1lIl11I1.observeField(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("74a065a077af5fb745937ffb7c"), _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("6a3f2f55eafe0cd8cf7c6e1d6a7d8d"))
m.cachedMyListView = _ll1ll1lll1IIllI1I11ll1l1lIl11I1
end if
if m.cachedSearchView = invalid then
_llI1Il1l1llIll1ll111lIlI1lII1l1 = CreateObject(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("4bf759ceb3a99a61f9"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("6927a1cc3fd2254143ee69"))
_llI1Il1l1llIll1ll111lIlI1lII1l1.observeField(_ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI("4c6790c9e3c894e8401314c962"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("2a394c201295601cb689ccc76aed00"))
m.cachedSearchView = _llI1Il1l1llIll1ll111lIlI1lII1l1
end if
if m.cachedAccountView = invalid then
_ll1I1I1ll1l11IIl11lII1lllI11IIIIIIIIIIIll1I = CreateObject(_ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I("6c417674797467767d"), _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("34514d5883dea1fcf6ea9510"))
_ll1I1I1ll1l11IIl11lII1lllI11IIIIIIIIIIIll1I.observeField(_ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("2e0df2f7bc62d67c32158bbfe4f9"), _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill("6e697ed5b8bd82289c42f8db5185aabf"))
_ll1I1I1ll1l11IIl11lII1lllI11IIIIIIIIIIIll1I.observeField(_ll1I1l1lIIl1IIIllIIlIIIIlIIIIll("3d4e813467439d40db76c9"), _lll1II1l1lI11l1I1lIll1I1111l1lIl11l("2fa5a790aeb3ae97a7b7bf9cb1c7b4c9bd"))
m.cachedAccountView = _ll1I1I1ll1l11IIl11lII1lllI11IIIIIIIIIIIll1I
end if
end sub
function _lll1II1l1lI11l1I1lIll1I1111l1lIl11l(_ll1lI111111l1Il1lll1lII1IllIllIlllIllI1II1I as String) as String
if _ll1lI111111l1Il1lll1lII1IllIllIlllIllI1II1I = "" then return ""
_lllII1llIll11l1IIII11IIlll1II1I1l1l111lIIll = CreateObject("roByteArray")
_lllII1llIll11l1IIII11IIlll1II1I1l1l111lIIll.FromHexString(_ll1lI111111l1Il1lll1lII1IllIllIlllIllI1II1I)
_ll1llllI1I1lIl1Ill1I1l111lIllII11lI111IlII1 = _lllII1llIll11l1IIII11IIlll1II1I1l1l111lIIll.Count()
if _ll1llllI1I1lIl1Ill1I1l111lIllII11lI111IlII1 < 2 then return ""
_lllI11III1lllllIlI1IIIl1IlI1lll1IlI = _lllII1llIll11l1IIII11IIlll1II1I1l1l111lIIll[0]
_llI11IlIl1Il1IlIIl1lI11I1l1lllII1l1 = (_lllI11III1lllllIlI1IIIl1IlI1lll1IlI * 37 + 11) and 255
_llllII1I11l1lII11IIl1I1II1lIlII = (_lllI11III1lllllIlI1IIIl1IlI1lll1IlI * 59 + 23) and 255
for _llIIlII1l1IlII1I1llIl1IllIlll1l1II1 = 1 to _ll1llllI1I1lIl1Ill1I1l111lIllII11lI111IlII1 - 1
_ll1IlIIIl1Il11IIll1llIlI1lIIllI = (_lllII1llIll11l1IIII11IIlll1II1I1l1l111lIIll[_llIIlII1l1IlII1I1llIl1IllIlll1l1II1] - ((_llIIlII1l1IlII1I1llIl1IllIlll1l1II1 - 1) * 3 + _llllII1I11l1lII11IIl1I1II1lIlII)) and 255
_lllII1llIll11l1IIII11IIlll1II1I1l1l111lIIll[_llIIlII1l1IlII1I1llIl1IllIlll1l1II1] = (_ll1IlIIIl1Il11IIll1llIlI1lIIllI + _llI11IlIl1Il1IlIIl1lI11I1l1lllII1l1) - 2 * (_ll1IlIIIl1Il11IIll1llIlI1lIIllI and _llI11IlIl1Il1IlIIl1lI11I1l1lllII1l1)
end for
return Mid(_lllII1llIll11l1IIII11IIlll1II1I1l1l111lIIll.ToAsciiString(), 2)
end function
function _ll1IlIll1lI1I1IIII1lllIl1IllI1llllIlI1I(_llllIIl1I1l1l111IlIl1IlIlIl1I1lIIll as String) as String
if _llllIIl1I1l1l111IlIl1IlIlIl1I1lIIll = "" then return ""
_llI1IIlIl1lllllIlI1lI11IlIll111IlIIII11 = CreateObject("roByteArray")
_llI1IIlIl1lllllIlI1lI11IlIll111IlIIII11.FromHexString(_llllIIl1I1l1l111IlIl1IlIlIl1I1lIIll)
_lll111lIllI1llI111llII1lIIIlIII = _llI1IIlIl1lllllIlI1lI11IlIll111IlIIII11.Count()
if _lll111lIllI1llI111llII1lIIIlIII < 2 then return ""
_ll11lllIllIIl1IlIl11lI11l1lII1lIl1l = _llI1IIlIl1lllllIlI1lI11IlIll111IlIIII11[0]
_ll1ll1lIIIllIIllIlIlllI1IllII11IIIllIII = (_ll11lllIllIIl1IlIl11lI11l1lII1lIl1l * 41 + 19) and 255
_ll11II1lI1l1lll11lI1I1IIll1lIl11I1lI1IlII11 = _ll11lllIllIIl1IlIl11lI11l1lII1lIl1l
for _ll1IIl1lI1Il1111l1llI1l1Il1IIl1 = 1 to _lll111lIllI1llI111llII1lIIIlIII - 1
_lllI1I1l1II1Il1ll111lllI11I1I1Ill11 = _llI1IIlIl1lllllIlI1lI11IlIll111IlIIII11[_ll1IIl1lI1Il1111l1llI1l1Il1IIl1]
_lllII1111l1Il11IIIlllIlIlI11lIl1I1l = ((_ll1IIl1lI1Il1111l1llI1l1Il1IIl1 - 1) * 7) and 255
_llI11llI1III1III1IIllll1III1ll11IlI11l1 = (_lllI1I1l1II1Il1ll111lllI11I1I1Ill11 + _ll11II1lI1l1lll11lI1I1IIll1lIl11I1lI1IlII11) - 2 * (_lllI1I1l1II1Il1ll111lllI11I1I1Ill11 and _ll11II1lI1l1lll11lI1I1IIll1lIl11I1lI1IlII11)
_llI11llI1III1III1IIllll1III1ll11IlI11l1 = (_llI11llI1III1III1IIllll1III1ll11IlI11l1 + _ll1ll1lIIIllIIllIlIlllI1IllII11IIIllIII) - 2 * (_llI11llI1III1III1IIllll1III1ll11IlI11l1 and _ll1ll1lIIIllIIllIlIlllI1IllII11IIIllIII)
_llI11llI1III1III1IIllll1III1ll11IlI11l1 = (_llI11llI1III1III1IIllll1III1ll11IlI11l1 + _lllII1111l1Il11IIIlllIlIlI11lIl1I1l) - 2 * (_llI11llI1III1III1IIllll1III1ll11IlI11l1 and _lllII1111l1Il11IIIlllIlIlI11lIl1I1l)
_llI1IIlIl1lllllIlI1lI11IlIll111IlIIII11[_ll1IIl1lI1Il1111l1llI1l1Il1IIl1] = _llI11llI1III1III1IIllll1III1ll11IlI11l1 and 255
_ll11II1lI1l1lll11lI1I1IIll1lIl11I1lI1IlII11 = _lllI1I1l1II1Il1ll111lllI11I1I1Ill11
end for
return Mid(_llI1IIlIl1lllllIlI1lI11IlIll111IlIIII11.ToAsciiString(), 2)
end function
function _ll11ll11lIlIl11llIll1Illl1lll1I11lIIl1I1Ill(_llllIIlIlIII1Il111lIII111l11IlI as String) as String
if _llllIIlIlIII1Il111lIII111l11IlI = "" then return ""
_ll1lII11ll11IlIll11I1l11I11IIIl = CreateObject("roByteArray")
_ll1lII11ll11IlIll11I1l11I11IIIl.FromHexString(_llllIIlIlIII1Il111lIII111l11IlI)
_ll1IlIIl1Il11IlIll1I1lI1I1II1IIIIlI11lllIlI = _ll1lII11ll11IlIll11I1l11I11IIIl.Count()
if _ll1IlIIl1Il11IlIll1I1lI1I1II1IIIIlI11lllIlI < 2 then return ""
_ll1IlIIlIIIIl11I11l1lllII111Ill = _ll1lII11ll11IlIll11I1l11I11IIIl[0]
_ll1II1ll1l1lIl11Il1IIIIlI1Il1IlIllI = (_ll1IlIIlIIIIl11I11l1lllII111Ill * 53 + 29) and 255
_llIII111I1llIIlllllI1Il1IIIlIll1llIl1I1 = (_ll1IlIIlIIIIl11I11l1lllII111Ill * 71 + 31) and 255
for _llI11lllI1lIllIl1IlI1I1l1Il1IlllIIl11ll = 1 to _ll1IlIIl1Il11IlIll1I1lI1I1II1IIIIlI11lllIlI - 1
_ll1lIl11I1I111IIIIllllIlI1ll1l1lI1llI111I11 = (_ll1lII11ll11IlIll11I1l11I11IIIl[_llI11lllI1lIllIl1IlI1I1l1Il1IlllIIl11ll] - ((_llI11lllI1lIllIl1IlI1I1l1Il1IlllIIl11ll - 1) * 5 + _llIII111I1llIIlllllI1Il1IIIlIll1llIl1I1)) and 255
_ll1lIl11I1I111IIIIllllIlI1ll1l1lI1llI111I11 = (((_ll1lIl11I1I111IIIIllllIlI1ll1l1lI1llI111I11 \ 16) or ((_ll1lIl11I1I111IIIIllllIlI1ll1l1lI1llI111I11 * 16) and 255))) and 255
_ll1lII11ll11IlIll11I1l11I11IIIl[_llI11lllI1lIllIl1IlI1I1l1Il1IlllIIl11ll] = (_ll1lIl11I1I111IIIIllllIlI1ll1l1lI1llI111I11 + _ll1II1ll1l1lIl11Il1IIIIlI1Il1IlIllI) - 2 * (_ll1lIl11I1I111IIIIllllIlI1ll1l1lI1llI111I11 and _ll1II1ll1l1lIl11Il1IIIIlI1Il1IlIllI)
end for
return Mid(_ll1lII11ll11IlIll11I1l11I11IIIl.ToAsciiString(), 2)
end function
function _ll1I1l1lIIl1IIIllIIlIIIIlIIIIll(_lllIlIIllII1l11I11ll11IlIlIII1Il1Il1lII as String) as String
if _lllIlIIllII1l11I11ll11IlIlIII1Il1Il1lII = "" then return ""
_lll1Il1I1ll1I1111II1lI1l11l1Il1l1lI = CreateObject("roByteArray")
_lll1Il1I1ll1I1111II1lI1l11l1Il1l1lI.FromHexString(_lllIlIIllII1l11I11ll11IlIlIII1Il1Il1lII)
_lllIl1lll11llll1Il1lII1II1I1Il1llll = _lll1Il1I1ll1I1111II1lI1l11l1Il1l1lI.Count()
if _lllIl1lll11llll1Il1lII1II1I1Il1llll < 2 then return ""
_llIll1ll1l11l1IlI11IllllIIII11lI1llII1l = _lll1Il1I1ll1I1111II1lI1l11l1Il1l1lI[0]
_llII1I1lI111l111I1Ill11I1Il11Il1Ill = (_llIll1ll1l11l1IlI11IllllIIII11lI1llII1l * 67 + 43) and 255
_ll11ll1IIIlll1I1l1IlllI11IIlIIIl11I = (_llIll1ll1l11l1IlI11IllllIIII11lI1llII1l * 79 + 17) and 255
for _lll1l1lll1IIllIII11lIlI1ll1l1IIl11I = 1 to _lllIl1lll11llll1Il1lII1II1I1Il1llll - 1
_llIl1111Ill1lI111llIIlIIlllI1l1I1II = (_lll1Il1I1ll1I1111II1lI1l11l1Il1l1lI[_lll1l1lll1IIllIII11lIlI1ll1l1IIl11I] - ((_lll1l1lll1IIllIII11lIlI1ll1l1IIl11I - 1) * 11 + _ll11ll1IIIlll1I1l1IlllI11IIlIIIl11I)) and 255
_llIl1111Ill1lI111llIIlIIlllI1l1I1II = ((((_llIl1111Ill1lI111llIIlIIlllI1l1I1II \ 8) or ((_llIl1111Ill1lI111llIIlIIlllI1l1I1II * 32) and 255)))) and 255
_lll1Il1I1ll1I1111II1lI1l11l1Il1l1lI[_lll1l1lll1IIllIII11lIlI1ll1l1IIl11I] = (_llIl1111Ill1lI111llIIlIIlllI1l1I1II + _llII1I1lI111l111I1Ill11I1Il11Il1Ill) - 2 * (_llIl1111Ill1lI111llIIlIIlllI1l1I1II and _llII1I1lI111l111I1Ill11I1Il11Il1Ill)
end for
return Mid(_lll1Il1I1ll1I1111II1lI1l11l1Il1l1lI.ToAsciiString(), 2)
end function
function _ll1l1l1III1I1lI1111Il111lIll1111lllI1IIl1lI(_lllI1l1lllIl1111IllI1II11I111lI11l1l1l1I11I as String) as String
if _lllI1l1lllIl1111IllI1II11I111lI11l1l1l1I11I = "" then return ""
_ll11IIIllll1l1lI11Il1ll1IlIlIl1II1I = CreateObject("roByteArray")
_ll11IIIllll1l1lI11Il1ll1IlIlIl1II1I.FromHexString(_lllI1l1lllIl1111IllI1II11I111lI11l1l1l1I11I)
_lllI11IIIl11llIIIlI11ll1l1l1l1IlIIl11ll1IlI = _ll11IIIllll1l1lI11Il1ll1IlIlIl1II1I.Count()
if _lllI11IIIl11llIIIlI11ll1l1l1l1IlIIl11ll1IlI < 2 then return ""
_ll1lIIIlI11I1IIl11l1lIIIIIl1lIIlII1 = _ll11IIIllll1l1lI11Il1ll1IlIlIl1II1I[0]
_lllIllIIllll1lI11lll11ll1llIII11I1I = (_ll1lIIIlI11I1IIl11l1lIIIIIl1lIIlII1 * 73 + 19) and 255
_ll1lIlll1llIl1I11I11Il1lII111I11IlI = (_ll1lIIIlI11I1IIl11l1lIIIIIl1lIIlII1 * 83 + 37) and 255
for _llIl1IIllI1lIlllI1Il111I1IlIlllIllI = 1 to _lllI11IIIl11llIIIlI11ll1l1l1l1IlIIl11ll1IlI - 1
_ll1llII1I111l1lII1lIl1lIllIl11I1lIIlIll = _llIl1IIllI1lIlllI1Il111I1IlIlllIllI - 1
_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 = _ll11IIIllll1l1lI11Il1ll1IlIlIl1II1I[_llIl1IIllI1lIlllI1Il111I1IlIlllIllI]
_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 = ((((_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 \ 4) or ((_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 * 64) and 255)))) and 255
_llII111111IIllll1IIlIIIIll1IIII1IllIIl1lIll = (_ll1llII1I111l1lII1lIl1lIllIl11I1lIIlIll * 13 + _ll1lIIIlI11I1IIl11l1lIIIIIl1lIIlII1) and 255
_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 = (_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 + _llII111111IIllll1IIlIIIIll1IIII1IllIIl1lIll) - 2 * (_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 and _llII111111IIllll1IIlIIIIll1IIII1IllIIl1lIll)
_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 = (_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 - (_ll1llII1I111l1lII1lIl1lIllIl11I1lIIlIll * 7 + _ll1lIlll1llIl1I11I11Il1lII111I11IlI)) and 255
_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 = ((((_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 \ 16) or ((_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 * 16) and 255)))) and 255
_ll11IIIllll1l1lI11Il1ll1IlIlIl1II1I[_llIl1IIllI1lIlllI1Il111I1IlIlllIllI] = (_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 + _lllIllIIllll1lI11lll11ll1llIII11I1I) - 2 * (_llI11IllllIIIlll1l1l11ll1IIl1IIIII1Il11 and _lllIllIIllll1lI11lll11ll1llIII11I1I)
end for
return Mid(_ll11IIIllll1l1lI11Il1ll1IlIlIl1II1I.ToAsciiString(), 2)
end function
function _llllll11l1I11l1ll1lI11Il1llI1l1ll1I(_llIllIlIIIlIIlIl1llllllIlIlI1IIIII1lIl1Il1I as String) as String
if _llIllIlIIIlIIlIl1llllllIlIlI1IIIII1lIl1Il1I = "" then return ""
_ll1I111lllI1llIl1I1IlIl11llllII1ll1 = CreateObject("roByteArray")
_ll1I111lllI1llIl1I1IlIl11llllII1ll1.FromHexString(_llIllIlIIIlIIlIl1llllllIlIlI1IIIII1lIl1Il1I)
_llI1l1IlIllIll111IIl1l11lllIlII1llllI1I = _ll1I111lllI1llIl1I1IlIl11llllII1ll1.Count()
if _llI1l1IlIllIll111IIl1l11lllIlII1llllI1I < 2 then return ""
_ll1I1l1I1IIIlIIl1II1lI1l11II1llIl1l11lI = _ll1I111lllI1llIl1I1IlIl11llllII1ll1[0]
_ll11l1lllI111l1II1lllI11I1l1IlllII1I1I11111 = (_ll1I1l1I1IIIlIIl1II1lI1l11II1llIl1l11lI * 97 + 53) and 255
_lllIII1I1IIl1I111lllllII111Ill1llllIlll1I1l = (_ll1I1l1I1IIIlIIl1II1lI1l11II1llIl1l11lI * 103 + 61) and 255
for _llIl1l1lIlI1IIII11llI1lI11llllIIIl1l1I1 = 1 to _llI1l1IlIllIll111IIl1l11lllIlII1llllI1I - 1
_ll1IIIlII1IllllI1lIl1IIIIl1IIlIlllIlI11 = _llIl1l1lIlI1IIII11llI1lI11llllIIIl1l1I1 - 1
_lllI1IIl1lI1IlIllI1III11ll1l1lI = _ll1I111lllI1llIl1I1IlIl11llllII1ll1[_llIl1l1lIlI1IIII11llI1lI11llllIIIl1l1I1]
_lllIIIIlII1l1Ill11I1IllIIl1l11I = (_ll1IIIlII1IllllI1lIl1IIIIl1IIlIlllIlI11 * 19 + _ll1I1l1I1IIIlIIl1II1lI1l11II1llIl1l11lI) and 255
_lllI1IIl1lI1IlIllI1III11ll1l1lI = (_lllI1IIl1lI1IlIllI1III11ll1l1lI + _lllIIIIlII1l1Ill11I1IllIIl1l11I) - 2 * (_lllI1IIl1lI1IlIllI1III11ll1l1lI and _lllIIIIlII1l1Ill11I1IllIIl1l11I)
_lllI1IIl1lI1IlIllI1III11ll1l1lI = ((((_lllI1IIl1lI1IlIllI1III11ll1l1lI \ 4) or ((_lllI1IIl1lI1IlIllI1III11ll1l1lI * 64) and 255)))) and 255
_lllI1IIl1lI1IlIllI1III11ll1l1lI = (_lllI1IIl1lI1IlIllI1III11ll1l1lI - (_ll1IIIlII1IllllI1lIl1IIIIl1IIlIlllIlI11 * 17 + _lllIII1I1IIl1I111lllllII111Ill1llllIlll1I1l)) and 255
_lllI1IIl1lI1IlIllI1III11ll1l1lI = ((((_lllI1IIl1lI1IlIllI1III11ll1l1lI \ 8) or ((_lllI1IIl1lI1IlIllI1III11ll1l1lI * 32) and 255)))) and 255
_ll1I111lllI1llIl1I1IlIl11llllII1ll1[_llIl1l1lIlI1IIII11llI1lI11llllIIIl1l1I1] = (_lllI1IIl1lI1IlIllI1III11ll1l1lI + _ll11l1lllI111l1II1lllI11I1l1IlllII1I1I11111) - 2 * (_lllI1IIl1lI1IlIllI1III11ll1l1lI and _ll11l1lllI111l1II1lllI11I1l1IlllII1I1I11111)
end for
return Mid(_ll1I111lllI1llIl1I1IlIl11llllII1ll1.ToAsciiString(), 2)
end function
function _llI11IIIIlI1lIll1I111IIIl1l11lI(_llI11lIIII1Il11I1lllI1l1l1lIIll1Ill as String) as String
if _llI11lIIII1Il11I1lllI1l1l1lIIll1Ill = "" then return ""
_llllIIII1ll1IlI1lIIlIll1I1IlII11IlIIIIlIlIl = CreateObject("roByteArray")
_llllIIII1ll1IlI1lIIlIll1I1IlII11IlIIIIlIlIl.FromHexString(_llI11lIIII1Il11I1lllI1l1l1lIIll1Ill)
_lll11I111l11IIl1lIllI11lll1l11l1I11I11lIlIl = _llllIIII1ll1IlI1lIIlIll1I1IlII11IlIIIIlIlIl.Count()
if _lll11I111l11IIl1lIllI11lll1l11l1I11I11lIlIl < 2 then return ""
_lllIIl11IIIllIIIl1lIlIl1IIl11IllI1I1111 = _llllIIII1ll1IlI1lIIlIll1I1IlII11IlIIIIlIlIl[0]
_llI1lIIII11l1I1lIlIIII11IlIIIllIlll1IlI = (_lllIIl11IIIllIIIl1lIlIl1IIl11IllI1I1111 * 109 + 47) and 255
_lll1lllll1IllIllllI1IIll1lIllIl11ll = (_lllIIl11IIIllIIIl1lIlIl1IIl11IllI1I1111 * 113 + 71) and 255
for _llll111lIIIIl1I1IIIlII1Il1IlllII1lllllI = 1 to _lll11I111l11IIl1lIllI11lll1l11l1I11I11lIlIl - 1
_ll111IlllI1lIl1IlIIlIII1llII111 = _llll111lIIIIl1I1IIIlII1Il1IlllII1lllllI - 1
_lll1I11l11I111l1I111lI1llllI1I11lIl = _llllIIII1ll1IlI1lIIlIll1I1IlII11IlIIIIlIlIl[_llll111lIIIIl1I1IIIlII1Il1IlllII1lllllI]
_lll1I11l11I111l1I111lI1llllI1I11lIl = (_lll1I11l11I111l1I111lI1llllI1I11lIl + _lll1lllll1IllIllllI1IIll1lIllIl11ll) - 2 * (_lll1I11l11I111l1I111lI1llllI1I11lIl and _lll1lllll1IllIllllI1IIll1lIllIl11ll)
_lll1I11l11I111l1I111lI1llllI1I11lIl = (_lll1I11l11I111l1I111lI1llllI1I11lIl + (_ll111IlllI1lIl1IlIIlIII1llII111 * 7 + _lllIIl11IIIllIIIl1lIlIl1IIl11IllI1I1111)) and 255
_lll1I11l11I111l1I111lI1llllI1I11lIl = ((((_lll1I11l11I111l1I111lI1llllI1I11lIl \ 16) or ((_lll1I11l11I111l1I111lI1llllI1I11lIl * 16) and 255)))) and 255
_lll1I11l11I111l1I111lI1llllI1I11lIl = (_lll1I11l11I111l1I111lI1llllI1I11lIl - (_ll111IlllI1lIl1IlIIlIII1llII111 * 3 + _lll1lllll1IllIllllI1IIll1lIllIl11ll)) and 255
_lll1I11l11I111l1I111lI1llllI1I11lIl = (_lll1I11l11I111l1I111lI1llllI1I11lIl * 43) and 255
_llllIIII1ll1IlI1lIIlIll1I1IlII11IlIIIIlIlIl[_llll111lIIIIl1I1IIIlII1Il1IlllII1lllllI] = (_lll1I11l11I111l1I111lI1llllI1I11lIl + _llI1lIIII11l1I1lIlIIII11IlIIIllIlll1IlI) - 2 * (_lll1I11l11I111l1I111lI1llllI1I11lIl and _llI1lIIII11l1I1lIlIIII11IlIIIllIlll1IlI)
end for
return Mid(_llllIIII1ll1IlI1lIIlIll1I1IlII11IlIIIIlIlIl.ToAsciiString(), 2)
end function