sub init()
m.viewHost = m.top.findNode(_l1d_14a035("fdf1f005db030a10", 193, 70))
m.headerBar = m.top.findNode(_l1d_14a035("6c7279797b91a4889a", 239, 229))
m.accentLine = m.top.findNode(_l1d_14a035("f8fd0005111a35151d17", 160, 55))
m.topBar = m.top.findNode(_l1d_14a035("ddc9e7fcdcf2", 237, 68))
m.bgGradient = m.top.findNode(_l1d_14a035("b4bc9fcdbfc5cdccd8e1", 128, 210))
m.navLiveTv = m.top.findNode(_l1d_14a035("abad99d6bea2b8caab", 246, 19))
m.navHome = m.top.findNode(_l1d_14a035("bab8c8e5c7c8c3", 164, 240))
m.navMovies = m.top.findNode(_l1d_14a035("a5afc3d1b2ccb6c5d2", 106, 161))
m.navTv = m.top.findNode(_l1d_14a035("adb3ab8cb1", 152, 183))
m.navCategories = m.top.findNode(_l1d_14a035("cabed8a6c7dfd1d6e1e9e1e0f1", 193, 27))
m.navSearch = m.top.findNode(_l1d_14a035("01111f05161d2f211f", 15, 160))
m.navPortal = m.top.findNode(_l1d_14a035("e0d8ceafebd3dceafa", 19, 99))
m.toastGroup = m.top.findNode(_l1d_14a035("362e2738421242404d4d", 67, 255))
m.toastText = m.top.findNode(_l1d_14a035("f4f0ed0200e3f5150c", 133, 3))
m.exitModal = m.top.findNode(_l1d_14a035("d3d1e5cbc7ece4ecf2", 20, 98))
m.btnExitCancel = m.top.findNode(_l1d_14a035("cedfd8b4f4e6eec2e7edebecf8", 199, 41))
m.btnExitConfirm = m.top.findNode(_l1d_14a035("bcb1cea6bed0c0b0dfe3dee2d0ec", 81, 137))
if m.btnExitCancel <> invalid then m.btnExitCancel.observeField(_l1d_14a035("405054573f4381524e585d6f6165", 47, 243), _l1d_14a035("54587474666e82676d6b6c78", 231, 204))
if m.btnExitConfirm <> invalid then m.btnExitConfirm.observeField(_l1d_14a035("2a1e222531354b403c46473d4f53", 121, 15), _l1d_14a035("1216fe26183808272b362a4834", 201, 108))
if m.navLiveTv <> invalid then m.navLiveTv.observeField(_l1d_14a035("170b0f121e22382d2933342a3c40", 121, 252), _l1d_14a035("02062901f7341200142809", 179, 38))
m.navHome.observeField(_l1d_14a035("3e2e32353d415f504c565b4d5f63", 63, 225), _l1d_14a035("474b2e566c35595e69", 203, 163))
m.navMovies.observeField(_l1d_14a035("0afcfe010b0ded1e182429192d2f", 158, 14), _l1d_14a035("080aed130bf51a141a291a", 216, 81))
m.navTv.observeField(_l1d_14a035("4a5c5e615b5d8d5e686469796d6f", 166, 134), _l1d_14a035("4a4c2f5d6d4e73", 76, 39))
m.navCategories.observeField(_l1d_14a035("fd0b0d100e10400d17131c281c1e", 36, 183), _l1d_14a035("d4d6b9e7d7cff0def2f7f2f0fa01fa", 156, 225))
if m.navSearch <> invalid then m.navSearch.observeField(_l1d_14a035("374d4f5250527a4f5955566a5e60", 32, 245), _l1d_14a035("b9bde0b8ceecc5c4d6c8d6", 163, 237))
if m.navPortal <> invalid then m.navPortal.observeField(_l1d_14a035("75616568747896837f8992809296", 61, 22), _l1d_14a035("1a1c3f313d662c4a4b4339", 110, 25))
m.navBtns = [m.navLiveTv, m.navHome, m.navMovies, m.navTv, m.navCategories, m.navSearch, m.navPortal]
m.verifyOverlay = m.top.findNode(_l1d_14a035("5a4c645e5674856f61796e6e89", 164, 136))
m.verifyTitle = m.top.findNode(_l1d_14a035("8e8498868a9c8292a8939f", 14, 22))
m.verifyDetail = m.top.findNode(_l1d_14a035("8da38fada9a391b5a7b7c2c8", 82, 105))
m.viewStack = []
m.top.observeField(_l1d_14a035("7872798e8f8488", 233, 233), _l1d_14a035("2024ea1d2230280e382f2425", 209, 98))
m.sessionWatchdogTimer = CreateObject(_l1d_14a035("080eedfcf81a2426", 221, 89), _l1d_14a035("1dfbfaf50f", 101, 236))
m.sessionWatchdogTimer.duration = 4
m.sessionWatchdogTimer.repeat = true
m.sessionWatchdogTimer.observeField(_l1d_14a035("88907a92", 243, 243), _l1d_14a035("787a728b989b888d8f8b9cb2a09caba5b0a4acb5b0", 10, 19))
if KA_IsActivated() then
verifyAndShowHome()
else
showKeyAuthView()
end if
m.initFocusTimer = CreateObject(_l1d_14a035("c0b0e7ded8bcc4c8", 104, 166), _l1d_14a035("a8aeb5c0d2", 201, 11))
m.initFocusTimer.duration = 0.15
m.initFocusTimer.repeat = false
m.initFocusTimer.observeField(_l1d_14a035("a197b3a9", 104, 147), _l1d_14a035("5458805e665e8f6978696e907e7d887e", 255, 196))
m.initFocusTimer.control = _l1d_14a035("5c5e546667", 71, 40)
end sub
sub verifyAndShowHome()
if ((37128 - 4641 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
_l1Ill1l = KA_GetSavedLicense()
_llIll1l = KA_GetSavedExpiry()
if KA_IsExpired(_llIll1l) then
KA_ClearLicense()
showToast(_l1d_14a035("45657277736b803e666c77837f9597", 152, 113))
showKeyAuthView()
if m.keyAuthView <> invalid then
_lIIll1l = m.keyAuthView.findNode(_l1d_14a035("0f15031b1d1e34162a18232b", 33, 189))
if _lIIll1l <> invalid then
_lIIll1l.text = _l1d_14a035("b4a58e9869b0b6b3b0beacb981ccc6bb8dcbcbc6e0cedadeaba8fbf2ecf3e8f5bdfb09f204fecf111bd81a1f0d2b1525ed343a373442303d0551464517", 53, 72)
end if
end if
return
end if
setHeaderVisible(false)
if m.verifyOverlay <> invalid then
m.verifyOverlay.visible = true
if m.verifyTitle <> invalid then m.verifyTitle.text = _l1d_14a035("776d616f7365787480c89f87909189899ac6e3", 254, 207) + _l1Ill1l
if m.verifyDetail <> invalid then m.verifyDetail.text = _l1d_14a035("0bfafcfff9fa0e060e0a461d1b4f441621294230384a334149734a487c4251534e54605e946363606571796eac7885b5797e928a9a8cd8dbde", 224, 104)
end if
if m.verifyTask <> invalid then m.verifyTask.control = _l1d_14a035("737d857f", 91, 107)
m.verifyTask = CreateObject(_l1d_14a035("64548b827c60686c", 232, 202), _l1d_14a035("2009f8330204132a22131e", 62, 171))
m.verifyTask.action = _l1d_14a035("9d8da78f99a5", 45, 66)
m.verifyTask.observeField(_l1d_14a035("9eaca5a2bca7", 180, 216), _l1d_14a035("afb199c1b1c1caceccb1c7d3d1cde7bfd9e6efe9f4", 2, 66))
m.verifyTask.control = _l1d_14a035("c5c1cf", 253, 22)
end sub
sub onStartupVerifyResult()
if ((4842 - 1614 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.verifyOverlay <> invalid then m.verifyOverlay.visible = false
_lI1I11l = m.verifyTask.result
if _lI1I11l <> invalid and _lI1I11l.success = true then
showToast(_l1d_14a035("0ae8e5eaf8def3b315faf006f808c2cb", 177, 13) + KA_GetSavedLicense())
showPortalSelectView()
startSessionWatchdog()
else
_l11I11l = _l1d_14a035("b79f9899a1b1a268b4b0b2b3c3c3c7bd", 166, 205)
if _lI1I11l <> invalid and _lI1I11l.message <> invalid and _lI1I11l.message <> "" then
_l11I11l = KA_CleanAuthMessage(_lI1I11l.message)
end if
KA_ClearLicense()
showToast(_l1d_14a035("af85908ca9939fb5a2a8b87865", 166, 187) + _l11I11l)
showKeyAuthView()
if m.keyAuthView <> invalid then
_llII11l = m.keyAuthView.findNode(_l1d_14a035("dde7d5edefecc6e8fceaf5fd", 3, 109))
if _llII11l <> invalid then
_llII11l.text = _l1d_14a035("e6cab2d2cfcc8c95", 180, 236) + _l11I11l + chr(10) + _l1d_14a035("bc8da6ae5f969eaba8a4c4b177b3d080b9bdd58cd0d5e1d1e9dba1dbddaa1ff1ecec15f30b25fe1414c4d1440b171e3320e626223b2f47f83c3401454a56465e50164d55625f5b7b682e6c718030", 44, 71)
end if
end if
end if
end sub
sub onSceneFocus()
if m.top.hasFocus() then
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then return
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
end sub
sub onInitFocusTimer()
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then return
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
if m.initFocusTimer <> invalid then m.initFocusTimer.control = _l1d_14a035("5d5d6767", 94, 48)
end sub
sub showHomeView(_l1I1ll1 = _l1d_14a035("5b5f646f", 251, 200) as String)
if ((58136 - 7267 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("2c010e0a3f0e0e071018201957221e2f632b413c38403a3c7b494f8450598d595d685a686866afa89b7a7675867fbd858d9a8e9acf939fd89c9db5adb9afedbcbcb5bec6cec705cfd0e711e8e21adcebedfaf2f604f73f", 98, 241))
return
end if
clearViews()
m.homeView = CreateObject(_l1d_14a035("07252c434f312f31", 243, 134), _l1d_14a035("fddddee9ffebf2e7", 189, 8))
m.homeView.category = _l1I1ll1
m.homeView.observeField(_l1d_14a035("5065616b6c6274788e6e807b", 185, 134), _l1d_14a035("1012f4322621162f2935324a3e40", 74, 235))
m.homeView.observeField(_l1d_14a035("7a6d817f8588629488929f", 131, 138), _l1d_14a035("292d5232332e473a2e4446496339495740", 245, 143))
m.viewHost.appendChild(m.homeView)
m.viewStack.Push(m.homeView)
setHeaderVisible(true)
focusActiveView(m.homeView)
end sub
sub onHomeScrollEvent()
checkLicenseOnInteraction()
end sub
sub showDetailsView(_ll1Il11 as Object)
if ((31095 - 6219 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.detailsView = CreateObject(_l1d_14a035("260e4d3c361a2226", 236, 136), _l1d_14a035("d2f608000b091bf9170e23", 4, 146))
m.detailsView.content = _ll1Il11
m.detailsView.observeField(_l1d_14a035("cad9dfca05e6e0e6ebef", 59, 127), _l1d_14a035("e6e8f9f0f0eb16f7e7070406", 118, 205))
m.viewHost.appendChild(m.detailsView)
m.viewStack.Push(m.detailsView)
setHeaderVisible(false)
m.detailsView.setFocus(true)
end sub
sub showPlayerView(_l1l1I11 as Object)
m.playerView = CreateObject(_l1d_14a035("1d0b423935172527", 107, 4), _l1d_14a035("00eff5e0fff118fc0b00", 185, 23))
m.playerView.playConfig = _l1l1I11
m.playerView.observeField(_l1d_14a035("475151605189605e796076", 103, 67), _l1d_14a035("6f73a17b7b9a8bc38a98a39ab0", 111, 111))
m.viewHost.appendChild(m.playerView)
m.viewStack.Push(m.playerView)
setHeaderVisible(false)
m.playerView.setFocus(true)
end sub
sub showSearchView()
clearViews()
m.searchView = CreateObject(_l1d_14a035("ddfd041b25090105", 48, 155), _l1d_14a035("19121103151330182718", 251, 113))
m.searchView.observeField(_l1d_14a035("c6b7b3bdc2d4c6caa8e0d2cd", 79, 138), _l1d_14a035("1d1f452b1f2a5b28322e37433739", 100, 18))
m.viewHost.appendChild(m.searchView)
m.viewStack.Push(m.searchView)
setHeaderVisible(true)
m.searchView.setFocus(true)
end sub
sub showMyListView()
if ((21141 - 7047 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
clearViews()
m.myListView = CreateObject(_l1d_14a035("98967d7480a29c9e", 193, 229), _l1d_14a035("ad84b49a9795baa6ada2", 189, 189))
m.myListView.observeField(_l1d_14a035("2b3c364247374b4d6d435752", 62, 222), _l1d_14a035("81836d9387927f909a969bab9fa1", 134, 152))
m.viewHost.appendChild(m.myListView)
m.viewStack.Push(m.myListView)
setHeaderVisible(true)
m.myListView.setFocus(true)
end sub
sub showCategoriesView()
if ((20328 - 2541 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
clearViews()
m.categoriesView = CreateObject(_l1d_14a035("37271e150f333f43", 202, 127), _l1d_14a035("1c01f90b0c17ff1b1a072f272617", 51, 172))
m.categoriesView.observeField(_l1d_14a035("a4a997abaca7a5a38cbdb7c3c8b8ccce", 222, 231), _l1d_14a035("cdd1a7ccc4d6d7e2cad6afe8f4eeebe5f7fb", 147, 209))
m.viewHost.appendChild(m.categoriesView)
m.viewStack.Push(m.categoriesView)
setHeaderVisible(true)
m.categoriesView.setFocus(true)
end sub
sub showKeyAuthView()
stopSessionWatchdog()
clearViews()
m.keyAuthView = CreateObject(_l1d_14a035("142cfb0a14383438", 22, 176), _l1d_14a035("89ae9d98a7a9b891bfc6bb", 220, 242))
m.keyAuthView.observeField(_l1d_14a035("feffef0ff30dfb1b181a2a0b202324191c", 246, 103), _l1d_14a035("3236143128132a2e451136474a4f4043", 145, 52))
m.keyAuthView.observeField(_l1d_14a035("9694988fa47a9eada2", 153, 156), _l1d_14a035("0305e5161df82f31180222243b34", 10, 158))
m.viewHost.appendChild(m.keyAuthView)
m.viewStack.Push(m.keyAuthView)
setHeaderVisible(false)
focusActiveView(m.keyAuthView)
end sub
sub onKeyAuthSuccess()
if ((24042 - 8014 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
showToast(_l1d_14a035("547c85867e7e8f55799a8a9a8ea896aaac7385a6bbbebfb4b7c5bbc5c8c09b", 30, 2))
showPortalSelectView()
startSessionWatchdog()
end sub
sub onKeyAuthClose()
if ((44560 - 8912 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if KA_IsActivated() then
showPortalSelectView()
else
showExitModal()
end if
end sub
sub showPortalSelectView()
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("647986823786867f889098914f9a96a75ba3b9b4b0b8b2b473c1c77cc8d185d1d5e0d2e0e0dea7a0d3f2eeedfef7b5fd05120612c70b17d014152d253127e534342d363e463ffd47485f09605a12546365726a6e7c6f37", 130, 137))
return
end if
clearViews()
m.portalSelectView = CreateObject(_l1d_14a035("637b8a99a3877f83", 116, 93), _l1d_14a035("2a44524f474d3f4c56525b674c6a6176", 196, 150))
m.portalSelectView.observeField(_l1d_14a035("ebece8ec21f2fcf8fd0d0103", 102, 224), _l1d_14a035("d9dba0e2c8cdddebcff4ecf0c1f600fcfdf10507", 144, 218))
m.portalSelectView.observeField(_l1d_14a035("313738334d47363d503d45595b", 122, 25), _l1d_14a035("0e10111735362e24113738332d3f5655485d5d5153", 206, 109))
m.viewHost.appendChild(m.portalSelectView)
m.viewStack.Push(m.portalSelectView)
setHeaderVisible(false)
focusActiveView(m.portalSelectView)
end sub
sub onPortalModeSelected(_ll1llll as Object)
_l11llll = _ll1llll.getData()
if _l11llll = _l1d_14a035("b7b7a3b9abac", 178, 217) then
showLiveTvView()
else if _l11llll = _l1d_14a035("1a0612", 42, 190) then
showHomeView(_l1d_14a035("23252621", 4, 183))
end if
end sub
sub onPortalBackRequested()
if ((48486 - 8081 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
showExitModal()
end sub
sub showLiveTvView()
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("d50ef7f74817171419250d22602b271c6c342a25412d434584563c8d594696626a556371716fbcb144837f7e7388c68e9a839787d89cace1a5aa9eb6a6b8f6c5c5c2c7d3bbd00edcd9d01ad1ef23e9f8fae3fb03ed004c", 208, 76))
return
end if
clearViews()
m.liveTvView = CreateObject(_l1d_14a035("8c8271606c8e8c8e", 199, 215), _l1d_14a035("765666588a6f9268677c", 224, 202))
m.liveTvView.observeField(_l1d_14a035("7571776e83577d8c81", 152, 122), _l1d_14a035("aaaecfb5afbfd3b8eec4c8c7d4", 189, 216))
m.liveTvView.observeField(_l1d_14a035("a6a596aca29e999fbdbeb6ac", 14, 41), _l1d_14a035("e9ed0eec0efe3217351c0121110b46162e332121", 105, 227))
m.viewHost.appendChild(m.liveTvView)
m.viewStack.Push(m.liveTvView)
setHeaderVisible(false)
focusActiveView(m.liveTvView)
end sub
sub onLiveTvClose()
if ((80748 - 8972 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
showPortalSelectView()
end sub
sub onLiveTvSwitchPortal()
showPortalSelectView()
end sub
sub onCategorySelected(_ll1lIIl as Object)
_lIllIIl = _ll1lIIl.getData()
if _lIllIIl = invalid or _lIllIIl = "" then return
if _lIllIIl = _l1d_14a035("5a58465a4e4f", 179, 123) then
showLiveTvView()
else if _lIllIIl = _l1d_14a035("282e2c2d453b", 222, 122) then
showPortalSelectView()
else if _lIllIIl = _l1d_14a035("95aead9fb1af", 187, 205) then
showSearchView()
else if _lIllIIl = _l1d_14a035("93ac9cb0bebdc3acae", 183, 211) then
showMyListView()
else if _lIllIIl = _l1d_14a035("b3b8c7c2d1d3c2", 76, 140) then
showKeyAuthView()
else
showHomeView(_lIllIIl)
end if
end sub
sub clearViews()
m.viewHost.removeChildrenIndex(m.viewHost.getChildCount(), 0)
m.viewStack.Clear()
end sub
sub setHeaderVisible(_l1IlIl1 as Boolean)
if ((19350 - 2150 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
m.headerBar.visible = _l1IlIl1
m.accentLine.visible = _l1IlIl1
m.topBar.visible = _l1IlIl1
if m.bgGradient <> invalid then m.bgGradient.visible = _l1IlIl1
if _l1IlIl1 then
m.viewHost.translation = [0, 140]
else
m.viewHost.translation = [0, 0]
end if
end sub
sub onItemSelected(_lI1Il11 as Object)
if ((44025 - 8805 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("adc6cfcf00cfcfccd1dde5da18e3dff424ec02fdf905fbfd3c0e1445111e4e1a222d1b29292774691c3b37364b407e46525b4f5f905464995d62766e7e70ae7d7d7a7f8b9388c69491a8d2a9a7dba1b0b2bbb3bbc5b804", 192, 20))
return
end if
_llIIl11 = _lI1Il11.getData()
if _llIIl11 <> invalid then
showDetailsView(_llIIl11)
end if
end sub
sub onPlayAction(_l111I11 as Object)
if ((61731 - 6859 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_ll11I11 = _l111I11.getData()
if _ll11I11 <> invalid then
if not KA_IsActivated() or KA_IsExpired(KA_GetSavedExpiry()) then
kickoutUser(_l1d_14a035("dff811114201010e130f271c5a152136662e343f2b473d3f7e4056874360904c546f5d5b5b69a6ab5e6d79788d82c0967f908acf8b93d8b297b59ce7ababf0b4b9cdb5d5c705c4c4d1d6d2eadf1ddbe8ef2900ee32080c0d03020145", 72, 206))
return
end if
m.pendingPlayConfig = _ll11I11
showToast(_l1d_14a035("dd0f071119071a1a26ea212936332f2f3c023441374611265853533c5a524c655b5b2b2e31", 28, 147))
if m.playVerifyTask <> invalid then m.playVerifyTask.control = _l1d_14a035("78828a84", 123, 80)
m.playVerifyTask = CreateObject(_l1d_14a035("9b99807783a59fa1", 129, 168), _l1d_14a035("6a573e7950545b7a685d68", 185, 120))
m.playVerifyTask.action = _l1d_14a035("d0e2d2ecece2", 48, 138)
m.playVerifyTask.observeField(_l1d_14a035("eafcf1f20cf7", 182, 38), _l1d_14a035("c5c9b6cdcbe6c0d0eae2dcf8d6e2fbf8f4ff", 5, 91))
m.playVerifyTask.control = _l1d_14a035("868e98", 123, 93)
end if
end sub
sub onPlayVerifyResult()
if ((56256 - 9376 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.playVerifyTask = invalid then return
_ll1l1I1 = m.playVerifyTask.result
if _ll1l1I1 = invalid then return
if _ll1l1I1.success = true then
if _ll1l1I1.expiry <> invalid then U_PrefSet(_l1d_14a035("8f88a18a8a859f8d95", 117, 113), _ll1l1I1.expiry)
if m.pendingPlayConfig <> invalid then
_l1ll1I1 = m.pendingPlayConfig
m.pendingPlayConfig = invalid
showPlayerView(_l1ll1I1)
end if
else
_lIll1I1 = _l1d_14a035("d0f0f902faf20bc9fa1404100f2022", 26, 122)
if _ll1l1I1.message <> invalid and _ll1l1I1.message <> "" then _lIll1I1 = KA_CleanAuthMessage(_ll1l1I1.message)
m.pendingPlayConfig = invalid
kickoutUser(_l1d_14a035("917679768f92c4a38593978e92f3dcd6a7b0baebb2b8b5b2c0cebb03cdda0cd5d715dce0e4dedff92aecf1fffd07f73f4a", 229, 237) + _lIll1I1 + _l1d_14a035("6464", 20, 39))
end if
end sub
sub onClosePlayer()
if m.viewStack.Count() > 0 then
_lllIII1 = m.viewStack.Peek()
if _lllIII1 <> invalid and _lllIII1.isSubtype(_l1d_14a035("818898a39aae8d9fa6b7", 206, 227)) then
m.viewHost.removeChild(_lllIII1)
m.viewStack.Pop()
if m.viewStack.Count() > 0 then
_lII1II1 = m.viewStack.Peek()
focusActiveView(_lII1II1)
if _lII1II1 <> invalid and _lII1II1.isSubtype(_l1d_14a035("5a383d38484a4132", 118, 28)) then
_lII1II1.category = _lII1II1.category
end if
else
showHomeView(_l1d_14a035("615f646f", 94, 43))
end if
end if
end if
end sub
sub focusActiveView(_l1l11lI as Object)
if _l1l11lI = invalid then return
if _l1l11lI.isSubtype(_l1d_14a035("fe3a222b39490d46524c4943245c5b4c", 19, 187)) then
setHeaderVisible(false)
_l1l11lI.setFocus(true)
_llIl1lI = _l1l11lI.findNode(_l1d_14a035("c2d3bce1c9ddd305e6", 238, 54))
if _llIl1lI <> invalid then _llIl1lI.setFocus(true)
else if _l1l11lI.isSubtype(_l1d_14a035("5e3e2e4052375a504f44", 48, 226)) then
setHeaderVisible(false)
_l1l11lI.setFocus(true)
else if _l1l11lI.isSubtype(_l1d_14a035("aed2e4dce7e5f7d5f3eaff", 68, 174)) then
setHeaderVisible(false)
_l1l11lI.setFocus(true)
_llIl1lI = _l1l11lI.findNode(_l1d_14a035("96b5aba6d4a9c6", 241, 21))
if _llIl1lI <> invalid then _llIl1lI.setFocus(true)
else if _l1l11lI.isSubtype(_l1d_14a035("678f909b7195a499", 25, 22)) then
setHeaderVisible(true)
_l1l11lI.setFocus(true)
_llIl1lI = _l1l11lI.findNode(_l1d_14a035("c8c0d4ccfcd3d3eef6e7e0", 166, 250))
if _llIl1lI <> invalid and _llIl1lI.visible then
_llIl1lI.setFocus(true)
else
_lll11lI = _l1l11lI.findNode(_l1d_14a035("2d1530fc243d3d", 78, 241))
if _lll11lI <> invalid then _lll11lI.setFocus(true)
end if
else if _l1l11lI.isSubtype(_l1d_14a035("2a3f3e52464e3f555469", 192, 151)) then
setHeaderVisible(true)
_l1l11lI.setFocus(true)
_l1Il1lI = _l1l11lI.findNode(_l1d_14a035("87949b99979cb2a7", 9, 37))
if _l1Il1lI <> invalid then _l1Il1lI.setFocus(true)
else if _l1l11lI.isSubtype(_l1d_14a035("ceefddf1f601ef0900f9d7150c01", 148, 247)) then
setHeaderVisible(true)
_l1l11lI.setFocus(true)
_llIl1lI = _l1l11lI.findNode(_l1d_14a035("c6bfc8a4d5cbd9d5dcdcd5dd", 26, 78))
if _llIl1lI <> invalid then _llIl1lI.setFocus(true)
else if _l1l11lI.isSubtype(_l1d_14a035("330a382019193a2c3324", 62, 192)) then
setHeaderVisible(true)
_l1l11lI.setFocus(true)
_lIIl1lI = _l1l11lI.findNode(_l1d_14a035("464431376b3b5353", 241, 169))
if _lIIl1lI <> invalid then _lIIl1lI.setFocus(true)
else if _l1l11lI.isSubtype(_l1d_14a035("3a1f0e49181c2b4430372c", 189, 68)) then
setHeaderVisible(false)
_l1Il1lI = _l1l11lI.findNode(_l1d_14a035("36374e38463f514a", 227, 174))
if _l1Il1lI <> invalid then
_l1Il1lI.setFocus(true)
else
_l1l11lI.setFocus(true)
end if
else
_l1l11lI.setFocus(true)
end if
end sub
sub onNavLiveTv()
if ((18505 - 3701 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
showLiveTvView()
end sub
sub onNavPortal()
if ((45808 - 6544 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
showPortalSelectView()
end sub
sub onNavHome()
showHomeView(_l1d_14a035("828c8d88", 96, 122))
end sub
sub onNavMovies()
showHomeView(_l1d_14a035("2c2d49394055", 207, 138))
showToast(_l1d_14a035("e3fb1418070f1a0d111d5d14312b2330282c38781839533d4c59", 74, 213))
end sub
sub onNavTv()
if ((15309 - 1701 * 9) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
showHomeView(_l1d_14a035("5b50605a596a", 32, 8))
showToast(_l1d_14a035("4a303d3f3e344f424c460477575d635f556b1c93982599737b8685", 33, 229))
end sub
sub onNavCategories()
showCategoriesView()
end sub
sub onNavSearch()
showSearchView()
end sub
sub onShowToastChange()
_lIII11l = m.top.showToast
if _lIII11l <> invalid and _lIII11l <> "" then
showToast(_lIII11l)
end if
end sub
sub showToast(_llI1lIl as String)
if ((46392 - 7732 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.toastText.text = _llI1lIl
m.toastGroup.visible = true
m.toastTimer = CreateObject(_l1d_14a035("e8f00f1e18fc0408", 252, 90), _l1d_14a035("20100f1a12", 252, 120))
m.toastTimer.duration = 2.5
m.toastTimer.observeField(_l1d_14a035("9593af9d", 172, 203), _l1d_14a035("323634382a443d4e56", 2, 200))
m.toastTimer.control = _l1d_14a035("b1b9c9b9c2", 122, 168)
end sub
sub hideToast()
m.toastGroup.visible = false
if m.toastTimer <> invalid then m.toastTimer.control = _l1d_14a035("f6f2e0fc", 76, 183)
end sub
sub showExitModal()
if m.exitModal <> invalid then
m.exitModal.visible = true
if m.btnExitCancel <> invalid then m.btnExitCancel.setFocus(true)
end if
end sub
sub hideExitModal()
if m.exitModal <> invalid then
m.exitModal.visible = false
if m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
end sub
sub onExitCancel()
hideExitModal()
end sub
sub onExitConfirm()
m.top.exitApp = true
end sub
function onKeyEvent(_lIIl1I1 as String, _lIl11I1 as Boolean) as Boolean
if ((16596 - 2766 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if not _lIl11I1 then return false
if m.exitModal <> invalid and m.exitModal.visible then
if _lIIl1I1 = _l1d_14a035("9ca0a19c", 107, 147) then
hideExitModal()
return true
else if _lIIl1I1 = _l1d_14a035("232f2f24", 250, 141) or _lIIl1I1 = _l1d_14a035("c8c6", 88, 155) then
if m.btnExitCancel <> invalid then
m.btnExitCancel.setFocus(true)
return true
end if
else if _lIIl1I1 = _l1d_14a035("bad2cbd9c0", 53, 115) or _lIIl1I1 = _l1d_14a035("9c98b39f", 77, 115) then
if m.btnExitConfirm <> invalid then
m.btnExitConfirm.setFocus(true)
return true
end if
else if _lIIl1I1 = _l1d_14a035("a3aa", 68, 152) or _lIIl1I1 = _l1d_14a035("5e534d595a6e", 232, 195) then
if m.btnExitConfirm <> invalid and m.btnExitConfirm.hasFocus() then
onExitConfirm()
return true
else
onExitCancel()
return true
end if
end if
return true
end if
if m.verifyOverlay <> invalid and m.verifyOverlay.visible then
if _lIIl1I1 = _l1d_14a035("a3a3a8a3", 189, 196) then
showExitModal()
return true
end if
return true
end if
if KA_IsActivated() then
checkLicenseOnInteraction()
end if
if m.top.hasFocus() then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
end if
end if
if _lIIl1I1 = _l1d_14a035("6d5f5e7c797d6b", 87, 53) then
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
_ll111I1 = m.viewStack.Peek()
if _ll111I1 <> invalid and _ll111I1.isSubtype(_l1d_14a035("685f5d585f5574746b5c", 55, 1)) then
return false
end if
end if
showSearchView()
return true
end if
if m.topBar <> invalid and m.topBar.isInFocusChain() then
if _lIIl1I1 = _l1d_14a035("97918c96", 186, 185) then
if m.viewStack.Count() > 0 then
focusActiveView(m.viewStack.Peek())
return true
end if
else if _lIIl1I1 = _l1d_14a035("282a2f2a", 124, 10) then
if m.viewStack.Count() > 0 then
_lI1l1I1 = m.viewStack.Peek()
if _lI1l1I1.isSubtype(_l1d_14a035("fe282924182e2d42", 64, 246)) then
showExitModal()
return true
else
focusActiveView(_lI1l1I1)
return true
end if
else
showExitModal()
return true
end if
else if _lIIl1I1 = _l1d_14a035("8995958a", 126, 119) or _lIIl1I1 = _l1d_14a035("8078717f86", 229, 233) then
_l1Il1I1 = 0
for _llIl1I1 = 0 to m.navBtns.Count() - 1
if m.navBtns[_llIl1I1].hasFocus() then
_l1Il1I1 = _llIl1I1
exit for
end if
end for
if _lIIl1I1 = _l1d_14a035("ede9def0f7", 71, 184) then
_lll11I1 = (_l1Il1I1 + 1) Mod m.navBtns.Count()
else
_lll11I1 = (_l1Il1I1 - 1 + m.navBtns.Count()) Mod m.navBtns.Count()
end if
m.navBtns[_lll11I1].setFocus(true)
return true
else if _lIIl1I1 = _l1d_14a035("9090", 115, 138) then
return true
end if
return false
end if
if _lIIl1I1 = _l1d_14a035("8d8d928d", 253, 238) then
if m.viewStack.Count() > 1 then
_ll111I1 = m.viewStack.Pop()
m.viewHost.removeChild(_ll111I1)
_l1l11I1 = m.viewStack.Peek()
if _l1l11I1 <> invalid then
focusActiveView(_l1l11I1)
return true
end if
else if m.viewStack.Count() = 1 then
_l11l1I1 = m.viewStack[0]
if _l11l1I1.isSubtype(_l1d_14a035("053219142b2d34153b4a3f", 152, 50)) and not KA_IsActivated() then
showExitModal()
return true
else if _l11l1I1.isSubtype(_l1d_14a035("455169726060546d6973708a6b738293", 75, 42)) then
showExitModal()
return true
else
showPortalSelectView()
return true
end if
else
showExitModal()
return true
end if
else if _lIIl1I1 = _l1d_14a035("121a", 135, 32) then
if m.headerBar.visible then
if m.viewStack.Count() > 0 then
_lI1l1I1 = m.viewStack.Peek()
if _lI1l1I1 <> invalid then
if _lI1l1I1.isSubtype(_l1d_14a035("1a3b51454a555b5554654b616075", 192, 151)) then
m.navCategories.setFocus(true)
return true
else if _lI1l1I1.isSubtype(_l1d_14a035("405158685c584d5f6677", 78, 35)) then
m.navSearch.setFocus(true)
return true
else if _lI1l1I1.isSubtype(_l1d_14a035("00e5d5e7e8f3e3fff6eb0b0b02f3", 55, 140)) or _lI1l1I1.isSubtype(_l1d_14a035("cdc4d4bad7d5fac6cde2", 45, 109)) then
m.navCategories.setFocus(true)
return true
else if _lI1l1I1.isSubtype(_l1d_14a035("dfc1c2bdf1cfc6db", 164, 243)) and _lI1l1I1.category <> invalid then
_ll1l1I1 = _lI1l1I1.category
if _ll1l1I1 = _l1d_14a035("dbe0fae0ef00", 200, 54) then
m.navMovies.setFocus(true)
return true
else if _ll1l1I1 = _l1d_14a035("f6e7fbe9f005", 46, 153) or _ll1l1I1 = _l1d_14a035("6b70", 216, 191) then
m.navTv.setFocus(true)
return true
else if _ll1l1I1 <> _l1d_14a035("97939893", 87, 88) then
m.navCategories.setFocus(true)
return true
end if
end if
end if
end if
m.navHome.setFocus(true)
return true
end if
end if
return false
end function
sub startSessionWatchdog()
m.watchdogTickCount = 0
if m.sessionWatchdogTimer <> invalid then
m.sessionWatchdogTimer.control = _l1d_14a035("09090313", 38, 180)
m.sessionWatchdogTimer.control = _l1d_14a035("acb6a4b6bf", 235, 20)
end if
end sub
sub stopSessionWatchdog()
if ((11790 - 2358 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if m.sessionWatchdogTimer <> invalid then
m.sessionWatchdogTimer.control = _l1d_14a035("7f7f6989", 110, 98)
end if
end sub
sub checkLicenseOnInteraction()
if ((19359 - 6453 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
if not KA_IsActivated() then
kickoutUser(_l1d_14a035("b1aa939566b5b3b0b5c3a9be7ec8b587d8dac493d5dad0e6d8e8b6abfefdf7f6eb00c00614fd0f01d21426db1d22182e2030f03f3d3a3f4d33480854514822", 49, 73))
return
end if
_llIIIlI = KA_GetSavedExpiry()
if KA_IsExpired(_llIIIlI) then
kickoutUser(_l1d_14a035("68819a9c4d8c8a979c9ab0a565a0aabf71b7bfcab4d2c6ca878cbfced8d7ece1a1e7e5fef002b3f5f7bcfe0319ff2111d1100e1b201e3429e9253239f54c38fe4241455e444e6659196d7374686766656f7935", 137, 152))
return
end if
_l1IIIlI = CreateObject(_l1d_14a035("3f370f3745392b4b4a45", 4, 201)).AsSeconds()
if m.lastOnlineVerifyTime = invalid then m.lastOnlineVerifyTime = 0
if (_l1IIIlI - m.lastOnlineVerifyTime) >= 4 then
m.lastOnlineVerifyTime = _l1IIIlI
triggerOnlineVerify()
end if
end sub
sub triggerOnlineVerify()
if not KA_IsActivated() then return
if m.watchdogTask <> invalid and m.watchdogTask.state = _l1d_14a035("f4fef6f9fbfffb", 162, 36) then return
if m.watchdogTask <> invalid then
m.watchdogTask.unobserveField(_l1d_14a035("8a7e8f94809b", 73, 79))
m.watchdogTask = invalid
end if
m.watchdogTask = CreateObject(_l1d_14a035("e3e108ff0bede7e9", 33, 144), _l1d_14a035("d9f2f1dcebed0cd30bfc17", 86, 188))
m.watchdogTask.action = _l1d_14a035("5a4c5c56566c", 32, 4)
m.watchdogTask.observeField(_l1d_14a035("7b8b80818d88", 31, 14), _l1d_14a035("44488257675f59605c679b6b856d7783b17d96937f9a", 173, 130))
m.watchdogTask.control = _l1d_14a035("35352f", 7, 224)
end sub
sub onSessionWatchdogTick()
if not KA_IsActivated() then
stopSessionWatchdog()
return
end if
_lIlllII = KA_GetSavedExpiry()
if KA_IsExpired(_lIlllII) then
kickoutUser(_l1d_14a035("074039390a4949565b574f64225d695e2e765c67736f858744495c8b97968ba05ea6a29baf9f70b4b479bdc2b6bebed08ecdcddadfdbd3e8a6e4f1d8b2e9f7bb010002fb030b0518d60c1011272625242c38f2", 24, 198))
return
end if
triggerOnlineVerify()
end sub
sub onWatchdogVerifyResult()
if ((42567 - 6081 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.watchdogTask = invalid then return
_l11I1II = m.watchdogTask.result
if _l11I1II = invalid then return
if _l11I1II.success = true then
if _l11I1II.expiry <> invalid and _l11I1II.expiry <> "" then
U_PrefSet(_l1d_14a035("48413a43635e58666e", 133, 90), _l11I1II.expiry)
if KA_IsExpired(_l11I1II.expiry) then
kickoutUser(_l1d_14a035("87a0b9b9eaa9a9b6bbb7cfc402bdc9de0ed6dce7d3efe5e72429dcebf7f60b003e06021b0f1f501414591d22361e3e306e2d2d3a3f3b5348864451589269579b6160627b636b8578b68c9091878685848c98d2", 72, 118))
return
end if
end if
else
_ll1I1II = _l11I1II.message
if _ll1I1II = invalid then _ll1I1II = ""
_lIlI1II = LCase(_ll1I1II)
_l1lI1II = (InStr(1, _lIlI1II, _l1d_14a035("f1d9e0ebedacee0709", 40, 149)) > 0 or InStr(1, _lIlI1II, _l1d_14a035("1e162a2e293933", 5, 179)) > 0 or InStr(1, _lIlI1II, _l1d_14a035("d9e8ecefe7e8fef4fd01", 193, 55)) > 0 or InStr(1, _lIlI1II, _l1d_14a035("4d545659535c681f6e6c", 132, 102)) > 0)
if not _l1lI1II then
_lllI1II = KA_CleanAuthMessage(_ll1I1II)
if _lllI1II = "" then _lllI1II = _l1d_14a035("a68e9b989494a1e79caa9eaab1b6b8ffb9b708c4c4d2d7c3d3cbdd", 252, 246)
kickoutUser(_l1d_14a035("64494c514245176c6056605f6c701932", 185, 108) + _lllI1II + _l1d_14a035("e1f2e5acb6bdcebf07c5bfdccee419dbd122e4e5f7e5fbef37eef4fdfef816074f07101f4d", 111, 160))
end if
end if
end sub
sub kickoutUser(_l1l1lll as String)
if m.playerView <> invalid then
_llI1lll = m.playerView.findNode(_l1d_14a035("696b61656e5e757590778b", 198, 185))
if _llI1lll <> invalid then _llI1lll.control = _l1d_14a035("4844624e", 212, 161)
m.viewHost.removeChild(m.playerView)
m.playerView = invalid
end if
if m.viewStack <> invalid and m.viewStack.Count() > 0 then
for _lll1lll = m.viewStack.Count() - 1 to 0 step -1
_l111lll = m.viewStack[_lll1lll]
if _l111lll <> invalid and _l111lll.isSubtype(_l1d_14a035("f3dae8d3eae403eff6eb", 61, 134)) then
_lI11lll = _l111lll.findNode(_l1d_14a035("a5bbb9bdca8ecdc5c0cfbf", 80, 127))
if _lI11lll <> invalid then _lI11lll.control = _l1d_14a035("1915031f", 204, 90)
m.viewHost.removeChild(_l111lll)
end if
end for
end if
stopSessionWatchdog()
KA_ClearLicense()
clearViews()
showKeyAuthView()
if m.keyAuthView <> invalid then
_lIl1lll = m.keyAuthView.findNode(_l1d_14a035("b1b5a5bbbfc0d4b8cabac5cb", 160, 222))
if _lIl1lll <> invalid then
_lIl1lll.text = _l1l1lll
end if
_lIIllll = m.keyAuthView.findNode(_l1d_14a035("f9fd05050ae80e", 203, 80))
if _lIIllll <> invalid then
_lIIllll.color = _l1d_14a035("7e4956598a8d94979598", 82, 28)
_lIIllll.width = 120
end if
_l1Illll = m.keyAuthView.findNode(_l1d_14a035("3537353b3c0e423037", 156, 55))
if _l1Illll <> invalid then
_l1Illll.text = _l1d_14a035("4860525c5b6c70", 219, 191)
_l1Illll.color = _l1d_14a035("f23d2e310003070a4043", 161, 97)
end if
_ll11lll = m.keyAuthView.findNode(_l1d_14a035("585c6c6266678b83718c88", 176, 149))
if _ll11lll <> invalid then _ll11lll.text = _l1d_14a035("17fcfffcf5f8ca1f0b011b22171b", 181, 35)
end if
showToast(_l1d_14a035("1a3a434c443c5513245e4e5a596a6c112e5273767f6c6f436a8e86889799", 154, 68))
end sub
function _l1d_14a035(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function