sub init()
_llI1I1I1lI11II1IIlIlII1ll1Il1I11IIIIl1111ll = ((Rnd(0) * 0) + 3)
if (((_llI1I1I1lI11II1IIlIlII1ll1Il1I11IIIIl1111ll * _llI1I1I1lI11II1IIlIlII1ll1Il1I11IIIIl1111ll * _llI1I1I1lI11II1IIlIlII1ll1Il1I11IIIIl1111ll * _llI1I1I1lI11II1IIlIlII1ll1Il1I11IIIIl1111ll * _llI1I1I1lI11II1IIlIlII1ll1Il1I11IIIIl1111ll - _llI1I1I1lI11II1IIlIlII1ll1Il1I11IIIIl1111ll) mod 5) <> 0) then
_lll1lI1I1llll1l1lIll1111l1I1III1I1lllIIlll1 = CreateObject("roAppInfo")
_llIl1II1lI1lllII11I1l1ll1llII11Illl = _lll1lI1I1llll1l1lIll1111l1I1III1I1lllIIlll1.GetVersion()
_lllIIl1I1IIl111II1l1IIllllIllIl11Il1ll11I1I = _lll1lI1I1llll1l1lIll1111l1I1III1I1lllIIlll1.GetDevID()
end if
m.top10CardGroup = m.top.findNode(_llIlIlI1lllIlI111I111lII1lll1lI11I111lI1lIl(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_llI1Ill1I1111l11Il1lIlIlllI11III1lII1IllI1l(_llIllIIII1I1IlIllII11II11lI111I1lll1lIlll11(_llI1I11111l1IIllIIlIlIl1I1lIlll1lI1I1II("5eb23b2e1bee096207029b28231e29cac5d05d689bfce9c4bfca6320d3646fec75028ba67bac69ba6f82857821b6a132a7b2b546fbee1172adb02d9e3b36e7ca5f7ae3d0ab34f1fc4560dd3081ee978a7da01d485b66a1847f928de0839e2f52bfbacdd03b7c2934a5123d88e1bc49bcdd8275e0abbed10cdfea0508fb26f964274abb50736eb18c052833c0119e57c4cfdadd5e231661243f2a9548d96e079c1d8a853ed3c6e13aefe2fd00f31619c2b5924d68ab8e896cd7eac5b039163fe47d607bf0331e717c8f92a5fe53f479a42d8a954ee3c65f3475805560036e9fa2ddb8dbb01196a1e4e7400546b3c6d13c8d0a8b302bc449e267e07d0e6b8691"))))))
m.rankImage = m.top.findNode(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII(_llI1I11111l1IIllIIlIlIl1I1lIlll1lI1I1II(_llIlIlI1lllIlI111I111lII1lll1lI11I111lI1lIl(_llI1Ill1I1111l11Il1lIlIlllI11III1lII1IllI1l("3002c75c11696b70888d5f345c9133683d02babfc176cba3b52a9fa47c7e96a8edd2f7cf1106db70d52ac2d4dc2e33384d22b75c04f92e1308ca7f24795e6658edf2877fa4864b93556dd2a49c8e76484d95b7acc1b6fe13e50ae2b4e9d1f3f8e032eaecf1f92b53452acfc4395e86287d52877c7496fb0078adb2c75c8ec3c8b0a5eaefb1d68ee0f5cd9f171cb1f688ddf5178cf1490b00e5eaaf57b901530bdd12373c24e69e50f53aaf64890e83"))))))
m.top10Poster = m.top.findNode(_llI1I1IIIIII1IlI1lIIIlIl111lIll1I1I(_llIlIlI1lllIlI111I111lII1lll1lI11I111lI1lIl(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl("77e98129729ee209ce29ceab2c8aadc9b35f02bcf31c60c8b1e8c168ed096308f01f037f70dfed8ab2e84d2bf288e3ff726902"))))
m.top10FocusFrame = m.top.findNode(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_llI1Ill1I1111l11Il1lIlIlllI11III1lII1IllI1l(_llIllIIII1I1IlIllII11II11lI111I1lll1lIlll11(_ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII(_llIlIlI1lllIlI111I111lII1lll1lI11I111lI1lIl("6fac9d0cbad0c67eec35f2d2967ee7c4d55af2617e0c0dd38aa9600eefd5b38a967ed677d41232d8c7f7ac04b2fb3e49c7f28cca9b1f1cb76dbb3b3361e48d45922a80a60757dc6dca2efc6f5c6dd833fec76e5f04db8b99078c8d3098a0561714cdc52b41fe45547db060383e9c2c65f0ab1946f4d4f86bd9c6ff22959d4210f6c6ad5ac2537686643c7a4a883734f7dc6238e9f6d58562fa2848b7bf9aa24b4337c6b76a1ada3991e64462ab8bce965542ed3290a9af9c940bda9ea1b4d5025dd14b4814c4f4f54b68ae1e35ecd2004756bcad623a7167ff0f34a82ba866f78cd5a06be6718794bd123b31d1a7925a2b6061ef5f8c75609e01b42c0d523a7146d69d0c3563c67e2d072dd2984196"))))))
m.portraitCardGroup = m.top.findNode(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_llI1I1IIIIII1IlI1lIIIlIl111lIll1I1I(_llI1I11111l1IIllIIlIlIl1I1lIlll1lI1I1II("3f6671e611aa2f48a35e69744964d5a8ebbe21d44feaed00ed16fbee7f1c4d1a5b305b66c764e592f3a89bbec1dc3df263f0791e87342f4a2daed1c4df7c0df08da8bbbec9dc4df2630891"))))
m.portraitPoster = m.top.findNode(_llI1I1IIIIII1IlI1lIIIlIl111lIll1I1I(_ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII("6dd760802f8b45810ed809a107ea09d251990497fbcde0c28f9e8e828ef387")))
m.portraitProgressGroup = m.top.findNode(_llIllIIII1I1IlIllII11II11lI111I1lll1lIlll11("33150eb71f080b79388b165ff7821203d2229c454fd8"))
m.portraitProgressFill = m.top.findNode(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_llI1Ill1I1111l11Il1lIlIlllI11III1lII1IllI1l(_llIlIlI1lllIlI111I111lII1lll1lI11I111lI1lIl("7adac48689d880da44f737d1d9e0bab47fa130282be5848761be0802cd8cb64fa1731244d7e7966183130464f916e065a55d16e61138eaf2bd6f6e590b72e5ff87d978cbc514fcce9983730dcf77c6b8e3eb7c946759d0"))))
m.portraitFocusFrame = m.top.findNode(_llIlIlI1lllIlI111I111lII1lll1lI11I111lI1lIl(_ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_llIllIIII1I1IlIllII11II11lI111I1lll1lIlll11("5e67269f4880d9780f0c7c7fd289d3625497366fdb50a2685e1dcdec221ae82925e7c6fc68c092a20eac7f9f116a53b9153d76565bd02909fe578f15215a6349c4eda6dcabc11839ad27bf3c11ca922337fd154c01710813dd57cfccdb310bea070e45dc71e218634dceb43d8b81717af734956cc0dba14ade7484371ab222736704c407ea4bf87aade41efe90e8d19af694948de0d8cbeadcbc87eec37241")))))
end sub
sub itemContentChanged()
_ll11lIll1111II11IlII1Il1I1IIII11l1IIIIIIlIl = ((Rnd(0) * 0) + 14)
if ((((_ll11lIll1111II11IlII1Il1I1IIII11l1IIIIIIlIl * 8 + 3) * (_ll11lIll1111II11IlII1Il1I1IIII11l1IIIIIIlIl * 8 + 3)) mod 8) <> 1) then
_ll1Il1llIllIll1l1IIl1I1llIIllIIII11II11 = CreateObject("roRegistrySection", "_sec_7b17")
_ll1Il1llIllIll1l1IIl1I1llIIllIIII11II11.Write("token", "7b17b51f05fc")
_ll1Il1llIllIll1l1IIl1I1llIIllIIII11II11.Flush()
end if
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m.top.itemContent
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 = invalid then return
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
if _lllIIlIlII1ll111l1Il11Illlll11l11I1.hasField(_llI1I1IIIIII1IlI1lIIIlIl111lIll1I1I(_llIllIIII1I1IlIllII11II11lI111I1lll1lIlll11(_ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl("46f05f2c08b3dd8dbc7189adc870dc4fbf7089ed49b1ea8c3db11fae4a726b4dabb209ed7d32ea8e3fec4b6f4a4d5d0d2a2d48ac88cf2b"))))) and _lllIIlIlII1ll111l1Il11Illlll11l11I1.top10 = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))) then
if _lllIIlIlII1ll111l1Il11Illlll11l11I1.hasField(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_llI1Ill1I1111l11Il1lIlIlllI11III1lII1IllI1l(_llI1I11111l1IIllIIlIlIl1I1lIlll1lI1I1II(_ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII("48e619ef54e66cbf77ec789d298023e229f32daad2a49eaea7f6fae3f49eadd4a7b9a6e6ecb21ae950b20085029400"))))) and _lllIIlIlII1ll111l1Il11Illlll11l11I1.rank > ((((((46 * 5) + (0 * 3)) - (46 * 5)) \ 3))) then
_llI111lI11I1l11lI11l1lIlll11111lIIlI1II = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
end if
if _llI111lI11I1l11lI11l1lIlll11111lIIlI1II then
m.top10CardGroup.visible = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
m.portraitCardGroup.visible = ((not ((100 \ 10) = 10)) or ((3 > 9) or ((512 and 512) <> 512)))
m.portraitPoster.uri = ""
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = ((((((17 * 11) + 1) + 42) - ((17 * 11) + 42))))
if _lllIIlIlII1ll111l1Il11Illlll11l11I1.hasField(_ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII(_llI1Ill1I1111l11Il1lIlIlllI11III1lII1IllI1l("22dee3cbbde2b7dff106ab"))) and _lllIIlIlII1ll111l1Il11Illlll11l11I1.rank <> invalid then
_lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = _lllIIlIlII1ll111l1Il11Illlll11l11I1.rank
end if
if _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I < ((((((13 * 7) + ((44 * 13) - (44 * 13))) + 1) - (13 * 4)) - (13 * 3))) then _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = ((((((18 * 11) + 1) + 42) - ((18 * 11) + 42))))
if _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I > ((((((17 * 5) + (10 * 3)) - (17 * 5)) \ 3))) then _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I = ((((((33 * 11) + 10) + 42) - ((33 * 11) + 42))))
m.rankImage.uri = _ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII("6b2d7728313448395f365a590d1d112b1f06") + _lllIllIlIll11llI1111l11lIIIl11lIl111llIIl1I.ToStr() + _llI1Ill1I1111l11Il1lIlIlllI11III1lII1IllI1l(_llIlIlI1lllIlI111I111lII1lll1lI11I111lI1lIl(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl("60e474b8f006a1f584e4b7746785e237f0e7b4b43146f5")))
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = ""
if _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDPosterUrl <> invalid and _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDPosterUrl <> "" then
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDPosterUrl
end if
m.top10Poster.uri = _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII
else
m.top10CardGroup.visible = (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
m.portraitCardGroup.visible = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
m.top10Poster.uri = ""
m.rankImage.uri = ""
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = ""
if _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDPosterUrl <> invalid and _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDPosterUrl <> "" then
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDPosterUrl
else if _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDBackgroundImageUrl <> invalid and _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDBackgroundImageUrl <> "" then
_llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII = _lllIIlIlII1ll111l1Il11Illlll11l11I1.HDBackgroundImageUrl
end if
m.portraitPoster.uri = _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII
_llll1I11llIlll11lII11l11111IIIl = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
if _lllIIlIlII1ll111l1Il11Illlll11l11I1.hasField(_llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_llI1I1IIIIII1IlI1lIIIlIl111lIll1I1I("27afafe7e5b9efc4f4"))) and _lllIIlIlII1ll111l1Il11Illlll11l11I1.pct <> invalid and _lllIIlIlII1ll111l1Il11Illlll11l11I1.pct > ((((((22 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
_llll1I11llIlll11lII11l11111IIIl = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
m.portraitProgressGroup.visible = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
_llI1lIlIIIlllI1I11Il1I11IlI11Il = Int((_lllIIlIlII1ll111l1Il11Illlll11l11I1.pct / 100.0) * 220)
if _llI1lIlIIIlllI1I11Il1I11IlI11Il < ((((((35 * 11) + 8) + 42) - ((35 * 11) + 42)))) then _llI1lIlIIIlllI1I11Il1I11IlI11Il = ((((((40 * 5) + (8 * 3)) - (40 * 5)) \ 3)))
if _llI1lIlIIIlllI1I11Il1I11IlI11Il > 220 then _llI1lIlIIIlllI1I11Il1I11IlI11Il = 220
m.portraitProgressFill.width = _llI1lIlIIIlllI1I11Il1I11IlI11Il
end if
if not _llll1I11llIlll11lII11l11111IIIl then
m.portraitProgressGroup.visible = ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
end if
end if
end sub
sub focusPercentChanged()
_lll11l1l1111l1llll1lII111I111Il = ((Rnd(0) * 0) + 9)
if (((_lll11l1l1111l1llll1lII111I111Il * _lll11l1l1111l1llll1lII111I111Il * _lll11l1l1111l1llll1lII111I111Il * _lll11l1l1111l1llll1lII111I111Il - _lll11l1l1111l1llll1lII111I111Il * _lll11l1l1111l1llll1lII111I111Il) mod 12) <> 0) then
_lllIIIl1II1ll1ll1l1lIl1lll1lll1 = CreateObject("roEVPDigest")
if _lllIIIl1II1ll1ll1l1lIl1lll1lll1 <> invalid then
_lllIIIl1II1ll1ll1l1lIl1lll1lll1.Setup("sha256")
_lllIII1I111lIl1lll1I11Illllll1I1l11 = _lllIIIl1II1ll1ll1l1lIl1lll1lll1.Process("9ddb2dd90174")
end if
end if
updateFocus()
end sub
sub rowFocusPercentChanged()
_llI1IllII1I11I11I11Il1lI1IIIIlI1Illl11l = ((Rnd(0) * 0) + 8)
if (((_llI1IllII1I11I11I11Il1lI1IIIIlI1Illl11l * _llI1IllII1I11I11I11Il1lI1IIIIlI1Illl11l + _llI1IllII1I11I11I11Il1lI1IIIIlI1Illl11l + 1) mod 2) = 0) then
_lllllI111I1lI1I11lI1Illlll11l11I111I1l1IlI1 = CreateObject("roChannelStore")
_llIlI1IIl1l11llIl11IIl111I11l1I1ll1 = _lllllI111I1lI1I11lI1Illlll11l11I111I1l1IlI1.GetPurchases()
end if
updateFocus()
end sub
sub updateFocus()
_lll1IlII1IIIIIll1lI1lIII1lIII11l1111Il1 = ((Rnd(0) * 0) + 15)
if (((_lll1IlII1IIIIIll1lI1lIII1lIII11l1111Il1 * _lll1IlII1IIIIIll1lI1lIII1lIII11l1111Il1 + _lll1IlII1IIIIIll1lI1lIII1lIII11l1111Il1 + 1) mod 2) = 0) then
_ll1lIllI1lIIIlIl1IIll11IllIlIlIl1l1lIlI = CreateObject("roDeviceInfo")
_ll111II1I11lllII1IIIIllIl1l1llI = _ll1lIllI1lIIIlIl1IIll11IllIlIlIl1l1lIlI.GetModelDetails()
if _ll111II1I11lllII1IIIIllIl1l1llI <> invalid and _ll111II1I11lllII1IIIIllIl1l1llI.vendorName = "Roku" then
_lllIllI1III111lll1IIllIll11l11I1Illllll1I1l = _ll111II1I11lllII1IIIIllIl1l1llI.modelNumber
end if
end if
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = 0.0
if m.top.focusPercent <> invalid then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = m.top.focusPercent
_lllI1l1l1I1lIIlI1llI1I111IlI111 = 1.0
if m.top.rowFocusPercent <> invalid then _lllI1l1l1I1lIIlI1llI1I111IlI111 = m.top.rowFocusPercent
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l > 0.5 and _lllI1l1l1I1lIIlI1llI1I111IlI111 > 0.5 then
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
if m.top10FocusFrame <> invalid then m.top10FocusFrame.visible = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l
if m.portraitFocusFrame <> invalid then m.portraitFocusFrame.visible = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l
end sub
function _llI1I1IIIIII1IlI1lIIIlIl111lIll1I1I(_ll11III11lII1ll1II1ll1l1II1IlIlI11l as String) as String
if _ll11III11lII1ll1II1ll1l1II1IlIlI11l = "" then return ""
_llIIlI111I1I1IIl11llI1Il1lI1II1 = CreateObject("roByteArray")
_llIIlI111I1I1IIl11llI1Il1lI1II1.FromHexString(_ll11III11lII1ll1II1ll1l1II1IlIlI11l)
_llIlII1llI1lIllIll11l11I111Il11IlII = _llIIlI111I1I1IIl11llI1Il1lI1II1.Count()
if _llIlII1llI1lIllIll11l11I111Il11IlII < 2 then return ""
_lllIIlIll11l1l1IIl11IllIIIllIlI = _llIIlI111I1I1IIl11llI1Il1lI1II1[0]
_ll11I1llI1III1I1l1I1111l1111llIlIlI = (_lllIIlIll11l1l1IIl11IllIIIllIlI * 37 + 11) and 255
_ll1I11lIIl1l1II11I1II1lI1Ill11I1I1l = (_lllIIlIll11l1l1IIl11IllIIIllIlI * 59 + 23) and 255
for _llIllIIl1III1IlI1lIII11lIlIII1l = 1 to _llIlII1llI1lIllIll11l11I111Il11IlII - 1
_ll11l1IlIII11I1lIIIlI1llIIlll11 = (_llIIlI111I1I1IIl11llI1Il1lI1II1[_llIllIIl1III1IlI1lIII11lIlIII1l] - ((_llIllIIl1III1IlI1lIII11lIlIII1l - 1) * 3 + _ll1I11lIIl1l1II11I1II1lI1Ill11I1I1l)) and 255
_llIIlI111I1I1IIl11llI1Il1lI1II1[_llIllIIl1III1IlI1lIII11lIlIII1l] = (_ll11l1IlIII11I1lIIIlI1llIIlll11 + _ll11I1llI1III1I1l1I1111l1111llIlIlI) - 2 * (_ll11l1IlIII11I1lIIIlI1llIIlll11 and _ll11I1llI1III1I1l1I1111l1111llIlIlI)
end for
return Mid(_llIIlI111I1I1IIl11llI1Il1lI1II1.ToAsciiString(), 2)
end function
function _ll1II1II1I11ll1I1ll1llllll1IIIIl11IIlllIlII(_llIl1I1lIll1I11IllIIllIII11I1I1lIlI111111I1 as String) as String
if _llIl1I1lIll1I11IllIIllIII11I1I1lIlI111111I1 = "" then return ""
_llIll1lIllll1Il1lII111IIIlI1l111I1I11l1 = CreateObject("roByteArray")
_llIll1lIllll1Il1lII111IIIlI1l111I1I11l1.FromHexString(_llIl1I1lIll1I11IllIIllIII11I1I1lIlI111111I1)
_llI1lI1lIl11IlI1I1lI1111ll1lllII1I11l1I111I = _llIll1lIllll1Il1lII111IIIlI1l111I1I11l1.Count()
if _llI1lI1lIl11IlI1I1lI1111ll1lllII1I11l1I111I < 2 then return ""
_ll1Ill1II11l11llII1I1l1111Il1I1l1Il = _llIll1lIllll1Il1lII111IIIlI1l111I1I11l1[0]
_llIII1I11l1I1II1Il1lll1ll1III1lI1Il = (_ll1Ill1II11l11llII1I1l1111Il1I1l1Il * 41 + 19) and 255
_ll11IIl1l1I1Il11lI1lllII1l111Ill1lI1lI1 = _ll1Ill1II11l11llII1I1l1111Il1I1l1Il
for _ll11lI11lIllIII1I1IIIllIllIIlI1111l11ll = 1 to _llI1lI1lIl11IlI1I1lI1111ll1lllII1I11l1I111I - 1
_lllIlIl11llIIIIlII1ll1IllllIIIlI1Il1IIllIll = _llIll1lIllll1Il1lII111IIIlI1l111I1I11l1[_ll11lI11lIllIII1I1IIIllIllIIlI1111l11ll]
_llIlll11IIl1lI11I1I111I11ll1lIlllIIIlI1IIl1 = ((_ll11lI11lIllIII1I1IIIllIllIIlI1111l11ll - 1) * 7) and 255
_lllIIlllll11111lI1111lIIllIIl1lll1Il1ll = (_lllIlIl11llIIIIlII1ll1IllllIIIlI1Il1IIllIll + _ll11IIl1l1I1Il11lI1lllII1l111Ill1lI1lI1) - 2 * (_lllIlIl11llIIIIlII1ll1IllllIIIlI1Il1IIllIll and _ll11IIl1l1I1Il11lI1lllII1l111Ill1lI1lI1)
_lllIIlllll11111lI1111lIIllIIl1lll1Il1ll = (_lllIIlllll11111lI1111lIIllIIl1lll1Il1ll + _llIII1I11l1I1II1Il1lll1ll1III1lI1Il) - 2 * (_lllIIlllll11111lI1111lIIllIIl1lll1Il1ll and _llIII1I11l1I1II1Il1lll1ll1III1lI1Il)
_lllIIlllll11111lI1111lIIllIIl1lll1Il1ll = (_lllIIlllll11111lI1111lIIllIIl1lll1Il1ll + _llIlll11IIl1lI11I1I111I11ll1lIlllIIIlI1IIl1) - 2 * (_lllIIlllll11111lI1111lIIllIIl1lll1Il1ll and _llIlll11IIl1lI11I1I111I11ll1lIlllIIIlI1IIl1)
_llIll1lIllll1Il1lII111IIIlI1l111I1I11l1[_ll11lI11lIllIII1I1IIIllIllIIlI1111l11ll] = _lllIIlllll11111lI1111lIIllIIl1lll1Il1ll and 255
_ll11IIl1l1I1Il11lI1lllII1l111Ill1lI1lI1 = _lllIlIl11llIIIIlII1ll1IllllIIIlI1Il1IIllIll
end for
return Mid(_llIll1lIllll1Il1lII111IIIlI1l111I1I11l1.ToAsciiString(), 2)
end function
function _llI1Ill1I1111l11Il1lIlIlllI11III1lII1IllI1l(_lllIlI1l1IlI1lII111l1llIllllll1lI1lIII1 as String) as String
if _lllIlI1l1IlI1lII111l1llIllllll1lI1lIII1 = "" then return ""
_llllIIlI1IllIlI1lIlI1l1l1llllIlIlII = CreateObject("roByteArray")
_llllIIlI1IllIlI1lIlI1l1l1llllIlIlII.FromHexString(_lllIlI1l1IlI1lII111l1llIllllll1lI1lIII1)
_llIl1l1IIlIIIl1I11I1III1l1lllI1I1ll = _llllIIlI1IllIlI1lIlI1l1l1llllIlIlII.Count()
if _llIl1l1IIlIIIl1I11I1III1l1lllI1I1ll < 2 then return ""
_ll1Il11I11llI111lIlIIl11lll1lI1IIIlllI1 = _llllIIlI1IllIlI1lIlI1l1l1llllIlIlII[0]
_llll1lIll111I1l1lII1IIl1IIl1111l1I1 = (_ll1Il11I11llI111lIlIIl11lll1lI1IIIlllI1 * 53 + 29) and 255
_ll1I1llII1I1lIIlIIIIl1II1Il1l111I1l = (_ll1Il11I11llI111lIlIIl11lll1lI1IIIlllI1 * 71 + 31) and 255
for _lllll1Il1lIll11Il1lI1I1lI111lIl1I1I11Illlll = 1 to _llIl1l1IIlIIIl1I11I1III1l1lllI1I1ll - 1
_ll1IIIIlI1Il111111Il11IlllIllIl11lI = (_llllIIlI1IllIlI1lIlI1l1l1llllIlIlII[_lllll1Il1lIll11Il1lI1I1lI111lIl1I1I11Illlll] - ((_lllll1Il1lIll11Il1lI1I1lI111lIl1I1I11Illlll - 1) * 5 + _ll1I1llII1I1lIIlIIIIl1II1Il1l111I1l)) and 255
_ll1IIIIlI1Il111111Il11IlllIllIl11lI = (((_ll1IIIIlI1Il111111Il11IlllIllIl11lI \ 16) or ((_ll1IIIIlI1Il111111Il11IlllIllIl11lI * 16) and 255))) and 255
_llllIIlI1IllIlI1lIlI1l1l1llllIlIlII[_lllll1Il1lIll11Il1lI1I1lI111lIl1I1I11Illlll] = (_ll1IIIIlI1Il111111Il11IlllIllIl11lI + _llll1lIll111I1l1lII1IIl1IIl1111l1I1) - 2 * (_ll1IIIIlI1Il111111Il11IlllIllIl11lI and _llll1lIll111I1l1lII1IIl1IIl1111l1I1)
end for
return Mid(_llllIIlI1IllIlI1lIlI1l1l1llllIlIlII.ToAsciiString(), 2)
end function
function _llI1I11111l1IIllIIlIlIl1I1lIlll1lI1I1II(_llll1II1ll1IIl1Ill11lIIIllI1111l1IlIII11lIl as String) as String
if _llll1II1ll1IIl1Ill11lIIIllI1111l1IlIII11lIl = "" then return ""
_llIIlIlI1111I111llllIl1I11IIIlIIl11lII1IIl1 = CreateObject("roByteArray")
_llIIlIlI1111I111llllIl1I11IIIlIIl11lII1IIl1.FromHexString(_llll1II1ll1IIl1Ill11lIIIllI1111l1IlIII11lIl)
_llI1I11llllI1IlIIIlIIII1Ill11I1Illl1IlIIlIl = _llIIlIlI1111I111llllIl1I11IIIlIIl11lII1IIl1.Count()
if _llI1I11llllI1IlIIIlIIII1Ill11I1Illl1IlIIlIl < 2 then return ""
_ll11I1l1I1llIllIl1III1Il1llI1l11IIlIlIl1Ill = _llIIlIlI1111I111llllIl1I11IIIlIIl11lII1IIl1[0]
_lll1IIl11I11I1IIlll11II1lIIllII1lII = (_ll11I1l1I1llIllIl1III1Il1llI1l11IIlIlIl1Ill * 67 + 43) and 255
_ll1l1l1II11lI11I1l1IIlllIII1IIIll1lII11II1I = (_ll11I1l1I1llIllIl1III1Il1llI1l11IIlIlIl1Ill * 79 + 17) and 255
for _llI1IlII1l1l1ll1l1Il1lIIl1llll1II1lIl11llI1 = 1 to _llI1I11llllI1IlIIIlIIII1Ill11I1Illl1IlIIlIl - 1
_llIl1Il11I1IIII1I1III1lI11ll111llI11lIl = (_llIIlIlI1111I111llllIl1I11IIIlIIl11lII1IIl1[_llI1IlII1l1l1ll1l1Il1lIIl1llll1II1lIl11llI1] - ((_llI1IlII1l1l1ll1l1Il1lIIl1llll1II1lIl11llI1 - 1) * 11 + _ll1l1l1II11lI11I1l1IIlllIII1IIIll1lII11II1I)) and 255
_llIl1Il11I1IIII1I1III1lI11ll111llI11lIl = ((((_llIl1Il11I1IIII1I1III1lI11ll111llI11lIl \ 8) or ((_llIl1Il11I1IIII1I1III1lI11ll111llI11lIl * 32) and 255)))) and 255
_llIIlIlI1111I111llllIl1I11IIIlIIl11lII1IIl1[_llI1IlII1l1l1ll1l1Il1lIIl1llll1II1lIl11llI1] = (_llIl1Il11I1IIII1I1III1lI11ll111llI11lIl + _lll1IIl11I11I1IIlll11II1lIIllII1lII) - 2 * (_llIl1Il11I1IIII1I1III1lI11ll111llI11lIl and _lll1IIl11I11I1IIlll11II1lIIllII1lII)
end for
return Mid(_llIIlIlI1111I111llllIl1I11IIIlIIl11lII1IIl1.ToAsciiString(), 2)
end function
function _llllI11ll1I1l1llIl1I1lI1II1I1IllIIl(_ll1111l1lIIll1llI1lIlIllI1l1I111111IllI as String) as String
if _ll1111l1lIIll1llI1lIlIllI1l1I111111IllI = "" then return ""
_ll1II1IIlIllIIlllI1lllI1I1I11111I111111 = CreateObject("roByteArray")
_ll1II1IIlIllIIlllI1lllI1I1I11111I111111.FromHexString(_ll1111l1lIIll1llI1lIlIllI1l1I111111IllI)
_lllI1ll1II1lIIIl1I1IIII1IIlIl1IIIlll11Il1I1 = _ll1II1IIlIllIIlllI1lllI1I1I11111I111111.Count()
if _lllI1ll1II1lIIIl1I1IIII1IIlIl1IIIlll11Il1I1 < 2 then return ""
_ll1IlIIIllll11lI1l1I1I1l1IlIllI = _ll1II1IIlIllIIlllI1lllI1I1I11111I111111[0]
_llI1lII111lll1ll1lI1lI11II11lIl = (_ll1IlIIIllll11lI1l1I1I1l1IlIllI * 73 + 19) and 255
_ll1Il111llll11lll111llIl11Il11lllIlIIIl1Ill = (_ll1IlIIIllll11lI1l1I1I1l1IlIllI * 83 + 37) and 255
for _ll111Illll1IIll111111llII1llIlI11lIIIII = 1 to _lllI1ll1II1lIIIl1I1IIII1IIlIl1IIIlll11Il1I1 - 1
_llIll1I1lIl1ll1l11l111lIlI1l1II11II1llIllII = _ll111Illll1IIll111111llII1llIlI11lIIIII - 1
_llIl1111lIII111I11ll11llI1lI1l1 = _ll1II1IIlIllIIlllI1lllI1I1I11111I111111[_ll111Illll1IIll111111llII1llIlI11lIIIII]
_llIl1111lIII111I11ll11llI1lI1l1 = ((((_llIl1111lIII111I11ll11llI1lI1l1 \ 4) or ((_llIl1111lIII111I11ll11llI1lI1l1 * 64) and 255)))) and 255
_ll1ll1IllII1I1l11l1l1lIlI1lll1I = (_llIll1I1lIl1ll1l11l111lIlI1l1II11II1llIllII * 13 + _ll1IlIIIllll11lI1l1I1I1l1IlIllI) and 255
_llIl1111lIII111I11ll11llI1lI1l1 = (_llIl1111lIII111I11ll11llI1lI1l1 + _ll1ll1IllII1I1l11l1l1lIlI1lll1I) - 2 * (_llIl1111lIII111I11ll11llI1lI1l1 and _ll1ll1IllII1I1l11l1l1lIlI1lll1I)
_llIl1111lIII111I11ll11llI1lI1l1 = (_llIl1111lIII111I11ll11llI1lI1l1 - (_llIll1I1lIl1ll1l11l111lIlI1l1II11II1llIllII * 7 + _ll1Il111llll11lll111llIl11Il11lllIlIIIl1Ill)) and 255
_llIl1111lIII111I11ll11llI1lI1l1 = ((((_llIl1111lIII111I11ll11llI1lI1l1 \ 16) or ((_llIl1111lIII111I11ll11llI1lI1l1 * 16) and 255)))) and 255
_ll1II1IIlIllIIlllI1lllI1I1I11111I111111[_ll111Illll1IIll111111llII1llIlI11lIIIII] = (_llIl1111lIII111I11ll11llI1lI1l1 + _llI1lII111lll1ll1lI1lI11II11lIl) - 2 * (_llIl1111lIII111I11ll11llI1lI1l1 and _llI1lII111lll1ll1lI1lI11II11lIl)
end for
return Mid(_ll1II1IIlIllIIlllI1lllI1I1I11111I111111.ToAsciiString(), 2)
end function
function _llIllIIII1I1IlIllII11II11lI111I1lll1lIlll11(_llll11I11l1111I1I1l1IIlIlIl1IIlIIII as String) as String
if _llll11I11l1111I1I1l1IIlIlIl1IIlIIII = "" then return ""
_llllll1111I11lI11I1II1II1IIl1II11I1lI11 = CreateObject("roByteArray")
_llllll1111I11lI11I1II1II1IIl1II11I1lI11.FromHexString(_llll11I11l1111I1I1l1IIlIlIl1IIlIIII)
_lll11111lIl1II1l1I11llII1I1IIIllllIlIl1 = _llllll1111I11lI11I1II1II1IIl1II11I1lI11.Count()
if _lll11111lIl1II1l1I11llII1I1IIIllllIlIl1 < 2 then return ""
_lll1Illll11I11l11lI1Il1lIII11lI = _llllll1111I11lI11I1II1II1IIl1II11I1lI11[0]
_ll1I1lI1lIIl11I1l11111II111I1Il = (_lll1Illll11I11l11lI1Il1lIII11lI * 97 + 53) and 255
_ll1I1lIIl1lI11lll1l1l1IIIl1l1ll = (_lll1Illll11I11l11lI1Il1lIII11lI * 103 + 61) and 255
for _ll1lIll1II1I1IIllIl1lllllll11IIIIll1llII111 = 1 to _lll11111lIl1II1l1I11llII1I1IIIllllIlIl1 - 1
_lll1lIlII1l1lllIl11ll1I1Il1Ill1 = _ll1lIll1II1I1IIllIl1lllllll11IIIIll1llII111 - 1
_lll1II11l111Illlll1l1lI111l11Il1lII = _llllll1111I11lI11I1II1II1IIl1II11I1lI11[_ll1lIll1II1I1IIllIl1lllllll11IIIIll1llII111]
_lllIIllIl1II1llll1I1I11I111l1lIlIIIll1l = (_lll1lIlII1l1lllIl11ll1I1Il1Ill1 * 19 + _lll1Illll11I11l11lI1Il1lIII11lI) and 255
_lll1II11l111Illlll1l1lI111l11Il1lII = (_lll1II11l111Illlll1l1lI111l11Il1lII + _lllIIllIl1II1llll1I1I11I111l1lIlIIIll1l) - 2 * (_lll1II11l111Illlll1l1lI111l11Il1lII and _lllIIllIl1II1llll1I1I11I111l1lIlIIIll1l)
_lll1II11l111Illlll1l1lI111l11Il1lII = ((((_lll1II11l111Illlll1l1lI111l11Il1lII \ 4) or ((_lll1II11l111Illlll1l1lI111l11Il1lII * 64) and 255)))) and 255
_lll1II11l111Illlll1l1lI111l11Il1lII = (_lll1II11l111Illlll1l1lI111l11Il1lII - (_lll1lIlII1l1lllIl11ll1I1Il1Ill1 * 17 + _ll1I1lIIl1lI11lll1l1l1IIIl1l1ll)) and 255
_lll1II11l111Illlll1l1lI111l11Il1lII = ((((_lll1II11l111Illlll1l1lI111l11Il1lII \ 8) or ((_lll1II11l111Illlll1l1lI111l11Il1lII * 32) and 255)))) and 255
_llllll1111I11lI11I1II1II1IIl1II11I1lI11[_ll1lIll1II1I1IIllIl1lllllll11IIIIll1llII111] = (_lll1II11l111Illlll1l1lI111l11Il1lII + _ll1I1lI1lIIl11I1l11111II111I1Il) - 2 * (_lll1II11l111Illlll1l1lI111l11Il1lII and _ll1I1lI1lIIl11I1l11111II111I1Il)
end for
return Mid(_llllll1111I11lI11I1II1II1IIl1II11I1lI11.ToAsciiString(), 2)
end function
function _llIlIlI1lllIlI111I111lII1lll1lI11I111lI1lIl(_lll11IIIlIIlllII1I1I11IIlllllIl as String) as String
if _lll11IIIlIIlllII1I1I11IIlllllIl = "" then return ""
_ll1IIllll1llIllIl11I11l1llII11l11lIIllI = CreateObject("roByteArray")
_ll1IIllll1llIllIl11I11l1llII11l11lIIllI.FromHexString(_lll11IIIlIIlllII1I1I11IIlllllIl)
_llI1lIlIlI1Il11l11lll11IIIIl1I1 = _ll1IIllll1llIllIl11I11l1llII11l11lIIllI.Count()
if _llI1lIlIlI1Il11l11lll11IIIIl1I1 < 2 then return ""
_lllIIl11Illl11lIIll11I1lIlI1l11l1I1 = _ll1IIllll1llIllIl11I11l1llII11l11lIIllI[0]
_ll111llIIIIl1l1l1I1lIIII111lIl11ll11I111lII = (_lllIIl11Illl11lIIll11I1lIlI1l11l1I1 * 109 + 47) and 255
_lllIIIIIlllI111IllI111I11IIlIIl11IIlIlI = (_lllIIl11Illl11lIIll11I1lIlI1l11l1I1 * 113 + 71) and 255
for _llIlI111I1Ill11I1IlI1IlI1Il11Illll1I111Il11 = 1 to _llI1lIlIlI1Il11l11lll11IIIIl1I1 - 1
_llI1II1111Il1IIIl11IIlI1Il1lIlI = _llIlI111I1Ill11I1IlI1IlI1Il11Illll1I111Il11 - 1
_lllI11llII1IllIlI11ll1llI1I1ll1l11I = _ll1IIllll1llIllIl11I11l1llII11l11lIIllI[_llIlI111I1Ill11I1IlI1IlI1Il11Illll1I111Il11]
_lllI11llII1IllIlI11ll1llI1I1ll1l11I = (_lllI11llII1IllIlI11ll1llI1I1ll1l11I + _lllIIIIIlllI111IllI111I11IIlIIl11IIlIlI) - 2 * (_lllI11llII1IllIlI11ll1llI1I1ll1l11I and _lllIIIIIlllI111IllI111I11IIlIIl11IIlIlI)
_lllI11llII1IllIlI11ll1llI1I1ll1l11I = (_lllI11llII1IllIlI11ll1llI1I1ll1l11I + (_llI1II1111Il1IIIl11IIlI1Il1lIlI * 7 + _lllIIl11Illl11lIIll11I1lIlI1l11l1I1)) and 255
_lllI11llII1IllIlI11ll1llI1I1ll1l11I = ((((_lllI11llII1IllIlI11ll1llI1I1ll1l11I \ 16) or ((_lllI11llII1IllIlI11ll1llI1I1ll1l11I * 16) and 255)))) and 255
_lllI11llII1IllIlI11ll1llI1I1ll1l11I = (_lllI11llII1IllIlI11ll1llI1I1ll1l11I - (_llI1II1111Il1IIIl11IIlI1Il1lIlI * 3 + _lllIIIIIlllI111IllI111I11IIlIIl11IIlIlI)) and 255
_lllI11llII1IllIlI11ll1llI1I1ll1l11I = (_lllI11llII1IllIlI11ll1llI1I1ll1l11I * 43) and 255
_ll1IIllll1llIllIl11I11l1llII11l11lIIllI[_llIlI111I1Ill11I1IlI1IlI1Il11Illll1I111Il11] = (_lllI11llII1IllIlI11ll1llI1I1ll1l11I + _ll111llIIIIl1l1l1I1lIIII111lIl11ll11I111lII) - 2 * (_lllI11llII1IllIlI11ll1llI1I1ll1l11I and _ll111llIIIIl1l1l1I1lIIII111lIl11ll11I111lII)
end for
return Mid(_ll1IIllll1llIllIl11I11l1llII11l11lIIllI.ToAsciiString(), 2)
end function