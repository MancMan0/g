sub init()
end sub
function onKeyEvent(_lIIll1l as String, _lll1l1l as Boolean) as Boolean
if ((18056 - 2257 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if not _lll1l1l then return false
_l1Ill1l = LCase(_lIIll1l)
if _l1Ill1l = _l1d_8494ee("2121", 41, 197) then
_llIll1l = m.top.numColumns
if _llIll1l <= 0 then _llIll1l = 4
if m.top.itemFocused < _llIll1l then
m.top.goUp = true
return true
end if
end if
return false
end function
function _l1d_8494ee(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function