sub init()
end sub
function onKeyEvent(_llI111lI11I1l11lI11l1lIlll11111lIIlI1II as String, _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII as Boolean) as Boolean
if not _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII then return ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
_llll1I11llIlll11lII11l11111IIIl = LCase(_llI111lI11I1l11lI11l1lIlll11111lIIlI1II)
if _llll1I11llIlll11lII11l11111IIIl = (Chr(117) + Chr(112)) then
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m.top.numColumns
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 <= ((((((43 * 5) + (0 * 3)) - (43 * 5)) \ 3))) then _lllIIlIlII1ll111l1Il11Illlll11l11I1 = ((((((13 * 5) + (4 * 3)) - (13 * 5)) \ 3)))
if m.top.itemFocused < _lllIIlIlII1ll111l1Il11Illlll11l11I1 then
m.top.goUp = (((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49)))
return ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
end if
end if
return ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
end function