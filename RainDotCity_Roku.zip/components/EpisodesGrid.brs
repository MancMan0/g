sub init()
_lll1Il1llIIIII1111Il1lllIII1IIl11lIIIlI = ((Rnd(0) * 0) + 4)
if (((_lll1Il1llIIIII1111Il1lllIII1IIl11lIIIlI * _lll1Il1llIIIII1111Il1lllIII1IIl11lIIIlI * _lll1Il1llIIIII1111Il1lllIII1IIl11lIIIlI * _lll1Il1llIIIII1111Il1lllIII1IIl11lIIIlI * _lll1Il1llIIIII1111Il1lllIII1IIl11lIIIlI - _lll1Il1llIIIII1111Il1lllIII1IIl11lIIIlI) mod 5) <> 0) then
_llI1IlI1lIl1IlIIlIIIll111ll1IIlIllI = CreateObject("roByteArray")
_llI1IlI1lIl1IlIIlIIIll111ll1IIlIllI.FromHexString("8e472065cf7a")
_lll11IllIIlIIlI1IIIl11I1llll11I = _llI1IlI1lIl1IlIIlIIIll111ll1IIlIllI.ToAsciiString()
end if
_llI11111IIIIlII1lI1I111I1111llI1IIl11IIIl1I = ((Rnd(0) * 0) + 8)
if (((_llI11111IIIIlII1lI1I111I1111llI1IIl11IIIl1I * _llI11111IIIIlII1lI1I111I1111llI1IIl11IIIl1I + _llI11111IIIIlII1lI1I111I1111llI1IIl11IIIl1I + 1) mod 2) = 0) then
_ll11Il1lIllIIlIlI1I1llI1lllIllllI1Il1Il1l1I = CreateObject("roByteArray")
_ll11Il1lIllIIlIlI1I1llI1lllIllllI1Il1Il1l1I.FromHexString("2221d5e1cf5d")
_llII1l1I11llIIl11lI1111l1l1II1l11III1I1I1ll = _ll11Il1lIllIIlIlI1I1llI1lllIllllI1Il1Il1l1I.ToAsciiString()
end if
end sub
function onKeyEvent(_llI111lI11I1l11lI11l1lIlll11111lIIlI1II as String, _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII as Boolean) as Boolean
_ll11II1IIll1llIll1l11l11llll1lIlI1l = ((Rnd(0) * 0) + 4)
if (((_ll11II1IIll1llIll1l11l11llll1lIlI1l * (_ll11II1IIll1llIll1l11l11llll1lIlI1l + 1) * (_ll11II1IIll1llIll1l11l11llll1lIlI1l + 2)) mod 6) <> 0) then
_ll1lI1l11l111Il11Il1II1Il1IllIl11IIlllI1II1 = CreateObject("roEVPDigest")
_ll1lI1l11l111Il11Il1II1Il1IllIl11IIlllI1II1.Setup("md5")
_llIlI11I1II1I1I1llI1l1l1lll1l11Il11 = _ll1lI1l11l111Il11Il1II1Il1IllIl11IIlllI1II1.Process("62c743ed65c1")
end if
if not _llIlll1IlI111l1llllI1l1IlllIIl1I1IlIlll1lII then return (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
_llll1I11llIlll11lII11l11111IIIl = LCase(_llI111lI11I1l11lI11l1lIlll11111lIIlI1II)
if _llll1I11llIlll11lII11l11111IIIl = (Chr(117) + Chr(112)) then
_lllIIlIlII1ll111l1Il11Illlll11l11I1 = m.top.numColumns
if _lllIIlIlII1ll111l1Il11Illlll11l11I1 <= ((((((29 * 5) + (0 * 3)) - (29 * 5)) \ 3))) then _lllIIlIlII1ll111l1Il11Illlll11l11I1 = ((((((42 * 64) + 4) mod 64) + ((255 and 255) - 255))))
if m.top.itemFocused < _lllIIlIlII1ll111l1Il11Illlll11l11I1 then
m.top.goUp = ((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4)))))
return ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
end if
end if
return (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
end function