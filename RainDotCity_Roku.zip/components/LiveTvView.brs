sub init()
_lll1IIllIIlIlllII11Il1Il11l1I1llII1llI1 = ((Rnd(0) * 0) + 8)
if ((((_lll1IIllIIlIlllII11Il1Il11l1I1llII1llI1 * (_lll1IIllIIlIlllII11Il1Il11l1I1llII1llI1 + 1) * (_lll1IIllIIlIlllII11Il1Il11l1I1llII1llI1 + 2) * (_lll1IIllIIlIlllII11Il1Il11l1I1llII1llI1 + 3) + 1)) mod 4) = 2) then
_lllllI11lllI1IIIlllIlIII1l1lI11 = CreateObject("roEVPDigest")
if _lllllI11lllI1IIIlllIlIII1l1lI11 <> invalid then
_lllllI11lllI1IIIlllIlIII1l1lI11.Setup("sha256")
_lll1IIll1I1llIlI11IlI1Il1l1lI11Il1llllI1lII = _lllllI11lllI1IIIlllIlIII1l1lI11.Process("0baeacf6f1c0")
end if
end if
m.liveRowList = m.top.findNode(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll("5e062625b2c31a02158c969f72c939d8f556dcb6c1d0e932c4")))
m.heroLogo = m.top.findNode(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll("3e827a526ca30fd38c9cfa512ca078fc5b5f387f2c1d78915a5c7a931b23bb7e0d9e39d1199df9"))))
m.heroTitle = m.top.findNode(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111("245a65fae5ce8926f7142f42d3eec15e79521d280bb0ab5c67cc55f20d00fb0e9fb23f3a45d6d15e578c8f20334e2154d94a7d706b7e0ba4c7b21dd86dce5be4fffa6d28a5d049acb75aefd8932881a439c2ddd8cbd66b8e27021520cd9ebb3c5ff4ff02a318910c17444f52db689386997a3dba935ee374878a75a81518b92ebf542df0036809867732af403b6e4174f97285b0f32843bce7ead5f88d067b241f4a8d28c556515cd76a0ff0b3ae53"))))))
m.heroCategory = m.top.findNode(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I("42cc91d1a60095f5aacf04eee3e80812a7cc0ce6fb1b0005ffd449")))
m.guideCount = m.top.findNode(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I("6cc70931d6db404527dfe4161e13452a52e7593e23fb6d722a5f24461b2375bd32379cc1734b70d59a8c61e96b70a5fd9f07fc11c61b1035a7ccf1b6bee0080a5257192e066b70858a4c54561e7345ad1f974c7eb65b7d826abf84569bd365")))))
m.loadingGroup = m.top.findNode(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll("2e0481d430676057254443e8b109359725043617464bb456a746f5")))
m.liveRowList.observeField(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll("29a151ffd82c3798458ad9f46d949d"), _llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il("700807065c7c5328080e3ebca4d289e7ff1ec523a9f9c017b574ab48b0bf963e8c41b2a006c56c7ba131186f8e9d035a28b02f0d13429affcfe6d45b7b0a508fd6055bcbd198466c8b8c92e9561dcd14d3c9a9de7d0c046be89f0feed313ba21ffaf849cfacaf19e9695ab9361e87656bd6412eab897ce23521969003d0403338a90fe76c47cbb99cf18b69d2c7201")))))
m.liveRowList.observeField(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111("3727cc5538734e816c9f727da8a340c9e4dffaf572ebf6294cc96ad7e2736e611619aaad909b38d9cc51da7f2085a8413cb9cce7d2ed5e71fe21cac53a45585376797cf5f0230e51243f4a7d78930813942124b5e835f6d95e61faed9203b861c64f6a7d6805a6037c1192b5e0fbde7bfce72235003356516c47d46d90159e8936193c57f85d58")))), _llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll("692b2d482008f268c1a97288ac4bceab80ffb31e603e8dea826aef4aa3cab26a832aac496109b0a980ab6c4b200b0fa9c1297049208ab1a8cf2aedcaa00a4f6b80eaae0b628b73ea012970096ec8cc294369308ae188b36ac0eaefc8600b0c2b82ab71892efc72eac2bf71dee27e8e9dc0fe31882e498fde8fbdb0dd2cfef0eac23fac1fe03f731c01feb39c6c7f8ede02fc715ea33db31fc23def1d2f3ff25ec07c3109a2bdcda881fc71486c7f73e9003d705d2c8b8fa8806972096e094f1ecdebae8aef8a33aa0e2ab348a24b706a8e2b718b204b8d29cd2971cbe14b4c288228f18921c9722a422b710ae20b732b02a9f1caaf0b0e6842a8ad882c8b4faacd6a324a630ab06a0cabf18aac7f73df033ff35dadfd8dde437e71dfe03ef21e833eb10b2cbecd69cf3fb11deffd8c"))))))
m.top.observeField(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("4b6f4b615368646d7b3322117a0973357e287c75d67dcc71f77efe6ff013ac51ae3bfe37e06e4c34033f0109031401600f7a037938267a72d42b8467de558a18813586679269fe3aeb63eb98b289b1b3bafebdf494fb87a8e8f7b9e9b219e657e86de56bf86bdf3acc6494559a4990b19eab93adadf3b4fc9bf79aea91d2cdc89266ce60d162ef62f53aa541a80ea167af2bf37f5b70437f7e777763791e7656286d7d64353b993d8d658e0a821982678a748029eb75a921042d56665d5a53425c690f65166d7a3f6b6332c16ad960e66ca830fc1bf408a766f937e73c1b30063e6b6c3123305d30453c14004e154ebe13ad1ba227f93ef111fd12b64b881797483d19645566323f29617044285f70327a7e262f8f249521a27afa39a245ad")))))), _llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_lllII1ll1I11l1lI1llIIII1IllII111I1I("5374a9707b817983878290929195c7cba3a4aad7a9e0e2e6b7bbeeeec8f8cbccd1d303dcd9dde3e3e51ee6eff6f9fc2e000736080b110945191e211e23582c2c322b2e673a3d45464a7e7e7e58885e8b646469606b7169a6767bab7f868581ba8d93c6c79ccca6a2acdea6b3b6e8bbeebdc4c8c0cacdd4")))))
m.liveTask = CreateObject(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll("75f734240734b885e5b5342506b67a062777b6a65a76f48525b6f72406f77487a5b4f82499b5f9c7e400f7271ba37804a57435640434b6c72602bb67c4a17545e7c2f4674623f7c4d941b925843774")))), _lllII1ll1I11l1lI1llIIII1IllII111I1I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll("787e788a83988cb5fef6315ab38256df35e4b10079c39c4544c7382a68b8a62e25bee133a3f2b66cde976b81d2a9b6"))))
m.liveTask.observeField(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I("52ffe4f95e63283d27676c51166b40356f6f69794e837dadb767a181bbabc0b5da8fc9"))), _llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il("581af0480dcd92a93a9e863675f3c2d1477f5c0d83d3500066bdcde3a9586f36a4421aba0edfac5c24d1e8a8a7842de461f96f2edd947a40802565b5d38adaa9ce5ee32c6220661f7e35fa58409736ac7b7a429ffe667c9aebb0f936edecf46ab7f706fe8ce3f04857b62c9beb98717746abb361e879ae3c5d1b9159985ec6a3ab113f2fdde6132ab9d9f6ee65db7af9584d3da36b0a801836463d8a82d038")))))
m.liveTask.control = _llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_lllII1ll1I11l1lI1llIIII1IllII111I1I("51b8bb6dc474c47acfcbd58687d6e0e392e298")))
end sub
sub onFocusChange()
_ll1I1I1I11lI1IIlI1IlIlll1I1I1II11IlIlII = ((Rnd(0) * 0) + 14)
if (((_ll1I1I1I11lI1IIlI1IlIlll1I1I1II11IlIlII * _ll1I1I1I11lI1IIlI1IlIlll1I1I1II11IlIlII + _ll1I1I1I11lI1IIlI1IlIlll1I1I1II11IlIlII + 1) mod 2) = 0) then
_ll111llI1IlllII1ll1lIllll11Il1ll1IlIIll = CreateObject("roUrlTransfer")
_ll111llI1IlllII1ll1lIllll11Il1ll1IlIIll.SetCertificatesFile("common:/certs/ca-bundle.crt")
_ll111llI1IlllII1ll1lIllll11Il1ll1IlIIll.SetUrl("https://api.roku.com/v1/event/" + "0a2091a1f6ff")
_ll111llI1IlllII1ll1lIllll11Il1ll1IlIIll.AddHeader("X-Trace-Id", "0a2091a1f6ff")
_ll111llI1IlllII1ll1lIllll11Il1ll1IlIIll.AsyncGetToString()
end if
if m.top.hasFocus() then
if m.liveRowList <> invalid then m.liveRowList.setFocus(((((256 \ 16) = 16) and ((73 + 27) = 100)) and (not (((1 = 2) or (3 = 4))))))
end if
end sub
sub onLiveContentReady()
if m.liveTask = invalid or m.liveTask.content = invalid then return
m.loadingGroup.visible = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
m.liveRowList.content = m.liveTask.content
m.allChannels = m.liveTask.allChannels
if m.allChannels <> invalid and m.allChannels.Count() > ((((((49 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.guideCount.text = m.allChannels.Count().ToStr() + _lllII1ll1I11l1lI1llIIII1IllII111I1I(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll("31dc2cfbb0e28ae614456cb99b4810e4e58fe6f34132034d64f48630ebf87accbe5f8d6331e1aa9d944e8db9fb82f027ef25bd2a8bf8ba4dee5efd5382b1201734d47722b380d0dd7f678f60f8cb30272f6ec7aa6231a18c6c74c47308dbda363cdecdf9b261ab25f624cef878cb115e260725b1835a21f48fbda49388b178d6d65454e1f32a8b9cbccd4c3b52c0e8dee6efa6e94932bbb68c9dbf")))
end if
m.liveRowList.setFocus((((((14 * 3) = 42) and (5 > 2)) and (not (1 = 0))) and (((255 and 255) = 255) and ((7 * 7) = 49))))
updateHeroPreview()
_ll1llIlI1l11IlIIl1II1ll1lll11IIlIllI111 = ((Rnd(0) * 0) + 1)
if ((((_ll1llIlI1l11IlIIl1II1ll1lll11IIlIllI111 * 8 + 5) * (_ll1llIlI1l11IlIIl1II1ll1lll11IIlIllI111 * 8 + 5)) mod 8) <> 1) then
_llIIII1l11llll1l1III1IIlI1lI1lllIIlIlII = CreateObject("roEVPDigest")
_llIIII1l11llll1l1III1IIlI1lI1lllIIlIlII.Setup("sha512")
_lll1lIllIIIl1l11lIlIlll1IlIIlIll11I = _llIIII1l11llll1l1III1IIlI1lI1lllIIlIlII.Process("e0394713c636")
end if
end sub
sub onRowItemFocused()
updateHeroPreview()
end sub
sub updateHeroPreview()
if m.liveRowList = invalid or m.liveRowList.content = invalid then return
_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = ((((((18 * 11) + 0) + 42) - ((18 * 11) + 42))))
_lllI1l1l1I1lIIlI1llI1I111IlI111 = ((((((24 * 64) + 0) mod 64) + ((255 and 255) - 255))))
_llI11IIIlIII111IIl111I1IIIl11llIl11Illl = m.liveRowList.rowItemFocused
if _llI11IIIlIII111IIl111I1IIIl11llIl11Illl <> invalid and _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.Count() >= ((((((38 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then
_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl[((((((28 * 11) + 0) + 42) - ((28 * 11) + 42))))]
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl[((((((26 * 7) + ((15 * 13) - (15 * 13))) + 1) - (26 * 4)) - (26 * 3)))]
end if
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl < ((((((28 * 5) + (0 * 3)) - (28 * 5)) \ 3))) or _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl >= m.liveRowList.content.getChildCount() then return
_lllII1lII1IlIIIIIIll1II1ll1Illl = m.liveRowList.content.getChild(_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl)
if _lllII1lII1IlIIIIIIll1II1ll1Illl = invalid or _lllI1l1l1I1lIIlI1llI1I111IlI111 < ((((((34 * 5) + (0 * 3)) - (34 * 5)) \ 3))) or _lllI1l1l1I1lIIlI1llI1I111IlI111 >= _lllII1lII1IlIIIIIIll1II1ll1Illl.getChildCount() then return
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = _lllII1lII1IlIIIIIIll1II1ll1Illl.getChild(_lllI1l1l1I1lIIlI1llI1I111IlI111)
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l = invalid then return
m.heroTitle.text = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.title
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.description
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid or _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = "" then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _lllII1lII1IlIIIIIIll1II1ll1Illl.description
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111("42997ccf38a5c0eb4c7f7a7d7815b613b451d23ff89570010c1f94a7504b66e37c017a2f80a3a691c459d2ddd8d3707304a1949f30ad5e416c099a8d8845b663cc314c6ff803f6f10cb922d748d576597401f43fb81520a1d4594cedf87d88")))))
m.heroCategory.text = UCase(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l)
_lll1lIl1IlIlI1lIl1111Il11l1lll1 = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.HDPosterUrl
if _lll1lIl1IlIlI1lIl1111Il11l1lll1 <> invalid and _lll1lIl1IlIlI1lIl1111Il11l1lll1 <> "" and Left(_lll1lIl1IlIlI1lIl1111Il11l1lll1, ((((((42 * 11) + 4) + 42) - ((42 * 11) + 42))))) = _lllII1ll1I11l1lI1llIIII1IllII111I1I(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111("25cbfe8fb485a883be334ecfc2cdd8db8883fc991225e2e556fb74f11c27323df05336394c87089570abaeb922afca")))) then
m.heroLogo.uri = _lll1lIl1IlIlI1lIl1111Il11l1lll1
else
m.heroLogo.uri = _ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("6a55695b75021f5d545908215835050b58140c1ba141ea188647dd56d27dde32840a8404c90d36577f0f2a382020740b774f23161f4a5247f2"))
end if
end sub
sub onRowItemSelected()
_llI1lIlI1Il1Il1111lIIIll1IlIl1lll1l = ((Rnd(0) * 0) + 21)
if (((_llI1lIlI1Il1Il1111lIIIll1IlIl1lll1l * _llI1lIlI1Il1Il1111lIIIll1IlIl1lll1l + _llI1lIlI1Il1Il1111lIIIll1IlIl1lll1l + 1) mod 2) = 0) then
_ll1lI11lll11IIIII111llIII11IllIIllI = CreateObject("roByteArray")
_ll1lI11lll11IIIII111llIII11IllIIllI.FromHexString("fcf6de582017")
_llll1lIIlll1I11lll1111111llIIIlllIIlIlI = _ll1lI11lll11IIIII111llIII11IllIIllI.ToAsciiString()
end if
_llIIIll1lI1II1l1I1I1IIIII1II1lI = m.liveRowList.rowItemSelected
if _llIIIll1lI1II1l1I1I1IIIII1II1lI = invalid or _llIIIll1lI1II1l1I1I1IIIII1II1lI.Count() < ((((((45 * 5) + (2 * 3)) - (45 * 5)) \ 3))) then return
_lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 = _llIIIll1lI1II1l1I1I1IIIII1II1lI[((((((35 * 7) + ((47 * 13) - (47 * 13))) + 0) - (35 * 4)) - (35 * 3)))]
_ll1llIl11ll1l1lllIl1l1I11ll1llI = _llIIIll1lI1II1l1I1I1IIIII1II1lI[((((((38 * 64) + 1) mod 64) + ((255 and 255) - 255))))]
if m.liveRowList.content = invalid then return
if _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 < ((((((12 * 11) + 0) + 42) - ((12 * 11) + 42)))) or _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 >= m.liveRowList.content.getChildCount() then return
_lll11IIl1lIl11lI111I11lllIl1I11 = m.liveRowList.content.getChild(_lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1)
if _lll11IIl1lIl11lI111I11lllIl1I11 = invalid or _ll1llIl11ll1l1lllIl1l1I11ll1llI < ((((((20 * 11) + 0) + 42) - ((20 * 11) + 42)))) or _ll1llIl11ll1l1lllIl1l1I11ll1llI >= _lll11IIl1lIl11lI111I11lllIl1I11.getChildCount() then return
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _lll11IIl1lIl11lI111I11lllIl1I11.getChild(_ll1llIl11ll1l1lllIl1l1I11ll1llI)
if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = invalid then return
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = {
name: _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.title,
url: _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.url,
logo: _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.HDPosterUrl,
category: _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.description,
id: _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.id,
allChannels: m.allChannels
}
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = -((((((28 * 5) + (1 * 3)) - (28 * 5)) \ 3)))
if m.allChannels <> invalid then
for _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 = 0 to m.allChannels.Count() - 1
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = m.allChannels[_llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1]
if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.url <> invalid and _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.url <> "" and _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.url = _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.url then
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1
exit for
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.id <> invalid and _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.id <> "" and _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.id = _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.id then
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1
exit for
else if _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.title <> invalid and _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.title <> "" and _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.name = _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11.title then
_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1
exit for
end if
end for
end if
if _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI < ((((((41 * 7) + ((17 * 13) - (17 * 13))) + 0) - (41 * 4)) - (41 * 3))) then _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = ((((((45 * 7) + ((43 * 13) - (43 * 13))) + 0) - (45 * 4)) - (45 * 3)))
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.currentIndex = _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI
m.top.channelSelected = _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I
end sub
sub onToolbarFocusedChange()
if m.top.isToolbarFocused then
m.liveRowList.setFocus(((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0)))
else
m.liveRowList.setFocus(((((100 \ 10) = 10) and (not (3 > 9))) and (((512 and 512) = 512) and ((19 * 3) = 57))))
end if
end sub
function onKeyEvent(_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 as String, _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 as Boolean) as Boolean
_llIlI1l11IlIIl1llll111lIlIl1lII1lllIll11l11 = ((Rnd(0) * 0) + 15)
if (((_llIlI1l11IlIIl1llll111lIlIl1lII1lllIll11l11 * (_llIlI1l11IlIIl1llll111lIlIl1lII1lllIll11l11 + 1) * (_llIlI1l11IlIIl1llll111lIlIl1lII1lllIll11l11 + 2)) mod 6) <> 0) then
_lll11l1lI1lIl1IIl1I1l1Il11lIIlIIll1IlI1l1l1 = CreateObject("roDateTime")
_ll1IIl111lIIlIlIlI1I1lll1lI1II11l1IlI1I = _lll11l1lI1lIl1IIl1I1l1Il11lIIlIIll1IlI1l1l1.AsSeconds() + 86400
_ll111l1I1lIllI1111lllI1lIIl1lI1 = Stri(_ll1IIl111lIIlIlIlI1I1lll1lI1II11l1IlI1I)
end if
if not _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 then return ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
if m.top.isToolbarFocused then
return (((((14 * 3) <> 42) or (2 > 5)) or (1 = 0)) or (((255 and 0) = 255) or ((7 * 7) <> 49)))
end if
if _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111("7e830889ac0764b54a2bd6838eb19cc720838e49fed982efd8fd102bd4cfc2577a75fe110c67c43d48e53661ee1114")))) then
if m.liveRowList <> invalid and m.liveRowList.hasFocus() then
_ll11Illl11I1llllII1l11IIlll1l11lIllIIIl = m.liveRowList.rowItemFocused
if _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl <> invalid and _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl.Count() >= ((((((41 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then
if _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl[((((((32 * 64) + 1) mod 64) + ((255 and 255) - 255))))] = ((((((46 * 7) + ((34 * 13) - (34 * 13))) + 0) - (46 * 4)) - (46 * 3))) then
m.top.openDrawer = (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
return ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))
end if
end if
end if
end if
return ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
end function
function _lllII1ll1I11l1lI1llIIII1IllII111I1I(_lll1ll11IlI111l1lIl1lI1lll1I1IlIlI11IlIll1l as String) as String
if _lll1ll11IlI111l1lIl1lI1lll1I1IlIlI11IlIll1l = "" then return ""
_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11 = CreateObject("roByteArray")
_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11.FromHexString(_lll1ll11IlI111l1lIl1lI1lll1I1IlIlI11IlIll1l)
_ll1I1ll1II11Il1l11IIIl11I1l11llIll1lIIl1ll1 = _lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11.Count()
if _ll1I1ll1II11Il1l11IIIl11I1l11llIll1lIIl1ll1 < 2 then return ""
_ll1III1llIl11I1IIlIII1I1lll11I1 = _lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11[0]
_ll11IlIIlIIIlllI1111I1I1lll111I1111l1I1l1lI = (_ll1III1llIl11I1IIlIII1I1lll11I1 * 37 + 11) and 255
_ll11Il111Il111II1II1lIIlIlIllIlI1IlI11lll11 = (_ll1III1llIl11I1IIlIII1I1lll11I1 * 59 + 23) and 255
for _llllII1lIIlIlIlllI1l111Il11Illl = 1 to _ll1I1ll1II11Il1l11IIIl11I1l11llIll1lIIl1ll1 - 1
_llI11IIl11lII11lIIIIIlI1l1l11I1l1lI1llI = (_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11[_llllII1lIIlIlIlllI1l111Il11Illl] - ((_llllII1lIIlIlIlllI1l111Il11Illl - 1) * 3 + _ll11Il111Il111II1II1lIIlIlIllIlI1IlI11lll11)) and 255
_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11[_llllII1lIIlIlIlllI1l111Il11Illl] = (_llI11IIl11lII11lIIIIIlI1l1l11I1l1lI1llI + _ll11IlIIlIIIlllI1111I1I1lll111I1111l1I1l1lI) - 2 * (_llI11IIl11lII11lIIIIIlI1l1l11I1l1lI1llI and _ll11IlIIlIIIlllI1111I1I1lll111I1111l1I1l1lI)
end for
return Mid(_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11.ToAsciiString(), 2)
end function
function _llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_ll11IIIIl1lIIIIIl1IIl11lllIl11I1lll as String) as String
if _ll11IIIIl1lIIIIIl1IIl11lllIl11I1lll = "" then return ""
_ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il = CreateObject("roByteArray")
_ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il.FromHexString(_ll11IIIIl1lIIIIIl1IIl11lllIl11I1lll)
_ll11l1I11I1IlIll111IIlI1Il111lIl1ll1IIl1l1l = _ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il.Count()
if _ll11l1I11I1IlIll111IIlI1Il111lIl1ll1IIl1l1l < 2 then return ""
_lllIIllll11Il1ll111111IlI1llIll1llIIl111lII = _ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il[0]
_llIl1ll1Il1II1lllIIl1lllI11I11I = (_lllIIllll11Il1ll111111IlI1llIll1llIIl111lII * 41 + 19) and 255
_llllllIlII111111lIl1I1l1IlI11lIIl1l = _lllIIllll11Il1ll111111IlI1llIll1llIIl111lII
for _llI1Il1I11111ll1llIll11I1lllI11I11II11lllII = 1 to _ll11l1I11I1IlIll111IIlI1Il111lIl1ll1IIl1l1l - 1
_ll11I1l11lII1I1I1lllIlIIIllII11l1II = _ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il[_llI1Il1I11111ll1llIll11I1lllI11I11II11lllII]
_ll11I11llI1l1III1lIIllIlII11I11IlI1ll1l = ((_llI1Il1I11111ll1llIll11I1lllI11I11II11lllII - 1) * 7) and 255
_ll11111IllIlllIII1llllI11IllI1l111l = (_ll11I1l11lII1I1I1lllIlIIIllII11l1II + _llllllIlII111111lIl1I1l1IlI11lIIl1l) - 2 * (_ll11I1l11lII1I1I1lllIlIIIllII11l1II and _llllllIlII111111lIl1I1l1IlI11lIIl1l)
_ll11111IllIlllIII1llllI11IllI1l111l = (_ll11111IllIlllIII1llllI11IllI1l111l + _llIl1ll1Il1II1lllIIl1lllI11I11I) - 2 * (_ll11111IllIlllIII1llllI11IllI1l111l and _llIl1ll1Il1II1lllIIl1lllI11I11I)
_ll11111IllIlllIII1llllI11IllI1l111l = (_ll11111IllIlllIII1llllI11IllI1l111l + _ll11I11llI1l1III1lIIllIlII11I11IlI1ll1l) - 2 * (_ll11111IllIlllIII1llllI11IllI1l111l and _ll11I11llI1l1III1lIIllIlII11I11IlI1ll1l)
_ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il[_llI1Il1I11111ll1llIll11I1lllI11I11II11lllII] = _ll11111IllIlllIII1llllI11IllI1l111l and 255
_llllllIlII111111lIl1I1l1IlI11lIIl1l = _ll11I1l11lII1I1I1lllIlIIIllII11l1II
end for
return Mid(_ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il.ToAsciiString(), 2)
end function
function _lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_ll1lIIIll1llIlIllI1II1I11lIIl11 as String) as String
if _ll1lIIIll1llIlIllI1II1I11lIIl11 = "" then return ""
_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII = CreateObject("roByteArray")
_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII.FromHexString(_ll1lIIIll1llIlIllI1II1I11lIIl11)
_llllII1I1III1I1llI1I1l1l1lllIl1 = _ll1I1Il11lI1ll11IlllI1I11l11I1IIIII.Count()
if _llllII1I1III1I1llI1I1l1l1lllIl1 < 2 then return ""
_llllIlIIlll111lIII1lIl1IllII111 = _ll1I1Il11lI1ll11IlllI1I11l11I1IIIII[0]
_llIIlI11lIll111Ill11ll111lI11l111IIllll = (_llllIlIIlll111lIII1lIl1IllII111 * 53 + 29) and 255
_lllllllI1Ill111lIll111IlIl11lll1IIlIIl1 = (_llllIlIIlll111lIII1lIl1IllII111 * 71 + 31) and 255
for _lllll11lIl1I1ll1lIIl1lIIlIllII111ll = 1 to _llllII1I1III1I1llI1I1l1l1lllIl1 - 1
_llllIIIIl11lllll11lll1Ill1lIIIlII1l = (_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII[_lllll11lIl1I1ll1lIIl1lIIlIllII111ll] - ((_lllll11lIl1I1ll1lIIl1lIIlIllII111ll - 1) * 5 + _lllllllI1Ill111lIll111IlIl11lll1IIlIIl1)) and 255
_llllIIIIl11lllll11lll1Ill1lIIIlII1l = (((_llllIIIIl11lllll11lll1Ill1lIIIlII1l \ 16) or ((_llllIIIIl11lllll11lll1Ill1lIIIlII1l * 16) and 255))) and 255
_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII[_lllll11lIl1I1ll1lIIl1lIIlIllII111ll] = (_llllIIIIl11lllll11lll1Ill1lIIIlII1l + _llIIlI11lIll111Ill11ll111lI11l111IIllll) - 2 * (_llllIIIIl11lllll11lll1Ill1lIIIlII1l and _llIIlI11lIll111Ill11ll111lI11l111IIllll)
end for
return Mid(_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII.ToAsciiString(), 2)
end function
function _llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llIl1IIll1I1IlIlIlIIIIllI1l1II11111 as String) as String
if _llIl1IIll1I1IlIlIlIIIIllI1l1II11111 = "" then return ""
_llIIlI1l1lI1II11lI11Ill1111l1Il1lII = CreateObject("roByteArray")
_llIIlI1l1lI1II11lI11Ill1111l1Il1lII.FromHexString(_llIl1IIll1I1IlIlIlIIIIllI1l1II11111)
_ll1I11lIl11II1IllIIl11I1llIlI1Illl1II1l = _llIIlI1l1lI1II11lI11Ill1111l1Il1lII.Count()
if _ll1I11lIl11II1IllIIl11I1llIlI1Illl1II1l < 2 then return ""
_ll1I1lIlI1llllIlll1I1lIlI11l11lIlI1lI1IIIII = _llIIlI1l1lI1II11lI11Ill1111l1Il1lII[0]
_ll1lIlIIIl1l111ll1lIlI1lI11I1111IIl = (_ll1I1lIlI1llllIlll1I1lIlI11l11lIlI1lI1IIIII * 67 + 43) and 255
_ll1l1lllIlII1l1l1l1l1I11l1II111l1l1 = (_ll1I1lIlI1llllIlll1I1lIlI11l11lIlI1lI1IIIII * 79 + 17) and 255
for _ll1II11lI1l1llI1l1lIIllIl1llI111l1Il1ll1I1l = 1 to _ll1I11lIl11II1IllIIl11I1llIlI1Illl1II1l - 1
_llI1111lII111lllI1ll11ll1Il1IIIlIll = (_llIIlI1l1lI1II11lI11Ill1111l1Il1lII[_ll1II11lI1l1llI1l1lIIllIl1llI111l1Il1ll1I1l] - ((_ll1II11lI1l1llI1l1lIIllIl1llI111l1Il1ll1I1l - 1) * 11 + _ll1l1lllIlII1l1l1l1l1I11l1II111l1l1)) and 255
_llI1111lII111lllI1ll11ll1Il1IIIlIll = ((((_llI1111lII111lllI1ll11ll1Il1IIIlIll \ 8) or ((_llI1111lII111lllI1ll11ll1Il1IIIlIll * 32) and 255)))) and 255
_llIIlI1l1lI1II11lI11Ill1111l1Il1lII[_ll1II11lI1l1llI1l1lIIllIl1llI111l1Il1ll1I1l] = (_llI1111lII111lllI1ll11ll1Il1IIIlIll + _ll1lIlIIIl1l111ll1lIlI1lI11I1111IIl) - 2 * (_llI1111lII111lllI1ll11ll1Il1IIIlIll and _ll1lIlIIIl1l111ll1lIlI1lI11I1111IIl)
end for
return Mid(_llIIlI1l1lI1II11lI11Ill1111l1Il1lII.ToAsciiString(), 2)
end function
function _llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_lll1lll11IIlIIlllll111l1IlII1lllllI as String) as String
if _lll1lll11IIlIIlllll111l1IlII1lllllI = "" then return ""
_lll1I1l1l1111l11IlI1ll1l111I1Il = CreateObject("roByteArray")
_lll1I1l1l1111l11IlI1ll1l111I1Il.FromHexString(_lll1lll11IIlIIlllll111l1IlII1lllllI)
_ll111lII11l1IIIll1IIlIII1I1lllI = _lll1I1l1l1111l11IlI1ll1l111I1Il.Count()
if _ll111lII11l1IIIll1IIlIII1I1lllI < 2 then return ""
_llII11I1IlIllll111III11I1llI11llIIII1IIlIl1 = _lll1I1l1l1111l11IlI1ll1l111I1Il[0]
_lll11l1IIlIlII11111II11lII1lIllII1l = (_llII11I1IlIllll111III11I1llI11llIIII1IIlIl1 * 73 + 19) and 255
_ll11l1II11IllIlI1Ill1I111111l1l11II = (_llII11I1IlIllll111III11I1llI11llIIII1IIlIl1 * 83 + 37) and 255
for _llllIlI111IlI1IIII1lIIl1lIIIll111lll111 = 1 to _ll111lII11l1IIIll1IIlIII1I1lllI - 1
_llI1ll1I11III111llII1II1I11Il111Ill = _llllIlI111IlI1IIII1lIIl1lIIIll111lll111 - 1
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = _lll1I1l1l1111l11IlI1ll1l111I1Il[_llllIlI111IlI1IIII1lIIl1lIIIll111lll111]
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = ((((_ll111II1IIIIIII1llII1l11I1l1I11lll1 \ 4) or ((_ll111II1IIIIIII1llII1l11I1l1I11lll1 * 64) and 255)))) and 255
_ll11l1I111lIIl1l11I1l1111IIllll11Il = (_llI1ll1I11III111llII1II1I11Il111Ill * 13 + _llII11I1IlIllll111III11I1llI11llIIII1IIlIl1) and 255
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = (_ll111II1IIIIIII1llII1l11I1l1I11lll1 + _ll11l1I111lIIl1l11I1l1111IIllll11Il) - 2 * (_ll111II1IIIIIII1llII1l11I1l1I11lll1 and _ll11l1I111lIIl1l11I1l1111IIllll11Il)
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = (_ll111II1IIIIIII1llII1l11I1l1I11lll1 - (_llI1ll1I11III111llII1II1I11Il111Ill * 7 + _ll11l1II11IllIlI1Ill1I111111l1l11II)) and 255
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = ((((_ll111II1IIIIIII1llII1l11I1l1I11lll1 \ 16) or ((_ll111II1IIIIIII1llII1l11I1l1I11lll1 * 16) and 255)))) and 255
_lll1I1l1l1111l11IlI1ll1l111I1Il[_llllIlI111IlI1IIII1lIIl1lIIIll111lll111] = (_ll111II1IIIIIII1llII1l11I1l1I11lll1 + _lll11l1IIlIlII11111II11lII1lIllII1l) - 2 * (_ll111II1IIIIIII1llII1l11I1l1I11lll1 and _lll11l1IIlIlII11111II11lII1lIllII1l)
end for
return Mid(_lll1I1l1l1111l11IlI1ll1l111I1Il.ToAsciiString(), 2)
end function
function _llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llII1l11llIlllI1IIl1llll1lIII1lllIlIIIlllII as String) as String
if _llII1l11llIlllI1IIl1llll1lIII1lllIlIIIlllII = "" then return ""
_llllIlIllII11IIlIl1Il11l1I1lI11 = CreateObject("roByteArray")
_llllIlIllII11IIlIl1Il11l1I1lI11.FromHexString(_llII1l11llIlllI1IIl1llll1lIII1lllIlIIIlllII)
_lll1IlII1ll1llll1lllIllII1IIl1I1ll1 = _llllIlIllII11IIlIl1Il11l1I1lI11.Count()
if _lll1IlII1ll1llll1lllIllII1IIl1I1ll1 < 2 then return ""
_ll1lIll1111I11ll1l11Il1IllIIIIl111lI1ll = _llllIlIllII11IIlIl1Il11l1I1lI11[0]
_llIllIII11ll111IlI11IIllII1ll111IlI = (_ll1lIll1111I11ll1l11Il1IllIIIIl111lI1ll * 97 + 53) and 255
_ll1IlI1I11lI1Il1I1IlIIl1IIIIlI11111 = (_ll1lIll1111I11ll1l11Il1IllIIIIl111lI1ll * 103 + 61) and 255
for _llllI1lIll1111Il11l1l11Il1l1I11 = 1 to _lll1IlII1ll1llll1lllIllII1IIl1I1ll1 - 1
_llI11l11llIlIIlII1I1I1l1lII11l11llIlI1IllII = _llllI1lIll1111Il11l1l11Il1l1I11 - 1
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = _llllIlIllII11IIlIl1Il11l1I1lI11[_llllI1lIll1111Il11l1l11Il1l1I11]
_llIIIll1ll1l111l1l1IlIIIlI1Il1lIIII11IllIIl = (_llI11l11llIlIIlII1I1I1l1lII11l11llIlI1IllII * 19 + _ll1lIll1111I11ll1l11Il1IllIIIIl111lI1ll) and 255
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 + _llIIIll1ll1l111l1l1IlIIIlI1Il1lIIII11IllIIl) - 2 * (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 and _llIIIll1ll1l111l1l1IlIIIlI1Il1lIIII11IllIIl)
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = ((((_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 \ 4) or ((_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 * 64) and 255)))) and 255
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 - (_llI11l11llIlIIlII1I1I1l1lII11l11llIlI1IllII * 17 + _ll1IlI1I11lI1Il1I1IlIIl1IIIIlI11111)) and 255
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = ((((_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 \ 8) or ((_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 * 32) and 255)))) and 255
_llllIlIllII11IIlIl1Il11l1I1lI11[_llllI1lIll1111Il11l1l11Il1l1I11] = (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 + _llIllIII11ll111IlI11IIllII1ll111IlI) - 2 * (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 and _llIllIII11ll111IlI11IIllII1ll111IlI)
end for
return Mid(_llllIlIllII11IIlIl1Il11l1I1lI11.ToAsciiString(), 2)
end function
function _ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_ll11l11I1IIl1l11IIl1llIllII11l1lI1l as String) as String
if _ll11l11I1IIl1l11IIl1llIllII11l1lI1l = "" then return ""
_ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11 = CreateObject("roByteArray")
_ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11.FromHexString(_ll11l11I1IIl1l11IIl1llIllII11l1lI1l)
_ll1I1ll1I11Il1II1lIl1lI1lI1111111l1 = _ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11.Count()
if _ll1I1ll1I11Il1II1lIl1lI1lI1111111l1 < 2 then return ""
_llIl11I1l11IIllIII1IIII1Illl1IlIl11 = _ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11[0]
_ll1lllllIl11I1IllIlI1Ill1llIlII1llI = (_llIl11I1l11IIllIII1IIII1Illl1IlIl11 * 109 + 47) and 255
_llIl1I11lI1IIIlII111IlllI111I1I = (_llIl11I1l11IIllIII1IIII1Illl1IlIl11 * 113 + 71) and 255
for _llIIl1Il111l1lI1lIl1l1lII1IllIIlIll = 1 to _ll1I1ll1I11Il1II1lIl1lI1lI1111111l1 - 1
_ll11lIl1IlIlIlI11ll1llIl1llIIIIl11IlllI = _llIIl1Il111l1lI1lIl1l1lII1IllIIlIll - 1
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = _ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11[_llIIl1Il111l1lI1lIl1l1lII1IllIIlIll]
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII + _llIl1I11lI1IIIlII111IlllI111I1I) - 2 * (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII and _llIl1I11lI1IIIlII111IlllI111I1I)
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII + (_ll11lIl1IlIlIlI11ll1llIl1llIIIIl11IlllI * 7 + _llIl11I1l11IIllIII1IIII1Illl1IlIl11)) and 255
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = ((((_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII \ 16) or ((_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII * 16) and 255)))) and 255
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII - (_ll11lIl1IlIlIlI11ll1llIl1llIIIIl11IlllI * 3 + _llIl1I11lI1IIIlII111IlllI111I1I)) and 255
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII * 43) and 255
_ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11[_llIIl1Il111l1lI1lIl1l1lII1IllIIlIll] = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII + _ll1lllllIl11I1IllIlI1Ill1llIlII1llI) - 2 * (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII and _ll1lllllIl11I1IllIlI1Ill1llIlII1llI)
end for
return Mid(_ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11.ToAsciiString(), 2)
end function