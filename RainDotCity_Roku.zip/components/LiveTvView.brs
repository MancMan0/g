sub init()
m.headerGroup = m.top.findNode(_l1d_6d53b9("a1a9b0aeb2ca9ad0b8d1d7", 12, 61))
m.headerStats = m.top.findNode(_l1d_6d53b9("1d151c1a1e1236162e1c22", 118, 255))
m.clockLabel = m.top.findNode(_l1d_6d53b9("daecece3ee18eef0f804", 51, 138))
m.btnSettings = m.top.findNode(_l1d_6d53b9("91828b699a8e919f9da79e", 31, 20))
m.btnSwitchPortal = m.top.findNode(_l1d_6d53b9("f00902ea110a180612fd1b212a1a28", 130, 16))
m.guideContainer = m.top.findNode(_l1d_6d53b9("8ea38a989c79989ab7a7a2a6b4c0", 202, 225))
m.groupList = m.top.findNode(_l1d_6d53b9("96a6a4b1b190aeb7c1", 131, 178))
m.channelList = m.top.findNode(_l1d_6d53b9("7c8a849295919d809ea7b1", 131, 156))
m.previewColumn = m.top.findNode(_l1d_6d53b9("4d52605472695e957c7c688387", 180, 137))
m.liveVideo = m.top.findNode(_l1d_6d53b9("b6bcc2b6e8c8c0c2cb", 103, 171))
m.videoBuffering = m.top.findNode(_l1d_6d53b9("acb6c4c8c1a7c1d1d4dac6d4d8e4", 26, 64))
m.bufferingText = m.top.findNode(_l1d_6d53b9("a591a7aaaaa4acaeb8cabcacb3", 189, 198))
m.chLogo = m.top.findNode(_l1d_6d53b9("ced6fde3dee9", 48, 123))
m.chName = m.top.findNode(_l1d_6d53b9("081633131a15", 103, 4))
m.chGroup = m.top.findNode(_l1d_6d53b9("d2e0fceceaf7f7", 163, 18))
m.chFormat = m.top.findNode(_l1d_6d53b9("a1ad82aebcb6b5c3", 70, 124))
m.btnFullscreen = m.top.findNode(_l1d_6d53b9("e5fae71202eef109fc10040705", 169, 26))
m.btnToggleFav = m.top.findNode(_l1d_6d53b9("afa0a986aeb9bcbac4a6cebc", 95, 114))
m.btnReload = m.top.findNode(_l1d_6d53b9("8c859ea59da9a9a2aa", 115, 123))
m.osdBanner = m.top.findNode(_l1d_6d53b9("837282678d91949286", 22, 10))
m.osdLogo = m.top.findNode(_l1d_6d53b9("3837431e444f4a", 28, 197))
m.osdNumber = m.top.findNode(_l1d_6d53b9("6c8b7d56927d8b8ba1", 15, 12))
m.osdName = m.top.findNode(_l1d_6d53b9("6180724b7b727d", 207, 193))
m.osdFav = m.top.findNode(_l1d_6d53b9("9fa6a081a1b7", 3, 51))
m.osdGroup = m.top.findNode(_l1d_6d53b9("50675d41715f7878", 137, 106))
m.osdClock = m.top.findNode(_l1d_6d53b9("0bf20a28181a111c", 114, 238))
m.playlistModal = m.top.findNode(_l1d_6d53b9("dcd3d1ecdce2ebedc7e8e6ecf4", 199, 37))
m.urlKeyboard = m.top.findNode(_l1d_6d53b9("a8aea78ba4c3adb3b4c6b7", 7, 54))
m.activeUrlLabel = m.top.findNode(_l1d_6d53b9("32334333473d30543d205050524c", 206, 131))
m.btnSavePlaylist = m.top.findNode(_l1d_6d53b9("70817a687d8b7f778e8ca7979da6a8", 199, 203))
m.btnDefaultPlaylist = m.top.findNode(_l1d_6d53b9("b9aac3e0c2c4ccbbd7c2e9e0ded9e9efd8da", 55, 100))
m.btnCancelPlaylist = m.top.findNode(_l1d_6d53b9("b4cdb69cc1bfc5cecac1d0d6e1d9d7f0fa", 11, 75))
m.loadingOverlay = m.top.findNode(_l1d_6d53b9("ced4c9cfd7dfdbc6d0e2d2efe7e2", 144, 210))
m.tvToast = m.top.findNode(_l1d_6d53b9("e8edcefa07fcfa", 221, 63))
m.tvToastText = m.top.findNode(_l1d_6d53b9("b0b196c0c9bac2a5d9bfce", 90, 130))
m.isFullscreen = false
m.parsedData = invalid
m.activeChannels = []
m.currentChannel = invalid
m.currentChannelIdx = 0
m.currentGroupIdx = 0
m.clockTimer = CreateObject(_l1d_6d53b9("0119283741252125", 182, 61), _l1d_6d53b9("657d847f8b", 2, 15))
m.clockTimer.duration = 5
m.clockTimer.repeat = true
m.clockTimer.observeField(_l1d_6d53b9("e3dbd5ed", 251, 70), _l1d_6d53b9("acaeceb2b8b7c2c6c6c3ce", 244, 17))
m.clockTimer.control = _l1d_6d53b9("2d2d453536", 222, 128)
updateClock()
m.osdTimer = CreateObject(_l1d_6d53b9("a5ad8c9b95b9c1c5", 28, 55), _l1d_6d53b9("241a211c0e", 49, 191))
m.osdTimer.duration = 4.0
m.osdTimer.repeat = false
m.osdTimer.observeField(_l1d_6d53b9("46584052", 22, 214), _l1d_6d53b9("0204fcfeeb1a08f1111b1e1630", 133, 21))
m.previewTimer = CreateObject(_l1d_6d53b9("fdf524131d01fd01", 166, 41), _l1d_6d53b9("b0c6cdc8da", 129, 219))
m.previewTimer.duration = 0.45
m.previewTimer.repeat = false
m.previewTimer.observeField(_l1d_6d53b9("a59d97af", 187, 200), _l1d_6d53b9("9599d6bba7bda9b0c5e7b5b4bfd9e8c4e2ce", 45, 83))
m.groupList.observeField(_l1d_6d53b9("343c2e39133d3c4d524347", 135, 70), _l1d_6d53b9("020630080e0b13401a291a1f3034", 191, 50))
m.groupList.observeField(_l1d_6d53b9("b2baacb7e8b5c1bbc4d2c4c8", 165, 230), _l1d_6d53b9("f9fdd7ef05f2fada0b171116081a1e", 151, 1))
m.channelList.observeField(_l1d_6d53b9("d1c9dbd6c4deeddae3f0f4", 29, 93), _l1d_6d53b9("dfe101ede9edf0eef811fdfc0d120305", 166, 22))
m.channelList.observeField(_l1d_6d53b9("1c3226215e2f29353a4a3e40", 46, 213), _l1d_6d53b9("dbdfcde7f1ebeef6f2d2fffb050efc0e12", 221, 41))
m.btnSettings.observeField(_l1d_6d53b9("a1b5b9bcb8bca2b7c3bdbed4c6ca", 129, 190), _l1d_6d53b9("919577a997a18fa0b4b7b5b3adc4", 135, 169))
m.btnSwitchPortal.observeField(_l1d_6d53b9("ddd5d9dcf4f8bef703fdfaf4060a", 211, 44), _l1d_6d53b9("51534b725b7967635e6c828b7b796f88828e8ba39799", 138, 108))
m.btnFullscreen.observeField(_l1d_6d53b9("576b6f725e62986d6973748a7c80", 233, 204), _l1d_6d53b9("dadef6e4cddfd908d8f4f7e7faeefafd0b", 245, 64))
m.btnToggleFav.observeField(_l1d_6d53b9("acbabcbfadafefbcb6c2cbd7cbcd", 44, 94), _l1d_6d53b9("3436433d383b4743634d397159615a655e60", 182, 91))
m.btnReload.observeField(_l1d_6d53b9("ebdfe3e6f2f6cc01fd0708fe1014", 153, 240), _l1d_6d53b9("f9fdccf804080505ed13191621161a", 85, 191))
m.btnSavePlaylist.observeField(_l1d_6d53b9("b6acaeb1cfd1d9ced8d4d5c9dddf", 240, 36), _l1d_6d53b9("787c62778d81719086a19997a0aa76a8a69faaabaf", 3, 12))
m.btnDefaultPlaylist.observeField(_l1d_6d53b9("827276798185a394909a9f91a3a7", 127, 101), _l1d_6d53b9("a0a2bfa3a3a59cb6a1c0bfb7b2c8c8b1b9e7d7d7d0dbdcde", 178, 195))
m.btnCancelPlaylist.observeField(_l1d_6d53b9("12080a0d2b2d352a34303125393b", 176, 64), _l1d_6d53b9("abaf85aab8aeb7c3aac9bfdad2d0d9e3afe1dfd8e3e4e8", 67, 127))
m.liveVideo.observeField(_l1d_6d53b9("e7eddbf3e5", 41, 141), _l1d_6d53b9("c1c3deccd2d6d3f2cee6d4e8", 124, 174))
m.top.observeField(_l1d_6d53b9("252f261f1c3539", 51, 208), _l1d_6d53b9("cacce7d9e0d103dfeedfe4", 190, 249))
loadM3uPlaylist(M3U_GetSavedUrl())
end sub
sub onViewFocus()
if m.top.hasFocus() then
if m.playlistModal <> invalid and m.playlistModal.visible then
if m.urlKeyboard <> invalid then m.urlKeyboard.setFocus(true)
else if m.isFullscreen then
if m.liveVideo <> invalid then m.liveVideo.setFocus(true)
else
if m.channelList <> invalid and m.channelList.content <> invalid then
m.channelList.setFocus(true)
else if m.groupList <> invalid then
m.groupList.setFocus(true)
end if
end if
end if
end sub
sub updateClock()
if ((56892 - 9482 * 6) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
_l11I11l = CreateObject(_l1d_6d53b9("5c4c78586e62945c636e", 170, 132))
_l11I11l.ToLocalTime()
_lI1I11l = _l11I11l.GetHours()
_l1II11l = _l11I11l.GetMinutes()
_llII11l = Box(_lI1I11l).ToStr()
if _lI1I11l < 10 then _llII11l = _l1d_6d53b9("29", 67, 182) + _llII11l
_lIII11l = Box(_l1II11l).ToStr()
if _l1II11l < 10 then _lIII11l = _l1d_6d53b9("dc", 1, 171) + _lIII11l
_llllI1l = _llII11l + _l1d_6d53b9("c8", 118, 124) + _lIII11l
if m.clockLabel <> invalid then m.clockLabel.text = _llllI1l
if m.osdClock <> invalid then m.osdClock.text = _llllI1l
end sub
sub onClockTick()
if ((11802 - 3934 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
updateClock()
end sub
sub loadM3uPlaylist(_llllIIl as String)
if m.liveVideo <> invalid then m.liveVideo.control = _l1d_6d53b9("5f5d7967", 213, 185)
m.loadingOverlay.visible = true
if m.headerStats <> invalid then m.headerStats.text = _l1d_6d53b9("1bfdfefc0c0804cc34c122d82b22221d2b331c1cf3f0f965413e424054504c16191c", 54, 161)
if m.m3uTask <> invalid then m.m3uTask.control = _l1d_6d53b9("50565258", 33, 222)
m.m3uTask = CreateObject(_l1d_6d53b9("706e554c587a7476", 129, 125), _l1d_6d53b9("ef18ddffcfe4df", 224, 66))
m.m3uTask.playlistUrl = _llllIIl
m.m3uTask.observeField(_l1d_6d53b9("45534c49534e", 188, 119), _l1d_6d53b9("3c3e20894e284e43494d4f", 64, 13))
m.m3uTask.control = _l1d_6d53b9("767a78", 193, 227)
end sub
sub onM3uLoaded()
m.loadingOverlay.visible = false
_l1lIll1 = m.m3uTask.result
if _l1lIll1 = invalid or _l1lIll1.groups = invalid or _l1lIll1.groups.Count() = 0 then
showToast(_l1d_6d53b9("93878a8290dbc8a893a1a0b0daa0aee3cfabb6b0b6beb4fbe310f107fad1d1ecdae2ebeb", 230, 240))
return
end if
m.parsedData = _l1lIll1
_lIlIll1 = _l1lIll1.allChannels.Count()
if m.headerStats <> invalid then
m.headerStats.text = _l1d_6d53b9("6e4f475f4b619f727169647a7a636bb0bd", 114, 59) + Box(_lIlIll1).ToStr() + _l1d_6d53b9("acdbf90bfbbbdf09031518101c24d6f8321e2931272d3a34", 1, 139)
end if
_lII1ll1 = CreateObject(_l1d_6d53b9("e301c8dfeb0d0709", 17, 128), _l1d_6d53b9("eedde1eadceaf310f2ecee", 33, 140))
for each _l1I1ll1 in _l1lIll1.groups
_lllIll1 = _lII1ll1.CreateChild(_l1d_6d53b9("ed0c10291b1932ff212b2d", 201, 99))
_lllIll1.title = _l1I1ll1
end for
m.groupList.content = _lII1ll1
m.currentGroupIdx = 0
m.groupList.jumpToItem = 0
selectGroupByIndex(0)
if m.channelList.content <> invalid and m.channelList.content.getChildCount() > 0 then
m.channelList.setFocus(true)
else
m.groupList.setFocus(true)
end if
end sub
sub selectGroupByIndex(_lIl1Il1 as Integer)
if m.parsedData = invalid or m.parsedData.groups = invalid then return
if _lIl1Il1 < 0 or _lIl1Il1 >= m.parsedData.groups.Count() then _lIl1Il1 = 0
m.currentGroupIdx = _lIl1Il1
_lll1Il1 = m.parsedData.groups[_lIl1Il1]
_llIlIl1 = m.parsedData.channelsByGroup[_lll1Il1]
if _llIlIl1 = invalid then _llIlIl1 = []
m.activeChannels = _llIlIl1
_l1IlIl1 = CreateObject(_l1d_6d53b9("977f7e6d678b979b", 206, 219), _l1d_6d53b9("91686a677b7370997d898d", 254, 212))
_l111Il1 = _llIlIl1.Count() - 1
if _l111Il1 > 600 then _l111Il1 = 599
for _l1l1Il1 = 0 to _l111Il1
_lI1lIl1 = _llIlIl1[_l1l1Il1]
_ll11Il1 = _l1IlIl1.CreateChild(_l1d_6d53b9("62494b584c54617a5e5a5e", 230, 189))
_lIIlIl1 = ""
if _lI1lIl1.isFavorite then _lIIlIl1 = _l1d_6d53b9("d0ee", 152, 51)
_lI11Il1 = Box(_l1l1Il1 + 1).ToStr()
if (_l1l1Il1 + 1) < 10 then _lI11Il1 = _l1d_6d53b9("ad", 234, 211) + _lI11Il1
_ll11Il1.title = _lI11Il1 + _l1d_6d53b9("ebe4", 195, 254) + _lIIlIl1 + _lI1lIl1.name
end for
m.channelList.content = _l1IlIl1
if _llIlIl1.Count() > 0 then
m.currentChannelIdx = 0
m.channelList.jumpToItem = 0
updateChannelDetails(_llIlIl1[0])
else
m.currentChannel = invalid
m.chName.text = _l1d_6d53b9("d2b4f6b6c4bec4c7c3cfbb11dbd91ac9e8ead329e9eedef0f1fcecf8", 119, 153)
m.chGroup.text = _lll1Il1
m.chFormat.text = ""
m.chLogo.uri = ""
end if
end sub
sub onGroupFocused()
if ((39620 - 7924 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
_ll1Il11 = m.groupList.itemFocused
selectGroupByIndex(_ll1Il11)
end sub
sub onGroupSelected()
if ((5256 - 1752 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.channelList.content <> invalid and m.channelList.content.getChildCount() > 0 then
m.channelList.setFocus(true)
end if
end sub
sub onChannelFocused()
_llll1I1 = m.channelList.itemFocused
if _llll1I1 >= 0 and _llll1I1 < m.activeChannels.Count() then
m.currentChannelIdx = _llll1I1
_lIIIlI1 = m.activeChannels[_llll1I1]
updateChannelDetails(_lIIIlI1)
if m.previewTimer <> invalid then
m.previewTimer.control = _l1d_6d53b9("747e8680", 155, 140)
m.previewTimer.control = _l1d_6d53b9("3133293b3c", 207, 117)
end if
end if
end sub
sub onChannelSelected()
onEnterFullscreen()
end sub
sub updateChannelDetails(_l11l1lI as Object)
m.currentChannel = _l11l1lI
if _l11l1lI = invalid then return
if m.chName <> invalid then m.chName.text = _l11l1lI.name
if m.chGroup <> invalid then m.chGroup.text = _l1d_6d53b9("6849374b505b495397a0", 244, 177) + _l11l1lI.group
if m.chFormat <> invalid then
_lI1l1lI = _l1d_6d53b9("484765396b8b90828980", 14, 2)
if Instr(1, _l11l1lI.url, _l1d_6d53b9("f4cdd7", 204, 18)) > 0 then _lI1l1lI = _l1d_6d53b9("b3c1b1b29fc9cfa3caf2f6ecb2e40409fb0209", 134, 232)
m.chFormat.text = _l1d_6d53b9("6f99899d9c8c5d66", 21, 28) + _lI1l1lI + _l1d_6d53b9("4e5152575a0d2e26322c2b32368b7817474f4146568d383f42499f474e51585a", 198, 104)
end if
if _l11l1lI.logo <> invalid and _l11l1lI.logo <> "" then
m.chLogo.uri = _l11l1lI.logo
else
m.chLogo.uri = _l1d_6d53b9("0df900503e03021112132c531519241f52323232363775523b45", 237, 112)
end if
if _l11l1lI.isFavorite then
m.btnToggleFav.text = _l1d_6d53b9("3b9373993a60705c7a647a6e70b75f", 204, 164)
else
m.btnToggleFav.text = _l1d_6d53b9("57052b0b6d5558174e662085655b755d79697b683e9c", 51, 239)
end if
end sub
sub onPreviewTimerFire()
if ((16290 - 5430 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
playCurrentStream()
end sub
sub playCurrentStream()
if m.currentChannel = invalid or m.currentChannel.url = "" then return
_l1l111I = CreateObject(_l1d_6d53b9("8a806f5e6a8c8a8c", 199, 213), _l1d_6d53b9("addce0cddfe9d6cff1eff1", 19, 93))
_l1l111I.url = m.currentChannel.url
_l1l111I.title = m.currentChannel.name
_l1l111I.live = true
_lll111I = _l1d_6d53b9("cbd2bc", 48, 115)
if Instr(1, m.currentChannel.url, _l1d_6d53b9("48717b", 20, 14)) > 0 then
_lll111I = _l1d_6d53b9("3d47", 140, 69)
else if Instr(1, m.currentChannel.url, _l1d_6d53b9("2bebdb1a", 117, 208)) > 0 then
_lll111I = _l1d_6d53b9("ee0c4b", 206, 75)
end if
_l1l111I.streamFormat = _lll111I
_l1l111I.minBandwidth = 0
_l1l111I.switchingStrategy = _l1d_6d53b9("939fa1b0a8b6b7b8ba", 60, 74)
m.videoBuffering.visible = true
m.bufferingText.text = _l1d_6d53b9("c6e8e2eae8e2acccfaf4fafdf905dac7", 135, 243) + m.currentChannel.name + _l1d_6d53b9("f5f8fb", 232, 47)
m.liveVideo.content = _l1l111I
m.liveVideo.control = _l1d_6d53b9("9bbab2ad", 114, 153)
updateOsdBanner()
end sub
sub onVideoState()
_l1III1I = m.liveVideo.state
if _l1III1I = _l1d_6d53b9("8e8d85a0939b97", 192, 222) then
m.videoBuffering.visible = false
else if _l1III1I = _l1d_6d53b9("beb6c8cbcfbdc9cfd9", 155, 197) then
m.videoBuffering.visible = true
m.bufferingText.text = _l1d_6d53b9("b08292959b8f9d99a56dc4aca0b67cceaeb3c5ccc3838689", 190, 180)
else if _l1III1I = _l1d_6d53b9("04f6f907ff", 217, 72) then
m.videoBuffering.visible = true
m.bufferingText.text = _l1d_6d53b9("8bb5afc1c4bcc87fafcbced7d5dfd797a79dd1f7f8ecebfab2d80a0d0b13", 129, 201)
showToast(_l1d_6d53b9("244049575e5523435b5e66641f384e6a7381887f4d9380888b99958e99916b9ba7a6b4bbc0b8c4c8bdc9", 28, 213))
end if
end sub
sub onEnterFullscreen()
if ((22248 - 7416 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
if m.currentChannel = invalid then return
m.isFullscreen = true
m.liveVideo.translation = [0, 0]
m.liveVideo.width = 1920
m.liveVideo.height = 1080
m.videoBuffering.translation = [0, 0]
m.videoBuffering.getChild(0).width = 1920
m.videoBuffering.getChild(0).height = 1080
m.videoBuffering.getChild(1).translation = [960, 540]
m.guideContainer.visible = false
m.headerGroup.visible = false
m.liveVideo.setFocus(true)
showOsdBanner()
end sub
sub exitFullscreen()
m.isFullscreen = false
m.liveVideo.translation = [984, 114]
m.liveVideo.width = 872
m.liveVideo.height = 492
m.videoBuffering.translation = [984, 114]
m.videoBuffering.getChild(0).width = 872
m.videoBuffering.getChild(0).height = 492
m.videoBuffering.getChild(1).translation = [436, 230]
m.guideContainer.visible = true
m.headerGroup.visible = true
hideOsdBanner()
m.channelList.setFocus(true)
end sub
sub showOsdBanner()
updateOsdBanner()
m.osdBanner.visible = true
if m.osdTimer <> invalid then
m.osdTimer.control = _l1d_6d53b9("d4daf6dc", 81, 178)
m.osdTimer.control = _l1d_6d53b9("8482988e8b", 245, 254)
end if
end sub
sub hideOsdBanner()
m.osdBanner.visible = false
if m.osdTimer <> invalid then m.osdTimer.control = _l1d_6d53b9("656b876d", 145, 131)
end sub
sub updateOsdBanner()
if m.currentChannel = invalid then return
_llII11l = m.currentChannel
_l1II11l = Box(m.currentChannelIdx + 1).ToStr()
if (m.currentChannelIdx + 1) < 10 then _l1II11l = _l1d_6d53b9("f5", 185, 108) + _l1II11l
m.osdNumber.text = _l1d_6d53b9("2432cd", 51, 180) + _l1II11l
m.osdName.text = _llII11l.name
m.osdGroup.text = _l1d_6d53b9("2106140809042220e0dd", 46, 180) + _llII11l.group
m.osdFav.visible = _llII11l.isFavorite
if _llII11l.logo <> invalid and _llII11l.logo <> "" then
m.osdLogo.uri = _llII11l.logo
else
m.osdLogo.uri = _l1d_6d53b9("c5b1b808f6bbbac9cacbe40bcdd1dcd70aeaeaeaeeef2d0af3fd", 237, 40)
end if
updateClock()
end sub
sub zapNextChannel(_l111lIl as Integer)
if ((20952 - 6984 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.activeChannels = invalid or m.activeChannels.Count() = 0 then return
_lI11lIl = (m.currentChannelIdx + _l111lIl + m.activeChannels.Count()) Mod m.activeChannels.Count()
m.currentChannelIdx = _lI11lIl
m.channelList.jumpToItem = _lI11lIl
updateChannelDetails(m.activeChannels[_lI11lIl])
playCurrentStream()
showOsdBanner()
end sub
sub onToggleFavClicked()
if m.currentChannel = invalid then return
M3U_ToggleFavorite(m.currentChannel.name)
m.currentChannel.isFavorite = not m.currentChannel.isFavorite
updateChannelDetails(m.currentChannel)
if m.currentChannel.isFavorite then
showToast(_l1d_6d53b9("b8d6fa20232729e81f3df11a38304c324c3a4e3f0912", 16, 163) + m.currentChannel.name)
else
showToast(_l1d_6d53b9("d9110c0d091d21e025142227ef14342a342c38384a37f310", 27, 144) + m.currentChannel.name)
end if
if m.channelList.content <> invalid and m.currentChannelIdx < m.channelList.content.getChildCount() then
_lIllIIl = ""
if m.currentChannel.isFavorite then _lIllIIl = _l1d_6d53b9("a9cf", 78, 94)
_ll1lIIl = Box(m.currentChannelIdx + 1).ToStr()
if (m.currentChannelIdx + 1) < 10 then _ll1lIIl = _l1d_6d53b9("a8", 253, 219) + _ll1lIIl
m.channelList.content.getChild(m.currentChannelIdx).title = _ll1lIIl + _l1d_6d53b9("dacf", 161, 75) + _lIllIIl + m.currentChannel.name
end if
end sub
sub onReloadClicked()
if ((28490 - 5698 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
playCurrentStream()
showToast(_l1d_6d53b9("4c808c90858d939d975584a294a464789e9fb3b2c1878a8d", 145, 137))
end sub
sub onSwitchPortalSelected()
if ((19670 - 3934 * 5) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
if m.liveVideo <> invalid then m.liveVideo.control = _l1d_6d53b9("100c1a16", 252, 129)
m.top.switchPortal = true
end sub
sub onOpenSettings()
_lI1Il11 = M3U_GetSavedUrl()
m.urlKeyboard.text = _lI1Il11
m.activeUrlLabel.text = _lI1Il11
m.playlistModal.visible = true
m.urlKeyboard.setFocus(true)
end sub
sub onSavePlaylistClicked()
_ll11I11 = m.urlKeyboard.text.Trim()
if _ll11I11 = "" then
showToast(_l1d_6d53b9("5c8c8f8f95e0c981817ed59b9cacafb3bbeaafb5f3bbc6ccd3db", 192, 215))
return
end if
M3U_SaveUrl(_ll11I11)
m.playlistModal.visible = false
showToast(_l1d_6d53b9("56554b465e5c454f9e6e63596d71afb39d837d826f798f958fd1919f99a7aaa6b296f6f9fc", 243, 179))
loadM3uPlaylist(_ll11I11)
end sub
sub onDefaultPlaylistClicked()
_l1ll1I1 = M3U_GetDefaultUrl()
M3U_SaveUrl(_l1ll1I1)
m.urlKeyboard.text = _l1ll1I1
m.playlistModal.visible = false
showToast(_l1d_6d53b9("7d95a2aca4aca4a8678eb0b2b2c9c5d07fb5aa88addcd4d7a2eee6abc2edf7acdffef40f07050e18c6", 131, 172))
loadM3uPlaylist(_l1ll1I1)
end sub
sub onCancelPlaylistClicked()
m.playlistModal.visible = false
m.channelList.setFocus(true)
end sub
sub showToast(_llIl1lI as String)
if ((67879 - 9697 * 7) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.tvToastText.text = _llIl1lI
m.tvToast.visible = true
m.toastTimer = CreateObject(_l1d_6d53b9("cbd3b2c1bbdfebef", 94, 159), _l1d_6d53b9("8f858c8775", 179, 168))
m.toastTimer.duration = 2.5
m.toastTimer.observeField(_l1d_6d53b9("17293123", 198, 119), _l1d_6d53b9("8f93a1a597bc9dabb0c5c9", 136, 175))
m.toastTimer.control = _l1d_6d53b9("a4a4bcacad", 182, 223)
end sub
sub hideTvToast()
m.tvToast.visible = false
if m.toastTimer <> invalid then m.toastTimer.control = _l1d_6d53b9("232d352f", 91, 251)
end sub
function onKeyEvent(_lIl111I as String, _l11111I as Boolean) as Boolean
if not _l11111I then return false
if m.playlistModal <> invalid and m.playlistModal.visible then
if _lIl111I = _l1d_6d53b9("0f0f141f", 17, 156) then
m.playlistModal.visible = false
m.channelList.setFocus(true)
return true
else if _lIl111I = _l1d_6d53b9("bcb4afbb", 223, 1) then
if m.urlKeyboard.hasFocus() then
m.btnSavePlaylist.setFocus(true)
return true
end if
else if _lIl111I = _l1d_6d53b9("9494", 209, 240) then
if m.btnSavePlaylist.hasFocus() or m.btnDefaultPlaylist.hasFocus() or m.btnCancelPlaylist.hasFocus() then
m.urlKeyboard.setFocus(true)
return true
end if
else if _lIl111I = _l1d_6d53b9("b0aab0a1", 213, 247) then
if m.btnDefaultPlaylist.hasFocus() then
m.btnSavePlaylist.setFocus(true)
return true
else if m.btnCancelPlaylist.hasFocus() then
m.btnDefaultPlaylist.setFocus(true)
return true
end if
else if _lIl111I = _l1d_6d53b9("f3ede6f2f9", 228, 93) then
if m.btnSavePlaylist.hasFocus() then
m.btnDefaultPlaylist.setFocus(true)
return true
else if m.btnDefaultPlaylist.hasFocus() then
m.btnCancelPlaylist.setFocus(true)
return true
end if
end if
return false
end if
if m.isFullscreen then
if _lIl111I = _l1d_6d53b9("afb3b4af", 155, 182) then
exitFullscreen()
return true
else if _lIl111I = _l1d_6d53b9("68707b77", 99, 97) then
zapNextChannel(1)
return true
else if _lIl111I = _l1d_6d53b9("ecec", 249, 96) then
zapNextChannel(-1)
return true
else if _lIl111I = _l1d_6d53b9("fa060afb", 120, 230) then
_lI1111I = (m.currentGroupIdx - 1 + m.parsedData.groups.Count()) Mod m.parsedData.groups.Count()
selectGroupByIndex(_lI1111I)
playCurrentStream()
showOsdBanner()
return true
else if _lIl111I = _l1d_6d53b9("4a665b6d54", 119, 69) then
_ll1111I = (m.currentGroupIdx + 1) Mod m.parsedData.groups.Count()
selectGroupByIndex(_ll1111I)
playCurrentStream()
showOsdBanner()
return true
else if _lIl111I = _l1d_6d53b9("2930", 62, 184) or _lIl111I = _l1d_6d53b9("695e58646579", 8, 238) then
if m.osdBanner.visible then
hideOsdBanner()
else
showOsdBanner()
end if
return true
else if _lIl111I = _l1d_6d53b9("989897a7a4a6a6", 30, 39) then
onToggleFavClicked()
showOsdBanner()
return true
end if
return true
end if
if _lIl111I = _l1d_6d53b9("5b5f606b", 39, 22) then
if m.btnFullscreen.hasFocus() or m.btnToggleFav.hasFocus() or m.btnReload.hasFocus() then
m.channelList.setFocus(true)
return true
else if m.channelList.hasFocus() then
m.groupList.setFocus(true)
return true
else if m.groupList.hasFocus() or m.btnSettings.hasFocus() or m.btnSwitchPortal.hasFocus() then
if m.liveVideo <> invalid then m.liveVideo.control = _l1d_6d53b9("343a363c", 1, 194)
m.top.closeView = true
return true
end if
return false
else if _lIl111I = _l1d_6d53b9("91898a909f", 161, 190) then
if m.groupList.hasFocus() then
if m.channelList.content <> invalid and m.channelList.content.getChildCount() > 0 then
m.channelList.setFocus(true)
return true
end if
else if m.channelList.hasFocus() then
m.btnFullscreen.setFocus(true)
return true
else if m.btnFullscreen.hasFocus() then
m.btnToggleFav.setFocus(true)
return true
else if m.btnToggleFav.hasFocus() then
m.btnReload.setFocus(true)
return true
else if m.btnSettings.hasFocus() then
m.btnSwitchPortal.setFocus(true)
return true
end if
else if _lIl111I = _l1d_6d53b9("ccc8ccbd", 148, 212) then
if m.channelList.hasFocus() then
m.groupList.setFocus(true)
return true
else if m.btnFullscreen.hasFocus() then
m.channelList.setFocus(true)
return true
else if m.btnToggleFav.hasFocus() then
m.btnFullscreen.setFocus(true)
return true
else if m.btnReload.hasFocus() then
m.btnToggleFav.setFocus(true)
return true
else if m.btnSwitchPortal.hasFocus() then
m.btnSettings.setFocus(true)
return true
end if
else if _lIl111I = _l1d_6d53b9("6b71", 204, 178) then
if m.groupList.hasFocus() and m.groupList.itemFocused = 0 then
m.btnSettings.setFocus(true)
return true
else if m.channelList.hasFocus() and m.channelList.itemFocused = 0 then
m.btnSettings.setFocus(true)
return true
else if m.btnFullscreen.hasFocus() or m.btnToggleFav.hasFocus() or m.btnReload.hasFocus() then
m.btnSettings.setFocus(true)
return true
end if
else if _lIl111I = _l1d_6d53b9("ece803ef", 233, 95) then
if m.btnSettings.hasFocus() or m.btnSwitchPortal.hasFocus() then
m.channelList.setFocus(true)
return true
end if
else if _lIl111I = _l1d_6d53b9("81687681", 239, 226) then
onEnterFullscreen()
return true
else if _lIl111I = _l1d_6d53b9("cfe3ead2dbddf5", 8, 104) then
onToggleFavClicked()
return true
end if
return false
end function
function _l1d_6d53b9(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function