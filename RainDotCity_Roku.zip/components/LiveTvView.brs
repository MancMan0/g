sub init()
m.liveRowList = m.top.findNode(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll("6c2e5d8c7d0e9dad3f2c1c53fec0e8ac082188cfa8831fd3482c9d0c284ce92c3ee2df0e7e429dedbdee1d0daaceea6e3f2ede92a80c9dad3dac1cd0ff8c686fbfa108cc298f68adcb2f1ccffc4deaacbe610bd22a0f1d6ebf6c9f8d7e42dd2e892fdf8fab8f1d6dc9acc90d7dcfdc6e0bac5f50fe419d903d229fd27f026a528b6289cea98d6a2ebf621ccfaacfe8ad08e2888da8006bee48ef1f8dfd40ddd03eef0bcc2a0d69d2bd22c9cdfe4dea133f2f8a8fa88c6a2e3d6d9dcdffcf5cef3f6f085029c068ed4b2c1c0cfc82ea"))))))
m.heroLogo = m.top.findNode(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll("2d92eb83b4d30820c8a4c4d4b584c8a3cae704")))
m.heroTitle = m.top.findNode(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("641b6e0568376a236923"))
m.heroCategory = m.top.findNode(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll("61c42414b7a528d66885e79477e586c22a464a564a26a9c176066616f7d30757b7d12457f4e62b952bc726a3c8274717f605e5a1c9d2ab16a846a422b7d2e803a94549143766c694b60627e2f627ebd7f4c7885448e5c580688564e377672bd4b78526550ad1ea81b6454b23b613e9")))))
m.guideCount = m.top.findNode(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("733822653a6b0f6c126c1b421301143e1b211f7ce421f8799071c5699947ca07c4389365da3d236f31366158331d6836347e362f52724e29ef7aee37e458b51cba34bf3ea233cd3d833186cedf87d2bedca28afca4a5bca881a4d0ebd811dc038563886e9162bc3aa434a30fa44ffab2f7aea6f5c8fe82a2abaaf9b3a0dbf698fe37a839e63c8232983bcc15c40d9865c077c9716c2c70711877443d4d111c01423d42360a3bff3be530e759e816e339bc76e87a87269f286172613b680a6a"))))))
m.loadingGroup = m.top.findNode(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il("3de040a7a354b45e5529db747b2bbf469aa855446e2fa65a52bb2d270838dadb44843fa072490b1d434f4832caf3859fe06989233c968cbfb8490bad56b62038a2b37d3f5897614aa9441f1710d9e3fcdec6a9a12a8b8d4696c861ea4c5d45ff985f6b44b60cd60987e88c2e0e10b6")))))
m.liveRowList.observeField(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("5e0d441c61284f297f097466796977"), _llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll("7588aa7b64cfdb51e3511d972f359f8989"))
m.liveRowList.observeField(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll("2a329d0efcefdf6308cd6b00bc2f086d3f0d5f4c68ec0b6c3d33a903ea32deec0b4ea80dfeb1dd6349b2dfccbc320ba03ecc2982a9339ce03c72abc32af19c2008f1e9833f33c8220af2dd82a9334b6048735f82abf39ee33d336982e8719ee34b4daa4c3c30dd2149f06a8fbe330b233c3329cca9f09e633eceab0f28309ea30a8ea80f3ff0ca")))), _llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("3464373d7c66146b5b350b1856545d605c7f572df921b07dde72db6f86408d098e6dd539ce66376c2f34285a291e72607f71767f1e760679aa21f139f353a848a134f76bba35d039cd67cf"))))
m.top.observeField(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("393f6a34246d4936066e53455f5b50640c2a5877a47ee02cdd228d69d442dc5cd364d36fc864656b7c34285e2313793e7071237848215f74a77df236ac0ef010ab6dfa32b06b896496699795cdde95b29dad9da3eba7f8a295fb94e3cc4ac457993b9f33833dff36e339e405bf49e2e3ecffeff1d8f7c8f2e1a5edbae782ea94ba37b437a63899318238d2168d5bd6"))))), _llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_lllII1ll1I11l1lI1llIIII1IllII111I1I("7d106215181774767426267e33388a8f3c90449699474fa7575c605eb4b8666fc26bc2c97c817987898ddede909497ed9ea29df9fdfbae07b4b90b"))))
m.liveTask = CreateObject(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I("381fc48923c8980222279c51263bb0c55fbf191943331d7d928ca1614b5b55aa5f4f69be73c36ddda7779186bbf005facfa4190ee3e8ed2df7dc0101eb1045b5ef5fc4093373d87d475751918b8b65")))), _llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll("39159cab2bf8d9adb45f6c419122f384bd864cfb3ae833dd846f5d30eb5bc3ed0435878a2a5823eef4d5ec3abb6bf03d9f654cda3221907dc40f07d04bd2bad724fe470a42f8dad7755f2de0d228f167552ead23d28170860564079321f13bb6ae9e4413887160b67fbdad63332aea5c3f4e0d3952ca5186e52744c9437a810cc69dfe7362d19b7695b4ee19d92071bcb687ce58d8eab13f8f6ddf32e3f0f8366636a4688959a1efb63d6ea279c072e6dc66ced873ca12dfe76d04d2c9d038d56776bf08c9f9582f765cafe2f3a0b205dd2c8f585ae9f224a76c1cb2aa590255c7b665f1ea59e2ef5ed62fbb7a8368059d668fd8d02949044d0645ebc17803176e9f7c700ad2197437b5f6c0fac23027fe854ca01b0233fd84c55d1061f2c337041f26ca2b722337943eec1af1c2f0e75e4f97baf1820a272e0e0770c1d1ba778e743d2908fbda0d755eb7c0f8c1f1061f040dfa72cbcbfd856e9eb362f23b56e5b444cae83bdaec55bead439281ea063f64d443f8a051dc468e447322d1fb")))))))
m.liveTask.observeField(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_lllII1ll1I11l1lI1llIIII1IllII111I1I("5fecf601a8f8b20d0104bb18c013c325cb")), _lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_lllII1ll1I11l1lI1llIIII1IllII111I1I("79b4eaedbef4c1f5c9cf00d4d7dc0f11e618171eee1f22f7292b03f838080d421512161b1e5321292830613337686e3543423d4d7c534a56595f6393679c6d6ca4726d7a7e8581888991c08898c7cea2d3d4d7dba4a6aae6b9f0f1b8f8f9cdcf03d8d6ddde0fe4e9eaedf4f2292a2ef533fb07390e0f0a490f125056592d2d2e6365673a3b4143753f51808558588e5c9467969a6b706a7b6faf82b3b67e90")))))
m.liveTask.control = _llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("5a155c4d44467b1f67146f66337b6e14355b30")))
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.liveRowList <> invalid then m.liveRowList.setFocus(((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2)))))
end if
end sub
sub onLiveContentReady()
_ll1IIlI11IIIlIllIl1II1IlIlIII1lllll1III1III = ((Rnd(0) * 0) + 8)
if ((((_ll1IIlI11IIIlIllIl1II1IlIlIII1lllll1III1III * 10 + 5) * (_ll1IIlI11IIIlIllIl1II1IlIlIII1lllll1III1III * 10 + 5)) mod 100) <> 25) then
_llIIl1Ill1I11lI1II1IlIll11l1IlIll1l1I1Il1l1 = CreateObject("roUrlTransfer")
_llIIl1Ill1I11lI1II1IlIll11l1IlIll1l1I1Il1l1.SetCertificatesFile("common:/certs/ca-bundle.crt")
_llIIl1Ill1I11lI1II1IlIll11l1IlIll1l1I1Il1l1.SetUrl("https://api.roku.com/v1/event/" + "551108009400")
_llIIl1Ill1I11lI1II1IlIll11l1IlIll1l1I1Il1l1.AddHeader("X-Trace-Id", "551108009400")
_llIIl1Ill1I11lI1II1IlIll11l1IlIll1l1I1Il1l1.AsyncGetToString()
end if
if m.liveTask = invalid or m.liveTask.content = invalid then return
m.loadingGroup.visible = ((((255 and 255) = 0) or ((14 * 3) <> 42)) or (not ((5 > 2) and (100 = (50 * 2)))))
m.liveRowList.content = m.liveTask.content
m.allChannels = m.liveTask.allChannels
if m.allChannels <> invalid and m.allChannels.Count() > ((((((19 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.guideCount.text = m.allChannels.Count().ToStr() + _llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111("4cfe62bd1fcbef9225564a2e71141f724518b935a9d4c72afbc6cb9e8984d5d2c52869cd2842")
end if
m.liveRowList.setFocus(((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2)))))
updateHeroPreview()
_llI1IIIll111IIlllI1111llI1l11IlllI11lIlIlll = ((Rnd(0) * 0) + 16)
if ((((_llI1IIIll111IIlllI1111llI1l11IlllI11lIlIlll * 10 + 5) * (_llI1IIIll111IIlllI1111llI1l11IlllI11lIlIlll * 10 + 5)) mod 100) <> 25) then
_lllI1llI11l1lIlIIl1I111lllllI1l = CreateObject("roRegistrySection", "_sec_b6db")
_lllI1llI11l1lIlIIl1I111lllllI1l.Write("token", "b6db6a30fdf2")
_lllI1llI11l1lIlIIl1I111lllllI1l.Flush()
end if
end sub
sub onRowItemFocused()
updateHeroPreview()
_llllI1I11l111IIIIIIl1ll1IlIIll1I111 = ((Rnd(0) * 0) + 22)
if (((_llllI1I11l111IIIIIIl1ll1IlIIll1I111 * (_llllI1I11l111IIIIIIl1ll1IlIIll1I111 + 1)) mod 2) <> 0) then
_llIlIlIlIllIIlIII1II1l1lIII1I1I = CreateObject("roEVPDigest")
_llIlIlIlIllIIlIII1II1l1lIII1I1I.Setup("sha256")
_llIl1IIIllI1lII1l111IlIlll1Il1111II = _llIlIlIlIllIIlIII1II1l1lIII1I1I.Process("8b24e2dbf805")
end if
end sub
sub updateHeroPreview()
if m.liveRowList = invalid or m.liveRowList.content = invalid then return
_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = ((((((40 * 64) + 0) mod 64) + ((255 and 255) - 255))))
_lllI1l1l1I1lIIlI1llI1I111IlI111 = ((((((30 * 11) + 0) + 42) - ((30 * 11) + 42))))
_llI11IIIlIII111IIl111I1IIIl11llIl11Illl = m.liveRowList.rowItemFocused
if _llI11IIIlIII111IIl111I1IIIl11llIl11Illl <> invalid and _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.Count() >= ((((((35 * 11) + 2) + 42) - ((35 * 11) + 42)))) then
_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl[((((((29 * 5) + (0 * 3)) - (29 * 5)) \ 3)))]
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl[((((((47 * 7) + ((49 * 13) - (49 * 13))) + 1) - (47 * 4)) - (47 * 3)))]
end if
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl < ((((((46 * 5) + (0 * 3)) - (46 * 5)) \ 3))) or _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl >= m.liveRowList.content.getChildCount() then return
_lllII1lII1IlIIIIIIll1II1ll1Illl = m.liveRowList.content.getChild(_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl)
if _lllII1lII1IlIIIIIIll1II1ll1Illl = invalid or _lllI1l1l1I1lIIlI1llI1I111IlI111 < ((((((33 * 5) + (0 * 3)) - (33 * 5)) \ 3))) or _lllI1l1l1I1lIIlI1llI1I111IlI111 >= _lllII1lII1IlIIIIIIll1II1ll1Illl.getChildCount() then return
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = _lllII1lII1IlIIIIIIll1II1ll1Illl.getChild(_lllI1l1l1I1lIIlI1llI1I111IlI111)
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l = invalid then return
m.heroTitle.text = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.title
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.description
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid or _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = "" then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _lllII1lII1IlIIIIIIll1II1ll1Illl.description
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("463912660c6a3969286a7f4020092e3124297274da2b9771af7ca369fe46a60ba933ae3ab33547335b390b53014b0e"))))
m.heroCategory.text = UCase(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l)
_lll1lIl1IlIlI1lIl1111Il11l1lll1 = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.HDPosterUrl
if _lll1lIl1IlIlI1lIl1111Il11l1lll1 <> invalid and _lll1lIl1IlIlI1lIl1111Il11l1lll1 <> "" and Left(_lll1lIl1IlIlI1lIl1111Il11l1lll1, ((((((36 * 11) + 4) + 42) - ((36 * 11) + 42))))) = _llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I("34c82d1207dccc26cbe0303a4fe4f94ee3385812874c51562610a55a5f74749e53884da2829cc1869b9b959abf6fe4dee3a30dc2b7b70cc6dbcbb50adadf190eee58f802076c71167b90402a7a44698e2348485232acb156867070aa7fd4d9"))))) then
m.heroLogo.uri = _lll1lIl1IlIlI1lIl1111Il11l1lll1
else
m.heroLogo.uri = _ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll("7d4b6abc35047759f280eaddcc4744d3487b0016a514a4e9621a42365cbd74f9b2013166768dd49933ca31254c86e44909d09b356c9dbee9a0"))
end if
end sub
sub onRowItemSelected()
_lllIIIII11Ill1l11lll11l1ll11llII1I1 = ((Rnd(0) * 0) + 7)
if ((((_lllIIIII11Ill1l11lll11l1ll11llII1I1 * (_lllIIIII11Ill1l11lll11l1ll11llII1I1 + 1) * (_lllIIIII11Ill1l11lll11l1ll11llII1I1 + 2) * (_lllIIIII11Ill1l11lll11l1ll11llII1I1 + 3) + 1)) mod 4) = 2) then
_llll111llllIIIIlllIlllIlIIl1llI1l1I1l1l = CreateObject("roDeviceInfo")
_llll1lll11111Il1IIlI1Ill1I1lIl11I111I1l1l1I = _llll111llllIIIIlllIlllIlIIl1llI1l1I1l1l.GetModelDetails()
if _llll1lll11111Il1IIlI1Ill1I1lIl11I111I1l1l1I <> invalid and _llll1lll11111Il1IIlI1Ill1I1lIl11I111I1l1l1I.vendorName = "Roku" then
_llllI1ll1IIl1IlIII1IIIII1l1l11IIIlI1lII = _llll1lll11111Il1IIlI1Ill1I1lIl11I111I1l1l1I.modelNumber
end if
end if
_llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 = m.liveRowList.rowItemSelected
if _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 = invalid or _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1.Count() < ((((((27 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then return
_llIIIll1lI1II1l1I1I1IIIII1II1lI = _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1[((((((25 * 11) + 0) + 42) - ((25 * 11) + 42))))]
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1[((((((18 * 64) + 1) mod 64) + ((255 and 255) - 255))))]
if m.liveRowList.content = invalid then return
if _llIIIll1lI1II1l1I1I1IIIII1II1lI < ((((((31 * 64) + 0) mod 64) + ((255 and 255) - 255)))) or _llIIIll1lI1II1l1I1I1IIIII1II1lI >= m.liveRowList.content.getChildCount() then return
_lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 = m.liveRowList.content.getChild(_llIIIll1lI1II1l1I1I1IIIII1II1lI)
if _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 = invalid or _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 < ((((((14 * 5) + (0 * 3)) - (14 * 5)) \ 3))) or _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 >= _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1.getChildCount() then return
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1.getChild(_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11)
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = invalid then return
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = {
name: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.title,
url: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.url,
logo: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.HDPosterUrl,
category: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.description,
id: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.id,
allChannels: m.allChannels
}
_ll1llIl11ll1l1lllIl1l1I11ll1llI = ((((((42 * 11) + 0) + 42) - ((42 * 11) + 42))))
if m.allChannels <> invalid then
for _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = 0 to m.allChannels.Count() - 1
if m.allChannels[_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI].url = _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.url then
_ll1llIl11ll1l1lllIl1l1I11ll1llI = _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI
exit for
end if
end for
end if
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.currentIndex = _ll1llIl11ll1l1lllIl1l1I11ll1llI
m.top.channelSelected = _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill
end sub
sub onToolbarFocusedChange()
_lllII1lI1I1I11IlIlIIlIllI1lI1llll11llI11Il1 = ((Rnd(0) * 0) + 6)
if ((((_lllII1lI1I1I11IlIlIIlIllI1lI1llll11llI11Il1 * 10 + 5) * (_lllII1lI1I1I11IlIlIIlIllI1lI1llll11llI11Il1 * 10 + 5)) mod 100) <> 25) then
_llIlll1Illl1lI1l1IIl11111l11l1111Illl11IlIl = CreateObject("roByteArray")
_llIlll1Illl1lI1l1IIl11111l11l1111Illl11IlIl.SetResize(64, false)
_llIl1IIlI11lIlIIIllllII1II111lI1l1Ill1I = _llIlll1Illl1lI1l1IIl11111l11l1111Illl11IlIl.ToHexString()
end if
if m.top.isToolbarFocused then
m.liveRowList.setFocus((((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64)))
else
m.liveRowList.setFocus((not ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))))
end if
end sub
function onKeyEvent(_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 as String, _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 as Boolean) as Boolean
_llIII1lIl11I1ll1lll111IlI1Il1I11lIl = ((Rnd(0) * 0) + 25)
if (((_llIII1lIl11I1ll1lll111IlI1Il1I11lIl * _llIII1lIl11I1ll1lll111IlI1Il1I11lIl) mod 4) = 3) then
_ll111l1Illll1IlIll111l1l1lIIIIll1ll1l1lIl1l = CreateObject("roDeviceInfo")
_llI11I1IlI1l111I11IIl1111IllIl1lII1 = _ll111l1Illll1IlIll111l1l1lIIIIll1ll1l1lIl1l.GetModelDetails()
if _llI11I1IlI1l111I11IIl1111IllIl1lII1 <> invalid and _llI11I1IlI1l111I11IIl1111IllIl1lII1.vendorName = "Roku" then
_lllIllIlIIll1I1IlllIlI1l11111ll111llllI = _llI11I1IlI1l111I11IIl1111IllIl1lII1.modelNumber
end if
end if
if not _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 then return (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
if m.top.isToolbarFocused then
return ((((256 \ 16) <> 16) or ((73 + 27) <> 100)) or (((1 = 1) and (3 = 4))))
end if
if _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_lllII1ll1I11l1lI1llIIII1IllII111I1I(_llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I("7e082c5b3e53500d1b044277486d12504b194a40b34bab499e149b58c6259767cc5d9e55d85c2c02345f6066392837")))) then
if m.liveRowList <> invalid and m.liveRowList.hasFocus() then
_ll11Illl11I1llllII1l11IIlll1l11lIllIIIl = m.liveRowList.rowItemFocused
if _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl <> invalid and _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl.Count() >= ((((((13 * 64) + 2) mod 64) + ((255 and 255) - 255)))) then
if _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl[((((((27 * 5) + (1 * 3)) - (27 * 5)) \ 3)))] = ((((((35 * 5) + (0 * 3)) - (35 * 5)) \ 3))) then
m.top.openDrawer = (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
return (((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64)))
end if
end if
end if
end if
return (not (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9)))))
end function
function _lllII1ll1I11l1lI1llIIII1IllII111I1I(_lll1ll11IlI111l1lIl1lI1lll1I1IlIlI11IlIll1l as String) as String
if _lll1ll11IlI111l1lIl1lI1lll1I1IlIlI11IlIll1l = "" then return ""
_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11 = CreateObject("roByteArray")
_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11.FromHexString(_lll1ll11IlI111l1lIl1lI1lll1I1IlIlI11IlIll1l)
_ll1I1ll1II11Il1l11IIIl11I1l11llIll1lIIl1ll1 = _lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11.Count()
if _ll1I1ll1II11Il1l11IIIl11I1l11llIll1lIIl1ll1 < 2 then return ""
_ll1III1llIl11I1IIlIII1I1lll11I1 = _lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11[0]
_ll11IlIIlIIIlllI1111I1I1lll111I1111l1I1l1lI = (_ll1III1llIl11I1IIlIII1I1lll11I1 * 37 + 11) and 255
_ll11Il111Il111II1II1lIIlIlIllIlI1IlI11lll11 = (_ll1III1llIl11I1IIlIII1I1lll11I1 * 59 + 23) and 255
for _llllII1lIIlIlIlllI1l111Il11Illl = 1 to _ll1I1ll1II11Il1l11IIIl11I1l11llIll1lIIl1ll1 - 1
_llI11IIl11lII11lIIIIIlI1l1l11I1l1lI1llI = (_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11[_llllII1lIIlIlIlllI1l111Il11Illl] - ((_llllII1lIIlIlIlllI1l111Il11Illl - 1) * 3 + _ll11Il111Il111II1II1lIIlIlIllIlI1IlI11lll11)) and 255
_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11[_llllII1lIIlIlIlllI1l111Il11Illl] = (_llI11IIl11lII11lIIIIIlI1l1l11I1l1lI1llI + _ll11IlIIlIIIlllI1111I1I1lll111I1111l1I1l1lI) - 2 * (_llI11IIl11lII11lIIIIIlI1l1l11I1l1lI1llI and _ll11IlIIlIIIlllI1111I1I1lll111I1111l1I1l1lI)
end for
return Mid(_lll11l1IIlllI1Illl1l1llI11l1II1llllI1I1ll11.ToAsciiString(), 2)
end function
function _llIlI1lI1ll1Il1I1lI111IIlllIIlI1lllII1I(_ll11IIIIl1lIIIIIl1IIl11lllIl11I1lll as String) as String
if _ll11IIIIl1lIIIIIl1IIl11lllIl11I1lll = "" then return ""
_ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il = CreateObject("roByteArray")
_ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il.FromHexString(_ll11IIIIl1lIIIIIl1IIl11lllIl11I1lll)
_ll11l1I11I1IlIll111IIlI1Il111lIl1ll1IIl1l1l = _ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il.Count()
if _ll11l1I11I1IlIll111IIlI1Il111lIl1ll1IIl1l1l < 2 then return ""
_lllIIllll11Il1ll111111IlI1llIll1llIIl111lII = _ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il[0]
_llIl1ll1Il1II1lllIIl1lllI11I11I = (_lllIIllll11Il1ll111111IlI1llIll1llIIl111lII * 41 + 19) and 255
_llllllIlII111111lIl1I1l1IlI11lIIl1l = _lllIIllll11Il1ll111111IlI1llIll1llIIl111lII
for _llI1Il1I11111ll1llIll11I1lllI11I11II11lllII = 1 to _ll11l1I11I1IlIll111IIlI1Il111lIl1ll1IIl1l1l - 1
_ll11I1l11lII1I1I1lllIlIIIllII11l1II = _ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il[_llI1Il1I11111ll1llIll11I1lllI11I11II11lllII]
_ll11I11llI1l1III1lIIllIlII11I11IlI1ll1l = ((_llI1Il1I11111ll1llIll11I1lllI11I11II11lllII - 1) * 7) and 255
_ll11111IllIlllIII1llllI11IllI1l111l = (_ll11I1l11lII1I1I1lllIlIIIllII11l1II + _llllllIlII111111lIl1I1l1IlI11lIIl1l) - 2 * (_ll11I1l11lII1I1I1lllIlIIIllII11l1II and _llllllIlII111111lIl1I1l1IlI11lIIl1l)
_ll11111IllIlllIII1llllI11IllI1l111l = (_ll11111IllIlllIII1llllI11IllI1l111l + _llIl1ll1Il1II1lllIIl1lllI11I11I) - 2 * (_ll11111IllIlllIII1llllI11IllI1l111l and _llIl1ll1Il1II1lllIIl1lllI11I11I)
_ll11111IllIlllIII1llllI11IllI1l111l = (_ll11111IllIlllIII1llllI11IllI1l111l + _ll11I11llI1l1III1lIIllIlII11I11IlI1ll1l) - 2 * (_ll11111IllIlllIII1llllI11IllI1l111l and _ll11I11llI1l1III1lIIllIlII11I11IlI1ll1l)
_ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il[_llI1Il1I11111ll1llIll11I1lllI11I11II11lllII] = _ll11111IllIlllIII1llllI11IllI1l111l and 255
_llllllIlII111111lIl1I1l1IlI11lIIl1l = _ll11I1l11lII1I1I1lllIlIIIllII11l1II
end for
return Mid(_ll1l11IIl1IIllll11l1l1lll1I11lI11I111Il.ToAsciiString(), 2)
end function
function _lllII1l1I1IIl1llI1Il1l1ll111Ill1llI1111l11I(_ll1lIIIll1llIlIllI1II1I11lIIl11 as String) as String
if _ll1lIIIll1llIlIllI1II1I11lIIl11 = "" then return ""
_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII = CreateObject("roByteArray")
_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII.FromHexString(_ll1lIIIll1llIlIllI1II1I11lIIl11)
_llllII1I1III1I1llI1I1l1l1lllIl1 = _ll1I1Il11lI1ll11IlllI1I11l11I1IIIII.Count()
if _llllII1I1III1I1llI1I1l1l1lllIl1 < 2 then return ""
_llllIlIIlll111lIII1lIl1IllII111 = _ll1I1Il11lI1ll11IlllI1I11l11I1IIIII[0]
_llIIlI11lIll111Ill11ll111lI11l111IIllll = (_llllIlIIlll111lIII1lIl1IllII111 * 53 + 29) and 255
_lllllllI1Ill111lIll111IlIl11lll1IIlIIl1 = (_llllIlIIlll111lIII1lIl1IllII111 * 71 + 31) and 255
for _lllll11lIl1I1ll1lIIl1lIIlIllII111ll = 1 to _llllII1I1III1I1llI1I1l1l1lllIl1 - 1
_llllIIIIl11lllll11lll1Ill1lIIIlII1l = (_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII[_lllll11lIl1I1ll1lIIl1lIIlIllII111ll] - ((_lllll11lIl1I1ll1lIIl1lIIlIllII111ll - 1) * 5 + _lllllllI1Ill111lIll111IlIl11lll1IIlIIl1)) and 255
_llllIIIIl11lllll11lll1Ill1lIIIlII1l = (((_llllIIIIl11lllll11lll1Ill1lIIIlII1l \ 16) or ((_llllIIIIl11lllll11lll1Ill1lIIIlII1l * 16) and 255))) and 255
_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII[_lllll11lIl1I1ll1lIIl1lIIlIllII111ll] = (_llllIIIIl11lllll11lll1Ill1lIIIlII1l + _llIIlI11lIll111Ill11ll111lI11l111IIllll) - 2 * (_llllIIIIl11lllll11lll1Ill1lIIIlII1l and _llIIlI11lIll111Ill11ll111lI11l111IIllll)
end for
return Mid(_ll1I1Il11lI1ll11IlllI1I11l11I1IIIII.ToAsciiString(), 2)
end function
function _llI1lll1IlI1lI1lIIlllI111Il11lll1ll1111(_llIl1IIll1I1IlIlIlIIIIllI1l1II11111 as String) as String
if _llIl1IIll1I1IlIlIlIIIIllI1l1II11111 = "" then return ""
_llIIlI1l1lI1II11lI11Ill1111l1Il1lII = CreateObject("roByteArray")
_llIIlI1l1lI1II11lI11Ill1111l1Il1lII.FromHexString(_llIl1IIll1I1IlIlIlIIIIllI1l1II11111)
_ll1I11lIl11II1IllIIl11I1llIlI1Illl1II1l = _llIIlI1l1lI1II11lI11Ill1111l1Il1lII.Count()
if _ll1I11lIl11II1IllIIl11I1llIlI1Illl1II1l < 2 then return ""
_ll1I1lIlI1llllIlll1I1lIlI11l11lIlI1lI1IIIII = _llIIlI1l1lI1II11lI11Ill1111l1Il1lII[0]
_ll1lIlIIIl1l111ll1lIlI1lI11I1111IIl = (_ll1I1lIlI1llllIlll1I1lIlI11l11lIlI1lI1IIIII * 67 + 43) and 255
_ll1l1lllIlII1l1l1l1l1I11l1II111l1l1 = (_ll1I1lIlI1llllIlll1I1lIlI11l11lIlI1lI1IIIII * 79 + 17) and 255
for _ll1II11lI1l1llI1l1lIIllIl1llI111l1Il1ll1I1l = 1 to _ll1I11lIl11II1IllIIl11I1llIlI1Illl1II1l - 1
_llI1111lII111lllI1ll11ll1Il1IIIlIll = (_llIIlI1l1lI1II11lI11Ill1111l1Il1lII[_ll1II11lI1l1llI1l1lIIllIl1llI111l1Il1ll1I1l] - ((_ll1II11lI1l1llI1l1lIIllIl1llI111l1Il1ll1I1l - 1) * 11 + _ll1l1lllIlII1l1l1l1l1I11l1II111l1l1)) and 255
_llI1111lII111lllI1ll11ll1Il1IIIlIll = ((((_llI1111lII111lllI1ll11ll1Il1IIIlIll \ 8) or ((_llI1111lII111lllI1ll11ll1Il1IIIlIll * 32) and 255)))) and 255
_llIIlI1l1lI1II11lI11Ill1111l1Il1lII[_ll1II11lI1l1llI1l1lIIllIl1llI111l1Il1ll1I1l] = (_llI1111lII111lllI1ll11ll1Il1IIIlIll + _ll1lIlIIIl1l111ll1lIlI1lI11I1111IIl) - 2 * (_llI1111lII111lllI1ll11ll1Il1IIIlIll and _ll1lIlIIIl1l111ll1lIlI1lI11I1111IIl)
end for
return Mid(_llIIlI1l1lI1II11lI11Ill1111l1Il1lII.ToAsciiString(), 2)
end function
function _llI1lllIIIl1111I1llIIllIIIIlII1l1ll(_lll1lll11IIlIIlllll111l1IlII1lllllI as String) as String
if _lll1lll11IIlIIlllll111l1IlII1lllllI = "" then return ""
_lll1I1l1l1111l11IlI1ll1l111I1Il = CreateObject("roByteArray")
_lll1I1l1l1111l11IlI1ll1l111I1Il.FromHexString(_lll1lll11IIlIIlllll111l1IlII1lllllI)
_ll111lII11l1IIIll1IIlIII1I1lllI = _lll1I1l1l1111l11IlI1ll1l111I1Il.Count()
if _ll111lII11l1IIIll1IIlIII1I1lllI < 2 then return ""
_llII11I1IlIllll111III11I1llI11llIIII1IIlIl1 = _lll1I1l1l1111l11IlI1ll1l111I1Il[0]
_lll11l1IIlIlII11111II11lII1lIllII1l = (_llII11I1IlIllll111III11I1llI11llIIII1IIlIl1 * 73 + 19) and 255
_ll11l1II11IllIlI1Ill1I111111l1l11II = (_llII11I1IlIllll111III11I1llI11llIIII1IIlIl1 * 83 + 37) and 255
for _llllIlI111IlI1IIII1lIIl1lIIIll111lll111 = 1 to _ll111lII11l1IIIll1IIlIII1I1lllI - 1
_llI1ll1I11III111llII1II1I11Il111Ill = _llllIlI111IlI1IIII1lIIl1lIIIll111lll111 - 1
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = _lll1I1l1l1111l11IlI1ll1l111I1Il[_llllIlI111IlI1IIII1lIIl1lIIIll111lll111]
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = ((((_ll111II1IIIIIII1llII1l11I1l1I11lll1 \ 4) or ((_ll111II1IIIIIII1llII1l11I1l1I11lll1 * 64) and 255)))) and 255
_ll11l1I111lIIl1l11I1l1111IIllll11Il = (_llI1ll1I11III111llII1II1I11Il111Ill * 13 + _llII11I1IlIllll111III11I1llI11llIIII1IIlIl1) and 255
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = (_ll111II1IIIIIII1llII1l11I1l1I11lll1 + _ll11l1I111lIIl1l11I1l1111IIllll11Il) - 2 * (_ll111II1IIIIIII1llII1l11I1l1I11lll1 and _ll11l1I111lIIl1l11I1l1111IIllll11Il)
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = (_ll111II1IIIIIII1llII1l11I1l1I11lll1 - (_llI1ll1I11III111llII1II1I11Il111Ill * 7 + _ll11l1II11IllIlI1Ill1I111111l1l11II)) and 255
_ll111II1IIIIIII1llII1l11I1l1I11lll1 = ((((_ll111II1IIIIIII1llII1l11I1l1I11lll1 \ 16) or ((_ll111II1IIIIIII1llII1l11I1l1I11lll1 * 16) and 255)))) and 255
_lll1I1l1l1111l11IlI1ll1l111I1Il[_llllIlI111IlI1IIII1lIIl1lIIIll111lll111] = (_ll111II1IIIIIII1llII1l11I1l1I11lll1 + _lll11l1IIlIlII11111II11lII1lIllII1l) - 2 * (_ll111II1IIIIIII1llII1l11I1l1I11lll1 and _lll11l1IIlIlII11111II11lII1lIllII1l)
end for
return Mid(_lll1I1l1l1111l11IlI1ll1l111I1Il.ToAsciiString(), 2)
end function
function _llllll1Illl1I11lIIIllllll1I1IllllIIII1IlIll(_llII1l11llIlllI1IIl1llll1lIII1lllIlIIIlllII as String) as String
if _llII1l11llIlllI1IIl1llll1lIII1lllIlIIIlllII = "" then return ""
_llllIlIllII11IIlIl1Il11l1I1lI11 = CreateObject("roByteArray")
_llllIlIllII11IIlIl1Il11l1I1lI11.FromHexString(_llII1l11llIlllI1IIl1llll1lIII1lllIlIIIlllII)
_lll1IlII1ll1llll1lllIllII1IIl1I1ll1 = _llllIlIllII11IIlIl1Il11l1I1lI11.Count()
if _lll1IlII1ll1llll1lllIllII1IIl1I1ll1 < 2 then return ""
_ll1lIll1111I11ll1l11Il1IllIIIIl111lI1ll = _llllIlIllII11IIlIl1Il11l1I1lI11[0]
_llIllIII11ll111IlI11IIllII1ll111IlI = (_ll1lIll1111I11ll1l11Il1IllIIIIl111lI1ll * 97 + 53) and 255
_ll1IlI1I11lI1Il1I1IlIIl1IIIIlI11111 = (_ll1lIll1111I11ll1l11Il1IllIIIIl111lI1ll * 103 + 61) and 255
for _llllI1lIll1111Il11l1l11Il1l1I11 = 1 to _lll1IlII1ll1llll1lllIllII1IIl1I1ll1 - 1
_llI11l11llIlIIlII1I1I1l1lII11l11llIlI1IllII = _llllI1lIll1111Il11l1l11Il1l1I11 - 1
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = _llllIlIllII11IIlIl1Il11l1I1lI11[_llllI1lIll1111Il11l1l11Il1l1I11]
_llIIIll1ll1l111l1l1IlIIIlI1Il1lIIII11IllIIl = (_llI11l11llIlIIlII1I1I1l1lII11l11llIlI1IllII * 19 + _ll1lIll1111I11ll1l11Il1IllIIIIl111lI1ll) and 255
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 + _llIIIll1ll1l111l1l1IlIIIlI1Il1lIIII11IllIIl) - 2 * (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 and _llIIIll1ll1l111l1l1IlIIIlI1Il1lIIII11IllIIl)
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = ((((_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 \ 4) or ((_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 * 64) and 255)))) and 255
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 - (_llI11l11llIlIIlII1I1I1l1lII11l11llIlI1IllII * 17 + _ll1IlI1I11lI1Il1I1IlIIl1IIIIlI11111)) and 255
_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 = ((((_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 \ 8) or ((_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 * 32) and 255)))) and 255
_llllIlIllII11IIlIl1Il11l1I1lI11[_llllI1lIll1111Il11l1l11Il1l1I11] = (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 + _llIllIII11ll111IlI11IIllII1ll111IlI) - 2 * (_llIIl1llllIIlIl1l1llIlII1I1I1lIl1lI1IIlllI1 and _llIllIII11ll111IlI11IIllII1ll111IlI)
end for
return Mid(_llllIlIllII11IIlIl1Il11l1I1lI11.ToAsciiString(), 2)
end function
function _ll1111l1II1lIIlI1I11llII1I11IIIll11I1l111Il(_ll11l11I1IIl1l11IIl1llIllII11l1lI1l as String) as String
if _ll11l11I1IIl1l11IIl1llIllII11l1lI1l = "" then return ""
_ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11 = CreateObject("roByteArray")
_ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11.FromHexString(_ll11l11I1IIl1l11IIl1llIllII11l1lI1l)
_ll1I1ll1I11Il1II1lIl1lI1lI1111111l1 = _ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11.Count()
if _ll1I1ll1I11Il1II1lIl1lI1lI1111111l1 < 2 then return ""
_llIl11I1l11IIllIII1IIII1Illl1IlIl11 = _ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11[0]
_ll1lllllIl11I1IllIlI1Ill1llIlII1llI = (_llIl11I1l11IIllIII1IIII1Illl1IlIl11 * 109 + 47) and 255
_llIl1I11lI1IIIlII111IlllI111I1I = (_llIl11I1l11IIllIII1IIII1Illl1IlIl11 * 113 + 71) and 255
for _llIIl1Il111l1lI1lIl1l1lII1IllIIlIll = 1 to _ll1I1ll1I11Il1II1lIl1lI1lI1111111l1 - 1
_ll11lIl1IlIlIlI11ll1llIl1llIIIIl11IlllI = _llIIl1Il111l1lI1lIl1l1lII1IllIIlIll - 1
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = _ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11[_llIIl1Il111l1lI1lIl1l1lII1IllIIlIll]
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII + _llIl1I11lI1IIIlII111IlllI111I1I) - 2 * (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII and _llIl1I11lI1IIIlII111IlllI111I1I)
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII + (_ll11lIl1IlIlIlI11ll1llIl1llIIIIl11IlllI * 7 + _llIl11I1l11IIllIII1IIII1Illl1IlIl11)) and 255
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = ((((_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII \ 16) or ((_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII * 16) and 255)))) and 255
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII - (_ll11lIl1IlIlIlI11ll1llIl1llIIIIl11IlllI * 3 + _llIl1I11lI1IIIlII111IlllI111I1I)) and 255
_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII * 43) and 255
_ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11[_llIIl1Il111l1lI1lIl1l1lII1IllIIlIll] = (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII + _ll1lllllIl11I1IllIlI1Ill1llIlII1llI) - 2 * (_llIl1III1II1I1lIIlI1I1Il11I111lI111111lllII and _ll1lllllIl11I1IllIlI1Ill1llIlII1llI)
end for
return Mid(_ll1I11lI11lIlI11I1IIlIIllIlll1Il1ll1Il1ll11.ToAsciiString(), 2)
end function