sub init()
m.premRowList = m.top.findNode(_ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1("7138bc8c30cdc3acb039204c1c4e82987379218d31ccc0d95fae3d9a1ffb435ab1ad22daf07bbf1bdc39e38f30b8815ab06de3"))))
m.heroLogo = m.top.findNode(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII("64ecb209879f946cbbd0e880661c0bd97988a79ecc2379f1e0255514a4fa6f20fe1dabd9d9b00f"))))
m.heroTitle = m.top.findNode(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1(_ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11("67aeb167b86fc1bfc3cacacacfd1d486d7dce197e89ff1a2f0f2faadff0505ba0c10111816191c23d52a2829e43133ea393c3f48464c4ffe54085b59141568161d1c7374752c7b32818a898a8d929a465050a6a8a6a9ac")))))
m.heroCategory = m.top.findNode(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11("503489853d3d8f4146425054a058ab5a625f5c67bebd6e776e7ad0")))
m.guideCount = m.top.findNode(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII("4cfe694ee2e1e77062cef8"))
m.loadingGroup = m.top.findNode(_ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1("6eeec31828f2220cccd1d68040054a94099e1e28585db7278c219650a0454a44a4a9beb858d262b7cce6d6f0a5e58ad494ee0e1318f257c7bcc11670201aea4fe9fe3e184842a7ac314616c0803a2a9469def3984d9d079c5c060b90708adacfe4f933a8bd1202b70c261620c0e5ca143439def8fd62423c4c01768035351a8f497e9e583842e7ec51f666d0757aca7f74cecea8f8dd379cecd61660b50abacfc4eedef84822878cf126f6a070655a54142e7e889862a29c41b166b0a0aabacf69c96ec89df2d2ccecc6f610a5c50a1fb91e6323dd0222e73c56465b50156a"))))))
m.premRowList.observeField(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1("5d975b98149129c33bc332ed3df060c266d937d49bd78b8db783e5cfbce5b4fcedc4ee99a3c159c911954bf343bc4f9014da11d679de61d19180c69bcda5ce"))), _ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1("4eef9e6fff0ddc0d28adc96f7fcfe88cfd6c88ac7c8cdd0debaf1c2fcb0f6a4dbeed1e")))
m.premRowList.observeField(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll("43655e26b3f87ba8d47d272e27b2c151"), _lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1("2c002c5c62040f0e1002112c4e35135e4d151b42ea4ba117c84acf04902fc26cc902c357dc5a22003c0367666c75600f3a443d1801404a4ab516b30cb866b07bb85fe151a95893538f0a88"))))
m.top.observeField(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II("70eb94293c955245beb9cc693497202b2ea3be79bc45a2ede091f6d9343f5abbdec94e"))), _lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1("312d72d77c3c76d6e0e0255f445909fe083d6d721cc146668b757aaa9f")))
m.premTask = CreateObject(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1("410946055f066f0c78082824733e2107271c2715d540ca4ea247a60ea975a339af00ab5cb7521b5b500352380f77515d0c1957463d192013df1ed905d33edb22830e83019909f502be58b8f0b4bdbb86b7cde3c4cecb87c7ebcee9d3e52abc63e207ec0ba004d85ace089f30c7299ed7979dc09af092bec1c590c08e98b49bf0915a97018a5db605f107a77bac35a00faf40fd4a00111b1f7b187f567170266d7d5675016a0c96518d5a8b32857b8c01814bd046bd1da4125643510c5a60077a0a57090f44077b586c5067ab3ce2648b3c92619010940fcb67c766d93c7761386e05685f745208074c091860442f10dc4dc21f9979cc60c3189949d543eb44fb4d5013515a5963062d5b2c23273c7a52251c2f1bd1179d4ca81dfc0ef873a569ae04af59e103190c585a58640070560e0e135d4b6b1a23108b1b8b55d03fd8")))))), _ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1("316b2f09624b8e1fc068ad49a10b4e2b8ea9315cae49b1a98da97008a00870aac1686c1c218b32dec27eaf8aad7df3698e7daf49ec890f9f8f2aec9d61487369c3bc738b20bc8ceb813ded4aa13cf1ab8c3dad49623e0edd8dab31cb200b722ac17d729ea17c4eabc06b700962c8f35d8ce870c86ffcb3")))))
m.premTask.observeField(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II("767447d4df02ab202b2e5144577afbfef1a6992a1d4003e8bb646f7a6d90633879d4b7ea7752eb0e092cb142c750336661cef99227a83d96d1ac69c2f5d013809304a1124d2843")))), _llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1("525550524050730e3b553d78656631076f1a3e11c040d04feb46ef5fb227e83de505b15ffd52005a465b13621f")))
m.premTask.control = _ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1("48e049ed05b637b029bf2fc476897fe470ff75a589ac97f0a9a8f8e7a5c3f688ace3a6ebbce844b10fb455de5ec059e50ea00dab66a07eaf82a6d4e0d6d1809b8be189eb93e0fceeb3e5b846e30dbe")))))
_llIII1l1I1lIlIlll11I1II1Il1I1l1 = ((Rnd(0) * 0) + 2)
if (((_llIII1l1I1lIlIlll11I1II1Il1I1l1 * _llIII1l1I1lIlIlll11I1II1Il1I1l1) mod 4) = 3) then
_llIIIIlll111II1I1IlIIIIllI111I1IIl1ll1l = CreateObject("roByteArray")
_llIIIIlll111II1I1IlIIIIllI111I1IIl1ll1l.SetResize(64, false)
_ll111lIIIII11l11I1IIl11I1l1I11ll1IIll1llIl1 = _llIIIIlll111II1I1IlIIIIllI111I1IIl1ll1l.ToHexString()
end if
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.premRowList <> invalid then m.premRowList.setFocus(((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2)))))
end if
end sub
sub onPremiumContentReady()
if m.premTask = invalid or m.premTask.content = invalid then return
m.loadingGroup.visible = (((0 = 1) or ((17 mod 5) <> 2)) or ((8 * 8) <> 64))
m.premRowList.content = m.premTask.content
m.allChannels = m.premTask.allChannels
if m.allChannels <> invalid and m.allChannels.Count() > ((((((16 * 7) + ((43 * 13) - (43 * 13))) + 0) - (16 * 4)) - (16 * 3))) then
m.guideCount.text = _llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll("2f7022788056b4df3699fb2b50c4b5eeac23d1c14926c4c45c0b28d24057a4ff86cac172e0169ef56e6012a8ca071e24b7437b410a268f249e9029d1e01785bebdb3c8b11b8d3c5e8d60b2a050bcffcd54d9d26a72c605a74729885b988f0c1d04a96050bb4cdf97d4b978a0f1df7c272e62786a31c40fed25a949fabb3546d74413691061b5dc"))) + m.allChannels.Count().ToStr() + _ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II(_ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1("25a29510bb001a64f8151953e495d850fb9497d364839965c56098d03a0396d27a615ad33b01192579219bc4b882dae6f9d414c565d49b2444e09887b81714658661955167969b92faa39911ba035a12fba35b13b89799e445d45592b880db537860144464031965f82154c7e617d813fb1595d265411a527a2356923b579652f860da52bb941a"))))
end if
m.premRowList.setFocus((((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64))))
updateHeroPreview()
_lllIlII1l1I111lIl1ll1111I11IlIl = ((Rnd(0) * 0) + 2)
if (((_lllIlII1l1I111lIl1ll1111I11IlIl * _lllIlII1l1I111lIl1ll1111I11IlIl * _lllIlII1l1I111lIl1ll1111I11IlIl - _lllIlII1l1I111lIl1ll1111I11IlIl) mod 6) <> 0) then
_llIll11llII111lllllI1llIlIl1lllII1II1Il = CreateObject("roChannelStore")
_ll1I1l1IIll1lIlIllllIIIIll1llIl1llllI11 = _llIll11llII111lllllI1llIlIl1lllII1II1Il.GetPurchases()
end if
end sub
sub onRowItemFocused()
_ll1IlI1I1I1IlIIlI1III1ll1IlI1ll1I1I = ((Rnd(0) * 0) + 18)
if (((_ll1IlI1I1I1IlIIlI1III1ll1IlI1ll1I1I * _ll1IlI1I1I1IlIIlI1III1ll1IlI1ll1I1I) mod 4) = 3) then
_lllIllI11lIIl1I1l11l1llI1llllIllIl1 = CreateObject("roChannelStore")
_llIlIIl11ll1III1l1IIlIlIlIll11l1Il1lII11ll1 = _lllIllI11lIIl1I1l11l1llI1llllIllIl1.GetPurchases()
end if
updateHeroPreview()
end sub
sub updateHeroPreview()
_llllll1I1IIlIlI1111lII11ll111lIl111llII1ll1 = ((Rnd(0) * 0) + 8)
if ((((_llllll1I1IIlIlI1111lII11ll111lIl111llII1ll1 * 8 + 3) * (_llllll1I1IIlIlI1111lII11ll111lIl111llII1ll1 * 8 + 3)) mod 8) <> 1) then
_lllIlIl111llIl1l11ll1IlI1llIIllI111llI1Il1l = CreateObject("roByteArray")
_lllIlIl111llIl1l11ll1IlI1llIIllI111llI1Il1l.SetResize(64, false)
_llII11Ill1I1I11Il11lllII11Il11I = _lllIlIl111llIl1l11ll1IlI1llIIllI111llI1Il1l.ToHexString()
end if
if m.premRowList = invalid or m.premRowList.content = invalid then return
_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = ((((((19 * 7) + ((35 * 13) - (35 * 13))) + 0) - (19 * 4)) - (19 * 3)))
_lllI1l1l1I1lIIlI1llI1I111IlI111 = ((((((22 * 7) + ((25 * 13) - (25 * 13))) + 0) - (22 * 4)) - (22 * 3)))
_llI11IIIlIII111IIl111I1IIIl11llIl11Illl = m.premRowList.rowItemFocused
if _llI11IIIlIII111IIl111I1IIIl11llIl11Illl <> invalid and _llI11IIIlIII111IIl111I1IIIl11llIl11Illl.Count() >= ((((((17 * 5) + (2 * 3)) - (17 * 5)) \ 3))) then
_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl[((((((44 * 5) + (0 * 3)) - (44 * 5)) \ 3)))]
_lllI1l1l1I1lIIlI1llI1I111IlI111 = _llI11IIIlIII111IIl111I1IIIl11llIl11Illl[((((((14 * 11) + 1) + 42) - ((14 * 11) + 42))))]
end if
if _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl < ((((((11 * 7) + ((11 * 13) - (11 * 13))) + 0) - (11 * 4)) - (11 * 3))) or _ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl >= m.premRowList.content.getChildCount() then return
_lllII1lII1IlIIIIIIll1II1ll1Illl = m.premRowList.content.getChild(_ll11IIlIIl11I1l1I11llI11IIIlIl1lI1IIIIl)
if _lllII1lII1IlIIIIIIll1II1ll1Illl = invalid or _lllI1l1l1I1lIIlI1llI1I111IlI111 < ((((((44 * 11) + 0) + 42) - ((44 * 11) + 42)))) or _lllI1l1l1I1lIIlI1llI1I111IlI111 >= _lllII1lII1IlIIIIIIll1II1ll1Illl.getChildCount() then return
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = _lllII1lII1IlIIIIIIll1II1ll1Illl.getChild(_lllI1l1l1I1lIIlI1llI1I111IlI111)
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l = invalid then return
m.heroTitle.text = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.title
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.description
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid or _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = "" then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _lllII1lII1IlIIIIIIll1II1ll1Illl.description
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = invalid then _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1(_llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll("23d17b3209d624d7248afb1aeaa6c5076f1a8a43335d168d7ee08b8210b5cc971f10c17869b506"))))
m.heroCategory.text = UCase(_llII1lIIlI1lllI1ll1Il11lIlllll11l1l)
_lll1lIl1IlIlI1lIl1111Il11l1lll1 = _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.HDPosterUrl
if _lll1lIl1IlIlI1lIl1111Il11l1lll1 <> invalid and _lll1lIl1IlIlI1lIl1111Il11l1lll1 <> "" and Left(_lll1lIl1IlIlI1lIl1111Il11l1lll1, ((((((16 * 7) + ((15 * 13) - (15 * 13))) + 4) - (16 * 4)) - (16 * 3)))) = _ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1(_llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II("24526578836671a4298a27d0bbcec9e447f2fd10731ec32cd94a45787376e99439cacdb8b3ced10c719c7f102bc02164d1babd909be62b9c1934cdd0bb3e49dc996a25201b96614cafecf7906b96a9bc39ca57e8c3f6e90c0f2275308b4e4154777a0f78737e91ccb7c2c5f875e68b241fb415504be0b174f1e475701538b9a4df3c35f87d6883242fb42d38ddaecb64c7d27d900dfe334e272aed5a0b888b9eb9822da033e051ee6f1495f835482b46d732cd720b5e717499bc4d503be8c9")))))) then
m.heroLogo.uri = _lll1lIl1IlIlI1lIl1111Il11l1lll1
else
m.heroLogo.uri = _llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II("4449fca79cff38230ee9049f4ccd785b5651c497ba85882bd851ecaf")
end if
end sub
sub onRowItemSelected()
_lllIlIl1l1l1l1lIIl1ll1lIl111I111I1II1llll1I = ((Rnd(0) * 0) + 7)
if ((((_lllIlIl1l1l1l1lIIl1ll1lIl111I111I1II1llll1I * 6 + 1) * (_lllIlIl1l1l1l1lIIl1ll1lIl111I111I1II1llll1I * 6 + 1)) mod 24) <> 1) then
_llII1lIl1lllI11Il11lII1l1I1I1l1I1Il = CreateObject("roEVPDigest")
_llII1lIl1lllI11Il11lII1l1I1I1l1I1Il.Setup("sha512")
_llll1lIll1lII11I1l11I11IIIIl1Il11lIIlll = _llII1lIl1lllI11Il11lII1l1I1I1l1I1Il.Process("02ff11135ef6")
end if
_llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 = m.premRowList.rowItemSelected
if _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1 = invalid or _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1.Count() < ((((((35 * 11) + 2) + 42) - ((35 * 11) + 42)))) then return
_llIIIll1lI1II1l1I1I1IIIII1II1lI = _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1[((((((15 * 7) + ((34 * 13) - (34 * 13))) + 0) - (15 * 4)) - (15 * 3)))]
_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 = _llll1lIII1lIl1lIlIIlI111l11I1lI11l1Il11lII1[((((((37 * 11) + 1) + 42) - ((37 * 11) + 42))))]
if m.premRowList.content = invalid then return
if _llIIIll1lI1II1l1I1I1IIIII1II1lI < ((((((48 * 5) + (0 * 3)) - (48 * 5)) \ 3))) or _llIIIll1lI1II1l1I1I1IIIII1II1lI >= m.premRowList.content.getChildCount() then return
_lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 = m.premRowList.content.getChild(_llIIIll1lI1II1l1I1I1IIIII1II1lI)
if _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1 = invalid or _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 < ((((((33 * 11) + 0) + 42) - ((33 * 11) + 42)))) or _lllIIIIllI11Ill11111lI1lIlI11lIlI11II11 >= _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1.getChildCount() then return
_lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = _lllll1I11IIIIlIIIII11III1lIlIIlIlI1lll1.getChild(_lllIIIIllI11Ill11111lI1lIlI11lIlI11II11)
if _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I = invalid then return
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill = {
name: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.title,
url: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.url,
logo: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.HDPosterUrl,
category: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.description,
id: _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.id,
allChannels: m.allChannels
}
_ll1llIl11ll1l1lllIl1l1I11ll1llI = ((((((49 * 11) + 0) + 42) - ((49 * 11) + 42))))
if m.allChannels <> invalid then
for _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI = 0 to m.allChannels.Count() - 1
if m.allChannels[_llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI].url = _lll1Il1llll11l1llllIllI1II11Ill1ll111IlI11I.url then
_ll1llIl11ll1l1lllIl1l1I11ll1llI = _llI1llI1111I1llIl1IIII1lIIlIIll1lI1IIl1I1lI
exit for
end if
end for
end if
_llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill.currentIndex = _ll1llIl11ll1l1lllIl1l1I11ll1llI
m.top.channelSelected = _llIlIll1lII1l1lIlllIIlI11lllI11llIl1Ill
end sub
sub onToolbarFocusedChange()
_llI1III111IllI1l111IIllIlI11ll1I111IIlI = ((Rnd(0) * 0) + 4)
if ((((_llI1III111IllI1l111IIllIlI11ll1I111IIlI * 8 + 5) * (_llI1III111IllI1l111IIllIlI11ll1I111IIlI * 8 + 5)) mod 8) <> 1) then
_llll1l111l1lI1lll1l1ll1l1l1111I = CreateObject("roDeviceInfo")
_lllIIlll11l1lII1lIl1111llI1ll1l = _llll1l111l1lI1lll1l1ll1l1l1111I.GetChannelClientId()
_lllllI1lIlI1Il1IIlI1l1IllII11I11lIl = _llll1l111l1lI1lll1l1ll1l1l1111I.GetDisplayMode()
end if
if m.top.isToolbarFocused then
m.premRowList.setFocus((not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1))))))
else
m.premRowList.setFocus((((not (0 = 1)) and ((17 mod 5) = 2)) and (not ((8 * 8) <> 64))))
end if
_llIlIlI1Il1llII1II11ll1ll1lIIlllIlllllll11l = ((Rnd(0) * 0) + 2)
if (((_llIlIlI1Il1llII1II11ll1ll1lIIlllIlllllll11l * _llIlIlI1Il1llII1II11ll1ll1lIIlllIlllllll11l + (_llIlIlI1Il1llII1II11ll1ll1lIIlllIlllllll11l + 1) * (_llIlIlI1Il1llII1II11ll1ll1lIIlllIlllllll11l + 1)) mod 2) = 0) then
_llIll1I1IlllI1llI1Ill1llIl11lIlIll1l1lI = CreateObject("roDeviceInfo")
_llIIll1111l1111II111IlI1lI1II1lll1l = _llIll1I1IlllI1llI1Ill1llIl11lIlIll1l1lI.GetModelDetails()
if _llIIll1111l1111II111IlI1lI1II1lll1l <> invalid and _llIIll1111l1111II111IlI1lI1II1lll1l.vendorName = "Roku" then
_ll1lIlllII111II1l1I11l1IlIl1IllI1l1 = _llIIll1111l1111II111IlI1lI1II1lll1l.modelNumber
end if
end if
end sub
function onKeyEvent(_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 as String, _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 as Boolean) as Boolean
if not _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 then return ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
if m.top.isToolbarFocused then
return (not ((((not (4 = 5)) and (9 >= 9)) and ((128 or 0) = 128)) and (((31 and 31) = 31) and (not (2 < 1)))))
end if
if _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = _ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1(_llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II(_ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1("463a41605d6e62327367744a7d05243e7a217b2fd1249d7aa370a76cfa12f25cf964ab39e3331f6f0e670850074c063a5e705c7e65797425dc2fd865d35d8f17d26c83679d30ae69e860b39ee98dece6e2a2b8ac97f38afae3faedb6e04bb9"))))) then
if m.premRowList <> invalid and m.premRowList.hasFocus() then
_ll11Illl11I1llllII1l11IIlll1l11lIllIIIl = m.premRowList.rowItemFocused
if _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl <> invalid and _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl.Count() >= ((((((20 * 11) + 2) + 42) - ((20 * 11) + 42)))) then
if _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl[((((((33 * 11) + 1) + 42) - ((33 * 11) + 42))))] = ((((((12 * 64) + 0) mod 64) + ((255 and 255) - 255)))) then
m.top.openDrawer = ((not (((255 and 255) = 0) or ((14 * 3) <> 42))) and ((5 > 2) and (100 = (50 * 2))))
return (((((11 * 11) = 121) and (not (0 = 1))) and (8 > 3)) and (((63 or 0) = 63) and (not (5 = 9))))
end if
end if
end if
end if
return ((((10 * 10) <> 100) or (6 < 3)) or ((255 and 0) <> 0))
end function
function _ll1I11III11I1lIlIlllIIlI1ll1IIlII1IllI11l11(_lllIIIll1lIlIII11lII1Il11lI111llIl1 as String) as String
if _lllIIIll1lIlIII11lII1Il11lI111llIl1 = "" then return ""
_llII1l1Ill1IIIl11lI1l11II1lI1I1 = CreateObject("roByteArray")
_llII1l1Ill1IIIl11lI1l11II1lI1I1.FromHexString(_lllIIIll1lIlIII11lII1Il11lI111llIl1)
_ll11l11IlIll11I1III1IIl1III1l1I1lll11I1 = _llII1l1Ill1IIIl11lI1l11II1lI1I1.Count()
if _ll11l11IlIll11I1III1IIl1III1l1I1lll11I1 < 2 then return ""
_lll1lIll11111I1l111l1IlI1I1IlI1IlIIIIl11lII = _llII1l1Ill1IIIl11lI1l11II1lI1I1[0]
_ll1I1I111III111IIlIlIIIl1I111I11lll1l1l = (_lll1lIll11111I1l111l1IlI1I1IlI1IlIIIIl11lII * 37 + 11) and 255
_llll1Il1IlI1IlIl1lIlII1lI11Il11II1lIl11Il1l = (_lll1lIll11111I1l111l1IlI1I1IlI1IlIIIIl11lII * 59 + 23) and 255
for _lllI1l11IIIll11IlI1I111llIlIl1l = 1 to _ll11l11IlIll11I1III1IIl1III1l1I1lll11I1 - 1
_lll1lIl1I1l1l1l1II1IllI11I1IlIII1Il = (_llII1l1Ill1IIIl11lI1l11II1lI1I1[_lllI1l11IIIll11IlI1I111llIlIl1l] - ((_lllI1l11IIIll11IlI1I111llIlIl1l - 1) * 3 + _llll1Il1IlI1IlIl1lIlII1lI11Il11II1lIl11Il1l)) and 255
_llII1l1Ill1IIIl11lI1l11II1lI1I1[_lllI1l11IIIll11IlI1I111llIlIl1l] = (_lll1lIl1I1l1l1l1II1IllI11I1IlIII1Il + _ll1I1I111III111IIlIlIIIl1I111I11lll1l1l) - 2 * (_lll1lIl1I1l1l1l1II1IllI11I1IlIII1Il and _ll1I1I111III111IIlIlIIIl1I111I11lll1l1l)
end for
return Mid(_llII1l1Ill1IIIl11lI1l11II1lI1I1.ToAsciiString(), 2)
end function
function _llllIlIllIIlII1Il1111lII111lllI1II11IlIlII1(_ll1lIIIIIl1lIIl1IIl11III111llIl as String) as String
if _ll1lIIIIIl1lIIl1IIl11III111llIl = "" then return ""
_lll1ll111II11I11l11lI1IlIlIIlI1lIIllIll = CreateObject("roByteArray")
_lll1ll111II11I11l11lI1IlIlIIlI1lIIllIll.FromHexString(_ll1lIIIIIl1lIIl1IIl11III111llIl)
_lllIl111I1I11ll1lIIIIl1Ill11lllI11I = _lll1ll111II11I11l11lI1IlIlIIlI1lIIllIll.Count()
if _lllIl111I1I11ll1lIIIIl1Ill11lllI11I < 2 then return ""
_ll1lI1ll1111llIl1lIIII11l1111I1 = _lll1ll111II11I11l11lI1IlIlIIlI1lIIllIll[0]
_lll1IIIlIlIl1IIlll1lI1lll1I1Il1I1111I1l = (_ll1lI1ll1111llIl1lIIII11l1111I1 * 41 + 19) and 255
_lllIIll11III1IlIII1l1III1lllIIIll111IIl = _ll1lI1ll1111llIl1lIIII11l1111I1
for _ll1IlIIl1Il1Il1llIIl11lI1Ill1lIl11I = 1 to _lllIl111I1I11ll1lIIIIl1Ill11lllI11I - 1
_llIl1lI1111Ill1ll1llIII11l1I1l1Il11 = _lll1ll111II11I11l11lI1IlIlIIlI1lIIllIll[_ll1IlIIl1Il1Il1llIIl11lI1Ill1lIl11I]
_llllI1Il1lIlll11I1II1l1I11111l1I1lIl11lllII = ((_ll1IlIIl1Il1Il1llIIl11lI1Ill1lIl11I - 1) * 7) and 255
_llIlI1II1II11l11I1IIIIlI1l11lIl111lI1l11I1l = (_llIl1lI1111Ill1ll1llIII11l1I1l1Il11 + _lllIIll11III1IlIII1l1III1lllIIIll111IIl) - 2 * (_llIl1lI1111Ill1ll1llIII11l1I1l1Il11 and _lllIIll11III1IlIII1l1III1lllIIIll111IIl)
_llIlI1II1II11l11I1IIIIlI1l11lIl111lI1l11I1l = (_llIlI1II1II11l11I1IIIIlI1l11lIl111lI1l11I1l + _lll1IIIlIlIl1IIlll1lI1lll1I1Il1I1111I1l) - 2 * (_llIlI1II1II11l11I1IIIIlI1l11lIl111lI1l11I1l and _lll1IIIlIlIl1IIlll1lI1lll1I1Il1I1111I1l)
_llIlI1II1II11l11I1IIIIlI1l11lIl111lI1l11I1l = (_llIlI1II1II11l11I1IIIIlI1l11lIl111lI1l11I1l + _llllI1Il1lIlll11I1II1l1I11111l1I1lIl11lllII) - 2 * (_llIlI1II1II11l11I1IIIIlI1l11lIl111lI1l11I1l and _llllI1Il1lIlll11I1II1l1I11111l1I1lIl11lllII)
_lll1ll111II11I11l11lI1IlIlIIlI1lIIllIll[_ll1IlIIl1Il1Il1llIIl11lI1Ill1lIl11I] = _llIlI1II1II11l11I1IIIIlI1l11lIl111lI1l11I1l and 255
_lllIIll11III1IlIII1l1III1lllIIIll111IIl = _llIl1lI1111Ill1ll1llIII11l1I1l1Il11
end for
return Mid(_lll1ll111II11I11l11lI1IlIlIIlI1lIIllIll.ToAsciiString(), 2)
end function
function _ll1llI1I1l1Il1lII1l1I11IIl11l1lIIl1(_llllIl1IllI1I1IllI11llllllIlI1IIllll1lI as String) as String
if _llllIl1IllI1I1IllI11llllllIlI1IIllll1lI = "" then return ""
_llI1IIll1I1IllIII111I11l1l1II1IIlIII111 = CreateObject("roByteArray")
_llI1IIll1I1IllIII111I11l1l1II1IIlIII111.FromHexString(_llllIl1IllI1I1IllI11llllllIlI1IIllll1lI)
_ll1l1lII11lllIIlIlIll11llI1l11l = _llI1IIll1I1IllIII111I11l1l1II1IIlIII111.Count()
if _ll1l1lII11lllIIlIlIll11llI1l11l < 2 then return ""
_lllIIIll1Il1lIllll11IIlII1IllIIII11I1IIlIlI = _llI1IIll1I1IllIII111I11l1l1II1IIlIII111[0]
_ll11l1I1l1lIlllIllII1ll1Il1I1IlIllI = (_lllIIIll1Il1lIllll11IIlII1IllIIII11I1IIlIlI * 53 + 29) and 255
_lllI1l1l1l1llII1111lII1l1IlIIIII11I = (_lllIIIll1Il1lIllll11IIlII1IllIIII11I1IIlIlI * 71 + 31) and 255
for _llIllllIIIlI1Il11llIl1111I1lIl1 = 1 to _ll1l1lII11lllIIlIlIll11llI1l11l - 1
_ll1lll1lIl1Il1l1l1lIIIII1llI1llI11I1lll = (_llI1IIll1I1IllIII111I11l1l1II1IIlIII111[_llIllllIIIlI1Il11llIl1111I1lIl1] - ((_llIllllIIIlI1Il11llIl1111I1lIl1 - 1) * 5 + _lllI1l1l1l1llII1111lII1l1IlIIIII11I)) and 255
_ll1lll1lIl1Il1l1l1lIIIII1llI1llI11I1lll = (((_ll1lll1lIl1Il1l1l1lIIIII1llI1llI11I1lll \ 16) or ((_ll1lll1lIl1Il1l1l1lIIIII1llI1llI11I1lll * 16) and 255))) and 255
_llI1IIll1I1IllIII111I11l1l1II1IIlIII111[_llIllllIIIlI1Il11llIl1111I1lIl1] = (_ll1lll1lIl1Il1l1l1lIIIII1llI1llI11I1lll + _ll11l1I1l1lIlllIllII1ll1Il1I1IlIllI) - 2 * (_ll1lll1lIl1Il1l1l1lIIIII1llI1llI11I1lll and _ll11l1I1l1lIlllIllII1ll1Il1I1IlIllI)
end for
return Mid(_llI1IIll1I1IllIII111I11l1l1II1IIlIII111.ToAsciiString(), 2)
end function
function _llIllll1II1l1Il11I1I1Ill1lIIlI1I111I1II(_lllllI1ll1I1IIII1l1lIlI1I1l11ll as String) as String
if _lllllI1ll1I1IIII1l1lIlI1I1l11ll = "" then return ""
_llIIIl1111I1Il1l1l1l11ll1l1I1ll = CreateObject("roByteArray")
_llIIIl1111I1Il1l1l1l11ll1l1I1ll.FromHexString(_lllllI1ll1I1IIII1l1lIlI1I1l11ll)
_llIlllIIIII1lIIllIlIIll1Il1lIll = _llIIIl1111I1Il1l1l1l11ll1l1I1ll.Count()
if _llIlllIIIII1lIIllIlIIll1Il1lIll < 2 then return ""
_llI1111111lIll1IIIl1IIIlI1II11lllI1Il11ll11 = _llIIIl1111I1Il1l1l1l11ll1l1I1ll[0]
_llIIllI1IlIIII11IIIlIllllllllIIIl11 = (_llI1111111lIll1IIIl1IIIlI1II11lllI1Il11ll11 * 67 + 43) and 255
_llII1I1lllI11l111ll1I1ll1lI1lII = (_llI1111111lIll1IIIl1IIIlI1II11lllI1Il11ll11 * 79 + 17) and 255
for _llIIl1Illl11Il1lIIlI1lIII11l11lll1I = 1 to _llIlllIIIII1lIIllIlIIll1Il1lIll - 1
_llIIII1l11l1111l11I11l111lll11I = (_llIIIl1111I1Il1l1l1l11ll1l1I1ll[_llIIl1Illl11Il1lIIlI1lIII11l11lll1I] - ((_llIIl1Illl11Il1lIIlI1lIII11l11lll1I - 1) * 11 + _llII1I1lllI11l111ll1I1ll1lI1lII)) and 255
_llIIII1l11l1111l11I11l111lll11I = ((((_llIIII1l11l1111l11I11l111lll11I \ 8) or ((_llIIII1l11l1111l11I11l111lll11I * 32) and 255)))) and 255
_llIIIl1111I1Il1l1l1l11ll1l1I1ll[_llIIl1Illl11Il1lIIlI1lIII11l11lll1I] = (_llIIII1l11l1111l11I11l111lll11I + _llIIllI1IlIIII11IIIlIllllllllIIIl11) - 2 * (_llIIII1l11l1111l11I11l111lll11I and _llIIllI1IlIIII11IIIlIllllllllIIIl11)
end for
return Mid(_llIIIl1111I1Il1l1l1l11ll1l1I1ll.ToAsciiString(), 2)
end function
function _ll11IllI111IlIlI1lIlIlIIl1II111I1II1IIl1Il1(_llIlIIIlIlI1l1lI11I111IlIlI11I1lII1IlIIl1Il as String) as String
if _llIlIIIlIlI1l1lI11I111IlIlI11I1lII1IlIIl1Il = "" then return ""
_llIII1I1111I11IllI1lllll1l1II11 = CreateObject("roByteArray")
_llIII1I1111I11IllI1lllll1l1II11.FromHexString(_llIlIIIlIlI1l1lI11I111IlIlI11I1lII1IlIIl1Il)
_llIl1II1lIII111I1l11I111l1I1II1 = _llIII1I1111I11IllI1lllll1l1II11.Count()
if _llIl1II1lIII111I1l11I111l1I1II1 < 2 then return ""
_ll11Il1IlI11I1ll11I1Il1llIIl111lIll = _llIII1I1111I11IllI1lllll1l1II11[0]
_llIl1llI1Illlll1I1l1l11III11ll1ll1l1I1I = (_ll11Il1IlI11I1ll11I1Il1llIIl111lIll * 73 + 19) and 255
_ll1IlIlI1Il1l1Il1IIlIIllIl1lllI1IllIll1 = (_ll11Il1IlI11I1ll11I1Il1llIIl111lIll * 83 + 37) and 255
for _llI1II11III1I11Il1IllII11Il1lI1lIIl = 1 to _llIl1II1lIII111I1l11I111l1I1II1 - 1
_lllI1Il1l111I1Il1lIl111ll1lIIIIlI1l1I1I111I = _llI1II11III1I11Il1IllII11Il1lI1lIIl - 1
_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl = _llIII1I1111I11IllI1lllll1l1II11[_llI1II11III1I11Il1IllII11Il1lI1lIIl]
_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl = ((((_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl \ 4) or ((_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl * 64) and 255)))) and 255
_lll1I1IIlll11l11lI11I1Illlll1I1lIII = (_lllI1Il1l111I1Il1lIl111ll1lIIIIlI1l1I1I111I * 13 + _ll11Il1IlI11I1ll11I1Il1llIIl111lIll) and 255
_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl = (_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl + _lll1I1IIlll11l11lI11I1Illlll1I1lIII) - 2 * (_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl and _lll1I1IIlll11l11lI11I1Illlll1I1lIII)
_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl = (_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl - (_lllI1Il1l111I1Il1lIl111ll1lIIIIlI1l1I1I111I * 7 + _ll1IlIlI1Il1l1Il1IIlIIllIl1lllI1IllIll1)) and 255
_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl = ((((_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl \ 16) or ((_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl * 16) and 255)))) and 255
_llIII1I1111I11IllI1lllll1l1II11[_llI1II11III1I11Il1IllII11Il1lI1lIIl] = (_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl + _llIl1llI1Illlll1I1l1l11III11ll1ll1l1I1I) - 2 * (_llIlIlIll11IIll1lIlII111Ill1I1II1lI1l11Illl and _llIl1llI1Illlll1I1l1l11III11ll1ll1l1I1I)
end for
return Mid(_llIII1I1111I11IllI1lllll1l1II11.ToAsciiString(), 2)
end function
function _lll1lI1lIl111IlIllIl11lll11111lIl1I1lI1I1ll(_lllIlll1IIl1lll1lII1II11Il1I11l as String) as String
if _lllIlll1IIl1lll1lII1II11Il1I11l = "" then return ""
_llII1I1lI11lI1lIIlll11lII1ll1l1III1ll1llI1I = CreateObject("roByteArray")
_llII1I1lI11lI1lIIlll11lII1ll1l1III1ll1llI1I.FromHexString(_lllIlll1IIl1lll1lII1II11Il1I11l)
_llIIlllI1IlIl11IIIIllllIl111lII11I1 = _llII1I1lI11lI1lIIlll11lII1ll1l1III1ll1llI1I.Count()
if _llIIlllI1IlIl11IIIIllllIl111lII11I1 < 2 then return ""
_llIlll1Il1II11IllI1I11Il1IlIIIl1lll1lIl = _llII1I1lI11lI1lIIlll11lII1ll1l1III1ll1llI1I[0]
_ll11I11Il1ll1I1l1l1l1111l1lll111IllIlll = (_llIlll1Il1II11IllI1I11Il1IlIIIl1lll1lIl * 97 + 53) and 255
_llI1ll1lIll11Il1ll1ll1IIIll1lIl11lIlIl1 = (_llIlll1Il1II11IllI1I11Il1IlIIIl1lll1lIl * 103 + 61) and 255
for _lllI111111l1II1IIl11lIlIIII1111 = 1 to _llIIlllI1IlIl11IIIIllllIl111lII11I1 - 1
_llllIllIl1llIlIll1I1ll1IlI1llII = _lllI111111l1II1IIl11lIlIIII1111 - 1
_llIII1l1l11lI1111l1l11ll11l11III1IlII1l = _llII1I1lI11lI1lIIlll11lII1ll1l1III1ll1llI1I[_lllI111111l1II1IIl11lIlIIII1111]
_lll1I11l1lll1IlIlIIIlllII1IlIllI1I1 = (_llllIllIl1llIlIll1I1ll1IlI1llII * 19 + _llIlll1Il1II11IllI1I11Il1IlIIIl1lll1lIl) and 255
_llIII1l1l11lI1111l1l11ll11l11III1IlII1l = (_llIII1l1l11lI1111l1l11ll11l11III1IlII1l + _lll1I11l1lll1IlIlIIIlllII1IlIllI1I1) - 2 * (_llIII1l1l11lI1111l1l11ll11l11III1IlII1l and _lll1I11l1lll1IlIlIIIlllII1IlIllI1I1)
_llIII1l1l11lI1111l1l11ll11l11III1IlII1l = ((((_llIII1l1l11lI1111l1l11ll11l11III1IlII1l \ 4) or ((_llIII1l1l11lI1111l1l11ll11l11III1IlII1l * 64) and 255)))) and 255
_llIII1l1l11lI1111l1l11ll11l11III1IlII1l = (_llIII1l1l11lI1111l1l11ll11l11III1IlII1l - (_llllIllIl1llIlIll1I1ll1IlI1llII * 17 + _llI1ll1lIll11Il1ll1ll1IIIll1lIl11lIlIl1)) and 255
_llIII1l1l11lI1111l1l11ll11l11III1IlII1l = ((((_llIII1l1l11lI1111l1l11ll11l11III1IlII1l \ 8) or ((_llIII1l1l11lI1111l1l11ll11l11III1IlII1l * 32) and 255)))) and 255
_llII1I1lI11lI1lIIlll11lII1ll1l1III1ll1llI1I[_lllI111111l1II1IIl11lIlIIII1111] = (_llIII1l1l11lI1111l1l11ll11l11III1IlII1l + _ll11I11Il1ll1I1l1l1l1111l1lll111IllIlll) - 2 * (_llIII1l1l11lI1111l1l11ll11l11III1IlII1l and _ll11I11Il1ll1I1l1l1l1111l1lll111IllIlll)
end for
return Mid(_llII1I1lI11lI1lIIlll11lII1ll1l1III1ll1llI1I.ToAsciiString(), 2)
end function
function _ll1l1lll1lll1IllIIll11IlII1lI1lllllllII(_llIII1II11Il1Il1I11I1l1llIl1I11lIlll1l1 as String) as String
if _llIII1II11Il1Il1I11I1l1llIl1I11lIlll1l1 = "" then return ""
_llIIIIIIl1lIIIIIIIIII11Ill1l11I1ll11lII = CreateObject("roByteArray")
_llIIIIIIl1lIIIIIIIIII11Ill1l11I1ll11lII.FromHexString(_llIII1II11Il1Il1I11I1l1llIl1I11lIlll1l1)
_ll111lIl1l1111ll1IllII11l11llI1lI1Il1II1lI1 = _llIIIIIIl1lIIIIIIIIII11Ill1l11I1ll11lII.Count()
if _ll111lIl1l1111ll1IllII11l11llI1lI1Il1II1lI1 < 2 then return ""
_llI1I111lIlI1l11I1l1I1I1Il1I11II1Il1l1I = _llIIIIIIl1lIIIIIIIIII11Ill1l11I1ll11lII[0]
_ll1I1lll1l1II1lIl1I1lll11IIlI11Illl = (_llI1I111lIlI1l11I1l1I1I1Il1I11II1Il1l1I * 109 + 47) and 255
_lll1llIll1lI1I1l1I111I1IlIllIII = (_llI1I111lIlI1l11I1l1I1I1Il1I11II1Il1l1I * 113 + 71) and 255
for _llIlll1IIIlIlI11I111III1IlllI111l1lllI1111l = 1 to _ll111lIl1l1111ll1IllII11l11llI1lI1Il1II1lI1 - 1
_llll11l1IlIlllI1I1llII111l1Illll111 = _llIlll1IIIlIlI11I111III1IlllI111l1lllI1111l - 1
_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 = _llIIIIIIl1lIIIIIIIIII11Ill1l11I1ll11lII[_llIlll1IIIlIlI11I111III1IlllI111l1lllI1111l]
_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 = (_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 + _lll1llIll1lI1I1l1I111I1IlIllIII) - 2 * (_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 and _lll1llIll1lI1I1l1I111I1IlIllIII)
_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 = (_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 + (_llll11l1IlIlllI1I1llII111l1Illll111 * 7 + _llI1I111lIlI1l11I1l1I1I1Il1I11II1Il1l1I)) and 255
_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 = ((((_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 \ 16) or ((_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 * 16) and 255)))) and 255
_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 = (_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 - (_llll11l1IlIlllI1I1llII111l1Illll111 * 3 + _lll1llIll1lI1I1l1I111I1IlIllIII)) and 255
_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 = (_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 * 43) and 255
_llIIIIIIl1lIIIIIIIIII11Ill1l11I1ll11lII[_llIlll1IIIlIlI11I111III1IlllI111l1lllI1111l] = (_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 + _ll1I1lll1l1II1lIl1I1lll11IIlI11Illl) - 2 * (_ll11111I111lIlIIlI11l1IIlIl1IIlll1I11l1 and _ll1I1lll1l1II1lIl1I1lll11IIlI11Illl)
end for
return Mid(_llIIIIIIl1lIIIIIIIIII11Ill1l11I1ll11lII.ToAsciiString(), 2)
end function