sub init()
m.keyboard = m.top.findNode(_llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("28afaa5598fbb639f4"))
m.btnActivate = m.top.findNode(_ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll("5c577d21385b91c5bb4fa599"))
m.hwidText = m.top.findNode(_ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll("2f33274d02041c5015"))
m.statusTitle = m.top.findNode(_ll1l111III1IIl1ll11Ill11lI1IllIll11("5d9591a9979ba4c0b0a6b1bd"))
m.statusDetail = m.top.findNode(_ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("5e5a5237225ad13e86dbd436a4"))
m.spinnerLabel = m.top.findNode(_llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11("787ac84998ef8f5a89d3e2416e"))
m.badgeText = m.top.findNode(_ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll("214f84b9aed3c9dd11d6"))
m.activatedActions = m.top.findNode(_ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll("54799ed408fe92e8dcf1a4cb01359aafe5"))
m.btnContinue = m.top.findNode(_llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII("4507541462315c225a2c4645"))
m.btnDeactivate = m.top.findNode(_llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("3de6a15c384a3530e396e96c0fa2"))
m.btnActivate.observeField(_llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11("2f46a9b6dc494664ac1afa0225716e"), _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("7e45582c46a98ccf62d55894b6d9b4ff9aad"))
m.keyboard.observeField(_ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll("3afbe0166bb004"), _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("2282952743e6890c5f12958ff3d6b1fcd7ea"))
if m.btnContinue <> invalid then m.btnContinue.observeField(_ll1l111III1IIl1ll11Ill11lI1IllIll11("55e4d2d4d7f5f7c7f4fefa03ef0305"), _ll1l111III1IIl1ll11Ill11lI1IllIll11("5921234b2a2c452d354f42633f3f4c475456"))
if m.btnDeactivate <> invalid then m.btnDeactivate.observeField(_llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("3305686b76595cce2a6d407bce6164"), _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("7424371115403bbea1c477ea6d87cbeea9f4afc2"))
_llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll = _ll11IlI1IllI11II1IIIl1llll1l1IlllI()
m.hwidText.text = _llll1lI11II1I1l1IllIIIlllllIlllII1I1IIlllll
refreshLicenseState()
if m.keyboard <> invalid then
if m.keyboard.textEditBox <> invalid then
m.keyboard.textEditBox.hintText = _llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII("52227e31742f194a2749263b30347a665f63")
m.keyboard.textEditBox.maxTextLength = 64
end if
m.keyboard.setFocus(true)
_llIIl111Illll1111ll111lllI11Il1l11ll11111ll = _lll1l1I1l1ll1I1IlI1lIIIIl11l1l111I()
if _llIIl111Illll1111ll111lllI11Il1l11ll11111ll <> "" then m.keyboard.text = _llIIl111Illll1111ll111lllI11Il1l11ll11111ll
end if
m.top.observeField(_llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("579ef19c3732cdd0"), _ll1l111III1IIl1ll11Ill11lI1IllIll11("2921234e2a3126275a323e3e4a4b"))
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
end if
end if
end sub
sub refreshLicenseState()
if _ll11llllII111I1II1I1I1IIllII11I11I() then
_ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il = _lll1l1I1l1ll1I1IlI1lIIIIl11l1l111I()
_lllIIllll1llIIlllIllI11lll1ll1lIl11 = U_PrefDefault(_ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("39aaf234a18efe2854ed7c4e23"), _llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11("349d95c712ac8c29f1"))
m.badgeText.text = _llI1lI1IIlIllll11111Ill111IIlIIll1ll1Il("698c954013a172")
m.statusTitle.text = _llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII("726b50684d6a6f75311d147302751e130f") + _ll111lllI1ll1ll1lIlIl11ll1Il1lll1Il
_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1 = U_PrefDefault(_llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11("4c382528dac815916b4b"), "")
_lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I = _llI1lIlII1Illl1II1l11lI1I1111l1ll1(_llIIIIIllI1l111l1lII1IlIII1IIIIIlll11ll1II1)
_llIll1IIIII1ll1l11III111lIII1ll = U_PrefDefault(_ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("2f71982e4534d9"), _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("3b0c203356c104cf"))
m.statusDetail.text = _llI1lI1IIlIllll11111Ill111IIlIIll1ll1Il("46fce231fc578d353b6babda54d6bd") + _llIll1IIIII1ll1l11III111lIII1ll + _llI1lI1IIlIllll11111Ill111IIlIIll1ll1Il("39b79ed0291aefb6dc164e3b596332") + _lllI1Il1l11I1ll1llll1ll1I1l1llIlI1I + chr(10) + _ll1l111III1IIl1ll11Ill11lI1IllIll11("41481a34376e2428293f3e4d4c54508c5055585d4e51a16d5aaa627e7f857c878486c59799ce859ca08ddda4a89cb2afb400")
if m.activatedActions <> invalid then m.activatedActions.visible = true
if m.btnActivate <> invalid then m.btnActivate.text = _ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("34e317909586294710f6c71a247f6605953443e6a400")
else
m.badgeText.text = _ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("4df736e6c5b1e9")
m.statusTitle.text = _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("43dd579a9dc8c38eaf1cffd06ef03b2eea4c7f437da013")
m.statusDetail.text = _llI1lI1IIlIllll11111Ill111IIlIIll1ll1Il("668a6d1722d128d366efa567c9e8fad84ce4dcddf3a0f27a363c7e0f38d9298adddfef54c3f14b1286ac441f2a8b3178af279467b36252a2f5f5378f831aca88dfbfe9dafa")
if m.activatedActions <> invalid then m.activatedActions.visible = false
if m.btnActivate <> invalid then m.btnActivate.text = _llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11("78fe3fad9f19c681014a0696f78a40dcb181efd7234b4aa8f59c59")
end if
end sub
sub onActivateClicked()
_llllI1lI1ll11l1lI1IlIll1II1lI11 = m.keyboard.text
if _llllI1lI1ll11l1lI1IlIll1II1lI11 = invalid then _llllI1lI1ll11l1lI1IlIll1II1lI11 = ""
_lll1I11l1Il1llllI11llI111lIlI1l = CreateObject(_llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("3c0225178b86a114"), _llI1lI1IIlIllll11111Ill111IIlIIll1ll1Il("5ab51d59b4e73826ebab"), Chr(103))
if _lll1I11l1Il1llllI11llI111lIlI1l <> invalid then _llllI1lI1ll11l1lI1IlIll1II1lI11 = _lll1I11l1Il1llllI11llI111lIlI1l.replaceAll(_llllI1lI1ll11l1lI1IlIll1II1lI11, "")
if _llllI1lI1ll11l1lI1IlIll1II1lI11 = "" then
if _ll11llllII111I1II1I1I1IIllII11I11I() then
_llllI1lI1ll11l1lI1IlIll1II1lI11 = _lll1l1I1l1ll1I1IlI1lIIIIl11l1l111I()
else
m.statusDetail.text = _ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("26d0973465991425c7a650b423965076015926756406973742e6a6b4e55b0574c5d4937667d79675c2a517b52087843404a456f864d6117444261476671654b7d7")
m.keyboard.setFocus(true)
return
end if
end if
m.spinnerLabel.visible = true
m.spinnerLabel.text = _llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII("4fa672a160af58af04ef04d85bda1b91238023a3f3b1db92fd96ad8fa6")
m.statusDetail.text = _llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11("729ff1536a9c5714a758aaf1c2b47af59028adedd754fe31d061485d0ed439adabdda10af47faae3e2a2397972ec3cfd69bdd7ee")
if m.authTask <> invalid then m.authTask.control = _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("500346793c")
m.authTask = CreateObject(_ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("4ebf08d742fbebc129"), _llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII("22ec0bf928c416d131ed248c"))
m.authTask.action = _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("7d180bc601346722")
m.authTask.licenseKey = _llllI1lI1ll11l1lI1IlIll1II1lI11
m.authTask.observeField(_ll1l111III1IIl1ll11Ill11lI1IllIll11("33f0eaf700ea05"), _ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll("4f796ea5e7dc22c8fce0057bff"))
m.authTask.control = _ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll("35160b61")
end sub
sub onAuthResult()
m.spinnerLabel.visible = false
_ll1lIIII11l1Ill1lIII111lIIIlIl1111l = m.authTask.result
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l <> invalid and _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.success = true then
m.badgeText.text = _ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll("485b8036ea6034")
m.statusTitle.text = _llI1lI1IIlIllll11111Ill111IIlIIll1ll1Il("23ec9978e9767d178635c190a23dc5afa45ab20e7b668c071ce251c0d20c57")
m.statusDetail.text = _llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII("38640d64196124607a3d660b1f21181f392d2513f407e656dc33fe20f352e15daf32bb2cbb2a4b2f5162175416094c6b45714e707b782e")
refreshLicenseState()
m.top.activationSuccess = true
else
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _ll1l111III1IIl1ll11Ill11lI1IllIll11("4383645c64607268707577408587828894964f58ba96a6a39e6a96aba8a479b8b8c1cac2bad391cbdcc397")
if _ll1lIIII11l1Ill1lIII111lIIIlIl1111l <> invalid and _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.message <> invalid and _ll1lIIII11l1Ill1lIII111lIIIlIl1111l.message <> "" then
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _llIlIlll1I11IllIIllI1lIllII11l1llI(_ll1lIIII11l1Ill1lIII111lIIIlIl1111l.message)
if _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11("64479fe447ab6bca6e0ece875dc200d9240e4571") or _llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11("7139011c14349b905e821bb7324e9ff497a47481aef8") then
_llII1lIIlI1lllI1ll1Il11lIlllll11l1l = _ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("5f1c05b7f50728f6e5e7c732c4c5a6b0672406b0b704d645c2a5c4b7eb8516b135a204f6e8f6a9748aa317b676039575f6a7d473a84254f4b564c77646")
end if
end if
m.badgeText.text = _llI1lI1IIlIllll11111Ill111IIlIIll1ll1Il("2e969dd64252a0")
m.statusTitle.text = _llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII("4b0e7609644e32606707416557765e")
m.statusDetail.text = _llII1lIIlI1lllI1ll1Il11lIlllll11l1l
end if
end sub
sub onContinueClicked()
m.top.activationSuccess = true
end sub
sub onDeactivateClicked()
_ll11I1III1II11lIlI11IlI11ll1lIIlll()
m.keyboard.text = ""
refreshLicenseState()
m.statusDetail.text = _ll1l111III1IIl1ll11Ill11lI1IllIll11("737e5e6770688079377e8281829a829e90a69a9c5b999b64bba2a6bf73babeceb8c1ca828bf3cbe8dce89de9defbf7acebebf4fdf50d06c4fe0f16d02711d91d1e361e3a2c4236f4383d3e393d00")
m.keyboard.setFocus(true)
end sub
function onKeyEvent(_llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 as String, _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl as Boolean) as Boolean
if not _ll11Illl11I1llllII1l11IIlll1l11lIllIIIl then return false
_ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = false
if m.btnActivate <> invalid and m.btnActivate.hasFocus() then _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = true
if m.btnContinue <> invalid and m.btnContinue.hasFocus() then _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = true
if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() then _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 = true
if not m.keyboard.isInFocusChain() and not _ll1I111l1lIlII1III1IIlIllIl11l1Ill1IlI1 then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
if _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 = _ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI("65254650b5") then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
else if m.btnActivate <> invalid and m.btnActivate.hasFocus() then
if m.activatedActions <> invalid and m.activatedActions.visible then
m.btnContinue.setFocus(true)
return true
end if
end if
else if _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 = (Chr(117) + Chr(112)) then
if m.btnActivate <> invalid and m.btnActivate.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
else if m.btnContinue <> invalid and m.btnContinue.hasFocus() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
else if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
end if
else if _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 = _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("5b9add18eb96") then
if m.btnContinue <> invalid and m.btnContinue.hasFocus() and m.btnDeactivate <> invalid and m.btnDeactivate.visible then
m.btnDeactivate.setFocus(true)
return true
end if
else if _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 = _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1("4f176a7df8") then
if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() and m.btnContinue <> invalid and m.btnContinue.visible then
m.btnContinue.setFocus(true)
return true
end if
else if _llI1l1lIl1I11lIl11l1l11IlI11l1I1IIlIlII1lI1 = _llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII("6797639c70") then
if _ll11llllII111I1II1I1I1IIllII11I11I() then
m.top.closeView = true
return true
end if
end if
return false
end function
function _ll1l111III1IIl1ll11Ill11lI1IllIll11(_lll1lll11lI1lIIllIlIlIll1Il1I1I as String) as String
if _lll1lll11lI1lIIllIlIlIll1Il1I1I = "" then return ""
_lllll1l1ll1llIlll1IIIlIlIIllIIIllI11111 = CreateObject("roByteArray")
_lllll1l1ll1llIlll1IIIlIlIIllIIIllI11111.FromHexString(_lll1lll11lI1lIIllIlIlIll1Il1I1I)
_llIIl1I1III1lllIll1IllIIlll1ll111I1l11IIII1 = _lllll1l1ll1llIlll1IIIlIlIIllIIIllI11111.Count()
if _llIIl1I1III1lllIll1IllIIlll1ll111I1l11IIII1 < 2 then return ""
_ll1IIllllI1I1l1Il1lIll1II1l1lIl11II = _lllll1l1ll1llIlll1IIIlIlIIllIIIllI11111[0]
_llIIII11lII1lIIII1II1ll11IllII1 = (_ll1IIllllI1I1l1Il1lIll1II1l1lIl11II * 37 + 11) and 255
_lllllII1l1I1Ill1lI1I1l1l1l11IIIII1l1I1I = (_ll1IIllllI1I1l1Il1lIll1II1l1lIl11II * 59 + 23) and 255
for _llIlI1II1IIl1l1llllIIIlllIlllII1IIlll1IIIlI = 1 to _llIIl1I1III1lllIll1IllIIlll1ll111I1l11IIII1 - 1
_lllll11ll1lIlIllllll111lIl1ll11l1I1Ill1IIll = (_lllll1l1ll1llIlll1IIIlIlIIllIIIllI11111[_llIlI1II1IIl1l1llllIIIlllIlllII1IIlll1IIIlI] - ((_llIlI1II1IIl1l1llllIIIlllIlllII1IIlll1IIIlI - 1) * 3 + _lllllII1l1I1Ill1lI1I1l1l1l11IIIII1l1I1I)) and 255
_lllll1l1ll1llIlll1IIIlIlIIllIIIllI11111[_llIlI1II1IIl1l1llllIIIlllIlllII1IIlll1IIIlI] = (_lllll11ll1lIlIllllll111lIl1ll11l1I1Ill1IIll + _llIIII11lII1lIIII1II1ll11IllII1) - 2 * (_lllll11ll1lIlIllllll111lIl1ll11l1I1Ill1IIll and _llIIII11lII1lIIII1II1ll11IllII1)
end for
return Mid(_lllll1l1ll1llIlll1IIIlIlIIllIIIllI11111.ToAsciiString(), 2)
end function
function _llI1IIlI1I1I1I1l1IIl1lllI11ll111IllllII(_ll11l1111lIII1II1III1I11lI111lIIllII1Il1Il1 as String) as String
if _ll11l1111lIII1II1III1I11lI111lIIllII1Il1Il1 = "" then return ""
_ll1l1llI11I11IIlII1lIIIl1I11ll1lll1I111 = CreateObject("roByteArray")
_ll1l1llI11I11IIlII1lIIIl1I11ll1lll1I111.FromHexString(_ll11l1111lIII1II1III1I11lI111lIIllII1Il1Il1)
_ll1I1l111l1IIIllIIl1II1IIIIIIlI11Il = _ll1l1llI11I11IIlII1lIIIl1I11ll1lll1I111.Count()
if _ll1I1l111l1IIIllIIl1II1IIIIIIlI11Il < 2 then return ""
_ll1Il1lI1lIIl1I1l11Il11l1llll1l = _ll1l1llI11I11IIlII1lIIIl1I11ll1lll1I111[0]
_ll1Ill111III1I11I1lIllllIlllIlIIl1I = (_ll1Il1lI1lIIl1I1l11Il11l1llll1l * 41 + 19) and 255
_llIlll1lIII11Ill1III11l11lIIl1lIII1 = _ll1Il1lI1lIIl1I1l11Il11l1llll1l
for _llIIllIlI111I1llIl11llIIlI1ll11lI1II1lIl1lI = 1 to _ll1I1l111l1IIIllIIl1II1IIIIIIlI11Il - 1
_lllIl1l1llI11Il11IlI1l11III1I11II1l1I11lIll = _ll1l1llI11I11IIlII1lIIIl1I11ll1lll1I111[_llIIllIlI111I1llIl11llIIlI1ll11lI1II1lIl1lI]
_lllIl11lll1IIIlllI1IllIllIllII1II1I = ((_llIIllIlI111I1llIl11llIIlI1ll11lI1II1lIl1lI - 1) * 7) and 255
_lll11IllIIIllIl1lIl1lIlII111111ll1111II = (_lllIl1l1llI11Il11IlI1l11III1I11II1l1I11lIll + _llIlll1lIII11Ill1III11l11lIIl1lIII1) - 2 * (_lllIl1l1llI11Il11IlI1l11III1I11II1l1I11lIll and _llIlll1lIII11Ill1III11l11lIIl1lIII1)
_lll11IllIIIllIl1lIl1lIlII111111ll1111II = (_lll11IllIIIllIl1lIl1lIlII111111ll1111II + _ll1Ill111III1I11I1lIllllIlllIlIIl1I) - 2 * (_lll11IllIIIllIl1lIl1lIlII111111ll1111II and _ll1Ill111III1I11I1lIllllIlllIlIIl1I)
_lll11IllIIIllIl1lIl1lIlII111111ll1111II = (_lll11IllIIIllIl1lIl1lIlII111111ll1111II + _lllIl11lll1IIIlllI1IllIllIllII1II1I) - 2 * (_lll11IllIIIllIl1lIl1lIlII111111ll1111II and _lllIl11lll1IIIlllI1IllIllIllII1II1I)
_ll1l1llI11I11IIlII1lIIIl1I11ll1lll1I111[_llIIllIlI111I1llIl11llIIlI1ll11lI1II1lIl1lI] = _lll11IllIIIllIl1lIl1lIlII111111ll1111II and 255
_llIlll1lIII11Ill1III11l11lIIl1lIII1 = _lllIl1l1llI11Il11IlI1l11III1I11II1l1I11lIll
end for
return Mid(_ll1l1llI11I11IIlII1lIIIl1I11ll1lll1I111.ToAsciiString(), 2)
end function
function _ll11l11IIlIllII11I1IIlI1111IllI1l1II1ll(_lllIlIlIlIIIIll11I1I1ll111l1I1lI11I11II1lll as String) as String
if _lllIlIlIlIIIIll11I1I1ll111l1I1lI11I11II1lll = "" then return ""
_ll1lIll1IIlIlIIII1lIIlll1lIlIll = CreateObject("roByteArray")
_ll1lIll1IIlIlIIII1lIIlll1lIlIll.FromHexString(_lllIlIlIlIIIIll11I1I1ll111l1I1lI11I11II1lll)
_lllI1IllII1lI11ll1lII11IlIII1Il = _ll1lIll1IIlIlIIII1lIIlll1lIlIll.Count()
if _lllI1IllII1lI11ll1lII11IlIII1Il < 2 then return ""
_lllII1I1lllII1lIIl1l1IIIIllIII1I1Il = _ll1lIll1IIlIlIIII1lIIlll1lIlIll[0]
_lll11IlIlII11I1lllllIlIl1ll1I1l1l1IlIIlI11l = (_lllII1I1lllII1lIIl1l1IIIIllIII1I1Il * 53 + 29) and 255
_llI1IIIll11IIllIl111II1I1Il1ll111II1llI = (_lllII1I1lllII1lIIl1l1IIIIllIII1I1Il * 71 + 31) and 255
for _llIll111I1l1lI111IlIIllIIlI1I11lII1lIlIlIl1 = 1 to _lllI1IllII1lI11ll1lII11IlIII1Il - 1
_llI1l1l1I1l1l1Illl1I11IIl11IIllI1lI = (_ll1lIll1IIlIlIIII1lIIlll1lIlIll[_llIll111I1l1lI111IlIIllIIlI1I11lII1lIlIlIl1] - ((_llIll111I1l1lI111IlIIllIIlI1I11lII1lIlIlIl1 - 1) * 5 + _llI1IIIll11IIllIl111II1I1Il1ll111II1llI)) and 255
_llI1l1l1I1l1l1Illl1I11IIl11IIllI1lI = (((_llI1l1l1I1l1l1Illl1I11IIl11IIllI1lI \ 16) or ((_llI1l1l1I1l1l1Illl1I11IIl11IIllI1lI * 16) and 255))) and 255
_ll1lIll1IIlIlIIII1lIIlll1lIlIll[_llIll111I1l1lI111IlIIllIIlI1I11lII1lIlIlIl1] = (_llI1l1l1I1l1l1Illl1I11IIl11IIllI1lI + _lll11IlIlII11I1lllllIlIl1ll1I1l1l1IlIIlI11l) - 2 * (_llI1l1l1I1l1l1Illl1I11IIl11IIllI1lI and _lll11IlIlII11I1lllllIlIl1ll1I1l1l1IlIIlI11l)
end for
return Mid(_ll1lIll1IIlIlIIII1lIIlll1lIlIll.ToAsciiString(), 2)
end function
function _llIl1IIIl11l11ll1I1l11Illlll1l1Ill1(_llIll1I1ll11l1lll1lllllI11III1lI1ll as String) as String
if _llIll1I1ll11l1lll1lllllI11III1lI1ll = "" then return ""
_llIIlIIlIIIl1l1lI11lIII1ll1I1IIl1lIll11lI11 = CreateObject("roByteArray")
_llIIlIIlIIIl1l1lI11lIII1ll1I1IIl1lIll11lI11.FromHexString(_llIll1I1ll11l1lll1lllllI11III1lI1ll)
_ll1IIIIIl1IIll11ll1lI11l1l1lIl1lllI111lIll1 = _llIIlIIlIIIl1l1lI11lIII1ll1I1IIl1lIll11lI11.Count()
if _ll1IIIIIl1IIll11ll1lI11l1l1lIl1lllI111lIll1 < 2 then return ""
_llIl1lI1lIlllIllIlllllllI11IlI1IlIl = _llIIlIIlIIIl1l1lI11lIII1ll1I1IIl1lIll11lI11[0]
_llll1I1II1lll1l1IIllllI1lllIl1lI1111l11IIII = (_llIl1lI1lIlllIllIlllllllI11IlI1IlIl * 67 + 43) and 255
_llI1IlllIl1I1lIIlIll1I11lI1l1Il = (_llIl1lI1lIlllIllIlllllllI11IlI1IlIl * 79 + 17) and 255
for _llllI1llI11I1llIII1lI1IIII11l1I = 1 to _ll1IIIIIl1IIll11ll1lI11l1l1lIl1lllI111lIll1 - 1
_ll111I1l111111I1Ill1IIllIIllll1Il1IlIl1 = (_llIIlIIlIIIl1l1lI11lIII1ll1I1IIl1lIll11lI11[_llllI1llI11I1llIII1lI1IIII11l1I] - ((_llllI1llI11I1llIII1lI1IIII11l1I - 1) * 11 + _llI1IlllIl1I1lIIlIll1I11lI1l1Il)) and 255
_ll111I1l111111I1Ill1IIllIIllll1Il1IlIl1 = ((((_ll111I1l111111I1Ill1IIllIIllll1Il1IlIl1 \ 8) or ((_ll111I1l111111I1Ill1IIllIIllll1Il1IlIl1 * 32) and 255)))) and 255
_llIIlIIlIIIl1l1lI11lIII1ll1I1IIl1lIll11lI11[_llllI1llI11I1llIII1lI1IIII11l1I] = (_ll111I1l111111I1Ill1IIllIIllll1Il1IlIl1 + _llll1I1II1lll1l1IIllllI1lllIl1lI1111l11IIII) - 2 * (_ll111I1l111111I1Ill1IIllIIllll1Il1IlIl1 and _llll1I1II1lll1l1IIllllI1lllIl1lI1111l11IIII)
end for
return Mid(_llIIlIIlIIIl1l1lI11lIII1ll1I1IIl1lIll11lI11.ToAsciiString(), 2)
end function
function _ll1II1Ill1I11ll1lI1l1lIII1IlIllI1lIllll1llI(_llllI1lI11lIIIII1IIII1lIIlIIlIII1II as String) as String
if _llllI1lI11lIIIII1IIII1lIIlIIlIII1II = "" then return ""
_llI1I1Ill111IIIlI1I1IllIlI1III11Ill1III = CreateObject("roByteArray")
_llI1I1Ill111IIIlI1I1IllIlI1III11Ill1III.FromHexString(_llllI1lI11lIIIII1IIII1lIIlIIlIII1II)
_llI1I11III1IlI11lI111ll111l111lI11I = _llI1I1Ill111IIIlI1I1IllIlI1III11Ill1III.Count()
if _llI1I11III1IlI11lI111ll111l111lI11I < 2 then return ""
_llI111llIll1IIll1I11I111Il11l1lIIll111IlIII = _llI1I1Ill111IIIlI1I1IllIlI1III11Ill1III[0]
_ll1I11lIIlI1111llIIIll1lllIl1IlI1l1 = (_llI111llIll1IIll1I11I111Il11l1lIIll111IlIII * 73 + 19) and 255
_llIll11I1llI1l1llI1lll111111lIlIIII = (_llI111llIll1IIll1I11I111Il11l1lIIll111IlIII * 83 + 37) and 255
for _llII1l1lll1IllllIl1IIII1l1IIIl1Il111ll1 = 1 to _llI1I11III1IlI11lI111ll111l111lI11I - 1
_lllll11lI1lllIIl11l1lIIlI1I11lII11I1llI = _llII1l1lll1IllllIl1IIII1l1IIIl1Il111ll1 - 1
_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 = _llI1I1Ill111IIIlI1I1IllIlI1III11Ill1III[_llII1l1lll1IllllIl1IIII1l1IIIl1Il111ll1]
_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 = ((((_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 \ 4) or ((_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 * 64) and 255)))) and 255
_llll1lll1IIlll1IIl111lIIll1IlII = (_lllll11lI1lllIIl11l1lIIlI1I11lII11I1llI * 13 + _llI111llIll1IIll1I11I111Il11l1lIIll111IlIII) and 255
_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 = (_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 + _llll1lll1IIlll1IIl111lIIll1IlII) - 2 * (_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 and _llll1lll1IIlll1IIl111lIIll1IlII)
_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 = (_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 - (_lllll11lI1lllIIl11l1lIIlI1I11lII11I1llI * 7 + _llIll11I1llI1l1llI1lll111111lIlIIII)) and 255
_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 = ((((_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 \ 16) or ((_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 * 16) and 255)))) and 255
_llI1I1Ill111IIIlI1I1IllIlI1III11Ill1III[_llII1l1lll1IllllIl1IIII1l1IIIl1Il111ll1] = (_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 + _ll1I11lIIlI1111llIIIll1lllIl1IlI1l1) - 2 * (_llIIlIIl1l11Il1IllI1111l1I111IlllI1I1lIIlI1 and _ll1I11lIIlI1111llIIIll1lllIl1IlI1l1)
end for
return Mid(_llI1I1Ill111IIIlI1I1IllIlI1III11Ill1III.ToAsciiString(), 2)
end function
function _llI1lI1IIlIllll11111Ill111IIlIIll1ll1Il(_llII11I11IIlIllI11l1llIIlIIlIlll11I as String) as String
if _llII11I11IIlIllI11l1llIIlIIlIlll11I = "" then return ""
_llllI1l1lI1111l1lIIl1lI1lIIlIll1IIl = CreateObject("roByteArray")
_llllI1l1lI1111l1lIIl1lI1lIIlIll1IIl.FromHexString(_llII11I11IIlIllI11l1llIIlIIlIlll11I)
_lll1IlIlIlII1I1lIl1l1I1I11IIIII = _llllI1l1lI1111l1lIIl1lI1lIIlIll1IIl.Count()
if _lll1IlIlIlII1I1lIl1l1I1I11IIIII < 2 then return ""
_lllIIIl11I1Illl1IIl1l111IlII1lIl11II1Il = _llllI1l1lI1111l1lIIl1lI1lIIlIll1IIl[0]
_lllII1lll1lIIl1111III1IIIlIlIlI1IlI1II1lIIl = (_lllIIIl11I1Illl1IIl1l111IlII1lIl11II1Il * 97 + 53) and 255
_llIlI1llIIl1Il1llIIl111lI1Il1l11I1l = (_lllIIIl11I1Illl1IIl1l111IlII1lIl11II1Il * 103 + 61) and 255
for _ll1lllI11l1llIlllIIIl1l1Ill1I1l = 1 to _lll1IlIlIlII1I1lIl1l1I1I11IIIII - 1
_lll11lIl11I11lIIlI1l1l1I1I11I1IIl11l1lIlI1l = _ll1lllI11l1llIlllIIIl1l1Ill1I1l - 1
_llllIIl11ll1I1IIIIllll1l11I1lll11ll = _llllI1l1lI1111l1lIIl1lI1lIIlIll1IIl[_ll1lllI11l1llIlllIIIl1l1Ill1I1l]
_llIIlI1Il1III11l1I1l1IIlII11lIlll1lI1Il = (_lll11lIl11I11lIIlI1l1l1I1I11I1IIl11l1lIlI1l * 19 + _lllIIIl11I1Illl1IIl1l111IlII1lIl11II1Il) and 255
_llllIIl11ll1I1IIIIllll1l11I1lll11ll = (_llllIIl11ll1I1IIIIllll1l11I1lll11ll + _llIIlI1Il1III11l1I1l1IIlII11lIlll1lI1Il) - 2 * (_llllIIl11ll1I1IIIIllll1l11I1lll11ll and _llIIlI1Il1III11l1I1l1IIlII11lIlll1lI1Il)
_llllIIl11ll1I1IIIIllll1l11I1lll11ll = ((((_llllIIl11ll1I1IIIIllll1l11I1lll11ll \ 4) or ((_llllIIl11ll1I1IIIIllll1l11I1lll11ll * 64) and 255)))) and 255
_llllIIl11ll1I1IIIIllll1l11I1lll11ll = (_llllIIl11ll1I1IIIIllll1l11I1lll11ll - (_lll11lIl11I11lIIlI1l1l1I1I11I1IIl11l1lIlI1l * 17 + _llIlI1llIIl1Il1llIIl111lI1Il1l11I1l)) and 255
_llllIIl11ll1I1IIIIllll1l11I1lll11ll = ((((_llllIIl11ll1I1IIIIllll1l11I1lll11ll \ 8) or ((_llllIIl11ll1I1IIIIllll1l11I1lll11ll * 32) and 255)))) and 255
_llllI1l1lI1111l1lIIl1lI1lIIlIll1IIl[_ll1lllI11l1llIlllIIIl1l1Ill1I1l] = (_llllIIl11ll1I1IIIIllll1l11I1lll11ll + _lllII1lll1lIIl1111III1IIIlIlIlI1IlI1II1lIIl) - 2 * (_llllIIl11ll1I1IIIIllll1l11I1lll11ll and _lllII1lll1lIIl1111III1IIIlIlIlI1IlI1II1lIIl)
end for
return Mid(_llllI1l1lI1111l1lIIl1lI1lIIlIll1IIl.ToAsciiString(), 2)
end function
function _llll11I1ll11l1lll1llIll1l1IllI111lIIl1lII11(_llII1llllll1I111I11l1I11lI1llI1 as String) as String
if _llII1llllll1I111I11l1I11lI1llI1 = "" then return ""
_llI1111ll1I1lI1I111l1I1Ill1IIII1lI11IlllIll = CreateObject("roByteArray")
_llI1111ll1I1lI1I111l1I1Ill1IIII1lI11IlllIll.FromHexString(_llII1llllll1I111I11l1I11lI1llI1)
_lllIII111lI1IlIl1II1I1I11II1l1IlIIl = _llI1111ll1I1lI1I111l1I1Ill1IIII1lI11IlllIll.Count()
if _lllIII111lI1IlIl1II1I1I11II1l1IlIIl < 2 then return ""
_ll1l1III11lIl1IlI1II11Il1Il11lIII1l11ll = _llI1111ll1I1lI1I111l1I1Ill1IIII1lI11IlllIll[0]
_llI1lIIIIIllI1lIlIIIlIl1IIIl1IIIlIIllI1l1l1 = (_ll1l1III11lIl1IlI1II11Il1Il11lIII1l11ll * 109 + 47) and 255
_ll1Il11l1Il1l1II1I1II11Il1II111 = (_ll1l1III11lIl1IlI1II11Il1Il11lIII1l11ll * 113 + 71) and 255
for _ll111I1I1IIlIlIIIl1l111II1IlIl1 = 1 to _lllIII111lI1IlIl1II1I1I11II1l1IlIIl - 1
_lllII11lIIIlIl1IlIII1l11l1111111I1I1IlIIIlI = _ll111I1I1IIlIlIIIl1l111II1IlIl1 - 1
_llIII1IlI1lIIll1l1lIIl1l1II1III = _llI1111ll1I1lI1I111l1I1Ill1IIII1lI11IlllIll[_ll111I1I1IIlIlIIIl1l111II1IlIl1]
_llIII1IlI1lIIll1l1lIIl1l1II1III = (_llIII1IlI1lIIll1l1lIIl1l1II1III + _ll1Il11l1Il1l1II1I1II11Il1II111) - 2 * (_llIII1IlI1lIIll1l1lIIl1l1II1III and _ll1Il11l1Il1l1II1I1II11Il1II111)
_llIII1IlI1lIIll1l1lIIl1l1II1III = (_llIII1IlI1lIIll1l1lIIl1l1II1III + (_lllII11lIIIlIl1IlIII1l11l1111111I1I1IlIIIlI * 7 + _ll1l1III11lIl1IlI1II11Il1Il11lIII1l11ll)) and 255
_llIII1IlI1lIIll1l1lIIl1l1II1III = ((((_llIII1IlI1lIIll1l1lIIl1l1II1III \ 16) or ((_llIII1IlI1lIIll1l1lIIl1l1II1III * 16) and 255)))) and 255
_llIII1IlI1lIIll1l1lIIl1l1II1III = (_llIII1IlI1lIIll1l1lIIl1l1II1III - (_lllII11lIIIlIl1IlIII1l11l1111111I1I1IlIIIlI * 3 + _ll1Il11l1Il1l1II1I1II11Il1II111)) and 255
_llIII1IlI1lIIll1l1lIIl1l1II1III = (_llIII1IlI1lIIll1l1lIIl1l1II1III * 43) and 255
_llI1111ll1I1lI1I111l1I1Ill1IIII1lI11IlllIll[_ll111I1I1IIlIlIIIl1l111II1IlIl1] = (_llIII1IlI1lIIll1l1lIIl1l1II1III + _llI1lIIIIIllI1lIlIIIlIl1IIIl1IIIlIIllI1l1l1) - 2 * (_llIII1IlI1lIIll1l1lIIl1l1II1III and _llI1lIIIIIllI1lIlIIIlIl1IIIl1IIIlIIllI1l1l1)
end for
return Mid(_llI1111ll1I1lI1I111l1I1Ill1IIII1lI11IlllIll.ToAsciiString(), 2)
end function