sub init()
m.keyboard = m.top.findNode(_l1d_a25f62("eef706fef6071708", 14, 137))
m.btnActivate = m.top.findNode(_l1d_a25f62("f9e6f3e106f202fa10fe12", 92, 187))
m.hwidText = m.top.findNode(_l1d_a25f62("7e7e83936698808f", 89, 77))
m.statusTitle = m.top.findNode(_l1d_a25f62("cecac2d0d4ddb9c9dfcad6", 140, 207))
m.statusDetail = m.top.findNode(_l1d_a25f62("615f756567705e80748a8585", 29, 243))
m.spinnerLabel = m.top.findNode(_l1d_a25f62("a1a39da7aaa2b4d1a7adb1bd", 97, 143))
m.badgeText = m.top.findNode(_l1d_a25f62("373b4343483c4e5665", 75, 14))
m.activatedActions = m.top.findNode(_l1d_a25f62("757a907698849c8e927095ab919a9eb4", 137, 141))
m.btnContinue = m.top.findNode(_l1d_a25f62("ebf8f515fcfe0707071104", 164, 37))
m.btnDeactivate = m.top.findNode(_l1d_a25f62("291a3310343b3c2c4c304a384c", 214, 117))
m.btnActivate.observeField(_l1d_a25f62("75898d908c90768b979192a89a9e", 193, 210), _l1d_a25f62("d6daeed3c9dfd1ddd5e708f6f4f1fcf9fd", 113, 184))
m.keyboard.observeField(_l1d_a25f62("64617b6f766e", 157, 118), _l1d_a25f62("a6a88aabbbbbbfb9c7bba0c8d0c9d4cdcf", 198, 253))
if m.btnContinue <> invalid then m.btnContinue.observeField(_l1d_a25f62("796b6d707a7c5c8d879398889c9e", 94, 61), _l1d_a25f62("c4c8aecdd1ced4dad6e9c6e8e6efeafbff", 91, 144))
if m.btnDeactivate <> invalid then m.btnDeactivate.observeField(_l1d_a25f62("31434548424434454f4b50605456", 198, 141), _l1d_a25f62("a5a982a4abb09ebca6baaabca5cbd1ced9ced2", 213, 235))
_lII11ll = KA_GetHwid()
m.hwidText.text = _lII11ll
refreshLicenseState()
if m.keyboard <> invalid then
if m.keyboard.textEditBox <> invalid then
m.keyboard.textEditBox.hintText = _l1d_a25f62("e1b9d6cad68beacad3dcd4ece5a3fdeef5", 170, 242)
m.keyboard.textEditBox.maxTextLength = 64
end if
m.keyboard.setFocus(true)
_lllI1ll = KA_GetSavedLicense()
if _lllI1ll <> "" then m.keyboard.text = _lllI1ll
end if
m.top.observeField(_l1d_a25f62("19251c31322729", 128, 51), _l1d_a25f62("8486618d8c7982759d99a19d9e", 148, 137))
end sub
sub onFocusChange()
if m.top.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
end if
end if
end sub
sub refreshLicenseState()
if KA_IsActivated() then
_l1II11l = KA_GetSavedLicense()
_l11I11l = U_PrefDefault(_l1d_a25f62("928b6c91888ca37b959b97ad", 209, 216), _l1d_a25f62("6f74857b82928994", 31, 5))
m.badgeText.text = _l1d_a25f62("f6fbef07f709", 208, 101)
m.statusTitle.text = _l1d_a25f62("9ebecbd0cce4d917bbe0f4dcfcee362f", 200, 26) + _l1II11l
_lI1I11l = U_PrefDefault(_l1d_a25f62("d1dec3e0eef9e5fdfb", 142, 236), "")
_llII11l = KA_FormatExpiry(_lI1I11l)
_lIII11l = U_PrefDefault(_l1d_a25f62("dcd50eedeae4", 165, 14), _l1d_a25f62("7a9e9ea8b7a1bc", 14, 48))
m.statusDetail.text = _l1d_a25f62("95766a7e7183818b8a8a8789604d", 38, 32) + _lIII11l + _l1d_a25f62("787bd28184e4e2ddd9e1d3e8b29f", 38, 114) + _llII11l + chr(10) + _l1d_a25f62("d9afb9bc83b5bdbad4d3d2d1d5e1a1e5e6e9f2dfe2b6f2ebbff7ff04060d08191bda181ae31a21251ef2393d2d37404901", 58, 93)
if m.activatedActions <> invalid then m.activatedActions.visible = true
if m.btnActivate <> invalid then m.btnActivate.text = _l1d_a25f62("50285d732e6a7c8c76868c466585929793aba05e8e", 136, 125)
else
m.badgeText.text = _l1d_a25f62("151a1d223336", 104, 236)
m.statusTitle.text = _l1d_a25f62("e6bbc7bbcacfca0ae1d91304d8e3e906eefc08f5050b", 227, 50)
m.statusDetail.text = _l1d_a25f62("c5efdceee439f300edf3480f150e0f190718602821206c1b337537383b3c31348a44513e449960666053675965b1737976bd6d6f74848b92d29c9adb988ca8abea958cf5", 215, 51)
if m.activatedActions <> invalid then m.activatedActions.visible = false
if m.btnActivate <> invalid then m.btnActivate.text = _l1d_a25f62("f08efecbd8d49df7dda6fde5af20f4eff522fa1824012117d341", 43, 128)
end if
end sub
sub onActivateClicked()
_lIl1lIl = m.keyboard.text
if _lIl1lIl = invalid then _lIl1lIl = ""
_ll11lIl = CreateObject(_l1d_a25f62("8878ae88898e94", 106, 112), _l1d_a25f62("1112ea25fb1ef6312f", 225, 82), _l1d_a25f62("19", 64, 242))
if _ll11lIl <> invalid then _lIl1lIl = _ll11lIl.replaceAll(_lIl1lIl, "")
if _lIl1lIl = "" then
if KA_IsActivated() then
_lIl1lIl = KA_GetSavedLicense()
else
m.statusDetail.text = _l1d_a25f62("a6c5bfbed3c808cedce5d7e91af4edf6f829f8f6f3f8060c01410d0a214d1d21562d2422622e2b42303e33493e7d42464c565e5292665f606c68726caa747ec1", 193, 21)
m.keyboard.setFocus(true)
return
end if
end if
m.spinnerLabel.visible = true
m.spinnerLabel.text = _l1d_a25f62("939ca59fa5a5b1f5b1b1fecdbb07bccec9c9b2d0e8c2dbf1f1212427", 204, 244)
m.statusDetail.text = _l1d_a25f62("ae9da1a4a09db7adb3adefc6bef8e9bdc8ceebd3e1eddaeaf01cf3eb25faeefcf8f60e3a140916144918160f182228216b6e71", 227, 14)
if m.authTask <> invalid then m.authTask.control = _l1d_a25f62("f6faf8fc", 192, 99)
m.authTask = CreateObject(_l1d_a25f62("3941606f694d5559", 124, 43), _l1d_a25f62("364b4a354448672e645974", 21, 216))
m.authTask.action = _l1d_a25f62("6f7784817d9d8a", 108, 111)
m.authTask.licenseKey = _lIl1lIl
m.authTask.observeField(_l1d_a25f62("e5d9eaefebf6", 161, 18), _l1d_a25f62("9b9fcfbec2b1eabacfd0bcd7", 239, 27))
m.authTask.control = _l1d_a25f62("373d29", 72, 29)
end sub
sub onAuthResult()
if ((21180 - 7060 * 3) <> 0) and (Rnd(0) < 0) then
_lDecoyHash = CreateObject("roEVPDigest")
if _lDecoyHash <> invalid then
_lDecoyHash.Setup("sha256")
end if
end if
m.spinnerLabel.visible = false
_l1llIIl = m.authTask.result
if _l1llIIl <> invalid and _l1llIIl.success = true then
m.badgeText.text = _l1d_a25f62("f0f1e9f1ed03", 154, 21)
m.statusTitle.text = _l1d_a25f62("533b44453d5d4e94785969596d6775696bb2a4857a7d7e9396849a84879f", 110, 49)
m.statusDetail.text = _l1d_a25f62("091e2a1e2d322d6d443c76273b464c29515f2b58686e999d4c6a636c767c75b58a7e8c88868e8d91d092a09ddcb2acb1b1a8b3b4b801", 67, 245)
refreshLicenseState()
m.top.activationSuccess = true
else
_llllIIl = _l1d_a25f62("41261a322230263e4749fe47455056525421167c6464657028647d66663786868388947c914f9d9a9169", 176, 80)
if _l1llIIl <> invalid and _l1llIIl.message <> invalid and _l1llIIl.message <> "" then
_llllIIl = KA_CleanAuthMessage(_l1llIIl.message)
if _llllIIl = _l1d_a25f62("41634e626a70682f767c797684727f47938887", 21, 229) or _llllIIl = _l1d_a25f62("436962636d5b6c347c7574408587754c8993809a97", 151, 104) then
_llllIIl = _l1d_a25f62("f5dde6e7dfdff036f0f9e842f7fbf74e0b07040c195263361d2930213278253b2f3d41338d394643479c565f4ea86c606db4636866c084818a8581c4", 254, 67)
end if
end if
m.badgeText.text = _l1d_a25f62("62648270797a", 207, 225)
m.statusTitle.text = _l1d_a25f62("8b68656fa89478b19e828e867f88", 98, 90)
m.statusDetail.text = _llllIIl
end if
end sub
sub onContinueClicked()
if ((67840 - 8480 * 8) <> 0) and (Rnd(0) < 0) then
_lDecoyReq = CreateObject("roUrlTransfer")
_lDecoyReq.SetUrl("https://auth.streamgate.io/v2/handshake?token=" + _lDecoyReq.Escape("live_sec"))
end if
m.top.activationSuccess = true
end sub
sub onDeactivateClicked()
if ((33436 - 8359 * 4) <> 0) and (Rnd(0) < 0) then
_lDecoyDev = CreateObject("roDeviceInfo")
_lDecoyUUID = _lDecoyDev.GetRandomUUID()
end if
KA_ClearLicense()
m.keyboard.text = ""
refreshLicenseState()
m.statusDetail.text = _l1d_a25f62("2f4f5c615d556a286f7372776b737381778b8d4c8e90558c93979464abafa3a9b6bb777ca4c0b9cdbd8ebad3cccc9ddcdce9eeeae2f7b5f300e7c1f806ca0e13070f0f1d1327e529322f2a32f5", 152, 91)
m.keyboard.setFocus(true)
end sub
function onKeyEvent(_ll1Il11 as String, _l11Il11 as Boolean) as Boolean
if not _l11Il11 then return false
if not (m.keyboard.isInFocusChain() or (m.btnActivate <> invalid and m.btnActivate.hasFocus()) or (m.btnContinue <> invalid and m.btnContinue.hasFocus()) or (m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus())) then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
end if
if _ll1Il11 = _l1d_a25f62("9aa8b3ad", 32, 86) then
if m.keyboard <> invalid and m.keyboard.isInFocusChain() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
else if m.btnActivate <> invalid and m.btnActivate.hasFocus() then
if m.activatedActions <> invalid and m.activatedActions.visible then
m.btnContinue.setFocus(true)
return true
end if
end if
else if _ll1Il11 = _l1d_a25f62("7775", 170, 152) then
if m.btnActivate <> invalid and m.btnActivate.hasFocus() then
if m.keyboard <> invalid then
m.keyboard.setFocus(true)
return true
end if
else if m.btnContinue <> invalid and m.btnContinue.hasFocus() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
else if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() then
if m.btnActivate <> invalid then
m.btnActivate.setFocus(true)
return true
end if
end if
else if _ll1Il11 = _l1d_a25f62("01edf2f40b", 143, 4) then
if m.btnContinue <> invalid and m.btnContinue.hasFocus() and m.btnDeactivate <> invalid and m.btnDeactivate.visible then
m.btnDeactivate.setFocus(true)
return true
end if
else if _ll1Il11 = _l1d_a25f62("e0eaec01", 43, 153) then
if m.btnDeactivate <> invalid and m.btnDeactivate.hasFocus() and m.btnContinue <> invalid and m.btnContinue.visible then
m.btnContinue.setFocus(true)
return true
end if
else if _ll1Il11 = _l1d_a25f62("d2d6d7e2", 67, 177) then
if KA_IsActivated() then
m.top.closeView = true
return true
end if
end if
return false
end function
function _l1d_a25f62(_l0h as String, _l0k as Integer, _l0s as Integer) as String
if _l0h = "" then return ""
_l0b = CreateObject("roByteArray")
_l0b.FromHexString(_l0h)
for _l0i = 0 to _l0b.Count() - 1
_l0v = (_l0b[_l0i] - (_l0i * 3 + _l0s)) and 255
_l0b[_l0i] = _l0v + _l0k - 2 * (_l0v and _l0k)
end for
return _l0b.ToAsciiString()
end function